# Zero-Sum

Protótipo de deckbuilder roguelike para Android (Godot 4.3+, **horizontal**), híbrido de Magic: The Gathering e Balatro:
tabuleiro com mana e criaturas (Magic) + dano calculado numa cascata **Poder × Mult** com relíquias a disparar uma a uma (Balatro).
Conteúdo: **300 cartas em 18 baralhos** (base de dados "Mana Cascade", convertida por `tools/convert_cards.py`).

## Loop

1. **Menu**: Novo Jogo (campanha), Continuar (a run guardada), Modo Livre (todos os baralhos e os baralhos personalizados, não conta para o progresso), Dificuldade (Fácil / Normal / Difícil: vida do inimigo ×0,7 / ×1 / ×1,4 e 4 / 3 / 2 canalizações por batalha), Como Jogar, Coleção, Estatísticas, Construtor, Configurações.
2. **Configurações** (`user://settings.json`, autoload `Settings`): volume dos efeitos (bus "Sfx"; o controlo de música aparece quando existir `assets/audio/music.ogg`, bus "Music"), idioma (automático / português / inglês — interface, cartas, relíquias, inimigos e regras; só a história da campanha fica em português), velocidade das animações (normal / rápida / instantânea — `Settings.dur(s)` escala todas as durações), vibração, **texto das cartas** (normal / grande), **mão dominante** (direita / esquerda: a coluna de ações troca de lado), repetir o tutorial, apagar progresso.
3. **Campanha** (`data/campaign.json`): 3 atos com história; cada capítulo é um dos 18 baralhos (8 a 26 cartas, 1 a 3 cores, dificuldade ★ a ★★★★★). Chegar ao ante 4 abre o capítulo seguinte; ao ante 6, o ato seguinte. O progresso fica em `user://progress.json`; a run em curso em `user://run.json`, gravada **no início de cada turno** com o estado da batalha (`BattleManager.to_dict/restore`) e ao entrar/sair da loja — Continuar retoma exatamente aí. Abandonar (menu de pausa) conta como derrota nesse ante.
4. **Batalha**: 5 turnos para reduzir a vida do inimigo a 0. Botão PAUSA (Continuar, Configurações, Como Jogar, Abandonar); toque longo numa carta abre-a em grande com o texto completo; GRIMÓRIO/CEMITÉRIO listam as zonas (o grimório ordenado por custo, para não revelar a ordem); toque numa relíquia mostra a descrição. O botão "retroceder" do Android abre a pausa / fecha painéis.
   - **Pré-visualizações**: cada carta jogável mostra o delta do total (`BattleManager.preview_play`, aproximação que ignora efeitos imediatos); a barra do inimigo mostra o dano previsto (segmento claro) e o botão fica verde/LETAL; o painel do inimigo diz quem bloqueia o contra-ataque e o que o inimigo faz a seguir (`preview_enemy_phase`, `enemy_intent`).
   - **Desfazer** (dentro do turno): `BattleManager.snapshot/restore_snapshot` guardam batalha + RNG + ouro + bónus permanentes antes de cada jogada/canalização.
   - **Arrastar** criaturas no tabuleiro e relíquias na prateleira reordena-as (a ordem importa: reativações, ×Mult depois de +Mult).
   - **Vida persistente**: a vida atravessa a run (cura na loja/eventos); chegar a 0 acaba a run.
   - **Bosses** nos antes múltiplos de 4 (`GameState.pick_enemy`): `rule` em `enemies.json` — `discards_minus`, `hand_size`, `creature_cost_plus`, `no_formations`, `relics_off`, `color_silenced`. Inimigos têm `acts` (conjunto por ato do baralho) e `min_ante`.
   - Mana: no turno N tens N+1 (2 → 6). Terrenos são opcionais: na mão dão bónus ("[Na Mão]"); jogados dão +1 mana permanente.
   - A mão repõe-se até 6 no início de cada turno. Se o grimório acabar, o cemitério é rebaralhado.
   - Criaturas ficam no tabuleiro (máx. 5) e atacam **todas** ao fim do turno. Feitiços custam 1 a menos (mín. 1) e contam no ataque desse turno.
   - **Canalizar**: botão CANALIZAR (N) e depois toque numa carta da mão — descarta-a e compra outra. Alimenta cemitério e "hellbent".
   - O inimigo responde: a criatura mais robusta que **sobreviva** ao golpe bloqueia; senão levas tu — a não ser que fosse letal (aí as criaturas sacrificam-se). Vida reposta no início de cada batalha.
5. **Loja**: 3 cartas das cores do baralho, booster (escolhe 1 de 3), novas ofertas (preço sobe), 2 relíquias ponderadas por raridade (máx. 5 relíquias; vender a metade do preço), curar (3 ouro → 5 vida), vida máxima +5 (uma vez por visita), melhorar uma carta (+10 Poder ou +0,5 Mult permanentes, via `deck[i].power_bonus/mult_bonus`), remover uma carta, ver baralho. Juros: +1 ouro por cada 5 guardados ao entrar (máx. 5).
6. **Eventos** (`data/events.json`) depois dos antes 2, 5 e 7: 2–3 opções com efeitos `gold`, `heal`, `max_hp`, `relic`, `card`, `remove_cards`, `grow_random`, `mult_random`; filtrados pelo ato, sem repetir na run.
7. Próximo ante → inimigo com mais vida (`GameState.ANTE_HP` × dificuldade). 8 antes = vitória; no ecrã final, **Modo Infinito** continua a run (vida do inimigo ×1,6 por ante a partir do 9, bosses de 4 em 4, juros e eventos continuam) até perderes — conta para o melhor ante.
8. **Tutorial** (`scenes/battle/Tutorial.gd`): na primeira batalha de sempre, 5 passos por cima do ecrã (jogar, mana, canalizar, atacar, loja); pode saltar-se e repetir-se nas Configurações (`progress.tutorial_done`).
9. **Estatísticas e conquistas** (autoload `Stats`, `data/achievements.json`): contadores globais e por baralho (runs, vitórias, melhor ante, maior ataque, dano total, inimigos/bosses, cartas jogadas, canalizações, turnos, eventos); 18 conquistas `{stat, min}` verificadas a cada mudança, com aviso no ecrã (`SceneRouter.toast`).
10. **Coleção**: as 300 cartas (filtros por baralho e cor), relíquias e inimigos — só os já vistos aparecem com nome e texto, os outros ficam "???" (`progress.seen`).
11. **Construtor de baralhos** (`scenes/builder/DeckBuilder.gd`, `user://custom_decks.json`): 6 espaços; 10 a 30 cartas, máximo 2 cópias, filtros por cor/tipo/custo; "Jogar" arranca uma run em modo livre com esse baralho (`CardDB.custom_decks`, ids `custom_1..custom_6`).

## A cascata

Ao atacar, o `EffectResolver` constrói um `Cascade` que a UI anima passo a passo (a carta avança, etiqueta a flutuar, os pilões Poder/Mult saltam, nota a subir meio-tom, partículas e número a voar até ao inimigo no total). Comprar, jogar (a carta voa da mão para o tabuleiro) e morrer também têm animação; as animações guardam-se por nó e são canceladas antes de o nó ser substituído, para não ficarem a meio.

1. **Criaturas**, pela ordem do tabuleiro: `+Poder` + efeitos `on_attack` (incluindo reativações ↻).
2. **Feitiços lançados neste turno**: `+Poder` + efeitos de cascata.
3. **Formações** (`data/formations.json`): Pacto Dual, Tríade, Bando Tribal, Tempestade Arcana, Curva de Mana 1-5, Devoção Pura, Horda, Convergência WUBRG. Todas as que se aplicarem somam.
4. **Cartas na mão** com efeitos `[Na Mão]` (terrenos, sobretudo).
5. **Relíquias**, da esquerda para a direita.

Dano = `Poder × Mult × vulnerabilidade`. A função é pura: o ecrã mostra sempre a pré-visualização.

## Estrutura

```
data/cards.json          300 cartas (gerado) · cards_en.json (nomes/textos em inglês, tools/make_cards_en.py) · decks.json 18 baralhos · relics.json (31, com raridade) · formations.json · enemies.json (17, com atos e bosses) · campaign.json (atos e história) · events.json (7 eventos) · achievements.json (18 conquistas)
tools/convert_cards.py   documento das 300 cartas → cards.json/decks.json (regras + overrides à mão; -v lista aproximações)
scripts/autoload/        EventBus → ContentUpdate (conteúdo descarregado) → CardDB → Settings → GameState (run, baralho com bónus permanentes, dificuldade, save/progresso) → Stats (estatísticas, conquistas, coleção) → SceneRouter (fade, overlays, toasts) → Sfx
scripts/core/            CardData / CardInstance / Deck / Cascade / BattleManager / EffectResolver / EnemyAbilities
scenes/                  main (menu) · campaign (atos/capítulos) · battle (+PauseMenu, Tutorial) · shop · event · builder (construtor) · ui (CardView com ícones/pips/molduras por raridade, RelicView, HowToPlay, RunOver, SettingsMenu, CardZoom, ZoneViewer — também serve de seletor de cartas, StatsScreen, Collection)
scripts/ui/UiKit.gd      widgets em código (botões, painéis centrados, fundo escuro) para os overlays · CardIcon.gd ícones de tipo desenhados em código
i18n/en.json             tradução da interface (chave = texto PT) · howto.json regras em pt/en · tools/make_en_json.py gera e valida
assets/icons, icon.png, splash.png   ícone (tools/make_icons.py) e ecrã de arranque
tests/SmokeTest.tscn     godot --headless --path . res://tests/SmokeTest.tscn  (0 = passou)
tests/Balance.tscn       simulação: até que ante chega cada baralho sem loja / com loja  (-- --deck=deck12 --verbose)
tests/Screenshots.tscn   capturas das cenas com xvfb (-- --out=/tmp/shots)
tools/make_manifest.py   pacote de atualização de conteúdo assinado (ver Atualizações de conteúdo)
```

## DSL de efeitos (resumo; ver cabeçalho de EffectResolver.gd)

`{"trigger", "action", "value", "per", "per_div", "cap", "filter", "cond", "exclude_self"}`

- triggers: `on_attack` (criatura, cada ataque) · `on_cast` (feitiço) · `on_play` (criatura entra) · `in_hand` · `in_hand_on_play` · `on_discard` · `turn_start` · `passive`
- cascata: `power_add` `mult_add` `mult_mul` `gold` `grow` `power_double_self` `power_pct_enemy` `retrigger (left|right|self|all|first|best|last_spell|last_creature|spells|formations|relics|hand)` `cascade_library (top|strongest|graveyard_spell)`
- imediatas: `draw` `mill` `mill_half` `discard_random` `silence_enemy` `extra_turn` `discard_plus` `consume_discard` `shuffle_graveyard` `enemy_max_hp_pct` `recover` `tutor_*` `grow_*` `destroy_left/right` `enemy_vulnerable`
- `per`: `attacker` `spell` `played` `hand` `graveyard` `library` `land_hand` `land` `gold` `colors` `graveyard_types` `relics` `drawn_this_turn` `discards_used` `neighbors` `max_power` `formations`
- `cond`: `position` `count{of,filter,min,max}` `formation[...]` `all_cost` `library_max` `hand_max/min` `discards_max/min` `gold_min` `enemy_hp_below_pct` `discarded_min/max` `neighbor_color/cost` `neighbors_min` `has_right` `right_cost` `colors_all/any` `hand_has` `hand_all_colorless` `consumed`
- flags de carta: `wild_color` `wild_cost` `counts_as_two` `counts_as` `force_formation` `return_to_library` `approx` (efeito aproximado, mostrado com ≈)

## Equilíbrio (tests/Balance.gd, bot simples)

Sem loja: morre-se no ante 3–5 (Izzet ~4). Com loja sensata (relíquias das suas cores, cura, 1 carta por visita): média 6,5; 10 dos 18 baralhos ganham runs; Centelha Rubra e Falange Solar ganham quase sempre; Izzet, Convergência Planar, Grixis (parede no boss do ante 4) e Orzhov são os mais difíceis. Alavancas: `ANTE_HP`, `hp_mult`/`rule` dos bosses, `formations.json`, overrides em `tools/convert_cards.py`. Nota: `1 in [1.0]` é falso no Godot — os números do JSON comparam-se com `int()` (`GameState._act_in`).

## Tradução

As chaves são o próprio texto em português: os Labels/Buttons das cenas traduzem-se sozinhos (auto translate) e o texto construído em código usa `tr("Turno %d/%d") % [...]` (traduzir o molde, depois formatar). `i18n/en.json` mapeia PT → EN; sem entrada, fica o português. As cartas usam `data/cards_en.json` (id → nome e texto; `tools/make_cards_en.py` gera a partir de um glossário e das regras do conversor) carregado pelo `Settings` para a mesma `Translation`. O fallback do projeto é `pt_PT` (senão o Godot cairia para "en"). Só ficheiros-recurso (.json, .png…) entram no APK — nada de .txt/.md para dados.

## Android

O ecrã usa modo imersivo: a barra de navegação do Android aparece por cima da margem inferior durante uns segundos depois de um toque perto dessa margem. Por isso os botões de ação estão na coluna da esquerda e a mão tem margem inferior — nada de interativo fica debaixo da barra.

## Atualizações de conteúdo (sem APK novo)

Ao arrancar, `ContentUpdate` lê `https://daewonpt.github.io/zerosum-updates/versao.txt` (um repositório público com GitHub Pages). O manifesto (`ZSUPD 1`, linhas `c` versão do conteúdo, `min` versionCode mínimo, `n pt/en` nota, `f <sha256> <tamanho> <caminho>`, `sig` assinatura) é verificado com **ECDSA P-256 / SHA-256** e a chave pública embutida no jogo; só passam caminhos `data/*.json` e `i18n/*.json` (nunca código). Se `c` for maior do que o instalado e a app for recente o suficiente, descarrega cada ficheiro de `f/<sha256>` (confirmando o hash) para `user://content/`, e `CardDB`/`Settings` passam a ler daí. Falhas são silenciosas (`ContentUpdate.clear_downloaded()` volta ao conteúdo do APK).

Publicar: `python3 tools/make_manifest.py --key zerosum-atualizacoes-privada.pem --version 2 --min-app 7 --out pub --note-pt "…" --note-en "…"` e enviar a pasta `pub/` (`versao.txt`, `f/`, `.nojekyll`) para o repositório. A chave privada fica fora do projeto. Um APK novo deve subir `APP_VERSION_CODE`/`BUNDLED_CONTENT_VERSION` em `ContentUpdate.gd` e o manifesto deve usar uma versão maior do que a embutida.

## Próximos passos sugeridos

- Música (bus e controlo já existem; falta a faixa em `assets/audio/music.ogg`).
- Publicação na Play Store (keystore própria, AAB, política de privacidade).
- Mais inimigos e eventos por ato; cartas foil; desafios diários (seed do dia).
