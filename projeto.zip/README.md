# Zero-Sum

Protótipo de deckbuilder roguelike para Android (Godot 4.3+, **horizontal**), híbrido de Magic: The Gathering e Balatro:
tabuleiro com mana e criaturas (Magic) + dano calculado numa cascata **Poder × Mult** com relíquias a disparar uma a uma (Balatro).
Conteúdo: **300 cartas em 18 baralhos** (base de dados "Mana Cascade", convertida por `tools/convert_cards.py`).

## Loop

1. **Menu**: Novo Jogo (campanha), Continuar (a run guardada), Modo Livre (todos os baralhos, não conta para o progresso), Dificuldade (Fácil / Normal / Difícil: vida do inimigo ×0,7 / ×1 / ×1,4 e 4 / 3 / 2 canalizações por batalha), Como Jogar, Configurações.
2. **Configurações** (`user://settings.json`, autoload `Settings`): volume dos efeitos (bus "Sfx"; o controlo de música aparece quando existir `assets/audio/music.ogg`, bus "Music"), idioma (automático / português / inglês — a interface traduz-se, as cartas e a história ficam em português), velocidade das animações (normal / rápida / instantânea — `Settings.dur(s)` escala todas as durações), vibração, apagar progresso.
3. **Campanha** (`data/campaign.json`): 3 atos com história; cada capítulo é um dos 18 baralhos (8 a 26 cartas, 1 a 3 cores, dificuldade ★ a ★★★★★). Chegar ao ante 4 abre o capítulo seguinte; ao ante 6, o ato seguinte. O progresso fica em `user://progress.json`; a run em curso em `user://run.json`, gravada **no início de cada turno** com o estado da batalha (`BattleManager.to_dict/restore`) e ao entrar/sair da loja — Continuar retoma exatamente aí. Abandonar (menu de pausa) conta como derrota nesse ante.
4. **Batalha**: 5 turnos para reduzir a vida do inimigo a 0. Botão PAUSA (Continuar, Configurações, Como Jogar, Abandonar); toque longo numa carta abre-a em grande com o texto completo; GRIMÓRIO/CEMITÉRIO listam as zonas (o grimório ordenado por custo, para não revelar a ordem); toque numa relíquia mostra a descrição. O botão "retroceder" do Android abre a pausa / fecha painéis.
   - Mana: no turno N tens N+1 (2 → 6). Terrenos são opcionais: na mão dão bónus ("[Na Mão]"); jogados dão +1 mana permanente.
   - A mão repõe-se até 6 no início de cada turno. Se o grimório acabar, o cemitério é rebaralhado.
   - Criaturas ficam no tabuleiro (máx. 5) e atacam **todas** ao fim do turno. Feitiços custam 1 a menos (mín. 1) e contam no ataque desse turno.
   - **Canalizar**: botão CANALIZAR (N) e depois toque numa carta da mão — descarta-a e compra outra. Alimenta cemitério e "hellbent".
   - O inimigo responde: a criatura mais robusta que **sobreviva** ao golpe bloqueia; senão levas tu — a não ser que fosse letal (aí as criaturas sacrificam-se). Vida reposta no início de cada batalha.
5. **Loja**: 3 cartas das cores do baralho + 2 relíquias; remoção de 1 carta por visita; "Ver baralho".
6. Próximo ante → inimigo com mais vida (`GameState.ANTE_HP` × dificuldade). 8 antes = vitória.

## A cascata

Ao atacar, o `EffectResolver` constrói um `Cascade` que a UI anima passo a passo (a carta avança, etiqueta a flutuar, os pilões Poder/Mult saltam, nota a subir meio-tom, partículas e número a voar até ao inimigo no total). Comprar, jogar (a carta voa da mão para o tabuleiro) e morrer também têm animação; as animações guardam-se por nó e são canceladas antes de o nó ser substituído, para não ficarem a meio.

1. **Criaturas**, pela ordem do tabuleiro: `+Poder` + efeitos `on_attack` (incluindo reativações ↻).
2. **Feitiços lançados neste turno**: `+Poder` + efeitos de cascata.
3. **Formações** (`data/formations.json`): Pacto Dual, Tríade, Bando Tribal, Tempestade Arcana, Curva de Mana 1-5, Devoção Pura, Horda, Convergência WUBRG. Todas as que se aplicarem somam.
4. **Cartas na mão** com efeitos `[Na Mão]` (terrenos, sobretudo).
5. **Relíquias**, da esquerda para a direita.

Dano = `Poder × Mult × vulnerabilidade`. A função é pura: o ecrã mostra sempre a pré-visualização.

## Estrutura

```
data/cards.json          300 cartas (gerado) · decks.json 18 baralhos · relics.json · formations.json · enemies.json · campaign.json (atos e história)
tools/convert_cards.py   documento das 300 cartas → cards.json/decks.json (regras + overrides à mão; -v lista aproximações)
scripts/autoload/        EventBus → CardDB → GameState (run, baralho com bónus permanentes, dificuldade, save/progresso) → SceneRouter (fade) → Sfx
scripts/core/            CardData / CardInstance / Deck / Cascade / BattleManager / EffectResolver / EnemyAbilities
scenes/                  main (menu) · campaign (atos/capítulos) · battle (+PauseMenu) · shop · ui (CardView, RelicView, HowToPlay, RunOver, SettingsMenu, CardZoom, ZoneViewer)
scripts/ui/UiKit.gd      widgets em código (botões, painéis centrados, fundo escuro) para os overlays
i18n/en.json             tradução da interface (chave = texto PT) · howto.json regras em pt/en · tools/make_en_json.py gera e valida
assets/icons, icon.png, splash.png   ícone (tools/make_icons.py) e ecrã de arranque
tests/SmokeTest.tscn     godot --headless --path . res://tests/SmokeTest.tscn  (0 = passou)
tests/Balance.tscn       simulação: até que ante chega cada baralho sem loja / com loja  (-- --deck=deck12 --verbose)
tests/Screenshots.tscn   capturas das cenas com xvfb (-- --out=/tmp/shots)
```

## DSL de efeitos (resumo; ver cabeçalho de EffectResolver.gd)

`{"trigger", "action", "value", "per", "per_div", "cap", "filter", "cond", "exclude_self"}`

- triggers: `on_attack` (criatura, cada ataque) · `on_cast` (feitiço) · `on_play` (criatura entra) · `in_hand` · `in_hand_on_play` · `on_discard` · `turn_start` · `passive`
- cascata: `power_add` `mult_add` `mult_mul` `gold` `grow` `power_double_self` `power_pct_enemy` `retrigger (left|right|self|all|first|best|last_spell|last_creature|spells|formations|relics|hand)` `cascade_library (top|strongest|graveyard_spell)`
- imediatas: `draw` `mill` `mill_half` `discard_random` `silence_enemy` `extra_turn` `discard_plus` `consume_discard` `shuffle_graveyard` `enemy_max_hp_pct` `recover` `tutor_*` `grow_*` `destroy_left/right` `enemy_vulnerable`
- `per`: `attacker` `spell` `played` `hand` `graveyard` `library` `land_hand` `land` `gold` `colors` `graveyard_types` `relics` `drawn_this_turn` `discards_used` `neighbors` `max_power` `formations`
- `cond`: `position` `count{of,filter,min,max}` `formation[...]` `all_cost` `library_max` `hand_max/min` `discards_max/min` `gold_min` `enemy_hp_below_pct` `discarded_min/max` `neighbor_color/cost` `neighbors_min` `has_right` `right_cost` `colors_all/any` `hand_has` `hand_all_colorless` `consumed`
- flags de carta: `wild_color` `wild_cost` `counts_as_two` `counts_as` `force_formation` `return_to_library` `approx` (efeito aproximado, mostrado com ≈)

## Equilíbrio (tests/Balance.gd, bot simples)

Sem loja: morre-se no ante 3–5 (Izzet ~3). Com loja sensata: média 6,8; 14 dos 18 baralhos ganham runs; Centelha Rubra, Falange Solar e Forja de Urza ganham quase sempre; Izzet, Convergência Planar, Grixis e Orzhov são os mais difíceis. Alavancas: `ANTE_HP`, `formations.json`, overrides em `tools/convert_cards.py`.

## Tradução

As chaves são o próprio texto em português: os Labels/Buttons das cenas traduzem-se sozinhos (auto translate) e o texto construído em código usa `tr("Turno %d/%d") % [...]` (traduzir o molde, depois formatar). `i18n/en.json` mapeia PT → EN; sem entrada, fica o português. O fallback do projeto é `pt_PT` (senão o Godot cairia para "en"). Só ficheiros-recurso (.json, .png…) entram no APK — nada de .txt/.md para dados.

## Android

O ecrã usa modo imersivo: a barra de navegação do Android aparece por cima da margem inferior durante uns segundos depois de um toque perto dessa margem. Por isso os botões de ação estão na coluna da esquerda e a mão tem margem inferior — nada de interativo fica debaixo da barra.

## Próximos passos sugeridos

- Reordenar criaturas/relíquias (arrastar) — a ordem importa com reativações e ×Mult.
- Regras de boss ("cartas azuis silenciadas", "-1 Canalização") e um ecrã de deck durante a run.
- Booster packs (escolher 1 de 3) e cartas foil/míticas.
- Música (bus e controlo já existem; falta a faixa em `assets/audio/music.ogg`); mais inimigos por ante.
