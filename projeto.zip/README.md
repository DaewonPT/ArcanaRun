# Zero-Sum

Protótipo de deckbuilder roguelike para Android (Godot 4.3+, **horizontal**), híbrido de Magic: The Gathering e Balatro:
tabuleiro com mana e criaturas (Magic) + dano calculado numa cascata **Poder × Mult** com relíquias a disparar uma a uma (Balatro).
Conteúdo: **300 cartas em 18 baralhos** (base de dados "Mana Cascade", convertida por `tools/convert_cards.py`).

## Loop

1. Escolhes um dos 18 baralhos (8 a 26 cartas, 1 a 3 cores, dificuldade ★ a ★★★★★).
2. **Batalha**: 5 turnos para reduzir a vida do inimigo a 0.
   - Mana: no turno N tens N+1 (2 → 6). Terrenos são opcionais: na mão dão bónus ("[Na Mão]"); jogados dão +1 mana permanente.
   - A mão repõe-se até 6 no início de cada turno. Se o grimório acabar, o cemitério é rebaralhado.
   - Criaturas ficam no tabuleiro (máx. 5) e atacam **todas** ao fim do turno. Feitiços custam 1 a menos (mín. 1) e contam no ataque desse turno.
   - **Canalizar**: toque longo numa carta da mão descarta-a e compra outra (3 por batalha). Alimenta cemitério e "hellbent".
   - O inimigo responde: a criatura mais robusta que **sobreviva** ao golpe bloqueia; senão levas tu — a não ser que fosse letal (aí as criaturas sacrificam-se). Vida reposta no início de cada batalha.
3. **Loja**: 3 cartas das cores do baralho + 2 relíquias; remoção de 1 carta por visita.
4. Próximo ante → inimigo com mais vida (`GameState.ANTE_HP`). 8 antes = vitória.

## A cascata

Ao atacar, o `EffectResolver` constrói um `Cascade` que a UI anima passo a passo (pop, etiqueta a flutuar, nota a subir meio-tom, boom no total):

1. **Criaturas**, pela ordem do tabuleiro: `+Poder` + efeitos `on_attack` (incluindo reativações ↻).
2. **Feitiços lançados neste turno**: `+Poder` + efeitos de cascata.
3. **Formações** (`data/formations.json`): Pacto Dual, Tríade, Bando Tribal, Tempestade Arcana, Curva de Mana 1-5, Devoção Pura, Horda, Convergência WUBRG. Todas as que se aplicarem somam.
4. **Cartas na mão** com efeitos `[Na Mão]` (terrenos, sobretudo).
5. **Relíquias**, da esquerda para a direita.

Dano = `Poder × Mult × vulnerabilidade`. A função é pura: o ecrã mostra sempre a pré-visualização.

## Estrutura

```
data/cards.json          300 cartas (gerado) · decks.json 18 baralhos · relics.json · formations.json · enemies.json
tools/convert_cards.py   documento das 300 cartas → cards.json/decks.json (regras + overrides à mão; -v lista aproximações)
scripts/autoload/        EventBus → CardDB → GameState (run, baralho com bónus permanentes, tabela de vida) → SceneRouter → Sfx
scripts/core/            CardData / CardInstance / Deck / Cascade / BattleManager / EffectResolver / EnemyAbilities
scenes/                  main (escolha de baralho) · battle · shop · ui (CardView, RelicView, RunOver)
tests/SmokeTest.tscn     godot --headless --path . res://tests/SmokeTest.tscn  (0 = passou)
tests/Balance.tscn       simulação: até que ante chega cada baralho sem loja / com loja  (-- --deck=deck12 --verbose)
```

## DSL de efeitos (resumo; ver cabeçalho de EffectResolver.gd)

`{"trigger", "action", "value", "per", "per_div", "cap", "filter", "cond", "exclude_self"}`

- triggers: `on_attack` (criatura, cada ataque) · `on_cast` (feitiço) · `on_play` (criatura entra) · `in_hand` · `in_hand_on_play` · `on_discard` · `turn_start` · `passive`
- cascata: `power_add` `mult_add` `mult_mul` `gold` `grow` `power_double_self` `power_pct_enemy` `retrigger (left|right|self|all|first|best|last_spell|last_creature|spells|formations|relics|hand)` `cascade_library (top|strongest|graveyard_spell)`
- imediatas: `draw` `mill` `mill_half` `discard_random` `silence_enemy` `extra_turn` `discard_plus` `consume_discard` `shuffle_graveyard` `enemy_max_hp_pct` `recover` `tutor_*` `grow_*` `destroy_left/right` `enemy_vulnerable`
- `per`: `attacker` `spell` `played` `hand` `graveyard` `library` `land_hand` `land` `gold` `colors` `graveyard_types` `relics` `drawn_this_turn` `discards_used` `neighbors` `max_power` `formations`
- `cond`: `position` `count{of,filter,min,max}` `formation[...]` `all_cost` `library_max` `hand_max/min` `discards_max/min` `gold_min` `enemy_hp_below_pct` `discarded_min/max` `neighbor_color/cost` `neighbors_min` `has_right` `right_cost` `colors_all/any` `hand_has` `hand_all_colorless` `consumed`
- flags de carta: `wild_color` `wild_cost` `counts_as_two` `counts_as` `force_formation` `return_to_library` `approx` (efeito aproximado, mostrado com ≈)

## Equilíbrio (tests/Balance.gd, bot simples)

Sem loja: morre-se no ante 3–5 (Izzet ~3). Com loja sensata: média 6,8; 14 dos 18 baralhos ganham runs; Centelha Rubra, Falange Solar e Forja de Urza ganham quase sempre; Izzet, Convergência Planar, Grixis e Orzhov são os mais difíceis. Alavancas: `ANTE_HP`, `formations.json`, overrides em `tools/convert_cards.py`.

## Próximos passos sugeridos

- Reordenar criaturas/relíquias (arrastar) — a ordem importa com reativações e ×Mult.
- Regras de boss ("cartas azuis silenciadas", "-1 Canalização") e um ecrã de deck durante a run.
- Booster packs (escolher 1 de 3) e cartas foil/míticas.
- Save automático a cada turno; mais inimigos por ante.
