# Arcana Run

Protótipo de deckbuilder roguelike para Android (Godot 4.3+), inspirado em Magic: The Gathering e Balatro.

## Loop

1. Escolhes uma cor → deck inicial de 20 cartas (10 terrenos + 10 starters).
2. **Batalha**: 6 turnos para reduzir a vida do inimigo a 0. Por turno: compras 1, jogas 1 terreno (= +1 mana permanente), gastas mana em criaturas/feitiços. No fim do turno as criaturas atacam; o inimigo responde e as criaturas bloqueiam antes de o dano chegar a ti.
3. **Loja**: 3 cartas + 2 relíquias (os "jokers"). Compras com ouro ganho nas batalhas.
4. Próximo ante → inimigo com mais vida (`12 × 1.55^(ante-1)`). 8 antes = vitória.

## Estrutura

```
project.godot            720x1280 retrato, renderer mobile, touch emulado pelo rato
data/
  cards.json             definições de cartas (dados, nunca código)
  relics.json            relíquias permanentes com efeitos passivos/trigger
  enemies.json           inimigos por ante
scripts/autoload/        singletons (ordem importa: EventBus → CardDB → GameState → SceneRouter)
  EventBus.gd            todos os sinais do jogo; UI e lógica só comunicam por aqui
  CardDB.gd              carrega JSON, cria CardInstance, gera ofertas de loja
  GameState.gd           estado da run (ante, ouro, vida, deck_ids, relic_ids, RNG com seed)
  SceneRouter.gd         troca de cenas por chave
scripts/core/            lógica pura, sem nós de UI
  CardData.gd            definição imutável (do JSON)
  CardInstance.gd        carta em jogo: zona, dano, buffs, summoning sickness
  Deck.gd                biblioteca/mão/cemitério + baralhar com seed
  BattleManager.gd       regras da batalha (turnos, mana, ataque, bloqueio)
  EffectResolver.gd      interpreta "effects" de cartas e relíquias
scenes/
  main/Main              menu: escolher cor
  battle/Battle          UI da batalha (liga-se ao EventBus)
  shop/Shop              loja entre antes
  ui/CardView            widget de carta (cor por identidade, toque = jogar)
  ui/RunOver             ecrã final + seed da run
```

## Sistema de efeitos (o coração "Balatro")

Cada carta/relíquia tem uma lista `effects`:

```json
{ "trigger": "land_played", "action": "damage_enemy", "value": 2, "filter": { "color": "red" } }
```

| trigger            | quando dispara                                   |
|--------------------|--------------------------------------------------|
| `turn_start`       | início de cada turno teu                         |
| `land_played`      | ao jogar um terreno                              |
| `creature_summoned`| ao jogar uma criatura                            |
| `on_cast`          | feitiços, ao serem lançados                      |
| `passive`          | avaliado continuamente (`cost_reduction`, `damage_mult`) |

| action           | efeito                                   |
|------------------|------------------------------------------|
| `damage_enemy`   | dano direto ao inimigo                   |
| `heal_player`    | cura                                     |
| `draw`           | compra N cartas                          |
| `buff_power`     | +N poder às criaturas (respeita `filter`)|
| `gold`           | +N ouro                                  |
| `cost_reduction` | passivo: −N custo (respeita `filter`)    |
| `damage_mult`    | passivo: multiplica o dano de ataque     |

Adicionar uma carta nova = uma linha no JSON. Adicionar um tipo de efeito novo = um `match` em `EffectResolver._apply`.

## Habilidades de inimigos

Em `enemies.json`, cada inimigo pode ter `abilities` (resolvidas em `EnemyAbilities.gd`, depois do ataque do inimigo):

| trigger          | quando                                     |
|------------------|--------------------------------------------|
| `turn_end`       | fim de cada turno                          |
| `every_n_turns`  | nos turnos múltiplos de `n`                |

| action                 | efeito                                      |
|------------------------|---------------------------------------------|
| `steal_gold`           | rouba N ouro                                |
| `heal_self`            | cura-se N (até ao máximo)                   |
| `destroy_strongest`    | destrói a tua criatura com mais poder       |
| `damage_all_creatures` | N de dano a todas as tuas criaturas         |
| `discard_random`       | descarta N cartas da tua mão ao acaso       |

A descrição (`text`) aparece por baixo do nome do inimigo; cada ativação aparece no registo da batalha.

## Remoção de cartas na loja

Uma remoção por visita, custo `2 + ante/3`. Abre a lista do deck agrupada por carta (terrenos primeiro); um toque remove uma cópia. Não é possível descer abaixo de 10 cartas.

## Correr

1. Godot 4.3+ → Import → escolher `project.godot`.
2. F5 corre no desktop (rato simula toque).
3. Android: Project → Export → Android (precisa do export template + Android SDK/JDK configurados no editor). Para testar rápido usa **One-click deploy** com o telemóvel em USB debugging.

## Próximos passos sugeridos

- Animações de carta (tween ao jogar / dano a flutuar).
- Mais cores (azul: comprar cartas/contramedidas; preto: sacrificar por valor).
- Inimigos com habilidades próprias (dano em área, "destrói a criatura mais forte").
- Remover cartas na loja (afinar o deck é metade do Balatro).
- Ecrã de deck durante a run.
