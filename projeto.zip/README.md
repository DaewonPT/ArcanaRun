# Zero-Sum

Protótipo de deckbuilder roguelike para Android (Godot 4.3+, **horizontal**), híbrido de Magic: The Gathering e Balatro:
tabuleiro com mana e criaturas (Magic) + dano calculado numa cascata **Poder × Mult** com relíquias a disparar uma a uma (Balatro).
Conteúdo: **300 cartas em 18 baralhos** (base de dados "Mana Cascade", convertida por `tools/convert_cards.py`) + 13 cartas de dupla face fora dos baralhos (c301–c313: loja, boosters, eventos) + 1 maldição (c314, só por eventos).

## Loop

1. **Menu**: Novo Jogo (campanha), Continuar (a run guardada), Modo Livre (todos os baralhos e os baralhos personalizados, não conta para o progresso), Arena Draft, Quebra-Cabeças, Dificuldade (Fácil / Normal / Difícil: vida do inimigo ×0,7 / ×1 / ×1,4 e 4 / 3 / 2 canalizações por batalha), Como Jogar, Coleção, Estatísticas, Construtor, Configurações.
2. **Configurações** (`user://settings.json`, autoload `Settings`): volume dos efeitos (bus "Sfx"; o controlo de música aparece quando existir `assets/audio/music.ogg`, bus "Music"), idioma (automático / português / inglês — interface, cartas, relíquias, inimigos e regras; só a história da campanha fica em português), velocidade das animações (normal / rápida / instantânea — `Settings.dur(s)` escala todas as durações), vibração, **texto das cartas** (normal / grande), **mão dominante** (direita / esquerda: a coluna de ações troca de lado), **modo daltónico** (símbolo em cada pip de cor: sol, gota, caveira, chama, árvore — `CardIcon.pip`), repetir o tutorial, apagar progresso. Fontes: Inter (texto) e Lora Bold (títulos, variação `TitleLabel` em `assets/theme.tres`), ambas SIL OFL (licenças em `assets/fonts/`).
3. **Campanha** (`data/campaign.json`): 3 livros com história; cada capítulo é um dos 18 baralhos (8 a 26 cartas, 1 a 3 cores, dificuldade ★ a ★★★★★). Chegar ao ante 4 abre o capítulo seguinte; ao ante 6, o livro seguinte. Cada baralho tem ainda 8 **Selos Planares** (dificuldade progressiva, `GameState.STAKES`, desbloqueados ao vencer o anterior; acumulam: sem ouro base nos Batedores, bosses +35 % a partir do ante 3, 2 canalizações, relíquias da loja presas, cartas de booster infetadas (Poder ×2, exilam-se ao fim de 3 utilizações), mão de 5, 2.ª regra dos bosses abaixo de metade da vida). O progresso fica em `user://progress.json`; a run em curso em `user://run.json` (versão 3), gravada **no início de cada turno** com o estado da batalha (`BattleManager.to_dict/restore`), no mapa e ao entrar/sair da loja — Continuar retoma exatamente aí. Abandonar (menu de pausa) conta como derrota nesse ante.
   - **Mapa da run** (`scenes/map/Map.gd`, `GameState.map_options`): 8 antes em 5 atos (I: 1–2, II: 3–4 com boss, III: 5–6, IV: 7–8 com o boss final, V: infinito). Em cada ante escolhe-se a batalha — Batedor (normal), Guarda (+25 % de vida, +4 ouro) ou, a partir do ante 2, às vezes **Elite** (+60 % de vida, +2 de ataque, +6 ouro e uma relíquia garantida); boss nos antes múltiplos de 4 — e depois a paragem: Loja ou outra (Evento, Acampamento, Fonte de Mana, Altar de Phyrexia, **Quadro de Contratos**, **Tribunal dos Deuses**, Mercador Cego), sorteadas por run com uma semente própria. O mapa mostra o ato inteiro, o **Clima Planar** do ato (e o do seguinte na última paragem) e o contrato ativo; as escolhas ficam em `map_choice`/`map_history`. Ao entrar num ato novo aparece um **interlúdio** (`ActInterlude`, `data/acts.json`: nome, frase de história e clima; uma vez por ato, `GameState.interlude_key`).
   - **Clima Planar** (`data/climates.json`, 8, um por ato, sorteado e guardado em `GameState.climates`; o ato I só tira climas com `min_act` 1; no infinito muda de 2 em 2 antes): Mercado das Guildas, Eco Temporal, Maré de Éter, Chuva de Meteoros, Eclipse de Mana, Ferrugem de Óleo, Lua de Sangue, Areias Escaldantes. Os efeitos vivem no `BattleManager` (mana, mão, fim do turno) e no `EffectResolver` (custos, passos `climate` no fim da cascata).
   - **Contratos** (`data/contracts.json`, 8): o Quadro oferece 3; o aceite vale para a batalha seguinte e é avaliado no fim (`GameState.resolve_contract`, contadores do `BattleManager`: turno, canalizações, vida perdida, maior golpe, formações, atacantes, recapitulações, terrenos). **Tribunal dos Deuses**: oferece 8 ouro ou 4 de vida e a roda (`SpinWheel`, 8 setores) decide — o resultado sorteia-se e grava-se antes de girar.
4. **Batalha**: 5 turnos para reduzir a vida do inimigo a 0. Botão PAUSA (Continuar, Configurações, Como Jogar, Ver baralho, Abandonar); toque longo numa carta abre-a em grande com o texto completo; GRIMÓRIO/CEMITÉRIO listam as zonas (o grimório ordenado por custo, para não revelar a ordem; o exílio por baixo do cemitério); toque numa relíquia mostra a descrição. O botão "retroceder" do Android abre a pausa / fecha painéis.
   - **Mulligan de Londres** (turno 1, antes de qualquer jogada): mão nova de 6, com 1 carta para o fundo do grimório por mulligan feito (máx. 3, fica com 3 cartas).
   - **Cartas de dupla face** (`mission` + `transformed` em `cards.json`, ids c301–c308): a missão conta nesta batalha (canalizar, lançar feitiços, jogar criaturas, sobreviver a ataques, ficar turnos na mão, ter ouro) e ao cumprir-se a carta vira (`CardInstance.transform`, animação de viragem), com `on_transform` para efeitos imediatos.
   - **Selos de guilda** (`data/seals.json`, aplicados na loja, guardados em `deck[i].seal`): Fúria (reativa a carta), Sabedoria (se ficar na mão no fim do turno, uma formação sobe de nível — `GameState.formation_levels`, `level_mult` em `formations.json`), Phyrexiano (×2.5 Mult, −10 Poder permanente por ataque, exilada da run a 0), Vitalidade (+15 Poder permanente à criatura à esquerda ao ser jogada), Dízimo (+3 ouro ao ser jogada).
   - **Recapitular** (`flashback: true` em 21 feitiços): lançam-se a partir do cemitério (toque em CEMITÉRIO, seletor com filtro) e vão para `Deck.exile` até ao fim da batalha.
   - **Planeswalker** (`data/planeswalkers.json`, 5, um por run, do Mercador Cego): lealdade sobe ao jogar cartas da cor dele (máx. 6); 3 habilidades (+1, −2, −6), uma por turno, resolvidas em `BattleManager.use_planeswalker`; os bónus de Mult entram no fim da cascata.
   - **Pré-visualizações**: cada carta jogável mostra o delta do total (`BattleManager.preview_play`, aproximação que ignora efeitos imediatos); a barra do inimigo mostra o dano previsto (segmento claro) e o botão fica verde/LETAL; o painel do inimigo diz quem bloqueia o contra-ataque e o que o inimigo faz a seguir (`preview_enemy_phase`, `enemy_intent`).
   - **Desfazer** (dentro do turno): `BattleManager.snapshot/restore_snapshot` guardam batalha + RNG + ouro + bónus permanentes antes de cada jogada/canalização.
   - **Arrastar** criaturas no tabuleiro e relíquias na prateleira reordena-as (a ordem importa: reativações, ×Mult depois de +Mult).
   - **Vida persistente**: a vida atravessa a run (cura na loja/eventos); chegar a 0 acaba a run.
   - **Bosses** nos antes múltiplos de 4 (`GameState.pick_enemy`): `rule` em `enemies.json` — `discards_minus`, `hand_size`, `creature_cost_plus/minus`, `spell_cost_plus`, `no_formations`, `relics_off`, `color_silenced`, `attack_per_graveyard`, `gold_tax`, `max_creatures`, `exile_rightmost`. Inimigos têm `acts` (conjunto por ato do baralho) e `min_ante`. **2 fases**: abaixo de metade da vida o boss desperta (+2 de ataque; com o Selo 8 também a `rule2`); risca dourada a meio da barra, falas (`lines`: intro, golpe, despertar, derrota) num balão ao lado do painel. Vencer um boss que não acaba a run abre o **Baú de Espólio** (`scenes/loot`): 1 de 3 relíquias de boss (`boss: true`, fortes com um preço; ficam em `GameState.boss_relics`, fora do limite de 5, e disparam depois das normais).
   - **HUD**: intenção do inimigo em ícones (ataque, quem bloqueia, habilidades; o texto completo abre ao tocar), vida com coração e mana em cristais (`ManaPips`), chips de clima/contrato e o planeswalker numa linha por cima do cálculo, **detalhe da cascata** ao tocar em Poder × Mult (`CascadeBreakdown`), total a contar estilo Balatro, chamas nas pílulas proporcionais ao ataque (`fire.gdshader`), hit-stop e abanão proporcionais ao golpe, brilho holográfico nas raras e faces viradas que segue a inclinação do telemóvel (`foil.gdshader`).
   - Mana: no turno N tens N+1 (2 → 6). Terrenos são opcionais: na mão dão bónus ("[Na Mão]"); jogados dão +1 mana permanente.
   - A mão repõe-se até 6 no início de cada turno. Se o grimório acabar, o cemitério é rebaralhado.
   - Criaturas ficam no tabuleiro (máx. 5) e atacam **todas** ao fim do turno. Feitiços custam 1 a menos (mín. 1) e contam no ataque desse turno.
   - **Canalizar**: botão CANALIZAR (N) e depois toque numa carta da mão — descarta-a e compra outra. Alimenta cemitério e "hellbent".
   - O inimigo responde: a criatura mais robusta que **sobreviva** ao golpe bloqueia; senão levas tu — a não ser que fosse letal (aí as criaturas sacrificam-se). Vida reposta no início de cada batalha.
5. **Loja**: 3 cartas das cores do baralho, booster (escolhe 1 de 3), novas ofertas (preço sobe), 2 relíquias ponderadas por raridade (máx. 5 relíquias; vender a metade do preço), curar (3 ouro → 5 vida), vida máxima +5 (uma vez por visita), melhorar uma carta (+10 Poder ou +0,5 Mult permanentes, via `deck[i].power_bonus/mult_bonus`), selar uma carta (6 ouro, `SealPicker`), remover uma carta, ver baralho. Juros: +1 ouro por cada 5 guardados ao entrar (máx. 5; ×2 com o Dízimo Dobrado). O **Mercador Cego** (mesma cena, `merchant`) vende 2 das 5 relíquias lendárias (`legendary: true`, fora do sorteio normal) e 2 planeswalkers. Todos os preços passam por `GameState.shop_price` (o Cálice do Abismo soma +2).
6. **Eventos** (`data/events.json`, nó "Evento" do mapa): 2–3 opções com efeitos `gold`, `heal`, `max_hp`, `relic`, `card`, `remove_cards`, `grow_random`, `mult_random`, `curse`, `seal`, `well`, `swap_cost5`, `contract`, `guess`, `gamble` (opções dinâmicas: `dynamic: contracts | guess_color`); filtrados pelo livro, sem repetir na run. Os nós fixos usam a mesma cena: Acampamento (`node_rest`), Fonte de Mana (`node_spring`, efeito `recolor`: até 3 cartas passam à cor principal — `deck[i].colors`), Altar de Phyrexia (`node_altar`, efeito `fuse`: sacrifica uma carta, outra herda os efeitos, o texto e metade do Poder — `deck[i].extra_effects/extra_text`). `CardData.with_entry` aplica estas alterações à carta.
7. Próximo ante → inimigo com mais vida (`GameState.ANTE_HP` × dificuldade). 8 antes = vitória; no ecrã final, **Modo Infinito** continua a run (vida do inimigo ×1,6 por ante a partir do 9, bosses de 4 em 4, juros e eventos continuam) até perderes — conta para o melhor ante.
8. **Tutorial** (`scenes/battle/Tutorial.gd`): na primeira batalha de sempre, 6 passos por cima do ecrã (jogar, atacar, contra-ataque, canalizar, desfazer, mulligan/recapitular/mapa); pode saltar-se e repetir-se nas Configurações (`progress.tutorial_done`).
9. **Estatísticas e conquistas** (autoload `Stats`, `data/achievements.json`): contadores globais e por baralho (runs, vitórias, melhor ante, maior ataque, dano total, inimigos/bosses, cartas jogadas, canalizações, turnos, eventos, mulligans, transformações, recapitulações, habilidades −6, melhor selo, enigmas, vitórias no draft); 30 conquistas `{stat, min}` verificadas a cada mudança, com aviso no ecrã (`SceneRouter.toast`).
10. **Coleção**: as 300 cartas (filtros por baralho e cor), relíquias e inimigos — só os já vistos aparecem com nome e texto, os outros ficam "???" (`progress.seen`).
11. **Construtor de baralhos** (`scenes/builder/DeckBuilder.gd`, `user://custom_decks.json`): 6 espaços; 10 a 30 cartas, máximo 2 cópias, filtros por cor/tipo/custo; "Jogar" arranca uma run em modo livre com esse baralho (`CardDB.custom_decks`, ids `custom_1..custom_6`).
12. **Arena Draft** (`scenes/draft/Draft.gd`): sem baralho; 5 boosters de 5 cartas (raridade ponderada; a partir do 2.º, 60 % das cartas das cores já escolhidas), 2 escolhas por booster, 3 terrenos de 6, e `GameState.new_draft_run` (13 cartas, 4 antes, modo livre; vitórias contam em `draft_wins`).
13. **Quebra-Cabeças do Mago** (`scenes/puzzles/Puzzles.gd`, `data/puzzles.json`): 5 cenários com mão/Arena/cemitério fixos, 1 turno, 0 canalizações (`BattleManager.start_puzzle`); a vida do inimigo é exatamente o melhor ataque possível — `tests/PuzzleSolver.gd` procura todas as linhas e o teste de fumo obriga `max == hp` (`tests/PuzzleTune.tscn` recalcula ao mudar cartas). Resolvidos em `progress.puzzles`.

## A cascata

Ao atacar, o `EffectResolver` constrói um `Cascade` que a UI anima passo a passo (a carta avança, etiqueta a flutuar, os pilões Poder/Mult saltam, nota a subir meio-tom, partículas e número a voar até ao inimigo no total). Comprar, jogar (a carta voa da mão para o tabuleiro) e morrer também têm animação; as animações guardam-se por nó e são canceladas antes de o nó ser substituído, para não ficarem a meio.

1. **Criaturas**, pela ordem do tabuleiro: `+Poder` + efeitos `on_attack` (incluindo reativações ↻).
2. **Feitiços lançados neste turno**: `+Poder` + efeitos de cascata.
3. **Formações** (`data/formations.json`): de custo, como no póquer (só a melhor: Quadra > Casa Cheia > Tríade > Pacto Duplo > Pacto Dual; `EffectResolver._cost_formation`; as maiores satisfazem as condições das que contêm — `FORMATION_IMPLIES`), Bando Tribal, Tempestade Arcana, Curva de Mana 1-5, Devoção Pura, Horda, Convergência WUBRG. Todas as que se aplicarem somam.
4. **Cartas na mão** com efeitos `[Na Mão]` (terrenos, sobretudo).
5. **Relíquias**, da esquerda para a direita (as de boss no fim). Relíquias que escalam (`scaling: {event}`, `per: relic_counter`): o contador (`GameState.relic_counters`) começa a 0 quando a ganhas e sobe com `battle_won`, `channel`, `life_lost` ou `card_added`.
6. **Planeswalker** e 7. **Clima** (passos `climate`).

Dano = `Poder × Mult × vulnerabilidade`. A função é pura: o ecrã mostra sempre a pré-visualização.

## Estrutura

```
data/cards.json          314 cartas (gerado; c301–c313 dupla face, c314 maldição, 21 com flashback) · cards_en.json (nomes/textos em inglês, incl. faces de trás) · decks.json 18 baralhos · relics.json (53: 5 lendárias, 6 de boss, 4 que escalam) · formations.json (11, com level_mult) · enemies.json (22; bosses com rule2 e falas) · campaign.json (livros e história) · events.json (11 eventos + 5 nós) · achievements.json (30) · seals.json (5) · planeswalkers.json (5) · puzzles.json (5) · climates.json (8) · contracts.json (8) · acts.json (interlúdios)
tools/convert_cards.py   documento das 300 cartas → cards.json/decks.json (regras + overrides à mão; -v lista aproximações)
scripts/autoload/        EventBus → ContentUpdate (conteúdo descarregado) → CardDB → Settings → GameState (run, baralho com bónus permanentes, dificuldade, save/progresso) → Stats (estatísticas, conquistas, coleção) → SceneRouter (fade, overlays, toasts) → Sfx
scripts/core/            CardData / CardInstance / Deck / Cascade / BattleManager / EffectResolver / EnemyAbilities
scenes/                  main (menu) · campaign (livros/capítulos, selos planares) · map (mapa da run) · battle (+PauseMenu, Tutorial) · shop (loja e Mercador Cego) · event (eventos, nós, Tribunal) · loot (Baú de Espólio) · draft · puzzles · builder (construtor) · ui (CardView com ícones/pips/molduras/selos/brilho, RelicView, HowToPlay, RunOver, SettingsMenu, CardZoom, ZoneViewer — seletor com filtro e secção de exílio, SealPicker, StatsScreen, Collection, CascadeBreakdown, ActInterlude)
scripts/ui/UiKit.gd      widgets em código (botões, painéis centrados, fundo escuro, chips) para os overlays · CardIcon.gd ícones desenhados em código (tipos, pips com símbolos, clima, contrato, roda, intenção) · SpinWheel.gd roda do Tribunal · ManaPips.gd cristais de mana
assets/shaders           foil.gdshader (brilho holográfico) · fire.gdshader (chamas das pílulas)
assets/fonts, theme.tres Inter Medium (texto) e Lora Bold (títulos), SIL OFL
i18n/en.json             tradução da interface (chave = texto PT) · howto.json regras em pt/en · tools/make_en_json.py gera e valida
assets/icons, icon.png, splash.png   ícone (tools/make_icons.py) e ecrã de arranque
tests/SmokeTest.tscn     godot --headless --path . res://tests/SmokeTest.tscn  (0 = passou)
tests/Balance.tscn       simulação: até que ante chega cada baralho sem loja / com loja  (-- --deck=deck12 --verbose)
tests/Screenshots.tscn   capturas das cenas com xvfb (-- --out=/tmp/shots)
tests/PuzzleTune.tscn    melhor ataque de cada quebra-cabeças (PuzzleSolver) para fixar a vida do inimigo
tools/make_manifest.py   pacote de atualização de conteúdo assinado (ver Atualizações de conteúdo)
```

## DSL de efeitos (resumo; ver cabeçalho de EffectResolver.gd)

`{"trigger", "action", "value", "per", "per_div", "cap", "filter", "cond", "exclude_self"}`

- triggers: `on_attack` (criatura, cada ataque) · `on_cast` (feitiço) · `on_play` (criatura entra) · `in_hand` · `in_hand_on_play` · `on_discard` · `on_transform` (dupla face ao virar) · `turn_start` · `battle_start` · `passive`
- cascata: `power_add` `mult_add` `mult_mul` (`linear: true` = ×1 + valor × contagem) `gold` `heal` `self_damage` `grow` `power_double_self` `power_pct_enemy` `retrigger (left|right|self|all|first|best|last_spell|last_creature|spells|formations|relics|hand)` `cascade_library (top|strongest|graveyard_spell)`
- imediatas: `draw` `mill` `mill_half` `discard_random` `silence_enemy` `extra_turn` `bonus_turn` `discard_plus` `consume_discard` `shuffle_graveyard` `enemy_max_hp_pct` `recover` `tutor_*` `grow_*` `buff_right` `destroy_left/right` `enemy_vulnerable`
- `per`: `attacker` `spell` `played` `hand` `graveyard` `library` `land_hand` `land` `gold` `colors` `graveyard_types` `relics` `drawn_this_turn` `discards_used` `neighbors` `max_power` `formations` `relic_counter` (relíquias que escalam)
- `cond`: `position` `count{of,filter,min,max}` `formation[...]` `all_cost` `library_max` `hand_max/min` `discards_max/min` `gold_min` `enemy_hp_below_pct` `discarded_min/max` `neighbor_color/cost` `neighbors_min` `has_right` `right_cost` `colors_all/any` `hand_has` `hand_all_colorless` `consumed`
- flags de carta: `wild_color` `wild_cost` `counts_as_two` `counts_as` `force_formation` `return_to_library` `approx` (efeito aproximado, mostrado com ≈)

## Equilíbrio (tests/Balance.gd, bot simples)

Sem loja: morre-se no ante 3–5 (Izzet ~4). Com loja sensata (relíquias das suas cores, cura, 1 carta por visita; o bot escolhe sempre Batedor e Loja): média 6,6; 10 dos 18 baralhos ganham runs; Centelha Rubra e Falange Solar ganham quase sempre; Izzet, Convergência Planar, Grixis (parede no boss do ante 4) e Orzhov são os mais difíceis. Alavancas: `ANTE_HP`, `hp_mult`/`rule` dos bosses, `formations.json`, overrides em `tools/convert_cards.py`. Nota: `1 in [1.0]` é falso no Godot — os números do JSON comparam-se com `int()` (`GameState._act_in`).

## Tradução

As chaves são o próprio texto em português: os Labels/Buttons das cenas traduzem-se sozinhos (auto translate) e o texto construído em código usa `tr("Turno %d/%d") % [...]` (traduzir o molde, depois formatar). `i18n/en.json` mapeia PT → EN; sem entrada, fica o português. As cartas usam `data/cards_en.json` (id → nome e texto; `tools/make_cards_en.py` gera a partir de um glossário e das regras do conversor) carregado pelo `Settings` para a mesma `Translation`. O fallback do projeto é `pt_PT` (senão o Godot cairia para "en"). Só ficheiros-recurso (.json, .png…) entram no APK — nada de .txt/.md para dados.

## Android

O ecrã usa modo imersivo: a barra de navegação do Android aparece por cima da margem inferior durante uns segundos depois de um toque perto dessa margem. Por isso os botões de ação estão na coluna da esquerda e a mão tem margem inferior — nada de interativo fica debaixo da barra.

## Atualizações de conteúdo (sem APK novo)

Ao arrancar, `ContentUpdate` lê `https://daewonpt.github.io/zerosum-updates/versao.txt` (um repositório público com GitHub Pages). O manifesto (`ZSUPD 1`, linhas `c` versão do conteúdo, `min` versionCode mínimo, `n pt/en` nota, `f <sha256> <tamanho> <caminho>`, `sig` assinatura) é verificado com **ECDSA P-256 / SHA-256** e a chave pública embutida no jogo; só passam caminhos `data/*.json` e `i18n/*.json` (nunca código). Se `c` for maior do que o instalado e a app for recente o suficiente, descarrega cada ficheiro de `f/<sha256>` (confirmando o hash) para `user://content/`, e `CardDB`/`Settings` passam a ler daí. Falhas são silenciosas (`ContentUpdate.clear_downloaded()` volta ao conteúdo do APK).

Publicar: `python3 tools/make_manifest.py --key zerosum-atualizacoes-privada.pem --version 4 --min-app 9 --out pub --note-pt "…" --note-en "…"` e enviar a pasta `pub/` (`versao.txt`, `f/`, `.nojekyll`) para o repositório. A chave privada fica fora do projeto. Um APK novo deve subir `APP_VERSION_CODE`/`BUNDLED_CONTENT_VERSION` em `ContentUpdate.gd` e o manifesto deve usar uma versão maior do que a embutida (0.9.0: APP_VERSION_CODE 9, conteúdo 3).

## Próximos passos sugeridos

- 0.10.0: o resto da lista de 50 sugestões (mão em leque, relíquias em medalhões, campanha narrativa, némesis, fichas, tipos de criatura, encantamentos, janela de reação, vales, modo treino, ecrã de novidades…).
- Música (bus e controlo já existem; falta a faixa em `assets/audio/music.ogg`).
- Publicação na Play Store (keystore própria, AAB, política de privacidade).
