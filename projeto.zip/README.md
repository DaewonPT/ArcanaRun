# Zero-Sum

Protótipo de deckbuilder roguelike para Android (Godot 4.3+, **horizontal**), híbrido de Magic: The Gathering e Balatro:
tabuleiro com terrenos, mana e criaturas (Magic) + dano calculado numa cascata **Poder × Mult** com relíquias a disparar uma a uma (Balatro).

## Loop

1. Escolhes uma cor → baralho inicial de 20 cartas (8 terrenos + 12 criaturas).
2. **Batalha**: 5 turnos para reduzir a vida do inimigo a 0. Por turno: a mão é reposta até 5, jogas 1 terreno (= +1 mana permanente), gastas mana em criaturas/feitiços. Ao terminar o turno **todas** as criaturas atacam (não há "summoning sickness"); o dano é uma cascata (ver abaixo). O inimigo responde: a criatura mais robusta que **sobreviva** ao golpe bloqueia; se nenhuma sobreviver, levas tu — a não ser que fosse letal, e aí as criaturas sacrificam-se. A tua vida repõe-se no início de cada batalha.
3. **Loja**: 3 cartas + 2 relíquias (os "jokers") e remoção de 1 carta por visita.
4. Próximo ante → inimigo com mais vida (tabela `GameState.ANTE_HP`). 8 antes = vitória.

## A cascata (o coração "Balatro")

Ao atacar, o `EffectResolver` constrói um `Cascade` — uma lista de passos que a UI anima um a um (pop na carta/relíquia, etiqueta a flutuar, nota a subir meio-tom por passo, e "boom" no total):

1. **Criaturas**, pela ordem do tabuleiro: `+Poder` de cada uma, seguido dos seus efeitos `on_attack`.
2. **Formações** (o "tipo de mão"): Bando (3+ atacantes, +1 Mult), Devoção (4+ da mesma cor, +1 Mult), Horda (5 atacantes, +2 Mult). Definidas em `data/formations.json`.
3. **Relíquias**, da esquerda para a direita.

Dano = `Poder × Mult`. A função é pura, por isso o ecrã mostra sempre a pré-visualização do ataque atual.

Tabuleiro limitado a 5 criaturas e mão de 5 — como as 5 cartas de uma mão do Balatro.

## Estrutura

```
project.godot            1280x720, sensor_landscape, renderer mobile
export_presets.cfg       preset Android (pt.zerosum.game, arm64, debug keystore do CI)
data/
  cards.json             cartas (dados, nunca código)
  relics.json            relíquias com efeitos passivos / de trigger / de ataque
  formations.json        formações (bónus de Mult por composição do ataque)
  enemies.json           inimigos por ante, com habilidades
scripts/autoload/        singletons: EventBus → CardDB → GameState → SceneRouter → Sfx
  EventBus.gd            todos os sinais do jogo; UI e lógica só comunicam por aqui
  CardDB.gd              carrega os JSON
  GameState.gd           estado da run (ante, ouro, vida, deck_ids, relic_ids, RNG com seed, tabela de vida)
  SceneRouter.gd         troca de cenas por chave
  Sfx.gd                 sons sintetizados em memória (blip com pitch, boom, hit)
scripts/core/            lógica pura, sem nós de UI
  CardData / CardInstance / Deck
  BattleManager.gd       turnos, mana, cascata (corrotina: espera que a UI anime), bloqueio, fim
  EffectResolver.gd      interpreta "effects"; build_attack_cascade() é pura
  Cascade.gd             resultado do ataque, passo a passo
  EnemyAbilities.gd      habilidades do inimigo (fim de turno / a cada N turnos)
scenes/
  main/Main              menu: escolher cor
  battle/Battle          UI da batalha + animação da cascata
  shop/Shop              loja + remoção de cartas
  ui/CardView, RelicView, RunOver
tests/
  SmokeTest.tscn         godot --headless --path . res://tests/SmokeTest.tscn  (sai com 0 se passou)
  Balance.tscn           simulação: até que ante chega um baralho inicial sem loja / com loja
```

## Efeitos (cartas e relíquias)

```json
{ "trigger": "on_attack", "action": "mult_add", "value": 2, "per": "attacker", "filter": { "color": "red" } }
```

| trigger            | quando                                               |
|--------------------|------------------------------------------------------|
| `turn_start`       | início de cada turno teu                             |
| `land_played`      | ao jogar um terreno                                  |
| `creature_summoned`| ao jogar uma criatura                                |
| `on_cast`          | feitiços, ao serem lançados                          |
| `passive`          | avaliado continuamente (`cost_reduction`)            |
| `on_attack`        | entra na cascata Poder × Mult                        |

| action           | efeito                                                     |
|------------------|------------------------------------------------------------|
| `damage_enemy`   | dano direto ao inimigo                                     |
| `heal_player`    | cura                                                       |
| `draw`           | compra N cartas                                            |
| `buff_power`     | +N poder às criaturas (respeita `filter`)                  |
| `gold`           | +N ouro                                                    |
| `cost_reduction` | passivo: −N custo (respeita `filter`)                      |
| `power_add`      | cascata: +N Poder                                          |
| `mult_add`       | cascata: +N Mult                                           |
| `mult_mul`       | cascata: ×N Mult                                           |
| `grow`           | cascata: +N Poder agora **e** para sempre (verde)          |

Modificadores opcionais de `on_attack`: `per` (`attacker` | `graveyard` | `land`) multiplica o valor pela contagem (respeita `filter`); `min_attackers` só dispara com N+ atacantes.

## Habilidades de inimigos (`enemies.json`)

| trigger          | quando                        |
|------------------|-------------------------------|
| `turn_end`       | fim de cada turno             |
| `every_n_turns`  | nos turnos múltiplos de `n`   |

Ações: `steal_gold`, `heal_self`, `destroy_strongest`, `damage_all_creatures`, `discard_random`.

## Equilíbrio (tests/Balance.gd)

Bot que joga tudo o que pode: sem loja morre no ante 3–4; comprando relíquias da sua cor ganha ~1 em 3 runs. Para apertar ou aliviar: `GameState.ANTE_HP`, `turns_for_ante`, os valores em `formations.json`.

## Correr

1. Godot 4.3+ → Import → `project.godot`. F5 corre no desktop.
2. Android: o repositório GitHub compila o APK a partir de `projeto.zip` (workflow em `.github/workflows`).

## Próximos passos sugeridos

- Reordenar relíquias (arrastar) — a ordem importa quando há ×Mult.
- Booster packs na loja (escolher 1 de 3) e cartas foil/míticas.
- Quarta cor: preto (usa o cemitério como recurso).
- Regras de boss ("cartas vermelhas silenciadas") e um ecrã de deck durante a run.
- Save automático a cada turno.
