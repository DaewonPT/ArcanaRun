extends Control
## Campanha: atos → capítulos (cada capítulo é um baralho com a sua história e dificuldade).
## Em Modo Livre todos os capítulos estão abertos e nada conta para o progresso.
## 0.12.0: também serve a Run Rápida (GameState.launch_mode == "quick"): qualquer baralho, 4 antes.
## 0.17.0: e a Torre do Arquimago ("tower") e a Corrida de Bosses ("rush"): qualquer baralho, sem Selos.

const COLOR_NAMES := {"white": "Branco", "blue": "Azul", "black": "Preto", "red": "Vermelho", "green": "Verde"}

@onready var header: Label = %Header
@onready var act_buttons: HBoxContainer = %ActButtons
@onready var act_intro: Label = %ActIntro
@onready var chapter_list: VBoxContainer = %ChapterList
@onready var chapter_title: Label = %ChapterTitle
@onready var deck_line: Label = %DeckLine
@onready var story_label: Label = %Story
@onready var stats_label: Label = %Stats
@onready var start_btn: Button = %Start
@onready var back_btn: Button = %Back
@onready var detail_panel: Control = %DetailPanel

var _act_index := 0
var _selected_deck := ""
var _stake := 1
var _stake_row: HBoxContainer
var _stake_label: Label
var _diff_btn: Button
var _quick := false   # Run Rápida (0.12.0): 4 antes, qualquer baralho
var _short := ""      # 0.19.0: "skirmish" (Batalha avulsa), "mini" (Run de 2 antes) ou "brawl" (Só batalhas)
var _side := ""       # 0.17.0: "tower" (Torre do Arquimago) ou "rush" (Corrida de Bosses); "" nos outros
var _variant := "classic"   # 0.12.0: variante do baralho (abre com o nível do baralho)
var _variant_btn: Button
var _variant_label: Label
var _back_picker: BackPicker
var _rewards_btn: Button   # 0.19.0 (75): «Cartas depois das batalhas» (opção da run)
## 0.13.1: o livro aberto em cada modo. Começa sempre no Livro I e, enquanto a app está aberta,
## fica no último livro escolhido ao voltar a este ecrã (como na História).
static var _last_act := {"campaign": 0, "free": 0, "quick": 0, "tower": 0, "rush": 0}

func _ready() -> void:
	_short = GameState.launch_mode if GameState.launch_mode in ["skirmish", "mini", "brawl"] else ""   # 0.19.0 (176, 177, 201)
	_quick = GameState.launch_mode == "quick" or _short != ""
	_side = GameState.launch_mode if GameState.launch_mode in ["tower", "rush"] else ""
	GameState.launch_mode = ""
	if _quick or _side != "":
		GameState.free_mode = true
	header.text = tr("RUN RÁPIDA") if _quick else (tr("MODO LIVRE") if GameState.free_mode else tr("CAMPANHA"))
	if _short != "":
		header.text = tr(String({"skirmish": "BATALHA AVULSA", "mini": "RUN DE 2 ANTES", "brawl": "SÓ BATALHAS"}[_short]))
	if _side != "":   # nomes curtos: a fila de cima (dificuldade e livros) tem de caber
		header.text = tr("TORRE") if _side == "tower" else tr("CORRIDA")
	# Dificuldade (vale para todas as runs): botão ao lado do título; tocar muda Fácil → Normal → Difícil.
	header.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	var bar := header.get_parent()
	_diff_btn = UiKit.button("", 48, 17)
	_diff_btn.name = "Difficulty"
	_diff_btn.custom_minimum_size.x = 220
	_diff_btn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_diff_btn.pressed.connect(_on_difficulty)
	bar.add_child(_diff_btn)
	bar.move_child(_diff_btn, header.get_index() + 1)
	_diff_btn.owner = self
	_diff_btn.unique_name_in_owner = true
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.add_child(spacer)
	bar.move_child(spacer, _diff_btn.get_index() + 1)
	_refresh_difficulty()
	back_btn.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	start_btn.pressed.connect(_on_start)
	# Selos Planares (dificuldade progressiva por baralho), por cima do botão de começar.
	var parent := start_btn.get_parent()
	# 0.12.0: variante do baralho (nível do baralho), por cima dos Selos.
	var vrow := HBoxContainer.new()
	vrow.add_theme_constant_override("separation", 10)
	parent.add_child(vrow)
	parent.move_child(vrow, start_btn.get_index())
	_variant_btn = UiKit.button("", 44, 16)
	_variant_btn.name = "Variant"
	_variant_btn.custom_minimum_size.x = 250
	_variant_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_variant_btn.pressed.connect(_on_variant)
	vrow.add_child(_variant_btn)
	# 0.16.1 (V12): as costas deste baralho.
	_back_picker = BackPicker.make("", 44)
	vrow.add_child(_back_picker)
	# 0.19.0 (299): a moldura, o tapete e o efeito do golpe deste baralho.
	var more := UiKit.button("✦", 44, 18)
	more.name = "DeckCosmetics"
	more.custom_minimum_size.x = 56
	more.tooltip_text = tr("Moldura, tapete e efeito do golpe deste baralho")
	more.pressed.connect(func():
		if _selected_deck != "" and not SceneRouter.has_overlay():
			Sfx.select()
			DeckCosmetics.open(_selected_deck))
	vrow.add_child(more)
	# 0.17.0: o texto da variante por baixo, a toda a largura (ao lado das costas ficava espremido numa coluna).
	_variant_label = UiKit.label("", 14, UiKit.TEXT_DIM, true)
	_variant_label.name = "VariantText"
	parent.add_child(_variant_label)
	parent.move_child(_variant_label, start_btn.get_index())
	# 0.19.0 (75): uma carta (1 de 3) depois de cada batalha ganha, ou saltar por ouro — opção da run.
	_rewards_btn = UiKit.button("", 44, 16)
	_rewards_btn.name = "CardRewards"
	_rewards_btn.tooltip_text = tr("Depois de cada batalha ganha escolhes 1 de 3 cartas das tuas cores, ou saltas e recebes %d ouro.") % Economy.CARD_SKIP_GOLD
	_rewards_btn.pressed.connect(_on_card_rewards)
	parent.add_child(_rewards_btn)
	parent.move_child(_rewards_btn, start_btn.get_index())
	_rewards_btn.visible = _side == ""
	_refresh_card_rewards()
	_stake_label = UiKit.label("", 15, UiKit.TEXT_DIM, true)
	parent.add_child(_stake_label)
	parent.move_child(_stake_label, start_btn.get_index())
	_stake_row = HBoxContainer.new()
	_stake_row.add_theme_constant_override("separation", 4)
	parent.add_child(_stake_row)
	parent.move_child(_stake_row, start_btn.get_index())
	_stake_row.visible = _side == ""   # 0.17.0: a Torre e a Corrida não têm Selos Planares
	_stake_label.visible = _side == ""
	for i in range(1, GameState.STAKES.size() + 1):
		var b := Button.new()
		b.text = str(i)
		b.custom_minimum_size = Vector2(0, 40)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 17)
		b.toggle_mode = true
		b.pressed.connect(_select_stake.bind(i))
		_stake_row.add_child(b)
	for i in CardDB.campaign.size():
		var act: Dictionary = CardDB.campaign[i]
		var b := Button.new()
		b.text = tr(String(act.get("title", "Ato")).split(" — ")[0])
		b.custom_minimum_size = Vector2(150, 54)
		b.add_theme_font_size_override("font_size", 20)
		b.toggle_mode = true
		b.pressed.connect(_select_act.bind(i))
		act_buttons.add_child(b)
	# 0.13.1: abre no Livro I (antes abria no livro mais avançado já aberto), ou no último livro
	# escolhido neste modo desde que a app abriu. 0.14.0: um livro bloqueado nunca fica guardado.
	# 0.19.0 (179): o livro, o baralho, o Selo e a variante da última vez também ficam de uma sessão para a outra.
	var lc := GameState.last_choice(_mode_key())
	if int(_last_act.get(_mode_key(), 0)) == 0 and not lc.is_empty():
		_last_act[_mode_key()] = int(lc.get("act", 0))
		_stake = maxi(1, int(lc.get("stake", 1)))
		_variant = String(lc.get("variant", "classic"))
		_remembered_deck = String(lc.get("deck", ""))
	var start := clampi(int(_last_act.get(_mode_key(), 0)), 0, CardDB.campaign.size() - 1)
	if not _act_open(start):
		start = 0
	_select_act(start)

func _act_open(i: int) -> bool:
	return GameState.free_mode or GameState.is_act_unlocked(i)

var _remembered_deck := ""

func _mode_key() -> String:
	if _side != "":
		return _side
	if _short != "":
		return _short
	return "quick" if _quick else ("free" if GameState.free_mode else "campaign")

func _refresh_difficulty() -> void:
	_diff_btn.text = tr("DIFICULDADE: %s") % tr(GameState.difficulty_name()).to_upper()

func _on_difficulty() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	GameState.cycle_difficulty()
	_refresh_difficulty()
	SceneRouter.toast(GameState.difficulty_text())

func _select_act(i: int) -> void:
	_act_index = i
	if _act_open(i):
		_last_act[_mode_key()] = i
	for j in act_buttons.get_child_count():
		(act_buttons.get_child(j) as Button).button_pressed = (j == i)
	var act: Dictionary = CardDB.campaign[i]
	var unlocked := GameState.free_mode or GameState.is_act_unlocked(i)
	act_intro.text = String(act.get("intro", "")) if unlocked else tr("Ato bloqueado — chega ao ante 6 com um baralho do ato anterior.")
	UiKit.clear_children(chapter_list)
	var first_open := ""
	for ch in act.get("chapters", []):
		var deck_id := String(ch["deck_id"])
		var deck := CardDB.get_deck(deck_id)
		var open := GameState.free_mode or GameState.is_deck_unlocked(deck_id)
		var best := GameState.best_ante(deck_id)
		var best_txt := ""
		if GameState.wins(deck_id) > 0:
			best_txt = "  ·  " + tr("VENCIDO")
		elif best > 0:
			best_txt = "  ·  " + tr("melhor: ante %d") % best
		var medal := GameState.medal_for(deck_id)
		var lock_txt := "" if open else "  ·  " + tr("bloqueado")
		if not open and ch.get("unlock") is Dictionary:
			lock_txt = "  ·  " + _achievement_lock_text(String((ch["unlock"] as Dictionary).get("achievement", "")))
		var b := UiKit.wrap_button("%02d · %s  —  %s  %s%s%s" % [int(deck.num), tr(ch["title"]), tr(deck.name), _stars(int(deck.difficulty)), best_txt, lock_txt], 66, 19)
		if medal != "":
			_add_medal(b, medal)
			UiKit.wrap_label(b).offset_right = -52   # espaço para a medalha
		b.disabled = not open
		b.pressed.connect(_select_chapter.bind(deck_id))
		chapter_list.add_child(b)
		if open and first_open == "":
			first_open = deck_id
	if _remembered_deck != "" and (GameState.free_mode or GameState.is_deck_unlocked(_remembered_deck)):
		for ch in act.get("chapters", []):
			if String(ch["deck_id"]) == _remembered_deck:
				first_open = _remembered_deck
		_remembered_deck = ""
	if first_open != "":
		_select_chapter(first_open)
	else:
		detail_panel.visible = false

## 0.13.0: capítulo que se abre com uma conquista — o que falta e quanto já tens ("Mecânico: joga 40… 12/40").
func _achievement_lock_text(ach_id: String) -> String:
	for a in CardDB.achievements:
		if String(a.get("id", "")) != ach_id:
			continue
		var cond: Dictionary = a.get("cond", {})
		var have := Stats.get_stat(String(cond.get("stat", "")))
		return tr("conquista %s: %s (%d/%d)") % [tr(String(a.get("name", ""))), tr(String(a.get("text", ""))), mini(have, int(cond.get("min", 1))), int(cond.get("min", 1))]
	return tr("bloqueado")

func _select_chapter(deck_id: String) -> void:
	_selected_deck = deck_id
	detail_panel.visible = true
	var deck := CardDB.get_deck(deck_id)
	var ch := CardDB.chapter_for_deck(deck_id)
	chapter_title.text = "%s — %s" % [tr(ch.get("title", "")), tr(deck.name)]
	deck_line.text = tr("%s  ·  %d cartas  ·  dificuldade %s") % [_colors_label(deck), int(deck.size), _stars(int(deck.difficulty))]
	story_label.text = String(ch.get("story", ""))
	var best := GameState.best_ante(deck_id)
	var approx := int(deck.get("approx_cards", 0))
	var parts: Array[String] = []
	parts.append(tr("Mecânica: %s") % tr(deck.mechanic))
	parts.append(tr("Melhor ante: %d") % best if best > 0 else tr("Ainda não jogado"))
	if GameState.wins(deck_id) > 0:
		parts.append(tr("Vitórias: %d") % GameState.wins(deck_id))
	if GameState.stake_won(deck_id) > 0:
		parts.append(tr("Selo Planar vencido: %d") % GameState.stake_won(deck_id) + "  ·  " + tr(MEDAL_NAMES.get(GameState.medal_for(deck_id), "")))
	if _quick and GameState.quick_stake_won(deck_id) > 0:   # 0.13.0: a escada da Run Rápida
		parts.append(tr("Selo vencido na Run Rápida: %d") % GameState.quick_stake_won(deck_id))
	var nxt := GameState.deck_next_xp(deck_id)
	parts.append(tr("Nível do baralho: %d") % GameState.deck_level(deck_id) + ("  ·  " + tr("%d/%d XP") % [GameState.deck_xp(deck_id), nxt] if nxt > 0 else "  ·  " + tr("nível máximo")))
	if not (_variant in GameState.deck_variants(deck_id)):
		_variant = "classic"
	_refresh_variant()
	if _back_picker != null:
		_back_picker.deck_id = deck_id
	_select_stake(clampi(_stake, 1, GameState.max_stake(deck_id, _quick)))
	if approx > 0:
		parts.append(tr("%d carta(s) com efeito aproximado (≈)") % approx)
	if _side != "":
		parts.push_front(_side_mode_text())
	stats_label.text = "\n".join(PackedStringArray(parts))
	_pulse(detail_panel)

## 75: a preferência fica guardada para as runs seguintes.
static func card_rewards_pref() -> bool:
	return GameState.card_rewards_pref()

func _on_card_rewards() -> void:
	Sfx.select()
	Settings.set_opt("card_reward", not card_rewards_pref())
	GameState.save_progress()
	_refresh_card_rewards()

func _refresh_card_rewards() -> void:
	if _rewards_btn != null:
		_rewards_btn.text = tr("Cartas depois das batalhas: %s") % (tr("SIM") if card_rewards_pref() else tr("NÃO")) + "  ▸"

## Variantes abertas pelo nível do baralho: toca para rodar.
func _on_variant() -> void:
	if _selected_deck == "":
		return
	var list := GameState.deck_variants(_selected_deck)
	Sfx.select()
	_variant = String(list[(list.find(_variant) + 1) % list.size()])
	_refresh_variant()

func _refresh_variant() -> void:
	if _variant_btn == null:
		return
	var list := GameState.deck_variants(_selected_deck) if _selected_deck != "" else ["classic"]
	_variant_btn.text = tr("Variante: %s") % tr(String(GameState.DECK_VARIANT_NAMES.get(_variant, ""))) + ("  ▸" if list.size() > 1 else "")
	_variant_btn.disabled = list.size() <= 1
	var locked := GameState.DECK_VARIANTS.size() - list.size()
	_variant_label.text = tr(String(GameState.DECK_VARIANT_TEXT.get(_variant, ""))) + ("  " + tr("(sobe o nível do baralho para abrir mais %d)") % locked if locked > 0 else "")

func _select_stake(n: int) -> void:
	var max_n := GameState.max_stake(_selected_deck, _quick) if _selected_deck != "" else 1
	_stake = clampi(n, 1, max_n)
	for i in _stake_row.get_child_count():
		var b: Button = _stake_row.get_child(i)
		b.button_pressed = (i + 1 == _stake)
		b.disabled = i + 1 > max_n
	var info: Dictionary = GameState.STAKES[_stake - 1]
	var txt := tr("Selo Planar %d — %s: %s") % [_stake, tr(String(info.get("name", ""))), tr(String(info.get("text", "")))]
	if _stake > 1:
		txt += "  " + tr("(acumula os selos anteriores)")
	if _quick and max_n < GameState.STAKES.size():
		txt += "  " + tr("Vence o Selo %d numa Run Rápida (ou na campanha) para abrir o seguinte.") % max_n
	_stake_label.text = txt

## 0.17.0: o que é o modo (Torre / Corrida) e o recorde, no topo do painel do baralho.
func _side_mode_text() -> String:
	if _side == "tower":
		var best := GameState.tower_best()
		var t := tr("Torre do Arquimago: andares seguidos, sem loja nem mapa. Depois de cada andar, uma carta, uma relíquia ou descanso; de 5 em 5 andares, um boss.")
		return t + ("\n" + tr("Recorde: andar %d.") % best if best > 0 else "")
	var n := GameState.rush_order().size()
	var t2 := tr("Corrida de Bosses: os %d bosses que já venceste, seguidos, com 30 %% de cura entre eles. Medalha pela média de turnos (ouro ≤ 2,5 · prata ≤ 3,5).") % n
	var rec := GameState.rush_record()
	if not rec.is_empty():
		t2 += "\n" + tr("Melhor: %s, média de %s turnos.") % [tr(String(MEDAL_NAMES.get(String(rec.get("medal", "")), ""))), GameState.fmt_dec(float(rec.get("avg", 0.0)))]
	return t2

func _on_start() -> void:
	if _selected_deck == "":
		return
	Sfx.boom()
	GameState.remember_choice(_mode_key(), _selected_deck, _stake, _variant, _act_index)   # 0.19.0 (179)
	GameState.claim_slot_for_new_run()
	if _side != "":   # 0.17.0: Torre do Arquimago / Corrida de Bosses (sem mapa: o ecrã da Torre)
		if _side == "tower":
			GameState.new_tower_run(_selected_deck)
		else:
			GameState.new_rush_run(_selected_deck)
		GameState.apply_deck_variant(_variant)
		GameState.save_run({}, "tower")
		SceneRouter.go("tower")
		return
	if _short != "":
		GameState.new_short_run(_short, _selected_deck, _stake)
	elif _quick:
		GameState.new_quick_run(_selected_deck, _stake)
	else:
		GameState.new_run(_selected_deck, 0, _stake)
		GameState.apply_talents()
	Economy.set_card_rewards(card_rewards_pref())   # 0.19.0 (75)
	GameState.apply_deck_variant(_variant)
	GameState.map_options(1)
	if _short == "skirmish":   # 176: direto para a batalha, sem mapa
		GameState.choose_battle(String((GameState.map_options(1)["battle"] as Array)[0]))
		GameState.save_run({}, "battle")
		SceneRouter.go("battle")
		return
	GameState.save_run({}, "map")
	SceneRouter.go("map")

const MEDAL_NAMES := {"bronze": "Medalha de bronze", "silver": "Medalha de prata", "gold": "Medalha de ouro"}
const MEDAL_COLORS := {"bronze": Color(0.8, 0.5, 0.25), "silver": Color(0.82, 0.84, 0.9), "gold": Color(0.98, 0.78, 0.3)}

## Medalha do baralho (pelo Selo Planar mais alto vencido): um disco no lado direito do botão.
func _add_medal(b: Button, medal: String) -> void:
	var col: Color = MEDAL_COLORS.get(medal, UiKit.GOLD)
	var disc := Control.new()
	disc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	disc.custom_minimum_size = Vector2(30, 30)
	disc.set_anchors_preset(Control.PRESET_CENTER_RIGHT)
	disc.position = Vector2(-40, -15)
	disc.tooltip_text = tr(MEDAL_NAMES.get(medal, ""))
	disc.draw.connect(func():
		disc.draw_circle(Vector2(15, 15), 13.0, col.darkened(0.35))
		disc.draw_circle(Vector2(15, 15), 10.0, col)
		disc.draw_arc(Vector2(15, 15), 13.0, 0.0, TAU, 28, col.lightened(0.3), 2.0, true))
	b.add_child(disc)
	disc.anchor_left = 1.0
	disc.anchor_right = 1.0
	disc.anchor_top = 0.5
	disc.anchor_bottom = 0.5
	disc.offset_left = -42
	disc.offset_right = -12
	disc.offset_top = -15
	disc.offset_bottom = 15

func _stars(n: int) -> String:
	var s := ""
	for i in 5:
		s += "★" if i < n else "☆"
	return s

func _colors_label(deck: Dictionary) -> String:
	var code: String = deck.get("color_code", "")
	if code == "CL/LD":
		return tr("Incolor")
	if code == "WUBRG":
		return tr("5 cores")
	var names: Array[String] = []
	for col in deck.get("colors", []):
		names.append(tr(COLOR_NAMES.get(String(col), String(col))))
	return "/".join(PackedStringArray(names))

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")

func _pulse(view: Control) -> void:
	view.modulate.a = 0.6
	create_tween().tween_property(view, "modulate:a", 1.0, 0.2)
