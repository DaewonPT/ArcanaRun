extends Control
## Campanha: atos → capítulos (cada capítulo é um baralho com a sua história e dificuldade).
## Em Modo Livre todos os capítulos estão abertos e nada conta para o progresso.

const COLOR_NAMES := {"white": "Branco", "blue": "Azul", "black": "Preto", "red": "Vermelho", "green": "Verde"}

@onready var header: Label = %Header
@onready var act_buttons: HBoxContainer = %ActButtons
@onready var act_intro: Label = %ActIntro
@onready var chapter_list: VBoxContainer = %ChapterList
@onready var chapter_title: Label = %ChapterTitle
@onready var deck_line: Label = %DeckLine
@onready var story_label: Label = %Story
@onready var stats_label: Label = %Stats
@onready var start_btn: Button = %Start
@onready var back_btn: Button = %Back
@onready var detail_panel: Control = %DetailPanel

var _act_index := 0
var _selected_deck := ""

func _ready() -> void:
	header.text = tr("MODO LIVRE  ·  todos os baralhos") if GameState.free_mode else tr("CAMPANHA  ·  %s") % tr(GameState.difficulty_name())
	back_btn.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	start_btn.pressed.connect(_on_start)
	for i in CardDB.campaign.size():
		var act: Dictionary = CardDB.campaign[i]
		var b := Button.new()
		b.text = tr(String(act.get("title", "Ato")).split(" — ")[0])
		b.custom_minimum_size = Vector2(150, 54)
		b.add_theme_font_size_override("font_size", 20)
		b.toggle_mode = true
		b.pressed.connect(_select_act.bind(i))
		act_buttons.add_child(b)
	# Abre no ato mais avançado desbloqueado.
	var open := 0
	for i in CardDB.campaign.size():
		if GameState.free_mode or GameState.is_act_unlocked(i):
			open = i
	_select_act(open)

func _select_act(i: int) -> void:
	_act_index = i
	for j in act_buttons.get_child_count():
		(act_buttons.get_child(j) as Button).button_pressed = (j == i)
	var act: Dictionary = CardDB.campaign[i]
	var unlocked := GameState.free_mode or GameState.is_act_unlocked(i)
	act_intro.text = String(act.get("intro", "")) if unlocked else tr("Ato bloqueado — chega ao ante 6 com um baralho do ato anterior.")
	for child in chapter_list.get_children():
		child.queue_free()
	var first_open := ""
	for ch in act.get("chapters", []):
		var deck_id := String(ch["deck_id"])
		var deck := CardDB.get_deck(deck_id)
		var open := GameState.free_mode or GameState.is_deck_unlocked(deck_id)
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 66)
		b.add_theme_font_size_override("font_size", 19)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		var best := GameState.best_ante(deck_id)
		var best_txt := ""
		if GameState.wins(deck_id) > 0:
			best_txt = "  ·  " + tr("VENCIDO")
		elif best > 0:
			best_txt = "  ·  " + tr("melhor: ante %d") % best
		b.text = "%02d · %s  —  %s  %s%s%s" % [int(deck.num), tr(ch["title"]), tr(deck.name), _stars(int(deck.difficulty)), best_txt, "" if open else "  ·  " + tr("bloqueado")]
		b.disabled = not open
		b.pressed.connect(_select_chapter.bind(deck_id))
		chapter_list.add_child(b)
		if open and first_open == "":
			first_open = deck_id
	if first_open != "":
		_select_chapter(first_open)
	else:
		detail_panel.visible = false

func _select_chapter(deck_id: String) -> void:
	_selected_deck = deck_id
	detail_panel.visible = true
	var deck := CardDB.get_deck(deck_id)
	var ch := CardDB.chapter_for_deck(deck_id)
	chapter_title.text = "%s — %s" % [tr(ch.get("title", "")), tr(deck.name)]
	deck_line.text = tr("%s  ·  %d cartas  ·  dificuldade %s") % [_colors_label(deck), int(deck.size), _stars(int(deck.difficulty))]
	story_label.text = String(ch.get("story", ""))
	var best := GameState.best_ante(deck_id)
	var approx := int(deck.get("approx_cards", 0))
	var parts: Array[String] = []
	parts.append(tr("Mecânica: %s") % tr(deck.mechanic))
	parts.append(tr("Melhor ante: %d") % best if best > 0 else tr("Ainda não jogado"))
	if GameState.wins(deck_id) > 0:
		parts.append(tr("Vitórias: %d") % GameState.wins(deck_id))
	if approx > 0:
		parts.append(tr("%d carta(s) com efeito aproximado (≈)") % approx)
	stats_label.text = "\n".join(PackedStringArray(parts))
	_pulse(detail_panel)

func _on_start() -> void:
	if _selected_deck == "":
		return
	Sfx.boom()
	GameState.clear_saved_run()
	GameState.new_run(_selected_deck)
	SceneRouter.go("battle")

func _stars(n: int) -> String:
	var s := ""
	for i in 5:
		s += "★" if i < n else "☆"
	return s

func _colors_label(deck: Dictionary) -> String:
	var code: String = deck.get("color_code", "")
	if code == "CL/LD":
		return tr("Incolor")
	if code == "WUBRG":
		return tr("5 cores")
	var names: Array[String] = []
	for col in deck.get("colors", []):
		names.append(tr(COLOR_NAMES.get(String(col), String(col))))
	return "/".join(PackedStringArray(names))

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")

func _pulse(view: Control) -> void:
	view.modulate.a = 0.6
	create_tween().tween_property(view, "modulate:a", 1.0, 0.2)
