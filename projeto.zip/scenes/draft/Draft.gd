extends Control
## Arena Draft (modo selado): começas sem baralho. Abres 5 boosters de 5 cartas, escolhes 2 de
## cada (10 cartas), juntas 3 terrenos à escolha e entras numa run curta de 4 antes (não conta
## para a campanha). Os boosters a partir do 2.º puxam mais pelas cores que já escolheste.

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const PACKS := 5
const PACK_SIZE := 5
const PICKS_PER_PACK := 2
const LAND_CHOICES := 6
const LANDS_TO_PICK := 3
const RARITY_WEIGHT := {"common": 60.0, "uncommon": 30.0, "rare": 10.0}

var _rng := RandomNumberGenerator.new()
var _pack_index := 0
var _picked: Array[String] = []        # ids escolhidos (não terrenos)
var _lands: Array[String] = []
var _current: Array[CardData] = []     # cartas do booster/terrenos em cima da mesa
var _picks_left := PICKS_PER_PACK
var _stage := "packs"                  # "packs" | "lands" | "done"

var _title: Label
var _progress: Label
var _table: HBoxContainer
var _list: VBoxContainer
var _summary: Label
var _start_btn: Button

func _ready() -> void:
	_rng.randomize()
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var back := UiKit.button(tr("◀ MENU"), 48, 18)
	back.custom_minimum_size.x = 120
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	_title = UiKit.label(tr("ARENA DRAFT"), 26, UiKit.GOLD)
	_title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(_title)
	_progress = UiKit.label("", 18, UiKit.TEXT_DIM)
	_progress.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_progress.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_progress.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	header.add_child(_progress)

	var body := HBoxContainer.new()
	body.add_theme_constant_override("separation", 14)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(body)
	var center := CenterContainer.new()
	center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	center.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_child(center)
	_table = HBoxContainer.new()
	_table.add_theme_constant_override("separation", 14)
	center.add_child(_table)

	var side := PanelContainer.new()
	side.custom_minimum_size.x = 300
	side.add_theme_stylebox_override("panel", UiKit.flat(UiKit.BG, 12, UiKit.BORDER, 2, 12))
	body.add_child(side)
	var side_box := VBoxContainer.new()
	side_box.add_theme_constant_override("separation", 6)
	side.add_child(side_box)
	side_box.add_child(UiKit.label(tr("O teu baralho"), 22, UiKit.GOLD))
	_summary = UiKit.label("", 15, UiKit.TEXT_DIM, true)
	side_box.add_child(_summary)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	side_box.add_child(scroll)
	_list = VBoxContainer.new()
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list.add_theme_constant_override("separation", 2)
	scroll.add_child(_list)
	_start_btn = UiKit.button(tr("ENTRAR NA ARENA  ▶"), 56, 22, UiKit.PRIMARY, Color(0, 0, 0, 0))
	_start_btn.visible = false
	_start_btn.pressed.connect(_on_start)
	side_box.add_child(_start_btn)

	var hint := UiKit.label(tr("Toca numa carta para a escolher; toque longo para ver em grande."), 15, UiKit.TEXT_DIM)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(hint)
	_open_pack()

# --- Boosters ---

func _weighted_pick(pool: Array[CardData]) -> CardData:
	var total := 0.0
	for c in pool:
		total += float(RARITY_WEIGHT.get(c.rarity, 30.0))
	var roll := _rng.randf() * total
	for c in pool:
		roll -= float(RARITY_WEIGHT.get(c.rarity, 30.0))
		if roll <= 0.0:
			return c
	return pool[pool.size() - 1]

## Cores já escolhidas, da mais à menos frequente.
func picked_colors() -> Array:
	var counts := {}
	for id in _picked:
		for col in CardDB.get_card(id).colors:
			counts[col] = counts.get(col, 0) + 1
	var cols: Array = counts.keys()
	cols.sort_custom(func(a, b): return counts[a] > counts[b])
	return cols

func _open_pack() -> void:
	_stage = "packs"
	_picks_left = PICKS_PER_PACK
	_current.clear()
	var all: Array[CardData] = []
	for c in CardDB.cards.values():
		if not c.is_land() and not c.is_curse() and not (c.id in _picked) and CardDB.is_available(c):
			all.append(c)
	var favored: Array[CardData] = []
	var top := picked_colors().slice(0, 2)
	if _pack_index > 0 and not top.is_empty():
		for c in all:
			if c.colors.all(func(col): return col in top):
				favored.append(c)
	for i in PACK_SIZE:
		var pool := favored if (not favored.is_empty() and _rng.randf() < 0.6) else all
		var pick := _weighted_pick(pool)
		_current.append(pick)
		all.erase(pick)
		favored.erase(pick)
	_progress.text = tr("Booster %d/%d  ·  escolhe %d") % [_pack_index + 1, PACKS, _picks_left]
	_build_table()
	_refresh_side()

func _open_lands() -> void:
	_stage = "lands"
	_picks_left = LANDS_TO_PICK
	_current.clear()
	var top := picked_colors().slice(0, 2)
	var lands: Array[CardData] = []
	for c in CardDB.cards.values():
		if c.is_land() and c.colors.all(func(col): return col in top):
			lands.append(c)
	if lands.size() < LAND_CHOICES:
		for c in CardDB.cards.values():
			if c.is_land() and not (c in lands):
				lands.append(c)
	for i in LAND_CHOICES:
		if lands.is_empty():
			break
		var pick: CardData = lands[_rng.randi_range(0, lands.size() - 1)]
		lands.erase(pick)
		_current.append(pick)
	_progress.text = tr("Terrenos  ·  escolhe %d") % _picks_left
	_build_table()
	_refresh_side()

func _build_table() -> void:
	for c in _table.get_children():
		c.queue_free()
	for d in _current:
		var view: CardView = CARD_VIEW.instantiate()
		_table.add_child(view)
		view.custom_minimum_size = Vector2(176, 250)
		view.setup(CardDB.new_instance(d.id))
		if not _picked.is_empty():
			view.set_synergy(CardDB.synergy_reason(d, _picked))
		view.pressed.connect(_on_pick)
		view.long_pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
		UiKit.pop_in(view)

func _on_pick(card: CardInstance) -> void:
	if _picks_left <= 0 or _stage == "done":
		return
	var d := card.data
	if not (d in _current):
		return
	Sfx.select()
	_current.erase(d)
	if _stage == "lands":
		_lands.append(d.id)
	else:
		_picked.append(d.id)
	Stats.mark_seen("cards", d.id, false)
	_picks_left -= 1
	for v in _table.get_children():
		if v is CardView and (v as CardView).card.data == d:
			v.queue_free()
	_refresh_side()
	if _picks_left > 0:
		_progress.text = (tr("Booster %d/%d  ·  escolhe %d") % [_pack_index + 1, PACKS, _picks_left]) if _stage == "packs" else (tr("Terrenos  ·  escolhe %d") % _picks_left)
		return
	if _stage == "packs":
		_pack_index += 1
		if _pack_index < PACKS:
			await get_tree().create_timer(Settings.dur(0.25)).timeout
			_open_pack()
		else:
			await get_tree().create_timer(Settings.dur(0.25)).timeout
			_open_lands()
	else:
		_stage = "done"
		for c in _table.get_children():
			c.queue_free()
		_progress.text = tr("Baralho pronto: %d cartas") % (_picked.size() + _lands.size())
		_start_btn.visible = true
		Sfx.boom()

func _refresh_side() -> void:
	for c in _list.get_children():
		c.queue_free()
	var all_ids := _picked + _lands
	for id in all_ids:
		var d := CardDB.get_card(id)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 6)
		for col in d.colors:
			row.add_child(CardIcon.pip(col))
		var l := UiKit.label("%d  %s" % [d.cost, tr(d.name)], 14, Color.WHITE)
		l.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(l)
		_list.add_child(row)
	var cols := picked_colors()
	var names: Array[String] = []
	for col in cols.slice(0, 2):
		names.append(tr(CardZoom.COLOR_NAMES.get(String(col), String(col))))
	_summary.text = tr("%d cartas  ·  %d terrenos  ·  cores: %s") % [_picked.size(), _lands.size(), "/".join(PackedStringArray(names)) if not names.is_empty() else "—"]

func _on_start() -> void:
	if _stage != "done":
		return
	Sfx.boom()
	var colors: Array = picked_colors().slice(0, 2)
	GameState.claim_slot_for_new_run()
	GameState.new_draft_run(_picked + _lands, colors)
	GameState.map_options(1)
	GameState.save_run({}, "map")
	SceneRouter.go("map")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
