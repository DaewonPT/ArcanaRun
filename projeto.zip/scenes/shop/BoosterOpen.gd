class_name BoosterOpen
extends Control
## 0.16.0 (V24): abrir um booster na loja. Um pacote (com as tuas costas e a faixa prateada) abana, rasga-se
## em cima e deixa 3 cartas viradas para baixo, que se viram uma a uma — as raras e as com edição com um
## brilho a passar. Depois escolhes uma (toque: sobe e aparece FICAR COM ESTA; manter o dedo: em grande).
## ✕ ou «retroceder» fecha sem escolher (o ouro só sai na escolha). Sem animações, as cartas aparecem logo.

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const SCALE := 1.3
const CARD := Vector2(169, 242)   # CardView.SIZE_NORMAL × 1.3 (as cartas do booster em grande)
const PACK := Vector2(200, 284)
const SPREAD := 230.0

var _cards: Array[CardInstance] = []
var _on_pick: Callable
var _views: Array[CardView] = []
var _backs: Array[CardBack] = []
var _keep: Button
var _hint: Label
var _picked := -1
var _ready_to_pick := false
var _closed := false
var _stage: Control

static func open(cards: Array[CardInstance], on_pick: Callable, title: String = "") -> BoosterOpen:
	var o := BoosterOpen.new()
	o._cards = cards
	o._on_pick = on_pick
	SceneRouter.show_overlay(o)
	SceneRouter.keep_awake(4.0)   # 0.16.0 (72): a abertura do pacote corre a 60 FPS
	o._build(title)
	return o

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.62))

func _animated() -> bool:
	return Settings.motion_ok() and Settings.anim_scale() > 0.0 and DisplayServer.get_name() != "headless"

func _build(title: String) -> void:
	_stage = Control.new()
	_stage.name = "Stage"
	_stage.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_stage)
	_stage.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var head := UiKit.label(title if title != "" else tr("BOOSTER — escolhe 1 de 3"), 30, UiKit.GOLD)
	head.name = "Title"
	head.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	UiKit.outline_for(head, UiKit.GOLD, 6)
	add_child(head)
	head.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	head.offset_top = 40.0
	head.offset_bottom = 84.0
	_hint = UiKit.label(tr("Toca numa carta para a escolher (manter o dedo: ver em grande)."), 17, UiKit.TEXT_DIM)
	_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(_hint)
	_hint.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	_hint.offset_top = 88.0
	_hint.offset_bottom = 112.0
	_hint.modulate.a = 0.0
	# ✕ para fechar sem escolher.
	var x := Button.new()
	x.name = "CloseX"
	x.custom_minimum_size = Vector2(52, 52)
	x.focus_mode = Control.FOCUS_NONE
	x.add_theme_stylebox_override("normal", UiKit.flat(Color(0, 0, 0, 0.35), 26))
	x.add_theme_stylebox_override("hover", UiKit.flat(Color(1, 1, 1, 0.1), 26))
	x.add_theme_stylebox_override("pressed", UiKit.flat(Color(1, 1, 1, 0.18), 26))
	x.tooltip_text = tr("Fechar")
	var xi := CardIcon.new("x", Color(1, 1, 1, 0.85), 22.0)
	x.add_child(xi)
	xi.set_anchors_preset(Control.PRESET_CENTER)
	xi.offset_left = -11.0
	xi.offset_right = 11.0
	xi.offset_top = -11.0
	xi.offset_bottom = 11.0
	x.pressed.connect(close)
	add_child(x)
	x.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	x.offset_left = -84.0
	x.offset_right = -32.0
	x.offset_top = 32.0
	x.offset_bottom = 84.0
	_keep = UiKit.button(tr("FICAR COM ESTA"), 56, 22, UiKit.PRIMARY)
	_keep.name = "Keep"
	_keep.set_meta("haptic", true)
	UiKit.gold_plate(_keep, true)
	_keep.custom_minimum_size.x = 280
	_keep.visible = false
	_keep.pressed.connect(func(): pick(_picked))
	add_child(_keep)
	for i in _cards.size():
		var v: CardView = CARD_VIEW.instantiate()
		v.name = "Card%d" % i
		v.select_chip = ""
		v.size_scale = SCALE
		_stage.add_child(v)
		v.setup(_cards[i])
		v.size = CARD
		v.visible = false
		v.pressed.connect(_on_card_tap.bind(i))
		v.long_pressed.connect(func(c): CardZoom.show_card(c))
		_views.append(v)
	if not _animated():
		_reveal_all_now()
		return
	_play.call_deferred()

func _slot_pos(i: int) -> Vector2:
	var c := size * 0.5 + Vector2(0, 26)
	var n := _cards.size()
	return c + Vector2((i - (n - 1) * 0.5) * SPREAD, 0) - CARD * 0.5

func _reveal_all_now() -> void:
	for i in _views.size():
		_views[i].position = _slot_pos(i)
		_views[i].visible = true
	_hint.modulate.a = 1.0
	_ready_to_pick = true

## A animação: o pacote abana, rasga-se e as cartas saem viradas, separam-se e viram-se uma a uma.
func _play() -> void:
	if _closed:
		return
	var center := size * 0.5 + Vector2(0, 26)
	var pack := _make_pack()
	pack.position = center - PACK * 0.5
	pack.pivot_offset = PACK * 0.5
	pack.scale = Vector2(0.6, 0.6)
	pack.modulate.a = 0.0
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(pack, "scale", Vector2.ONE, 0.25).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tw.tween_property(pack, "modulate:a", 1.0, 0.15)
	tw.set_parallel(false)
	for k in 6:
		tw.tween_property(pack, "rotation", 0.06 if k % 2 == 0 else -0.06, 0.05)
	tw.tween_property(pack, "rotation", 0.0, 0.05)
	await tw.finished
	if _closed:
		return
	Sfx.hit()
	Settings.vibrate(20)
	# Rasga: a faixa de cima voa e o pacote desce e apaga-se enquanto as cartas sobem.
	var strip: Control = pack.get_node("Strip")
	var t2 := create_tween().set_parallel(true)
	t2.tween_property(strip, "position", strip.position + Vector2(40, -70), 0.3).set_ease(Tween.EASE_OUT)
	t2.tween_property(strip, "rotation", 0.5, 0.3)
	t2.tween_property(strip, "modulate:a", 0.0, 0.3)
	t2.tween_property(pack, "position:y", pack.position.y + 120.0, 0.4).set_delay(0.12).set_ease(Tween.EASE_IN)
	t2.tween_property(pack, "modulate:a", 0.0, 0.3).set_delay(0.2)
	for i in _cards.size():
		var b := CardBack.new()
		b.back_id = GameState.run_back()
		b.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.size = CARD
		b.pivot_offset = CARD * 0.5
		_stage.add_child(b)
		_stage.move_child(b, 0)
		b.position = center - CARD * 0.5 + Vector2(0, 40)
		b.modulate.a = 0.0
		_backs.append(b)
		t2.tween_property(b, "modulate:a", 1.0, 0.15).set_delay(0.1)
		t2.tween_property(b, "position", _slot_pos(i), 0.35).set_delay(0.12 + 0.05 * i).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	await t2.finished
	if _closed:
		return
	pack.queue_free()
	# Viram-se uma a uma.
	for i in _cards.size():
		if _closed:
			return
		await _flip(i)
	var t3 := create_tween()
	t3.tween_property(_hint, "modulate:a", 1.0, 0.2)
	_ready_to_pick = true

func _flip(i: int) -> void:
	var b := _backs[i]
	var v := _views[i]
	v.position = b.position
	v.pivot_offset = CARD * 0.5
	var tw := create_tween()
	tw.tween_property(b, "scale:x", 0.0, 0.12).set_ease(Tween.EASE_IN)
	await tw.finished
	if _closed or not is_instance_valid(v):
		return
	b.visible = false
	v.visible = true
	v.scale = Vector2(0.0, 1.0)
	var t2 := create_tween()
	t2.tween_property(v, "scale:x", 1.0, 0.14).set_ease(Tween.EASE_OUT)
	var rare := String(_cards[i].data.rarity) in ["rare", "mythic"] or _cards[i].edition() != ""
	if rare:
		Sfx.boom()
		_shine(v)
	else:
		Sfx.select()
	await t2.finished

## Brilho dourado que passa uma vez por cima de uma carta rara.
func _shine(v: Control) -> void:
	var s := Control.new()
	s.mouse_filter = Control.MOUSE_FILTER_IGNORE
	s.clip_contents = true
	s.size = CARD
	v.add_child(s)
	var band := ColorRect.new()
	band.color = Color(1.0, 0.92, 0.6, 0.0)
	band.size = Vector2(40, CARD.y * 1.6)
	band.rotation = 0.35
	band.position = Vector2(-60, -30)
	band.mouse_filter = Control.MOUSE_FILTER_IGNORE
	s.add_child(band)
	var tw := s.create_tween().set_parallel(true)
	tw.tween_property(band, "position:x", CARD.x + 30.0, 0.5).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(band, "color:a", 0.55, 0.15)
	tw.tween_property(band, "color:a", 0.0, 0.2).set_delay(0.3)
	tw.chain().tween_callback(s.queue_free)

## O pacote: as tuas costas como capa, com uma faixa prateada em cima (a que se rasga) e outra em baixo.
func _make_pack() -> Control:
	var pack := Control.new()
	pack.name = "Pack"
	pack.size = PACK
	pack.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_stage.add_child(pack)
	var cover := CardBack.new()
	cover.back_id = GameState.run_back()
	cover.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cover.size = PACK - Vector2(0, 36)
	cover.position = Vector2(0, 18)
	pack.add_child(cover)
	for top in [true, false]:
		var crimp := Control.new()
		crimp.name = "Strip" if top else "Bottom"
		crimp.mouse_filter = Control.MOUSE_FILTER_IGNORE
		crimp.size = Vector2(PACK.x, 22)
		crimp.position = Vector2(0, 0 if top else PACK.y - 22)
		crimp.pivot_offset = crimp.size * 0.5
		crimp.draw.connect(_draw_crimp.bind(crimp, top))
		pack.add_child(crimp)
	return pack

func _draw_crimp(c: Control, top: bool) -> void:
	var w := c.size.x
	var h := c.size.y
	var pts := PackedVector2Array()
	var teeth := 14
	if top:
		pts.append(Vector2(0, h))
		for k in teeth + 1:
			pts.append(Vector2(w * k / teeth, 4.0 if k % 2 == 0 else 0.0))
		pts.append(Vector2(w, h))
	else:
		pts.append(Vector2(0, 0))
		pts.append(Vector2(w, 0))
		for k in range(teeth, -1, -1):
			pts.append(Vector2(w * k / teeth, h - (4.0 if k % 2 == 0 else 0.0)))
	var cols := PackedColorArray()
	for p in pts:
		cols.append(Color(0.86, 0.86, 0.94).lerp(Color(0.5, 0.48, 0.6), p.y / h))
	c.draw_polygon(pts, cols)
	for k in 6:
		var x := w * (k + 0.5) / 6.0
		c.draw_line(Vector2(x, 6), Vector2(x, h - 4), Color(1, 1, 1, 0.25), 1.0)

func _on_card_tap(_c: CardInstance, i: int) -> void:
	if not _ready_to_pick or _closed:
		return
	Sfx.select()
	_picked = i
	for k in _views.size():
		var on := k == i
		_views[k].set_selected(on, true)
		var y := _slot_pos(k).y - (16.0 if on else 0.0)
		if _animated():
			create_tween().tween_property(_views[k], "position:y", y, 0.12).set_ease(Tween.EASE_OUT)
		else:
			_views[k].position.y = y
	_keep.visible = true
	_keep.reset_size()
	var vp := _slot_pos(i)
	_keep.position = Vector2(clampf(vp.x + CARD.x * 0.5 - _keep.size.x * 0.5, 16.0, size.x - _keep.size.x - 16.0), vp.y + CARD.y + 22.0)

## Fica com a carta i (também usado pelos testes).
func pick(i: int) -> void:
	if _closed or i < 0 or i >= _cards.size():
		return
	_closed = true
	var c := _cards[i]
	UiKit.close_animated(self)
	if _on_pick.is_valid():
		_on_pick.call(c)

func close() -> void:
	if _closed:
		return
	_closed = true
	Sfx.select()
	UiKit.close_animated(self)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()
