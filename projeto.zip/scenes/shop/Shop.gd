extends Control
## Loja (nó do mapa): cartas (3 ofertas, booster 1-de-3, novas ofertas), relíquias (2 ofertas, as
## tuas com venda, máx. 5) e serviços (curar, vida máxima, melhorar carta, selar carta, remover
## carta, ver baralho). Juros: +1 ouro por cada 5 guardados (máx. 5), uma vez por ante.
## Mercador Cego (outro nó): só relíquias lendárias (não saem na loja normal) e planeswalkers.
## Selos Planares: 5 — relíquias compradas não se vendem; 6 — cartas de booster podem vir infetadas.
## 0.10.0: um Vale por visita (melhoria da run: +1 mão, +1 canalização, +1 relíquia, juros, preços…),
## ícone ⚭ (corrente) nas cartas que combinam com o baralho e regras dos Desafios (sem relíquias, custo ≤ 2).

const HEAL_PRICE := 3
const HEAL_AMOUNT := 5
const MAX_HP_PRICE := 8
const MAX_HP_AMOUNT := 5
const UPGRADE_PRICE := 4
const UPGRADE_POWER := 10
const UPGRADE_MULT := 0.5
const BOOSTER_PRICE := 5
const REROLL_BASE := 2
const SEAL_PRICE := 6
const INFECTION_CHANCE := 0.5

@onready var cards_box: VBoxContainer = %CardOffers
@onready var relics_box: VBoxContainer = %RelicOffers
@onready var owned_box: VBoxContainer = %OwnedRelics
@onready var owned_title: Label = %OwnedTitle
@onready var gold_label: Label = %GoldLabel
@onready var life_label: Label = %LifeLabel
@onready var continue_btn: Button = %Continue
@onready var remove_btn: Button = %RemoveButton
@onready var heal_btn: Button = %HealBtn
@onready var max_hp_btn: Button = %MaxHpBtn
@onready var upgrade_btn: Button = %UpgradeBtn
@onready var booster_btn: Button = %BoosterBtn
@onready var reroll_btn: Button = %RerollBtn
@onready var deck_btn: Button = %DeckButton
@onready var seal_btn: Button = %SealBtn
@onready var interest_label: Label = %InterestLabel
@onready var note_label: Label = %ServicesNote

var removed_this_visit: bool = false
var upgraded_this_visit: bool = false
var max_hp_this_visit: bool = false
var booster_this_visit: bool = false
var sealed_this_visit: bool = false
var rerolls: int = 0
var merchant: bool = false            # Mercador Cego
var _offer_cards: Array[CardData] = []
var _offer_relics: Array[Dictionary] = []
var _offer_pws: Array[Dictionary] = []
var _bought_cards: Array[String] = []
var _bought_relics: Array[String] = []
var _voucher: String = ""             # Vale à venda nesta visita ("" = nenhum)

func _ready() -> void:
	merchant = String(GameState.map_choice.get("stop", "")) == "merchant"
	if merchant:
		%Title.text = tr("MERCADOR CEGO  ·  ante %d vencido  ·  %s") % [GameState.ante, tr(GameState.deck_def.get("name", ""))]
		%CardsTitle.text = tr("Planeswalkers")
		%RelicsTitle.text = tr("Relíquias lendárias")
	else:
		%Title.text = tr("MERCADOR  ·  ante %d vencido  ·  %s") % [GameState.ante, tr(GameState.deck_def.get("name", ""))]
	GameState.save_run({}, "shop")   # fechar a app aqui retoma na loja (mesmas ofertas, mesmos juros)
	var due := GameState.pay_interest()
	if due > 0:
		interest_label.text = tr("Juros: +%d ouro (1 por cada 5 guardados, máx. %d).") % [due, GameState.interest_cap()]
	else:
		interest_label.text = tr("Juros: 1 ouro por cada 5 guardados ao entrar na loja (máx. %d).") % GameState.interest_cap()
	var tax := int(GameState.relic_passive("shop_tax"))
	if tax > 0:
		interest_label.text += "  ·  " + tr("Preços +%d (relíquia de boss).") % tax
	EventBus.gold_changed.connect(_on_gold_changed)
	EventBus.player_hp_changed.connect(func(c, m): life_label.text = tr("Vida %d/%d") % [c, m])
	life_label.text = tr("Vida %d/%d") % [GameState.player_hp, GameState.player_max_hp]
	continue_btn.pressed.connect(_on_continue)
	remove_btn.pressed.connect(_on_remove)
	heal_btn.pressed.connect(_on_heal)
	max_hp_btn.pressed.connect(_on_max_hp)
	upgrade_btn.pressed.connect(_on_upgrade)
	booster_btn.pressed.connect(_on_booster)
	reroll_btn.pressed.connect(_on_reroll)
	seal_btn.pressed.connect(_on_seal)
	deck_btn.pressed.connect(func(): Sfx.select(); ZoneViewer.open_deck(tr("O TEU BARALHO")))
	if merchant:
		booster_btn.visible = false
		reroll_btn.visible = false
		upgrade_btn.visible = false
		remove_btn.visible = false
		seal_btn.visible = false
	else:
		_voucher = GameState.shop_voucher_offer()
	if not GameState.relics_allowed():
		%RelicsTitle.text = tr("Sem relíquias (Desafio)")
	_roll_offers()
	_build_offers()
	_on_gold_changed(GameState.gold)

func _on_gold_changed(g: int) -> void:
	gold_label.text = tr("Ouro: %d") % g
	_refresh_services()
	_refresh_offer_buttons()

# --- Ofertas ---

func _roll_offers() -> void:
	_offer_relics.clear()
	_offer_pws.clear()
	_bought_cards.clear()
	_bought_relics.clear()
	if merchant:
		_offer_cards = []
		var legendary := CardDB.legendary_relics(GameState.relic_ids) if GameState.relics_allowed() else []
		for i in 2:
			if legendary.is_empty():
				break
			var pick: Dictionary = legendary[GameState.rng.randi_range(0, legendary.size() - 1)]
			legendary.erase(pick)
			_offer_relics.append(pick)
		var pws: Array = CardDB.planeswalkers.filter(func(p): return String(p.get("id", "")) != String(GameState.planeswalker.get("id", "")) and CardDB.is_planeswalker_available(p))
		for i in 2:
			if pws.is_empty():
				break
			var pick: Dictionary = pws[GameState.rng.randi_range(0, pws.size() - 1)]
			pws.erase(pick)
			_offer_pws.append(pick)
		return
	_offer_cards = CardDB.random_shop_offers(3 + int(GameState.voucher_value("shop_cards")), GameState.rng)
	if not GameState.relics_allowed():
		return
	var exclude: Array = GameState.relic_ids.duplicate()
	for i in 2:
		var r := CardDB.random_relic_offer(GameState.rng, exclude)
		if r.is_empty():
			break
		_offer_relics.append(r)
		exclude.append(String(r.get("id", "")))

func _build_offers() -> void:
	for child in cards_box.get_children():
		child.queue_free()
	for child in relics_box.get_children():
		child.queue_free()
	for c in _offer_cards:
		Stats.mark_seen("cards", c.id, false)
		var stats := ""
		if c.is_creature():
			stats = "  ·  %d⚔ %d♥" % [c.power, c.toughness]
		elif c.power > 0:
			stats = "  ·  %d⚔" % c.power
		var card_price := _p(c.price)
		var why := CardDB.synergy_reason(c)
		var head := ("⚭ " if why != "" else "") + tr("%s  (custo %d%s  ·  %d ouro)") % [tr(c.name), c.cost, stats, card_price]
		var btn := _offer_button(head + "\n" + tr(c.text) + (("\n⚭ " + tr("Combina: %s") % why) if why != "" else ""), card_price)
		if why != "":
			btn.custom_minimum_size.y = 112
			btn.tooltip_text = tr("Combina com o teu baralho: %s") % why
		btn.set_meta("price", card_price)
		btn.set_meta("kind", "card")
		btn.pressed.connect(func():
			if GameState.spend_gold(card_price):
				GameState.add_card(c.id)
				_bought_cards.append(c.id)
				Sfx.select()
				btn.disabled = true
				btn.text += "  ✓")
		cards_box.add_child(btn)
	for p in _offer_pws:
		Stats.mark_seen("planeswalkers", String(p.get("id", "")), false)
		var price := _p(int(p.get("price", 10)))
		var skill_txt: Array[String] = []
		for sk in p.get("skills", []):
			skill_txt.append(tr(String(sk.get("text", ""))))
		var btn := _offer_button(tr("✦ %s  (%d ouro)") % [tr(String(p.get("name", ""))), price] + "\n" + "  ".join(PackedStringArray(skill_txt)), price)
		btn.set_meta("price", price)
		btn.set_meta("kind", "pw")
		btn.custom_minimum_size.y = 96
		btn.pressed.connect(func():
			if GameState.spend_gold(price):
				GameState.set_planeswalker(String(p.get("id", "")))
				Sfx.boom()
				btn.disabled = true
				btn.text += "  ✓"
				_note(tr("%s junta-se a ti. A lealdade sobe ao jogar cartas da cor dele/dela.") % tr(String(p.get("name", "")))))
		cards_box.add_child(btn)
	for r in _offer_relics:
		Stats.mark_seen("relics", String(r.get("id", "")), false)
		var price := _p(int(r.get("price", 5)))
		var rarity_txt := tr("Lendária") if bool(r.get("legendary", false)) else tr(CardZoom.RARITY_NAMES.get(String(r.get("rarity", "common")), "Comum"))
		var btn := _offer_button(tr("★ %s  (%d ouro · %s)") % [tr(r.name), price, rarity_txt] + "\n" + tr(r.text), price)
		btn.set_meta("price", price)
		btn.set_meta("kind", "relic")
		btn.pressed.connect(func():
			if GameState.relic_ids.size() >= GameState.max_relics():
				_note(tr("Já tens %d relíquias: vende uma primeiro.") % GameState.max_relics())
				return
			if GameState.spend_gold(price):
				GameState.add_relic(String(r.id))
				_bought_relics.append(String(r.id))
				if GameState.stake >= 5:
					GameState.relic_locked.append(String(r.id))
				Sfx.select()
				btn.disabled = true
				btn.text += "  ✓"
				_build_owned())
		relics_box.add_child(btn)
	_add_voucher_offer()
	_build_owned()
	_refresh_offer_buttons()

## Preço com a taxa das relíquias de boss (Cálice do Abismo: +2 em tudo).
func _p(base: int) -> int:
	return GameState.shop_price(base)

## Preço dos serviços (o Vale do Artesão baixa-os; nunca menos de 1).
func _svc(base: int) -> int:
	return _p(maxi(1, base - int(GameState.voucher_value("service_discount"))))

func _reroll_price() -> int:
	return _p(maxi(0, REROLL_BASE + rerolls - int(GameState.voucher_value("reroll_discount"))))

## Um Vale por visita: melhoria que fica para o resto da run.
func _add_voucher_offer() -> void:
	if _voucher == "":
		return
	var v := CardDB.get_voucher(_voucher)
	var price := _p(int(v.get("price", 10)))
	var owned := _voucher in GameState.vouchers
	var btn := _offer_button(tr("◆ Vale: %s  (%d ouro)") % [tr(String(v.get("name", ""))), price] + "\n" + tr(String(v.get("text", ""))), price)
	btn.set_meta("price", price)
	btn.set_meta("kind", "voucher")
	btn.add_theme_color_override("font_color", Color(0.65, 0.95, 0.85))
	if owned:
		btn.disabled = true
		btn.text += "  ✓"
	btn.pressed.connect(func():
		if GameState.buy_voucher(_voucher):
			Sfx.boom()
			btn.disabled = true
			btn.text += "  ✓"
			_note(tr("Vale ativo até ao fim da run: %s") % tr(String(v.get("text", ""))))
			_build_owned()
			_refresh_services()
			_refresh_offer_buttons())
	relics_box.add_child(btn)

func _offer_button(label: String, _price: int) -> Button:
	var btn := Button.new()
	btn.text = label
	btn.custom_minimum_size.y = 92
	btn.add_theme_font_size_override("font_size", 15)
	btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
	btn.clip_text = true
	return btn

func _refresh_offer_buttons() -> void:
	for btn in cards_box.get_children() + relics_box.get_children():
		if not (btn is Button) or btn.text.ends_with("✓"):
			continue
		var price: int = btn.get_meta("price", 0)
		var full: bool = btn.get_meta("kind", "") == "relic" and GameState.relic_ids.size() >= GameState.max_relics()
		btn.disabled = GameState.gold < price or full
	booster_btn.text = tr("BOOSTER (%d ouro)") % _p(BOOSTER_PRICE) if not booster_this_visit else tr("Booster aberto  ✓")
	booster_btn.disabled = booster_this_visit or GameState.gold < _p(BOOSTER_PRICE)
	var reroll_price := _reroll_price()
	reroll_btn.text = tr("NOVAS OFERTAS (%d ouro)") % reroll_price
	reroll_btn.disabled = GameState.gold < reroll_price

func _build_owned() -> void:
	for child in owned_box.get_children():
		child.queue_free()
	owned_title.text = tr("As tuas relíquias (%d/%d)") % [GameState.relic_ids.size(), GameState.max_relics()]
	if not GameState.boss_relics.is_empty():
		owned_title.text += "  ·  " + tr("de boss: %d") % GameState.boss_relics.size()
	if not GameState.vouchers.is_empty():
		owned_title.text += "  ·  " + tr("Vales: %d") % GameState.vouchers.size()
	for id in GameState.relic_ids:
		var r: Dictionary = CardDB.relics.get(id, {})
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		var name_btn := Button.new()
		name_btn.text = tr(String(r.get("name", id)))
		name_btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		name_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name_btn.custom_minimum_size.y = 40
		name_btn.add_theme_font_size_override("font_size", 16)
		name_btn.clip_text = true
		name_btn.pressed.connect(func(): Sfx.select(); CardZoom.show_relic(id))
		row.add_child(name_btn)
		var sell := Button.new()
		sell.text = tr("VENDER +%d") % GameState.relic_sell_price(id)
		sell.custom_minimum_size = Vector2(130, 40)
		sell.add_theme_font_size_override("font_size", 15)
		if id in GameState.relic_locked:
			sell.text = tr("PRESA")
			sell.disabled = true
			sell.tooltip_text = tr("Marca Eterna: as relíquias compradas na loja não se vendem.")
		sell.pressed.connect(func():
			GameState.add_gold(GameState.relic_sell_price(id))
			GameState.remove_relic(id)
			Sfx.hit()
			_build_owned()
			_refresh_offer_buttons())
		row.add_child(sell)
		owned_box.add_child(row)
	# Relíquias de boss: não se vendem nem ocupam lugar.
	for id in GameState.boss_relics:
		var r: Dictionary = CardDB.relics.get(id, {})
		var brow := HBoxContainer.new()
		brow.add_theme_constant_override("separation", 8)
		var bname := Button.new()
		bname.text = tr(String(r.get("name", id)))
		bname.alignment = HORIZONTAL_ALIGNMENT_LEFT
		bname.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		bname.custom_minimum_size.y = 40
		bname.add_theme_font_size_override("font_size", 16)
		bname.add_theme_color_override("font_color", Color(1.0, 0.6, 0.55))
		bname.clip_text = true
		bname.pressed.connect(func(): Sfx.select(); CardZoom.show_relic(id))
		brow.add_child(bname)
		var tag := Button.new()
		tag.text = tr("DE BOSS")
		tag.disabled = true
		tag.custom_minimum_size = Vector2(130, 40)
		tag.add_theme_font_size_override("font_size", 15)
		brow.add_child(tag)
		owned_box.add_child(brow)

# --- Serviços ---

func _refresh_services() -> void:
	var price := _svc(GameState.removal_price())
	if removed_this_visit:
		remove_btn.text = tr("Carta removida  ✓")
		remove_btn.disabled = true
	else:
		remove_btn.text = tr("REMOVER UMA CARTA (%d ouro)") % price
		remove_btn.disabled = GameState.gold < price or GameState.deck.size() <= 6
	heal_btn.text = tr("CURAR %d (%d ouro)") % [HEAL_AMOUNT, _svc(HEAL_PRICE)]
	heal_btn.disabled = GameState.gold < _svc(HEAL_PRICE) or GameState.player_hp >= GameState.player_max_hp
	if max_hp_this_visit:
		max_hp_btn.text = tr("Vida máxima +%d  ✓") % MAX_HP_AMOUNT
		max_hp_btn.disabled = true
	else:
		max_hp_btn.text = tr("VIDA MÁXIMA +%d (%d ouro)") % [MAX_HP_AMOUNT, _svc(MAX_HP_PRICE)]
		max_hp_btn.disabled = GameState.gold < _svc(MAX_HP_PRICE)
	if upgraded_this_visit:
		upgrade_btn.text = tr("Carta melhorada  ✓")
		upgrade_btn.disabled = true
	else:
		upgrade_btn.text = tr("MELHORAR UMA CARTA (%d ouro)") % _svc(UPGRADE_PRICE)
		upgrade_btn.disabled = GameState.gold < _svc(UPGRADE_PRICE)
	if sealed_this_visit:
		seal_btn.text = tr("Carta selada  ✓")
		seal_btn.disabled = true
	else:
		seal_btn.text = tr("SELAR UMA CARTA (%d ouro)") % _svc(SEAL_PRICE)
		seal_btn.disabled = GameState.gold < _svc(SEAL_PRICE)
	if note_label.text == "":
		note_label.text = tr("Melhorar: +%d Poder permanente (criaturas e feitiços com Poder) ou +%s Mult (as outras). Vida máxima e melhoria: uma vez por visita.") % [UPGRADE_POWER, Cascade.fmt_mult(UPGRADE_MULT)]

func _note(text: String) -> void:
	note_label.text = text

func _on_heal() -> void:
	if GameState.player_hp >= GameState.player_max_hp or not GameState.spend_gold(_svc(HEAL_PRICE)):
		return
	GameState.heal(HEAL_AMOUNT)
	Sfx.select()
	_refresh_services()

func _on_max_hp() -> void:
	if max_hp_this_visit or not GameState.spend_gold(_svc(MAX_HP_PRICE)):
		return
	max_hp_this_visit = true
	GameState.change_max_hp(MAX_HP_AMOUNT)
	GameState.heal(MAX_HP_AMOUNT)
	Sfx.select()
	_refresh_services()

func _on_upgrade() -> void:
	if upgraded_this_visit or GameState.gold < _svc(UPGRADE_PRICE) or SceneRouter.has_overlay():
		return
	Sfx.select()
	ZoneViewer.open_deck(tr("MELHORAR — escolhe a carta"), func(card: CardInstance):
		if upgraded_this_visit or card.entry_index < 0 or not GameState.spend_gold(_svc(UPGRADE_PRICE)):
			return
		upgraded_this_visit = true
		var entry: Dictionary = GameState.deck[card.entry_index]
		if card.data.is_creature() or card.data.power > 0:
			entry["power_bonus"] = int(entry.get("power_bonus", 0)) + UPGRADE_POWER
			_note(tr("%s: +%d Poder permanente.") % [tr(card.data.name), UPGRADE_POWER])
		else:
			entry["mult_bonus"] = float(entry.get("mult_bonus", 0.0)) + UPGRADE_MULT
			_note(tr("%s: +%s Mult permanente.") % [tr(card.data.name), Cascade.fmt_mult(UPGRADE_MULT)])
		Sfx.boom()
		_refresh_services())

## Selo de guilda: escolhe o selo e depois a carta (uma carta só tem um selo; selar outra vez substitui).
func _on_seal() -> void:
	if sealed_this_visit or GameState.gold < _svc(SEAL_PRICE) or SceneRouter.has_overlay():
		return
	Sfx.select()
	var picker := SealPicker.open(func(seal_id: String):
		ZoneViewer.open_deck(tr("SELAR — escolhe a carta"), func(card: CardInstance):
			if sealed_this_visit or card.entry_index < 0 or not GameState.spend_gold(_svc(SEAL_PRICE)):
				return
			sealed_this_visit = true
			GameState.deck[card.entry_index]["seal"] = seal_id
			_note(tr("%s recebeu o %s.") % [tr(card.data.name), tr(String(CardDB.get_seal(seal_id).get("name", seal_id)))])
			Sfx.boom()
			_refresh_services()))
	if picker == null:
		return

func _on_remove() -> void:
	if removed_this_visit or GameState.gold < _svc(GameState.removal_price()) or SceneRouter.has_overlay():
		return
	Sfx.select()
	ZoneViewer.open_deck(tr("REMOVER — escolhe a carta"), func(card: CardInstance):
		if removed_this_visit or card.entry_index < 0 or GameState.deck.size() <= 6:
			return
		if not GameState.spend_gold(_svc(GameState.removal_price())):
			return
		GameState.deck.remove_at(card.entry_index)
		removed_this_visit = true
		_note(tr("%s removida do baralho.") % tr(card.data.name))
		Sfx.hit()
		_refresh_services())

func _on_booster() -> void:
	if booster_this_visit or GameState.gold < _p(BOOSTER_PRICE) or SceneRouter.has_overlay():
		return
	Sfx.select()
	var cards: Array[CardInstance] = []
	var pool := CardDB.shop_pool()
	for i in 3:
		if pool.is_empty():
			break
		var pick := pool[GameState.rng.randi_range(0, pool.size() - 1)]
		pool.erase(pick)
		cards.append(CardDB.new_instance(pick.id))
	ZoneViewer.open(tr("BOOSTER — escolhe 1 de 3"), cards, false, func(card: CardInstance):
		if booster_this_visit or not GameState.spend_gold(_p(BOOSTER_PRICE)):
			return
		booster_this_visit = true
		var infected := GameState.stake >= 6 and GameState.rng.randf() < INFECTION_CHANCE
		GameState.add_card(card.data.id, infected)
		if infected:
			_note(tr("%s juntou-se ao baralho — INFETADA: Poder a dobrar, exila-se ao fim de %d utilizações.") % [tr(card.data.name), BattleManager.INFECTED_USES])
		else:
			_note(tr("%s juntou-se ao baralho.") % tr(card.data.name))
		Sfx.boom()
		_refresh_offer_buttons())

func _on_reroll() -> void:
	var price := _reroll_price()
	if not GameState.spend_gold(price):
		return
	rerolls += 1
	Sfx.select()
	_roll_offers()
	_build_offers()

func _on_continue() -> void:
	GameState.next_ante()
	GameState.save_run({}, "map")
	SceneRouter.go("map")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		Sfx.select()   # na loja o botão "retroceder" não faz nada de destrutivo
