extends Control
## Loja (nó do mapa): cartas (3 ofertas, booster 1-de-3, novas ofertas), relíquias (2 ofertas, as
## tuas com venda, máx. 5) e serviços (curar, vida máxima, melhorar carta, selar carta, remover
## carta, ver baralho). Juros: +1 ouro por cada 5 guardados (máx. 5), uma vez por ante.
## Mercador Cego (outro nó): só relíquias lendárias (não saem na loja normal) e planeswalkers.
## Selos Planares: 5 — relíquias compradas não se vendem; 6 — cartas de booster podem vir infetadas.
## 0.10.0: um Vale por visita (melhoria da run: +1 mão, +1 canalização, +1 relíquia, juros, preços…),
## ícone de elos nas cartas que combinam com o baralho e regras dos Desafios (sem relíquias, custo ≤ 2).
## 0.13.0: cartas com edição (Brilhante, Holográfica, Policromática: mais caras, ver EffectResolver.EDITIONS),
## também no booster; compras caras pedem um segundo toque (Configurações → Confirmar compras caras).
## 0.15.0: Constelação (sobe 1 nível a uma formação à escolha, uma por visita) e DESFAZER (a última compra,
## serviço ou venda desta visita; NOVAS OFERTAS não se desfaz e limpa o que havia para desfazer).
## 0.16.0 (a loja nova, visual «A — Bancada» que o Paulo escolheu):
##   V14 cartas como cartas (tocar escolhe, a carta sobe e aparece COMPRAR; manter o dedo: em grande) ·
##   V15 relíquias com a ilustração (medalhão com a raridade no aro) · V16 poções com imagem e o Vale como
##   bilhete dourado (com «VALE» na vertical, para caber noutras línguas) · V17 serviços com ícones · V18 moeda
##   em todos os preços (vermelho quando não chega) · V19 a tenda por trás · V20 o mercador fala · V21 a compra
##   voa, o ouro desce a contar e saltam moedas · V22 carimbo VENDIDO · V23 as ofertas novas viram-se · V24 o
##   booster abre-se · V25 as tuas relíquias em ranhuras (tocar: a janela com VENDER) · V26 os juros voam para
##   o ouro · V27 MENU (a loja grava as ofertas e cada compra; ao voltar fica tudo igual).

const HEAL_PRICE := 3
const HEAL_AMOUNT := 5
const MAX_HP_PRICE := 8
const MAX_HP_AMOUNT := 5
const UPGRADE_PRICE := 4
const UPGRADE_POWER := 10
const UPGRADE_MULT := 0.5
const BOOSTER_PRICE := 5
const REROLL_BASE := 2
const SEAL_PRICE := 6
const INFECTION_CHANCE := 0.5
const CONFIRM_PRICE := 10     # 0.13.0: "Confirmar compras caras" pede um 2.º toque a partir deste preço…
const CONFIRM_HALF_MIN := 5   # …ou, a partir deste, quando custa metade (ou mais) do ouro que tens
const CONFIRM_TIME := 3.0
const CONSTELLATION_PRICE := 5   # 0.15.0
const ROW_BG := Color(0.17, 0.14, 0.25, 0.92)
const BODY_COLOR := Color(0.85, 0.84, 0.91)
const SLOT := 46.0

@onready var cards_box: BoxContainer = %CardOffers
@onready var card_scroll: ScrollContainer = %CardScroll
@onready var relics_box: VBoxContainer = %RelicOffers
@onready var owned_box: HBoxContainer = %OwnedRelics
@onready var owned_title: Label = %OwnedTitle
@onready var gold_label: Label = %GoldLabel
@onready var gold_box: HBoxContainer = %GoldBox
@onready var life_label: Label = %LifeLabel
@onready var life_box: HBoxContainer = %LifeBox
@onready var face: Control = %MerchantFace
@onready var menu_btn: Button = %MenuBtn
@onready var shop_art: TextureRect = %ShopArt
@onready var continue_btn: Button = %Continue
@onready var remove_btn: Button = %RemoveButton
@onready var heal_btn: Button = %HealBtn
@onready var max_hp_btn: Button = %MaxHpBtn
@onready var upgrade_btn: Button = %UpgradeBtn
@onready var booster_btn: Button = %BoosterBtn
@onready var reroll_btn: Button = %RerollBtn
@onready var deck_btn: Button = %DeckButton
@onready var seal_btn: Button = %SealBtn
@onready var interest_label: Label = %InterestLabel
@onready var note_label: Label = %ServicesNote
@onready var undo_btn: Button = %UndoBtn

var removed_this_visit: bool = false
var upgraded_this_visit: bool = false
var max_hp_this_visit: bool = false
var booster_this_visit: bool = false
var sealed_this_visit: bool = false
var rerolls: int = 0
var merchant: bool = false            # Mercador Cego
var _offer_cards: Array[CardData] = []
var _offer_editions: Array[String] = []   # 0.13.0: edição de cada carta oferecida ("" = normal)
var _confirm_btn: Button                   # 0.13.0: botão à espera do 2.º toque
var _confirm_text := ""
var _confirm_token := 0
var _offer_relics: Array[Dictionary] = []
var _offer_pws: Array[Dictionary] = []
var _bought_cards: Array[String] = []
var _bought_relics: Array[String] = []
var _voucher: String = ""             # Vale à venda nesta visita ("" = nenhum)
var _offer_item: String = ""          # 0.13.0: poção ou pergaminho à venda nesta visita ("" = nenhum)
var _bought_keys: Array[String] = []   # 0.15.0: ofertas compradas ("card:0", "relic:<id>", "item", …), para as refazer
var _undo: Dictionary = {}             # 0.15.0: run e loja antes da última compra/serviço ({} = nada a desfazer)
# 0.16.0
var _tiles: Array[ShopCardTile] = []
var _selected_tile: ShopCardTile = null
var _booster_cards: Array = []         # o booster desta visita ([{"id", "edition"}]): abrir outra vez mostra o mesmo
var _gold_shown := 0                   # o número que o contador mostra (conta até ao ouro a sério)
var _gold_tw: Tween
var _gold_icon: CardIcon
var _svc_parts: Dictionary = {}        # botão → {"label", "price", "done", "icon"}
var _bubble: Control
var _bubble_tw: Tween
var _face_art: Texture2D
var _did_something := false            # comprou, usou um serviço ou vendeu nesta visita
var _leave_armed := false              # PRÓXIMO ANTE sem comprar nada: o mercador despede-se (2.º toque sai logo)
var _busy_reroll := false

func _ready() -> void:
	merchant = String(GameState.map_choice.get("stop", "")) == "merchant"
	if merchant:
		%Title.text = tr("MERCADOR CEGO  ·  ante %d vencido  ·  %s") % [GameState.ante, tr(GameState.deck_def.get("name", ""))]
		%CardsTitle.text = tr("Patronos")
		%RelicsTitle.text = tr("Relíquias lendárias")
		cards_box.vertical = true
		cards_box.alignment = BoxContainer.ALIGNMENT_BEGIN
		card_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		card_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	else:
		%Title.text = tr("MERCADOR  ·  ante %d vencido  ·  %s") % [GameState.ante, tr(GameState.deck_def.get("name", ""))]
	if not GameState.relics_allowed():
		%RelicsTitle.text = tr("Sem relíquias (Desafio)")
	var due := 0
	if not _restore_state():
		# Os juros pagam-se uma vez por ante; depois as ofertas (e fica tudo gravado: voltar da app ou do menu
		# encontra a loja como estava).
		due = GameState.pay_interest()
		if not merchant:
			_voucher = GameState.shop_voucher_offer()
		_roll_offers()
	_style_scene()
	EventBus.gold_changed.connect(_on_gold_changed)
	EventBus.player_hp_changed.connect(func(c, m): life_label.text = "%d/%d" % [c, m])
	life_label.text = "%d/%d" % [GameState.player_hp, GameState.player_max_hp]
	life_box.tooltip_text = tr("Vida %d/%d") % [GameState.player_hp, GameState.player_max_hp]
	continue_btn.pressed.connect(_on_continue)
	remove_btn.pressed.connect(_on_remove)
	heal_btn.pressed.connect(_on_heal)
	max_hp_btn.pressed.connect(_on_max_hp)
	upgrade_btn.pressed.connect(_on_upgrade)
	booster_btn.pressed.connect(_on_booster)
	reroll_btn.pressed.connect(_on_reroll)
	seal_btn.pressed.connect(_on_seal)
	undo_btn.pressed.connect(_on_undo)
	menu_btn.pressed.connect(_on_menu)
	deck_btn.pressed.connect(func(): Sfx.select(); ZoneViewer.open_deck(tr("O TEU BARALHO")))
	if merchant:
		booster_btn.visible = false
		reroll_btn.visible = false
		upgrade_btn.visible = false
		remove_btn.visible = false
		seal_btn.visible = false
	_build_offers()
	_save_state()
	_interest_text(due)
	_set_gold_now(GameState.gold - due)
	_refresh_services()
	_refresh_offer_buttons()
	_refresh_undo()
	if due > 0:
		_play_interest(due)
	else:
		_set_gold_now(GameState.gold)
	_say_later("enter", 0.45)

# --- Aspeto (0.16.0) ---

func _animated() -> bool:
	return Settings.motion_ok() and Settings.anim_scale() > 0.0 and DisplayServer.get_name() != "headless"

## A tenda por trás (V19), o retrato do mercador, os ícones da vida e do ouro, o MENU e os botões com ícones.
func _style_scene() -> void:
	var bg := ArtLib.texture("background", "shop_blind" if merchant else "shop_merchant")
	shop_art.texture = bg
	shop_art.visible = bg != null and not Settings.high_contrast
	_face_art = ArtLib.texture("portrait", "blind_merchant" if merchant else "merchant")
	face.tooltip_text = tr("Mercador Cego") if merchant else tr("Mercador")
	face.draw.connect(_draw_face)
	face.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed and not SceneRouter.has_overlay():
			_say("enter"))
	var heart := CardIcon.new("heart", Color(0.94, 0.32, 0.37), 24.0)
	heart.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	life_box.add_child(heart)
	life_box.move_child(heart, 0)
	_gold_icon = CardIcon.new("coin", UiKit.COIN, 30.0)
	_gold_icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	gold_box.add_child(_gold_icon)
	gold_box.move_child(_gold_icon, 0)
	gold_box.tooltip_text = tr("Ouro. Juros: 1 ouro por cada 5 guardados ao entrar na loja (máx. %d).") % GameState.interest_cap()
	for st in ["normal", "hover", "pressed", "disabled"]:
		menu_btn.add_theme_stylebox_override(st, UiKit.flat(UiKit.BTN_BG.lightened(0.0 if st == "normal" else 0.08), 12))
	UiKit.button_icon(menu_btn, "menu", Color.WHITE, 24.0, true)
	menu_btn.tooltip_text = tr("Sair para o menu (a loja fica gravada tal como está)")
	_svc_setup(heal_btn, "heart", Color(0.94, 0.32, 0.37))
	_svc_setup(max_hp_btn, "lifelink", Color(0.94, 0.32, 0.37))
	_svc_setup(upgrade_btn, "anvil", Color(0.85, 0.82, 0.95))
	_svc_setup(remove_btn, "x", Color(1.0, 0.55, 0.5))
	_svc_setup(seal_btn, "seal", Color(0.78, 0.5, 1.0))
	_svc_setup(deck_btn, "cards", Color(0.85, 0.82, 0.95))
	_svc_setup(booster_btn, "pack", Color(0.62, 0.52, 0.95))
	_svc_setup(reroll_btn, "replay", Color(0.85, 0.82, 0.95))
	for b in [booster_btn, reroll_btn, heal_btn, max_hp_btn, upgrade_btn, remove_btn, seal_btn]:
		(b as Button).set_meta("haptic", true)
	undo_btn.text = tr("DESFAZER")
	UiKit.button_icon(undo_btn, "undo", Color.WHITE, 22.0, false)
	UiKit.gold_plate(continue_btn, true)
	continue_btn.set_meta("haptic", true)

func _draw_face() -> void:
	var c := face.size * 0.5
	var r := minf(face.size.x, face.size.y) * 0.5
	face.draw_circle(c, r, Color(0.08, 0.06, 0.12))
	if _face_art != null:
		ArtLib.draw_round(face, _face_art, c, r - 2.0)
	var ring := StyleBoxFlat.new()
	ring.draw_center = false
	ring.set_border_width_all(3)
	ring.border_color = Color(0.78, 0.55, 1.0) if merchant else Color(0.95, 0.76, 0.36)
	ring.set_corner_radius_all(int(r))
	face.draw_style_box(ring, Rect2(Vector2.ZERO, face.size))

## Serviço (V17): ícone à esquerda, o nome e o preço com a moeda à direita (ou um visto quando já se usou).
func _svc_setup(b: Button, icon_kind: String, icon_color: Color) -> void:
	b.text = ""
	b.clip_contents = true
	var row := HBoxContainer.new()
	row.name = "Content"
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 10)
	b.add_child(row)
	row.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	row.offset_left = 12.0
	row.offset_right = -12.0
	var icon := CardIcon.new(icon_kind, icon_color, 22.0)
	icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(icon)
	var l := UiKit.label("", 16, Color.WHITE, true)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.size_flags_vertical = Control.SIZE_FILL
	row.add_child(l)
	var pr := UiKit.price(0, true, 17)
	pr.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(pr)
	var done := CardIcon.new("check", Color(0.5, 0.92, 0.62), 22.0)
	done.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	done.visible = false
	row.add_child(done)
	_svc_parts[b] = {"label": l, "price": pr, "done": done, "icon": icon}
	b.draw.connect(_svc_dim.bind(b))

func _svc_dim(b: Button) -> void:
	var p: Dictionary = _svc_parts.get(b, {})
	if p.is_empty():
		return
	(p["icon"] as Control).modulate.a = 0.45 if b.disabled else 1.0
	(p["label"] as Control).modulate.a = 0.5 if b.disabled else 1.0

## Texto, preço (−1: sem preço) e visto de um serviço.
func _set_svc(b: Button, text: String, price: int, done: bool) -> void:
	var p: Dictionary = _svc_parts.get(b, {})
	if p.is_empty():
		b.text = text + ("" if price < 0 else "  (%d)" % price)
		return
	(p["label"] as Label).text = text
	var pr: HBoxContainer = p["price"]
	pr.visible = price >= 0 and not done
	if price >= 0:
		UiKit.set_price(pr, price, GameState.gold >= price)
	(p["done"] as Control).visible = done
	b.tooltip_text = text

func _on_gold_changed(g: int) -> void:
	_animate_gold(g)
	_refresh_services()
	_refresh_offer_buttons()

## O contador do ouro conta até ao novo valor (e, a descer, saltam moedas dele — V21).
func _animate_gold(target: int) -> void:
	if _gold_tw != null and _gold_tw.is_valid():
		_gold_tw.kill()
	var from := _gold_shown
	if not _animated() or from == target:
		_set_gold_now(target)
		return
	if target < from:
		for k in mini(5, from - target):
			_pop_coin(k * 0.04)
	_gold_tw = create_tween()
	_gold_tw.tween_method(func(v: float): _set_gold_now(int(round(v))), float(from), float(target), clampf(0.04 * absi(target - from), 0.2, 0.6))

func _set_gold_now(g: int) -> void:
	_gold_shown = g
	gold_label.text = str(g)

func _pop_coin(delay: float) -> void:
	if _gold_icon == null or not is_inside_tree():
		return
	var c := CardIcon.new("coin", UiKit.COIN, 18.0)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.z_index = 30
	add_child(c)
	var p0 := _gold_icon.get_global_rect().get_center() - Vector2(9, 9)
	c.global_position = p0
	c.modulate.a = 0.0
	var tw := c.create_tween().set_parallel(true)
	tw.tween_property(c, "modulate:a", 1.0, 0.05).set_delay(delay)
	tw.tween_property(c, "global_position", p0 + Vector2(randf_range(-28, 28), randf_range(-46, -26)), 0.32).set_delay(delay).set_ease(Tween.EASE_OUT)
	tw.tween_property(c, "modulate:a", 0.0, 0.2).set_delay(delay + 0.2)
	tw.chain().tween_callback(c.queue_free)

# --- Juros (V26) ---

func _interest_text(due: int) -> void:
	var t := ""
	if due > 0:
		t = tr("Juros: +%d ouro (1 por cada 5 guardados, máx. %d).") % [due, GameState.interest_cap()]
	else:
		t = tr("Juros: 1 ouro por cada 5 guardados ao entrar na loja (máx. %d).") % GameState.interest_cap()
	var tax := int(GameState.relic_passive("shop_tax"))
	if tax > 0:
		t += "  ·  " + tr("Preços +%d (relíquia de boss).") % tax
	interest_label.text = t

## As moedas dos juros voam de baixo para o contador, que sobe uma a uma; por cima aparece «+N juros».
func _play_interest(due: int) -> void:
	if not _animated():
		_set_gold_now(GameState.gold)
		return
	await get_tree().create_timer(0.4).timeout
	if not is_inside_tree():
		return
	var to := _gold_icon.get_global_rect().get_center()
	var from := interest_label.get_global_rect().position + Vector2(40, 18)
	var n := mini(due, 6)
	var base := GameState.gold - due
	for k in n:
		var c := CardIcon.new("coin", UiKit.COIN, 22.0)
		c.mouse_filter = Control.MOUSE_FILTER_IGNORE
		c.z_index = 30
		add_child(c)
		var p0 := from + Vector2(randf_range(-20, 60), randf_range(-6, 6))
		var ctrl := p0.lerp(to, 0.5) + Vector2(0, -160)
		c.global_position = p0 - Vector2(11, 11)
		var step := int(round(float(due) * (k + 1) / n))
		var tw := c.create_tween()
		tw.tween_interval(0.08 * k)
		tw.tween_method(func(t: float):
			var a := p0.lerp(ctrl, t)
			var b := ctrl.lerp(to, t)
			c.global_position = a.lerp(b, t) - Vector2(11, 11), 0.0, 1.0, 0.5).set_ease(Tween.EASE_IN_OUT)
		tw.tween_callback(func():
			_set_gold_now(base + step)
			Sfx.blip(mini(20, 6 + k * 2))
			c.queue_free())
	await get_tree().create_timer(0.08 * n + 0.55).timeout
	if not is_inside_tree():
		return
	_set_gold_now(GameState.gold)
	var plus := UiKit.label(tr("+%d juros") % due, 19, Color(0.55, 0.95, 0.66))
	UiKit.outline_for(plus, Color(0.55, 0.95, 0.66), 4)
	plus.z_index = 45
	add_child(plus)
	# Por baixo do ouro (em cima ficava cortado pela borda do ecrã e tapado pelo MENU), a subir até ele.
	var gr := gold_box.get_global_rect()
	plus.reset_size()
	plus.global_position = Vector2(gr.position.x + (gr.size.x - plus.size.x) * 0.5, gr.end.y + 8.0)
	var t2 := plus.create_tween().set_parallel(true)
	t2.tween_property(plus, "position:y", plus.position.y - 8.0, 1.1).set_ease(Tween.EASE_OUT)
	t2.tween_property(plus, "modulate:a", 0.0, 0.5).set_delay(0.7)
	t2.chain().tween_callback(plus.queue_free)

# --- O mercador fala (V20) ---

func _merchant_key() -> String:
	return "blind_merchant" if merchant else "merchant"

func _say_later(moment: String, delay: float) -> void:
	if not _animated():
		return
	await get_tree().create_timer(delay).timeout
	if is_inside_tree():
		_say(moment)

## Uma frase do mercador num balão ao lado do retrato (some sozinha, não apanha toques).
func _say(moment: String) -> void:
	var lines: Array = (CardDB.shop_lines.get(_merchant_key(), {}) as Dictionary).get(moment, [])
	if lines.is_empty() or not is_inside_tree():
		return
	var text := tr(String(lines[randi() % lines.size()]))   # sem o rng da run: as frases não mexem nas ofertas
	if _bubble_tw != null and _bubble_tw.is_valid():
		_bubble_tw.kill()
	if _bubble != null and is_instance_valid(_bubble):
		if _bubble.get_parent() != null:
			_bubble.get_parent().remove_child(_bubble)   # sai já (o nome fica livre para o balão novo)
		_bubble.queue_free()
	var b := PanelContainer.new()
	b.name = "MerchantSays"
	b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.z_index = 20
	b.add_theme_stylebox_override("panel", UiKit.flat(Color(0.97, 0.94, 0.88), 14, Color(0.24, 0.15, 0.27), 3, 11))
	var l := UiKit.label(tr("«%s»") % text, 17, Color(0.14, 0.08, 0.16), true)
	l.custom_minimum_size.x = 300
	b.add_child(l)
	add_child(b)
	_bubble = b
	b.modulate.a = 0.0
	await get_tree().process_frame
	if not is_instance_valid(b):
		return
	b.reset_size()
	b.size.x = minf(b.size.x, 440.0)
	var fr := face.get_global_rect()
	b.global_position = Vector2(fr.end.x + 14.0, fr.position.y + fr.size.y * 0.62)
	var tail := Polygon2D.new()
	tail.color = Color(0.97, 0.94, 0.88)
	tail.polygon = PackedVector2Array([Vector2(2, 12), Vector2(-15, 4), Vector2(2, 26)])
	b.add_child(tail)
	b.pivot_offset = Vector2(0, 16)
	b.scale = Vector2(0.75, 0.75)
	_bubble_tw = create_tween()
	_bubble_tw.set_parallel(true)
	_bubble_tw.tween_property(b, "modulate:a", 1.0, 0.15)
	_bubble_tw.tween_property(b, "scale", Vector2.ONE, 0.22).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	_bubble_tw.chain().tween_interval(3.0)
	_bubble_tw.chain().tween_property(b, "modulate:a", 0.0, 0.3)
	_bubble_tw.chain().tween_callback(b.queue_free)

# --- Ofertas ---

func _roll_offers() -> void:
	_offer_relics.clear()
	_offer_pws.clear()
	_bought_cards.clear()
	_bought_relics.clear()
	_bought_keys.clear()
	if merchant:
		_offer_cards = []
		_offer_editions.clear()
		_offer_item = ""
		var legendary := CardDB.legendary_relics(GameState.relic_ids) if GameState.relics_allowed() else []
		for i in 2:
			if legendary.is_empty():
				break
			var pick: Dictionary = legendary[GameState.rng.randi_range(0, legendary.size() - 1)]
			legendary.erase(pick)
			_offer_relics.append(pick)
		var pws: Array = CardDB.planeswalkers.filter(func(p): return String(p.get("id", "")) != String(GameState.planeswalker.get("id", "")) and CardDB.is_planeswalker_available(p))
		for i in 2:
			if pws.is_empty():
				break
			var pick: Dictionary = pws[GameState.rng.randi_range(0, pws.size() - 1)]
			pws.erase(pick)
			_offer_pws.append(pick)
		return
	_offer_cards = CardDB.random_shop_offers(3 + int(GameState.voucher_value("shop_cards")), GameState.rng)
	_offer_editions.clear()
	for c in _offer_cards:
		_offer_editions.append(GameState.roll_edition(c))
	_offer_item = GameState.random_consumable()   # 0.13.0: uma poção ou pergaminho por visita
	if not GameState.relics_allowed():
		return
	var exclude: Array = GameState.relic_ids.duplicate()
	for i in 2:
		var r := CardDB.random_relic_offer(GameState.rng, exclude)
		if r.is_empty():
			break
		_offer_relics.append(r)
		exclude.append(String(r.get("id", "")))

func _build_offers(start_on_back: bool = false) -> void:
	_clear_confirm()
	UiKit.clear_children(cards_box)
	UiKit.clear_children(relics_box)
	_tiles.clear()
	_selected_tile = null
	for i in _offer_cards.size():
		var c: CardData = _offer_cards[i]
		var ed: String = _offer_editions[i] if i < _offer_editions.size() else ""
		Stats.mark_seen("cards", c.id, false)
		var card_price := _p(c.price + edition_price(ed))
		var why := CardDB.synergy_reason(c)
		var inst := CardDB.new_instance(c.id, {"id": c.id, "edition": ed} if ed != "" else {})
		var tile := ShopCardTile.new()
		tile.name = "Offer%d" % i
		tile.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		cards_box.add_child(tile)
		tile.setup(inst, card_price, "card:%d" % i, why)
		tile.set_meta("index", i)
		if why != "":
			tile.tooltip_text = tr("Combina com o teu baralho: %s") % why
		tile.tapped.connect(_on_tile_tapped)
		tile.buy_pressed.connect(_on_tile_buy)
		_tiles.append(tile)
		if tile.key in _bought_keys:
			tile.mark_bought(false)
		elif start_on_back:
			tile.start_on_back()
	if _offer_editions.any(func(e): return e != ""):
		_edition_tip()
	for p in _offer_pws:
		_add_pw_offer(p)
	for r in _offer_relics:
		_add_relic_offer(r)
	_add_item_offer()
	_add_constellation_offer()
	_add_voucher_offer()
	_build_owned()
	_refresh_offer_buttons()

## Linha de uma oferta (relíquia, patrono, poção, Constelação, Vale): imagem à esquerda, nome, linha pequena,
## texto e o preço à direita. Tocar compra (as caras com Confirmar compras pedem 2 toques).
func _offer_row(title: String, sub: String, body: String, price: int, media: Control, height: int = 84) -> Button:
	var btn := Button.new()
	btn.focus_mode = Control.FOCUS_NONE
	btn.custom_minimum_size = Vector2(0, height)
	btn.clip_contents = true
	btn.set_meta("haptic", true)
	for st in ["normal", "hover", "pressed", "disabled"]:
		var bg := ROW_BG
		if st == "hover":
			bg = ROW_BG.lightened(0.06)
		elif st == "pressed":
			bg = ROW_BG.lightened(0.14)
		elif st == "disabled":
			bg = Color(0.13, 0.11, 0.19, 0.88)
		btn.add_theme_stylebox_override(st, UiKit.flat(bg, 12, Color(0, 0, 0, 0), 0, 0))
	var row := HBoxContainer.new()
	row.name = "Content"
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 10)
	btn.add_child(row)
	row.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	row.offset_left = 10.0
	row.offset_right = -10.0
	row.offset_top = 4.0
	row.offset_bottom = -4.0
	if media != null:
		media.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		row.add_child(media)
	var col := VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_theme_constant_override("separation", 1)
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(col)
	var tl := UiKit.label(title, 16, Color.WHITE)
	tl.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	col.add_child(tl)
	if sub != "":
		var sl := UiKit.label(sub, 12, Color(0.74, 0.71, 0.84))
		sl.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		col.add_child(sl)
	var bl := UiKit.label(body, 13, BODY_COLOR, true)
	# As linhas que cabem na altura da fila; a última acaba em «…» quando o texto não cabe (o texto todo fica na dica).
	var used := 16.0 * 1.25 + 1.0 + ((12.0 * 1.25 + 1.0) if sub != "" else 0.0)
	var max_lines := clampi(int((float(height) - 8.0 - used) / (13.0 * 1.25)), 1, 4)
	bl.max_lines_visible = max_lines
	bl.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	bl.set_meta("max_lines", max_lines)
	bl.resized.connect(_fit_body.bind(bl))
	col.add_child(bl)
	var pr := UiKit.price(price, true, 18)
	pr.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(pr)
	btn.set_meta("price", price)
	btn.set_meta("body", bl)
	btn.set_meta("price_row", pr)
	btn.set_meta("content", row)
	btn.tooltip_text = title + ": " + body
	return btn

## Com «…» no fim, o Label com várias linhas deixa de pedir altura: dá-se-lhe a das linhas que o texto ocupa
## nesta largura (até max_lines). Corre quando a fila muda de tamanho e quando o texto muda (confirmar a compra).
func _fit_body(l: Label) -> void:
	if not is_instance_valid(l):
		return
	var f := l.get_theme_font("font")
	var fs := l.get_theme_font_size("font_size")
	var w := l.size.x
	if f == null or w <= 4.0:
		return
	var lh := f.get_height(fs)
	var h := f.get_multiline_string_size(l.text, HORIZONTAL_ALIGNMENT_LEFT, w, fs).y
	var n := clampi(int(ceil(h / lh - 0.05)), 1, int(l.get_meta("max_lines", 2)))
	var want := ceilf(n * lh + l.get_theme_constant("line_spacing") * (n - 1))
	if absf(l.custom_minimum_size.y - want) > 0.5:
		l.custom_minimum_size.y = want

## Imagem redonda com aro (poções, retratos dos patronos, a Constelação).
func _round_media(tex: Texture2D, ring: Color, px: float, icon_kind: String = "", fill: Color = Color(0.1, 0.08, 0.16)) -> Control:
	var m := Control.new()
	m.custom_minimum_size = Vector2(px, px)
	m.mouse_filter = Control.MOUSE_FILTER_IGNORE
	m.draw.connect(func():
		var c := m.size * 0.5
		var r := minf(m.size.x, m.size.y) * 0.5
		m.draw_circle(c, r, fill)
		if tex != null:
			ArtLib.draw_round(m, tex, c, r - 2.0)
		var st := StyleBoxFlat.new()
		st.draw_center = false
		st.set_border_width_all(3)
		st.border_color = ring
		st.set_corner_radius_all(int(r))
		m.draw_style_box(st, Rect2(Vector2.ZERO, m.size)))
	if icon_kind != "":
		var ic := CardIcon.new(icon_kind, ring.lightened(0.45), px * 0.5)
		m.add_child(ic)
		ic.set_anchors_preset(Control.PRESET_CENTER)
		ic.offset_left = -px * 0.25
		ic.offset_right = px * 0.25
		ic.offset_top = -px * 0.25
		ic.offset_bottom = px * 0.25
	return m

func _relic_media(id: String, px: float) -> RelicView:
	var rv := RelicView.new()
	rv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rv.custom_minimum_size = Vector2(px, px)
	rv.setup(id)
	return rv

func _add_pw_offer(p: Dictionary) -> void:
	Stats.mark_seen("planeswalkers", String(p.get("id", "")), false)
	var price := _p(int(p.get("price", 10)))
	var skill_txt: Array[String] = []
	for sk in p.get("skills", []):
		skill_txt.append(tr(String(sk.get("text", ""))))
	var col: Color = CardView.COLORS.get(String(p.get("color", "colorless")), UiKit.GOLD)
	var media := _round_media(ArtLib.texture("portrait", String(p.get("id", ""))), col, 62.0)
	var btn := _offer_row(tr(String(p.get("name", ""))), tr("Patrono"), "  ".join(PackedStringArray(skill_txt)), price, media, 104)
	btn.set_meta("kind", "pw")
	var key := "pw:" + String(p.get("id", ""))
	btn.pressed.connect(func():
		if not _confirm(btn, price):
			return
		var snap := _snap()
		if GameState.spend_gold(price):
			GameState.set_planeswalker(String(p.get("id", "")))
			_bought_keys.append(key)
			Sfx.boom()
			_mark_bought(btn)
			_note(tr("%s junta-se a ti. A lealdade sobe ao jogar cartas da cor dele/dela.") % tr(String(p.get("name", ""))))
			_say("rare")
			_commit_undo(snap, tr("a compra de %s") % tr(String(p.get("name", "")))))
	cards_box.add_child(btn)
	if key in _bought_keys:
		_mark_bought(btn, false)

func _add_relic_offer(r: Dictionary) -> void:
	var rid := String(r.get("id", ""))
	Stats.mark_seen("relics", rid, false)
	var price := _p(int(r.get("price", 5)))
	var rarity_txt := tr("Lendária") if bool(r.get("legendary", false)) else tr(CardZoom.RARITY_NAMES.get(String(r.get("rarity", "common")), "Comum"))
	var sub := rarity_txt
	var rs := CardDB.relic_set_of(rid)   # 0.13.0: conjuntos de relíquias
	if not rs.is_empty():
		var have := 0
		for m in rs.get("relics", []):
			if String(m) in GameState.relic_ids:
				have += 1
		sub += "  ·  " + tr("Conjunto: %s (%d/%d)") % [tr(String(rs.get("name", ""))), have, (rs.get("relics", []) as Array).size()]
	var btn := _offer_row(tr(String(r.get("name", rid))), sub, tr(String(r.get("text", ""))), price, _relic_media(rid, 56.0), 78)
	btn.set_meta("kind", "relic")
	btn.set_meta("relic", rid)
	var key := "relic:" + rid
	btn.pressed.connect(func():
		if GameState.relic_ids.size() >= GameState.max_relics():
			_note(tr("Já tens %d relíquias: vende uma primeiro.") % GameState.max_relics())
			return
		if not _confirm(btn, price):
			return
		var snap := _snap()
		if GameState.spend_gold(price):
			GameState.add_relic(rid)
			_bought_relics.append(rid)
			_bought_keys.append(key)
			if GameState.stake >= 5:
				GameState.relic_locked.append(rid)
			Sfx.select()
			Settings.vibrate(18)
			_mark_bought(btn)
			_build_owned()
			_fly_to_slot(btn, rid)
			if bool(r.get("legendary", false)) or String(r.get("rarity", "")) == "rare":
				_say("rare")
			_commit_undo(snap, tr("a compra de %s") % tr(String(r.get("name", rid)))))
	relics_box.add_child(btn)
	if key in _bought_keys:
		_mark_bought(btn, false)

## Preço com a taxa das relíquias de boss (Cálice do Abismo: +2 em tudo).
func _p(base: int) -> int:
	return GameState.shop_price(base)

## 0.13.0: ouro a mais por uma carta com edição.
static func edition_price(ed: String) -> int:
	return int(EffectResolver.EDITIONS[ed]["price"]) if EffectResolver.EDITIONS.has(ed) else 0

## Compra cara: 10+ ouro, ou 5+ quando é metade (ou mais) do que tens.
static func is_expensive(price: int, gold: int) -> bool:
	return price >= CONFIRM_PRICE or (price >= CONFIRM_HALF_MIN and price * 2 >= gold)

## 0.13.0 (Confirmar compras caras): o 1.º toque numa compra cara só avisa (no texto da linha); o 2.º (em 3 s)
## compra. As cartas já pedem dois toques (escolher e COMPRAR) e não passam por aqui.
func _confirm(btn: Button, price: int) -> bool:
	if not Settings.confirm_buy or GameState.gold < price or not is_expensive(price, GameState.gold):
		return true
	if _confirm_btn == btn and is_instance_valid(btn):
		_clear_confirm()
		return true
	_clear_confirm()
	_confirm_btn = btn
	var bl: Label = btn.get_meta("body", null)
	if bl != null:
		_confirm_text = bl.text
		bl.text = tr("Toca outra vez para comprar por %d ouro.") % price
		bl.add_theme_color_override("font_color", UiKit.GOLD)
		_fit_body(bl)
	Sfx.select()
	_confirm_token += 1
	var tok := _confirm_token
	create_tween().tween_callback(func():
		if tok == _confirm_token:
			_clear_confirm()).set_delay(CONFIRM_TIME)
	return false

func _clear_confirm() -> void:
	if _confirm_btn != null and is_instance_valid(_confirm_btn):
		var bl: Label = _confirm_btn.get_meta("body", null)
		if bl != null and _confirm_text != "":
			bl.text = _confirm_text
			bl.add_theme_color_override("font_color", BODY_COLOR)
			_fit_body(bl)
	_confirm_btn = null
	_confirm_text = ""

## Texto de uma oferta (para os testes e para o aviso das compras caras).
static func row_text(btn: Button) -> String:
	var bl: Label = btn.get_meta("body", null)
	return bl.text if bl != null else btn.text

## Dica das edições (a 1.ª vez que aparece uma carta com edição).
func _edition_tip() -> void:
	if Settings.tips_enabled and not GameState.tip_seen("edition") and CardDB.tips.has("edition"):
		GameState.mark_tip_seen("edition")
		SceneRouter.toast(tr("Dica: ") + tr(String(CardDB.tips["edition"])), 7.0)

## Preço dos serviços (o Vale do Artesão baixa-os; nunca menos de 1).
func _svc(base: int) -> int:
	return _p(maxi(1, base - int(GameState.voucher_value("service_discount"))))

func _reroll_price() -> int:
	if rerolls == 0 and GameState.talent_value("free_reroll") > 0.0:
		return 0   # talento Sorte do Apostador (0.12.0)
	return _p(maxi(0, REROLL_BASE + rerolls - int(GameState.voucher_value("reroll_discount"))))

## 0.13.0: uma poção ou pergaminho por visita (até 2 contigo; usam-se na batalha ou no mapa).
func _add_item_offer() -> void:
	if _offer_item == "":
		return
	var def := CardDB.get_consumable(_offer_item)
	var price := _p(int(def.get("price", 4)))
	var col := Color(String(def.get("color", "#ffffff")))
	var art := ArtLib.texture("item", _offer_item)
	var media := _round_media(art, UiKit.GOLD, 48.0, "" if art != null else String(def.get("kind", "potion")))
	var use_txt := tr("Usa-se no mapa.") if String(def.get("use", "battle")) == "map" else tr("Usa-se na batalha.")
	var btn := _offer_row(tr(String(def.get("name", ""))), use_txt, tr(String(def.get("text", ""))), price, media, 78)
	btn.name = "ItemOffer"
	btn.set_meta("kind", "item")
	(btn.get_meta("body") as Label).add_theme_color_override("font_color", col.lerp(Color.WHITE, 0.55))
	btn.pressed.connect(func():
		if not GameState.can_add_consumable():
			_note(tr("Já tens %d poções/pergaminhos: usa um primeiro.") % GameState.consumable_slots())
			return
		if not _confirm(btn, price):
			return
		var snap := _snap()
		if GameState.spend_gold(price) and GameState.add_consumable(_offer_item):
			_bought_keys.append("item")
			Sfx.select()
			Settings.vibrate(18)
			_mark_bought(btn)
			_note(tr("Recebes: %s.") % tr(String(def.get("name", "")))
				+ "  " + (tr("Usa-o no mapa.") if String(def.get("use", "battle")) == "map" else tr("Usa-o na batalha (barra de cima).")))
			_build_owned()
			_commit_undo(snap, tr("a compra de %s") % tr(String(def.get("name", "")))))
	relics_box.add_child(btn)
	if "item" in _bought_keys:
		_mark_bought(btn, false)

## Um Vale por visita: melhoria que fica para o resto da run. V16: um bilhete dourado, com o canhoto à esquerda
## e «VALE» escrito na vertical (assim cabe também em inglês).
func _add_voucher_offer() -> void:
	if _voucher == "":
		return
	if Settings.tips_enabled and not GameState.tip_seen("voucher") and CardDB.tips.has("voucher"):
		GameState.mark_tip_seen("voucher")
		SceneRouter.toast(tr("Dica: ") + tr(String(CardDB.tips["voucher"])), 6.0)
	var v := CardDB.get_voucher(_voucher)
	var price := _p(int(v.get("price", 10)))
	var owned := _voucher in GameState.vouchers
	var stub := Control.new()
	stub.name = "Stub"
	stub.custom_minimum_size = Vector2(34, 50)
	stub.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stub.draw.connect(_draw_ticket_stub.bind(stub))
	var btn := _offer_row(tr(String(v.get("name", ""))), "", tr(String(v.get("text", ""))), price, stub, 64)
	btn.name = "VoucherOffer"
	btn.set_meta("kind", "voucher")
	var ticket := Color(0.86, 0.68, 0.3)
	for st in ["normal", "hover", "pressed", "disabled"]:
		var bg := ticket if st == "normal" else (ticket.lightened(0.08) if st != "disabled" else ticket.darkened(0.35))
		btn.add_theme_stylebox_override(st, UiKit.flat(bg, 12, Color(0, 0, 0, 0), 0, 0))
	var row: HBoxContainer = btn.get_meta("content")
	for l in row.find_children("*", "Label", true, false):
		(l as Label).add_theme_color_override("font_color", Color(0.17, 0.09, 0.02))
	# Os dois recortes do bilhete (meias-luas da cor do fundo da coluna).
	var cuts := Control.new()
	cuts.mouse_filter = Control.MOUSE_FILTER_IGNORE
	btn.add_child(cuts)
	cuts.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	cuts.draw.connect(func():
		var bgc := Color(0.09, 0.075, 0.14)
		cuts.draw_circle(Vector2(0, cuts.size.y * 0.5), 8.0, bgc)
		cuts.draw_circle(Vector2(cuts.size.x, cuts.size.y * 0.5), 8.0, bgc))
	if owned:
		_mark_bought(btn, false)
	btn.pressed.connect(func():
		if not _confirm(btn, price):
			return
		var snap := _snap()
		if GameState.buy_voucher(_voucher):
			Sfx.boom()
			Settings.vibrate(18)
			_mark_bought(btn)
			_note(tr("Vale ativo até ao fim da run: %s") % tr(String(v.get("text", ""))))
			_build_owned()
			_refresh_services()
			_refresh_offer_buttons()
			_commit_undo(snap, tr("a compra de %s") % (tr("Vale: %s") % tr(String(v.get("name", ""))))))
	relics_box.add_child(btn)

const STUB_FONT := preload("res://assets/fonts/Lora-Bold.ttf")

func _draw_ticket_stub(stub: Control) -> void:
	var s := stub.size
	var dark := Color(0.24, 0.13, 0.03)
	for k in 6:
		var y := 4.0 + (s.y - 8.0) * k / 5.0
		stub.draw_rect(Rect2(Vector2(s.x - 2.0, y - 2.0), Vector2(2.0, 4.0)), Color(dark, 0.5))
	var font: Font = STUB_FONT
	var txt := tr("VALE")
	var fs := 16
	while fs > 9 and font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x > s.y - 6.0:
		fs -= 1
	var tw := font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
	stub.draw_set_transform(Vector2(s.x * 0.5 - 1.0, s.y * 0.5), -PI / 2.0, Vector2.ONE)
	stub.draw_string(font, Vector2(-tw * 0.5, font.get_ascent(fs) * 0.36), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, dark)
	stub.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

## Oferta comprada (V22): fica apagada, com o carimbo VENDIDO, e de fora das atualizações de preço.
func _mark_bought(btn: Button, animate: bool = true) -> void:
	btn.disabled = true
	btn.set_meta("bought", true)
	var row = btn.get_meta("content", null)
	if row is Control:
		(row as Control).modulate = Color(1, 1, 1, 0.55)
	SoldStamp.stamp(btn, false, animate)

func _refresh_offer_buttons() -> void:
	for t in _tiles:
		if is_instance_valid(t) and not t.bought:
			t.set_affordable(GameState.gold >= t.price)
	for btn in cards_box.get_children() + relics_box.get_children():
		if not (btn is Button) or bool(btn.get_meta("bought", false)):
			continue
		var price: int = btn.get_meta("price", 0)
		var full: bool = (btn.get_meta("kind", "") == "relic" and GameState.relic_ids.size() >= GameState.max_relics()) \
			or (btn.get_meta("kind", "") == "item" and not GameState.can_add_consumable())
		btn.disabled = GameState.gold < price or full
		var pr = btn.get_meta("price_row", null)
		if pr is Control:
			UiKit.set_price(pr, price, GameState.gold >= price)
	var bp := _p(BOOSTER_PRICE)
	if booster_this_visit:
		_set_svc(booster_btn, tr("Booster aberto"), -1, true)
	else:
		_set_svc(booster_btn, tr("Booster · 1 de 3"), bp, false)
	booster_btn.disabled = booster_this_visit or GameState.gold < bp
	var reroll_price := _reroll_price()
	_set_svc(reroll_btn, tr("Novas ofertas"), reroll_price, false)
	reroll_btn.disabled = GameState.gold < reroll_price or _busy_reroll

# --- Cartas (V14, V21) ---

func _on_tile_tapped(tile: ShopCardTile) -> void:
	if tile.bought or SceneRouter.has_overlay() or _busy_reroll:
		return
	Sfx.select()
	if _selected_tile == tile:
		tile.set_selected(false)
		_selected_tile = null
		return
	if _selected_tile != null and is_instance_valid(_selected_tile):
		_selected_tile.set_selected(false)
	_selected_tile = tile
	tile.set_selected(true)

func _on_tile_buy(tile: ShopCardTile) -> void:
	_buy_tile(tile)

## Compra a carta de uma oferta (também usado pelos testes). Devolve true se comprou.
func _buy_tile(tile: ShopCardTile) -> bool:
	if tile == null or tile.bought or SceneRouter.has_overlay():
		return false
	var c := tile.card
	var ed := c.edition()
	var snap := _snap()
	if not GameState.spend_gold(tile.price):
		Sfx.deny()
		return false
	GameState.add_card(c.data.id, false, ed)
	_bought_cards.append(c.data.id)
	_bought_keys.append(tile.key)
	if ed != "":
		Sfx.boom()
		_note(tr("%s (%s) juntou-se ao baralho.") % [tr(c.data.name), EffectResolver.edition_name(ed)])
	else:
		Sfx.select()
	Settings.vibrate(18)
	_fly_card_to_deck(tile)
	tile.mark_bought()
	if _selected_tile == tile:
		_selected_tile = null
	if ed != "" or String(c.data.rarity) in ["rare", "mythic"]:
		_say("rare")
	_commit_undo(snap, tr("a compra de %s") % tr(c.data.name))
	return true

## V21: a carta comprada voa (a encolher) até ao VER BARALHO.
func _fly_card_to_deck(tile: ShopCardTile) -> void:
	if not _animated() or tile.view == null:
		return
	var from := tile.view.get_global_rect()
	var to := deck_btn.get_global_rect()
	var ghost: CardView = ShopCardTile.CARD_VIEW.instantiate()
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.z_index = 40
	add_child(ghost)
	ghost.setup(tile.card)
	ghost.size = from.size
	ghost.global_position = from.position
	ghost.pivot_offset = from.size * 0.5
	var tw := ghost.create_tween().set_parallel(true)
	var dest := to.get_center() - from.size * 0.5
	tw.tween_property(ghost, "global_position", dest, 0.45).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
	tw.tween_property(ghost, "scale", Vector2(0.22, 0.22), 0.45).set_ease(Tween.EASE_IN)
	tw.tween_property(ghost, "rotation", -0.25, 0.45)
	tw.tween_property(ghost, "modulate:a", 0.0, 0.15).set_delay(0.32)
	tw.chain().tween_callback(ghost.queue_free)

## A relíquia comprada voa (o medalhão) até à sua ranhura.
func _fly_to_slot(btn: Button, rid: String) -> void:
	if not _animated():
		return
	var slot: Control = null
	for s in owned_box.get_children():
		if String(s.get_meta("relic", "")) == rid:
			slot = s
	if slot == null:
		return
	await get_tree().process_frame
	if not is_instance_valid(slot) or not is_instance_valid(btn):
		return
	var rv := _relic_media(rid, 58.0)
	rv.z_index = 40
	add_child(rv)
	var from := btn.get_global_rect()
	rv.size = Vector2(58, 58)
	rv.global_position = from.position + Vector2(10, (from.size.y - 58.0) * 0.5)
	var to := slot.get_global_rect()
	slot.modulate.a = 0.0
	var tw := rv.create_tween().set_parallel(true)
	tw.tween_property(rv, "global_position", to.position - Vector2(6, 6), 0.45).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_QUAD)
	tw.tween_property(rv, "scale", Vector2(to.size.x / 58.0, to.size.y / 58.0), 0.45)
	tw.chain().tween_callback(func():
		if is_instance_valid(slot):
			slot.modulate.a = 1.0
		rv.queue_free())

# --- As tuas relíquias em ranhuras (V25) ---

func _build_owned() -> void:
	UiKit.clear_children(owned_box)
	var t := tr("As tuas relíquias (%d/%d)") % [GameState.relic_ids.size(), GameState.max_relics()]
	if not GameState.boss_relics.is_empty():
		t += "  ·  " + tr("de boss: %d") % GameState.boss_relics.size()
	if not GameState.vouchers.is_empty():
		t += "  ·  " + tr("Vales: %d") % GameState.vouchers.size()
	t += "  ·  " + tr("Poções %d/%d") % [GameState.consumables.size(), GameState.consumable_slots()]
	owned_title.text = t
	for i in GameState.max_relics():
		if i < GameState.relic_ids.size():
			var id := GameState.relic_ids[i]
			var rv := RelicView.new()
			rv.name = "Owned_" + id
			rv.custom_minimum_size = Vector2(SLOT, SLOT)
			rv.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			owned_box.add_child(rv)
			rv.setup(id)
			rv.set_meta("relic", id)
			rv.set_meta("locked", id in GameState.relic_locked)
			rv.pressed.connect(_open_owned)
		else:
			owned_box.add_child(_empty_slot(SLOT, ""))
	# Relíquias de boss: não se vendem nem ocupam lugar.
	if not GameState.boss_relics.is_empty():
		owned_box.add_child(_slot_sep())
		for id in GameState.boss_relics:
			var bv := RelicView.new()
			bv.name = "Boss_" + id
			bv.custom_minimum_size = Vector2(SLOT, SLOT)
			bv.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			owned_box.add_child(bv)
			bv.setup(id)
			bv.set_meta("boss", id)
			bv.pressed.connect(func(rid: String):
				if not SceneRouter.has_overlay():
					Sfx.select()
					CardZoom.show_relic(rid))
	# As poções e os pergaminhos (lugares vazios com o frasco apagado).
	owned_box.add_child(_slot_sep())
	for i in GameState.consumable_slots():
		if i < GameState.consumables.size():
			var cid := GameState.consumables[i]
			var cdef := CardDB.get_consumable(cid)
			var art := ArtLib.texture("item", cid)
			var m := _round_media(art, UiKit.GOLD, 38.0, "" if art != null else String(cdef.get("kind", "potion")))
			m.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			m.tooltip_text = tr(String(cdef.get("name", cid))) + ": " + tr(String(cdef.get("text", "")))
			m.mouse_filter = Control.MOUSE_FILTER_PASS
			owned_box.add_child(m)
		else:
			owned_box.add_child(_empty_slot(38.0, "potion"))

func _empty_slot(px: float, icon_kind: String) -> Control:
	var s := Control.new()
	s.custom_minimum_size = Vector2(px, px)
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	s.mouse_filter = Control.MOUSE_FILTER_IGNORE
	s.draw.connect(func():
		var c := s.size * 0.5
		var r := minf(s.size.x, s.size.y) * 0.5 - 1.5
		for k in 12:
			var a0 := TAU * k / 12.0
			var p0 := c + Vector2(cos(a0), sin(a0)) * r
			var p1 := c + Vector2(cos(a0 + TAU / 24.0), sin(a0 + TAU / 24.0)) * r
			s.draw_line(p0, p1, Color(1, 1, 1, 0.3), 2.0))
	if icon_kind != "":
		var ic := CardIcon.new(icon_kind, Color(1, 1, 1, 0.28), px * 0.5)
		s.add_child(ic)
		ic.set_anchors_preset(Control.PRESET_CENTER)
		ic.offset_left = -px * 0.25
		ic.offset_right = px * 0.25
		ic.offset_top = -px * 0.25
		ic.offset_bottom = px * 0.25
	return s

func _slot_sep() -> Control:
	var s := ColorRect.new()
	s.color = Color(1, 1, 1, 0.14)
	s.custom_minimum_size = Vector2(2, 30)
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	s.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return s

## Tocar numa das tuas relíquias: a janela dela, com VENDER (ou NÃO SE VENDE, com a Marca Eterna).
func _open_owned(id: String) -> void:
	if SceneRouter.has_overlay() or not (id in GameState.relic_ids):
		return
	Sfx.select()
	var locked := id in GameState.relic_locked
	CardZoom.show_relic(id, [{
		"text": tr("NÃO SE VENDE") if locked else tr("VENDER"),
		"price": -1 if locked else GameState.relic_sell_price(id),
		"enabled": not locked,
		"tooltip": tr("Marca Eterna: as relíquias compradas na loja não se vendem.") if locked else "",
		"call": _sell_relic.bind(id),
	}])

## Vende uma relíquia tua (também usado pelos testes).
func _sell_relic(id: String) -> void:
	if not (id in GameState.relic_ids) or id in GameState.relic_locked:
		return
	var r: Dictionary = CardDB.relics.get(id, {})
	var snap := _snap()
	GameState.add_gold(GameState.relic_sell_price(id))
	GameState.remove_relic(id)   # o ouro que entra já toca a moeda
	_did_something = true
	_build_owned()
	_refresh_offer_buttons()
	_commit_undo(snap, tr("a venda de %s") % tr(String(r.get("name", id))))

# --- Serviços ---

func _refresh_services() -> void:
	var price := _svc(GameState.removal_price())
	if removed_this_visit:
		_set_svc(remove_btn, tr("Carta removida"), -1, true)
		remove_btn.disabled = true
	else:
		_set_svc(remove_btn, tr("Remover uma carta"), price, false)
		remove_btn.disabled = GameState.gold < price or GameState.deck.size() <= 6
	_set_svc(heal_btn, tr("Curar %d") % HEAL_AMOUNT, _svc(HEAL_PRICE), false)
	heal_btn.disabled = GameState.gold < _svc(HEAL_PRICE) or GameState.player_hp >= GameState.player_max_hp
	if max_hp_this_visit:
		_set_svc(max_hp_btn, tr("Vida máxima +%d") % MAX_HP_AMOUNT, -1, true)
		max_hp_btn.disabled = true
	else:
		_set_svc(max_hp_btn, tr("Vida máxima +%d") % MAX_HP_AMOUNT, _svc(MAX_HP_PRICE), false)
		max_hp_btn.disabled = GameState.gold < _svc(MAX_HP_PRICE)
	if upgraded_this_visit:
		_set_svc(upgrade_btn, tr("Carta melhorada"), -1, true)
		upgrade_btn.disabled = true
	else:
		_set_svc(upgrade_btn, tr("Melhorar uma carta"), _svc(UPGRADE_PRICE), false)
		upgrade_btn.disabled = GameState.gold < _svc(UPGRADE_PRICE)
	if sealed_this_visit:
		_set_svc(seal_btn, tr("Carta selada"), -1, true)
		seal_btn.disabled = true
	else:
		_set_svc(seal_btn, tr("Selar uma carta"), _svc(SEAL_PRICE), false)
		seal_btn.disabled = GameState.gold < _svc(SEAL_PRICE)
	_set_svc(deck_btn, tr("Ver baralho"), -1, false)
	if note_label.text == "":
		note_label.text = tr("Melhorar: +%d Poder permanente (criaturas e feitiços com Poder) ou +%s Mult (as outras). Vida máxima e melhoria: uma vez por visita.") % [UPGRADE_POWER, Cascade.fmt_mult(UPGRADE_MULT)]

func _note(text: String) -> void:
	note_label.text = text

func _on_heal() -> void:
	var snap := _snap()
	if GameState.player_hp >= GameState.player_max_hp or not GameState.spend_gold(_svc(HEAL_PRICE)):
		return
	GameState.heal(HEAL_AMOUNT)
	Sfx.heal()
	_refresh_services()
	_commit_undo(snap, tr("a cura"))

func _on_max_hp() -> void:
	var snap := _snap()
	if max_hp_this_visit or not GameState.spend_gold(_svc(MAX_HP_PRICE)):
		return
	max_hp_this_visit = true
	GameState.change_max_hp(MAX_HP_AMOUNT)
	GameState.heal(MAX_HP_AMOUNT)
	Sfx.heal()
	_refresh_services()
	_commit_undo(snap, tr("a vida máxima"))

func _on_upgrade() -> void:
	if upgraded_this_visit or GameState.gold < _svc(UPGRADE_PRICE) or SceneRouter.has_overlay():
		return
	Sfx.select()
	ZoneViewer.open_deck(tr("MELHORAR — escolhe a carta"), func(card: CardInstance):
		var snap := _snap()
		if upgraded_this_visit or card.entry_index < 0 or not GameState.spend_gold(_svc(UPGRADE_PRICE)):
			return
		upgraded_this_visit = true
		var entry: Dictionary = GameState.deck[card.entry_index]
		if card.data.is_creature() or card.data.power > 0:
			entry["power_bonus"] = int(entry.get("power_bonus", 0)) + UPGRADE_POWER
			_note(tr("%s: +%d Poder permanente.") % [tr(card.data.name), UPGRADE_POWER])
		else:
			entry["mult_bonus"] = float(entry.get("mult_bonus", 0.0)) + UPGRADE_MULT
			_note(tr("%s: +%s Mult permanente.") % [tr(card.data.name), Cascade.fmt_mult(UPGRADE_MULT)])
		Sfx.boom()
		_refresh_services()
		_commit_undo(snap, tr("a melhoria de %s") % tr(card.data.name)))

## Selo de guilda: escolhe o selo e depois a carta (uma carta só tem um selo; selar outra vez substitui).
func _on_seal() -> void:
	if sealed_this_visit or GameState.gold < _svc(SEAL_PRICE) or SceneRouter.has_overlay():
		return
	Sfx.select()
	var picker := SealPicker.open(func(seal_id: String):
		ZoneViewer.open_deck(tr("SELAR — escolhe a carta"), func(card: CardInstance):
			var snap := _snap()
			if sealed_this_visit or card.entry_index < 0 or not GameState.spend_gold(_svc(SEAL_PRICE)):
				return
			sealed_this_visit = true
			GameState.deck[card.entry_index]["seal"] = seal_id
			_note(tr("%s recebeu o %s.") % [tr(card.data.name), tr(String(CardDB.get_seal(seal_id).get("name", seal_id)))])
			Sfx.boom()
			_refresh_services()
			_commit_undo(snap, tr("o selo de %s") % tr(card.data.name))))
	if picker == null:
		return

func _on_remove() -> void:
	if removed_this_visit or GameState.gold < _svc(GameState.removal_price()) or SceneRouter.has_overlay():
		return
	Sfx.select()
	ZoneViewer.open_deck(tr("REMOVER — escolhe a carta"), func(card: CardInstance):
		if removed_this_visit or card.entry_index < 0 or GameState.deck.size() <= 6:
			return
		var snap := _snap()
		if not GameState.spend_gold(_svc(GameState.removal_price())):
			return
		GameState.deck.remove_at(card.entry_index)
		removed_this_visit = true
		_note(tr("%s removida do baralho.") % tr(card.data.name))
		Sfx.hit()
		_refresh_services()
		_commit_undo(snap, tr("a remoção de %s") % tr(card.data.name)))

## V24: o booster abre-se (pacote a rasgar, 3 cartas a virar). As cartas desta visita ficam escolhidas na 1.ª
## vez que se abre (fechar e voltar a abrir mostra as mesmas); o ouro só sai quando escolhes uma.
func _on_booster() -> void:
	if booster_this_visit or GameState.gold < _p(BOOSTER_PRICE) or SceneRouter.has_overlay():
		return
	Sfx.select()
	if _booster_cards.is_empty():
		var pool := CardDB.shop_pool()
		for i in 3:
			if pool.is_empty():
				break
			var pick := pool[GameState.rng.randi_range(0, pool.size() - 1)]
			pool.erase(pick)
			_booster_cards.append({"id": pick.id, "edition": GameState.roll_edition(pick)})   # 0.13.0: edições sem custo a mais
		_save_state()
	var snap := _snap()
	var cards: Array[CardInstance] = []
	for e in _booster_cards:
		var ed := String(e.get("edition", ""))
		cards.append(CardDB.new_instance(String(e["id"]), {"id": String(e["id"]), "edition": ed} if ed != "" else {}))
		if ed != "":
			_edition_tip()
	BoosterOpen.open(cards, func(card: CardInstance):
		if booster_this_visit or not GameState.spend_gold(_p(BOOSTER_PRICE)):
			return
		booster_this_visit = true
		var infected := GameState.stake >= 6 and GameState.rng.randf() < INFECTION_CHANCE
		var ed := card.edition()
		GameState.add_card(card.data.id, infected, ed)
		var nm := tr(card.data.name) + ((" (%s)" % EffectResolver.edition_name(ed)) if ed != "" else "")
		if infected:
			_note(tr("%s juntou-se ao baralho — INFETADA: Poder a dobrar, exila-se ao fim de %d utilizações.") % [nm, BattleManager.INFECTED_USES])
		else:
			_note(tr("%s juntou-se ao baralho.") % nm)
		Sfx.boom()
		Settings.vibrate(18)
		if ed != "" or String(card.data.rarity) in ["rare", "mythic"]:
			_say("rare")
		_refresh_offer_buttons()
		_commit_undo(snap, tr("o booster (%s)") % nm), tr("BOOSTER — escolhe 1 de 3"))

## V23: as cartas viram-se para as tuas costas e voltam com as ofertas novas.
func _on_reroll() -> void:
	if _busy_reroll or SceneRouter.has_overlay():
		return
	var price := _reroll_price()
	if not GameState.spend_gold(price):
		return
	rerolls += 1
	Sfx.shuffle()
	_did_something = true
	_undo = {}   # 0.15.0: as ofertas mudaram — o que havia para desfazer fica para trás
	_refresh_undo()
	if rerolls == 1 or randi() % 3 == 0:
		_say("reroll")
	if _animated() and not _tiles.is_empty():
		_busy_reroll = true
		_refresh_offer_buttons()
		for k in _tiles.size():
			var t := _tiles[k]
			if is_instance_valid(t) and not t.bought:
				t.flip(true, 0.1)
			await get_tree().create_timer(0.04).timeout
		await get_tree().create_timer(0.3).timeout
		if not is_inside_tree():
			return
		_roll_offers()
		_build_offers(true)
		await get_tree().create_timer(0.08).timeout
		for k in _tiles.size():
			var t := _tiles[k]
			if is_instance_valid(t):
				t.flip(false, 0.11)
			await get_tree().create_timer(0.07).timeout
		_busy_reroll = false
	else:
		_roll_offers()
		_build_offers()
	_refresh_offer_buttons()
	_save_state()

# --- 0.15.0: Constelação e DESFAZER ---

## Constelação: sobe 1 nível a uma formação à escolha (uma por visita, fora do Mercador Cego). Tocar abre a
## escolha; o ouro só sai quando se escolhe a formação (cancelar não custa nada).
func _add_constellation_offer() -> void:
	if merchant or CardDB.formations.is_empty():
		return
	var price := _p(CONSTELLATION_PRICE)
	var media := _round_media(null, Color(0.56, 0.69, 1.0), 42.0, "star", Color(0.1, 0.12, 0.26))
	var btn := _offer_row(tr("Constelação"), "", tr("Sobe 1 nível a uma formação à tua escolha."), price, media, 66)
	btn.tooltip_text = tr("Sobe 1 nível a uma formação à tua escolha: mais Mult sempre que a fizeres, até ao fim da run.")
	btn.name = "ConstellationOffer"
	btn.set_meta("kind", "constellation")
	btn.pressed.connect(func():
		if SceneRouter.has_overlay() or bool(btn.get_meta("bought", false)) or GameState.gold < price:
			return
		_clear_confirm()
		Sfx.select()
		FormationPicker.open(func(fid: String): _buy_constellation(btn, fid, price)))
	relics_box.add_child(btn)
	if "constellation" in _bought_keys:
		_mark_bought(btn, false)

func _buy_constellation(btn: Button, fid: String, price: int) -> void:
	if not is_instance_valid(btn) or bool(btn.get_meta("bought", false)):
		return
	var snap := _snap()
	if not GameState.spend_gold(price) or not GameState.level_up_formation(fid):
		return
	_bought_keys.append("constellation")
	Sfx.boom()
	_mark_bought(btn)
	var f := CardDB.get_formation(fid)
	var lvl := GameState.formation_level(fid)
	_note(tr("%s sobe ao nível %d: +%s Mult sempre que a fizeres.") % [tr(String(f.get("name", ""))), lvl, Cascade.fmt_mult(FormationPicker.mult_at(f, lvl))])
	_commit_undo(snap, tr("a Constelação (%s)") % tr(String(f.get("name", ""))))

## Fotografia da run e da loja antes de uma compra ou serviço (para o DESFAZER).
func _snap() -> Dictionary:
	return {"gs": GameState.shop_snapshot(), "shop": {
		"removed": removed_this_visit, "upgraded": upgraded_this_visit, "max_hp": max_hp_this_visit,
		"booster": booster_this_visit, "sealed": sealed_this_visit, "bought": _bought_keys.duplicate(),
		"cards": _bought_cards.duplicate(), "relics": _bought_relics.duplicate()}}

## A compra ou o serviço aconteceu: o DESFAZER passa a desfazê-lo (só o último), e a loja grava-se (V27).
func _commit_undo(snap: Dictionary, what: String) -> void:
	snap["what"] = what
	_undo = snap
	_did_something = true
	_leave_armed = false
	_refresh_undo()
	_save_state()

func _refresh_undo() -> void:
	undo_btn.disabled = _undo.is_empty()
	undo_btn.tooltip_text = tr("Desfaz %s.") % String(_undo.get("what", "")) if not _undo.is_empty() \
		else tr("Desfaz a última compra, serviço ou venda desta visita.")

## DESFAZER: a run e a loja voltam a estar como antes da última compra, serviço ou venda.
func _on_undo() -> void:
	if _undo.is_empty() or SceneRouter.has_overlay():
		return
	var s: Dictionary = _undo
	_undo = {}
	_clear_confirm()
	GameState.restore_shop_snapshot(s.get("gs", {}))
	var l: Dictionary = s.get("shop", {})
	removed_this_visit = bool(l.get("removed", false))
	upgraded_this_visit = bool(l.get("upgraded", false))
	max_hp_this_visit = bool(l.get("max_hp", false))
	booster_this_visit = bool(l.get("booster", false))
	sealed_this_visit = bool(l.get("sealed", false))
	_bought_keys.assign(l.get("bought", []))
	_bought_cards.assign(l.get("cards", []))
	_bought_relics.assign(l.get("relics", []))
	_build_offers()
	_on_gold_changed(GameState.gold)
	_note(tr("Desfeito: %s.") % String(s.get("what", "")))
	Sfx.back()
	_refresh_undo()
	_save_state()

# --- Gravar a loja (V27) ---

## O estado da loja (ofertas e o que já se fez) vai na gravação da run: sair para o menu ou fechar a app e
## voltar encontra a loja igual (as mesmas ofertas, compradas ou não, e os juros já pagos).
func _state_dict() -> Dictionary:
	var cards: Array[String] = []
	for c in _offer_cards:
		cards.append(c.id)
	var relics: Array[String] = []
	for r in _offer_relics:
		relics.append(String(r.get("id", "")))
	var pws: Array[String] = []
	for p in _offer_pws:
		pws.append(String(p.get("id", "")))
	return {
		"ante": GameState.ante, "merchant": merchant,
		"cards": cards, "editions": _offer_editions.duplicate(), "relics": relics, "pws": pws,
		"item": _offer_item, "voucher": _voucher, "booster_cards": _booster_cards.duplicate(true),
		"bought": _bought_keys.duplicate(), "bought_cards": _bought_cards.duplicate(), "bought_relics": _bought_relics.duplicate(),
		"rerolls": rerolls, "removed": removed_this_visit, "upgraded": upgraded_this_visit, "max_hp": max_hp_this_visit,
		"booster": booster_this_visit, "sealed": sealed_this_visit,
	}

func _save_state() -> void:
	GameState.save_run({"shop": _state_dict()}, "shop")

## Volta a pôr a loja como estava quando se gravou (false se não há nada desta visita para retomar).
func _restore_state() -> bool:
	var pb = GameState.pending_battle
	if not (pb is Dictionary) or not (pb as Dictionary).has("shop") or GameState.saved_scene != "shop":
		return false
	var st: Dictionary = (pb as Dictionary)["shop"]
	GameState.pending_battle = {}
	if int(st.get("ante", -1)) != GameState.ante or bool(st.get("merchant", false)) != merchant:
		return false
	_offer_cards.clear()
	for id in st.get("cards", []):
		var d := CardDB.get_card(String(id))
		if d != null:
			_offer_cards.append(d)
	_offer_editions.assign(st.get("editions", []))
	while _offer_editions.size() < _offer_cards.size():
		_offer_editions.append("")
	_offer_relics.clear()
	for id in st.get("relics", []):
		var r: Dictionary = CardDB.relics.get(String(id), {})
		if not r.is_empty():
			_offer_relics.append(r)
	_offer_pws.clear()
	for id in st.get("pws", []):
		var p := CardDB.get_planeswalker(String(id))
		if not p.is_empty():
			_offer_pws.append(p)
	_offer_item = String(st.get("item", ""))
	_voucher = String(st.get("voucher", ""))
	_booster_cards = (st.get("booster_cards", []) as Array).duplicate(true)
	_bought_keys.assign(st.get("bought", []))
	_bought_cards.assign(st.get("bought_cards", []))
	_bought_relics.assign(st.get("bought_relics", []))
	rerolls = int(st.get("rerolls", 0))
	removed_this_visit = bool(st.get("removed", false))
	upgraded_this_visit = bool(st.get("upgraded", false))
	max_hp_this_visit = bool(st.get("max_hp", false))
	booster_this_visit = bool(st.get("booster", false))
	sealed_this_visit = bool(st.get("sealed", false))
	_did_something = not _bought_keys.is_empty() or removed_this_visit or upgraded_this_visit or max_hp_this_visit or booster_this_visit or sealed_this_visit
	return true

## V27: MENU — a loja já está gravada (ofertas e compras); volta-se a ela em CONTINUAR.
func _on_menu() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	_save_state()
	SceneRouter.go("main")

func _on_continue() -> void:
	if SceneRouter.has_overlay():
		return
	# V20: quem sai sem comprar nada ouve o mercador; um 2.º toque (ou 1,2 s) segue logo.
	if not _did_something and not _leave_armed and _animated():
		_leave_armed = true
		_say("leave")
		await get_tree().create_timer(1.2).timeout
		if not is_inside_tree() or not _leave_armed:
			return
	_leave_armed = false
	GameState.next_ante()
	GameState.save_run({}, "map")
	SceneRouter.go("map")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		Sfx.select()   # na loja o botão "retroceder" não faz nada de destrutivo
