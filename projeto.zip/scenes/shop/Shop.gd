extends Control
## Loja entre antes (horizontal): cartas (3 ofertas, booster 1-de-3, novas ofertas), relíquias
## (2 ofertas, as tuas com venda, máx. 5) e serviços (curar, vida máxima, melhorar carta,
## remover carta, ver baralho). Juros: +1 ouro por cada 5 guardados (máx. 5), uma vez por ante.

const HEAL_PRICE := 3
const HEAL_AMOUNT := 5
const MAX_HP_PRICE := 8
const MAX_HP_AMOUNT := 5
const UPGRADE_PRICE := 4
const UPGRADE_POWER := 10
const UPGRADE_MULT := 0.5
const BOOSTER_PRICE := 5
const REROLL_BASE := 2

@onready var cards_box: VBoxContainer = %CardOffers
@onready var relics_box: VBoxContainer = %RelicOffers
@onready var owned_box: VBoxContainer = %OwnedRelics
@onready var owned_title: Label = %OwnedTitle
@onready var gold_label: Label = %GoldLabel
@onready var life_label: Label = %LifeLabel
@onready var continue_btn: Button = %Continue
@onready var remove_btn: Button = %RemoveButton
@onready var heal_btn: Button = %HealBtn
@onready var max_hp_btn: Button = %MaxHpBtn
@onready var upgrade_btn: Button = %UpgradeBtn
@onready var booster_btn: Button = %BoosterBtn
@onready var reroll_btn: Button = %RerollBtn
@onready var deck_btn: Button = %DeckButton
@onready var interest_label: Label = %InterestLabel
@onready var note_label: Label = %ServicesNote

var removed_this_visit: bool = false
var upgraded_this_visit: bool = false
var max_hp_this_visit: bool = false
var booster_this_visit: bool = false
var rerolls: int = 0
var _offer_cards: Array[CardData] = []
var _offer_relics: Array[Dictionary] = []
var _bought_cards: Array[String] = []
var _bought_relics: Array[String] = []

func _ready() -> void:
	%Title.text = tr("MERCADOR  ·  ante %d vencido  ·  %s") % [GameState.ante, tr(GameState.deck_def.get("name", ""))]
	GameState.save_run({}, "shop")   # fechar a app aqui retoma na loja (mesmas ofertas, mesmos juros)
	var due := GameState.pay_interest()
	if due > 0:
		interest_label.text = tr("Juros: +%d ouro (1 por cada 5 guardados, máx. 5).") % due
	else:
		interest_label.text = tr("Juros: 1 ouro por cada 5 guardados ao entrar na loja (máx. 5).")
	EventBus.gold_changed.connect(_on_gold_changed)
	EventBus.player_hp_changed.connect(func(c, m): life_label.text = tr("Vida %d/%d") % [c, m])
	life_label.text = tr("Vida %d/%d") % [GameState.player_hp, GameState.player_max_hp]
	continue_btn.pressed.connect(_on_continue)
	remove_btn.pressed.connect(_on_remove)
	heal_btn.pressed.connect(_on_heal)
	max_hp_btn.pressed.connect(_on_max_hp)
	upgrade_btn.pressed.connect(_on_upgrade)
	booster_btn.pressed.connect(_on_booster)
	reroll_btn.pressed.connect(_on_reroll)
	deck_btn.pressed.connect(func(): Sfx.select(); ZoneViewer.open_deck(tr("O TEU BARALHO")))
	_roll_offers()
	_build_offers()
	_on_gold_changed(GameState.gold)

func _on_gold_changed(g: int) -> void:
	gold_label.text = tr("Ouro: %d") % g
	_refresh_services()
	_refresh_offer_buttons()

# --- Ofertas ---

func _roll_offers() -> void:
	_offer_cards = CardDB.random_shop_offers(3, GameState.rng)
	_offer_relics.clear()
	var exclude: Array = GameState.relic_ids.duplicate()
	for i in 2:
		var r := CardDB.random_relic_offer(GameState.rng, exclude)
		if r.is_empty():
			break
		_offer_relics.append(r)
		exclude.append(String(r.get("id", "")))
	_bought_cards.clear()
	_bought_relics.clear()

func _build_offers() -> void:
	for child in cards_box.get_children():
		child.queue_free()
	for child in relics_box.get_children():
		child.queue_free()
	for c in _offer_cards:
		Stats.mark_seen("cards", c.id, false)
		var stats := ""
		if c.is_creature():
			stats = "  ·  %d⚔ %d♥" % [c.power, c.toughness]
		elif c.power > 0:
			stats = "  ·  %d⚔" % c.power
		var btn := _offer_button(tr("%s  (custo %d%s  ·  %d ouro)") % [tr(c.name), c.cost, stats, c.price] + "\n" + tr(c.text), c.price)
		btn.set_meta("price", c.price)
		btn.set_meta("kind", "card")
		btn.pressed.connect(func():
			if GameState.spend_gold(c.price):
				GameState.add_card(c.id)
				_bought_cards.append(c.id)
				Sfx.select()
				btn.disabled = true
				btn.text += "  ✓")
		cards_box.add_child(btn)
	for r in _offer_relics:
		Stats.mark_seen("relics", String(r.get("id", "")), false)
		var price := int(r.get("price", 5))
		var btn := _offer_button(tr("★ %s  (%d ouro · %s)") % [tr(r.name), price, tr(CardZoom.RARITY_NAMES.get(String(r.get("rarity", "common")), "Comum"))] + "\n" + tr(r.text), price)
		btn.set_meta("price", price)
		btn.set_meta("kind", "relic")
		btn.pressed.connect(func():
			if GameState.relic_ids.size() >= GameState.MAX_RELICS:
				_note(tr("Já tens %d relíquias: vende uma primeiro.") % GameState.MAX_RELICS)
				return
			if GameState.spend_gold(price):
				GameState.add_relic(String(r.id))
				_bought_relics.append(String(r.id))
				Sfx.select()
				btn.disabled = true
				btn.text += "  ✓"
				_build_owned())
		relics_box.add_child(btn)
	_build_owned()
	_refresh_offer_buttons()

func _offer_button(label: String, _price: int) -> Button:
	var btn := Button.new()
	btn.text = label
	btn.custom_minimum_size.y = 78
	btn.add_theme_font_size_override("font_size", 17)
	btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
	btn.clip_text = true
	return btn

func _refresh_offer_buttons() -> void:
	for btn in cards_box.get_children() + relics_box.get_children():
		if not (btn is Button) or btn.text.ends_with("✓"):
			continue
		var price: int = btn.get_meta("price", 0)
		var full: bool = btn.get_meta("kind", "") == "relic" and GameState.relic_ids.size() >= GameState.MAX_RELICS
		btn.disabled = GameState.gold < price or full
	booster_btn.text = tr("BOOSTER (%d ouro)") % BOOSTER_PRICE if not booster_this_visit else tr("Booster aberto  ✓")
	booster_btn.disabled = booster_this_visit or GameState.gold < BOOSTER_PRICE
	var reroll_price := REROLL_BASE + rerolls
	reroll_btn.text = tr("NOVAS OFERTAS (%d ouro)") % reroll_price
	reroll_btn.disabled = GameState.gold < reroll_price

func _build_owned() -> void:
	for child in owned_box.get_children():
		child.queue_free()
	owned_title.text = tr("As tuas relíquias (%d/%d)") % [GameState.relic_ids.size(), GameState.MAX_RELICS]
	for id in GameState.relic_ids:
		var r: Dictionary = CardDB.relics.get(id, {})
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		var name_btn := Button.new()
		name_btn.text = tr(String(r.get("name", id)))
		name_btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		name_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name_btn.custom_minimum_size.y = 40
		name_btn.add_theme_font_size_override("font_size", 16)
		name_btn.clip_text = true
		name_btn.pressed.connect(func(): Sfx.select(); CardZoom.show_relic(id))
		row.add_child(name_btn)
		var sell := Button.new()
		sell.text = tr("VENDER +%d") % GameState.relic_sell_price(id)
		sell.custom_minimum_size = Vector2(130, 40)
		sell.add_theme_font_size_override("font_size", 15)
		sell.pressed.connect(func():
			GameState.add_gold(GameState.relic_sell_price(id))
			GameState.remove_relic(id)
			Sfx.hit()
			_build_owned()
			_refresh_offer_buttons())
		row.add_child(sell)
		owned_box.add_child(row)

# --- Serviços ---

func _refresh_services() -> void:
	var price := GameState.removal_price()
	if removed_this_visit:
		remove_btn.text = tr("Carta removida  ✓")
		remove_btn.disabled = true
	else:
		remove_btn.text = tr("REMOVER UMA CARTA (%d ouro)") % price
		remove_btn.disabled = GameState.gold < price or GameState.deck.size() <= 6
	heal_btn.text = tr("CURAR %d (%d ouro)") % [HEAL_AMOUNT, HEAL_PRICE]
	heal_btn.disabled = GameState.gold < HEAL_PRICE or GameState.player_hp >= GameState.player_max_hp
	if max_hp_this_visit:
		max_hp_btn.text = tr("Vida máxima +%d  ✓") % MAX_HP_AMOUNT
		max_hp_btn.disabled = true
	else:
		max_hp_btn.text = tr("VIDA MÁXIMA +%d (%d ouro)") % [MAX_HP_AMOUNT, MAX_HP_PRICE]
		max_hp_btn.disabled = GameState.gold < MAX_HP_PRICE
	if upgraded_this_visit:
		upgrade_btn.text = tr("Carta melhorada  ✓")
		upgrade_btn.disabled = true
	else:
		upgrade_btn.text = tr("MELHORAR UMA CARTA (%d ouro)") % UPGRADE_PRICE
		upgrade_btn.disabled = GameState.gold < UPGRADE_PRICE
	if note_label.text == "":
		note_label.text = tr("Melhorar: +%d Poder permanente (criaturas e feitiços com Poder) ou +%s Mult (as outras). Vida máxima e melhoria: uma vez por visita.") % [UPGRADE_POWER, Cascade.fmt_mult(UPGRADE_MULT)]

func _note(text: String) -> void:
	note_label.text = text

func _on_heal() -> void:
	if GameState.player_hp >= GameState.player_max_hp or not GameState.spend_gold(HEAL_PRICE):
		return
	GameState.heal(HEAL_AMOUNT)
	Sfx.select()
	_refresh_services()

func _on_max_hp() -> void:
	if max_hp_this_visit or not GameState.spend_gold(MAX_HP_PRICE):
		return
	max_hp_this_visit = true
	GameState.change_max_hp(MAX_HP_AMOUNT)
	GameState.heal(MAX_HP_AMOUNT)
	Sfx.select()
	_refresh_services()

func _on_upgrade() -> void:
	if upgraded_this_visit or GameState.gold < UPGRADE_PRICE or SceneRouter.has_overlay():
		return
	Sfx.select()
	ZoneViewer.open_deck(tr("MELHORAR — escolhe a carta"), func(card: CardInstance):
		if upgraded_this_visit or card.entry_index < 0 or not GameState.spend_gold(UPGRADE_PRICE):
			return
		upgraded_this_visit = true
		var entry: Dictionary = GameState.deck[card.entry_index]
		if card.data.is_creature() or card.data.power > 0:
			entry["power_bonus"] = int(entry.get("power_bonus", 0)) + UPGRADE_POWER
			_note(tr("%s: +%d Poder permanente.") % [tr(card.data.name), UPGRADE_POWER])
		else:
			entry["mult_bonus"] = float(entry.get("mult_bonus", 0.0)) + UPGRADE_MULT
			_note(tr("%s: +%s Mult permanente.") % [tr(card.data.name), Cascade.fmt_mult(UPGRADE_MULT)])
		Sfx.boom()
		_refresh_services())

func _on_remove() -> void:
	if removed_this_visit or GameState.gold < GameState.removal_price() or SceneRouter.has_overlay():
		return
	Sfx.select()
	ZoneViewer.open_deck(tr("REMOVER — escolhe a carta"), func(card: CardInstance):
		if removed_this_visit or card.entry_index < 0 or GameState.deck.size() <= 6:
			return
		if not GameState.spend_gold(GameState.removal_price()):
			return
		GameState.deck.remove_at(card.entry_index)
		removed_this_visit = true
		_note(tr("%s removida do baralho.") % tr(card.data.name))
		Sfx.hit()
		_refresh_services())

func _on_booster() -> void:
	if booster_this_visit or GameState.gold < BOOSTER_PRICE or SceneRouter.has_overlay():
		return
	Sfx.select()
	var cards: Array[CardInstance] = []
	var pool := CardDB.cards_for_colors(GameState.deck_colors())
	for i in 3:
		if pool.is_empty():
			break
		var pick := pool[GameState.rng.randi_range(0, pool.size() - 1)]
		pool.erase(pick)
		cards.append(CardDB.new_instance(pick.id))
	ZoneViewer.open(tr("BOOSTER — escolhe 1 de 3"), cards, false, func(card: CardInstance):
		if booster_this_visit or not GameState.spend_gold(BOOSTER_PRICE):
			return
		booster_this_visit = true
		GameState.add_card(card.data.id)
		_note(tr("%s juntou-se ao baralho.") % tr(card.data.name))
		Sfx.boom()
		_refresh_offer_buttons())

func _on_reroll() -> void:
	var price := REROLL_BASE + rerolls
	if not GameState.spend_gold(price):
		return
	rerolls += 1
	Sfx.select()
	_roll_offers()
	_build_offers()

func _on_continue() -> void:
	GameState.next_ante()
	GameState.save_run({}, "battle")
	SceneRouter.go("battle")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		Sfx.select()   # na loja o botão "retroceder" não faz nada de destrutivo
