extends Control
## Loja entre antes (horizontal): 3 cartas à esquerda, 2 relíquias à direita,
## remoção de UMA carta do deck por visita.

@onready var cards_box: VBoxContainer = %CardOffers
@onready var relics_box: VBoxContainer = %RelicOffers
@onready var gold_label: Label = %GoldLabel
@onready var continue_btn: Button = %Continue
@onready var remove_btn: Button = %RemoveButton
@onready var remove_panel: PanelContainer = %RemovePanel
@onready var deck_list: GridContainer = %DeckList
@onready var remove_close: Button = %RemoveClose

var removed_this_visit: bool = false

func _ready() -> void:
	EventBus.gold_changed.connect(_on_gold_changed)
	_on_gold_changed(GameState.gold)
	continue_btn.pressed.connect(_on_continue)
	remove_btn.pressed.connect(_open_remove_panel)
	remove_close.pressed.connect(func(): remove_panel.hide())
	remove_panel.hide()
	_build_offers()
	_refresh_remove_button()

func _on_gold_changed(g: int) -> void:
	gold_label.text = "Ouro: %d" % g
	_refresh_remove_button()

# --- Compras ---

func _build_offers() -> void:
	for c in CardDB.random_shop_offers(3, GameState.rng):
		var stats := ""
		if c.is_creature():
			stats = "  ·  %d⚔ %d♥" % [c.power, c.toughness]
		elif c.power > 0:
			stats = "  ·  %d⚔" % c.power
		_add_offer(cards_box, "%s  (custo %d%s  ·  %d ouro)\n%s" % [c.name, c.cost, stats, c.price, c.text], c.price, func(): GameState.add_card(c.id))
	var relic_pool: Array = CardDB.relics.values().filter(func(r): return not (r.id in GameState.relic_ids))
	for i in min(2, relic_pool.size()):
		var r: Dictionary = relic_pool[GameState.rng.randi_range(0, relic_pool.size() - 1)]
		relic_pool.erase(r)
		_add_offer(relics_box, "★ %s  (%d ouro)\n%s" % [r.name, r.price, r.text], int(r.price), func(): GameState.add_relic(r.id))

func _add_offer(parent: Control, label: String, price: int, on_buy: Callable) -> void:
	var btn := Button.new()
	btn.text = label
	btn.custom_minimum_size.y = 84
	btn.add_theme_font_size_override("font_size", 20)
	btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
	btn.pressed.connect(func():
		if GameState.spend_gold(price):
			on_buy.call()
			Sfx.select()
			btn.disabled = true
			btn.text += "  ✓")
	parent.add_child(btn)

# --- Remoção ---

func _refresh_remove_button() -> void:
	var price := GameState.removal_price()
	if removed_this_visit:
		remove_btn.text = "Carta removida  ✓"
		remove_btn.disabled = true
	else:
		remove_btn.text = "REMOVER UMA CARTA (%d ouro)" % price
		remove_btn.disabled = GameState.gold < price or GameState.deck.size() <= 6

func _open_remove_panel() -> void:
	for child in deck_list.get_children():
		child.queue_free()
	var counts := GameState.deck_counts()
	var ids := counts.keys()
	# Terrenos primeiro, depois por custo, para a lista ser previsível.
	ids.sort_custom(func(a, b):
		var ca := CardDB.get_card(a)
		var cb := CardDB.get_card(b)
		if ca.is_land() != cb.is_land():
			return ca.is_land()
		return ca.cost < cb.cost)
	for id in ids:
		var data := CardDB.get_card(id)
		var btn := Button.new()
		var stats := "" if not data.is_creature() else "  %d⚔" % data.power
		btn.text = "×%d  %s (%d)%s" % [counts[id], data.name, data.cost, stats]
		btn.custom_minimum_size.y = 64
		btn.add_theme_font_size_override("font_size", 20)
		btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		btn.pressed.connect(_on_remove_pressed.bind(id))
		deck_list.add_child(btn)
	remove_panel.show()

func _on_remove_pressed(id: String) -> void:
	if removed_this_visit:
		return
	if not GameState.spend_gold(GameState.removal_price()):
		return
	GameState.remove_card(id)
	removed_this_visit = true
	Sfx.hit()
	remove_panel.hide()
	_refresh_remove_button()

func _on_continue() -> void:
	GameState.next_ante()
	SceneRouter.go("battle")
