extends Control
## Loja (nó do mapa): cartas (3 ofertas, booster 1-de-3, novas ofertas), relíquias (2 ofertas, as
## tuas com venda, máx. 5) e serviços (curar, vida máxima, melhorar carta, selar carta, remover
## carta, ver baralho). Juros: +1 ouro por cada 5 guardados (máx. 5), uma vez por ante.
## Mercador Cego (outro nó): só relíquias lendárias (não saem na loja normal) e planeswalkers.
## Selos Planares: 5 — relíquias compradas não se vendem; 6 — cartas de booster podem vir infetadas.
## 0.10.0: um Vale por visita (melhoria da run: +1 mão, +1 canalização, +1 relíquia, juros, preços…),
## ícone ⚭ (corrente) nas cartas que combinam com o baralho e regras dos Desafios (sem relíquias, custo ≤ 2).
## 0.13.0: cartas com edição (Brilhante, Holográfica, Policromática: mais caras, ver EffectResolver.EDITIONS),
## também no booster; compras caras pedem um segundo toque (Configurações → Confirmar compras caras).
## 0.15.0: Constelação (sobe 1 nível a uma formação à escolha, uma por visita) e ↩ DESFAZER (a última compra,
## serviço ou venda desta visita; NOVAS OFERTAS não se desfaz e limpa o que havia para desfazer).

const HEAL_PRICE := 3
const HEAL_AMOUNT := 5
const MAX_HP_PRICE := 8
const MAX_HP_AMOUNT := 5
const UPGRADE_PRICE := 4
const UPGRADE_POWER := 10
const UPGRADE_MULT := 0.5
const BOOSTER_PRICE := 5
const REROLL_BASE := 2
const SEAL_PRICE := 6
const INFECTION_CHANCE := 0.5
const CONFIRM_PRICE := 10     # 0.13.0: "Confirmar compras caras" pede um 2.º toque a partir deste preço…
const CONFIRM_HALF_MIN := 5   # …ou, a partir deste, quando custa metade (ou mais) do ouro que tens
const CONFIRM_TIME := 3.0
const CONSTELLATION_PRICE := 5   # 0.15.0

@onready var cards_box: VBoxContainer = %CardOffers
@onready var relics_box: VBoxContainer = %RelicOffers
@onready var owned_box: VBoxContainer = %OwnedRelics
@onready var owned_title: Label = %OwnedTitle
@onready var gold_label: Label = %GoldLabel
@onready var life_label: Label = %LifeLabel
@onready var continue_btn: Button = %Continue
@onready var remove_btn: Button = %RemoveButton
@onready var heal_btn: Button = %HealBtn
@onready var max_hp_btn: Button = %MaxHpBtn
@onready var upgrade_btn: Button = %UpgradeBtn
@onready var booster_btn: Button = %BoosterBtn
@onready var reroll_btn: Button = %RerollBtn
@onready var deck_btn: Button = %DeckButton
@onready var seal_btn: Button = %SealBtn
@onready var interest_label: Label = %InterestLabel
@onready var note_label: Label = %ServicesNote
@onready var undo_btn: Button = %UndoBtn

var removed_this_visit: bool = false
var upgraded_this_visit: bool = false
var max_hp_this_visit: bool = false
var booster_this_visit: bool = false
var sealed_this_visit: bool = false
var rerolls: int = 0
var merchant: bool = false            # Mercador Cego
var _offer_cards: Array[CardData] = []
var _offer_editions: Array[String] = []   # 0.13.0: edição de cada carta oferecida ("" = normal)
var _confirm_btn: Button                   # 0.13.0: botão à espera do 2.º toque
var _confirm_text := ""
var _confirm_token := 0
var _offer_relics: Array[Dictionary] = []
var _offer_pws: Array[Dictionary] = []
var _bought_cards: Array[String] = []
var _bought_relics: Array[String] = []
var _voucher: String = ""             # Vale à venda nesta visita ("" = nenhum)
var _offer_item: String = ""          # 0.13.0: poção ou pergaminho à venda nesta visita ("" = nenhum)
var _bought_keys: Array[String] = []   # 0.15.0: ofertas compradas ("card:0", "relic:<id>", "item", …), para as refazer
var _undo: Dictionary = {}             # 0.15.0: run e loja antes da última compra/serviço ({} = nada a desfazer)

func _ready() -> void:
	merchant = String(GameState.map_choice.get("stop", "")) == "merchant"
	if merchant:
		%Title.text = tr("MERCADOR CEGO  ·  ante %d vencido  ·  %s") % [GameState.ante, tr(GameState.deck_def.get("name", ""))]
		%CardsTitle.text = tr("Patronos")
		%RelicsTitle.text = tr("Relíquias lendárias")
	else:
		%Title.text = tr("MERCADOR  ·  ante %d vencido  ·  %s") % [GameState.ante, tr(GameState.deck_def.get("name", ""))]
	GameState.save_run({}, "shop")   # fechar a app aqui retoma na loja (mesmas ofertas, mesmos juros)
	var due := GameState.pay_interest()
	if due > 0:
		interest_label.text = tr("Juros: +%d ouro (1 por cada 5 guardados, máx. %d).") % [due, GameState.interest_cap()]
	else:
		interest_label.text = tr("Juros: 1 ouro por cada 5 guardados ao entrar na loja (máx. %d).") % GameState.interest_cap()
	var tax := int(GameState.relic_passive("shop_tax"))
	if tax > 0:
		interest_label.text += "  ·  " + tr("Preços +%d (relíquia de boss).") % tax
	EventBus.gold_changed.connect(_on_gold_changed)
	EventBus.player_hp_changed.connect(func(c, m): life_label.text = tr("Vida %d/%d") % [c, m])
	life_label.text = tr("Vida %d/%d") % [GameState.player_hp, GameState.player_max_hp]
	continue_btn.pressed.connect(_on_continue)
	remove_btn.pressed.connect(_on_remove)
	heal_btn.pressed.connect(_on_heal)
	max_hp_btn.pressed.connect(_on_max_hp)
	upgrade_btn.pressed.connect(_on_upgrade)
	booster_btn.pressed.connect(_on_booster)
	reroll_btn.pressed.connect(_on_reroll)
	seal_btn.pressed.connect(_on_seal)
	undo_btn.pressed.connect(_on_undo)
	undo_btn.text = tr("↩ DESFAZER")
	deck_btn.pressed.connect(func(): Sfx.select(); ZoneViewer.open_deck(tr("O TEU BARALHO")))
	if merchant:
		booster_btn.visible = false
		reroll_btn.visible = false
		upgrade_btn.visible = false
		remove_btn.visible = false
		seal_btn.visible = false
	else:
		_voucher = GameState.shop_voucher_offer()
	if not GameState.relics_allowed():
		%RelicsTitle.text = tr("Sem relíquias (Desafio)")
	_roll_offers()
	_build_offers()
	_on_gold_changed(GameState.gold)
	_refresh_undo()

func _on_gold_changed(g: int) -> void:
	gold_label.text = tr("Ouro: %d") % g
	_refresh_services()
	_refresh_offer_buttons()

# --- Ofertas ---

func _roll_offers() -> void:
	_offer_relics.clear()
	_offer_pws.clear()
	_bought_cards.clear()
	_bought_relics.clear()
	_bought_keys.clear()
	if merchant:
		_offer_cards = []
		_offer_editions.clear()
		_offer_item = ""
		var legendary := CardDB.legendary_relics(GameState.relic_ids) if GameState.relics_allowed() else []
		for i in 2:
			if legendary.is_empty():
				break
			var pick: Dictionary = legendary[GameState.rng.randi_range(0, legendary.size() - 1)]
			legendary.erase(pick)
			_offer_relics.append(pick)
		var pws: Array = CardDB.planeswalkers.filter(func(p): return String(p.get("id", "")) != String(GameState.planeswalker.get("id", "")) and CardDB.is_planeswalker_available(p))
		for i in 2:
			if pws.is_empty():
				break
			var pick: Dictionary = pws[GameState.rng.randi_range(0, pws.size() - 1)]
			pws.erase(pick)
			_offer_pws.append(pick)
		return
	_offer_cards = CardDB.random_shop_offers(3 + int(GameState.voucher_value("shop_cards")), GameState.rng)
	_offer_editions.clear()
	for c in _offer_cards:
		_offer_editions.append(GameState.roll_edition(c))
	_offer_item = GameState.random_consumable()   # 0.13.0: uma poção ou pergaminho por visita
	if not GameState.relics_allowed():
		return
	var exclude: Array = GameState.relic_ids.duplicate()
	for i in 2:
		var r := CardDB.random_relic_offer(GameState.rng, exclude)
		if r.is_empty():
			break
		_offer_relics.append(r)
		exclude.append(String(r.get("id", "")))

func _build_offers() -> void:
	UiKit.clear_children(cards_box)
	UiKit.clear_children(relics_box)
	for i in _offer_cards.size():
		var c: CardData = _offer_cards[i]
		var ed: String = _offer_editions[i] if i < _offer_editions.size() else ""
		Stats.mark_seen("cards", c.id, false)
		var stats := ""
		if c.is_creature():
			stats = "  ·  %d⚔ %d♥" % [c.power, c.toughness]
		elif c.power > 0:
			stats = "  ·  %d⚔" % c.power
		var card_price := _p(c.price + edition_price(ed))
		var why := CardDB.synergy_reason(c)
		var head := ("⚭ " if why != "" else "") + tr("%s  (custo %d%s  ·  %d ouro)") % [tr(c.name), c.cost, stats, card_price]
		if ed != "":
			head = String(EffectResolver.EDITIONS[ed]["symbol"]) + " " + head
		var body := head + "\n" + tr(c.text)
		if ed != "":
			body += "\n" + String(EffectResolver.EDITIONS[ed]["symbol"]) + " " + EffectResolver.edition_text(ed)
		if why != "":
			body += "\n⚭ " + tr("Combina: %s") % why
		var btn := _offer_button(body, card_price)
		btn.custom_minimum_size.y = _fit_height(body)
		if why != "":
			btn.tooltip_text = tr("Combina com o teu baralho: %s") % why
		if ed != "":
			UiKit.wrap_label(btn).add_theme_color_override("font_color", EffectResolver.edition_color(ed).lightened(0.25))
		btn.set_meta("price", card_price)
		btn.set_meta("kind", "card")
		var key := "card:%d" % i
		btn.pressed.connect(func():
			if not _confirm(btn, card_price):
				return
			var snap := _snap()
			if GameState.spend_gold(card_price):
				GameState.add_card(c.id, false, ed)
				_bought_cards.append(c.id)
				_bought_keys.append(key)
				if ed != "":
					Sfx.boom()
				else:
					Sfx.select()
				_mark_bought(btn)
				if ed != "":
					_note(tr("%s (%s) juntou-se ao baralho.") % [tr(c.name), EffectResolver.edition_name(ed)])
				_commit_undo(snap, tr("a compra de %s") % tr(c.name)))
		cards_box.add_child(btn)
		if key in _bought_keys:
			_mark_bought(btn)
	if _offer_editions.any(func(e): return e != ""):
		_edition_tip()
	for p in _offer_pws:
		Stats.mark_seen("planeswalkers", String(p.get("id", "")), false)
		var price := _p(int(p.get("price", 10)))
		var skill_txt: Array[String] = []
		for sk in p.get("skills", []):
			skill_txt.append(tr(String(sk.get("text", ""))))
		var btn := _offer_button(tr("✦ %s  (%d ouro)") % [tr(String(p.get("name", ""))), price] + "\n" + "  ".join(PackedStringArray(skill_txt)), price)
		btn.set_meta("price", price)
		btn.set_meta("kind", "pw")
		btn.custom_minimum_size.y = 96
		var key := "pw:" + String(p.get("id", ""))
		btn.pressed.connect(func():
			if not _confirm(btn, price):
				return
			var snap := _snap()
			if GameState.spend_gold(price):
				GameState.set_planeswalker(String(p.get("id", "")))
				_bought_keys.append(key)
				Sfx.boom()
				_mark_bought(btn)
				_note(tr("%s junta-se a ti. A lealdade sobe ao jogar cartas da cor dele/dela.") % tr(String(p.get("name", ""))))
				_commit_undo(snap, tr("a compra de %s") % tr(String(p.get("name", "")))))
		cards_box.add_child(btn)
		if key in _bought_keys:
			_mark_bought(btn)
	for r in _offer_relics:
		Stats.mark_seen("relics", String(r.get("id", "")), false)
		var price := _p(int(r.get("price", 5)))
		var rarity_txt := tr("Lendária") if bool(r.get("legendary", false)) else tr(CardZoom.RARITY_NAMES.get(String(r.get("rarity", "common")), "Comum"))
		var rtext := tr("★ %s  (%d ouro · %s)") % [tr(r.name), price, rarity_txt] + "\n" + tr(r.text)
		var rs := CardDB.relic_set_of(String(r.id))   # 0.13.0: conjuntos de relíquias
		if not rs.is_empty():
			var have := 0
			for m in rs.get("relics", []):
				if String(m) in GameState.relic_ids:
					have += 1
			rtext += "\n◆ " + tr("Conjunto: %s (%d/%d)") % [tr(String(rs.get("name", ""))), have, (rs.get("relics", []) as Array).size()]
		var btn := _offer_button(rtext, price)
		btn.custom_minimum_size.y = _fit_height(rtext)
		btn.set_meta("price", price)
		btn.set_meta("kind", "relic")
		var key := "relic:" + String(r.id)
		btn.pressed.connect(func():
			if GameState.relic_ids.size() >= GameState.max_relics():
				_note(tr("Já tens %d relíquias: vende uma primeiro.") % GameState.max_relics())
				return
			if not _confirm(btn, price):
				return
			var snap := _snap()
			if GameState.spend_gold(price):
				GameState.add_relic(String(r.id))
				_bought_relics.append(String(r.id))
				_bought_keys.append(key)
				if GameState.stake >= 5:
					GameState.relic_locked.append(String(r.id))
				Sfx.select()
				_mark_bought(btn)
				_build_owned()
				_commit_undo(snap, tr("a compra de %s") % tr(r.name)))
		relics_box.add_child(btn)
		if key in _bought_keys:
			_mark_bought(btn)
	_add_constellation_offer()
	_add_item_offer()
	_add_voucher_offer()
	_build_owned()
	_refresh_offer_buttons()

## Preço com a taxa das relíquias de boss (Cálice do Abismo: +2 em tudo).
func _p(base: int) -> int:
	return GameState.shop_price(base)

## 0.13.0: ouro a mais por uma carta com edição.
static func edition_price(ed: String) -> int:
	return int(EffectResolver.EDITIONS[ed]["price"]) if EffectResolver.EDITIONS.has(ed) else 0

## Compra cara: 10+ ouro, ou 5+ quando é metade (ou mais) do que tens.
static func is_expensive(price: int, gold: int) -> bool:
	return price >= CONFIRM_PRICE or (price >= CONFIRM_HALF_MIN and price * 2 >= gold)

## 0.13.0 (Confirmar compras caras): o 1.º toque numa compra cara só avisa; o 2.º (em 3 s) compra.
func _confirm(btn: Button, price: int) -> bool:
	if not Settings.confirm_buy or GameState.gold < price or not is_expensive(price, GameState.gold):
		return true
	if _confirm_btn == btn and is_instance_valid(btn):
		_clear_confirm()
		return true
	_clear_confirm()
	_confirm_btn = btn
	_confirm_text = UiKit.wrap_text(btn)
	UiKit.set_wrap_text(btn, tr("Toca outra vez para comprar por %d ouro.") % price + "\n" + _confirm_text.split("\n")[0])
	Sfx.select()
	_confirm_token += 1
	var tok := _confirm_token
	create_tween().tween_callback(func():
		if tok == _confirm_token:
			_clear_confirm()).set_delay(CONFIRM_TIME)
	return false

func _clear_confirm() -> void:
	if _confirm_btn != null and is_instance_valid(_confirm_btn) and not bool(_confirm_btn.get_meta("bought", false)):
		UiKit.set_wrap_text(_confirm_btn, _confirm_text)
	_confirm_btn = null
	_confirm_text = ""

## Dica das edições (a 1.ª vez que aparece uma carta com edição).
func _edition_tip() -> void:
	if Settings.tips_enabled and not GameState.tip_seen("edition") and CardDB.tips.has("edition"):
		GameState.mark_tip_seen("edition")
		SceneRouter.toast(tr("Dica: ") + tr(String(CardDB.tips["edition"])), 7.0)

## Preço dos serviços (o Vale do Artesão baixa-os; nunca menos de 1).
func _svc(base: int) -> int:
	return _p(maxi(1, base - int(GameState.voucher_value("service_discount"))))

func _reroll_price() -> int:
	if rerolls == 0 and GameState.talent_value("free_reroll") > 0.0:
		return 0   # talento Sorte do Apostador (0.12.0)
	return _p(maxi(0, REROLL_BASE + rerolls - int(GameState.voucher_value("reroll_discount"))))

## 0.13.0: uma poção ou pergaminho por visita (até 2 contigo; usam-se na batalha ou no mapa).
func _add_item_offer() -> void:
	if _offer_item == "":
		return
	var def := CardDB.get_consumable(_offer_item)
	var price := _p(int(def.get("price", 4)))
	var btn := _offer_button(tr("◆ %s  (%d ouro)") % [tr(String(def.get("name", ""))), price] + "\n" + tr(String(def.get("text", ""))), price)
	btn.name = "ItemOffer"
	btn.set_meta("price", price)
	btn.set_meta("kind", "item")
	UiKit.wrap_label(btn).add_theme_color_override("font_color", Color(String(def.get("color", "#ffffff"))).lerp(Color.WHITE, 0.35))
	btn.pressed.connect(func():
		if not GameState.can_add_consumable():
			_note(tr("Já tens %d poções/pergaminhos: usa um primeiro.") % GameState.consumable_slots())
			return
		if not _confirm(btn, price):
			return
		var snap := _snap()
		if GameState.spend_gold(price) and GameState.add_consumable(_offer_item):
			_bought_keys.append("item")
			Sfx.select()
			_mark_bought(btn)
			_note(tr("Recebes: %s.") % tr(String(def.get("name", "")))
				+ "  " + (tr("Usa-o no mapa.") if String(def.get("use", "battle")) == "map" else tr("Usa-o na batalha (barra de cima).")))
			_build_owned()
			_commit_undo(snap, tr("a compra de %s") % tr(String(def.get("name", "")))))
	relics_box.add_child(btn)
	if "item" in _bought_keys:
		_mark_bought(btn)

## Um Vale por visita: melhoria que fica para o resto da run.
func _add_voucher_offer() -> void:
	if _voucher == "":
		return
	if Settings.tips_enabled and not GameState.tip_seen("voucher") and CardDB.tips.has("voucher"):
		GameState.mark_tip_seen("voucher")
		SceneRouter.toast(tr("Dica: ") + tr(String(CardDB.tips["voucher"])), 6.0)
	var v := CardDB.get_voucher(_voucher)
	var price := _p(int(v.get("price", 10)))
	var owned := _voucher in GameState.vouchers
	var btn := _offer_button(tr("◆ Vale: %s  (%d ouro)") % [tr(String(v.get("name", ""))), price] + "\n" + tr(String(v.get("text", ""))), price)
	btn.set_meta("price", price)
	btn.set_meta("kind", "voucher")
	UiKit.wrap_label(btn).add_theme_color_override("font_color", Color(0.65, 0.95, 0.85))
	if owned:
		_mark_bought(btn)
	btn.pressed.connect(func():
		if not _confirm(btn, price):
			return
		var snap := _snap()
		if GameState.buy_voucher(_voucher):
			Sfx.boom()
			_mark_bought(btn)
			_note(tr("Vale ativo até ao fim da run: %s") % tr(String(v.get("text", ""))))
			_build_owned()
			_refresh_services()
			_refresh_offer_buttons()
			_commit_undo(snap, tr("a compra de %s") % (tr("Vale: %s") % tr(String(v.get("name", ""))))))
	relics_box.add_child(btn)

## Altura de uma oferta de carta para caber o texto todo (linhas de ~52 letras na coluna).
static func _fit_height(text: String) -> int:
	var lines := 0
	for part in text.split("\n"):
		lines += maxi(1, ceili(part.length() / 52.0))
	return maxi(92, lines * 20 + 22)

func _offer_button(label: String, _price: int) -> Button:
	var btn := UiKit.wrap_button(label, 92, 15)
	for st in ["normal", "hover", "pressed", "disabled"]:
		btn.remove_theme_stylebox_override(st)   # aspeto do tema (como antes), só com o texto em várias linhas
	return btn

## Oferta comprada: desativa o botão e acrescenta ✓ ao texto (fica de fora das atualizações de preço).
func _mark_bought(btn: Button) -> void:
	btn.disabled = true
	btn.set_meta("bought", true)
	UiKit.set_wrap_text(btn, UiKit.wrap_text(btn) + "  ✓")

func _refresh_offer_buttons() -> void:
	for btn in cards_box.get_children() + relics_box.get_children():
		if not (btn is Button) or bool(btn.get_meta("bought", false)):
			continue
		var price: int = btn.get_meta("price", 0)
		var full: bool = (btn.get_meta("kind", "") == "relic" and GameState.relic_ids.size() >= GameState.max_relics()) \
			or (btn.get_meta("kind", "") == "item" and not GameState.can_add_consumable())
		btn.disabled = GameState.gold < price or full
	booster_btn.text = tr("BOOSTER (%d ouro)") % _p(BOOSTER_PRICE) if not booster_this_visit else tr("Booster aberto  ✓")
	booster_btn.disabled = booster_this_visit or GameState.gold < _p(BOOSTER_PRICE)
	var reroll_price := _reroll_price()
	reroll_btn.text = tr("NOVAS OFERTAS (%d ouro)") % reroll_price
	reroll_btn.disabled = GameState.gold < reroll_price

func _build_owned() -> void:
	for child in owned_box.get_children():
		child.queue_free()
	owned_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART   # 0.13.0: a linha cresceu (poções), não pode alargar a coluna
	owned_title.text = tr("As tuas relíquias (%d/%d)") % [GameState.relic_ids.size(), GameState.max_relics()]
	if not GameState.boss_relics.is_empty():
		owned_title.text += "  ·  " + tr("de boss: %d") % GameState.boss_relics.size()
	if not GameState.vouchers.is_empty():
		owned_title.text += "  ·  " + tr("Vales: %d") % GameState.vouchers.size()
	owned_title.text += "  ·  " + tr("Poções/pergaminhos: %d/%d") % [GameState.consumables.size(), GameState.consumable_slots()]
	for id in GameState.relic_ids:
		var r: Dictionary = CardDB.relics.get(id, {})
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		var name_btn := Button.new()
		name_btn.text = tr(String(r.get("name", id)))
		name_btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		name_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name_btn.custom_minimum_size.y = 40
		name_btn.add_theme_font_size_override("font_size", 16)
		name_btn.clip_text = true
		name_btn.pressed.connect(func(): Sfx.select(); CardZoom.show_relic(id))
		row.add_child(name_btn)
		var sell := Button.new()
		sell.text = tr("VENDER +%d") % GameState.relic_sell_price(id)
		sell.custom_minimum_size = Vector2(130, 40)
		sell.add_theme_font_size_override("font_size", 15)
		if id in GameState.relic_locked:
			sell.text = tr("PRESA")
			sell.disabled = true
			sell.tooltip_text = tr("Marca Eterna: as relíquias compradas na loja não se vendem.")
		sell.pressed.connect(func():
			var snap := _snap()
			GameState.add_gold(GameState.relic_sell_price(id))
			GameState.remove_relic(id)   # o ouro que entra já toca a moeda
			_build_owned()
			_refresh_offer_buttons()
			_commit_undo(snap, tr("a venda de %s") % tr(String(r.get("name", id)))))
		row.add_child(sell)
		owned_box.add_child(row)
	# Relíquias de boss: não se vendem nem ocupam lugar.
	for id in GameState.boss_relics:
		var r: Dictionary = CardDB.relics.get(id, {})
		var brow := HBoxContainer.new()
		brow.add_theme_constant_override("separation", 8)
		var bname := Button.new()
		bname.text = tr(String(r.get("name", id)))
		bname.alignment = HORIZONTAL_ALIGNMENT_LEFT
		bname.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		bname.custom_minimum_size.y = 40
		bname.add_theme_font_size_override("font_size", 16)
		bname.add_theme_color_override("font_color", Color(1.0, 0.6, 0.55))
		bname.clip_text = true
		bname.pressed.connect(func(): Sfx.select(); CardZoom.show_relic(id))
		brow.add_child(bname)
		var tag := Button.new()
		tag.text = tr("DE BOSS")
		tag.disabled = true
		tag.custom_minimum_size = Vector2(130, 40)
		tag.add_theme_font_size_override("font_size", 15)
		brow.add_child(tag)
		owned_box.add_child(brow)

# --- Serviços ---

func _refresh_services() -> void:
	var price := _svc(GameState.removal_price())
	if removed_this_visit:
		remove_btn.text = tr("Carta removida  ✓")
		remove_btn.disabled = true
	else:
		remove_btn.text = tr("REMOVER UMA CARTA (%d ouro)") % price
		remove_btn.disabled = GameState.gold < price or GameState.deck.size() <= 6
	heal_btn.text = tr("CURAR %d (%d ouro)") % [HEAL_AMOUNT, _svc(HEAL_PRICE)]
	heal_btn.disabled = GameState.gold < _svc(HEAL_PRICE) or GameState.player_hp >= GameState.player_max_hp
	if max_hp_this_visit:
		max_hp_btn.text = tr("Vida máxima +%d  ✓") % MAX_HP_AMOUNT
		max_hp_btn.disabled = true
	else:
		max_hp_btn.text = tr("VIDA MÁXIMA +%d (%d ouro)") % [MAX_HP_AMOUNT, _svc(MAX_HP_PRICE)]
		max_hp_btn.disabled = GameState.gold < _svc(MAX_HP_PRICE)
	if upgraded_this_visit:
		upgrade_btn.text = tr("Carta melhorada  ✓")
		upgrade_btn.disabled = true
	else:
		upgrade_btn.text = tr("MELHORAR UMA CARTA (%d ouro)") % _svc(UPGRADE_PRICE)
		upgrade_btn.disabled = GameState.gold < _svc(UPGRADE_PRICE)
	if sealed_this_visit:
		seal_btn.text = tr("Carta selada  ✓")
		seal_btn.disabled = true
	else:
		seal_btn.text = tr("SELAR UMA CARTA (%d ouro)") % _svc(SEAL_PRICE)
		seal_btn.disabled = GameState.gold < _svc(SEAL_PRICE)
	if note_label.text == "":
		note_label.text = tr("Melhorar: +%d Poder permanente (criaturas e feitiços com Poder) ou +%s Mult (as outras). Vida máxima e melhoria: uma vez por visita.") % [UPGRADE_POWER, Cascade.fmt_mult(UPGRADE_MULT)]

func _note(text: String) -> void:
	note_label.text = text

func _on_heal() -> void:
	var snap := _snap()
	if GameState.player_hp >= GameState.player_max_hp or not GameState.spend_gold(_svc(HEAL_PRICE)):
		return
	GameState.heal(HEAL_AMOUNT)
	Sfx.select()
	_refresh_services()
	_commit_undo(snap, tr("a cura"))

func _on_max_hp() -> void:
	var snap := _snap()
	if max_hp_this_visit or not GameState.spend_gold(_svc(MAX_HP_PRICE)):
		return
	max_hp_this_visit = true
	GameState.change_max_hp(MAX_HP_AMOUNT)
	GameState.heal(MAX_HP_AMOUNT)
	Sfx.select()
	_refresh_services()
	_commit_undo(snap, tr("a vida máxima"))

func _on_upgrade() -> void:
	if upgraded_this_visit or GameState.gold < _svc(UPGRADE_PRICE) or SceneRouter.has_overlay():
		return
	Sfx.select()
	ZoneViewer.open_deck(tr("MELHORAR — escolhe a carta"), func(card: CardInstance):
		var snap := _snap()
		if upgraded_this_visit or card.entry_index < 0 or not GameState.spend_gold(_svc(UPGRADE_PRICE)):
			return
		upgraded_this_visit = true
		var entry: Dictionary = GameState.deck[card.entry_index]
		if card.data.is_creature() or card.data.power > 0:
			entry["power_bonus"] = int(entry.get("power_bonus", 0)) + UPGRADE_POWER
			_note(tr("%s: +%d Poder permanente.") % [tr(card.data.name), UPGRADE_POWER])
		else:
			entry["mult_bonus"] = float(entry.get("mult_bonus", 0.0)) + UPGRADE_MULT
			_note(tr("%s: +%s Mult permanente.") % [tr(card.data.name), Cascade.fmt_mult(UPGRADE_MULT)])
		Sfx.boom()
		_refresh_services()
		_commit_undo(snap, tr("a melhoria de %s") % tr(card.data.name)))

## Selo de guilda: escolhe o selo e depois a carta (uma carta só tem um selo; selar outra vez substitui).
func _on_seal() -> void:
	if sealed_this_visit or GameState.gold < _svc(SEAL_PRICE) or SceneRouter.has_overlay():
		return
	Sfx.select()
	var picker := SealPicker.open(func(seal_id: String):
		ZoneViewer.open_deck(tr("SELAR — escolhe a carta"), func(card: CardInstance):
			var snap := _snap()
			if sealed_this_visit or card.entry_index < 0 or not GameState.spend_gold(_svc(SEAL_PRICE)):
				return
			sealed_this_visit = true
			GameState.deck[card.entry_index]["seal"] = seal_id
			_note(tr("%s recebeu o %s.") % [tr(card.data.name), tr(String(CardDB.get_seal(seal_id).get("name", seal_id)))])
			Sfx.boom()
			_refresh_services()
			_commit_undo(snap, tr("o selo de %s") % tr(card.data.name))))
	if picker == null:
		return

func _on_remove() -> void:
	if removed_this_visit or GameState.gold < _svc(GameState.removal_price()) or SceneRouter.has_overlay():
		return
	Sfx.select()
	ZoneViewer.open_deck(tr("REMOVER — escolhe a carta"), func(card: CardInstance):
		if removed_this_visit or card.entry_index < 0 or GameState.deck.size() <= 6:
			return
		var snap := _snap()
		if not GameState.spend_gold(_svc(GameState.removal_price())):
			return
		GameState.deck.remove_at(card.entry_index)
		removed_this_visit = true
		_note(tr("%s removida do baralho.") % tr(card.data.name))
		Sfx.hit()
		_refresh_services()
		_commit_undo(snap, tr("a remoção de %s") % tr(card.data.name)))

func _on_booster() -> void:
	if booster_this_visit or GameState.gold < _p(BOOSTER_PRICE) or SceneRouter.has_overlay():
		return
	Sfx.select()
	var snap := _snap()
	var cards: Array[CardInstance] = []
	var pool := CardDB.shop_pool()
	for i in 3:
		if pool.is_empty():
			break
		var pick := pool[GameState.rng.randi_range(0, pool.size() - 1)]
		pool.erase(pick)
		var ed := GameState.roll_edition(pick)   # 0.13.0: o booster também pode trazer edições (sem custo a mais)
		cards.append(CardDB.new_instance(pick.id, {"id": pick.id, "edition": ed} if ed != "" else {}))
		if ed != "":
			_edition_tip()
	ZoneViewer.open(tr("BOOSTER — escolhe 1 de 3"), cards, false, func(card: CardInstance):
		if booster_this_visit or not GameState.spend_gold(_p(BOOSTER_PRICE)):
			return
		booster_this_visit = true
		var infected := GameState.stake >= 6 and GameState.rng.randf() < INFECTION_CHANCE
		var ed := card.edition()
		GameState.add_card(card.data.id, infected, ed)
		var nm := tr(card.data.name) + ((" (%s)" % EffectResolver.edition_name(ed)) if ed != "" else "")
		if infected:
			_note(tr("%s juntou-se ao baralho — INFETADA: Poder a dobrar, exila-se ao fim de %d utilizações.") % [nm, BattleManager.INFECTED_USES])
		else:
			_note(tr("%s juntou-se ao baralho.") % nm)
		Sfx.boom()
		_refresh_offer_buttons()
		_commit_undo(snap, tr("o booster (%s)") % nm))

func _on_reroll() -> void:
	var price := _reroll_price()
	if not GameState.spend_gold(price):
		return
	rerolls += 1
	Sfx.select()
	_undo = {}   # 0.15.0: as ofertas mudaram — o que havia para desfazer fica para trás
	_refresh_undo()
	_roll_offers()
	_build_offers()

# --- 0.15.0: Constelação e DESFAZER ---

## Constelação: sobe 1 nível a uma formação à escolha (uma por visita, fora do Mercador Cego). Tocar abre a
## escolha; o ouro só sai quando se escolhe a formação (cancelar não custa nada).
func _add_constellation_offer() -> void:
	if merchant or CardDB.formations.is_empty():
		return
	var price := _p(CONSTELLATION_PRICE)
	var btn := _offer_button(tr("⁂ Constelação  (%d ouro)") % price + "\n" + tr("Sobe 1 nível a uma formação à tua escolha: mais Mult sempre que a fizeres, até ao fim da run."), price)
	btn.name = "ConstellationOffer"
	btn.set_meta("price", price)
	btn.set_meta("kind", "constellation")
	UiKit.wrap_label(btn).add_theme_color_override("font_color", Color(1.0, 0.9, 0.6))
	btn.pressed.connect(func():
		if SceneRouter.has_overlay() or bool(btn.get_meta("bought", false)) or GameState.gold < price:
			return
		_clear_confirm()
		Sfx.select()
		FormationPicker.open(func(fid: String): _buy_constellation(btn, fid, price)))
	cards_box.add_child(btn)
	if "constellation" in _bought_keys:
		_mark_bought(btn)

func _buy_constellation(btn: Button, fid: String, price: int) -> void:
	if not is_instance_valid(btn) or bool(btn.get_meta("bought", false)):
		return
	var snap := _snap()
	if not GameState.spend_gold(price) or not GameState.level_up_formation(fid):
		return
	_bought_keys.append("constellation")
	Sfx.boom()
	_mark_bought(btn)
	var f := CardDB.get_formation(fid)
	var lvl := GameState.formation_level(fid)
	_note(tr("%s sobe ao nível %d: +%s Mult sempre que a fizeres.") % [tr(String(f.get("name", ""))), lvl, Cascade.fmt_mult(FormationPicker.mult_at(f, lvl))])
	_commit_undo(snap, tr("a Constelação (%s)") % tr(String(f.get("name", ""))))

## Fotografia da run e da loja antes de uma compra ou serviço (para o DESFAZER).
func _snap() -> Dictionary:
	return {"gs": GameState.shop_snapshot(), "shop": {
		"removed": removed_this_visit, "upgraded": upgraded_this_visit, "max_hp": max_hp_this_visit,
		"booster": booster_this_visit, "sealed": sealed_this_visit, "bought": _bought_keys.duplicate(),
		"cards": _bought_cards.duplicate(), "relics": _bought_relics.duplicate()}}

## A compra ou o serviço aconteceu: o DESFAZER passa a desfazê-lo (só o último).
func _commit_undo(snap: Dictionary, what: String) -> void:
	snap["what"] = what
	_undo = snap
	_refresh_undo()

func _refresh_undo() -> void:
	undo_btn.disabled = _undo.is_empty()
	undo_btn.tooltip_text = tr("Desfaz %s.") % String(_undo.get("what", "")) if not _undo.is_empty() \
		else tr("Desfaz a última compra, serviço ou venda desta visita.")

## ↩ DESFAZER: a run e a loja voltam a estar como antes da última compra, serviço ou venda.
func _on_undo() -> void:
	if _undo.is_empty() or SceneRouter.has_overlay():
		return
	var s: Dictionary = _undo
	_undo = {}
	_clear_confirm()
	GameState.restore_shop_snapshot(s.get("gs", {}))
	var l: Dictionary = s.get("shop", {})
	removed_this_visit = bool(l.get("removed", false))
	upgraded_this_visit = bool(l.get("upgraded", false))
	max_hp_this_visit = bool(l.get("max_hp", false))
	booster_this_visit = bool(l.get("booster", false))
	sealed_this_visit = bool(l.get("sealed", false))
	_bought_keys.assign(l.get("bought", []))
	_bought_cards.assign(l.get("cards", []))
	_bought_relics.assign(l.get("relics", []))
	_build_offers()
	_on_gold_changed(GameState.gold)
	_note(tr("Desfeito: %s.") % String(s.get("what", "")))
	Sfx.select()
	_refresh_undo()

func _on_continue() -> void:
	GameState.next_ante()
	GameState.save_run({}, "map")
	SceneRouter.go("map")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		Sfx.select()   # na loja o botão "retroceder" não faz nada de destrutivo
