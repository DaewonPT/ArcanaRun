class_name ShopCardTile
extends Control
## 0.16.0 (V14): uma carta à venda na loja como carta a sério (o visual «Arte em destaque», com a ilustração),
## com o preço numa etiqueta por baixo (moeda; vermelho se o ouro não chega). Tocar escolhe — a carta sobe e o
## preço passa a COMPRAR; manter o dedo mostra-a em grande. Comprada, fica apagada com o carimbo VENDIDO (V22).
## Ao renovar as ofertas (V23) vira-se: mostra as tuas costas e volta com a carta nova.

signal tapped(tile: ShopCardTile)
signal buy_pressed(tile: ShopCardTile)

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const LIFT := 14.0
const GAP := 8.0
const BUY_H := 40.0
const SCALE := 1.25           # na loja as cartas são um pouco maiores do que na mão

var card: CardInstance
var price := 0
var key := ""
var bought := false
var view: CardView
var buy_btn: Button
var _price_row: HBoxContainer
var _back: CardBack
var _selected := false
var _affordable := true
var _card_size := CardView.SIZE_NORMAL

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_PASS

func setup(p_card: CardInstance, p_price: int, p_key: String, why: String = "") -> void:
	card = p_card
	price = p_price
	key = p_key
	_card_size = (CardView.SIZE_NORMAL * SCALE).round()
	custom_minimum_size = Vector2(_card_size.x, LIFT + _card_size.y + GAP + BUY_H)
	set_meta("kind", "card")
	set_meta("price", price)
	view = CARD_VIEW.instantiate()
	view.name = "Card"
	view.select_chip = ""
	view.size_scale = SCALE
	add_child(view)
	view.setup(card)
	if why != "":
		view.set_synergy(why)
	view.pressed.connect(func(_c): tapped.emit(self))
	view.long_pressed.connect(func(c):
		if not SceneRouter.has_overlay():
			CardZoom.show_card(c))
	_price_row = UiKit.price(price, true, 19)
	_price_row.alignment = BoxContainer.ALIGNMENT_CENTER
	_price_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_price_row)
	buy_btn = UiKit.button("", int(BUY_H), 16, UiKit.PRIMARY)
	buy_btn.name = "Buy"
	buy_btn.set_meta("haptic", true)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 6)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	buy_btn.add_child(row)
	row.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bl := UiKit.label(tr("COMPRAR"), 16, Color.WHITE)
	bl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(bl)
	var bp := UiKit.price(price, true, 16)
	(bp.get_meta("label") as Label).add_theme_color_override("font_color", Color.WHITE)
	row.add_child(bp)
	UiKit.gold_plate(buy_btn, true)
	buy_btn.visible = false
	buy_btn.pressed.connect(func(): buy_pressed.emit(self))
	add_child(buy_btn)
	_layout()
	resized.connect(_layout)

func _layout() -> void:
	if view == null:
		return
	var cx := (size.x - _card_size.x) * 0.5
	view.size = _card_size
	view.position = Vector2(cx, 0.0 if _selected else LIFT)
	if _back != null:
		_back.size = _card_size
		_back.position = view.position
	var by := LIFT + _card_size.y + GAP
	_price_row.reset_size()
	_price_row.position = Vector2((size.x - _price_row.size.x) * 0.5, by + (BUY_H - _price_row.size.y) * 0.5)
	buy_btn.size = Vector2(maxf(_card_size.x, 120.0), BUY_H)
	buy_btn.position = Vector2((size.x - buy_btn.size.x) * 0.5, by)

func is_selected() -> bool:
	return _selected

func set_selected(on: bool) -> void:
	if bought:
		on = false
	if on == _selected:
		return
	_selected = on
	view.set_selected(on, true)
	_price_row.visible = not on
	buy_btn.visible = on
	buy_btn.disabled = not _affordable
	var y := 0.0 if on else LIFT
	if Settings.motion_ok() and Settings.anim_scale() > 0.0 and is_inside_tree():
		var tw := create_tween()
		tw.tween_property(view, "position:y", y, Settings.dur(0.12)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	else:
		view.position.y = y

func set_affordable(on: bool) -> void:
	_affordable = on
	UiKit.set_price(_price_row, price, on)
	buy_btn.disabled = not on
	if not bought:
		view.modulate = Color.WHITE if on else Color(0.78, 0.76, 0.82)

func mark_bought(animate: bool = true) -> void:
	bought = true
	set_meta("bought", true)
	if _selected:
		_selected = false
		view.set_selected(false, true)
		view.position.y = LIFT
	buy_btn.visible = false
	_price_row.visible = false
	view.modulate = Color(0.5, 0.48, 0.56)
	var c := view.position + _card_size * 0.5
	SoldStamp.stamp(self, true, animate, Rect2(c - Vector2(66, 24), Vector2(132, 48)))

## V23: vira a carta (para as costas, ou das costas para a frente) em 2 × d segundos.
func flip(to_back: bool, d: float) -> void:
	if _back == null:
		_back = CardBack.new()
		_back.name = "Back"
		_back.back_id = Settings.card_back
		_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_back.visible = false
		add_child(_back)
		_layout()
	var a: Control = view if to_back else _back
	var b: Control = _back if to_back else view
	if d <= 0.0 or not is_inside_tree():
		a.visible = false
		b.visible = true
		b.scale = Vector2.ONE
		return
	for n in [a, b]:
		(n as Control).pivot_offset = _card_size * 0.5
	var tw := create_tween()
	tw.tween_property(a, "scale:x", 0.0, d).set_ease(Tween.EASE_IN)
	await tw.finished
	if not is_instance_valid(a) or not is_instance_valid(b):
		return
	a.visible = false
	a.scale = Vector2.ONE
	b.visible = true
	b.scale = Vector2(0.0, 1.0)
	var t2 := create_tween()
	t2.tween_property(b, "scale:x", 1.0, d).set_ease(Tween.EASE_OUT)
	await t2.finished

## Começa virada para baixo (as ofertas novas viram-se a seguir).
func start_on_back() -> void:
	await flip(true, 0.0)
