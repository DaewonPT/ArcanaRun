class_name ShopCardTile
extends Control
## 0.16.0 (V14): uma carta à venda na loja como carta a sério (o visual «Arte em destaque», com a ilustração),
## com o preço numa etiqueta por baixo (moeda; vermelho se o ouro não chega). Tocar escolhe — a carta sobe e o
## preço passa a COMPRAR; manter o dedo mostra-a em grande. Comprada, fica apagada com o carimbo VENDIDO (V22).
## Ao renovar as ofertas (V23) vira-se: mostra as tuas costas e volta com a carta nova.

signal tapped(tile: ShopCardTile)
signal buy_pressed(tile: ShopCardTile)
signal reserve_pressed(tile: ShopCardTile)   # 0.19.0 (79)

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const LIFT := 14.0
const GAP := 8.0
const BUY_H := 40.0
const SCALE := 1.25           # na loja as cartas são um pouco maiores do que na mão

var card: CardInstance
## 0.19.0 (10): as cartas à venda (para passar à seguinte na carta em grande).
var zoom_list: Callable = Callable()
var price := 0
var key := ""
var bought := false
var reserved := false              # 0.19.0 (79): reservada para a próxima loja
var can_reserve := false           # mostra o cadeado quando está escolhida
var view: CardView
var reserve_btn: Button
var buy_btn: Button
var _price_row: HBoxContainer
var _back: CardBack
var _selected := false
var _affordable := true
var _card_size := CardView.SIZE_NORMAL

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_PASS

func setup(p_card: CardInstance, p_price: int, p_key: String, why: String = "") -> void:
	card = p_card
	price = p_price
	key = p_key
	_card_size = (CardView.SIZE_NORMAL * SCALE).round()
	custom_minimum_size = Vector2(_card_size.x, LIFT + _card_size.y + GAP + BUY_H)
	set_meta("kind", "card")
	set_meta("price", price)
	view = CARD_VIEW.instantiate()
	view.name = "Card"
	view.select_chip = ""
	view.size_scale = SCALE
	add_child(view)
	view.setup(card)
	if why != "":
		view.set_synergy(why)
	view.pressed.connect(func(_c): tapped.emit(self))
	view.long_pressed.connect(func(c):
		if not SceneRouter.has_overlay():
			CardZoom.show_card_in(c, zoom_list.call() if zoom_list.is_valid() else []))   # 0.19.0 (10)
	_price_row = UiKit.price(price, true, 19)
	_price_row.alignment = BoxContainer.ALIGNMENT_CENTER
	_price_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_price_row)
	buy_btn = UiKit.button("", int(BUY_H), 16, UiKit.PRIMARY)
	buy_btn.name = "Buy"
	buy_btn.set_meta("haptic", true)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 6)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	buy_btn.add_child(row)
	row.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bl := UiKit.label(tr("COMPRAR"), 16, Color.WHITE)
	bl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(bl)
	var bp := UiKit.price(price, true, 16)
	(bp.get_meta("label") as Label).add_theme_color_override("font_color", Color.WHITE)
	row.add_child(bp)
	UiKit.gold_plate(buy_btn, true)
	buy_btn.visible = false
	buy_btn.pressed.connect(func(): buy_pressed.emit(self))
	add_child(buy_btn)
	# 0.19.0 (79): reservar (o cadeado no canto da carta escolhida).
	reserve_btn = Button.new()
	reserve_btn.name = "Reserve"
	reserve_btn.focus_mode = Control.FOCUS_NONE
	reserve_btn.custom_minimum_size = Vector2(BUY_H, BUY_H)
	reserve_btn.size = Vector2(BUY_H, BUY_H)
	reserve_btn.tooltip_text = tr("Reservar para a próxima loja (%d ouro).") % Economy.RESERVE_PRICE
	for st in ["normal", "hover", "pressed", "disabled"]:
		reserve_btn.add_theme_stylebox_override(st, UiKit.flat(Color(0.12, 0.1, 0.2, 0.92 if st == "normal" else 1.0), 12, Color(0.85, 0.8, 1.0, 0.7), 2, 0))
	var ic := CardIcon.new("lock", Color(0.92, 0.88, 1.0), 20.0)
	ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	reserve_btn.add_child(ic)
	ic.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	ic.offset_left = -10
	ic.offset_right = 10
	ic.offset_top = -10
	ic.offset_bottom = 10
	reserve_btn.visible = false
	reserve_btn.pressed.connect(func(): reserve_pressed.emit(self))
	add_child(reserve_btn)
	_layout()
	resized.connect(_layout)

func _layout() -> void:
	if view == null:
		return
	var cx := (size.x - _card_size.x) * 0.5
	view.size = _card_size
	view.position = Vector2(cx, 0.0 if _selected else LIFT)
	if _back != null:
		_back.size = _card_size
		_back.position = view.position
	var by := LIFT + _card_size.y + GAP
	_price_row.reset_size()
	_price_row.position = Vector2((size.x - _price_row.size.x) * 0.5, by + (BUY_H - _price_row.size.y) * 0.5)
	# 0.19.0 (79): com o cadeado de reservar, o COMPRAR encolhe e o cadeado fica ao lado dele.
	var with_lock := reserve_btn != null and reserve_btn.visible
	var bw := maxf(_card_size.x, 120.0) - (BUY_H + 4.0 if with_lock else 0.0)
	buy_btn.size = Vector2(bw, BUY_H)
	buy_btn.position = Vector2((size.x - bw - (BUY_H + 4.0 if with_lock else 0.0)) * 0.5, by)
	if reserve_btn != null:
		reserve_btn.position = Vector2(buy_btn.position.x + bw + 4.0, by)

func is_selected() -> bool:
	return _selected

func set_selected(on: bool) -> void:
	if bought:
		on = false
	if on == _selected:
		return
	_selected = on
	view.set_selected(on, true)
	_price_row.visible = not on
	buy_btn.visible = on
	buy_btn.disabled = not _affordable
	if reserve_btn != null:
		reserve_btn.visible = on and can_reserve and not reserved
		reserve_btn.disabled = GameState.gold < Economy.RESERVE_PRICE
	_layout()
	var y := 0.0 if on else LIFT
	if Settings.motion_ok() and Settings.anim_scale() > 0.0 and is_inside_tree():
		var tw := create_tween()
		tw.tween_property(view, "position:y", y, Settings.dur(0.12)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	else:
		view.position.y = y

func set_affordable(on: bool) -> void:
	_affordable = on
	UiKit.set_price(_price_row, price, on)
	buy_btn.disabled = not on
	UiKit.explain(buy_btn, func() -> String: return "" if bought else UiKit.why_gold(price))   # 0.19.0 (121)
	if not bought:
		view.modulate = Color.WHITE if on else Color(0.78, 0.76, 0.82)

func mark_bought(animate: bool = true) -> void:
	bought = true
	set_meta("bought", true)
	if _selected:
		_selected = false
		view.set_selected(false, true)
		view.position.y = LIFT
	buy_btn.visible = false
	if reserve_btn != null:
		reserve_btn.visible = false
	_price_row.visible = false
	view.modulate = Color(0.5, 0.48, 0.56)
	var c := view.position + _card_size * 0.5
	SoldStamp.stamp(self, true, animate, Rect2(c - Vector2(66, 24), Vector2(132, 48)))

## 0.19.0 (80): o preço sem o desconto, riscado ao lado do preço.
func set_old_price(old: int) -> void:
	UiKit.set_old_price(_price_row, old, price)

## 0.19.0 (79): uma etiqueta pequena por cima da carta («RESERVADA»).
func set_note(text: String) -> void:
	var p := PanelContainer.new()
	p.name = "Note"
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_theme_stylebox_override("panel", UiKit.flat(Color(0.3, 0.2, 0.55), 8, Color(0.85, 0.75, 1.0), 1, 3))
	p.add_child(UiKit.label(text, 12, Color.WHITE))
	add_child(p)
	p.position = Vector2((size.x - 90.0) * 0.5 if size.x > 0.0 else 8.0, LIFT + 4.0)

## 0.19.0 (79): reservada nesta loja para a seguinte — apagada, com o carimbo RESERVADA.
func mark_reserved(animate: bool = true) -> void:
	reserved = true
	set_meta("bought", true)
	if _selected:
		_selected = false
		view.set_selected(false, true)
		view.position.y = LIFT
	buy_btn.visible = false
	if reserve_btn != null:
		reserve_btn.visible = false
	_price_row.visible = false
	view.modulate = Color(0.55, 0.52, 0.66)
	var c := view.position + _card_size * 0.5
	SoldStamp.stamp(self, true, animate, Rect2(c - Vector2(70, 24), Vector2(140, 48)), "RESERVADA")

## V23: vira a carta (para as costas, ou das costas para a frente) em 2 × d segundos.
func flip(to_back: bool, d: float) -> void:
	if _back == null:
		_back = CardBack.new()
		_back.name = "Back"
		_back.back_id = GameState.run_back()
		_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_back.visible = false
		add_child(_back)
		_layout()
	var a: Control = view if to_back else _back
	var b: Control = _back if to_back else view
	if d <= 0.0 or not is_inside_tree():
		a.visible = false
		b.visible = true
		b.scale = Vector2.ONE
		return
	for n in [a, b]:
		(n as Control).pivot_offset = _card_size * 0.5
	var tw := create_tween()
	tw.tween_property(a, "scale:x", 0.0, d).set_ease(Tween.EASE_IN)
	await tw.finished
	if not is_instance_valid(a) or not is_instance_valid(b):
		return
	a.visible = false
	a.scale = Vector2.ONE
	b.visible = true
	b.scale = Vector2(0.0, 1.0)
	var t2 := create_tween()
	t2.tween_property(b, "scale:x", 1.0, d).set_ease(Tween.EASE_OUT)
	await t2.finished

## Começa virada para baixo (as ofertas novas viram-se a seguir).
func start_on_back() -> void:
	await flip(true, 0.0)
