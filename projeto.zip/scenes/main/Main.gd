class_name MainMenu
extends Control
## Menu principal, arrumado em 3 páginas para não haver botões a mais no ecrã:
##  • Início: CONTINUAR (só com uma run gravada, diz qual é), NOVO JOGO (campanha), MODOS DE JOGO ›,
##    COLEÇÃO ›, e por baixo COMO JOGAR e CONFIGURAÇÕES.
##  • Modos de jogo: História, Desafios, Modo Livre, Arena Draft, Quebra-cabeças e Treino — cada um com
##    uma linha a explicar e o progresso (capítulos, medalhas, enigmas).
##  • Coleção: cartas e relíquias, construtor de baralhos e estatísticas.
## A dificuldade está no ecrã da campanha e nas Configurações (Jogo). Ao lado da versão: NOVIDADES e
## SAIR; as Novidades abrem sozinhas depois de uma atualização. O "retroceder" do Android numa página
## volta ao início; no início sai do jogo.

const PAGE_MAIN := "main"
const PAGE_MODES := "modes"
const PAGE_COLLECTION := "collection"

## Página a mostrar quando se volta ao menu: quem sai de um modo volta à lista dos modos.
static var return_page := PAGE_MAIN

@onready var title_label: Label = %Title
@onready var subtitle: Label = %Subtitle
@onready var buttons: VBoxContainer = %Buttons

var continue_btn: Button
var _pages: Dictionary = {}   # nome da página → VBoxContainer
var _page := PAGE_MAIN
var _update_btn: Button
var _page_tween: Tween
var _unique: Array = []       # botões a registar como %Nome depois de entrarem na árvore

func _ready() -> void:
	var start := return_page if return_page in [PAGE_MAIN, PAGE_MODES, PAGE_COLLECTION] else PAGE_MAIN
	return_page = PAGE_MAIN
	_page = start
	_build_pages()
	# Novidades e Sair, lado a lado por baixo da versão.
	var quit: Button = %Quit
	var left: Control = quit.get_parent()
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	left.add_child(row)
	left.move_child(row, quit.get_index())
	var news := UiKit.button(tr("NOVIDADES"), 48, 18)
	news.custom_minimum_size.x = 170
	news.pressed.connect(func():
		if not SceneRouter.has_overlay():
			Sfx.select()
			NewsOverlay.open())
	row.add_child(news)
	left.remove_child(quit)
	row.add_child(quit)
	quit.pressed.connect(func(): get_tree().quit())
	Settings.changed.connect(_build_pages)   # idioma novo: refaz os textos
	AppUpdate.update_available.connect(_show_update)
	if not AppUpdate.info.is_empty():
		_show_update(AppUpdate.info)
	_animate_in()
	if not SceneRouter.has_overlay():
		NewsOverlay.maybe_show()

# --- Páginas ---

func _build_pages() -> void:
	for c in buttons.get_children():
		buttons.remove_child(c)
		c.queue_free()
	_pages.clear()
	_unique.clear()
	_pages[PAGE_MAIN] = _main_page()
	_pages[PAGE_MODES] = _modes_page()
	_pages[PAGE_COLLECTION] = _collection_page()
	for key in _pages:
		var page: Control = _pages[key]
		buttons.add_child(page)
		page.visible = key == _page
	# O dono tem de ser um antepassado: só depois de as páginas estarem na árvore.
	for n in _unique:
		(n as Node).owner = self
		(n as Node).unique_name_in_owner = true
	_unique.clear()

func _main_page() -> VBoxContainer:
	var page := _new_page()
	var saved := GameState.has_saved_run()
	continue_btn = _tile("CONTINUAR", GameState.saved_run_summary(), "▶", true, 80)
	continue_btn.name = "Continue"
	continue_btn.visible = saved
	continue_btn.pressed.connect(_on_continue)
	page.add_child(continue_btn)
	var new_game := _tile("NOVO JOGO", tr("Campanha: escolhe um dos 18 baralhos e sobe os Selos Planares."), "", not saved, 80 if not saved else 68)
	new_game.name = "NewGame"
	new_game.pressed.connect(func(): _launch("campaign", false))
	page.add_child(new_game)
	var modes := _tile("MODOS DE JOGO", tr("Escola do Mago, História, Desafios, Treino e mais."), "›")
	modes.name = "Modes"
	modes.pressed.connect(func(): Sfx.select(); _show_page(PAGE_MODES))
	page.add_child(modes)
	var collection := _tile("COLEÇÃO", tr("Talentos, cartas, construtor de baralhos e estatísticas."), "›")
	collection.name = "CollectionPage"
	collection.pressed.connect(func(): Sfx.select(); _show_page(PAGE_COLLECTION))
	page.add_child(collection)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	page.add_child(row)
	var howto := UiKit.button(tr("COMO JOGAR"), 54, 19)
	howto.name = "HowTo"
	howto.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	howto.pressed.connect(func(): Sfx.select(); SceneRouter.go("howto"))
	row.add_child(howto)
	var settings := UiKit.button(tr("CONFIGURAÇÕES"), 54, 19)
	settings.name = "Settings"
	settings.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	settings.pressed.connect(_on_settings)
	row.add_child(settings)
	_mark_unique([continue_btn, new_game, modes, collection, howto, settings])
	return page

func _modes_page() -> VBoxContainer:
	var page := _new_page(8)
	page.add_child(_page_header("MODOS DE JOGO"))
	var entries := [
		["School", "ESCOLA DO MAGO", "Seis lições curtas e jogáveis para aprender as mecânicas.", _count_done(CardDB.lessons, GameState.lesson_done), "school", false],
		["Saga", "HISTÓRIA", "Cinco capítulos curtos, um por cor, com bosses que falam.", _count_done(CardDB.saga, GameState.saga_done), "saga", true],
		["Challenges", "DESAFIOS", "Runs com uma regra especial. Vence para ganhar a medalha.", _count_done(CardDB.challenges, GameState.challenge_done), "challenges", true],
		["FreeMode", "MODO LIVRE", "Qualquer baralho, também os teus. Não conta para a campanha.", "", "campaign", true],
		["Draft", "ARENA DRAFT", "Monta o baralho na hora, a abrir boosters.", "", "draft", true],
		["Puzzles", "QUEBRA-CABEÇAS", "Um turno com a mão fixa: encontra o golpe certo.", _count_done(CardDB.puzzles, Stats.is_puzzle_solved), "puzzles", false],
		["Training", "TREINO", "Testa combos contra um boneco de vida infinita.", "", "training", false],
	]
	var made: Array = []
	for e in entries:
		var b := _tile(String(e[1]), tr(String(e[2])), String(e[3]), false, 56)
		b.name = String(e[0])
		var scene := String(e[4])
		var free := bool(e[5])
		b.pressed.connect(func(): _launch(scene, free, PAGE_MODES))
		page.add_child(b)
		made.append(b)
	_mark_unique(made)
	return page

func _collection_page() -> VBoxContainer:
	var page := _new_page(10)
	page.add_child(_page_header("COLEÇÃO"))
	var ach := "%d/%d" % [Stats.unlocked_count(), CardDB.achievements.size()]
	var entries := [
		["Talents", "TALENTOS", "Vantagens permanentes, pagas com os pontos das runs.", tr("%d pts") % GameState.talent_points(), "talents", false],
		["Collection", "CARTAS E RELÍQUIAS", "Tudo o que já descobriste: cartas, relíquias e inimigos.", "", "collection", false],
		["Builder", "CONSTRUTOR DE BARALHOS", "Cria até 6 baralhos teus para jogar no Modo Livre.", "", "builder", true],
		["Stats", "ESTATÍSTICAS", "Recordes, conquistas e desbloqueios.", ach, "stats", false],
	]
	var made: Array = []
	for e in entries:
		var b := _tile(String(e[1]), tr(String(e[2])), String(e[3]), false, 66)
		b.name = String(e[0])
		var scene := String(e[4])
		var free := bool(e[5])
		b.pressed.connect(func(): _launch(scene, free, PAGE_COLLECTION))
		page.add_child(b)
		made.append(b)
	_mark_unique(made)
	return page

func _new_page(separation: int = 12) -> VBoxContainer:
	var page := VBoxContainer.new()
	page.add_theme_constant_override("separation", separation)
	page.alignment = BoxContainer.ALIGNMENT_CENTER
	return page

## Cabeçalho das páginas de dentro: ◀ VOLTAR e o título.
func _page_header(title: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	var back := UiKit.button(tr("◀ VOLTAR"), 48, 18)
	back.name = "Back"
	back.custom_minimum_size.x = 140
	back.pressed.connect(func(): Sfx.select(); _show_page(PAGE_MAIN))
	row.add_child(back)
	var t := UiKit.label(tr(title), 24, UiKit.GOLD)
	t.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(t)
	return row

## Botão grande: título, uma linha a explicar e, à direita, um contador ou uma seta.
func _tile(title: String, desc: String, side: String = "", primary: bool = false, height: int = 66) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(0, height)
	b.focus_mode = Control.FOCUS_NONE
	var bg: Color = UiKit.PRIMARY if primary else UiKit.BTN_BG
	b.add_theme_stylebox_override("normal", UiKit.flat(bg, 14))
	b.add_theme_stylebox_override("hover", UiKit.flat(bg.lightened(0.07), 14))
	b.add_theme_stylebox_override("pressed", UiKit.flat(bg.lightened(0.16), 14))
	b.add_theme_stylebox_override("disabled", UiKit.flat(bg.darkened(0.35), 14))
	var row := HBoxContainer.new()
	row.set_anchors_preset(Control.PRESET_FULL_RECT)
	row.offset_left = 20
	row.offset_right = -18
	row.offset_top = 4
	row.offset_bottom = -4
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 10)
	b.add_child(row)
	var texts := VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.alignment = BoxContainer.ALIGNMENT_CENTER
	texts.mouse_filter = Control.MOUSE_FILTER_IGNORE
	texts.add_theme_constant_override("separation", 0)
	row.add_child(texts)
	var t := UiKit.label(tr(title), 22 if primary else 20, Color.WHITE)
	t.name = "TileTitle"
	t.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	texts.add_child(t)
	if desc != "":
		var d := UiKit.label(desc, 14, Color(1, 1, 1, 0.82) if primary else UiKit.TEXT_DIM)
		d.name = "TileDesc"
		d.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		texts.add_child(d)
	if side != "":
		var s := UiKit.label(side, 26 if side in ["›", "▶"] else 18, Color.WHITE if primary else UiKit.GOLD)
		s.theme_type_variation = &""
		s.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(s)
	return b

## "feitos/total" de uma lista de dados (capítulos, desafios, enigmas).
func _count_done(list: Array, is_done: Callable) -> String:
	if list.is_empty():
		return ""
	var done := 0
	for item in list:
		if item is Dictionary and is_done.call(String(item.get("id", ""))):
			done += 1
	return "%d/%d" % [done, list.size()]

## Os botões feitos em código também ficam acessíveis por %Nome (testes e capturas).
func _mark_unique(nodes: Array) -> void:
	_unique.append_array(nodes)

func _show_page(key: String, animate: bool = true) -> void:
	if not _pages.has(key) or SceneRouter.has_overlay():
		return
	_page = key
	if _page_tween != null and _page_tween.is_valid():
		_page_tween.kill()
	for k in _pages:
		var p: Control = _pages[k]
		p.visible = k == key
		p.modulate.a = 1.0
	if animate and Settings.motion_ok():
		var page: Control = _pages[key]
		page.modulate.a = 0.0
		_page_tween = create_tween()
		_page_tween.tween_property(page, "modulate:a", 1.0, Settings.dur(0.18))

func current_page() -> String:
	return _page

## Abre um modo; quem vem de uma página de dentro volta para ela ao regressar ao menu.
func _launch(scene: String, free_mode: bool, from_page: String = PAGE_MAIN) -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	return_page = from_page
	GameState.free_mode = free_mode
	SceneRouter.go(scene)

# --- Atualização da app ---

## Há uma versão nova publicada (AppUpdate): botão dourado por baixo do título.
func _show_update(info: Dictionary) -> void:
	if _update_btn != null and is_instance_valid(_update_btn):
		return
	var version := String(info.get("name", "")).trim_prefix("Zero-Sum").strip_edges()
	_update_btn = UiKit.button("⬇  " + tr("NOVA VERSÃO %s — ATUALIZAR") % version, 58, 22, UiKit.PRIMARY, UiKit.GOLD)
	_update_btn.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_update_btn.custom_minimum_size.x = 440
	_update_btn.pressed.connect(_on_update)
	title_label.get_parent().add_child(_update_btn)
	UiKit.pop_in(_update_btn)

func _on_update() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	AppUpdate.open_download()
	var notes := String(AppUpdate.info.get("notes", ""))
	CardZoom.show_text(tr("A transferir a versão nova"), tr("Quando acabar, abre o ficheiro ZeroSum.apk e toca em Instalar. O teu progresso fica.") + ("\n\n" + notes if notes != "" else ""), tr("Atualização"), UiKit.GOLD)

func _on_settings() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	var menu := SettingsMenu.open()
	menu.closed.connect(func():
		if is_instance_valid(continue_btn):
			continue_btn.visible = GameState.has_saved_run())

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		if _page != PAGE_MAIN:
			Sfx.select()
			_show_page(PAGE_MAIN)
		else:
			get_tree().quit()

func _on_continue() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	return_page = PAGE_MAIN
	if GameState.load_run():
		var target := "battle"
		if GameState.saved_scene == "shop":
			target = "shop"
		elif GameState.saved_scene == "event" and GameState.pending_event != "":
			target = "event"
		elif GameState.saved_scene == "map":
			target = "map"
		elif GameState.saved_scene == "loot":
			target = "loot"
		SceneRouter.go(target)
	else:
		continue_btn.visible = false

func _animate_in() -> void:
	# Título desce, botões entram um a um.
	title_label.modulate.a = 0.0
	ContentUpdate.check()
	AppUpdate.check()
	await get_tree().process_frame
	title_label.pivot_offset = Vector2(0, title_label.size.y / 2.0)
	title_label.scale = Vector2(0.9, 0.9)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(title_label, "modulate:a", 1.0, 0.5)
	tw.tween_property(title_label, "scale", Vector2.ONE, 0.5).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	if not _pages.has(_page):
		return
	var delay := 0.15
	for b in (_pages[_page] as Control).get_children():
		if not (b as Control).visible:
			continue
		b.modulate.a = 0.0
		var t := create_tween()
		t.tween_interval(delay)
		t.tween_property(b, "modulate:a", 1.0, 0.25)
		delay += 0.07
