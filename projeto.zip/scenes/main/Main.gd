extends Control
## Menu inicial: escolhe a cor de partida e começa a run.

@onready var color_buttons: HBoxContainer = %ColorButtons

func _ready() -> void:
	for btn in color_buttons.get_children():
		btn.pressed.connect(_on_color_pressed.bind(btn.name.to_lower()))

func _on_color_pressed(color: String) -> void:
	GameState.new_run(color)
	SceneRouter.go("battle")
