class_name MainMenu
extends Control
## Menu principal, arrumado em páginas para não haver botões a mais no ecrã:
##  • Início: CONTINUAR (a run gravada há menos tempo, diz qual é), NOVO JOGO ›, JOGOS GUARDADOS ›,
##    APRENDER E TREINAR ›, COLEÇÃO ›, e por baixo COMO JOGAR e CONFIGURAÇÕES.
##  • Novo jogo (0.12.0): o modo — Campanha, Run Rápida, Modo Livre, Arena Draft, História e Desafios —
##    e depois o espaço onde a run fica gravada (SlotPicker).
##  • Jogos guardados (0.12.0): os 6 espaços — continuar, mudar o nome ou apagar.
##  • Aprender e treinar: Escola do Mago, Quebra-cabeças e Treino.
##  • Coleção: talentos, cartas e relíquias, construtor de baralhos e estatísticas.
## A dificuldade está no ecrã da campanha e nas Configurações (Jogo). Ao lado da versão: NOVIDADES, SOBRE
## (0.18.0: créditos, contactos, reportar um erro, privacidade) e SAIR; as Novidades abrem sozinhas depois
## de uma atualização. O "retroceder" do Android numa página
## volta ao início; no início sai do jogo.

const PAGE_MAIN := "main"
const PAGE_NEW := "new"
const PAGE_SAVES := "saves"
const PAGE_MODES := "modes"
const PAGE_COLLECTION := "collection"
const PAGES := [PAGE_MAIN, PAGE_NEW, PAGE_SAVES, PAGE_MODES, PAGE_COLLECTION]

## Página a mostrar quando se volta ao menu: quem sai de um modo volta à lista dos modos.
static var return_page := PAGE_MAIN

## 0.13.1 (visual "Grimório dourado"): título em New Rocker, dourado, e botões como placas.
const TITLE_FONT := preload("res://assets/fonts/NewRocker-Regular.ttf")
const TITLE_SHADER := preload("res://assets/shaders/title_gold.gdshader")
const TITLE_SIZE := 104
const PLAQUE_BORDER := Color(0.97, 0.84, 0.5, 0.5)
## Medalhões (ilustrações do mapa) nos botões da página inicial.
const TILE_ART := {"NewGame": "scout", "Saves": "vault", "Modes": "library", "CollectionPage": "treasure"}

@onready var title_label: Label = %Title
@onready var subtitle: Label = %Subtitle
@onready var buttons: VBoxContainer = %Buttons

var continue_btn: Button
var _pages: Dictionary = {}   # nome da página → VBoxContainer
var _page := PAGE_MAIN
var _update_btn: Button
var _page_tween: Tween
var _unique: Array = []       # botões a registar como %Nome depois de entrarem na árvore
var _preselected_slot := 0    # espaço vazio tocado em JOGOS GUARDADOS: o jogo novo fica lá
var _armed_delete := 0        # espaço à espera do 2.º toque em APAGAR

func _ready() -> void:
	# 0.12.0: fundo animado (aurora, estrelas, orbes de mana e cartas fantasma).
	var backdrop := MenuBackdrop.new()
	backdrop.name = "MenuBackdrop"
	backdrop.title_node = title_label   # 0.13.1: o círculo de runas fica atrás do título
	add_child(backdrop)
	move_child(backdrop, get_node("Glow").get_index() + 1)
	_style_title()
	var start := return_page if return_page in PAGES else PAGE_MAIN
	return_page = PAGE_MAIN
	_page = start
	_build_pages()
	# Novidades e Sair, lado a lado por baixo da versão.
	var quit: Button = %Quit
	var left: Control = quit.get_parent()
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	left.add_child(row)
	left.move_child(row, quit.get_index())
	var news := UiKit.button(tr("NOVIDADES"), 48, 18)
	news.custom_minimum_size.x = 170
	news.pressed.connect(func():
		if not SceneRouter.has_overlay():
			Sfx.select()
			NewsOverlay.open())
	row.add_child(news)
	# 0.18.0: SOBRE — créditos, contactos, reportar um erro, privacidade e licenças.
	var about := UiKit.button(tr("SOBRE"), 48, 18)
	about.name = "About"
	about.custom_minimum_size.x = 130
	about.pressed.connect(func():
		if not SceneRouter.has_overlay():
			Sfx.select()
			AboutOverlay.open())
	row.add_child(about)
	# 0.19.0 (137): o sino com os últimos avisos.
	var bell := UiKit.button("", 48, 18)
	bell.name = "Bell"
	bell.custom_minimum_size.x = 56
	bell.tooltip_text = tr("Os últimos avisos")
	UiKit.button_icon(bell, "bell", Color(0.95, 0.85, 0.55), 22.0, true)
	bell.pressed.connect(func():
		if not SceneRouter.has_overlay():
			Sfx.select()
			NoticeLog.open())
	row.add_child(bell)
	left.remove_child(quit)
	row.add_child(quit)
	_plaque(news)
	_plaque(about)
	_plaque(quit)
	quit.pressed.connect(func(): get_tree().quit())
	Settings.changed.connect(_build_pages)   # idioma novo: refaz os textos
	AppUpdate.update_available.connect(_show_update)
	if not AppUpdate.info.is_empty():
		_show_update(AppUpdate.info)
	_animate_in()
	if GameState.restored_backup > 0:
		SceneRouter.toast(tr("O progresso estava estragado: recuperámos a cópia de segurança mais recente."))
		GameState.restored_backup = 0
	# 0.16.1 (66): abertura animada na primeira vez que o menu abre (as Novidades esperam por ela).
	var opening := Opening.play_if_first(self)
	var questions := SessionWindows.needs_first_questions() and DisplayServer.get_name() != "headless" and not PerfBench.requested()
	if opening != null:
		opening.finished.connect(func():
			if is_inside_tree() and not SceneRouter.has_overlay():
				if questions:
					SessionWindows.open_first_run()   # 0.19.0 (277, 286): as perguntas do 1.º arranque (antes do tutorial)
				else:
					NewsOverlay.maybe_show())
	elif questions and not SceneRouter.has_overlay():
		SessionWindows.open_first_run()
	elif not SceneRouter.has_overlay() and not PerfBench.requested():
		NewsOverlay.maybe_show()
	SessionWindows.maybe_rules_refresher()   # 0.19.0 (196): depois de um mês sem jogar, as regras em 30 s
	_after_first_frame.call_deferred()
	_hook_dev_taps()   # 0.19.0 (250)

## 0.19.0 (243): o menu aparece primeiro; as Novidades, o lembrete das regras, o aviso de fecho inesperado, os
## shaders da batalha e as miniaturas das cartas vêm logo a seguir ao 1.º frame (246: e mede-se quanto demorou).
func _after_first_frame() -> void:
	await get_tree().process_frame
	if not ErrorReport.boot.has("menu_ms"):
		ErrorReport.boot["menu_ms"] = Time.get_ticks_msec()
	if not is_inside_tree():
		return
	if PerfBench.requested():   # 0.19.0 (251): o teste de desempenho do Actions (emulador)
		PerfBench.run(SceneRouter)
		return
	maybe_crash_offer()
	ShaderWarmup.run(self)   # 0.16.0 (78): prepara os shaders da batalha uma vez por sessão
	ThumbCache.queue_all()   # 0.19.0 (236): no APK, as miniaturas das cartas fazem-se devagar a partir de agora

## 230: o jogo fechou-se sozinho da última vez — oferecer o relatório de erros (uma vez).
func maybe_crash_offer() -> Control:
	if not Storage.crashed_before or SceneRouter.has_overlay() or DisplayServer.get_name() == "headless":
		return null
	Storage.crashed_before = false
	var d := ChoiceDialog.open(tr("O JOGO FECHOU-SE SOZINHO"), tr("Da última vez, o jogo fechou-se de repente. Queres enviar o relatório de erros? Ajuda a encontrar o que falhou (o progresso está guardado)."),
		[[tr("ENVIAR RELATÓRIO"), "send", true], [tr("SÓ COPIAR"), "copy"], [tr("AGORA NÃO"), null]], Color(1.0, 0.62, 0.55))
	d.name = "CrashOffer"
	d.chosen.connect(func(v):
		if v == "send":
			AboutOverlay.send_report()
		elif v == "copy":
			DisplayServer.clipboard_set(ErrorReport.build())
			SceneRouter.toast(tr("Relatório copiado: cola-o numa mensagem para %s.") % AboutOverlay.email()))
	return d

## 250: 5 toques na versão ligam (ou desligam) o modo programador — FPS, comandos de desenho e memória no canto.
var _dev_taps: Array[float] = []

func _hook_dev_taps() -> void:
	var v := get_node_or_null("%Version") as Label
	if v == null:
		return
	v.mouse_filter = Control.MOUSE_FILTER_STOP
	v.gui_input.connect(func(e: InputEvent):
		if (e is InputEventMouseButton and e.pressed and e.button_index == MOUSE_BUTTON_LEFT) or (e is InputEventScreenTouch and e.pressed):
			dev_tap())

func dev_tap() -> void:
	var now := Time.get_ticks_msec() / 1000.0
	var keep: Array[float] = []
	for x in _dev_taps:
		if now - x < 2.5:
			keep.append(x)
	_dev_taps = keep
	_dev_taps.append(now)
	if _dev_taps.size() >= 5:
		_dev_taps.clear()
		var on := not bool(Settings.opt("dev_mode"))
		Settings.set_opt("dev_mode", on)
		SceneRouter.refresh_dev_overlay()
		SceneRouter.toast(tr("Modo programador ligado") if on else tr("Modo programador desligado"), 2.0)

# --- Páginas ---

func _build_pages() -> void:
	for c in buttons.get_children():
		buttons.remove_child(c)
		c.queue_free()
	_pages.clear()
	_unique.clear()
	_pages[PAGE_MAIN] = _main_page()
	_pages[PAGE_NEW] = _new_game_page()
	_pages[PAGE_SAVES] = _saves_page()
	_pages[PAGE_MODES] = _modes_page()
	_pages[PAGE_COLLECTION] = _collection_page()
	for key in _pages:
		var page: Control = _pages[key]
		buttons.add_child(page)
		page.visible = key == _page
	# O dono tem de ser um antepassado: só depois de as páginas estarem na árvore.
	for n in _unique:
		(n as Node).owner = self
		(n as Node).unique_name_in_owner = true
	_unique.clear()

func _main_page() -> VBoxContainer:
	var page := _new_page()
	var latest := GameState.latest_slot()
	var saved := latest > 0
	var cont_desc := ""
	if saved:
		cont_desc = GameState.saved_run_summary(latest) + "  ·  " + GameState.slot_name(latest)
	continue_btn = _tile("CONTINUAR", cont_desc, "▶", true, 80)
	continue_btn.name = "Continue"
	continue_btn.visible = saved
	continue_btn.set_meta("slot", latest)
	continue_btn.pressed.connect(func(): _on_continue(int(continue_btn.get_meta("slot", 0))))
	page.add_child(continue_btn)
	var new_game := _tile("NOVO JOGO", tr("Campanha, Run Rápida, História, Desafios…"), "›", not saved, 80 if not saved else 66, TILE_ART["NewGame"])
	new_game.name = "NewGame"
	new_game.pressed.connect(func(): Sfx.select(); _preselected_slot = 0; _show_page(PAGE_NEW))
	page.add_child(new_game)
	var saves := _tile("JOGOS GUARDADOS", tr("Continua, muda o nome ou apaga as runs a meio."), "%d/%d" % [GameState.saved_slot_count(), GameState.SLOT_COUNT], false, 60, TILE_ART["Saves"])
	saves.name = "Saves"
	saves.pressed.connect(func(): Sfx.select(); _show_page(PAGE_SAVES))
	page.add_child(saves)
	var modes := _tile("APRENDER E TREINAR", tr("Escola do Mago, Quebra-Cabeças e Treino."), "›", false, 60, TILE_ART["Modes"])
	modes.name = "Modes"
	modes.pressed.connect(func(): Sfx.select(); _show_page(PAGE_MODES))
	page.add_child(modes)
	var collection := _tile("COLEÇÃO", tr("Talentos, cartas, construtor de baralhos e estatísticas."), "›", false, 60, TILE_ART["CollectionPage"])
	collection.name = "CollectionPage"
	collection.pressed.connect(func(): Sfx.select(); _show_page(PAGE_COLLECTION))
	page.add_child(collection)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	page.add_child(row)
	# 0.19.0 (178): JOGAR num toque — uma Run Rápida com o último baralho e Selo.
	var play := UiKit.button("▶ " + tr("JOGAR"), 54, 19, UiKit.PRIMARY)
	play.name = "QuickPlay"
	play.custom_minimum_size.x = 150
	play.tooltip_text = quick_play_text()
	play.pressed.connect(_quick_play)
	row.add_child(play)
	var howto := UiKit.button(tr("COMO JOGAR"), 54, 19)
	howto.name = "HowTo"
	howto.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	howto.pressed.connect(func(): Sfx.select(); SceneRouter.go("howto"))
	row.add_child(howto)
	var settings := UiKit.button(tr("CONFIGURAÇÕES"), 54, 19)
	settings.name = "Settings"
	settings.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	settings.pressed.connect(_on_settings)
	row.add_child(settings)
	_plaque(howto)
	_plaque(settings)
	# 0.19.0 (194): o próximo desbloqueio à vista (a conquista mais perto).
	var near := GameState.closest_achievement()
	if not near.is_empty():
		var nl := UiKit.label(tr("Quase: %s (%d/%d)") % [tr(String(near["name"])), int(near["have"]), int(near["need"])], 14, UiKit.TEXT_DIM)
		nl.name = "NextUnlock"
		nl.tooltip_text = tr(String(near.get("text", "")))
		nl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		page.add_child(nl)
	_mark_unique([continue_btn, new_game, saves, modes, collection, howto, settings, play])
	return page

## 178: «Run Rápida · Centelha Rubra · Selo 2» (o que o JOGAR começa).
func quick_play_text() -> String:
	var lc := GameState.last_choice("quick")
	if lc.is_empty():
		lc = GameState.last_choice("_last")
	var deck_id := String(lc.get("deck", "deck01"))
	return tr("Run Rápida") + "  ·  " + tr(String(CardDB.get_deck(deck_id).get("name", ""))) + "  ·  " + tr("Selo %d") % maxi(1, int(lc.get("stake", 1)))

func _quick_play() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.boom()
	var lc := GameState.last_choice("quick")
	if lc.is_empty():
		lc = GameState.last_choice("_last")
	var deck_id := String(lc.get("deck", "deck01"))
	if CardDB.get_deck(deck_id).is_empty():
		deck_id = "deck01"
	var st := clampi(int(lc.get("stake", 1)), 1, GameState.max_stake(deck_id, true))
	GameState.claim_slot_for_new_run()
	GameState.new_quick_run(deck_id, st)
	var v := String(lc.get("variant", "classic"))
	GameState.apply_deck_variant(v if v in GameState.deck_variants(deck_id) else "classic")
	GameState.map_options(1)
	GameState.save_run({}, "map")
	SceneRouter.go("map")

## NOVO JOGO: o modo; a seguir escolhe-se o espaço de gravação (ou fica no espaço vazio tocado em
## JOGOS GUARDADOS) e abre-se o ecrã do modo (baralho, capítulo, desafio ou draft).
func _new_game_page() -> VBoxContainer:
	var page := _new_page(8)
	page.add_child(_page_header("NOVO JOGO"))
	var entries := [
		["Campaign", "CAMPANHA", _campaign_desc(), "", "campaign", "", "Campanha"],
		["QuickRun", "RUN RÁPIDA", "4 antes com o boss final no 4.º, com qualquer baralho.", "", "campaign", "quick", "Run Rápida"],
		["FreeMode", "MODO LIVRE", "Qualquer baralho, também os teus. Não conta para a campanha.", "", "campaign", "free", "Modo Livre"],
		["Draft", "ARENA DRAFT", "Monta o baralho na hora, a abrir boosters.", "", "draft", "free", "Arena Draft"],
		["Saga", "HISTÓRIA", "Capítulos curtos com bosses que falam.", _count_done(CardDB.saga, GameState.saga_done), "saga", "free", "História"],
		["Challenges", "DESAFIOS", "Runs com uma regra especial. Vence para ganhar a medalha.", _count_done(CardDB.challenges, GameState.challenge_done), "challenges", "free", "Desafios"],
	]
	var made: Array = []
	const MODE_OF := {"Campaign": "campaign", "QuickRun": "quick", "Draft": "draft", "Saga": "saga", "Challenges": "challenge"}
	for e in entries:
		var desc := tr(String(e[2]))
		var avg := GameState.avg_run_secs(String(MODE_OF.get(String(e[0]), "")))   # 0.19.0 (169): a média das tuas runs
		if avg > 0:
			desc += "  ·  ≈ " + GameState.fmt_duration(avg)
		var b := _tile(String(e[1]), desc, String(e[3]), false, 58)
		b.name = String(e[0])
		var scene := String(e[4])
		var kind := String(e[5])
		var mode_title := String(e[6])
		b.pressed.connect(func(): _new_game(scene, kind, mode_title))
		page.add_child(b)
		made.append(b)
	# 0.17.0 (83, 84): Torre do Arquimago e Corrida de Bosses, lado a lado na última fila.
	var row := HBoxContainer.new()
	row.name = "SideModes"
	row.add_theme_constant_override("separation", 8)
	page.add_child(row)
	var best := GameState.tower_best()
	var tower := _tile("TORRE DO ARQUIMAGO", tr("Recorde: andar %d") % best if best > 0 else tr("Andares seguidos, sem loja."), "", false, 58)
	tower.name = "Tower"
	tower.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tower.pressed.connect(func(): _new_game("campaign", "tower", "Torre do Arquimago"))
	row.add_child(tower)
	var open := GameState.rush_unlocked()
	var rec := GameState.rush_record()
	var rush_desc := tr("Abre com %d bosses (%d/%d).") % [GameState.RUSH_MIN_BOSSES, GameState.defeated_bosses().size(), GameState.RUSH_MIN_BOSSES]
	if open:
		rush_desc = tr("Melhor: medalha de %s") % tr(String(RUSH_MEDALS.get(String(rec.get("medal", "")), ""))).to_lower() if not rec.is_empty() else tr("Bosses vencidos, seguidos.")
	var rush := _tile("CORRIDA DE BOSSES", rush_desc, "", false, 58)
	rush.name = "Rush"
	rush.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for t in [tower, rush]:   # meia largura: o título um pouco mais pequeno para caber
		((t as Button).find_child("TileTitle", true, false) as Label).add_theme_font_size_override("font_size", 18)
	rush.pressed.connect(func():
		if not GameState.rush_unlocked():
			Sfx.deny()
			SceneRouter.toast(tr("Vence %d bosses da campanha para abrir a Corrida de Bosses (tens %d).") % [GameState.RUSH_MIN_BOSSES, GameState.defeated_bosses().size()], 2.8)
			return
		_new_game("campaign", "rush", "Corrida de Bosses"))
	row.add_child(rush)
	made.append_array([tower, rush])
	# 0.19.0 (176, 177, 201): os modos curtos, lado a lado.
	var srow := HBoxContainer.new()
	srow.name = "ShortModes"
	srow.add_theme_constant_override("separation", 8)
	page.add_child(srow)
	for sm in [["Skirmish", "BATALHA AVULSA", "1 batalha · ~5 min", "skirmish"], ["MiniRun", "RUN DE 2 ANTES", "Boss no 2.º · ~10 min", "mini"],
			["Brawl", "SÓ BATALHAS", "Sem lojas · 4 antes", "brawl"]]:
		var sd := tr(String(sm[2]))
		var savg := GameState.avg_run_secs(String(sm[3]))
		if savg > 0:
			sd = tr("Média: %s") % GameState.fmt_duration(savg)
		var st := _tile(String(sm[1]), sd, "", false, 58)
		st.name = String(sm[0])
		st.tooltip_text = tr({"skirmish": "Uma batalha, sem run (~5 min).", "mini": "Com o boss no 2.º (~10 min).", "brawl": "4 antes sem lojas nem eventos."}[String(sm[3])])
		st.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var srow_in := (st as Button).get_child((st as Button).get_child_count() - 1) as Control
		for c in (st as Button).get_children():
			if c is HBoxContainer:
				srow_in = c
		srow_in.offset_left = 12
		srow_in.offset_right = -8
		((st as Button).find_child("TileTitle", true, false) as Label).add_theme_font_size_override("font_size", 15)
		var sk := String(sm[3])
		var stitle := String(sm[1])
		st.pressed.connect(func(): _new_game("campaign", sk, stitle))
		srow.add_child(st)
		made.append(st)
	_mark_unique(made)
	return page

const RUSH_MEDALS := {"gold": "Ouro", "silver": "Prata", "bronze": "Bronze"}

## 0.17.0: o texto da Campanha conta os baralhos dos livros (eram «18» à mão; são 20 desde a 0.13.0).
func _campaign_desc() -> String:
	var n := 0
	for book in CardDB.campaign:
		if book is Dictionary and book.get("chapters") is Array:
			n += (book["chapters"] as Array).size()
	if n == 0:
		n = CardDB.decks.size()
	return tr("Os %d baralhos, um a um: sobe os Selos Planares e ganha medalhas.") % n

## Escolhido o modo: espaço de gravação e depois o ecrã do modo.
func _new_game(scene: String, kind: String, mode_title: String) -> void:
	if SceneRouter.has_overlay():
		return
	var start := func(_slot: int):
		GameState.launch_mode = kind if kind in ["quick", "tower", "rush", "skirmish", "mini", "brawl"] else ""
		_launch(scene, kind != "", PAGE_NEW)
	if _preselected_slot > 0 and not GameState.has_saved_run(_preselected_slot):
		GameState.current_slot = _preselected_slot
		GameState.slot_confirmed = true
		_preselected_slot = 0
		start.call(GameState.current_slot)
		return
	Sfx.select()
	SlotPicker.open(tr(mode_title), start)

## JOGOS GUARDADOS: os 6 espaços. Tocar num ocupado continua essa run; num vazio começa lá um jogo
## novo. NOME muda o nome; APAGAR pede um 2.º toque.
func _saves_page() -> VBoxContainer:
	var page := _new_page(8)
	page.add_child(_page_header("JOGOS GUARDADOS"))
	var made: Array = []
	for i in range(1, GameState.SLOT_COUNT + 1):
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		page.add_child(row)
		# 0.19.0 (32): ▲ ▼ mudam a ordem dos jogos guardados.
		var mv := VBoxContainer.new()
		mv.add_theme_constant_override("separation", 2)
		row.add_child(mv)
		for d in [-1, 1]:
			var a := UiKit.button("▲" if d < 0 else "▼", 32, 14)
			a.name = ("Up%d" if d < 0 else "Down%d") % i
			a.custom_minimum_size = Vector2(52, 31 if GameState.has_trash() else 36)
			a.disabled = (d < 0 and i == 1) or (d > 0 and i == GameState.SLOT_COUNT) or (not GameState.has_saved_run(i) and not GameState.has_saved_run(i + d))
			a.tooltip_text = tr("Subir") if d < 0 else tr("Descer")
			a.pressed.connect(_on_move_slot.bind(i, d))
			mv.add_child(a)
			made.append(a)
		var b := SlotPicker.slot_button(i)
		b.name = "Slot%d" % i
		b.custom_minimum_size = Vector2(0, 66 if GameState.has_trash() else 76)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(_on_slot_tile.bind(i))
		_plaque_styles(b, b.get_meta("bg", UiKit.BTN_BG), false, 14)   # 0.13.1: placas, como o resto do menu
		PlaqueDeco.attach(b, 14.0, GameState.has_saved_run(i), false, 0.07)
		row.add_child(b)
		made.append(b)
		if GameState.has_saved_run(i):
			var ren := UiKit.button(tr("NOME"), 66 if GameState.has_trash() else 76, 16)
			ren.name = "Rename%d" % i
			ren.custom_minimum_size.x = 82
			ren.pressed.connect(_on_rename.bind(i))
			_plaque(ren)
			row.add_child(ren)
			var del := UiKit.button(tr("APAGAR"), 66 if GameState.has_trash() else 76, 16, UiKit.BTN_BG)
			del.name = "Delete%d" % i
			del.custom_minimum_size.x = 96
			del.pressed.connect(_on_delete.bind(i, del))
			_plaque(del)
			row.add_child(del)
			made.append_array([ren, del])
	# 0.13.0: a última run apagada, substituída ou abandonada pode recuperar-se. 0.19.0 (229): ficam as últimas 6,
	# durante 7 dias (com mais de uma, o botão abre a lista).
	var trash := GameState.trash_info()
	if not trash.is_empty():
		var n_trash := GameState.trash_list().size()
		var head := tr("↺ RECUPERAR A ÚLTIMA RUN APAGADA") if n_trash == 1 else tr("↺ LIXO: %d RUNS APAGADAS (7 DIAS)") % n_trash
		var rec := UiKit.wrap_button(head + "\n" + "%s  ·  %s  ·  %s" % [String(trash.get("what", "")), tr("Ante %d") % int(trash.get("ante", 1)), SlotPicker.ago(float(trash.get("deleted_at", 0.0)))], 64, 16, Color(0.2, 0.17, 0.08), UiKit.GOLD)
		rec.name = "RecoverRun"
		rec.pressed.connect(_on_recover if n_trash == 1 else _open_trash)
		page.add_child(rec)
		made.append(rec)
	_mark_unique(made)
	return page

## 0.19.0 (32): troca o espaço `slot` com o de cima (−1) ou o de baixo (+1).
func _on_move_slot(slot: int, step: int) -> void:
	if SceneRouter.has_overlay():
		return
	if GameState.swap_slots(slot, slot + step):
		Sfx.select()
		_rebuild_keep_page()

## 0.19.0 (229): a lista do lixo — cada run com o que era, quando saiu, porquê, quantos dias faltam e RECUPERAR.
func _open_trash() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	var root := Control.new()
	root.name = "TrashWindow"
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(UiKit.dim(0.8))
	SceneRouter.show_overlay(root)
	var body := UiKit.window(root, 760, tr("RUNS APAGADAS"), UiKit.GOLD, func(): UiKit.close_animated(root), tr("Ficam 7 dias (até 6). Recuperar põe a run no espaço dela ou no primeiro livre."))
	for t in GameState.trash_list():
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		body.add_child(row)
		var why := String({"deleted": "apagada", "replaced": "substituída", "abandoned": "abandonada"}.get(String(t.get("reason", "")), "apagada"))
		var l := UiKit.label("%s  ·  %s\n%s  ·  %s  ·  %s" % [String(t.get("what", "")), tr("Ante %d") % int(t.get("ante", 1)),
			tr(why), SlotPicker.ago(float(t.get("deleted_at", 0.0))), tr("sai daqui a %d dia(s)") % GameState.trash_days_left(float(t.get("deleted_at", 0.0)))], 16, Color.WHITE)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(l)
		var b := UiKit.button(tr("RECUPERAR"), 50, 16, Color(0.2, 0.17, 0.08), UiKit.GOLD)
		b.name = "Restore%d" % int(t.get("index", 0))
		b.custom_minimum_size.x = 160
		b.pressed.connect(func():
			var slot := GameState.restore_trash(int(t.get("index", 0)))
			if slot <= 0:
				Sfx.deny()
				SceneRouter.toast(tr("Não há espaços livres: apaga ou acaba um jogo primeiro."), 2.6)
				return
			Sfx.level_up()
			SceneRouter.toast(tr("Run recuperada no espaço %d.") % slot, 2.4)
			UiKit.close_animated(root)
			_rebuild_keep_page())
		row.add_child(b)
	UiKit.pop_in(body.get_meta("panel"))

## 0.13.0: recupera a última run apagada/substituída para o espaço dela (ou o primeiro livre).
func _on_recover() -> void:
	if SceneRouter.has_overlay():
		return
	var slot := GameState.restore_trash()
	if slot <= 0:
		Sfx.deny()
		SceneRouter.toast(tr("Não há espaços livres: apaga ou acaba um jogo primeiro."), 2.6)
		return
	Sfx.level_up()
	SceneRouter.toast(tr("Run recuperada no espaço %d.") % slot, 2.4)
	_rebuild_keep_page()

func _on_slot_tile(slot: int) -> void:
	if SceneRouter.has_overlay():
		return
	if GameState.has_saved_run(slot):
		_on_continue(slot)
	else:
		Sfx.select()
		_preselected_slot = slot
		_show_page(PAGE_NEW)

func _on_rename(slot: int) -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	var current := String(GameState.slot_info(slot).get("name", ""))
	TextPrompt.open(tr("Nome do jogo %d") % slot, current, tr("Jogo %d") % slot, GameState.RUN_NAME_MAX, func(value: String):
		GameState.rename_slot(slot, value)
		_rebuild_keep_page())

func _on_delete(slot: int, btn: Button) -> void:
	if SceneRouter.has_overlay():
		return
	if _armed_delete != slot:
		Sfx.select()
		_armed_delete = slot
		btn.text = tr("APAGAR?")
		btn.add_theme_stylebox_override("normal", UiKit.flat(UiKit.DANGER, 12))
		btn.add_theme_stylebox_override("hover", UiKit.flat(UiKit.DANGER.lightened(0.06), 12))
		return
	Sfx.hit()
	_armed_delete = 0
	GameState.trash_slot(slot, "deleted")   # 0.13.0: pode recuperar-se (RECUPERAR, em baixo)
	GameState.delete_slot(slot)
	_rebuild_keep_page()

## Refaz as páginas (nomes e contadores novos) sem sair da página em que se está.
func _rebuild_keep_page() -> void:
	_armed_delete = 0
	_build_pages()

func _modes_page() -> VBoxContainer:
	var page := _new_page(10)
	page.add_child(_page_header("APRENDER E TREINAR"))
	var entries := [
		["School", "ESCOLA DO MAGO", "Lições curtas e jogáveis para aprender as mecânicas.", _count_done(CardDB.lessons, GameState.lesson_done), "school", false],
		["Puzzles", "QUEBRA-CABEÇAS", "Um turno com a mão fixa: encontra o golpe certo.", _count_done(CardDB.puzzles, Stats.is_puzzle_solved), "puzzles", false],
		["Training", "TREINO", "Testa combos contra um boneco ou luta outra vez com um boss que já venceste.", "", "training", false],
	]
	var made: Array = []
	for e in entries:
		var b := _tile(String(e[1]), tr(String(e[2])), String(e[3]), false, 70)
		b.name = String(e[0])
		var scene := String(e[4])
		var free := bool(e[5])
		b.pressed.connect(func(): _launch(scene, free, PAGE_MODES))
		page.add_child(b)
		made.append(b)
	# 0.19.0 (193): um quebra-cabeças por resolver, ao acaso (para 2 minutos).
	var rp := _tile("ENIGMA AO ACASO", tr("Um quebra-cabeças que ainda não resolveste, já."), "▶", false, 60)
	rp.name = "RandomPuzzle"
	rp.pressed.connect(_random_puzzle)
	page.add_child(rp)
	made.append(rp)
	_mark_unique(made)
	return page

func _random_puzzle() -> void:
	if SceneRouter.has_overlay():
		return
	var id := GameState.random_unsolved_puzzle()
	if id == "":
		Sfx.deny()
		SceneRouter.toast(tr("Já resolveste todos os quebra-cabeças!"), 2.4)
		return
	Sfx.boom()
	GameState.reset_for_side_battle(id)
	SceneRouter.go("battle")

func _collection_page() -> VBoxContainer:
	var page := _new_page(10)
	page.add_child(_page_header("COLEÇÃO"))
	var ach := "%d/%d" % [Stats.unlocked_count(), CardDB.achievements.size()]
	var entries := [
		["Talents", "TALENTOS", "Vantagens permanentes, pagas com os pontos das runs.", tr("%d pts") % GameState.talent_points(), "talents", false],
		["Collection", "CARTAS E RELÍQUIAS", "Tudo o que já descobriste: cartas, relíquias e inimigos.", "", "collection", false],
		["Builder", "CONSTRUTOR DE BARALHOS", "Cria até 6 baralhos teus para jogar no Modo Livre.", "", "builder", true],
		["Stats", "PERFIL E ESTATÍSTICAS", "O teu perfil, recordes, conquistas e desbloqueios.", ach, "stats", false],
	]
	var made: Array = []
	for e in entries:
		var b := _tile(String(e[1]), tr(String(e[2])), String(e[3]), false, 66)
		b.name = String(e[0])
		var scene := String(e[4])
		var free := bool(e[5])
		b.pressed.connect(func(): _launch(scene, free, PAGE_COLLECTION))
		page.add_child(b)
		made.append(b)
	_mark_unique(made)
	return page

func _new_page(separation: int = 12) -> VBoxContainer:
	var page := VBoxContainer.new()
	page.add_theme_constant_override("separation", separation)
	page.alignment = BoxContainer.ALIGNMENT_CENTER
	return page

## Cabeçalho das páginas de dentro: ◀ VOLTAR e o título.
func _page_header(title: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	var back := UiKit.button(tr("◀ VOLTAR"), 48, 18)
	back.name = "Back"
	back.custom_minimum_size.x = 140
	back.pressed.connect(func(): Sfx.select(); _preselected_slot = 0; _show_page(PAGE_MAIN))
	row.add_child(back)
	_plaque(back)
	var t := UiKit.label(tr(title), 24, UiKit.GOLD)
	t.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(t)
	return row

## Botão grande: título, uma linha a explicar e, à direita, um contador ou uma seta.
## 0.13.1: é uma placa — moldura dourada fina, luz de cima, cantoneiras e, com `icon`, um medalhão com a
## ilustração do mapa à esquerda; o principal (laranja) tem um aro claro, brilho à volta e um reflexo a passar.
func _tile(title: String, desc: String, side: String = "", primary: bool = false, height: int = 66, icon: String = "") -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(0, height)
	b.focus_mode = Control.FOCUS_NONE
	var bg: Color = UiKit.accent() if primary else UiKit.BTN_BG
	_plaque_styles(b, bg, primary, 14)
	PlaqueDeco.attach(b, 14.0, not primary, primary, 0.2 if primary else 0.07)
	var row := HBoxContainer.new()
	row.set_anchors_preset(Control.PRESET_FULL_RECT)
	row.offset_left = 12 if icon != "" else 20
	row.offset_right = -18
	row.offset_top = 4
	row.offset_bottom = -4
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 12 if icon != "" else 10)
	b.add_child(row)
	if icon != "":
		var med := TileMedallion.new(icon, minf(46.0, height - 14.0))
		med.name = "Medallion"
		row.add_child(med)
	var texts := VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.alignment = BoxContainer.ALIGNMENT_CENTER
	texts.mouse_filter = Control.MOUSE_FILTER_IGNORE
	texts.add_theme_constant_override("separation", 0)
	row.add_child(texts)
	var t := UiKit.label(tr(title), 22 if primary else 20, Color.WHITE)
	t.name = "TileTitle"
	t.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	texts.add_child(t)
	if desc != "":
		var d := UiKit.label(desc, 14, Color(1, 1, 1, 0.82) if primary else UiKit.TEXT_DIM)
		d.name = "TileDesc"
		d.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		texts.add_child(d)
	if side != "":
		var s := UiKit.label(side, 26 if side in ["›", "▶"] else 18, Color.WHITE if primary else UiKit.GOLD)
		s.theme_type_variation = &""
		s.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(s)
	return b

## 0.13.1: estilos de placa (fundo, moldura dourada fina e sombra; o principal com aro claro e brilho).
## Com alto contraste a moldura é clara e mais grossa, como nos outros botões.
func _plaque_styles(b: Button, bg: Color, primary: bool = false, radius: int = 12) -> void:
	var border := Color(1.0, 0.89, 0.63) if primary else PLAQUE_BORDER
	var bw := 2 if primary else 1
	if Settings.high_contrast:
		border = UiKit.HC_BORDER
		bw = 2
	var glow := Color(0.96, 0.66, 0.24, 0.45) if primary else Color(0, 0, 0, 0.45)
	var base := bg if primary else Color(bg, 0.93)
	var states := {"normal": [base, border], "hover": [base.lightened(0.07), Color(border, minf(border.a + 0.3, 1.0))],
		"pressed": [base.lightened(0.16), Color(border, 1.0)]}
	for st in states:
		var sb := UiKit.flat(states[st][0], radius, states[st][1], bw, 10)
		sb.shadow_color = glow
		sb.shadow_size = 14 if primary else 8
		sb.shadow_offset = Vector2.ZERO if primary else Vector2(0, 4)
		b.add_theme_stylebox_override(st, sb)
	b.add_theme_stylebox_override("disabled", UiKit.flat(bg.darkened(0.35), radius))
	if primary:
		b.set_meta("haptic", true)   # 0.16.0 (V60): os botões principais do menu vibram um instante

## Um botão de texto do menu (NOVIDADES, SAIR, COMO JOGAR, ◀ VOLTAR…) com o estilo de placa.
func _plaque(b: Button) -> void:
	_plaque_styles(b, UiKit.BTN_BG, false, 12)

## 0.13.1: o título em New Rocker, pintado de dourado (degradê do shader title_gold), com contorno escuro e
## sombra; por baixo, a divisória com o losango.
func _style_title() -> void:
	title_label.add_theme_font_override("font", TITLE_FONT)
	title_label.add_theme_font_size_override("font_size", TITLE_SIZE)
	title_label.add_theme_color_override("font_color", Color.WHITE)   # branco: o shader troca-o pelo dourado
	title_label.add_theme_color_override("font_outline_color", Color(0.14, 0.08, 0.2))
	title_label.add_theme_constant_override("outline_size", 10)
	title_label.add_theme_color_override("font_shadow_color", Color(0.03, 0.01, 0.06, 0.6))
	title_label.add_theme_constant_override("shadow_offset_x", 0)
	title_label.add_theme_constant_override("shadow_offset_y", 6)
	title_label.add_theme_constant_override("shadow_outline_size", 12)
	var mat := ShaderMaterial.new()
	mat.shader = TITLE_SHADER
	var cap := TITLE_SIZE * 0.68
	mat.set_shader_parameter("text_top", TITLE_FONT.get_ascent(TITLE_SIZE) - cap)
	mat.set_shader_parameter("text_height", cap)
	title_label.material = mat
	var div := OrnamentDivider.new(520.0)
	div.name = "TitleDivider"
	var left := title_label.get_parent()
	left.add_child(div)
	left.move_child(div, title_label.get_index() + 1)

## "feitos/total" de uma lista de dados (capítulos, desafios, enigmas).
func _count_done(list: Array, is_done: Callable) -> String:
	if list.is_empty():
		return ""
	var done := 0
	for item in list:
		if item is Dictionary and is_done.call(String(item.get("id", ""))):
			done += 1
	return "%d/%d" % [done, list.size()]

## Os botões feitos em código também ficam acessíveis por %Nome (testes e capturas).
func _mark_unique(nodes: Array) -> void:
	_unique.append_array(nodes)

func _show_page(key: String, animate: bool = true) -> void:
	if not _pages.has(key) or SceneRouter.has_overlay():
		return
	if _armed_delete != 0:   # um APAGAR? por confirmar volta ao normal ao mudar de página
		_armed_delete = 0
		_build_pages()
	_page = key
	if _page_tween != null and _page_tween.is_valid():
		_page_tween.kill()
	for k in _pages:
		var p: Control = _pages[k]
		p.visible = k == key
		p.modulate.a = 1.0
	if animate and Settings.motion_ok():
		var page: Control = _pages[key]
		page.modulate.a = 0.0
		_page_tween = create_tween()
		_page_tween.tween_property(page, "modulate:a", 1.0, Settings.dur(0.18))

func current_page() -> String:
	return _page

## Abre um modo; quem vem de uma página de dentro volta para ela ao regressar ao menu.
func _launch(scene: String, free_mode: bool, from_page: String = PAGE_MAIN) -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	return_page = from_page
	GameState.free_mode = free_mode
	SceneRouter.go(scene)

# --- Atualização da app ---

## Há uma versão nova publicada (AppUpdate): botão dourado por baixo do título.
func _show_update(info: Dictionary) -> void:
	if _update_btn != null and is_instance_valid(_update_btn):
		return
	var version := String(info.get("name", "")).trim_prefix("Zero-Sum").strip_edges()
	var mb := AppUpdate.size_text(info)   # 0.19.0 (242): o tamanho à vista
	_update_btn = UiKit.button("⬇  " + tr("NOVA VERSÃO %s — ATUALIZAR") % version + ((" (%s)" % mb) if mb != "" else ""), 58, 22, UiKit.PRIMARY, UiKit.GOLD)
	_update_btn.name = "UpdateButton"
	_update_btn.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_update_btn.custom_minimum_size.x = 440
	_update_btn.pressed.connect(_on_update)
	title_label.get_parent().add_child(_update_btn)
	UiKit.pop_in(_update_btn)

func _on_update() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	AppUpdate.open_download()
	var notes := String(AppUpdate.info.get("notes", ""))
	# 0.17.0: o ficheiro tem a versão no nome (ZeroSum_vX.Y.Z.apk), como o anexo da Release.
	var file := AppUpdate.file_name_of(String(AppUpdate.info.get("apk", "")))
	var how := tr("Quando acabar, abre o ficheiro %s e toca em Instalar. O teu progresso fica.") % file
	var mb := AppUpdate.size_text(AppUpdate.info)
	if mb != "":
		how = tr("São %s: se puderes, usa o Wi-Fi.") % mb + " " + how
	CardZoom.show_text(tr("A transferir a versão nova"), how + ("\n\n" + notes if notes != "" else ""), tr("Atualização"), UiKit.GOLD)

func _on_settings() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	var menu := SettingsMenu.open()
	menu.closed.connect(func():
		if is_inside_tree():
			_rebuild_keep_page())

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		if _page != PAGE_MAIN:
			Sfx.select()
			_show_page(PAGE_MAIN)
		else:
			get_tree().quit()

func _on_continue(slot: int = 0) -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	return_page = PAGE_MAIN
	if slot <= 0:
		slot = GameState.latest_slot()
	if slot > 0 and GameState.load_run(slot):
		var target := "battle"
		if GameState.saved_scene == "shop":
			target = "shop"
		elif GameState.saved_scene == "event" and GameState.pending_event != "":
			target = "event"
		elif GameState.saved_scene == "map":
			target = "map"
		elif GameState.saved_scene == "loot":
			target = "loot"
		elif GameState.saved_scene == "tower" or (GameState.mode in ["tower", "rush"] and GameState.saved_scene != "battle"):
			target = "tower"   # 0.17.0: entre andares da Torre / bosses da Corrida
		# 0.19.0 (175): uma run parada há mais de 6 horas — primeiro o resumo de onde ficaste.
		var saved_at := float(GameState.slot_info(slot).get("saved_at", 0.0))
		if saved_at > 0.0 and Time.get_unix_time_from_system() - saved_at > SessionWindows.RESUME_AFTER:
			SessionWindows.open_resume(func(): SceneRouter.go(target))
			return
		SceneRouter.go(target)
	else:
		_rebuild_keep_page()

func _title_glow() -> void:
	if not is_instance_valid(title_label) or not title_label.is_inside_tree():
		return
	var tw := create_tween().set_loops()
	tw.tween_property(title_label, "modulate", Color(1.12, 1.08, 1.0), 2.2).set_trans(Tween.TRANS_SINE)
	tw.tween_property(title_label, "modulate", Color.WHITE, 2.2).set_trans(Tween.TRANS_SINE)
	_glow_tw = tw

## 0.19.0 (207, 224): o brilho do título também descansa (ao fim de 1 minuto sem toques, sem foco ou com uma janela).
var _glow_tw: Tween

func _process(_delta: float) -> void:
	if _glow_tw == null or not _glow_tw.is_valid():
		return
	var still := SceneRouter.decor_still()
	if still and _glow_tw.is_running():
		_glow_tw.pause()
		title_label.modulate = Color.WHITE
	elif not still and not _glow_tw.is_running():
		_glow_tw.play()

func _animate_in() -> void:
	# Título desce, botões entram um a um.
	title_label.modulate.a = 0.0
	ContentUpdate.check()
	AppUpdate.check()
	await get_tree().process_frame
	title_label.pivot_offset = Vector2(0, title_label.size.y / 2.0)
	title_label.scale = Vector2(0.9, 0.9)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(title_label, "modulate:a", 1.0, 0.5)
	tw.tween_property(title_label, "scale", Vector2.ONE, 0.5).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	# 0.12.0: o título "respira" (brilho lento), a não ser com o movimento reduzido.
	if Settings.motion_ok():
		tw.chain().tween_callback(_title_glow)
	if not _pages.has(_page):
		return
	var delay := 0.15
	for b in (_pages[_page] as Control).get_children():
		if not (b as Control).visible:
			continue
		b.modulate.a = 0.0
		var t := create_tween()
		t.tween_interval(delay)
		t.tween_property(b, "modulate:a", 1.0, 0.25)
		delay += 0.07
