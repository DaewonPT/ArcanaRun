extends Control
## Menu inicial: escolhe um dos 18 baralhos e começa a run.

const COLOR_NAMES := {"white": "Branco", "blue": "Azul", "black": "Preto", "red": "Vermelho", "green": "Verde"}

@onready var grid: GridContainer = %DeckGrid

func _ready() -> void:
	for child in grid.get_children():
		child.queue_free()
	for deck in CardDB.decks:
		var btn := Button.new()
		btn.custom_minimum_size = Vector2(380, 118)
		btn.add_theme_font_size_override("font_size", 17)
		btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		var stars := ""
		for i in 5:
			stars += "★" if i < int(deck.get("difficulty", 1)) else "☆"
		var colors := _colors_label(deck)
		var approx := int(deck.get("approx_cards", 0))
		var note := ("  ·  ≈%d" % approx) if approx > 0 else ""
		btn.text = "%02d  %s\n%s  ·  %d cartas  ·  %s%s\n%s" % [int(deck.num), deck.name, colors, int(deck.size), stars, note, deck.mechanic]
		btn.pressed.connect(_on_deck_pressed.bind(String(deck.id)))
		grid.add_child(btn)

func _colors_label(deck: Dictionary) -> String:
	var code: String = deck.get("color_code", "")
	if code == "CL/LD":
		return "Incolor"
	if code == "WUBRG":
		return "5 cores"
	var names: Array[String] = []
	for col in deck.get("colors", []):
		names.append(COLOR_NAMES.get(String(col), String(col)))
	return "/".join(PackedStringArray(names))

func _on_deck_pressed(deck_id: String) -> void:
	Sfx.select()
	GameState.new_run(deck_id)
	SceneRouter.go("battle")
