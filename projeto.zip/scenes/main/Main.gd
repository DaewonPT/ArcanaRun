class_name MainMenu
extends Control
## Menu principal, arrumado em páginas para não haver botões a mais no ecrã:
##  • Início: CONTINUAR (a run gravada há menos tempo, diz qual é), NOVO JOGO ›, JOGOS GUARDADOS ›,
##    APRENDER E TREINAR ›, COLEÇÃO ›, e por baixo COMO JOGAR e CONFIGURAÇÕES.
##  • Novo jogo (0.12.0): o modo — Campanha, Run Rápida, Modo Livre, Arena Draft, História e Desafios —
##    e depois o espaço onde a run fica gravada (SlotPicker).
##  • Jogos guardados (0.12.0): os 6 espaços — continuar, mudar o nome ou apagar.
##  • Aprender e treinar: Escola do Mago, Quebra-cabeças e Treino.
##  • Coleção: talentos, cartas e relíquias, construtor de baralhos e estatísticas.
## A dificuldade está no ecrã da campanha e nas Configurações (Jogo). Ao lado da versão: NOVIDADES e
## SAIR; as Novidades abrem sozinhas depois de uma atualização. O "retroceder" do Android numa página
## volta ao início; no início sai do jogo.

const PAGE_MAIN := "main"
const PAGE_NEW := "new"
const PAGE_SAVES := "saves"
const PAGE_MODES := "modes"
const PAGE_COLLECTION := "collection"
const PAGES := [PAGE_MAIN, PAGE_NEW, PAGE_SAVES, PAGE_MODES, PAGE_COLLECTION]

## Página a mostrar quando se volta ao menu: quem sai de um modo volta à lista dos modos.
static var return_page := PAGE_MAIN

## 0.13.1 (visual "Grimório dourado"): título em New Rocker, dourado, e botões como placas.
const TITLE_FONT := preload("res://assets/fonts/NewRocker-Regular.ttf")
const TITLE_SHADER := preload("res://assets/shaders/title_gold.gdshader")
const TITLE_SIZE := 104
const PLAQUE_BORDER := Color(0.97, 0.84, 0.5, 0.5)
## Medalhões (ilustrações do mapa) nos botões da página inicial.
const TILE_ART := {"NewGame": "scout", "Saves": "vault", "Modes": "library", "CollectionPage": "treasure"}

@onready var title_label: Label = %Title
@onready var subtitle: Label = %Subtitle
@onready var buttons: VBoxContainer = %Buttons

var continue_btn: Button
var _pages: Dictionary = {}   # nome da página → VBoxContainer
var _page := PAGE_MAIN
var _update_btn: Button
var _page_tween: Tween
var _unique: Array = []       # botões a registar como %Nome depois de entrarem na árvore
var _preselected_slot := 0    # espaço vazio tocado em JOGOS GUARDADOS: o jogo novo fica lá
var _armed_delete := 0        # espaço à espera do 2.º toque em APAGAR

func _ready() -> void:
	# 0.12.0: fundo animado (aurora, estrelas, orbes de mana e cartas fantasma).
	var backdrop := MenuBackdrop.new()
	backdrop.name = "MenuBackdrop"
	backdrop.title_node = title_label   # 0.13.1: o círculo de runas fica atrás do título
	add_child(backdrop)
	move_child(backdrop, get_node("Glow").get_index() + 1)
	_style_title()
	var start := return_page if return_page in PAGES else PAGE_MAIN
	return_page = PAGE_MAIN
	_page = start
	_build_pages()
	# Novidades e Sair, lado a lado por baixo da versão.
	var quit: Button = %Quit
	var left: Control = quit.get_parent()
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	left.add_child(row)
	left.move_child(row, quit.get_index())
	var news := UiKit.button(tr("NOVIDADES"), 48, 18)
	news.custom_minimum_size.x = 170
	news.pressed.connect(func():
		if not SceneRouter.has_overlay():
			Sfx.select()
			NewsOverlay.open())
	row.add_child(news)
	left.remove_child(quit)
	row.add_child(quit)
	_plaque(news)
	_plaque(quit)
	quit.pressed.connect(func(): get_tree().quit())
	Settings.changed.connect(_build_pages)   # idioma novo: refaz os textos
	AppUpdate.update_available.connect(_show_update)
	if not AppUpdate.info.is_empty():
		_show_update(AppUpdate.info)
	_animate_in()
	if GameState.restored_backup > 0:
		SceneRouter.toast(tr("O progresso estava estragado: recuperámos a cópia de segurança mais recente."))
		GameState.restored_backup = 0
	# 0.16.1 (66): abertura animada na primeira vez que o menu abre (as Novidades esperam por ela).
	var opening := Opening.play_if_first(self)
	if opening != null:
		opening.finished.connect(func():
			if is_inside_tree() and not SceneRouter.has_overlay():
				NewsOverlay.maybe_show())
	elif not SceneRouter.has_overlay():
		NewsOverlay.maybe_show()
	ShaderWarmup.run(self)   # 0.16.0 (78): prepara os shaders da batalha uma vez por sessão

# --- Páginas ---

func _build_pages() -> void:
	for c in buttons.get_children():
		buttons.remove_child(c)
		c.queue_free()
	_pages.clear()
	_unique.clear()
	_pages[PAGE_MAIN] = _main_page()
	_pages[PAGE_NEW] = _new_game_page()
	_pages[PAGE_SAVES] = _saves_page()
	_pages[PAGE_MODES] = _modes_page()
	_pages[PAGE_COLLECTION] = _collection_page()
	for key in _pages:
		var page: Control = _pages[key]
		buttons.add_child(page)
		page.visible = key == _page
	# O dono tem de ser um antepassado: só depois de as páginas estarem na árvore.
	for n in _unique:
		(n as Node).owner = self
		(n as Node).unique_name_in_owner = true
	_unique.clear()

func _main_page() -> VBoxContainer:
	var page := _new_page()
	var latest := GameState.latest_slot()
	var saved := latest > 0
	var cont_desc := ""
	if saved:
		cont_desc = GameState.saved_run_summary(latest) + "  ·  " + GameState.slot_name(latest)
	continue_btn = _tile("CONTINUAR", cont_desc, "▶", true, 80)
	continue_btn.name = "Continue"
	continue_btn.visible = saved
	continue_btn.set_meta("slot", latest)
	continue_btn.pressed.connect(func(): _on_continue(int(continue_btn.get_meta("slot", 0))))
	page.add_child(continue_btn)
	var new_game := _tile("NOVO JOGO", tr("Escolhe o modo: Campanha, Run Rápida, História, Desafios…"), "›", not saved, 80 if not saved else 66, TILE_ART["NewGame"])
	new_game.name = "NewGame"
	new_game.pressed.connect(func(): Sfx.select(); _preselected_slot = 0; _show_page(PAGE_NEW))
	page.add_child(new_game)
	var saves := _tile("JOGOS GUARDADOS", tr("Continua, muda o nome ou apaga as runs a meio."), "%d/%d" % [GameState.saved_slot_count(), GameState.SLOT_COUNT], false, 60, TILE_ART["Saves"])
	saves.name = "Saves"
	saves.pressed.connect(func(): Sfx.select(); _show_page(PAGE_SAVES))
	page.add_child(saves)
	var modes := _tile("APRENDER E TREINAR", tr("Escola do Mago, Quebra-Cabeças e Treino."), "›", false, 60, TILE_ART["Modes"])
	modes.name = "Modes"
	modes.pressed.connect(func(): Sfx.select(); _show_page(PAGE_MODES))
	page.add_child(modes)
	var collection := _tile("COLEÇÃO", tr("Talentos, cartas, construtor de baralhos e estatísticas."), "›", false, 60, TILE_ART["CollectionPage"])
	collection.name = "CollectionPage"
	collection.pressed.connect(func(): Sfx.select(); _show_page(PAGE_COLLECTION))
	page.add_child(collection)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	page.add_child(row)
	var howto := UiKit.button(tr("COMO JOGAR"), 54, 19)
	howto.name = "HowTo"
	howto.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	howto.pressed.connect(func(): Sfx.select(); SceneRouter.go("howto"))
	row.add_child(howto)
	var settings := UiKit.button(tr("CONFIGURAÇÕES"), 54, 19)
	settings.name = "Settings"
	settings.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	settings.pressed.connect(_on_settings)
	row.add_child(settings)
	_plaque(howto)
	_plaque(settings)
	_mark_unique([continue_btn, new_game, saves, modes, collection, howto, settings])
	return page

## NOVO JOGO: o modo; a seguir escolhe-se o espaço de gravação (ou fica no espaço vazio tocado em
## JOGOS GUARDADOS) e abre-se o ecrã do modo (baralho, capítulo, desafio ou draft).
func _new_game_page() -> VBoxContainer:
	var page := _new_page(8)
	page.add_child(_page_header("NOVO JOGO"))
	var entries := [
		["Campaign", "CAMPANHA", "Os 18 baralhos, um a um: sobe os Selos Planares e ganha medalhas.", "", "campaign", "", "Campanha"],
		["QuickRun", "RUN RÁPIDA", "4 antes com o boss final no 4.º, com qualquer baralho.", "", "campaign", "quick", "Run Rápida"],
		["FreeMode", "MODO LIVRE", "Qualquer baralho, também os teus. Não conta para a campanha.", "", "campaign", "free", "Modo Livre"],
		["Draft", "ARENA DRAFT", "Monta o baralho na hora, a abrir boosters.", "", "draft", "free", "Arena Draft"],
		["Saga", "HISTÓRIA", "Capítulos curtos com bosses que falam.", _count_done(CardDB.saga, GameState.saga_done), "saga", "free", "História"],
		["Challenges", "DESAFIOS", "Runs com uma regra especial. Vence para ganhar a medalha.", _count_done(CardDB.challenges, GameState.challenge_done), "challenges", "free", "Desafios"],
	]
	var made: Array = []
	for e in entries:
		var b := _tile(String(e[1]), tr(String(e[2])), String(e[3]), false, 58)
		b.name = String(e[0])
		var scene := String(e[4])
		var kind := String(e[5])
		var mode_title := String(e[6])
		b.pressed.connect(func(): _new_game(scene, kind, mode_title))
		page.add_child(b)
		made.append(b)
	_mark_unique(made)
	return page

## Escolhido o modo: espaço de gravação e depois o ecrã do modo.
func _new_game(scene: String, kind: String, mode_title: String) -> void:
	if SceneRouter.has_overlay():
		return
	var start := func(_slot: int):
		GameState.launch_mode = "quick" if kind == "quick" else ""
		_launch(scene, kind != "", PAGE_NEW)
	if _preselected_slot > 0 and not GameState.has_saved_run(_preselected_slot):
		GameState.current_slot = _preselected_slot
		GameState.slot_confirmed = true
		_preselected_slot = 0
		start.call(GameState.current_slot)
		return
	Sfx.select()
	SlotPicker.open(tr(mode_title), start)

## JOGOS GUARDADOS: os 6 espaços. Tocar num ocupado continua essa run; num vazio começa lá um jogo
## novo. NOME muda o nome; APAGAR pede um 2.º toque.
func _saves_page() -> VBoxContainer:
	var page := _new_page(8)
	page.add_child(_page_header("JOGOS GUARDADOS"))
	var made: Array = []
	for i in range(1, GameState.SLOT_COUNT + 1):
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		page.add_child(row)
		var b := SlotPicker.slot_button(i)
		b.name = "Slot%d" % i
		b.custom_minimum_size = Vector2(0, 66 if GameState.has_trash() else 76)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(_on_slot_tile.bind(i))
		_plaque_styles(b, b.get_meta("bg", UiKit.BTN_BG), false, 14)   # 0.13.1: placas, como o resto do menu
		PlaqueDeco.attach(b, 14.0, GameState.has_saved_run(i), false, 0.07)
		row.add_child(b)
		made.append(b)
		if GameState.has_saved_run(i):
			var ren := UiKit.button(tr("NOME"), 66 if GameState.has_trash() else 76, 16)
			ren.name = "Rename%d" % i
			ren.custom_minimum_size.x = 82
			ren.pressed.connect(_on_rename.bind(i))
			_plaque(ren)
			row.add_child(ren)
			var del := UiKit.button(tr("APAGAR"), 66 if GameState.has_trash() else 76, 16, UiKit.BTN_BG)
			del.name = "Delete%d" % i
			del.custom_minimum_size.x = 96
			del.pressed.connect(_on_delete.bind(i, del))
			_plaque(del)
			row.add_child(del)
			made.append_array([ren, del])
	# 0.13.0: a última run apagada, substituída ou abandonada pode recuperar-se.
	var trash := GameState.trash_info()
	if not trash.is_empty():
		var rec := UiKit.wrap_button(tr("↺ RECUPERAR A ÚLTIMA RUN APAGADA") + "\n" + "%s  ·  %s  ·  %s" % [String(trash.get("what", "")), tr("Ante %d") % int(trash.get("ante", 1)), SlotPicker.ago(float(trash.get("deleted_at", 0.0)))], 64, 16, Color(0.2, 0.17, 0.08), UiKit.GOLD)
		rec.name = "RecoverRun"
		rec.pressed.connect(_on_recover)
		page.add_child(rec)
		made.append(rec)
	_mark_unique(made)
	return page

## 0.13.0: recupera a última run apagada/substituída para o espaço dela (ou o primeiro livre).
func _on_recover() -> void:
	if SceneRouter.has_overlay():
		return
	var slot := GameState.restore_trash()
	if slot <= 0:
		Sfx.deny()
		SceneRouter.toast(tr("Não há espaços livres: apaga ou acaba um jogo primeiro."), 2.6)
		return
	Sfx.level_up()
	SceneRouter.toast(tr("Run recuperada no espaço %d.") % slot, 2.4)
	_rebuild_keep_page()

func _on_slot_tile(slot: int) -> void:
	if SceneRouter.has_overlay():
		return
	if GameState.has_saved_run(slot):
		_on_continue(slot)
	else:
		Sfx.select()
		_preselected_slot = slot
		_show_page(PAGE_NEW)

func _on_rename(slot: int) -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	var current := String(GameState.slot_info(slot).get("name", ""))
	TextPrompt.open(tr("Nome do jogo %d") % slot, current, tr("Jogo %d") % slot, GameState.RUN_NAME_MAX, func(value: String):
		GameState.rename_slot(slot, value)
		_rebuild_keep_page())

func _on_delete(slot: int, btn: Button) -> void:
	if SceneRouter.has_overlay():
		return
	if _armed_delete != slot:
		Sfx.select()
		_armed_delete = slot
		btn.text = tr("APAGAR?")
		btn.add_theme_stylebox_override("normal", UiKit.flat(UiKit.DANGER, 12))
		btn.add_theme_stylebox_override("hover", UiKit.flat(UiKit.DANGER.lightened(0.06), 12))
		return
	Sfx.hit()
	_armed_delete = 0
	GameState.trash_slot(slot, "deleted")   # 0.13.0: pode recuperar-se (RECUPERAR, em baixo)
	GameState.delete_slot(slot)
	_rebuild_keep_page()

## Refaz as páginas (nomes e contadores novos) sem sair da página em que se está.
func _rebuild_keep_page() -> void:
	_armed_delete = 0
	_build_pages()

func _modes_page() -> VBoxContainer:
	var page := _new_page(10)
	page.add_child(_page_header("APRENDER E TREINAR"))
	var entries := [
		["School", "ESCOLA DO MAGO", "Lições curtas e jogáveis para aprender as mecânicas.", _count_done(CardDB.lessons, GameState.lesson_done), "school", false],
		["Puzzles", "QUEBRA-CABEÇAS", "Um turno com a mão fixa: encontra o golpe certo.", _count_done(CardDB.puzzles, Stats.is_puzzle_solved), "puzzles", false],
		["Training", "TREINO", "Testa combos contra um boneco de vida infinita.", "", "training", false],
	]
	var made: Array = []
	for e in entries:
		var b := _tile(String(e[1]), tr(String(e[2])), String(e[3]), false, 70)
		b.name = String(e[0])
		var scene := String(e[4])
		var free := bool(e[5])
		b.pressed.connect(func(): _launch(scene, free, PAGE_MODES))
		page.add_child(b)
		made.append(b)
	_mark_unique(made)
	return page

func _collection_page() -> VBoxContainer:
	var page := _new_page(10)
	page.add_child(_page_header("COLEÇÃO"))
	var ach := "%d/%d" % [Stats.unlocked_count(), CardDB.achievements.size()]
	var entries := [
		["Talents", "TALENTOS", "Vantagens permanentes, pagas com os pontos das runs.", tr("%d pts") % GameState.talent_points(), "talents", false],
		["Collection", "CARTAS E RELÍQUIAS", "Tudo o que já descobriste: cartas, relíquias e inimigos.", "", "collection", false],
		["Builder", "CONSTRUTOR DE BARALHOS", "Cria até 6 baralhos teus para jogar no Modo Livre.", "", "builder", true],
		["Stats", "PERFIL E ESTATÍSTICAS", "O teu perfil, recordes, conquistas e desbloqueios.", ach, "stats", false],
	]
	var made: Array = []
	for e in entries:
		var b := _tile(String(e[1]), tr(String(e[2])), String(e[3]), false, 66)
		b.name = String(e[0])
		var scene := String(e[4])
		var free := bool(e[5])
		b.pressed.connect(func(): _launch(scene, free, PAGE_COLLECTION))
		page.add_child(b)
		made.append(b)
	_mark_unique(made)
	return page

func _new_page(separation: int = 12) -> VBoxContainer:
	var page := VBoxContainer.new()
	page.add_theme_constant_override("separation", separation)
	page.alignment = BoxContainer.ALIGNMENT_CENTER
	return page

## Cabeçalho das páginas de dentro: ◀ VOLTAR e o título.
func _page_header(title: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	var back := UiKit.button(tr("◀ VOLTAR"), 48, 18)
	back.name = "Back"
	back.custom_minimum_size.x = 140
	back.pressed.connect(func(): Sfx.select(); _preselected_slot = 0; _show_page(PAGE_MAIN))
	row.add_child(back)
	_plaque(back)
	var t := UiKit.label(tr(title), 24, UiKit.GOLD)
	t.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(t)
	return row

## Botão grande: título, uma linha a explicar e, à direita, um contador ou uma seta.
## 0.13.1: é uma placa — moldura dourada fina, luz de cima, cantoneiras e, com `icon`, um medalhão com a
## ilustração do mapa à esquerda; o principal (laranja) tem um aro claro, brilho à volta e um reflexo a passar.
func _tile(title: String, desc: String, side: String = "", primary: bool = false, height: int = 66, icon: String = "") -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(0, height)
	b.focus_mode = Control.FOCUS_NONE
	var bg: Color = UiKit.PRIMARY if primary else UiKit.BTN_BG
	_plaque_styles(b, bg, primary, 14)
	PlaqueDeco.attach(b, 14.0, not primary, primary, 0.2 if primary else 0.07)
	var row := HBoxContainer.new()
	row.set_anchors_preset(Control.PRESET_FULL_RECT)
	row.offset_left = 12 if icon != "" else 20
	row.offset_right = -18
	row.offset_top = 4
	row.offset_bottom = -4
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 12 if icon != "" else 10)
	b.add_child(row)
	if icon != "":
		var med := TileMedallion.new(icon, minf(46.0, height - 14.0))
		med.name = "Medallion"
		row.add_child(med)
	var texts := VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.alignment = BoxContainer.ALIGNMENT_CENTER
	texts.mouse_filter = Control.MOUSE_FILTER_IGNORE
	texts.add_theme_constant_override("separation", 0)
	row.add_child(texts)
	var t := UiKit.label(tr(title), 22 if primary else 20, Color.WHITE)
	t.name = "TileTitle"
	t.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	texts.add_child(t)
	if desc != "":
		var d := UiKit.label(desc, 14, Color(1, 1, 1, 0.82) if primary else UiKit.TEXT_DIM)
		d.name = "TileDesc"
		d.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		texts.add_child(d)
	if side != "":
		var s := UiKit.label(side, 26 if side in ["›", "▶"] else 18, Color.WHITE if primary else UiKit.GOLD)
		s.theme_type_variation = &""
		s.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(s)
	return b

## 0.13.1: estilos de placa (fundo, moldura dourada fina e sombra; o principal com aro claro e brilho).
## Com alto contraste a moldura é clara e mais grossa, como nos outros botões.
func _plaque_styles(b: Button, bg: Color, primary: bool = false, radius: int = 12) -> void:
	var border := Color(1.0, 0.89, 0.63) if primary else PLAQUE_BORDER
	var bw := 2 if primary else 1
	if Settings.high_contrast:
		border = UiKit.HC_BORDER
		bw = 2
	var glow := Color(0.96, 0.66, 0.24, 0.45) if primary else Color(0, 0, 0, 0.45)
	var base := bg if primary else Color(bg, 0.93)
	var states := {"normal": [base, border], "hover": [base.lightened(0.07), Color(border, minf(border.a + 0.3, 1.0))],
		"pressed": [base.lightened(0.16), Color(border, 1.0)]}
	for st in states:
		var sb := UiKit.flat(states[st][0], radius, states[st][1], bw, 10)
		sb.shadow_color = glow
		sb.shadow_size = 14 if primary else 8
		sb.shadow_offset = Vector2.ZERO if primary else Vector2(0, 4)
		b.add_theme_stylebox_override(st, sb)
	b.add_theme_stylebox_override("disabled", UiKit.flat(bg.darkened(0.35), radius))
	if primary:
		b.set_meta("haptic", true)   # 0.16.0 (V60): os botões principais do menu vibram um instante

## Um botão de texto do menu (NOVIDADES, SAIR, COMO JOGAR, ◀ VOLTAR…) com o estilo de placa.
func _plaque(b: Button) -> void:
	_plaque_styles(b, UiKit.BTN_BG, false, 12)

## 0.13.1: o título em New Rocker, pintado de dourado (degradê do shader title_gold), com contorno escuro e
## sombra; por baixo, a divisória com o losango.
func _style_title() -> void:
	title_label.add_theme_font_override("font", TITLE_FONT)
	title_label.add_theme_font_size_override("font_size", TITLE_SIZE)
	title_label.add_theme_color_override("font_color", Color.WHITE)   # branco: o shader troca-o pelo dourado
	title_label.add_theme_color_override("font_outline_color", Color(0.14, 0.08, 0.2))
	title_label.add_theme_constant_override("outline_size", 10)
	title_label.add_theme_color_override("font_shadow_color", Color(0.03, 0.01, 0.06, 0.6))
	title_label.add_theme_constant_override("shadow_offset_x", 0)
	title_label.add_theme_constant_override("shadow_offset_y", 6)
	title_label.add_theme_constant_override("shadow_outline_size", 12)
	var mat := ShaderMaterial.new()
	mat.shader = TITLE_SHADER
	var cap := TITLE_SIZE * 0.68
	mat.set_shader_parameter("text_top", TITLE_FONT.get_ascent(TITLE_SIZE) - cap)
	mat.set_shader_parameter("text_height", cap)
	title_label.material = mat
	var div := OrnamentDivider.new(520.0)
	div.name = "TitleDivider"
	var left := title_label.get_parent()
	left.add_child(div)
	left.move_child(div, title_label.get_index() + 1)

## "feitos/total" de uma lista de dados (capítulos, desafios, enigmas).
func _count_done(list: Array, is_done: Callable) -> String:
	if list.is_empty():
		return ""
	var done := 0
	for item in list:
		if item is Dictionary and is_done.call(String(item.get("id", ""))):
			done += 1
	return "%d/%d" % [done, list.size()]

## Os botões feitos em código também ficam acessíveis por %Nome (testes e capturas).
func _mark_unique(nodes: Array) -> void:
	_unique.append_array(nodes)

func _show_page(key: String, animate: bool = true) -> void:
	if not _pages.has(key) or SceneRouter.has_overlay():
		return
	if _armed_delete != 0:   # um APAGAR? por confirmar volta ao normal ao mudar de página
		_armed_delete = 0
		_build_pages()
	_page = key
	if _page_tween != null and _page_tween.is_valid():
		_page_tween.kill()
	for k in _pages:
		var p: Control = _pages[k]
		p.visible = k == key
		p.modulate.a = 1.0
	if animate and Settings.motion_ok():
		var page: Control = _pages[key]
		page.modulate.a = 0.0
		_page_tween = create_tween()
		_page_tween.tween_property(page, "modulate:a", 1.0, Settings.dur(0.18))

func current_page() -> String:
	return _page

## Abre um modo; quem vem de uma página de dentro volta para ela ao regressar ao menu.
func _launch(scene: String, free_mode: bool, from_page: String = PAGE_MAIN) -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	return_page = from_page
	GameState.free_mode = free_mode
	SceneRouter.go(scene)

# --- Atualização da app ---

## Há uma versão nova publicada (AppUpdate): botão dourado por baixo do título.
func _show_update(info: Dictionary) -> void:
	if _update_btn != null and is_instance_valid(_update_btn):
		return
	var version := String(info.get("name", "")).trim_prefix("Zero-Sum").strip_edges()
	_update_btn = UiKit.button("⬇  " + tr("NOVA VERSÃO %s — ATUALIZAR") % version, 58, 22, UiKit.PRIMARY, UiKit.GOLD)
	_update_btn.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_update_btn.custom_minimum_size.x = 440
	_update_btn.pressed.connect(_on_update)
	title_label.get_parent().add_child(_update_btn)
	UiKit.pop_in(_update_btn)

func _on_update() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	AppUpdate.open_download()
	var notes := String(AppUpdate.info.get("notes", ""))
	CardZoom.show_text(tr("A transferir a versão nova"), tr("Quando acabar, abre o ficheiro ZeroSum.apk e toca em Instalar. O teu progresso fica.") + ("\n\n" + notes if notes != "" else ""), tr("Atualização"), UiKit.GOLD)

func _on_settings() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	var menu := SettingsMenu.open()
	menu.closed.connect(func():
		if is_inside_tree():
			_rebuild_keep_page())

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		if _page != PAGE_MAIN:
			Sfx.select()
			_show_page(PAGE_MAIN)
		else:
			get_tree().quit()

func _on_continue(slot: int = 0) -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	return_page = PAGE_MAIN
	if slot <= 0:
		slot = GameState.latest_slot()
	if slot > 0 and GameState.load_run(slot):
		var target := "battle"
		if GameState.saved_scene == "shop":
			target = "shop"
		elif GameState.saved_scene == "event" and GameState.pending_event != "":
			target = "event"
		elif GameState.saved_scene == "map":
			target = "map"
		elif GameState.saved_scene == "loot":
			target = "loot"
		SceneRouter.go(target)
	else:
		_rebuild_keep_page()

func _title_glow() -> void:
	if not is_instance_valid(title_label) or not title_label.is_inside_tree():
		return
	var tw := create_tween().set_loops()
	tw.tween_property(title_label, "modulate", Color(1.12, 1.08, 1.0), 2.2).set_trans(Tween.TRANS_SINE)
	tw.tween_property(title_label, "modulate", Color.WHITE, 2.2).set_trans(Tween.TRANS_SINE)

func _animate_in() -> void:
	# Título desce, botões entram um a um.
	title_label.modulate.a = 0.0
	ContentUpdate.check()
	AppUpdate.check()
	await get_tree().process_frame
	title_label.pivot_offset = Vector2(0, title_label.size.y / 2.0)
	title_label.scale = Vector2(0.9, 0.9)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(title_label, "modulate:a", 1.0, 0.5)
	tw.tween_property(title_label, "scale", Vector2.ONE, 0.5).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	# 0.12.0: o título "respira" (brilho lento), a não ser com o movimento reduzido.
	if Settings.motion_ok():
		tw.chain().tween_callback(_title_glow)
	if not _pages.has(_page):
		return
	var delay := 0.15
	for b in (_pages[_page] as Control).get_children():
		if not (b as Control).visible:
			continue
		b.modulate.a = 0.0
		var t := create_tween()
		t.tween_interval(delay)
		t.tween_property(b, "modulate:a", 1.0, 0.25)
		delay += 0.07
