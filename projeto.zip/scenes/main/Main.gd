extends Control
## Menu principal: Novo Jogo (campanha), Continuar, História, Desafios, Modo Livre, Arena Draft,
## Quebra-cabeças, Treino, Coleção, Estatísticas, Construtor, Como Jogar, Dificuldade, Configurações.
## A versão (por baixo do título) abre as Novidades; abrem sozinhas depois de uma atualização.

@onready var continue_btn: Button = %Continue
@onready var difficulty_btn: Button = %Difficulty
@onready var title_label: Label = %Title
@onready var subtitle: Label = %Subtitle
@onready var buttons: VBoxContainer = %Buttons

var _update_btn: Button

func _ready() -> void:
	continue_btn.visible = GameState.has_saved_run()
	_refresh_difficulty()
	%NewGame.pressed.connect(func(): _go("campaign", false))
	continue_btn.pressed.connect(_on_continue)
	%FreeMode.pressed.connect(func(): _go("campaign", true))
	difficulty_btn.pressed.connect(_on_difficulty)
	%HowTo.pressed.connect(func(): Sfx.select(); SceneRouter.go("howto"))
	%Settings.pressed.connect(_on_settings)
	%Stats.pressed.connect(func(): Sfx.select(); SceneRouter.go("stats"))
	%Collection.pressed.connect(func(): Sfx.select(); SceneRouter.go("collection"))
	%Builder.pressed.connect(func(): _go("builder", true))
	%Draft.pressed.connect(func(): _go("draft", true))
	%Puzzles.pressed.connect(func(): Sfx.select(); SceneRouter.go("puzzles"))
	%Saga.pressed.connect(func(): _go("saga", true))
	%Challenges.pressed.connect(func(): _go("challenges", true))
	%Training.pressed.connect(func(): Sfx.select(); SceneRouter.go("training"))
	# Novidades e Sair, lado a lado por baixo da versão.
	var quit: Button = %Quit
	var left: Control = quit.get_parent()
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	left.add_child(row)
	left.move_child(row, quit.get_index())
	var news := UiKit.button(tr("NOVIDADES"), 48, 18)
	news.custom_minimum_size.x = 170
	news.pressed.connect(func():
		if not SceneRouter.has_overlay():
			Sfx.select()
			NewsOverlay.open())
	row.add_child(news)
	left.remove_child(quit)
	row.add_child(quit)
	quit.pressed.connect(func(): get_tree().quit())
	Settings.changed.connect(_refresh_difficulty)
	AppUpdate.update_available.connect(_show_update)
	if not AppUpdate.info.is_empty():
		_show_update(AppUpdate.info)
	_animate_in()
	if not SceneRouter.has_overlay():
		NewsOverlay.maybe_show()

## Há uma versão nova publicada (AppUpdate): botão dourado por baixo do título.
func _show_update(info: Dictionary) -> void:
	if _update_btn != null and is_instance_valid(_update_btn):
		return
	var version := String(info.get("name", "")).trim_prefix("Zero-Sum").strip_edges()
	_update_btn = UiKit.button("⬇  " + tr("NOVA VERSÃO %s — ATUALIZAR") % version, 58, 22, UiKit.PRIMARY, UiKit.GOLD)
	_update_btn.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_update_btn.custom_minimum_size.x = 440
	_update_btn.pressed.connect(_on_update)
	title_label.get_parent().add_child(_update_btn)
	UiKit.pop_in(_update_btn)

func _on_update() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	AppUpdate.open_download()
	var notes := String(AppUpdate.info.get("notes", ""))
	CardZoom.show_text(tr("A transferir a versão nova"), tr("Quando acabar, abre o ficheiro ZeroSum.apk e toca em Instalar. O teu progresso fica.") + ("\n\n" + notes if notes != "" else ""), tr("Atualização"), UiKit.GOLD)

func _on_settings() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	var menu := SettingsMenu.open()
	menu.closed.connect(func(): continue_btn.visible = GameState.has_saved_run())

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		get_tree().quit()

func _refresh_difficulty() -> void:
	difficulty_btn.text = tr("DIFICULDADE: %s") % tr(GameState.difficulty_name()).to_upper()

func _on_difficulty() -> void:
	Sfx.select()
	GameState.cycle_difficulty()
	_refresh_difficulty()
	_bump(difficulty_btn)

func _go(scene: String, free_mode: bool) -> void:
	Sfx.select()
	GameState.free_mode = free_mode
	SceneRouter.go(scene)

func _on_continue() -> void:
	Sfx.select()
	if GameState.load_run():
		var target := "battle"
		if GameState.saved_scene == "shop":
			target = "shop"
		elif GameState.saved_scene == "event" and GameState.pending_event != "":
			target = "event"
		elif GameState.saved_scene == "map":
			target = "map"
		elif GameState.saved_scene == "loot":
			target = "loot"
		SceneRouter.go(target)
	else:
		continue_btn.visible = false

func _animate_in() -> void:
	# Título desce, botões entram um a um.
	title_label.modulate.a = 0.0
	ContentUpdate.check()
	AppUpdate.check()
	await get_tree().process_frame
	title_label.pivot_offset = Vector2(0, title_label.size.y / 2.0)
	title_label.scale = Vector2(0.9, 0.9)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(title_label, "modulate:a", 1.0, 0.5)
	tw.tween_property(title_label, "scale", Vector2.ONE, 0.5).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	var delay := 0.15
	for b in buttons.get_children():
		if not b.visible:
			continue
		b.modulate.a = 0.0
		var t := create_tween()
		t.tween_interval(delay)
		t.tween_property(b, "modulate:a", 1.0, 0.25)
		delay += 0.07

func _bump(view: Control) -> void:
	view.pivot_offset = view.size / 2.0
	var tw := create_tween()
	tw.tween_property(view, "scale", Vector2(1.06, 1.06), 0.06)
	tw.tween_property(view, "scale", Vector2.ONE, 0.12)
