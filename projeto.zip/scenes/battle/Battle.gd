extends Control
## Cena de batalha (horizontal). Liga a UI ao BattleManager através do EventBus e anima:
## cartas a voar da mão para o tabuleiro, compra, investida das criaturas na cascata,
## impacto no inimigo, número de dano a voar, partículas no total, banner de ante.

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const RELIC_VIEW := preload("res://scenes/ui/RelicView.tscn")

const COLOR_POWER := Color(0.22, 0.74, 0.97)
const COLOR_MULT := Color(0.96, 0.25, 0.37)
const COLOR_MULT_X := Color(0.72, 0.35, 0.95)
const COLOR_FORMATION := Color(0.98, 0.75, 0.25)
const COLOR_GROW := Color(0.35, 0.85, 0.45)
const COLOR_GOLD := Color(0.98, 0.85, 0.3)
const DISCARD_TINT := Color(0.8, 0.6, 1.0)

const ABILITY_LOG := {
	"steal_gold": "roubou-te ouro",
	"heal_self": "curou-se",
	"destroy_strongest": "destruiu a tua criatura mais forte",
	"damage_all_creatures": "feriu todas as tuas criaturas",
	"discard_random": "fez-te descartar uma carta",
}

@onready var battle: BattleManager = $BattleManager
@onready var layout: Control = $Layout
@onready var hand_box: HBoxContainer = %Hand
@onready var board_box: HBoxContainer = %Board
@onready var spell_strip: HBoxContainer = %SpellStrip
@onready var spell_hint: Label = %SpellHint
@onready var relics_bar: HBoxContainer = %RelicsBar
@onready var turn_label: Label = %TurnLabel
@onready var gold_label: Label = %GoldLabel
@onready var enemy_panel: Control = %EnemyPanel
@onready var enemy_name: Label = %EnemyName
@onready var enemy_hp_bar: ProgressBar = %EnemyHPBar
@onready var enemy_hp_label: Label = %EnemyHPLabel
@onready var enemy_text: Label = %EnemyText
@onready var log_label: Label = %LogLabel
@onready var player_label: Label = %PlayerLabel
@onready var mana_label: Label = %ManaLabel
@onready var end_turn_btn: Button = %EndTurn
@onready var discard_btn: Button = %DiscardBtn
@onready var formation_label: Label = %FormationLabel
@onready var power_label: Label = %PowerLabel
@onready var mult_label: Label = %MultLabel
@onready var total_label: Label = %TotalLabel
@onready var power_pill: Control = %PowerPill
@onready var mult_pill: Control = %MultPill
@onready var banner: Label = %Banner

var _board_views: Dictionary = {}   # uid -> CardView
var _hand_views: Dictionary = {}    # uid -> CardView
var _spell_chips: Dictionary = {}   # uid -> Control
var _relic_views: Dictionary = {}   # relic_id -> RelicView
var _animating: bool = false
var _discard_mode: bool = false
var _layout_base: Vector2
var _particles: CPUParticles2D
var _hp_tween: Tween

func _ready() -> void:
	_layout_base = layout.position
	EventBus.enemy_hp_changed.connect(_on_enemy_hp)
	EventBus.player_hp_changed.connect(func(c, m): player_label.text = "Vida %d/%d" % [c, m])
	EventBus.gold_changed.connect(func(g): gold_label.text = "Ouro %d" % g)
	EventBus.mana_changed.connect(_on_mana_changed)
	EventBus.discards_changed.connect(_on_discards_changed)
	EventBus.turn_started.connect(_on_turn_started)
	EventBus.card_drawn.connect(func(_c): _refresh_hand())
	EventBus.hand_changed.connect(_refresh_hand)
	EventBus.spell_cast.connect(_on_spell_cast)
	EventBus.creature_died.connect(_on_creature_died)
	EventBus.creature_blocked.connect(_on_creature_blocked)
	EventBus.card_discarded.connect(_on_card_discarded)
	EventBus.card_grew.connect(_on_card_grew)
	EventBus.enemy_ability_used.connect(_on_enemy_ability)
	EventBus.damage_dealt.connect(_on_damage_dealt)
	EventBus.cascade_started.connect(_on_cascade_started)
	EventBus.battle_ended.connect(_on_battle_ended)
	end_turn_btn.pressed.connect(_on_end_turn)
	discard_btn.toggled.connect(_on_discard_toggled)
	_make_particles()

	_build_relics()
	gold_label.text = "Ouro %d" % GameState.gold
	GameState.save_run()
	battle.start(_pick_enemy())
	enemy_name.text = battle.enemy.name
	enemy_text.text = battle.enemy.text
	_log("Toca numa carta para a jogar.")
	_show_banner("ANTE %d\n%s" % [GameState.ante, battle.enemy.name])

func _pick_enemy() -> Dictionary:
	var pool := CardDB.enemies.filter(func(e): return int(e.get("min_ante", 1)) <= GameState.ante)
	var def: Dictionary = pool[GameState.rng.randi_range(0, pool.size() - 1)]
	var hp := GameState.enemy_hp_for_ante(GameState.ante)
	return {
		"name": def.name,
		"hp": hp, "max_hp": hp,
		"attack": int(def.attack),
		"text": def.get("text", ""),
		"abilities": def.get("abilities", []),
	}

func _make_particles() -> void:
	_particles = CPUParticles2D.new()
	_particles.emitting = false
	_particles.one_shot = true
	_particles.explosiveness = 0.95
	_particles.amount = 48
	_particles.lifetime = 0.8
	_particles.spread = 180.0
	_particles.direction = Vector2(0, -1)
	_particles.gravity = Vector2(0, 700)
	_particles.initial_velocity_min = 220.0
	_particles.initial_velocity_max = 520.0
	_particles.scale_amount_min = 3.0
	_particles.scale_amount_max = 7.0
	_particles.color = Color(1.0, 0.85, 0.35)
	add_child(_particles)

# --- Construção / refresh ---

func _build_relics() -> void:
	for child in relics_bar.get_children():
		child.queue_free()
	_relic_views.clear()
	for id in GameState.relic_ids:
		var view: RelicView = RELIC_VIEW.instantiate()
		relics_bar.add_child(view)
		view.setup(id)
		_relic_views[id] = view

func _refresh_all() -> void:
	_refresh_hand()
	_refresh_board()
	_refresh_spells()
	_refresh_preview()

func _refresh_hand() -> void:
	# Se a mão é a mesma (mesmas cartas, mesma ordem), só atualiza as vistas — não interrompe animações.
	var live := hand_box.get_children().filter(func(c): return not c.is_queued_for_deletion())
	var same := _hand_views.size() == battle.deck.hand.size() and live.size() == battle.deck.hand.size()
	if same:
		var i := 0
		for card in battle.deck.hand:
			if not _hand_views.has(card.uid) or live[i] != _hand_views[card.uid]:
				same = false
				break
			i += 1
	if same:
		for card in battle.deck.hand:
			var v: CardView = _hand_views[card.uid]
			if _alive(v):
				v.refresh()
				v.playable = battle.can_play(card) or card.data.is_land() or _discard_mode
		_refresh_preview()
		return
	var previous := _hand_views.keys()
	for child in hand_box.get_children():
		child.queue_free()
	_hand_views.clear()
	var stagger := 0.0
	for card in battle.deck.hand:
		var view: CardView = CARD_VIEW.instantiate()
		hand_box.add_child(view)
		view.setup(card)
		view.playable = battle.can_play(card) or card.data.is_land() or _discard_mode
		if _discard_mode:
			view.modulate = DISCARD_TINT
		view.pressed.connect(_on_hand_card_pressed)
		_hand_views[card.uid] = view
		if not (card.uid in previous):
			_animate_draw(view, stagger)
			stagger += 0.05
	_refresh_preview()

func _refresh_board() -> void:
	if _animating:
		return
	var creatures := battle.creatures()
	var live := board_box.get_children().filter(func(c): return not c.is_queued_for_deletion())
	var same := _board_views.size() == creatures.size() and live.size() == creatures.size()
	if same:
		var i := 0
		for card in creatures:
			if not _board_views.has(card.uid) or live[i] != _board_views[card.uid]:
				same = false
				break
			i += 1
	if same:
		for card in creatures:
			if _alive(_board_views[card.uid]):
				(_board_views[card.uid] as CardView).refresh()
		return
	for child in board_box.get_children():
		child.queue_free()
	_board_views.clear()
	for card in creatures:
		var view: CardView = CARD_VIEW.instantiate()
		board_box.add_child(view)
		view.setup(card)
		_board_views[card.uid] = view

func _refresh_spells() -> void:
	if _animating:
		return
	for child in spell_strip.get_children():
		if child != spell_hint:
			child.queue_free()
	_spell_chips.clear()
	spell_hint.visible = battle.spells_this_turn.is_empty()
	for sp in battle.spells_this_turn:
		var chip := _make_chip(sp)
		spell_strip.add_child(chip)
		_spell_chips[sp.uid] = chip

func _make_chip(sp: CardInstance) -> Control:
	var chip := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = CardView.COLORS.get(sp.data.primary_color(), CardView.COLORS.colorless)
	style.set_corner_radius_all(8)
	style.set_content_margin_all(6)
	chip.add_theme_stylebox_override("panel", style)
	var label := Label.new()
	label.text = "%s  %d⚔" % [sp.data.name, sp.data.power] if sp.data.power > 0 else sp.data.name
	label.add_theme_font_size_override("font_size", 15)
	label.add_theme_color_override("font_color", Color(0.08, 0.08, 0.1) if style.bg_color.get_luminance() > 0.45 else Color.WHITE)
	chip.add_child(label)
	return chip

## Mostra o que o ataque faria se atacasses agora.
func _refresh_preview() -> void:
	if _animating:
		return
	var c := battle.preview_attack()
	if c.is_empty():
		formation_label.text = "Sem atacantes"
	elif c.formations.is_empty():
		formation_label.text = "Ataque"
	else:
		formation_label.text = " · ".join(PackedStringArray(c.formations))
	power_label.text = Cascade.fmt_int(c.power)
	mult_label.text = Cascade.fmt_mult(c.mult)
	total_label.text = Cascade.fmt_int(c.total())
	end_turn_btn.text = "ATACAR\n%s" % Cascade.fmt_int(c.total()) if c.total() > 0 else "ATACAR"

func _refresh_discard_button() -> void:
	discard_btn.text = "CANALIZAR (%d)" % battle.discards_left
	discard_btn.disabled = battle.discards_left <= 0 or battle.resolving or battle.finished
	if discard_btn.disabled and _discard_mode:
		discard_btn.button_pressed = false

# --- Handlers ---

func _on_mana_changed(available: int, total: int) -> void:
	mana_label.text = "Mana %d/%d" % [available, total]
	_refresh_hand()

func _on_discards_changed(_left: int) -> void:
	_refresh_discard_button()

func _on_turn_started(t: int) -> void:
	turn_label.text = "Turno %d/%d  ·  Ante %d" % [t, battle.max_turns + battle.extra_turns, GameState.ante]
	end_turn_btn.disabled = false
	_refresh_discard_button()
	_refresh_all()
	if t > 1:
		_show_banner("TURNO %d" % t, 0.6)

func _on_enemy_hp(current: int, max_hp: int) -> void:
	enemy_hp_bar.max_value = max_hp
	if _hp_tween != null and _hp_tween.is_valid():
		_hp_tween.kill()
	_hp_tween = create_tween()
	_hp_tween.tween_property(enemy_hp_bar, "value", float(current), 0.45).set_ease(Tween.EASE_OUT)
	enemy_hp_label.text = "%s / %s" % [Cascade.fmt_int(current), Cascade.fmt_int(max_hp)]

func _on_spell_cast(_card: CardInstance) -> void:
	_refresh_spells()

func _on_creature_died(card: CardInstance) -> void:
	Sfx.hit()
	_log("%s morreu." % card.data.name)
	if _board_views.has(card.uid) and is_instance_valid(_board_views[card.uid]):
		_animate_death(_board_views[card.uid])
	_refresh_board()
	_refresh_preview()

func _on_creature_blocked(card: CardInstance, amount: int) -> void:
	_log("%s bloqueou %d de dano." % [card.data.name, amount])
	if _board_views.has(card.uid):
		var view: CardView = _board_views[card.uid]
		if is_instance_valid(view):
			view.refresh()
			_flash(view, Color(1.6, 1.6, 1.6))
			_bump(view, 0.9)

func _on_card_discarded(card: CardInstance) -> void:
	_log("Canalizaste %s." % card.data.name)

func _on_card_grew(card: CardInstance, amount: int) -> void:
	var view: Control = _board_views.get(card.uid, _hand_views.get(card.uid))
	if view != null and is_instance_valid(view):
		if view is CardView:
			view.refresh()
		_pop(view, "Cresce +%d" % amount, COLOR_GROW)
	_refresh_preview()

func _on_hand_card_pressed(card: CardInstance) -> void:
	if _discard_mode:
		if battle.discard(card):
			Sfx.hit()
			discard_btn.button_pressed = false   # desliga o modo (toggled → _on_discard_toggled)
			_refresh_all()
		return
	var from_rect := Rect2()
	if _hand_views.has(card.uid) and is_instance_valid(_hand_views[card.uid]):
		from_rect = (_hand_views[card.uid] as Control).get_global_rect()
	if battle.play(card):
		Sfx.select()
		_refresh_all()
		_animate_play(card, from_rect)

func _on_discard_toggled(on: bool) -> void:
	_discard_mode = on and battle.discards_left > 0
	if on and battle.discards_left <= 0:
		discard_btn.button_pressed = false
	for view in _hand_views.values():
		if is_instance_valid(view):
			view.modulate = DISCARD_TINT if _discard_mode else Color.WHITE
			view.playable = battle.can_play(view.card) or view.card.data.is_land() or _discard_mode
	if _discard_mode:
		_log("Toca na carta a canalizar.")
		Sfx.select()

func _on_end_turn() -> void:
	if battle.resolving or battle.finished:
		return
	_bump(end_turn_btn, 0.92)
	end_turn_btn.disabled = true
	discard_btn.button_pressed = false
	discard_btn.disabled = true
	battle.end_turn()

func _on_enemy_ability(enemy_name_str: String, action: String) -> void:
	_log("%s %s!" % [enemy_name_str, ABILITY_LOG.get(action, action)])
	_flash(enemy_panel, Color(1.3, 1.1, 1.5))
	_refresh_all()

func _on_damage_dealt(target: String, amount: int) -> void:
	if target == "enemy":
		_log("Causaste %s de dano." % Cascade.fmt_int(amount))
		_animate_enemy_hit(amount)
	else:
		Sfx.hit()
		_animate_enemy_strike()
		_shake(8.0)
		_flash(player_label, Color(2.0, 0.6, 0.6))
		_log("Levaste %d de dano." % amount)

func _on_battle_ended(victory: bool) -> void:
	if victory:
		if GameState.ante >= GameState.max_ante:
			GameState.last_victory = true
			EventBus.run_ended.emit(true)
			_show_banner("VITÓRIA", 1.0)
			await get_tree().create_timer(0.9).timeout
			SceneRouter.go("run_over")
		else:
			_show_banner("ANTE %d VENCIDO" % GameState.ante, 1.0)
			Sfx.boom()
			await get_tree().create_timer(0.9).timeout
			SceneRouter.go("shop")
	else:
		GameState.last_victory = false
		EventBus.run_ended.emit(false)
		_show_banner("DERROTA", 1.0)
		await get_tree().create_timer(1.0).timeout
		SceneRouter.go("run_over")

# --- Cascata ---

func _on_cascade_started(cascade: Cascade) -> void:
	_animating = true
	end_turn_btn.disabled = true
	formation_label.text = "Ataque"
	power_label.text = "0"
	mult_label.text = "1"
	total_label.text = ""
	var shown_formations: Array[String] = []
	var i := 0
	for s in cascade.steps:
		var target := _view_for_step(s)
		var color := _color_for_step(s)
		if s.source_kind == "formation" and not s.retrigger:
			shown_formations.append(s.source_name)
			formation_label.text = " · ".join(PackedStringArray(shown_formations))
		if s.source_kind == "creature" and s.action == "power_add":
			_lunge(target)
		_pop(target, ("↻ " if s.retrigger else "") + s.label, color)
		power_label.text = Cascade.fmt_int(s.power_after)
		mult_label.text = Cascade.fmt_mult(s.mult_after)
		_bump(power_pill if s.action == "power_add" else mult_pill)
		Sfx.blip(i)
		await get_tree().create_timer(maxf(0.09, 0.28 - i * 0.012)).timeout
		i += 1
	total_label.text = Cascade.fmt_int(cascade.total())
	_bump(total_label, 1.5)
	_particles.global_position = total_label.global_position + total_label.size / 2.0
	_particles.restart()
	Sfx.boom()
	_shake(10.0)
	await get_tree().create_timer(0.5).timeout
	_animating = false
	EventBus.cascade_finished.emit()

func _view_for_step(s: Cascade.Step) -> Control:
	match s.source_kind:
		"creature":
			if s.source_card != null and _board_views.has(s.source_card.uid):
				return _board_views[s.source_card.uid]
		"spell":
			if s.source_card != null and _spell_chips.has(s.source_card.uid):
				return _spell_chips[s.source_card.uid]
		"hand":
			if s.source_card != null and _hand_views.has(s.source_card.uid):
				return _hand_views[s.source_card.uid]
		"relic":
			if _relic_views.has(s.source_id):
				return _relic_views[s.source_id]
	return formation_label

func _color_for_step(s: Cascade.Step) -> Color:
	if s.grow > 0:
		return COLOR_GROW
	if s.source_kind == "formation":
		return COLOR_FORMATION
	match s.action:
		"power_add":
			return COLOR_POWER
		"mult_mul":
			return COLOR_MULT_X
		"gold":
			return COLOR_GOLD
	return COLOR_MULT

# --- Animações ---

func _alive(view) -> bool:
	return view != null and is_instance_valid(view) and not view.is_queued_for_deletion()

## Mata o tween guardado em meta (se existir) para nunca haver dois a disputar a mesma propriedade.
func _kill_tween(view: Object, key: String) -> void:
	if view.has_meta(key):
		var old = view.get_meta(key)
		if old is Tween and (old as Tween).is_valid():
			(old as Tween).kill()

## Pop da vista + etiqueta a flutuar por cima dela.
func _pop(view: Control, text: String, color: Color) -> void:
	if not _alive(view):
		return
	_bump(view, 1.22)
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", 26)
	label.add_theme_color_override("font_color", Color.WHITE)
	label.add_theme_color_override("font_outline_color", color.darkened(0.35))
	label.add_theme_constant_override("outline_size", 8)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(label)
	label.reset_size()
	var start := view.global_position + Vector2(view.size.x * 0.5 - label.size.x * 0.5, -label.size.y * 0.6)
	label.global_position = start
	var tw := create_tween().set_parallel(true)
	tw.tween_property(label, "global_position:y", start.y - 46.0, 0.6).set_ease(Tween.EASE_OUT)
	tw.tween_property(label, "modulate:a", 0.0, 0.6).set_delay(0.25)
	tw.chain().tween_callback(label.queue_free)

## Escala rápida e volta a 1. Mata o bump anterior da mesma vista para nunca ficar a meio.
func _bump(view: Control, amount: float = 1.18) -> void:
	if not _alive(view):
		return
	view.pivot_offset = view.size / 2.0
	_kill_tween(view, "bump_tw")
	view.scale = Vector2.ONE
	var tw := create_tween()
	tw.tween_property(view, "scale", Vector2.ONE * amount, 0.07)
	tw.tween_property(view, "scale", Vector2.ONE, 0.13).set_ease(Tween.EASE_OUT)
	view.set_meta("bump_tw", tw)

## Investida: a criatura inclina-se e salta para a frente (rotação + escala, não mexe no layout).
func _lunge(view: Control) -> void:
	if not _alive(view):
		return
	view.pivot_offset = view.size / 2.0
	_kill_tween(view, "lunge_tw")
	view.rotation = 0.0
	var tw := create_tween()
	tw.tween_property(view, "rotation", -0.16, 0.06)
	tw.tween_property(view, "rotation", 0.0, 0.16).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	view.set_meta("lunge_tw", tw)

func _flash(view: Control, color: Color) -> void:
	if not _alive(view):
		return
	_kill_tween(view, "flash_tw")
	var base := Color.WHITE
	if view in _hand_views.values() and _discard_mode:
		base = DISCARD_TINT
	view.modulate = color
	var tw := create_tween()
	tw.tween_property(view, "modulate", base, 0.35)
	view.set_meta("flash_tw", tw)

func _shake(strength: float) -> void:
	var tw := create_tween()
	for i in 5:
		var off := Vector2(randf_range(-strength, strength), randf_range(-strength, strength)) * (1.0 - i / 5.0)
		tw.tween_property(layout, "position", _layout_base + off, 0.03)
	tw.tween_property(layout, "position", _layout_base, 0.04)

## Carta nova na mão: entra de baixo, a crescer.
func _animate_draw(view: CardView, delay: float) -> void:
	var target_alpha := view.modulate.a
	view.modulate.a = 0.0
	view.scale = Vector2(0.7, 0.7)
	await get_tree().process_frame
	if not _alive(view):
		return
	view.pivot_offset = view.size / 2.0
	var tw := create_tween().set_parallel(true)
	tw.tween_property(view, "modulate:a", target_alpha, 0.18).set_delay(delay)
	tw.tween_property(view, "scale", Vector2.ONE, 0.22).set_delay(delay).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)

## Carta jogada: um "fantasma" voa da posição na mão até ao sítio novo (tabuleiro, feitiços ou mana).
func _animate_play(card: CardInstance, from_rect: Rect2) -> void:
	if from_rect.size == Vector2.ZERO:
		return
	await get_tree().process_frame   # deixa o layout colocar a vista nova
	var target: Control = null
	if card.data.is_creature():
		target = _board_views.get(card.uid)
	elif card.data.is_spell():
		target = _spell_chips.get(card.uid)
	else:
		target = mana_label
	if not _alive(target):
		return
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = from_rect.size
	ghost.global_position = from_rect.position
	ghost.pivot_offset = ghost.size / 2.0
	var real_target := target
	if card.data.is_creature():
		real_target.modulate.a = 0.0
	var dest := target.global_position + (target.size - ghost.size) / 2.0
	var end_scale := Vector2.ONE if card.data.is_creature() else Vector2(0.35, 0.35)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(ghost, "global_position", dest, 0.24).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
	tw.tween_property(ghost, "scale", end_scale, 0.24).set_ease(Tween.EASE_IN)
	tw.tween_property(ghost, "rotation", 0.08, 0.12)
	await tw.finished
	if _alive(real_target):
		real_target.modulate.a = 1.0
		_bump(real_target, 1.12)
		if not card.data.is_creature():
			_flash(real_target, Color(1.8, 1.8, 1.8))
	if _alive(ghost):
		ghost.queue_free()
	Sfx.blip(0)

## Criatura morre: uma cópia cai e desvanece.
func _animate_death(view: Control) -> void:
	if not _alive(view):
		return
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup((view as CardView).card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = view.size
	ghost.global_position = view.global_position
	ghost.pivot_offset = ghost.size / 2.0
	ghost.modulate = Color(1.0, 0.5, 0.5)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(ghost, "global_position:y", ghost.global_position.y + 60.0, 0.4).set_ease(Tween.EASE_IN)
	tw.tween_property(ghost, "rotation", 0.5, 0.4)
	tw.tween_property(ghost, "modulate:a", 0.0, 0.4)
	tw.chain().tween_callback(ghost.queue_free)

## O inimigo encaixa o golpe: flash vermelho, abanão e o número de dano a voar do total até ele.
func _animate_enemy_hit(amount: int) -> void:
	_flash(enemy_panel, Color(2.0, 0.7, 0.7))
	_bump(enemy_panel, 0.94)
	var label := Label.new()
	label.text = "-" + Cascade.fmt_int(amount)
	label.add_theme_font_size_override("font_size", 44)
	label.add_theme_color_override("font_color", Color(1, 0.92, 0.6))
	label.add_theme_color_override("font_outline_color", Color(0.4, 0.1, 0.1))
	label.add_theme_constant_override("outline_size", 10)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(label)
	label.reset_size()
	label.global_position = total_label.global_position
	var dest := enemy_panel.global_position + Vector2(enemy_panel.size.x * 0.5 - label.size.x * 0.5, 40.0)
	var tw := create_tween()
	tw.tween_property(label, "global_position", dest, 0.35).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
	tw.tween_callback(func(): _flash(enemy_hp_bar, Color(2.5, 1.5, 1.5)))
	tw.tween_property(label, "modulate:a", 0.0, 0.4)
	tw.tween_callback(label.queue_free)

## O inimigo contra-ataca: salta para a direita (rotação) e o ecrã abana.
func _animate_enemy_strike() -> void:
	if not _alive(enemy_panel):
		return
	enemy_panel.pivot_offset = enemy_panel.size / 2.0
	var tw := create_tween()
	tw.tween_property(enemy_panel, "rotation", 0.06, 0.07)
	tw.tween_property(enemy_panel, "rotation", 0.0, 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	_flash(enemy_panel, Color(1.4, 1.4, 1.4))

## Banner central (ANTE N / TURNO N / VITÓRIA).
func _show_banner(text: String, hold: float = 1.1) -> void:
	banner.text = text
	banner.visible = true
	banner.pivot_offset = banner.size / 2.0
	banner.scale = Vector2(0.6, 0.6)
	banner.modulate.a = 0.0
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(banner, "scale", Vector2.ONE, 0.3).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tw.tween_property(banner, "modulate:a", 1.0, 0.2)
	tw.chain().tween_interval(hold)
	tw.chain().tween_property(banner, "modulate:a", 0.0, 0.3)
	tw.chain().tween_callback(func(): banner.visible = false)

func _log(msg: String) -> void:
	log_label.text = msg
	log_label.modulate = Color(1, 0.85, 0.5)
	create_tween().tween_property(log_label, "modulate", Color.WHITE, 0.8)
