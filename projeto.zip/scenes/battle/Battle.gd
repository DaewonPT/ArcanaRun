extends Control
## Cena de batalha (horizontal). Liga a UI ao BattleManager através do EventBus e
## anima a cascata de ataque passo a passo (pop + etiqueta a flutuar + nota a subir).

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const RELIC_VIEW := preload("res://scenes/ui/RelicView.tscn")

const COLOR_POWER := Color(0.22, 0.74, 0.97)
const COLOR_MULT := Color(0.96, 0.25, 0.37)
const COLOR_MULT_X := Color(0.72, 0.35, 0.95)
const COLOR_FORMATION := Color(0.98, 0.75, 0.25)
const COLOR_GROW := Color(0.35, 0.85, 0.45)

const ABILITY_LOG := {
	"steal_gold": "roubou-te ouro",
	"heal_self": "curou-se",
	"destroy_strongest": "destruiu a tua criatura mais forte",
	"damage_all_creatures": "feriu todas as tuas criaturas",
	"discard_random": "fez-te descartar uma carta",
}

@onready var battle: BattleManager = $BattleManager
@onready var layout: Control = $Layout
@onready var hand_box: HBoxContainer = %Hand
@onready var board_box: HBoxContainer = %Board
@onready var relics_bar: HBoxContainer = %RelicsBar
@onready var turn_label: Label = %TurnLabel
@onready var gold_label: Label = %GoldLabel
@onready var enemy_name: Label = %EnemyName
@onready var enemy_hp_bar: ProgressBar = %EnemyHPBar
@onready var enemy_hp_label: Label = %EnemyHPLabel
@onready var enemy_text: Label = %EnemyText
@onready var log_label: Label = %LogLabel
@onready var player_label: Label = %PlayerLabel
@onready var mana_label: Label = %ManaLabel
@onready var end_turn_btn: Button = %EndTurn
@onready var formation_label: Label = %FormationLabel
@onready var power_label: Label = %PowerLabel
@onready var mult_label: Label = %MultLabel
@onready var total_label: Label = %TotalLabel
@onready var power_pill: Control = %PowerPill
@onready var mult_pill: Control = %MultPill

var _board_views: Dictionary = {}   # uid -> CardView
var _relic_views: Dictionary = {}   # relic_id -> RelicView
var _animating: bool = false
var _layout_base: Vector2

func _ready() -> void:
	_layout_base = layout.position
	EventBus.enemy_hp_changed.connect(_on_enemy_hp)
	EventBus.player_hp_changed.connect(func(c, m): player_label.text = "Vida %d/%d" % [c, m])
	EventBus.gold_changed.connect(func(g): gold_label.text = "Ouro %d" % g)
	EventBus.mana_changed.connect(_on_mana_changed)
	EventBus.turn_started.connect(_on_turn_started)
	EventBus.card_drawn.connect(func(_c): _refresh_hand())
	EventBus.hand_changed.connect(_refresh_hand)
	EventBus.creature_died.connect(_on_creature_died)
	EventBus.creature_blocked.connect(_on_creature_blocked)
	EventBus.enemy_ability_used.connect(_on_enemy_ability)
	EventBus.damage_dealt.connect(_on_damage_dealt)
	EventBus.cascade_started.connect(_on_cascade_started)
	EventBus.battle_ended.connect(_on_battle_ended)
	end_turn_btn.pressed.connect(_on_end_turn)

	_build_relics()
	gold_label.text = "Ouro %d" % GameState.gold
	battle.start(_pick_enemy())
	enemy_name.text = battle.enemy.name
	enemy_text.text = battle.enemy.text
	_log("Toca numa carta para a jogar.")

func _pick_enemy() -> Dictionary:
	var pool := CardDB.enemies.filter(func(e): return int(e.get("min_ante", 1)) <= GameState.ante)
	var def: Dictionary = pool[GameState.rng.randi_range(0, pool.size() - 1)]
	var hp := GameState.enemy_hp_for_ante(GameState.ante)
	return {
		"name": def.name,
		"hp": hp, "max_hp": hp,
		"attack": int(def.attack),
		"text": def.get("text", ""),
		"abilities": def.get("abilities", []),
	}

# --- Construção / refresh ---

func _build_relics() -> void:
	for child in relics_bar.get_children():
		child.queue_free()
	_relic_views.clear()
	for id in GameState.relic_ids:
		var view: RelicView = RELIC_VIEW.instantiate()
		relics_bar.add_child(view)
		view.setup(id)
		_relic_views[id] = view

func _refresh_all() -> void:
	_refresh_hand()
	_refresh_board()
	_refresh_preview()

func _refresh_hand() -> void:
	for child in hand_box.get_children():
		child.queue_free()
	for card in battle.deck.hand:
		var view: CardView = CARD_VIEW.instantiate()
		hand_box.add_child(view)
		view.setup(card)
		view.playable = battle.can_play(card)
		view.pressed.connect(_on_hand_card_pressed)

func _refresh_board() -> void:
	if _animating:
		return
	for child in board_box.get_children():
		child.queue_free()
	_board_views.clear()
	for card in battle.creatures():
		var view: CardView = CARD_VIEW.instantiate()
		board_box.add_child(view)
		view.setup(card)
		_board_views[card.uid] = view

## Mostra o que o ataque faria se terminasses o turno agora.
func _refresh_preview() -> void:
	if _animating:
		return
	var c := battle.preview_attack()
	if c.is_empty():
		formation_label.text = "Sem atacantes prontos"
	elif c.formations.is_empty():
		formation_label.text = "Ataque"
	else:
		formation_label.text = " · ".join(PackedStringArray(c.formations))
	power_label.text = str(c.power)
	mult_label.text = Cascade.fmt_mult(c.mult)
	total_label.text = str(c.total())

# --- Handlers ---

func _on_mana_changed(available: int, total: int) -> void:
	mana_label.text = "Mana %d/%d" % [available, total]
	_refresh_hand()

func _on_turn_started(t: int) -> void:
	turn_label.text = "Turno %d/%d  ·  Ante %d" % [t, battle.max_turns, GameState.ante]
	end_turn_btn.disabled = false
	_refresh_all()

func _on_enemy_hp(current: int, max_hp: int) -> void:
	enemy_hp_bar.max_value = max_hp
	enemy_hp_bar.value = current
	enemy_hp_label.text = "%d / %d" % [current, max_hp]

func _on_creature_died(card: CardInstance) -> void:
	Sfx.hit()
	_log("%s morreu." % card.data.name)
	_refresh_board()
	_refresh_preview()

func _on_creature_blocked(card: CardInstance, amount: int) -> void:
	_log("%s bloqueou %d de dano." % [card.data.name, amount])
	if _board_views.has(card.uid):
		var view: CardView = _board_views[card.uid]
		view.refresh()
		_bump(view, 0.9)

func _on_hand_card_pressed(card: CardInstance) -> void:
	if battle.play(card):
		Sfx.select()
		_refresh_all()

func _on_end_turn() -> void:
	if battle.resolving or battle.finished:
		return
	end_turn_btn.disabled = true
	battle.end_turn()

func _on_enemy_ability(enemy_name_str: String, action: String) -> void:
	_log("%s %s!" % [enemy_name_str, ABILITY_LOG.get(action, action)])
	_refresh_all()

func _on_damage_dealt(target: String, amount: int) -> void:
	if target == "enemy":
		_log("Causaste %d de dano." % amount)
	else:
		Sfx.hit()
		_shake(6.0)
		_log("Levaste %d de dano." % amount)

func _on_battle_ended(victory: bool) -> void:
	if victory:
		if GameState.ante >= GameState.max_ante:
			EventBus.run_ended.emit(true)
			SceneRouter.go("run_over")
		else:
			SceneRouter.go("shop")
	else:
		EventBus.run_ended.emit(false)
		SceneRouter.go("run_over")

# --- Cascata ---

func _on_cascade_started(cascade: Cascade) -> void:
	_animating = true
	end_turn_btn.disabled = true
	formation_label.text = "Ataque"
	power_label.text = "0"
	mult_label.text = "1"
	total_label.text = ""
	var shown_formations: Array[String] = []
	var i := 0
	for s in cascade.steps:
		var target := _view_for_step(s)
		var color := _color_for_step(s)
		if s.source_kind == "formation":
			shown_formations.append(s.source_name)
			formation_label.text = " · ".join(PackedStringArray(shown_formations))
		_pop(target, s.label, color)
		power_label.text = str(s.power_after)
		mult_label.text = Cascade.fmt_mult(s.mult_after)
		_bump(power_pill if s.action == "power_add" else mult_pill)
		Sfx.blip(i)
		await get_tree().create_timer(maxf(0.11, 0.30 - i * 0.012)).timeout
		i += 1
	total_label.text = str(cascade.total())
	_bump(total_label, 1.5)
	Sfx.boom()
	_shake(10.0)
	await get_tree().create_timer(0.55).timeout
	_animating = false
	EventBus.cascade_finished.emit()

func _view_for_step(s: Cascade.Step) -> Control:
	match s.source_kind:
		"creature":
			if s.source_card != null and _board_views.has(s.source_card.uid):
				return _board_views[s.source_card.uid]
		"relic":
			if _relic_views.has(s.source_id):
				return _relic_views[s.source_id]
	return formation_label

func _color_for_step(s: Cascade.Step) -> Color:
	if s.grow > 0:
		return COLOR_GROW
	if s.source_kind == "formation":
		return COLOR_FORMATION
	match s.action:
		"power_add":
			return COLOR_POWER
		"mult_mul":
			return COLOR_MULT_X
	return COLOR_MULT

## Pop da vista + etiqueta a flutuar por cima dela.
func _pop(view: Control, text: String, color: Color) -> void:
	_bump(view, 1.22)
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", 26)
	label.add_theme_color_override("font_color", Color.WHITE)
	label.add_theme_color_override("font_outline_color", color.darkened(0.35))
	label.add_theme_constant_override("outline_size", 8)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(label)
	label.reset_size()
	var start := view.global_position + Vector2(view.size.x * 0.5 - label.size.x * 0.5, -label.size.y * 0.6)
	label.global_position = start
	var tw := create_tween().set_parallel(true)
	tw.tween_property(label, "global_position:y", start.y - 46.0, 0.6).set_ease(Tween.EASE_OUT)
	tw.tween_property(label, "modulate:a", 0.0, 0.6).set_delay(0.25)
	tw.chain().tween_callback(label.queue_free)

func _bump(view: Control, amount: float = 1.18) -> void:
	view.pivot_offset = view.size / 2.0
	var tw := create_tween()
	tw.tween_property(view, "scale", Vector2.ONE * amount, 0.07)
	tw.tween_property(view, "scale", Vector2.ONE, 0.13).set_ease(Tween.EASE_OUT)

func _shake(strength: float) -> void:
	var tw := create_tween()
	for i in 5:
		var off := Vector2(randf_range(-strength, strength), randf_range(-strength, strength)) * (1.0 - i / 5.0)
		tw.tween_property(layout, "position", _layout_base + off, 0.03)
	tw.tween_property(layout, "position", _layout_base, 0.04)

func _log(msg: String) -> void:
	log_label.text = msg
	log_label.modulate = Color(1, 0.85, 0.5)
	create_tween().tween_property(log_label, "modulate", Color.WHITE, 0.8)
