extends Control
## Cena de batalha (horizontal). Liga a UI ao BattleManager através do EventBus e anima:
## cartas a voar da mão para o tabuleiro, compra, investida das criaturas na cascata,
## impacto no inimigo, número de dano a voar, partículas no total, banner de ante.
## Grava a run no início de cada turno (BattleManager.to_dict) e retoma-a se houver uma
## batalha pendente em GameState.pending_battle. Pausa, carta em grande e grimório/cemitério
## abrem como overlays (SceneRouter.show_overlay) sem destruir a cena.
## 0.10.0: mão em leque (FanHand), relíquias em medalhões, turnos em pips, retrato do inimigo,
## fundo por ato com o clima, medidor da Cadeia, encantamentos na faixa dos feitiços, escudo e
## lacaios do inimigo, janela de Reação, escolha do Reforço, avisos opcionais, histórico (tocar na
## linha de log), efeitos por cor na cascata e Némesis com falas.

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const RELIC_VIEW := preload("res://scenes/ui/RelicView.tscn")
const FIRE_SHADER := preload("res://assets/shaders/fire.gdshader")

const COLOR_POWER := Color(0.22, 0.74, 0.97)
const COLOR_MULT := Color(0.96, 0.25, 0.37)
const COLOR_MULT_X := Color(0.72, 0.35, 0.95)
const COLOR_FORMATION := Color(0.98, 0.75, 0.25)
const COLOR_GROW := Color(0.35, 0.85, 0.45)
const COLOR_GOLD := Color(0.98, 0.85, 0.3)
const COLOR_SEAL := Color(0.9, 0.5, 0.9)
const COLOR_CLIMATE := Color(0.35, 0.8, 0.85)
const COLOR_BOSS_RELIC := Color(0.95, 0.4, 0.4)
const DISCARD_TINT := Color(0.8, 0.6, 1.0)
const BOTTOM_TINT := Color(0.6, 0.8, 1.0)
const VARIANT_NAMES := {"scout": "Batedor", "guard": "Guarda", "elite": "Elite", "boss": "Boss", "nemesis": "Némesis"}
const COLOR_TRIBE := Color(0.55, 0.9, 0.75)
const COLOR_CHAIN := Color(1.0, 0.62, 0.3)
const COLOR_ENCHANT := Color(0.75, 0.6, 1.0)
const HISTORY_MAX := 30

const ABILITY_LOG := {
	"steal_gold": "roubou-te ouro",
	"heal_self": "curou-se",
	"destroy_strongest": "destruiu a tua criatura mais forte",
	"damage_all_creatures": "feriu todas as tuas criaturas",
	"discard_random": "fez-te descartar uma carta",
	"gold_tax": "cobrou-te ouro",
	"heal_self_pct": "recuperou vida",
}

@onready var battle: BattleManager = $BattleManager
@onready var layout: Control = $Layout
@onready var hand_box: FanHand = %Hand
@onready var board_box: HBoxContainer = %Board
@onready var spell_strip: HBoxContainer = %SpellStrip
@onready var spell_hint: Label = %SpellHint
@onready var relics_bar: HBoxContainer = %RelicsBar
@onready var turn_label: Label = %TurnLabel
@onready var gold_label: Label = %GoldLabel
@onready var pause_btn: Button = %PauseBtn
@onready var enemy_panel: Control = %EnemyPanel
@onready var enemy_name: Label = %EnemyName
@onready var enemy_hp_bar: ProgressBar = %EnemyHPBar
@onready var enemy_hp_ghost: ProgressBar = %EnemyHPGhost
@onready var enemy_hp_label: Label = %EnemyHPLabel
@onready var enemy_text: Label = %EnemyText
@onready var counter_label: Label = %CounterLabel
@onready var emblem: PanelContainer = %Emblem
@onready var emblem_label: Label = %EmblemLabel
@onready var log_label: Label = %LogLabel
@onready var undo_btn: Button = %UndoBtn
@onready var player_label: Label = %PlayerLabel
@onready var mana_label: Label = %ManaLabel
@onready var end_turn_btn: Button = %EndTurn
@onready var discard_btn: Button = %DiscardBtn
@onready var library_btn: Button = %LibraryBtn
@onready var graveyard_btn: Button = %GraveyardBtn
@onready var formation_label: Label = %FormationLabel
@onready var power_label: Label = %PowerLabel
@onready var mult_label: Label = %MultLabel
@onready var total_label: Label = %TotalLabel
@onready var power_pill: Control = %PowerPill
@onready var mult_pill: Control = %MultPill
@onready var banner: Label = %Banner
@onready var mulligan_btn: Button = %MulliganBtn
@onready var pw_row: HBoxContainer = %PwRow

var _board_views: Dictionary = {}   # uid -> CardView
var _hand_views: Dictionary = {}    # uid -> CardView
var _spell_chips: Dictionary = {}   # uid -> Control
var _relic_views: Dictionary = {}   # relic_id -> RelicView
var _animating: bool = false
var _discard_mode: bool = false
var _layout_base: Vector2
var _particles: CPUParticles2D
var _hp_tween: Tween
var _pause_menu: PauseMenu
var _resumed: bool = false
var _undo_stack: Array[Dictionary] = []
var _undo_turn: int = 0
var _drag_ghost: Control
var _drag_view: Control
var _attack_style: StyleBoxFlat
var _lethal_style: StyleBoxFlat
var _last_preview_total: int = 0
var _pw_buttons: Array[Button] = []
var _pw_loyalty: Label
var _pw_name: Label
var _pw_panel: Control
var _climate_chip: Control
var _climate_label: Label
var _contract_chip: Control
var _bubble: Control
var _bubble_tw: Tween
var _banner_tw: Tween
var _banner_lock_until: int = 0
var _hp_marker: ColorRect
var _fire_layer: Control
var _fire_rects: Array[ColorRect] = []
var _fire_level: float = 0.0
var _fire_target: float = 0.0
var _hit_line_said: bool = false
var _mana_pips: ManaPips
var _intent_row: HBoxContainer
var _intent_sig: String = ""
var _last_cascade: Cascade
# 0.10.0
var _backdrop: BattleBackdrop
var _portrait: EnemyPortrait
var _turn_pips: TurnPips
var _chain_meter: ChainMeter
var _ench_box: HBoxContainer
var _ench_chips: Dictionary = {}   # uid -> Control
var _defense_row: HBoxContainer
var _history: Array[String] = []
var _modal: Control                # janela de Reação / escolha do Reforço / aviso
var _drag_shadow: Panel
var _drag_last_x: float = 0.0

## Ícones da intenção do inimigo: ação → [ícone, cor, mostra o valor?]
const INTENT_ICONS := {
	"steal_gold": ["coin", Color(0.98, 0.8, 0.3), true],
	"heal_self": ["cross", Color(0.45, 0.9, 0.5), true],
	"destroy_strongest": ["skull", Color(0.92, 0.92, 0.92), false],
	"damage_all_creatures": ["burst", Color(1.0, 0.6, 0.3), true],
	"discard_random": ["card", Color(0.8, 0.6, 1.0), true],
	"heal_self_pct": ["cross", Color(0.45, 0.9, 0.5), true],
}

const ABILITY_INTENT := {
	"steal_gold": "rouba %d ouro",
	"heal_self": "cura-se %d",
	"destroy_strongest": "destrói a tua criatura mais forte",
	"damage_all_creatures": "%d de dano às tuas criaturas",
	"discard_random": "descarta-te %d carta(s)",
	"heal_self_pct": "cura-se %d%% da vida",
}

func _ready() -> void:
	_layout_base = layout.position
	EventBus.enemy_hp_changed.connect(_on_enemy_hp)
	EventBus.player_hp_changed.connect(_set_life)
	EventBus.gold_changed.connect(func(g): gold_label.text = tr("Ouro %d") % g)
	EventBus.mana_changed.connect(_on_mana_changed)
	EventBus.discards_changed.connect(_on_discards_changed)
	EventBus.turn_started.connect(_on_turn_started)
	EventBus.card_drawn.connect(func(_c): _refresh_hand())
	EventBus.hand_changed.connect(_refresh_hand)
	EventBus.spell_cast.connect(_on_spell_cast)
	EventBus.creature_died.connect(_on_creature_died)
	EventBus.creature_blocked.connect(_on_creature_blocked)
	EventBus.card_discarded.connect(_on_card_discarded)
	EventBus.card_grew.connect(_on_card_grew)
	EventBus.enemy_ability_used.connect(_on_enemy_ability)
	EventBus.damage_dealt.connect(_on_damage_dealt)
	EventBus.cascade_started.connect(_on_cascade_started)
	EventBus.battle_ended.connect(_on_battle_ended)
	EventBus.relics_changed.connect(_build_relics)
	EventBus.mulligan_taken.connect(_on_mulligan_taken)
	EventBus.card_transformed.connect(_on_card_transformed)
	EventBus.card_flashback.connect(_on_card_flashback)
	EventBus.seal_triggered.connect(_on_seal_triggered)
	EventBus.formation_leveled.connect(_on_formation_leveled)
	EventBus.planeswalker_changed.connect(_refresh_planeswalker)
	EventBus.card_exiled_run.connect(_on_card_exiled_run)
	EventBus.boss_ascended.connect(_on_boss_ascended)
	EventBus.boss_phase2.connect(_on_boss_phase2)
	EventBus.death_saved.connect(_on_death_saved)
	EventBus.contract_resolved.connect(_on_contract_resolved)
	EventBus.creature_exiled.connect(_on_creature_exiled)
	EventBus.climate_hit.connect(_on_climate_hit)
	EventBus.gold_changed.connect(func(_g): battle.on_gold_changed())
	EventBus.token_created.connect(_on_token_created)
	EventBus.enchantment_played.connect(_on_enchantment_played)
	EventBus.card_kicked.connect(_on_card_kicked)
	EventBus.reaction_window.connect(_on_reaction_window)
	EventBus.reaction_played.connect(_on_reaction_played)
	EventBus.shield_hit.connect(_on_shield_hit)
	EventBus.minions_changed.connect(func(_n): _refresh_defense())
	Settings.changed.connect(_refresh_texts)
	end_turn_btn.pressed.connect(_on_end_turn)
	mulligan_btn.pressed.connect(_on_mulligan)
	discard_btn.toggled.connect(_on_discard_toggled)
	pause_btn.pressed.connect(_open_pause)
	library_btn.pressed.connect(_open_library)
	graveyard_btn.pressed.connect(_open_graveyard)
	undo_btn.pressed.connect(_on_undo)
	_apply_handedness()
	_attack_style = end_turn_btn.get_theme_stylebox("normal")
	_lethal_style = _attack_style.duplicate()
	_lethal_style.bg_color = Color(0.2, 0.68, 0.32)
	_make_particles()
	_make_fire()
	_make_status_icons()
	_make_intent_row()
	_make_calc_tap()
	_make_010_widgets()
	Settings.set_battle_screen_on(true)
	# Contorno escuro no texto por cima do cálculo: continua legível com as chamas atrás.
	for l in [log_label, formation_label]:
		l.add_theme_color_override("font_outline_color", Color(0.06, 0.04, 0.09))
		l.add_theme_constant_override("outline_size", 6)

	_build_relics()
	gold_label.text = tr("Ouro %d") % GameState.gold
	# Quebra-cabeças: mão fixa, 1 turno; sem gravação nem mapa.
	if GameState.puzzle_id != "":
		var training := GameState.puzzle_id == "training"
		var pdef := GameState.training_def() if training else CardDB.get_puzzle(GameState.puzzle_id)
		_resumed = true
		battle.start_puzzle(pdef)
		_resumed = false
		_refresh_enemy_header()
		_build_info_row()
		_setup_backdrop()
		_refresh_all()
		if training:
			_log(tr("Treino: joga a mão e ataca. O boneco aguenta tudo."))
			_show_banner(tr("TREINO"), 1.0)
		else:
			_log(tr("Um só turno: encontra o ataque certo."))
			_show_banner(tr("ENIGMA") + "\n" + tr(String(pdef.get("name", ""))), 1.4)
		return
	# Retoma uma batalha gravada a meio, se houver; senão começa uma nova neste ante.
	var resumed := false
	if not GameState.pending_battle.is_empty():
		var state := GameState.pending_battle
		GameState.pending_battle = {}
		_resumed = true   # sem banner "TURNO N" durante o restore
		resumed = battle.restore(state)
		_resumed = false
	if not resumed:
		if not GameState.map_choice.has("battle"):
			GameState.choose_battle("boss" if GameState.is_boss_ante(GameState.ante) else "scout")
		battle.start(GameState.pick_enemy(GameState.ante))
	_refresh_enemy_header()
	_build_info_row()
	_setup_backdrop()
	_refresh_all()
	if not resumed and not Stats.tutorial_done() and GameState.ante == 1 and battle.turn == 1:
		TutorialOverlay.open(self)
	if resumed:
		_log(tr("Run retomada no turno %d.") % battle.turn)
		_show_banner(tr("ANTE %d") % GameState.ante + "\n" + tr("TURNO %d") % battle.turn)
	else:
		_log(tr("Toca numa carta para a jogar.") if not battle.can_mulligan() else tr("Toca numa carta para a jogar — ou faz Mulligan."))
		if battle.enemy.get("boss", false):
			_show_banner(tr("BOSS") + "\n" + tr(battle.enemy.name), 1.4)
			_say_after(_boss_line("intro"), _d(1.7) + 0.2, 3.4)
		elif String(battle.enemy.get("variant", "")) == "nemesis":
			_show_banner(tr("NÉMESIS") + "\n" + tr(battle.enemy.name) + "  ·  " + tr("Nível %d") % int(battle.enemy.get("nemesis_level", 1)), 1.4)
			_say_after(_boss_line("intro"), _d(1.7) + 0.2, 3.4)
		else:
			_show_banner(tr("ATO %s · ANTE %d") % [GameState.act_name(), GameState.ante] + "\n" + tr(battle.enemy.name) + "  ·  " + tr(VARIANT_NAMES.get(String(battle.enemy.get("variant", "scout")), "Batedor")))

## Modo canhoto: a coluna dos botões passa para a direita.
func _apply_handedness() -> void:
	var middle: HBoxContainer = layout.get_node("Middle")
	var left_col: Control = middle.get_node("LeftCol")
	middle.move_child(left_col, middle.get_child_count() - 1 if Settings.left_handed else 0)

## Nome, emblema (inicial numa cor derivada do id) e texto do inimigo; moldura dourada nos bosses.
func _refresh_enemy_header() -> void:
	enemy_name.text = battle.enemy.name
	enemy_text.text = battle.enemy.text
	if battle.ascended and String(battle.enemy.get("rule2_text", "")) != "":
		enemy_text.text = String(battle.enemy.get("rule2_text", ""))
	var id := String(battle.enemy.get("id", battle.enemy.name))
	var name_txt := tr(String(battle.enemy.name))
	emblem_label.text = name_txt.substr(0, 1).to_upper() if name_txt != "" else "?"
	var style: StyleBoxFlat = emblem.get_theme_stylebox("panel").duplicate()
	style.bg_color = Color.from_hsv(fmod(float(abs(id.hash())) / 1000.0, 1.0), 0.55, 0.75)
	emblem.add_theme_stylebox_override("panel", style)
	if _portrait != null:
		_portrait.archetype = _portrait_archetype()
		_portrait.tint = style.bg_color
		_portrait.boss = bool(battle.enemy.get("boss", false)) or String(battle.enemy.get("variant", "")) == "nemesis"
	_refresh_defense()
	enemy_name.add_theme_color_override("font_color", Color(1.0, 0.5, 0.45) if battle.phase2 else Color.WHITE)
	if battle.enemy.get("boss", false):
		_ensure_hp_marker()
		var panel_style: StyleBoxFlat = enemy_panel.get_theme_stylebox("panel").duplicate()
		panel_style.border_color = UiKit.GOLD
		panel_style.border_width_left = 3
		panel_style.border_width_right = 3
		panel_style.border_width_top = 3
		panel_style.border_width_bottom = 3
		if battle.phase2:
			panel_style.border_color = Color(0.95, 0.35, 0.3)
		enemy_panel.add_theme_stylebox_override("panel", panel_style)

## Bosses: risca dourada a meio da barra de vida (abaixo dela o boss desperta).
func _ensure_hp_marker() -> void:
	if _hp_marker == null:
		_hp_marker = ColorRect.new()
		_hp_marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_hp_marker.anchor_left = 0.5
		_hp_marker.anchor_right = 0.5
		_hp_marker.anchor_bottom = 1.0
		_hp_marker.offset_left = -2.0
		_hp_marker.offset_right = 2.0
		_hp_marker.offset_top = -4.0
		_hp_marker.offset_bottom = 4.0
		enemy_hp_bar.get_parent().add_child(_hp_marker)
	_hp_marker.color = Color(1, 1, 1, 0.3) if battle.phase2 else UiKit.GOLD

func _make_particles() -> void:
	_particles = CPUParticles2D.new()
	_particles.emitting = false
	_particles.one_shot = true
	_particles.explosiveness = 0.95
	_particles.amount = 48
	_particles.lifetime = 0.8
	_particles.spread = 180.0
	_particles.direction = Vector2(0, -1)
	_particles.gravity = Vector2(0, 700)
	_particles.initial_velocity_min = 220.0
	_particles.initial_velocity_max = 520.0
	_particles.scale_amount_min = 3.0
	_particles.scale_amount_max = 7.0
	_particles.color = Color(1.0, 0.85, 0.35)
	add_child(_particles)

## Chamas atrás das pílulas de Poder e Mult (o fundo das pílulas tapa a base; vêem-se a subir).
## Crescem com o ataque em relação à vida que falta ao inimigo: letal = fogo no máximo.
func _make_fire() -> void:
	_fire_layer = Control.new()
	_fire_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fire_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(_fire_layer)
	move_child(_fire_layer, layout.get_index())
	for tint in [Vector3(0.25, 0.6, 1.0), Vector3(1.0, 0.35, 0.12)]:
		var r := ColorRect.new()
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		r.visible = false
		var m := ShaderMaterial.new()
		m.shader = FIRE_SHADER
		m.set_shader_parameter("tint", tint)
		m.set_shader_parameter("intensity", 0.0)
		r.material = m
		_fire_layer.add_child(r)
		_fire_rects.append(r)

## 0..1: um ataque de 25 % da vida restante começa a arder; letal arde no máximo.
func _fire_for(total: float) -> float:
	var hp := float(maxi(1, int(battle.enemy.get("hp", 1))))
	return clampf((total / hp - 0.25) / 0.75, 0.0, 1.0)

func _process(delta: float) -> void:
	_fire_level = move_toward(_fire_level, _fire_target, delta * 1.6)
	var on := _fire_level > 0.01
	for i in _fire_rects.size():
		var r := _fire_rects[i]
		r.visible = on
		if not on:
			continue
		var pill: Control = power_pill if i == 0 else mult_pill
		var pr := pill.get_global_rect()
		var h := pr.size.y * 2.3
		r.global_position = Vector2(pr.position.x - pr.size.x * 0.08, pr.end.y - h)
		r.size = Vector2(pr.size.x * 1.16, h)
		(r.material as ShaderMaterial).set_shader_parameter("intensity", _fire_level)

## Vida com um coração e mana em cristais (menos texto na coluna da esquerda).
func _make_status_icons() -> void:
	var row: HBoxContainer = player_label.get_parent()
	var heart := CardIcon.new("heart", Color(0.95, 0.35, 0.4), 24.0)
	heart.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(heart)
	row.move_child(heart, player_label.get_index())
	player_label.add_theme_font_size_override("font_size", 22)
	_mana_pips = ManaPips.new()
	_mana_pips.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(_mana_pips)
	row.move_child(_mana_pips, mana_label.get_index())
	mana_label.add_theme_font_size_override("font_size", 16)
	_set_life(GameState.player_hp, GameState.player_max_hp)

func _set_life(current: int, max_hp: int) -> void:
	player_label.text = "%d/%d" % [current, max_hp]
	player_label.tooltip_text = tr("Vida %d/%d") % [current, max_hp]

func _set_mana(available: int, total: int) -> void:
	mana_label.text = "%d/%d" % [available, total]
	if _mana_pips != null:
		_mana_pips.set_mana(available, total)

## Duração de uma animação com a velocidade das Configurações.
func _d(seconds: float) -> float:
	return Settings.dur(seconds)

# --- Construção / refresh ---

func _build_relics() -> void:
	for child in relics_bar.get_children():
		relics_bar.remove_child(child)
		child.queue_free()
	_relic_views.clear()
	var n := GameState.relic_ids.size() + GameState.boss_relics.size()
	var w := _relic_width(n)
	for id in GameState.relic_ids:
		var view: RelicView = RELIC_VIEW.instantiate()
		relics_bar.add_child(view)
		view.setup(id)
		view.set_width(w)
		view.pressed.connect(_on_relic_pressed)
		view.drag_started.connect(_on_relic_drag_started)
		view.drag_moved.connect(_on_relic_drag_moved)
		view.drag_ended.connect(_on_relic_drag_ended)
		_relic_views[id] = view
	# Relíquias de boss: depois das normais (disparam a seguir na cascata), sem arrastar.
	for id in GameState.boss_relics:
		var bview: RelicView = RELIC_VIEW.instantiate()
		relics_bar.add_child(bview)
		bview.setup(id)
		bview.set_width(w)
		bview.pressed.connect(_on_relic_pressed)
		_relic_views[id] = bview
	if not _animating and battle.effects != null:
		_refresh_preview()

## Largura de cada relíquia para caberem todas na barra de cima (sem empurrar o ecrã).
func _relic_width(_n: int) -> float:
	return RelicView.SIZE   # medalhões: tamanho fixo (o nome abre ao tocar)

func _refresh_all() -> void:
	_refresh_hand()
	_refresh_board()
	_refresh_spells()
	_refresh_enchantments()
	_refresh_defense()
	_refresh_preview()
	_refresh_zone_buttons()
	for v in _relic_views.values():
		if _alive(v):
			(v as RelicView).refresh_value()

## Texto que depende do idioma (chamado quando as Configurações mudam).
func _turn_text() -> String:
	var line1 := tr("Turno %d/%d  ·  Ante %d") % [battle.turn, battle.max_turns + battle.extra_turns, GameState.ante]
	if battle.puzzle:
		return line1.split("  ·  ")[0] + "\n" + tr("Quebra-cabeças")
	var line2 := tr("Ato %s") % GameState.act_name() + "  ·  " + tr(VARIANT_NAMES.get(String(battle.enemy.get("variant", "scout")), "Batedor"))
	if GameState.stake > 1:
		line2 += "  ·  " + tr("Selo %d") % GameState.stake
	return line1 + "\n" + line2

func _refresh_texts() -> void:
	if battle.enemy.is_empty():
		return
	_apply_handedness()
	turn_label.text = _turn_text()
	_refresh_pips()
	gold_label.text = tr("Ouro %d") % GameState.gold
	_set_life(GameState.player_hp, GameState.player_max_hp)
	_set_mana(battle.mana_available, battle.mana_total)
	_refresh_enemy_header()
	_refresh_discard_button()
	_refresh_zone_buttons()
	_refresh_planeswalker()
	if not _animating:
		_refresh_preview()
		for v in _hand_views.values():
			if _alive(v):
				v.refresh()
		for v in _board_views.values():
			if _alive(v):
				v.refresh()

func _refresh_zone_buttons() -> void:
	library_btn.text = tr("GRIMÓRIO %d") % battle.deck.library.size()
	var fb := 0
	for c in battle.flashback_cards():
		if battle.can_flashback(c):
			fb += 1
	graveyard_btn.text = tr("CEMITÉRIO %d") % battle.deck.graveyard.size() + (" ↺" if fb > 0 else "")
	undo_btn.disabled = _undo_stack.is_empty() or battle.resolving or battle.finished
	mulligan_btn.visible = battle.can_mulligan()
	mulligan_btn.text = tr("MULLIGAN") if battle.mulligans == 0 else tr("MULLIGAN (−%d)") % (battle.mulligans + 1)
	_refresh_planeswalker()

func _refresh_hand() -> void:
	# Se a mão é a mesma (mesmas cartas, mesma ordem), só atualiza as vistas — não interrompe animações.
	var live := hand_box.get_children().filter(func(c): return not c.is_queued_for_deletion())
	var same := _hand_views.size() == battle.deck.hand.size() and live.size() == battle.deck.hand.size()
	if same:
		var i := 0
		for card in battle.deck.hand:
			if not _hand_views.has(card.uid) or live[i] != _hand_views[card.uid]:
				same = false
				break
			i += 1
	if same:
		for card in battle.deck.hand.duplicate():
			var v: CardView = _hand_views[card.uid]
			if _alive(v):
				v.refresh()
				v.playable = battle.can_play(card) or card.data.is_land() or _discard_mode or battle.pending_bottom > 0
				v.modulate = BOTTOM_TINT if battle.pending_bottom > 0 else (DISCARD_TINT if _discard_mode else Color.WHITE)
				v.delta = 0 if (_discard_mode or _animating or battle.pending_bottom > 0) else battle.preview_play(card)
		_refresh_preview()
		_refresh_zone_buttons()
		return
	var previous := _hand_views.keys()
	for child in hand_box.get_children():
		hand_box.remove_child(child)   # sai já da árvore: nunca se desenha em duplicado com as novas
		child.queue_free()
	_hand_views.clear()
	var stagger := 0.0
	for card in battle.deck.hand.duplicate():
		var view: CardView = CARD_VIEW.instantiate()
		hand_box.add_child(view)
		view.setup(card)
		view.playable = battle.can_play(card) or card.data.is_land() or _discard_mode or battle.pending_bottom > 0
		if battle.pending_bottom > 0:
			view.modulate = BOTTOM_TINT
		elif _discard_mode:
			view.modulate = DISCARD_TINT
		view.pressed.connect(_on_hand_card_pressed)
		view.long_pressed.connect(_on_card_long_pressed)
		view.delta = 0 if (_discard_mode or _animating or battle.pending_bottom > 0) else battle.preview_play(card)
		_hand_views[card.uid] = view
		if not (card.uid in previous):
			_animate_draw(view, stagger)
			stagger += 0.05
	_refresh_preview()
	_refresh_zone_buttons()

func _refresh_board() -> void:
	if _animating:
		return
	var creatures := battle.creatures()
	var live := board_box.get_children().filter(func(c): return not c.is_queued_for_deletion())
	var same := _board_views.size() == creatures.size() and live.size() == creatures.size()
	if same:
		var i := 0
		for card in creatures:
			if not _board_views.has(card.uid) or live[i] != _board_views[card.uid]:
				same = false
				break
			i += 1
	if same:
		for card in creatures:
			if _alive(_board_views[card.uid]):
				(_board_views[card.uid] as CardView).refresh()
		return
	for child in board_box.get_children():
		board_box.remove_child(child)
		child.queue_free()
	_board_views.clear()
	for card in creatures:
		var view: CardView = CARD_VIEW.instantiate()
		board_box.add_child(view)
		view.setup(card)
		view.long_pressed.connect(_on_card_long_pressed)
		view.pressed.connect(_on_card_long_pressed)   # no tabuleiro um toque simples também abre em grande
		view.draggable = true
		view.drag_started.connect(_on_board_drag_started)
		view.drag_moved.connect(_on_board_drag_moved)
		view.drag_ended.connect(_on_board_drag_ended)
		_board_views[card.uid] = view

func _refresh_spells() -> void:
	if _animating:
		return
	for chip in _spell_chips.values():
		if is_instance_valid(chip):
			spell_strip.remove_child(chip)
			chip.queue_free()
	_spell_chips.clear()
	spell_hint.visible = battle.spells_this_turn.is_empty() and battle.enchantments.is_empty()
	var at := spell_hint.get_index() + 1
	for sp in battle.spells_this_turn:
		var chip := _make_chip(sp)
		spell_strip.add_child(chip)
		spell_strip.move_child(chip, at)
		at += 1
		_spell_chips[sp.uid] = chip
	_fit_chips()

const CHIP_MIN_W := 44.0
const CHIP_MAX_W := 180.0

func _make_chip(sp: CardInstance, text_override: String = "") -> Control:
	var chip := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = CardView.COLORS.get(sp.data.primary_color(), CardView.COLORS.colorless)
	style.set_corner_radius_all(8)
	style.set_content_margin_all(6)
	chip.add_theme_stylebox_override("panel", style)
	chip.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	var label := Label.new()
	if text_override != "":
		label.text = text_override
	else:
		label.text = ("↺ " if sp.zone == CardInstance.Zone.EXILE else "") + ("%s  %d⚔" % [sp.data.display_name(), sp.data.power] if sp.data.power > 0 else sp.data.display_name())
	label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	label.add_theme_font_size_override("font_size", 15)
	label.add_theme_color_override("font_color", Color(0.08, 0.08, 0.1) if style.bg_color.get_luminance() > 0.45 else Color.WHITE)
	# Largura natural do texto (as fichas encolhem só quando não cabem todas — ver _fit_chips).
	var font := label.get_theme_font("font")
	var natural := font.get_string_size(label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, 15).x if font != null else label.text.length() * 8.0
	label.set_meta("natural_w", ceilf(natural) + 2.0)
	label.custom_minimum_size.x = clampf(ceilf(natural) + 2.0, CHIP_MIN_W, CHIP_MAX_W)
	chip.tooltip_text = sp.data.display_name()
	chip.add_child(label)
	return chip

## Reparte a largura da faixa pelas fichas de feitiços e encantamentos: cada uma mostra o nome
## inteiro (até CHIP_MAX_W) e só encolhe, com reticências, quando não cabem todas.
func _fit_chips() -> void:
	var labels: Array[Label] = []
	for dict in [_spell_chips, _ench_chips]:
		for chip in dict.values():
			if is_instance_valid(chip) and chip.get_child_count() > 0:
				labels.append(chip.get_child(0) as Label)
	if labels.is_empty():
		return
	var room := spell_strip.size.x if spell_strip.size.x > 200.0 else 560.0
	if _chain_meter != null and _chain_meter.visible:
		room -= _chain_meter.get_combined_minimum_size().x + 16.0
	var per := room / float(labels.size()) - 8.0 - 12.0
	for label in labels:
		var natural: float = float(label.get_meta("natural_w", CHIP_MAX_W))
		label.custom_minimum_size.x = clampf(minf(natural, per), CHIP_MIN_W, CHIP_MAX_W)

## Mostra o que o ataque faria se atacasses agora.
func _refresh_preview() -> void:
	if _animating:
		return
	var c := battle.preview_attack()
	if c.is_empty():
		formation_label.text = tr("Sem atacantes")
	elif c.formations.is_empty():
		formation_label.text = tr("Ataque")
	else:
		var names: Array[String] = []
		for i in c.formations.size():
			var lvl: int = c.formation_levels[i] if i < c.formation_levels.size() else 0
			names.append(tr(c.formations[i]) + ((" (%s %d)" % [tr("nv"), lvl]) if lvl > 0 else ""))
		formation_label.text = " · ".join(PackedStringArray(names))
	var extra_names: Array[String] = []
	for st in c.steps:
		if (st.source_kind == "tribe" or st.source_kind == "seal_set") and not (st.source_name in extra_names):
			extra_names.append(st.source_name)
	if not extra_names.is_empty() and not c.is_empty():
		formation_label.text += "  ·  " + " · ".join(PackedStringArray(extra_names))
	power_label.text = Cascade.fmt_int(c.power)
	mult_label.text = Cascade.fmt_mult(c.mult)
	var net := c.net_total()
	_set_total(Cascade.fmt_int(net))
	_last_preview_total = net
	_fire_target = _fire_for(net)
	_refresh_chain_meter()
	var lethal := net > 0 and net >= int(battle.enemy.hp)
	var shield_txt := ("  ·  " + tr("Escudo −%s") % Cascade.fmt_int(c.shield)) if c.shield > 0 and c.total() > 0 else ""
	if lethal:
		end_turn_btn.text = tr("ATACAR") + "   " + Cascade.fmt_int(net) + "  ·  " + tr("LETAL")
		end_turn_btn.add_theme_stylebox_override("normal", _lethal_style)
	else:
		end_turn_btn.text = (tr("ATACAR") + "   " + Cascade.fmt_int(net) + shield_txt) if c.total() > 0 else tr("ATACAR")
		end_turn_btn.add_theme_stylebox_override("normal", _attack_style)
	_refresh_hp_bars()
	_refresh_counter(lethal)

## Total do ataque: a letra encolhe com números muito grandes (para nunca empurrar o ecrã).
func _set_total(text: String) -> void:
	total_label.text = text
	var n := text.length()
	total_label.add_theme_font_size_override("font_size", 46 if n <= 9 else (38 if n <= 12 else 30))

## Barra do inimigo: a parte clara (fantasma) é o dano do ataque atual.
func _refresh_hp_bars() -> void:
	var hp := int(battle.enemy.hp)
	enemy_hp_ghost.max_value = battle.enemy.max_hp
	enemy_hp_bar.max_value = battle.enemy.max_hp
	enemy_hp_ghost.value = hp
	if _animating:
		return
	enemy_hp_bar.value = max(0, hp - _last_preview_total)

## Contra-ataque previsto e intenção do inimigo para este turno.
func _refresh_counter(lethal: bool) -> void:
	if lethal:
		counter_label.text = tr("O ataque é letal: não há contra-ataque.")
		counter_label.add_theme_color_override("font_color", Color(0.45, 0.9, 0.55))
		_refresh_intent(true, {})
		return
	counter_label.add_theme_color_override("font_color", Color(1, 0.6, 0.55))
	var p := battle.preview_enemy_phase()
	_refresh_intent(false, p)
	var parts: Array[String] = []
	if int(p["damage"]) <= 0:
		parts.append(tr("Não ataca."))
	elif p["blocker"] != null:
		parts.append(tr("Ataca %d: %s bloqueia e sobrevive.") % [int(p["damage"]), tr((p["blocker"] as CardInstance).data.name)])
	elif (p["deaths"] as Array).is_empty():
		parts.append(tr("Ataca %d: ninguém bloqueia, levas tu %d.") % [int(p["damage"]), int(p["player_damage"])])
	else:
		parts.append(tr("Ataca %d (letal): %d criatura(s) sacrificam-se, levas %d.") % [int(p["damage"]), (p["deaths"] as Array).size(), int(p["player_damage"])])
	var intents: Array[String] = []
	for a in battle.enemy_intent(battle.turn):
		var tmpl: String = ABILITY_INTENT.get(String(a.get("action", "")), "")
		if tmpl == "":
			continue
		intents.append(tr(tmpl) % int(a.get("value", 0)) if tmpl.contains("%d") else tr(tmpl))
	if not intents.is_empty():
		parts.append(tr("Depois: ") + "; ".join(PackedStringArray(intents)) + ".")
	counter_label.text = " ".join(PackedStringArray(parts))

# --- Intenção do inimigo em ícones (o texto completo abre ao tocar) ---

func _make_intent_row() -> void:
	var vbox: Control = counter_label.get_parent()
	_intent_row = HBoxContainer.new()
	_intent_row.add_theme_constant_override("separation", 6)
	_intent_row.custom_minimum_size.y = 40
	_intent_row.mouse_filter = Control.MOUSE_FILTER_STOP
	vbox.add_child(_intent_row)
	vbox.move_child(_intent_row, counter_label.get_index())
	counter_label.visible = false
	_intent_row.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed and not SceneRouter.has_overlay():
			Sfx.select()
			CardZoom.show_text(tr(battle.enemy.name), counter_label.text, tr("Intenção do inimigo"), Color(1, 0.6, 0.55)))

func _intent_chip(parts: Array, bg: Color) -> PanelContainer:
	var chip := PanelContainer.new()
	chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	chip.add_theme_stylebox_override("panel", UiKit.flat(bg, 8, Color(0, 0, 0, 0), 0, 6))
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 3)
	chip.add_child(row)
	for part in parts:
		var icon := CardIcon.new(String(part[0]), part[1], 18.0)
		icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		row.add_child(icon)
		if String(part[2]) != "":
			var l := UiKit.label(String(part[2]), 17, Color.WHITE)
			l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
			row.add_child(l)
	return chip

func _refresh_intent(lethal: bool, p: Dictionary) -> void:
	if _intent_row == null:
		return
	var sig := "L" if lethal else "%d|%s|%d|%d|%s" % [int(p.get("damage", 0)), str(p.get("blocker") != null), (p.get("deaths", []) as Array).size(), int(p.get("player_damage", 0)), str(battle.enemy_intent(battle.turn))]
	if sig == _intent_sig and _intent_row.get_child_count() > 0:
		return
	_intent_sig = sig
	for c in _intent_row.get_children():
		_intent_row.remove_child(c)
		c.queue_free()
	if lethal:
		_intent_row.add_child(_intent_chip([["check", Color(0.45, 0.95, 0.55), tr("Letal: sem contra-ataque")]], Color(0.12, 0.3, 0.16)))
		return
	var dmg := int(p.get("damage", 0))
	if dmg <= 0:
		_intent_row.add_child(_intent_chip([["shield", Color(0.7, 0.8, 1.0), tr("Não ataca")]], Color(0.16, 0.18, 0.28)))
	else:
		var parts: Array = [["creature", Color(1.0, 0.55, 0.5), str(dmg)]]
		if p.get("blocker") != null:
			parts.append(["shield", Color(0.7, 0.85, 1.0), ""])
		else:
			if not (p.get("deaths", []) as Array).is_empty():
				parts.append(["skull", Color(0.92, 0.92, 0.92), str((p["deaths"] as Array).size())])
			if int(p.get("player_damage", 0)) > 0:
				parts.append(["heart", Color(0.95, 0.35, 0.4), "−%d" % int(p["player_damage"])])
		_intent_row.add_child(_intent_chip(parts, Color(0.3, 0.12, 0.14)))
	for a in battle.enemy_intent(battle.turn):
		var info: Array = INTENT_ICONS.get(String(a.get("action", "")), [])
		if info.is_empty():
			continue
		_intent_row.add_child(_intent_chip([[info[0], info[1], str(int(a.get("value", 0))) if info[2] else ""]], Color(0.2, 0.16, 0.28)))

# --- Detalhe da cascata (tocar no cálculo) ---

func _make_calc_tap() -> void:
	var calc: Control = power_pill.get_parent()
	calc.mouse_filter = Control.MOUSE_FILTER_STOP
	power_pill.mouse_filter = Control.MOUSE_FILTER_PASS
	mult_pill.mouse_filter = Control.MOUSE_FILTER_PASS
	calc.tooltip_text = tr("Toca para ver o detalhe do ataque")
	calc.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed:
			_open_breakdown())

func _open_breakdown() -> void:
	if _animating or SceneRouter.has_overlay():
		return
	var c := battle.preview_attack()
	var title := tr("Ataque previsto: %s") % Cascade.fmt_int(c.net_total())
	if c.is_empty():
		if _last_cascade == null or _last_cascade.is_empty():
			return
		c = _last_cascade
		title = tr("Último ataque: %s") % Cascade.fmt_int(c.net_total())
	Sfx.select()
	CascadeBreakdown.open(c, title)

func _translated(names: Array[String]) -> Array[String]:
	var out: Array[String] = []
	for n in names:
		out.append(tr(n))
	return out

func _refresh_discard_button() -> void:
	discard_btn.text = tr("CANALIZAR (%d)") % battle.discards_left
	discard_btn.disabled = battle.discards_left <= 0 or battle.resolving or battle.finished
	if discard_btn.disabled and _discard_mode:
		discard_btn.button_pressed = false

# --- Handlers ---

func _on_mana_changed(available: int, total: int) -> void:
	_set_mana(available, total)
	_refresh_hand()

func _on_discards_changed(_left: int) -> void:
	_refresh_discard_button()

func _on_turn_started(t: int) -> void:
	turn_label.text = _turn_text()
	_refresh_pips()
	_refresh_info_row()
	end_turn_btn.disabled = false
	if t != _undo_turn:
		_undo_stack.clear()
		_undo_turn = t
	_refresh_discard_button()
	_refresh_all()
	if not battle.finished and not battle.puzzle:
		GameState.save_run(battle.to_dict(), "battle")   # gravação automática a cada turno
	if t > 1 and not _resumed:
		_show_banner(tr("TURNO %d") % t, 0.6, true)

func _on_enemy_hp(current: int, max_hp: int) -> void:
	enemy_hp_bar.max_value = max_hp
	enemy_hp_ghost.max_value = max_hp
	if _hp_tween != null and _hp_tween.is_valid():
		_hp_tween.kill()
	_hp_tween = create_tween().set_parallel(true)
	_hp_tween.tween_property(enemy_hp_ghost, "value", float(current), _d(0.45)).set_ease(Tween.EASE_OUT)
	_hp_tween.tween_property(enemy_hp_bar, "value", float(current if _animating else max(0, current - _last_preview_total)), _d(0.45)).set_ease(Tween.EASE_OUT)
	enemy_hp_label.text = "%s / %s" % [Cascade.fmt_int(current), Cascade.fmt_int(max_hp)]
	if GameState.puzzle_id == "training":
		enemy_hp_label.text = "∞"

func _on_spell_cast(_card: CardInstance) -> void:
	_refresh_spells()

func _on_creature_died(card: CardInstance) -> void:
	Sfx.hit()
	_log(tr("%s morreu.") % tr(card.data.name))
	if _board_views.has(card.uid) and is_instance_valid(_board_views[card.uid]):
		_animate_death(_board_views[card.uid])
	_refresh_board()
	_refresh_preview()
	_refresh_zone_buttons()

func _on_creature_blocked(card: CardInstance, amount: int) -> void:
	_log(tr("%s bloqueou %d de dano.") % [tr(card.data.name), amount])
	if _board_views.has(card.uid):
		var view: CardView = _board_views[card.uid]
		if is_instance_valid(view):
			view.refresh()
			_flash(view, Color(1.6, 1.6, 1.6))
			_bump(view, 0.9)

func _on_card_discarded(card: CardInstance) -> void:
	_log(tr("Canalizaste %s.") % tr(card.data.name))
	_refresh_zone_buttons()

func _on_card_grew(card: CardInstance, amount: int) -> void:
	var view: Control = _board_views.get(card.uid, _hand_views.get(card.uid))
	if view != null and is_instance_valid(view):
		if view is CardView:
			view.refresh()
		_pop(view, tr("Cresce +%d") % amount, COLOR_GROW)
	_refresh_preview()

func _on_hand_card_pressed(card: CardInstance) -> void:
	if battle.resolving or battle.finished:
		return
	if battle.pending_bottom > 0:
		if battle.bottom_card(card):
			Sfx.hit()
			if battle.pending_bottom > 0:
				_log(tr("Escolhe mais %d carta(s) para o fundo do grimório.") % battle.pending_bottom)
			else:
				_log(tr("Mão nova com %d cartas. Toca numa carta para a jogar.") % battle.deck.hand.size())
				GameState.save_run(battle.to_dict(), "battle")
			_refresh_all()
		return
	if _discard_mode:
		if battle.can_discard(card):
			if Settings.warn_rare and (card.data.rarity == "rare" or card.data.rarity == "mythic") and not battle.puzzle:
				var go_on := await _ask(tr("Canalizar uma rara?"), tr("%s é uma carta rara. Canalizá-la manda-a para o cemitério.") % card.data.display_name(), tr("CANALIZAR"))
				if go_on == "never":
					Settings.warn_rare = false
					Settings.save_settings()
				elif go_on != "yes":
					return
				if not battle.can_discard(card):
					return
			_push_undo()
			battle.discard(card)
			Sfx.hit()
			Settings.vibrate(20)
			discard_btn.button_pressed = false   # desliga o modo (toggled → _on_discard_toggled)
			_refresh_all()
		return
	var from_rect := Rect2()
	if _hand_views.has(card.uid) and is_instance_valid(_hand_views[card.uid]):
		from_rect = (_hand_views[card.uid] as Control).get_global_rect()
	if battle.can_play(card):
		var kick := false
		if battle.can_kick(card):
			var choice := await _ask_kicker(card)
			if choice == "":
				return
			kick = choice == "kick"
			if not battle.can_play(card):
				return
		_push_undo()
		battle.play(card, kick)
		Sfx.select()
		hand_box.clear_hover()
		_refresh_all()
		_animate_play(card, from_rect)

func _push_undo() -> void:
	_undo_stack.append(battle.snapshot())
	if _undo_stack.size() > 12:
		_undo_stack.pop_front()

func _on_undo() -> void:
	if _undo_stack.is_empty() or battle.resolving or battle.finished:
		return
	var snap: Dictionary = _undo_stack.pop_back()
	discard_btn.button_pressed = false
	_resumed = true   # sem banner "TURNO N"
	var ok := battle.restore_snapshot(snap)
	_resumed = false
	if ok:
		Sfx.hit()
		_log(tr("Jogada desfeita."))
	_refresh_all()

func _on_card_long_pressed(card: CardInstance) -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	CardZoom.show_card(card)

func _on_relic_pressed(id: String) -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	CardZoom.show_relic(id)

func _open_library() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	ZoneViewer.open(tr("GRIMÓRIO"), battle.deck.library, true)

func _open_graveyard() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	var pickable := battle.flashback_cards().filter(func(c): return battle.can_flashback(c))
	if pickable.is_empty() or battle.resolving or battle.finished:
		ZoneViewer.open(tr("CEMITÉRIO"), battle.deck.graveyard, false, Callable(), Callable(), tr("EXÍLIO"), battle.deck.exile)
		return
	ZoneViewer.open(tr("CEMITÉRIO — ↺ toca num feitiço para o recapitular"), battle.deck.graveyard, false,
		func(card: CardInstance):
			if battle.can_flashback(card):
				_push_undo()
				battle.play_flashback(card)
				Sfx.boom()
				_refresh_all(),
		func(card: CardInstance): return battle.can_flashback(card),
		tr("EXÍLIO"), battle.deck.exile)

# --- Mulligan ---

func _on_mulligan() -> void:
	if not battle.can_mulligan() or SceneRouter.has_overlay():
		return
	Sfx.hit()
	Settings.vibrate(20)
	battle.mulligan()

func _on_mulligan_taken(count: int) -> void:
	_log(tr("Mão nova. Escolhe %d carta(s) para o fundo do grimório.") % count)
	_refresh_all()

# --- Dupla face, selos, recapitular, exílio ---

func _on_card_transformed(card: CardInstance) -> void:
	Sfx.boom()
	Settings.vibrate(40)
	_log(tr("%s virou!") % tr(card.data.name))
	var view: Control = _board_views.get(card.uid, _hand_views.get(card.uid))
	if _alive(view) and Settings.anim_scale() > 0.0:
		view.pivot_offset = view.size / 2.0
		_kill_tween(view, "flip_tw")
		var tw := create_tween()
		tw.tween_property(view, "scale:x", 0.0, _d(0.14)).set_ease(Tween.EASE_IN)
		tw.tween_callback(func():
			if _alive(view) and view is CardView:
				(view as CardView).refresh())
		tw.tween_property(view, "scale:x", 1.0, _d(0.16)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
		view.set_meta("flip_tw", tw)
		_pop(view, "⇄ " + tr("Transformação!"), COLOR_FORMATION)
	else:
		_refresh_all()
	_refresh_preview()

func _on_card_flashback(card: CardInstance) -> void:
	_log(tr("Recapitulaste %s — vai para o exílio.") % tr(card.data.name))

func _on_seal_triggered(card: CardInstance, seal: String) -> void:
	var view: Control = _board_views.get(card.uid, _hand_views.get(card.uid))
	var text := ""
	match seal:
		"tithe":
			text = tr("+3 ouro")
		"vitality":
			text = tr("+15 Poder")
		"phyrexian":
			text = tr("−10 Poder")
		"wisdom":
			text = tr("Formação +1")
	if text != "":
		_pop(view if _alive(view) else formation_label, "◉ " + text, COLOR_SEAL)

func _on_formation_leveled(id: String, level: int) -> void:
	_log(tr("%s sobe para o nível %d.") % [tr(String(CardDB.get_formation(id).get("name", id))), level])

func _on_card_exiled_run(card: CardInstance) -> void:
	_log(tr("%s foi exilada da run.") % tr(card.data.name))
	if _board_views.has(card.uid) and is_instance_valid(_board_views[card.uid]):
		_animate_death(_board_views[card.uid])
	_refresh_all()

func _on_boss_ascended(text: String) -> void:
	Sfx.hit()
	Settings.vibrate(80)
	_shake(12.0)
	# Vem logo a seguir ao despertar: o banner junta as duas coisas.
	_show_banner((tr("O BOSS DESPERTA") + "\n" if battle.phase2 else "") + tr("ASCENSÃO MÍTICA"), 1.3)
	_log(tr(text) if text != "" else tr("O boss ativa a 2.ª regra!"))
	_refresh_enemy_header()
	_refresh_discard_button()

## O boss passou abaixo de metade da vida: desperta (+ataque) e diz uma fala.
func _on_boss_phase2(line: String) -> void:
	Sfx.boom()
	Settings.vibrate(80)
	_shake(14.0)
	_show_banner(tr("O BOSS DESPERTA") + "\n" + tr("+%d de ataque") % BattleManager.PHASE2_ATTACK, 1.1)
	_log(tr("%s despertou: +%d de ataque.") % [tr(battle.enemy.name), BattleManager.PHASE2_ATTACK])
	_flash(enemy_panel, Color(2.0, 0.6, 0.5))
	_refresh_enemy_header()
	_refresh_preview()
	_say(line, 3.0)

## Coração de Vidro: um golpe mortal deixou-te com 1 de vida.
func _on_death_saved() -> void:
	Sfx.boom()
	Settings.vibrate(120)
	_show_banner(tr("CORAÇÃO DE VIDRO"), 1.2)
	_log(tr("O Coração de Vidro estilhaçou-se: ficas com 1 de vida."))
	_flash(player_label, Color(1.6, 1.8, 2.4))

func _on_contract_resolved(success: bool, text: String) -> void:
	if text != "":
		SceneRouter.toast(("✓ " if success else "✗ ") + text, 2.6)

## Devorador de Horizontes: a criatura mais à direita sai para o exílio.
func _on_creature_exiled(card: CardInstance) -> void:
	Sfx.hit()
	_log(tr("%s devorou %s.") % [tr(battle.enemy.name), tr(card.data.name)])
	if _board_views.has(card.uid) and is_instance_valid(_board_views[card.uid]):
		_animate_death(_board_views[card.uid])
	_refresh_board()
	_refresh_preview()
	_refresh_zone_buttons()

## Chuva de Meteoros: dano à criatura da 3.ª posição no fim do turno.
func _on_climate_hit(card: CardInstance, amount: int) -> void:
	_log(tr("%s: %s sofre %d de dano.") % [tr(battle.climate_name()), tr(card.data.name), amount])
	var view: Control = _board_views.get(card.uid)
	if _alive(view):
		if view is CardView:
			(view as CardView).refresh()
		_flash(view, Color(2.0, 0.9, 0.6))
		_pop(view, "−%d" % amount, Color(1.0, 0.45, 0.25))

# --- Falas do boss ---

func _boss_line(key: String) -> String:
	if not bool(battle.enemy.get("boss", false)) and String(battle.enemy.get("variant", "")) != "nemesis":
		return ""
	return String((battle.enemy.get("lines", {}) as Dictionary).get(key, ""))

func _say_after(text: String, delay: float, seconds: float = 3.0) -> void:
	if text == "":
		return
	if delay > 0.0:
		await get_tree().create_timer(delay).timeout
	if is_inside_tree() and not battle.finished:
		_say(text, seconds)

## Balão de fala ao lado do painel do inimigo (some sozinho e não bloqueia toques).
func _say(text: String, seconds: float = 3.0) -> void:
	if text == "" or not is_inside_tree():
		return
	if _bubble_tw != null and _bubble_tw.is_valid():
		_bubble_tw.kill()
	if _alive(_bubble):
		_bubble.queue_free()
	var b := PanelContainer.new()
	b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_theme_stylebox_override("panel", UiKit.flat(Color(0.97, 0.94, 0.88), 14, Color(0.25, 0.15, 0.3), 3, 12))
	var l := UiKit.label("«" + tr(text) + "»", 18, Color(0.14, 0.08, 0.16), true)
	l.custom_minimum_size.x = 300
	b.add_child(l)
	add_child(b)
	_bubble = b
	b.modulate.a = 0.0
	await get_tree().process_frame
	if not _alive(b):
		return
	b.reset_size()
	var er := enemy_panel.get_global_rect()
	var right_side := not Settings.left_handed
	var x := er.end.x + 16.0 if right_side else er.position.x - b.size.x - 16.0
	b.global_position = Vector2(x, er.position.y + 8.0)
	# Bico a apontar para o inimigo.
	var tail := Polygon2D.new()
	tail.color = Color(0.97, 0.94, 0.88)
	if right_side:
		tail.polygon = PackedVector2Array([Vector2(2, 16), Vector2(-16, 26), Vector2(2, 36)])
	else:
		tail.polygon = PackedVector2Array([Vector2(b.size.x - 2, 16), Vector2(b.size.x + 16, 26), Vector2(b.size.x - 2, 36)])
	b.add_child(tail)
	b.pivot_offset = Vector2(0.0 if right_side else b.size.x, 26.0)
	b.scale = Vector2(0.7, 0.7)
	_bubble_tw = create_tween()
	_bubble_tw.set_parallel(true)
	_bubble_tw.tween_property(b, "modulate:a", 1.0, 0.15)
	_bubble_tw.tween_property(b, "scale", Vector2.ONE, 0.22).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	_bubble_tw.chain().tween_interval(seconds)
	_bubble_tw.chain().tween_property(b, "modulate:a", 0.0, 0.3)
	_bubble_tw.chain().tween_callback(b.queue_free)
	Sfx.blip(3)

# --- Linha de informação: clima, contrato e planeswalker ---

## Por cima do cálculo: chip do Clima Planar, chip do contrato ativo e o painel do planeswalker.
func _build_info_row() -> void:
	for c in pw_row.get_children():
		pw_row.remove_child(c)
		c.queue_free()
	_pw_buttons.clear()
	_pw_panel = null
	_pw_loyalty = null
	_pw_name = null
	_climate_chip = null
	_climate_label = null
	_contract_chip = null
	var any := false
	if battle.climate != "":
		var cdef := CardDB.get_climate(battle.climate)
		_climate_chip = UiKit.info_chip("climate", tr(String(cdef.get("name", ""))), COLOR_CLIMATE, func():
			CardZoom.show_climate(battle.climate, _climate_suffix()))
		_climate_label = _climate_chip.get_meta("label")
		pw_row.add_child(_climate_chip)
		any = true
	if not GameState.contract.is_empty() and not battle.puzzle:
		var con: Dictionary = GameState.contract
		_contract_chip = UiKit.info_chip("contract", tr(String(con.get("name", ""))), UiKit.GOLD, func():
			CardZoom.show_contract(con))
		pw_row.add_child(_contract_chip)
		any = true
	var def := GameState.planeswalker_def()
	if not def.is_empty():
		_build_planeswalker(def, any)
		any = true
	pw_row.visible = any
	_refresh_info_row()

## Lua de Sangue: "· Dia" / "· Noite" conforme o turno.
func _climate_suffix() -> String:
	if battle.climate == "blood_moon":
		return "  ·  " + (tr("Noite") if battle.is_night() else tr("Dia"))
	return ""

func _refresh_info_row() -> void:
	if _climate_label != null and is_instance_valid(_climate_label):
		_climate_label.text = tr(battle.climate_name()) + _climate_suffix()
	_refresh_planeswalker()

func _build_planeswalker(def: Dictionary, compact: bool) -> void:
	var color: Color = CardView.COLORS.get(String(def.get("color", "colorless")), UiKit.GOLD)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.12, 0.1, 0.18), 10, color, 2, 6))
	pw_row.add_child(panel)
	_pw_panel = panel
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	panel.add_child(row)
	var info := VBoxContainer.new()
	info.add_theme_constant_override("separation", 0)
	info.custom_minimum_size.x = 180 if compact else 230
	row.add_child(info)
	_pw_name = UiKit.label("✦ " + tr(String(def.get("name", ""))), 15, color)
	_pw_name.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	info.add_child(_pw_name)
	_pw_loyalty = UiKit.label("", 14, UiKit.TEXT_DIM)
	_pw_loyalty.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	info.add_child(_pw_loyalty)
	var zoom := Button.new()
	zoom.text = "?"
	zoom.custom_minimum_size = Vector2(34, 34)
	zoom.add_theme_font_size_override("font_size", 16)
	zoom.pressed.connect(func():
		if not SceneRouter.has_overlay():
			Sfx.select()
			CardZoom.show_planeswalker(String(def.get("id", ""))))
	row.add_child(zoom)
	var skills: Array = def.get("skills", [])
	for i in skills.size():
		var cost := int(skills[i].get("cost", 0))
		var b := UiKit.button(("+%d" if cost > 0 else "%d") % cost, 36, 16, color.darkened(0.35), color)
		b.custom_minimum_size.x = 62
		b.pressed.connect(_on_pw_skill.bind(i))
		b.tooltip_text = tr(String(skills[i].get("text", "")))
		row.add_child(b)
		_pw_buttons.append(b)

func _refresh_planeswalker() -> void:
	var def := GameState.planeswalker_def()
	var has_panel := _pw_panel != null and is_instance_valid(_pw_panel)
	if def.is_empty():
		if has_panel:
			_build_info_row()
		return
	if not has_panel or _pw_buttons.size() != (def.get("skills", []) as Array).size():
		_build_info_row()
		return
	var max_l := int(def.get("max_loyalty", 6))
	var l := GameState.planeswalker_loyalty()
	var pips := ""
	for i in max_l:
		pips += "●" if i < l else "○"
	_pw_loyalty.text = tr("Lealdade %d/%d") % [l, max_l] + "  " + pips + ("  ·  " + tr("usado") if battle.pw_used_this_turn else "")
	for i in _pw_buttons.size():
		_pw_buttons[i].disabled = not battle.can_use_planeswalker(i)

func _on_pw_skill(i: int) -> void:
	if not battle.can_use_planeswalker(i) or SceneRouter.has_overlay():
		return
	var skill: Dictionary = battle.planeswalker_skills()[i]
	_push_undo()
	if battle.use_planeswalker(i):
		Sfx.boom()
		Settings.vibrate(30)
		_log("✦ " + tr(String(skill.get("text", ""))))
		_pop(_pw_panel if _alive(_pw_panel) else pw_row, "✦ " + tr(String(GameState.planeswalker_def().get("name", ""))), COLOR_FORMATION)
		_refresh_all()

func _on_discard_toggled(on: bool) -> void:
	_discard_mode = on and battle.discards_left > 0
	if on and battle.discards_left <= 0:
		discard_btn.button_pressed = false
	for view in _hand_views.values():
		if is_instance_valid(view):
			view.modulate = DISCARD_TINT if _discard_mode else Color.WHITE
			view.playable = battle.can_play(view.card) or view.card.data.is_land() or _discard_mode
	if _discard_mode:
		_log(tr("Toca na carta a canalizar."))
		Sfx.select()

func _on_end_turn() -> void:
	if battle.resolving or battle.finished or _alive(_modal):
		return
	if Settings.warn_mana and not battle.puzzle and battle.mana_available > 0:
		var best := 0
		for c in battle.deck.hand:
			if battle.can_play(c) and not c.data.is_land():
				best = maxi(best, battle.preview_play(c))
		if best > 0:
			var ans := await _ask(tr("Atacar sem gastar a mana?"), tr("Ainda tens %d de mana e cartas que aumentam o ataque (até +%s).") % [battle.mana_available, Cascade.fmt_int(best)], tr("ATACAR"))
			if ans == "never":
				Settings.warn_mana = false
				Settings.save_settings()
			elif ans != "yes":
				return
			if battle.resolving or battle.finished:
				return
	_bump(end_turn_btn, 0.92)
	end_turn_btn.disabled = true
	discard_btn.button_pressed = false
	discard_btn.disabled = true
	battle.end_turn()

func _on_enemy_ability(enemy_name_str: String, action: String) -> void:
	_log("%s %s!" % [tr(enemy_name_str), tr(ABILITY_LOG.get(action, action))])
	_flash(enemy_panel, Color(1.3, 1.1, 1.5))
	_refresh_all()

func _on_damage_dealt(target: String, amount: int) -> void:
	if target == "enemy":
		_log(tr("Causaste %s de dano.") % Cascade.fmt_int(amount))
		_animate_enemy_hit(amount)
		if _portrait != null:
			_portrait.hit()
		# Peso do golpe: congela um instante e abana em proporção à vida máxima do inimigo.
		var pct := minf(1.0, float(amount) / maxf(1.0, float(battle.enemy.get("max_hp", 1))))
		if pct >= 0.2:
			SceneRouter.hit_stop(0.05 + 0.1 * pct)
		_shake(4.0 + 16.0 * pct)
		if not _hit_line_said and pct >= 0.25 and int(battle.enemy.hp) > 0:
			var will_awaken := not battle.phase2 and int(battle.enemy.hp) * 2 <= int(battle.enemy.max_hp)
			var line := _boss_line("hit")
			if line != "" and not will_awaken:
				_hit_line_said = true
				_say(line, 2.4)
	else:
		Sfx.hit()
		Settings.vibrate(60)
		_animate_enemy_strike()
		_shake(8.0)
		_flash(player_label, Color(2.0, 0.6, 0.6))
		_log(tr("Levaste %d de dano.") % amount)

func _on_battle_ended(victory: bool) -> void:
	pause_btn.disabled = true
	if GameState.puzzle_id == "training":
		_training_result()
		return
	if battle.puzzle:
		if victory:
			Stats.on_puzzle_solved(GameState.puzzle_id)
			_show_banner(tr("RESOLVIDO!"), 1.2)
			Sfx.boom()
		else:
			_show_banner(tr("NÃO CHEGOU") + "\n" + tr("Tenta outra vez."), 1.2)
		await get_tree().create_timer(_d(1.1)).timeout
		GameState.puzzle_id = ""
		SceneRouter.go("puzzles")
		return
	if victory:
		var last_words := _boss_line("defeat")
		var extra := 0.0
		if last_words != "":
			_say(last_words, 2.0)
			extra = _d(1.3)
		if String(battle.enemy.get("variant", "")) == "nemesis" and GameState.last_reward_text != "":
			SceneRouter.toast("☠ " + tr("Némesis vencida: %s") % GameState.last_reward_text, 2.8)
		if String(battle.enemy.get("variant", "")) == "elite":
			if battle.elite_relic != "":
				SceneRouter.toast("★ " + tr("Elite vencida: recebes %s.") % tr(String(CardDB.relics.get(battle.elite_relic, {}).get("name", ""))), 2.6)
			else:
				SceneRouter.toast(tr("Elite vencida: +%d ouro (não tinhas lugar para outra relíquia).") % 10, 2.6)
		if GameState.ante >= GameState.max_ante and not GameState.endless:
			GameState.last_victory = true
			EventBus.run_ended.emit(true)
			_show_banner(tr("VITÓRIA"), 1.0)
			await get_tree().create_timer(_d(0.9) + extra).timeout
			SceneRouter.go("run_over")
		else:
			_show_banner(tr("ANTE %d VENCIDO") % GameState.ante, 1.0)
			Sfx.boom()
			await get_tree().create_timer(_d(0.9) + extra).timeout
			GameState.map_phase = "stop"
			# Boss que não acaba a run: Baú de Espólio (1 de 3 relíquias de boss) antes da paragem.
			if bool(battle.enemy.get("boss", false)) and not GameState.prepare_loot().is_empty():
				GameState.save_run({}, "loot")
				SceneRouter.go("loot")
			else:
				GameState.save_run({}, "map")
				SceneRouter.go("map")
	else:
		GameState.last_victory = false
		EventBus.run_ended.emit(false)
		_show_banner(tr("DERROTA"), 1.0)
		await get_tree().create_timer(_d(1.0)).timeout
		SceneRouter.go("run_over")

# --- Arrastar para reordenar (tabuleiro e relíquias) ---

func _on_board_drag_started(card: CardInstance, pos: Vector2) -> void:
	if battle.resolving or battle.finished or _drag_ghost != null:
		return
	var view: Control = _board_views.get(card.uid)
	if not _alive(view):
		return
	_drag_view = view
	view.modulate.a = 0.35
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = view.size
	ghost.pivot_offset = ghost.size / 2.0
	ghost.scale = Vector2(1.06, 1.06)
	ghost.rotation = 0.04
	ghost.global_position = pos - ghost.size / 2.0
	_drag_ghost = ghost
	_drag_last_x = pos.x
	# Sombra por baixo da carta levantada (fica a 12 px, como se a carta estivesse no ar).
	_drag_shadow = Panel.new()
	_drag_shadow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := StyleBoxFlat.new()
	sh.bg_color = Color(0, 0, 0, 0.35)
	sh.set_corner_radius_all(14)
	sh.shadow_color = Color(0, 0, 0, 0.45)
	sh.shadow_size = 14
	_drag_shadow.add_theme_stylebox_override("panel", sh)
	_drag_shadow.size = view.size
	add_child(_drag_shadow)
	move_child(_drag_shadow, ghost.get_index())
	_drag_shadow.global_position = ghost.global_position + Vector2(10, 14)
	Settings.vibrate(15)

func _on_board_drag_moved(card: CardInstance, pos: Vector2) -> void:
	if _drag_ghost == null:
		return
	_drag_ghost.global_position = pos - _drag_ghost.size / 2.0
	_tilt_ghost(pos)
	var index := _index_for_x(board_box, pos.x, _drag_view)
	var current := battle.board.find(card)
	if index != current and index >= 0:
		battle.move_creature(card, index)
		board_box.move_child(_drag_view, index)
		_refresh_preview()

func _on_board_drag_ended(_card: CardInstance, _pos: Vector2) -> void:
	if _drag_ghost != null:
		_drag_ghost.queue_free()
		_drag_ghost = null
	if _alive(_drag_shadow):
		_drag_shadow.queue_free()
	_drag_shadow = null
	if _alive(_drag_view):
		_drag_view.modulate.a = 1.0
		_bump(_drag_view, 1.08)
	_drag_view = null
	Sfx.select()
	_refresh_preview()

func _on_relic_drag_started(id: String, pos: Vector2) -> void:
	if battle.resolving or battle.finished or _drag_ghost != null:
		return
	var view: Control = _relic_views.get(id)
	if not _alive(view):
		return
	_drag_view = view
	view.modulate.a = 0.35
	var ghost: RelicView = RELIC_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(id)
	ghost.set_width(view.size.x)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = view.size
	ghost.global_position = pos - ghost.size / 2.0
	_drag_ghost = ghost

func _on_relic_drag_moved(id: String, pos: Vector2) -> void:
	if _drag_ghost == null:
		return
	_drag_ghost.global_position = pos - _drag_ghost.size / 2.0
	var index := mini(_index_for_x(relics_bar, pos.x, _drag_view), GameState.relic_ids.size() - 1)
	var current := GameState.relic_ids.find(id)
	if index != current and index >= 0:
		GameState.relic_ids.erase(id)
		GameState.relic_ids.insert(clampi(index, 0, GameState.relic_ids.size()), id)
		relics_bar.move_child(_drag_view, index)
		_refresh_preview()

func _on_relic_drag_ended(_id: String, _pos: Vector2) -> void:
	_on_board_drag_ended(null, Vector2.ZERO)
	GameState.save_run(battle.to_dict(), "battle")

## Posição (índice) em que um item arrastado deve ficar numa fila horizontal, pela coordenada x.
func _index_for_x(box: Control, x: float, dragged: Control) -> int:
	var live := box.get_children().filter(func(c): return not c.is_queued_for_deletion())
	var index := 0
	for c in live:
		if c == dragged:
			continue
		var center: float = c.global_position.x + c.size.x / 2.0
		if x > center:
			index += 1
	return index

# --- Pausa ---

func _open_pause() -> void:
	if battle.finished or SceneRouter.has_overlay() or (_pause_menu != null and is_instance_valid(_pause_menu)):
		return
	Sfx.select()
	_pause_menu = PauseMenu.open(_pause_info())
	_pause_menu.abandoned.connect(_on_abandon)

func _pause_info() -> String:
	if GameState.puzzle_id == "training":
		return tr("Treino")
	if battle.puzzle:
		return tr("Quebra-cabeças") + "  ·  " + tr(String(CardDB.get_puzzle(GameState.puzzle_id).get("name", "")))
	var info := "%s  ·  %s  ·  %s  ·  %s" % [
		tr(GameState.deck_def.get("name", "")),
		_turn_text().replace("\n", "  ·  "),
		tr("Selo %d") % GameState.stake if GameState.stake > 1 else tr("Selo 1"),
		tr("Seed %d") % GameState.seed_value,
	]
	if battle.climate != "":
		info += "  ·  " + tr(battle.climate_name())
	return info

func _on_abandon() -> void:
	if GameState.puzzle_id == "training":
		GameState.puzzle_id = ""
		SceneRouter.go("training")
		return
	if battle.puzzle:
		GameState.puzzle_id = ""
		SceneRouter.go("puzzles")
		return
	GameState.abandon_run()
	SceneRouter.go("main")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		if _alive(_modal):
			_close_modal("")
			return
		_open_pause()
	elif what == NOTIFICATION_EXIT_TREE:
		Settings.set_battle_screen_on(false)

# --- Cascata ---

func _on_cascade_started(cascade: Cascade) -> void:
	_animating = true
	_last_cascade = cascade
	end_turn_btn.disabled = true
	undo_btn.disabled = true
	enemy_hp_bar.value = enemy_hp_ghost.value   # durante a cascata a barra mostra a vida real
	for v in _hand_views.values():
		if _alive(v):
			v.delta = 0
	formation_label.text = tr("Ataque")
	power_label.text = "0"
	mult_label.text = "1"
	total_label.text = ""
	var shown_formations: Array[String] = []
	var i := 0
	var speed := Settings.anim_scale()
	for s in cascade.steps:
		var target := _view_for_step(s)
		var color := _color_for_step(s)
		if s.source_kind == "formation" and not s.retrigger:
			shown_formations.append(tr(s.source_name) + ((" (%s %d)" % [tr("nv"), s.level]) if s.level > 0 else ""))
			formation_label.text = " · ".join(PackedStringArray(shown_formations))
		if s.source_kind == "creature" and s.action == "power_add" and s.tag != "minion":
			_lunge(target)
		var prefix := "↻ " if s.retrigger else ""
		if s.tag == "seal":
			prefix = "◉ "
		elif s.tag == "minion":
			prefix = "◈ "
		elif s.source_kind == "planeswalker":
			prefix = "✦ "
		elif s.source_kind == "chain":
			prefix = "⚭ "
		_pop(target, prefix + s.label, color)
		if s.source_card != null and s.tag != "minion" and _alive(target):
			ColorBurst.spawn(self, target.global_position + target.size / 2.0, s.source_card.data.primary_color())
		power_label.text = Cascade.fmt_int(s.power_after)
		mult_label.text = Cascade.fmt_mult(s.mult_after)
		_fire_target = _fire_for(s.power_after * s.mult_after)
		_bump(power_pill if s.action == "power_add" else mult_pill)
		Sfx.blip(i)
		if speed > 0.0:
			await get_tree().create_timer(maxf(0.09, 0.28 - i * 0.012) * speed).timeout
		elif i % 4 == 3:
			await get_tree().process_frame
		i += 1
	# Escudo do inimigo: trava os primeiros X do ataque.
	if cascade.shield > 0 and cascade.total() > 0:
		_pop(enemy_panel, "◈ " + tr("Escudo −%s") % Cascade.fmt_int(mini(cascade.shield, cascade.total())), Color(0.6, 0.8, 1.0))
	# O total conta a subir (cada vez mais depressa) e treme mais quanto mais perto do fim.
	var total := cascade.net_total()
	if speed > 0.0 and total > 0:
		var ticks := 14
		total_label.pivot_offset = total_label.size / 2.0
		for k in range(1, ticks + 1):
			var t := float(k) / ticks
			_set_total(Cascade.fmt_int(int(round(total * t * t))))
			total_label.rotation = randf_range(-1.0, 1.0) * 0.07 * t
			total_label.scale = Vector2.ONE * (1.0 + 0.3 * t)
			Sfx.blip(mini(30, i + k))
			await get_tree().create_timer(0.032 * speed).timeout
		total_label.rotation = 0.0
		total_label.scale = Vector2.ONE
	_set_total(Cascade.fmt_int(total))
	_bump(total_label, 1.5)
	_particles.global_position = total_label.global_position + total_label.size / 2.0
	_particles.restart()
	Sfx.boom()
	Settings.vibrate(50)
	_fire_target = _fire_for(cascade.net_total())
	_shake(6.0 + 10.0 * _fire_target)
	await get_tree().create_timer(_d(0.5)).timeout
	_animating = false
	EventBus.cascade_finished.emit()

func _view_for_step(s: Cascade.Step) -> Control:
	match s.source_kind:
		"creature":
			if s.source_card != null and _board_views.has(s.source_card.uid):
				return _board_views[s.source_card.uid]
		"spell":
			if s.source_card != null and _spell_chips.has(s.source_card.uid):
				return _spell_chips[s.source_card.uid]
		"hand":
			if s.source_card != null and _hand_views.has(s.source_card.uid):
				return _hand_views[s.source_card.uid]
		"relic":
			if _relic_views.has(s.source_id):
				return _relic_views[s.source_id]
		"planeswalker":
			return _pw_panel if _alive(_pw_panel) else pw_row
		"climate":
			if s.source_card != null and _board_views.has(s.source_card.uid):
				return _board_views[s.source_card.uid]
			if _alive(_climate_chip):
				return _climate_chip
		"enchantment":
			if s.source_card != null and _ench_chips.has(s.source_card.uid) and _alive(_ench_chips[s.source_card.uid]):
				return _ench_chips[s.source_card.uid]
		"chain":
			if _alive(_chain_meter):
				return _chain_meter
		"rule":
			if s.source_card != null and _board_views.has(s.source_card.uid):
				return _board_views[s.source_card.uid]
	return formation_label

func _color_for_step(s: Cascade.Step) -> Color:
	if s.grow > 0:
		return COLOR_GROW
	if s.tag == "seal":
		return COLOR_SEAL
	if s.source_kind == "climate" and s.action != "gold":
		return COLOR_CLIMATE
	if s.source_kind == "relic" and GameState.boss_relics.has(s.source_id):
		return COLOR_BOSS_RELIC
	if s.source_kind == "formation" or s.source_kind == "planeswalker":
		return COLOR_FORMATION
	if s.source_kind == "tribe":
		return COLOR_TRIBE
	if s.source_kind == "chain":
		return COLOR_CHAIN
	if s.source_kind == "enchantment":
		return COLOR_ENCHANT
	if s.source_kind == "seal_set":
		return COLOR_SEAL
	match s.action:
		"power_add":
			return COLOR_POWER
		"mult_mul":
			return COLOR_MULT_X
		"gold":
			return COLOR_GOLD
	return COLOR_MULT

# --- Animações ---

func _alive(view) -> bool:
	return view != null and is_instance_valid(view) and not view.is_queued_for_deletion()

## Mata o tween guardado em meta (se existir) para nunca haver dois a disputar a mesma propriedade.
func _kill_tween(view: Object, key: String) -> void:
	if view.has_meta(key):
		var old = view.get_meta(key)
		if old is Tween and (old as Tween).is_valid():
			(old as Tween).kill()

## Pop da vista + etiqueta a flutuar por cima dela.
func _pop(view: Control, text: String, color: Color) -> void:
	if not _alive(view):
		return
	_bump(view, 1.22)
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", 26)
	label.add_theme_color_override("font_color", Color.WHITE)
	label.add_theme_color_override("font_outline_color", color.darkened(0.35))
	label.add_theme_constant_override("outline_size", 8)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(label)
	label.reset_size()
	var start := view.global_position + Vector2(view.size.x * 0.5 - label.size.x * 0.5, -label.size.y * 0.6)
	label.global_position = start
	var tw := create_tween().set_parallel(true)
	tw.tween_property(label, "global_position:y", start.y - 46.0, _d(0.6)).set_ease(Tween.EASE_OUT)
	tw.tween_property(label, "modulate:a", 0.0, _d(0.6)).set_delay(_d(0.25))
	tw.chain().tween_callback(label.queue_free)

## Escala rápida e volta a 1. Mata o bump anterior da mesma vista para nunca ficar a meio.
func _bump(view: Control, amount: float = 1.18) -> void:
	if not _alive(view):
		return
	view.pivot_offset = view.size / 2.0
	_kill_tween(view, "bump_tw")
	view.scale = Vector2.ONE
	var tw := create_tween()
	tw.tween_property(view, "scale", Vector2.ONE * amount, _d(0.07))
	tw.tween_property(view, "scale", Vector2.ONE, _d(0.13)).set_ease(Tween.EASE_OUT)
	view.set_meta("bump_tw", tw)

## Investida: a criatura inclina-se e salta para a frente (rotação + escala, não mexe no layout).
func _lunge(view: Control) -> void:
	if not _alive(view):
		return
	view.pivot_offset = view.size / 2.0
	_kill_tween(view, "lunge_tw")
	view.rotation = 0.0
	var tw := create_tween()
	tw.tween_property(view, "rotation", -0.16, _d(0.06))
	tw.tween_property(view, "rotation", 0.0, _d(0.16)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	view.set_meta("lunge_tw", tw)

func _flash(view: Control, color: Color) -> void:
	if not _alive(view) or Settings.reduce_motion:
		return
	_kill_tween(view, "flash_tw")
	var base := Color.WHITE
	if view in _hand_views.values() and _discard_mode:
		base = DISCARD_TINT
	view.modulate = color
	var tw := create_tween()
	tw.tween_property(view, "modulate", base, _d(0.35))
	view.set_meta("flash_tw", tw)

func _shake(strength: float) -> void:
	if not Settings.motion_ok():
		return
	var tw := create_tween()
	for i in 5:
		var off := Vector2(randf_range(-strength, strength), randf_range(-strength, strength)) * (1.0 - i / 5.0)
		tw.tween_property(layout, "position", _layout_base + off, 0.03)
	tw.tween_property(layout, "position", _layout_base, 0.04)

## Carta nova na mão: entra de baixo, a crescer.
func _animate_draw(view: CardView, delay: float) -> void:
	var target_alpha := view.modulate.a
	view.modulate.a = 0.0
	view.scale = Vector2(0.7, 0.7)
	await get_tree().process_frame
	if not _alive(view):
		return
	view.pivot_offset = view.size / 2.0
	var tw := create_tween().set_parallel(true)
	tw.tween_property(view, "modulate:a", target_alpha, _d(0.18)).set_delay(_d(delay))
	tw.tween_property(view, "scale", Vector2.ONE, _d(0.22)).set_delay(_d(delay)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)

## Carta jogada: um "fantasma" voa da posição na mão até ao sítio novo (tabuleiro, feitiços ou mana).
func _animate_play(card: CardInstance, from_rect: Rect2) -> void:
	if from_rect.size == Vector2.ZERO or Settings.anim_scale() <= 0.0:
		return
	await get_tree().process_frame   # deixa o layout colocar a vista nova
	var target: Control = null
	if card.data.is_creature():
		target = _board_views.get(card.uid)
	elif card.data.is_spell():
		target = _spell_chips.get(card.uid)
	elif card.data.is_enchantment():
		target = _ench_chips.get(card.uid)
	else:
		target = mana_label
	if not _alive(target):
		return
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = from_rect.size
	ghost.global_position = from_rect.position
	ghost.pivot_offset = ghost.size / 2.0
	var real_target := target
	if card.data.is_creature():
		real_target.modulate.a = 0.0
	var dest := target.global_position + (target.size - ghost.size) / 2.0
	var end_scale := Vector2.ONE if card.data.is_creature() else Vector2(0.35, 0.35)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(ghost, "global_position", dest, _d(0.24)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
	tw.tween_property(ghost, "scale", end_scale, _d(0.24)).set_ease(Tween.EASE_IN)
	tw.tween_property(ghost, "rotation", 0.08, _d(0.12))
	await tw.finished
	if _alive(real_target):
		real_target.modulate.a = 1.0
		_bump(real_target, 1.12)
		if not card.data.is_creature():
			_flash(real_target, Color(1.8, 1.8, 1.8))
	if _alive(ghost):
		ghost.queue_free()
	Sfx.blip(0)

## Criatura morre: uma cópia cai e desvanece.
func _animate_death(view: Control) -> void:
	if not _alive(view) or Settings.anim_scale() <= 0.0:
		return
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup((view as CardView).card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = view.size
	ghost.global_position = view.global_position
	ghost.pivot_offset = ghost.size / 2.0
	ghost.modulate = Color(1.0, 0.5, 0.5)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(ghost, "global_position:y", ghost.global_position.y + 60.0, _d(0.4)).set_ease(Tween.EASE_IN)
	tw.tween_property(ghost, "rotation", 0.5, _d(0.4))
	tw.tween_property(ghost, "modulate:a", 0.0, _d(0.4))
	tw.chain().tween_callback(ghost.queue_free)

## O inimigo encaixa o golpe: flash vermelho, abanão e o número de dano a voar do total até ele.
func _animate_enemy_hit(amount: int) -> void:
	_flash(enemy_panel, Color(2.0, 0.7, 0.7))
	_bump(enemy_panel, 0.94)
	var label := Label.new()
	label.text = "-" + Cascade.fmt_int(amount)
	label.add_theme_font_size_override("font_size", 44)
	label.add_theme_color_override("font_color", Color(1, 0.92, 0.6))
	label.add_theme_color_override("font_outline_color", Color(0.4, 0.1, 0.1))
	label.add_theme_constant_override("outline_size", 10)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(label)
	label.reset_size()
	label.global_position = total_label.global_position
	var dest := enemy_panel.global_position + Vector2(enemy_panel.size.x * 0.5 - label.size.x * 0.5, 40.0)
	var tw := create_tween()
	tw.tween_property(label, "global_position", dest, _d(0.35)).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
	tw.tween_callback(func(): _flash(enemy_hp_bar, Color(2.5, 1.5, 1.5)))
	tw.tween_property(label, "modulate:a", 0.0, _d(0.4))
	tw.tween_callback(label.queue_free)

## O inimigo contra-ataca: salta para a direita (rotação) e o ecrã abana.
func _animate_enemy_strike() -> void:
	if not _alive(enemy_panel):
		return
	enemy_panel.pivot_offset = enemy_panel.size / 2.0
	var tw := create_tween()
	tw.tween_property(enemy_panel, "rotation", 0.06, _d(0.07))
	tw.tween_property(enemy_panel, "rotation", 0.0, _d(0.2)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	_flash(enemy_panel, Color(1.4, 1.4, 1.4))

## Banner central (ANTE N / TURNO N / VITÓRIA).
## minor = true (o "TURNO N"): não tapa um banner importante que ainda esteja no ecrã
## (despertar do boss, Coração de Vidro…).
func _show_banner(text: String, hold: float = 1.1, minor: bool = false) -> void:
	var now := Time.get_ticks_msec()
	if minor and now < _banner_lock_until:
		return
	if not minor:
		_banner_lock_until = now + int((_d(hold) + _d(0.5)) * 1000.0)
	if _banner_tw != null and _banner_tw.is_valid():
		_banner_tw.kill()
	banner.text = text
	banner.visible = true
	banner.pivot_offset = banner.size / 2.0
	banner.scale = Vector2(0.6, 0.6)
	banner.modulate.a = 0.0
	var tw := create_tween()
	_banner_tw = tw
	tw.set_parallel(true)
	tw.tween_property(banner, "scale", Vector2.ONE, _d(0.3)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tw.tween_property(banner, "modulate:a", 1.0, _d(0.2))
	tw.chain().tween_interval(maxf(0.05, _d(hold)))
	tw.chain().tween_property(banner, "modulate:a", 0.0, _d(0.3))
	tw.chain().tween_callback(func(): banner.visible = false)

func _log(msg: String) -> void:
	_history.append(("T%d  " % battle.turn if battle.turn > 0 else "") + msg)
	if _history.size() > HISTORY_MAX:
		_history.pop_front()
	log_label.text = msg
	log_label.modulate = Color(1, 0.85, 0.5)
	create_tween().tween_property(log_label, "modulate", Color.WHITE, 0.8)

# ---------------------------------------------------------------------------
# 0.10.0 — widgets novos
# ---------------------------------------------------------------------------

func _make_010_widgets() -> void:
	# Modo compacto: o tabuleiro encolhe com as cartas (sobra altura para ecrãs pequenos).
	if Settings.compact:
		(board_box.get_parent() as Control).custom_minimum_size.y = CardView.SIZE_COMPACT.y + 4
	# Fundo do ato (com as partículas do clima) por cima do fundo liso.
	var bg: Control = get_node("Background")
	_backdrop = BattleBackdrop.new()
	add_child(_backdrop)
	move_child(_backdrop, bg.get_index() + 1)
	# Retrato do inimigo no lugar do emblema com a inicial.
	emblem.visible = false
	_portrait = EnemyPortrait.new()
	_portrait.custom_minimum_size = Vector2(60, 60)
	_portrait.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var name_row: Control = emblem.get_parent()
	name_row.add_child(_portrait)
	name_row.move_child(_portrait, 0)
	# Turnos em pips no lugar das duas linhas de texto (o resto está na pausa).
	turn_label.visible = false
	_turn_pips = TurnPips.new()
	_turn_pips.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var top: Control = turn_label.get_parent()
	top.add_child(_turn_pips)
	top.move_child(_turn_pips, turn_label.get_index())
	# Encantamentos em jogo: à esquerda na faixa dos feitiços; o medidor da Cadeia à direita.
	_ench_box = HBoxContainer.new()
	_ench_box.add_theme_constant_override("separation", 6)
	spell_strip.add_child(_ench_box)
	spell_strip.move_child(_ench_box, 0)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	spell_strip.add_child(spacer)
	_chain_meter = ChainMeter.new()
	_chain_meter.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_chain_meter.tooltip_text = tr("Cadeia de cor")
	spell_strip.add_child(_chain_meter)
	# Escudo e lacaios do inimigo: por baixo da barra de vida.
	_defense_row = HBoxContainer.new()
	_defense_row.add_theme_constant_override("separation", 6)
	var vbox: Control = enemy_hp_label.get_parent()
	vbox.add_child(_defense_row)
	vbox.move_child(_defense_row, enemy_hp_label.get_index() + 1)
	# Histórico: tocar na linha de log mostra as últimas 30 ações.
	log_label.mouse_filter = Control.MOUSE_FILTER_STOP
	log_label.tooltip_text = tr("Toca para ver o histórico")
	log_label.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed:
			_open_history())

func _setup_backdrop() -> void:
	if _backdrop != null:
		_backdrop.setup(GameState.act_of_ante(GameState.ante) if not battle.puzzle else 1, battle.climate)

## Arquétipo do retrato: o do inimigo (enemies.json "portrait"); bonecos de treino e enigmas.
func _portrait_archetype() -> String:
	var a := String(battle.enemy.get("portrait", ""))
	if a != "":
		return a
	if battle.puzzle:
		return "dummy"
	var def := CardDB.enemy_def(String(battle.enemy.get("id", "")))
	return String(def.get("portrait", "brute"))

func _refresh_pips() -> void:
	if _turn_pips != null:
		_turn_pips.set_turns(battle.turn, battle.max_turns, battle.extra_turns)

func _refresh_chain_meter() -> void:
	if _chain_meter == null:
		return
	var info := EffectResolver.chain_of(battle.attackers())
	_chain_meter.set_chain(int(info["len"]), String(info["color"]), EffectResolver.chain_needed(), battle.max_creatures())
	_chain_meter.visible = not battle.board.is_empty()

## Escudo (% da vida máxima travada por ataque) e lacaios (●● = golpes que ainda aguentam).
func _refresh_defense() -> void:
	if _defense_row == null:
		return
	for c in _defense_row.get_children():
		_defense_row.remove_child(c)
		c.queue_free()
	var pct := float(battle.enemy.get("shield_pct", 0))
	if pct > 0.0:
		_defense_row.add_child(_intent_chip([["shield", Color(0.6, 0.8, 1.0), tr("Escudo %d%%") % int(pct)]], Color(0.14, 0.2, 0.32)))
	if not battle.minions.is_empty():
		var dots := ""
		for h in battle.minions:
			dots += "●".repeat(h) + " "
		_defense_row.add_child(_intent_chip([["creature", Color(0.9, 0.75, 0.55), tr("Lacaios") + " " + dots.strip_edges()]], Color(0.26, 0.18, 0.12)))
	_defense_row.visible = _defense_row.get_child_count() > 0
	_defense_row.mouse_filter = Control.MOUSE_FILTER_STOP
	if _defense_row.visible and not _defense_row.gui_input.is_connected(_on_defense_tap):
		_defense_row.gui_input.connect(_on_defense_tap)

func _on_defense_tap(ev: InputEvent) -> void:
	if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed and not SceneRouter.has_overlay():
		Sfx.select()
		var lines: Array[String] = []
		if float(battle.enemy.get("shield_pct", 0)) > 0.0:
			lines.append(tr("Escudo: trava os primeiros %s de cada ataque (volta a encher todos os turnos).") % Cascade.fmt_int(battle.shield_amount()))
		if not battle.minions.is_empty():
			lines.append(tr("Lacaios: cada um trava o Poder base de uma das primeiras criaturas da Arena (as habilidades disparam na mesma) e cai ao fim de 2 bloqueios. Põe as criaturas fracas à frente."))
		CardZoom.show_text(tr(battle.enemy.name), "\n\n".join(PackedStringArray(lines)), tr("Defesas do inimigo"), Color(0.6, 0.8, 1.0))

## Encantamentos em jogo: fichas na faixa dos feitiços (tocar abre a carta).
func _refresh_enchantments() -> void:
	if _ench_box == null:
		return
	for c in _ench_box.get_children():
		_ench_box.remove_child(c)
		c.queue_free()
	_ench_chips.clear()
	for en in battle.enchantments:
		var chip := _make_chip(en, "✧ " + en.data.display_name())
		var style: StyleBoxFlat = chip.get_theme_stylebox("panel").duplicate()
		style.set_border_width_all(2)
		style.border_color = COLOR_ENCHANT
		chip.add_theme_stylebox_override("panel", style)
		chip.mouse_filter = Control.MOUSE_FILTER_STOP
		chip.gui_input.connect(func(ev: InputEvent):
			if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed and not SceneRouter.has_overlay():
				Sfx.select()
				CardZoom.show_card(en))
		_ench_box.add_child(chip)
		_ench_chips[en.uid] = chip
	if spell_hint != null:
		spell_hint.visible = battle.spells_this_turn.is_empty() and battle.enchantments.is_empty()
	_fit_chips()

func _open_history() -> void:
	if SceneRouter.has_overlay() or _history.is_empty():
		return
	Sfx.select()
	var lines := _history.duplicate()
	lines.reverse()
	CardZoom.show_text(tr("Histórico da batalha"), "\n".join(PackedStringArray(lines)), tr("Últimas %d ações (a mais recente em cima)") % lines.size(), UiKit.TEXT_DIM)

## Inclina a carta arrastada para o lado para onde o dedo a puxa (e a sombra acompanha).
func _tilt_ghost(pos: Vector2) -> void:
	var vx := pos.x - _drag_last_x
	_drag_last_x = pos.x
	if Settings.motion_ok():
		_drag_ghost.rotation = lerpf(_drag_ghost.rotation, clampf(vx * 0.012, -0.28, 0.28), 0.35)
	if _alive(_drag_shadow):
		_drag_shadow.global_position = _drag_ghost.global_position + Vector2(10, 14)
		_drag_shadow.rotation = _drag_ghost.rotation
		_drag_shadow.pivot_offset = _drag_shadow.size / 2.0

# --- Fichas, encantamentos, Reforço, Reação, escudo ---

func _on_token_created(card: CardInstance) -> void:
	_log(tr("Uma Ficha de %s entra na Arena.") % card.data.display_name())
	if not _animating:
		_refresh_board()
		_refresh_preview()

func _on_enchantment_played(card: CardInstance) -> void:
	_log(tr("%s fica em jogo.") % card.data.display_name())
	_refresh_enchantments()

func _on_card_kicked(card: CardInstance) -> void:
	_log(tr("%s com Reforço!") % card.data.display_name())

func _on_shield_hit(_amount: int) -> void:
	pass   # o número aparece na cascata (antes do total)

func _on_reaction_played(card: CardInstance) -> void:
	Sfx.boom()
	Settings.vibrate(40)
	_show_banner(tr("REAÇÃO") + "\n" + card.data.display_name(), 0.9)
	_log(tr("Reagiste com %s.") % card.data.display_name())
	_refresh_all()

## O inimigo vai contra-atacar e tens uma Mágica com Reação que podes pagar: reages ou não.
func _on_reaction_window(options: Array) -> void:
	var dmg := battle.enemy_attack()
	var box := _open_modal(tr("REAÇÃO"), tr("%s vai atacar com %d. Reages com a mana que sobrou (%d)?") % [tr(battle.enemy.name), dmg, battle.mana_available])
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	for c in options:
		var v: CardView = CARD_VIEW.instantiate()
		row.add_child(v)
		v.setup(c)
		v.pressed.connect(func(card: CardInstance): _close_modal(card))
		v.long_pressed.connect(func(card: CardInstance): CardZoom.show_card(card))
	var skip := UiKit.button(tr("NÃO REAGIR"), 54, 20)
	skip.custom_minimum_size.x = 260
	skip.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	skip.pressed.connect(func(): _close_modal(null))
	box.add_child(skip)
	_modal.set_meta("reaction", true)
	Sfx.select()

## Reforço: jogar normal ou pagar mais mana pelo efeito extra. Devolve "plain", "kick" ou "" (cancelar).
func _ask_kicker(card: CardInstance) -> String:
	var base := battle.effects.cost_of(card)
	var extra := battle.kicker_cost(card)
	var box := _open_modal(card.data.display_name(), tr("Reforço: %s.") % card.data.display_kicker_text())
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 14)
	box.add_child(row)
	var plain := UiKit.button(tr("JOGAR (%d)") % base, 58, 20)
	plain.custom_minimum_size.x = 220
	plain.pressed.connect(func(): _close_modal("plain"))
	row.add_child(plain)
	var kick := UiKit.button(tr("COM REFORÇO (%d)") % (base + extra), 58, 20, Color(0.45, 0.32, 0.12), UiKit.GOLD)
	kick.custom_minimum_size.x = 260
	kick.pressed.connect(func(): _close_modal("kick"))
	row.add_child(kick)
	var gain_plain := battle.preview_play(card)
	var gain_kick := battle.preview_play(card, true)
	if gain_kick != gain_plain:
		var hint := UiKit.label(tr("Ataque: +%s normal · +%s com Reforço") % [Cascade.fmt_int(gain_plain), Cascade.fmt_int(gain_kick)], 17, UiKit.TEXT_DIM)
		hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(hint)
	var res = await _modal_result()
	return String(res) if res is String else ""

## Aviso com "não avisar mais". Devolve "yes", "no" ou "never".
func _ask(title: String, body: String, yes_text: String) -> String:
	var box := _open_modal(title, body)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	var yes := UiKit.button(yes_text, 56, 20, UiKit.PRIMARY.darkened(0.2), UiKit.PRIMARY)
	yes.custom_minimum_size.x = 200
	yes.pressed.connect(func(): _close_modal("yes"))
	row.add_child(yes)
	var no := UiKit.button(tr("VOLTAR"), 56, 20)
	no.custom_minimum_size.x = 160
	no.pressed.connect(func(): _close_modal("no"))
	row.add_child(no)
	var never := UiKit.button(tr("NÃO AVISAR MAIS"), 48, 16)
	never.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	never.custom_minimum_size.x = 240
	never.pressed.connect(func(): _close_modal("never"))
	box.add_child(never)
	var res = await _modal_result()
	return String(res) if res is String else "no"

## Janela modal da batalha (por cima do layout; o botão "retroceder" fecha-a como "não").
func _open_modal(title: String, body: String) -> VBoxContainer:
	if _alive(_modal):
		_close_modal(null)
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(UiKit.dim(0.6))
	add_child(root)
	_modal = root
	var panel := UiKit.centered_panel(root, 640, UiKit.BG, UiKit.GOLD)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	panel.add_child(box)
	var t := UiKit.label(title, 30, UiKit.GOLD)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(t)
	if body != "":
		var b := UiKit.label(body, 19, Color.WHITE, true)
		b.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(b)
	UiKit.pop_in(panel)
	return box

signal _modal_closed(result)

func _modal_result():
	return await _modal_closed

func _close_modal(result) -> void:
	if not _alive(_modal):
		return
	var was_reaction := bool(_modal.get_meta("reaction", false))
	_modal.queue_free()
	_modal = null
	Sfx.select()
	if was_reaction:
		EventBus.reaction_done.emit(result if result is CardInstance else null)
	else:
		_modal_closed.emit(result)

## Fim do turno de Treino: o dano do ataque e três saídas (repetir, editar, sair).
func _training_result() -> void:
	await get_tree().create_timer(_d(0.6)).timeout
	if not is_inside_tree():
		return
	var dmg := battle.best_hit
	var box := _open_modal(tr("TREINO"), tr("Dano do ataque: %s") % Cascade.fmt_int(dmg))
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	for opt in [["REPETIR", "battle"], ["EDITAR", "training"], ["SAIR", "main"]]:
		var b := UiKit.button(tr(String(opt[0])), 56, 20, UiKit.PRIMARY.darkened(0.2) if opt[1] == "battle" else UiKit.BG_LIGHT, Color(0, 0, 0, 0))
		b.custom_minimum_size.x = 180
		var target := String(opt[1])
		b.pressed.connect(func():
			Sfx.select()
			if target == "battle":
				GameState.start_training()
			else:
				GameState.puzzle_id = ""
			SceneRouter.go(target))
		row.add_child(b)
	Sfx.boom()
