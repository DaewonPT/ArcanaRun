extends Control
## Cena de batalha: liga a UI ao BattleManager através do EventBus.

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")

@onready var battle: BattleManager = $BattleManager
@onready var hand_box: HBoxContainer = %Hand
@onready var board_box: HBoxContainer = %Board
@onready var enemy_label: Label = %EnemyLabel
@onready var player_label: Label = %PlayerLabel
@onready var mana_label: Label = %ManaLabel
@onready var turn_label: Label = %TurnLabel
@onready var end_turn_btn: Button = %EndTurn
@onready var enemy_text: Label = %EnemyText
@onready var log_label: Label = %LogLabel

func _ready() -> void:
	EventBus.enemy_hp_changed.connect(func(c, m): enemy_label.text = "%s  %d/%d" % [battle.enemy.name, c, m])
	EventBus.player_hp_changed.connect(func(c, m): player_label.text = "Vida %d/%d   Ouro %d" % [c, m, GameState.gold])
	EventBus.gold_changed.connect(func(_g): EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp))
	EventBus.mana_changed.connect(_on_mana_changed)
	EventBus.turn_started.connect(_on_turn_started)
	EventBus.card_drawn.connect(func(_c): _refresh_hand())
	EventBus.hand_changed.connect(_refresh_hand)
	EventBus.creature_died.connect(func(_c): _refresh_board())
	EventBus.enemy_ability_used.connect(_on_enemy_ability)
	EventBus.damage_dealt.connect(_on_damage_dealt)
	EventBus.battle_ended.connect(_on_battle_ended)
	end_turn_btn.pressed.connect(_on_end_turn)

	battle.start(_pick_enemy())
	enemy_text.text = battle.enemy.text
	log_label.text = "Toca numa carta para a jogar."

func _pick_enemy() -> Dictionary:
	var raw: Array = JSON.parse_string(FileAccess.get_file_as_string("res://data/enemies.json"))
	var pool := raw.filter(func(e): return int(e.min_ante) <= GameState.ante)
	var def: Dictionary = pool[GameState.rng.randi_range(0, pool.size() - 1)]
	var hp := GameState.enemy_hp_for_ante(GameState.ante)
	return {
		"name": def.name,
		"hp": hp, "max_hp": hp,
		"attack": int(def.attack),
		"text": def.get("text", ""),
		"abilities": def.get("abilities", []),
	}

const ABILITY_LOG := {
	"steal_gold": "roubou-te ouro",
	"heal_self": "curou-se",
	"destroy_strongest": "destruiu a tua criatura mais forte",
	"damage_all_creatures": "feriu todas as tuas criaturas",
	"discard_random": "fez-te descartar uma carta",
}

func _on_enemy_ability(enemy_name: String, action: String) -> void:
	_log("%s %s!" % [enemy_name, ABILITY_LOG.get(action, action)])
	_refresh_all()

func _on_damage_dealt(target: String, amount: int) -> void:
	if target == "enemy":
		_log("Causaste %d de dano." % amount)
	else:
		_log("Levaste %d de dano." % amount)

func _log(msg: String) -> void:
	log_label.text = msg
	# Pequeno destaque para o jogador reparar nos eventos do inimigo.
	var tween := create_tween()
	log_label.modulate = Color(1, 0.85, 0.5)
	tween.tween_property(log_label, "modulate", Color.WHITE, 0.8)

func _on_mana_changed(available: int, total: int) -> void:
	mana_label.text = "Mana %d/%d" % [available, total]
	_refresh_hand()

func _on_turn_started(t: int) -> void:
	turn_label.text = "Turno %d/%d   Ante %d" % [t, battle.max_turns, GameState.ante]
	_refresh_all()

func _refresh_all() -> void:
	_refresh_hand()
	_refresh_board()

func _refresh_hand() -> void:
	for child in hand_box.get_children():
		child.queue_free()
	for card in battle.deck.hand:
		var view: CardView = CARD_VIEW.instantiate()
		hand_box.add_child(view)
		view.setup(card)
		view.playable = battle.can_play(card)
		view.pressed.connect(_on_hand_card_pressed)

func _refresh_board() -> void:
	for child in board_box.get_children():
		child.queue_free()
	for card in battle.board:
		if not card.data.is_creature():
			continue
		var view: CardView = CARD_VIEW.instantiate()
		board_box.add_child(view)
		view.setup(card)
		view.playable = not card.summoning_sick

func _on_hand_card_pressed(card: CardInstance) -> void:
	if battle.play(card):
		_refresh_all()

func _on_end_turn() -> void:
	end_turn_btn.disabled = true
	battle.end_turn()
	end_turn_btn.disabled = false

func _on_battle_ended(victory: bool) -> void:
	if victory:
		if GameState.ante >= GameState.max_ante:
			EventBus.run_ended.emit(true)
			SceneRouter.go("run_over")
		else:
			SceneRouter.go("shop")
	else:
		EventBus.run_ended.emit(false)
		SceneRouter.go("run_over")
