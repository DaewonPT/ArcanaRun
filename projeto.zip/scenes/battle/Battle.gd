extends Control
## Cena de batalha (horizontal). Liga a UI ao BattleManager através do EventBus e anima:
## cartas a voar da mão para o tabuleiro, compra, investida das criaturas na cascata,
## impacto no inimigo, número de dano a voar, partículas no total, banner de ante.
## Grava a run no início de cada turno (BattleManager.to_dict) e retoma-a se houver uma
## batalha pendente em GameState.pending_battle. Pausa, carta em grande e grimório/cemitério
## abrem como overlays (SceneRouter.show_overlay) sem destruir a cena.
## 0.10.0: mão em leque (FanHand), relíquias em medalhões, turnos em pips, retrato do inimigo,
## fundo por ato com o clima, medidor da Cadeia, encantamentos na faixa dos feitiços, escudo e
## lacaios do inimigo, janela de Reação, escolha do Reforço, avisos opcionais, histórico (tocar na
## linha de log), efeitos por cor na cascata e Némesis com falas.
## 0.15.0: Energia (⚡) ao lado da mana, Coroa sobre o coração, Ponto fraco e Ritual do boss por baixo da vida
## do inimigo, avisos do Mana de Sangue, Persistir, Veteranos e Excesso; grava também depois de cada jogada.

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const RELIC_VIEW := preload("res://scenes/ui/RelicView.tscn")
const FIRE_SHADER := preload("res://assets/shaders/fire.gdshader")

const COLOR_POWER := Color(0.22, 0.74, 0.97)
const COLOR_MULT := Color(0.96, 0.25, 0.37)
const COLOR_MULT_X := Color(0.72, 0.35, 0.95)
const COLOR_FORMATION := Color(0.98, 0.75, 0.25)
const COLOR_GROW := Color(0.35, 0.85, 0.45)
const COLOR_GOLD := Color(0.98, 0.85, 0.3)
const COLOR_SEAL := Color(0.9, 0.5, 0.9)
const COLOR_CLIMATE := Color(0.35, 0.8, 0.85)
const COLOR_BOSS_RELIC := Color(0.95, 0.4, 0.4)
const DISCARD_TINT := Color(0.8, 0.6, 1.0)
const BOTTOM_TINT := Color(0.6, 0.8, 1.0)
const VARIANT_NAMES := {"scout": "Batedor", "guard": "Guarda", "elite": "Elite", "boss": "Boss", "nemesis": "Némesis", "arena": "Campeão da Arena",
	"ambush": "Emboscada", "siege": "Cerco", "escape": "Fuga", "pair": "Dupla"}
const COLOR_TRIBE := Color(0.55, 0.9, 0.75)
const COLOR_CHAIN := Color(1.0, 0.62, 0.3)
const COLOR_ENCHANT := Color(0.75, 0.6, 1.0)
const COLOR_WEAK := Color(1.0, 0.55, 0.35)      # 0.15.0 Ponto fraco
const COLOR_RITUAL := Color(0.85, 0.7, 1.0)     # 0.15.0 Ritual do boss
const HISTORY_MAX := 30
const WARN_QUEUE_MAX := 3   # 0.20.0 (B10): avisos à espera no topo (fila curta)

const ABILITY_LOG := {
	"steal_gold": "roubou-te ouro",
	"heal_self": "curou-se",
	"destroy_strongest": "destruiu a tua criatura mais forte",
	"damage_all_creatures": "feriu todas as tuas criaturas",
	"discard_random": "fez-te descartar uma carta",
	"gold_tax": "cobrou-te ouro",
	"heal_self_pct": "recuperou vida",
	"steal_card": "roubou-te a carta mais cara da mão",
	"mirror_best": "copiou a tua criatura mais forte",
	"grow_attack": "ficou mais forte",
	"drain_mana": "sugou-te mana para o próximo turno",
	"grow_shield": "reforçou o escudo",
	"jail_strongest": "prendeu a tua criatura mais forte",
	"shuffle_board": "baralhou a ordem da tua Arena",
	"punish_channel": "castigou a canalização",
	"charge_attack": "está a carregar um golpe forte",
	"steal_relic": "desligou-te uma relíquia",
	# 0.17.0: inimigos novos
	"exile_graveyard": "exilou cartas do teu cemitério",
	"summon_minion": "chamou mais um lacaio",
	"freeze_card": "congelou a carta mais cara da tua mão",
	"weave": "afiou o fio com a tua relíquia (o contra-ataque sobe)",
	"discard_hand": "levou-te as cartas que não jogaste",
}

@onready var battle: BattleManager = $BattleManager
@onready var layout: Control = $Layout
@onready var hand_box: FanHand = %Hand
@onready var board_box: HBoxContainer = %Board
@onready var spell_strip: HBoxContainer = %SpellStrip
@onready var spell_hint: Label = %SpellHint
@onready var relics_bar: HBoxContainer = %RelicsBar
@onready var turn_label: Label = %TurnLabel
@onready var gold_label: Label = %GoldLabel
@onready var pause_btn: Button = %PauseBtn
@onready var enemy_panel: Control = %EnemyPanel
@onready var enemy_name: Label = %EnemyName
@onready var enemy_hp_bar: ProgressBar = %EnemyHPBar
@onready var enemy_hp_ghost: ProgressBar = %EnemyHPGhost
@onready var enemy_hp_label: Label = %EnemyHPLabel
@onready var enemy_text: Label = %EnemyText
@onready var counter_label: Label = %CounterLabel
@onready var emblem: PanelContainer = %Emblem
@onready var emblem_label: Label = %EmblemLabel
@onready var log_label: Label = %LogLabel
@onready var undo_btn: Button = %UndoBtn
@onready var player_label: Label = %PlayerLabel
@onready var mana_label: Label = %ManaLabel
@onready var end_turn_btn: Button = %EndTurn
@onready var discard_btn: Button = %DiscardBtn
@onready var library_btn: Button = %LibraryBtn
@onready var graveyard_btn: Button = %GraveyardBtn
@onready var formation_label: Label = %FormationLabel
@onready var power_label: Label = %PowerLabel
@onready var mult_label: Label = %MultLabel
@onready var total_label: Label = %TotalLabel
@onready var power_pill: Control = %PowerPill
@onready var mult_pill: Control = %MultPill
@onready var banner: Label = %Banner
@onready var mulligan_btn: Button = %MulliganBtn
@onready var pw_row: HBoxContainer = %PwRow

var _board_views: Dictionary = {}   # uid -> CardView
var _hand_views: Dictionary = {}    # uid -> CardView
var _spell_chips: Dictionary = {}   # uid -> Control
var _relic_views: Dictionary = {}   # relic_id -> RelicView
var _animating: bool = false
var _skip_cascade: bool = false   # 0.11.0: tocar no ecrã durante a cascata salta para o total
var _discard_mode: bool = false
var _layout_base: Vector2
var _particles: CPUParticles2D
var _hp_tween: Tween
var _pause_menu: PauseMenu
var _resumed: bool = false
var _undo_stack: Array[Dictionary] = []
var _undo_turn: int = 0
var _drag_ghost: Control
var _drag_view: Control
var _attack_style: StyleBoxFlat
var _lethal_style: StyleBoxFlat
const CONFIRM_ATTACK_TIME := 3.0   # 0.20.0 (B7): o 2.º toque que confirma um ataque que perde a run (como o Shop.CONFIRM_TIME)
var _attack_armed := false         # 0.20.0 (B7): o 1.º toque já avisou; o 2.º, dentro de CONFIRM_ATTACK_TIME, ataca
var _attack_arm_token := 0
var _danger_style: StyleBoxFlat    # 0.20.0 (B7): o ATACAR vermelho («NÃO CHEGA», «MORRES»)
var _last_preview_total: int = 0
var _pw_buttons: Array[Button] = []
var _pw_loyalty: Label
var _pw_name: Label
var _pw_panel: Control
var _pw_dial: Control                # 0.16.0: mostrador da lealdade do patrono
var _climate_chip: Control
var _climate_label: Label
var _contract_chip: Control
var _bubble: Control
var _bubble_tw: Tween
var _banner_tw: Tween
var _banner_lock_until: int = 0
var _hp_marker: ColorRect
var _fire_layer: Control
var _fire_rects: Array[ColorRect] = []
var _fire_still := false   # 0.19.0 (209): no modo de desempenho, uma imagem fixa (sem o shader a correr)
var _mute_btn: Button      # 0.19.0 (271)
var _mute_icon: CardIcon
var _fire_level: float = 0.0
var _fire_target: float = 0.0
var _hit_line_said: bool = false
var _mana_pips: ManaPips
var _intent_row: HBoxContainer
var _intent_sig: String = ""
var _last_cascade: Cascade
# 0.10.0
var _backdrop: BattleBackdrop
var _portrait: EnemyPortrait
var _turn_pips: TurnPips
var _chain_meter: ChainMeter
var _ench_box: HBoxContainer
var _ench_chips: Dictionary = {}   # uid -> Control
var _defense_row: HFlowContainer   # 0.15.0: parte em duas linhas (escudo, lacaios, ponto fraco, ritual)
var _history: Array[String] = []
var _modal: Control                # janela de Reação / escolha do Reforço / aviso
var _drag_shadow: Panel
var _drag_last_x: float = 0.0
# 0.12.1: mão — carta escolhida (1.º toque) e carta a ser arrastada (a flutuar).
var _selected_uid: int = -1
var _sel_hint: bool = false     # a linha de texto mostra a dica da carta escolhida (não vai para o histórico)
var _last_log: String = ""      # última mensagem a sério (volta quando a escolha acaba)
var _hand_drag_card: CardInstance = null
var _play_zone: bool = false
# 0.13.0
var _overlay: BattleOverlay          # números de ordem, etiquetas e setas do inimigo por cima da Arena
var _notice: Control                 # aviso curto no topo (não tapa o cálculo)
var _warn_queue: Array = []          # B10: [texto, cor, segundos, now, histórico] à espera de o _notice sair
var _what_if: bool = false           # o cálculo mostra o ataque com a carta arrastada
var _no_plays_turn: int = 0          # turno em que já se avisou "sem jogadas"
var _attack_glow: Tween              # ATACAR a brilhar quando não há mais jogadas
var _kw_bubble: Control              # explicação de uma palavra-chave (tocar no ícone)
var _last_attack_turn: int = 0       # turno do último ataque (para o "rever")
var _energy_box: HBoxContainer       # 0.15.0: Energia (⚡) ao lado da mana
var _energy_label: Label
var _crown_icon: Control             # 0.15.0: Coroa por cima do coração
var _weak_chip: Control              # 0.15.0: Ponto fraco do inimigo (por baixo da vida)
var _ritual_chip: PanelContainer     # 0.15.0: ritual do boss com a contagem
var _ritual_hot := false             # o ataque previsto já chega para interromper o ritual
var _save_timer: Timer               # 0.15.0: gravação depois de cada jogada (junta jogadas seguidas)

## Ícones da intenção do inimigo: ação → [ícone, cor, mostra o valor?]
const INTENT_ICONS := {
	"steal_gold": ["coin", Color(0.98, 0.8, 0.3), true],
	"heal_self": ["cross", Color(0.45, 0.9, 0.5), true],
	"destroy_strongest": ["skull", Color(0.92, 0.92, 0.92), false],
	"damage_all_creatures": ["burst", Color(1.0, 0.6, 0.3), true],
	"discard_random": ["card", Color(0.8, 0.6, 1.0), true],
	"heal_self_pct": ["cross", Color(0.45, 0.9, 0.5), true],
	"grow_attack": ["creature", Color(1.0, 0.45, 0.4), true],
	"drain_mana": ["mana", Color(0.6, 0.75, 1.0), true],
	"grow_shield": ["shield", Color(0.7, 0.85, 1.0), true],
	"jail_strongest": ["lock", Color(0.75, 0.75, 0.85), false],
	"shuffle_board": ["card", Color(0.95, 0.7, 1.0), false],
	"mirror_best": ["mirror", Color(0.78, 0.86, 1.0), false],
	"steal_card": ["card", Color(0.98, 0.8, 0.3), false],
	"charge_attack": ["instant", Color(1.0, 0.62, 0.2), false],
	"steal_relic": ["relic", Color(0.98, 0.8, 0.3), false],
	"exile_graveyard": ["exile", Color(0.78, 0.6, 1.0), true],   # 0.17.0
	"summon_minion": ["shield", Color(0.95, 0.8, 0.45), false],
	"freeze_card": ["lock", Color(0.6, 0.86, 1.0), true],
}

const ABILITY_INTENT := {
	"steal_gold": "rouba %d ouro",
	"heal_self": "cura-se %d",
	"destroy_strongest": "destrói a tua criatura mais forte",
	"damage_all_creatures": "%d de dano às tuas criaturas",
	"discard_random": "descarta-te %d carta(s)",
	"heal_self_pct": "cura-se %d%% da vida",
	"steal_card": "rouba a tua carta mais cara",
	"mirror_best": "copia a tua criatura mais forte",
	"grow_attack": "o ataque dele sobe %d",
	"drain_mana": "tens −%d de mana no próximo turno",
	"grow_shield": "o escudo sobe %d%%",
	"jail_strongest": "prende a tua criatura mais forte (não ataca no turno seguinte)",
	"shuffle_board": "baralha a ordem da tua Arena",
	"charge_attack": "carrega um golpe forte: no turno seguinte ataca com ×%s",
	"steal_relic": "desliga a tua relíquia mais à esquerda até ao fim da batalha",
	"exile_graveyard": "exila %d carta(s) de cima do teu cemitério",   # 0.17.0
	"summon_minion": "chama mais um lacaio (até 4)",
	"freeze_card": "congela a carta mais cara da tua mão: no turno seguinte custa +%d",
}

func _ready() -> void:
	add_to_group(SceneRouter.HOLD_GROUP)   # 0.20.0 (C11): os avisos de progresso esperam enquanto a batalha está na árvore
	_warm_art = ArtLib.collect_warm()   # 0.16.0 (77): as ilustrações que o mapa já carregou
	_layout_base = layout.position
	EventBus.enemy_hp_changed.connect(_on_enemy_hp)
	EventBus.player_hp_changed.connect(_set_life)
	EventBus.gold_changed.connect(_set_gold)
	EventBus.mana_changed.connect(_on_mana_changed)
	EventBus.discards_changed.connect(_on_discards_changed)
	EventBus.turn_started.connect(_on_turn_started)
	EventBus.card_drawn.connect(func(_c): _refresh_hand())
	EventBus.hand_changed.connect(_refresh_hand)
	EventBus.spell_cast.connect(_on_spell_cast)
	EventBus.creature_died.connect(_on_creature_died)
	EventBus.creature_blocked.connect(_on_creature_blocked)
	EventBus.creature_mirrored.connect(func(_c): _refresh_board())
	EventBus.card_stolen.connect(func(c: CardInstance):
		_log(tr("Roubada: %s (volta depois da batalha).") % c.data.display_name())
		_refresh_hand())
	EventBus.card_discarded.connect(_on_card_discarded)
	EventBus.card_grew.connect(_on_card_grew)
	EventBus.enemy_ability_used.connect(_on_enemy_ability)
	EventBus.damage_dealt.connect(_on_damage_dealt)
	EventBus.cascade_started.connect(_on_cascade_started)
	EventBus.battle_ended.connect(_on_battle_ended)
	EventBus.relics_changed.connect(_build_relics)
	EventBus.mulligan_taken.connect(_on_mulligan_taken)
	EventBus.card_transformed.connect(_on_card_transformed)
	EventBus.card_flashback.connect(_on_card_flashback)
	EventBus.seal_triggered.connect(_on_seal_triggered)
	EventBus.formation_leveled.connect(_on_formation_leveled)
	EventBus.planeswalker_changed.connect(_refresh_planeswalker)
	EventBus.card_exiled_run.connect(_on_card_exiled_run)
	EventBus.boss_ascended.connect(_on_boss_ascended)
	EventBus.boss_phase2.connect(_on_boss_phase2)
	EventBus.boss_phase.connect(_on_boss_phase)
	EventBus.relic_stolen.connect(_on_relic_stolen)
	EventBus.consumables_changed.connect(_refresh_items)
	EventBus.death_saved.connect(_on_death_saved)
	EventBus.contract_resolved.connect(_on_contract_resolved)
	EventBus.creature_exiled.connect(_on_creature_exiled)
	EventBus.climate_hit.connect(_on_climate_hit)
	EventBus.gold_changed.connect(func(_g): battle.on_gold_changed())
	EventBus.token_created.connect(_on_token_created)
	EventBus.enchantment_played.connect(_on_enchantment_played)
	EventBus.card_kicked.connect(_on_card_kicked)
	EventBus.reaction_window.connect(_on_reaction_window)
	EventBus.reaction_played.connect(_on_reaction_played)
	EventBus.shield_hit.connect(_on_shield_hit)
	EventBus.minions_changed.connect(func(_n): _refresh_defense())
	EventBus.keyword_granted.connect(_on_keyword_granted)
	EventBus.landfall.connect(_on_landfall)
	EventBus.creature_jailed.connect(func(_c): _refresh_board())
	EventBus.board_shuffled.connect(func():
		_refresh_board()
		_refresh_preview())
	EventBus.enemy_attacking.connect(_on_enemy_attacking)
	_connect_0180()
	Settings.changed.connect(_refresh_texts)
	end_turn_btn.pressed.connect(_on_end_turn_pressed)   # 0.19.0 (5): pode pedir para segurar
	end_turn_btn.button_down.connect(_on_end_turn_down)
	end_turn_btn.button_up.connect(_on_end_turn_up)
	set_meta("pad_custom", true)   # 0.19.0 (17): o comando joga a batalha (o SceneRouter não mexe no foco)
	mulligan_btn.pressed.connect(_on_mulligan)
	discard_btn.toggled.connect(_on_discard_toggled)
	pause_btn.pressed.connect(_open_pause)
	library_btn.pressed.connect(_open_library)
	graveyard_btn.pressed.connect(_open_graveyard)
	undo_btn.pressed.connect(_on_undo)
	_make_0160_layout()
	_apply_handedness()
	_attack_style = end_turn_btn.get_theme_stylebox("normal")
	_lethal_style = _attack_style.duplicate()
	_lethal_style.bg_color = Color(0.2, 0.68, 0.32)
	_make_particles()
	_make_fire()
	_make_status_icons()
	_make_intent_row()
	_make_calc_tap()
	_make_010_widgets()
	_make_0120_widgets()
	_make_0130_widgets()
	_make_0150_widgets()
	_make_0160_widgets()
	_make_0190_widgets()
	_make_s4_widgets()   # 0.19.0 (secção 4): clareza visual
	_make_s5_widgets()   # 0.19.0 (secção 5): legibilidade e HUD
	Settings.set_battle_screen_on(true)
	# Contorno escuro no texto por cima do cálculo: continua legível com as chamas atrás.
	for l in [log_label, formation_label]:
		l.add_theme_color_override("font_outline_color", Color(0.06, 0.04, 0.09))
		l.add_theme_constant_override("outline_size", 6)

	_build_relics()
	_set_gold(GameState.gold)
	# Quebra-cabeças: mão fixa, 1 turno; sem gravação nem mapa. (0.17.0: o Treino contra um boss é uma
	# batalha normal, mais abaixo.)
	if GameState.puzzle_id != "" and GameState.puzzle_id != "training_boss":
		var training := GameState.puzzle_id == "training"
		var lesson := GameState.is_lesson_battle()
		var pdef := GameState.training_def() if training else (CardDB.get_lesson(GameState.puzzle_id) if lesson else CardDB.get_puzzle(GameState.puzzle_id))
		_resumed = true
		battle.start_puzzle(pdef)
		_resumed = false
		_refresh_enemy_header()
		_build_info_row()
		_setup_backdrop()
		_refresh_all()
		if training:
			_log(tr("Treino: joga a mão e ataca. O boneco aguenta tudo."))
			_show_banner(tr("TREINO"), 1.0)
		elif lesson:
			_lesson_def = pdef
			EventBus.reaction_played.connect(_on_lesson_reaction)
			_log(tr("Objetivo: %s") % tr(String(pdef.get("goal", ""))))
			_show_banner(tr("LIÇÃO") + "\n" + tr(String(pdef.get("name", ""))), 1.2, false, true)
			_show_lesson_panel(pdef)
		else:
			_log(tr("Um só turno: encontra o ataque certo."))
			_show_banner(tr("ENIGMA") + "\n" + tr(String(pdef.get("name", ""))), 1.4, false, true)
		return
	# Retoma uma batalha gravada a meio, se houver; senão começa uma nova neste ante.
	var resumed := false
	if not GameState.pending_battle.is_empty():
		var state := GameState.pending_battle
		GameState.pending_battle = {}
		_resumed = true   # sem banner "TURNO N" durante o restore
		resumed = battle.restore(state)
		_resumed = false
	if not resumed:
		if GameState.puzzle_id == "training_boss":
			battle.start(GameState.training_boss_enemy())   # 0.17.0 (88): Treino contra um boss
		elif GameState.arena_battle:
			battle.start(GameState.pick_arena_enemy())   # 0.12.0: paragem Arena (batalha extra)
		else:
			if not GameState.map_choice.has("battle"):
				GameState.choose_battle("boss" if GameState.is_boss_ante(GameState.ante) else "scout")
			battle.start(GameState.pick_enemy(GameState.ante))
	_refresh_enemy_header()
	_build_info_row()
	_setup_backdrop()
	_refresh_all()
	# D12: também numa batalha retomada (CONTINUAR): no turno 1 desde o MULLIGAN (ou do «jogar», se já não der),
	# a partir do turno 2 desde o CANALIZAR.
	if not Stats.tutorial_done() and GameState.ante == 1 and (resumed or battle.turn == 1):
		var tut_from := "channel" if battle.turn >= 2 else ("mulligan" if battle.can_mulligan() else "play")
		TutorialOverlay.open(self, tut_from)
	if resumed:
		_log(tr("Run retomada no turno %d.") % battle.turn)
		var stage := GameState.stage_label().to_upper() if GameState.mode in ["tower", "rush"] else tr("ANTE %d") % GameState.ante
		if _is_last_turn():   # 0.20.0 (B7): o letreiro de uma batalha nova, com o ante antes do «faltam X»
			_show_last_turn_banner(stage + "  ·  ")
		else:
			_show_banner(stage + "\n" + tr("TURNO %d") % battle.turn, 1.1, false, true)
		_special_intro()
	else:
		_log(_play_help(battle.can_mulligan()))
		if battle.enemy.get("boss", false):
			# 0.12.0: entrada de cinema (retrato a cair, rugido); sem animações fica o letreiro.
			# 0.19.0 (181): com a opção, a entrada só na 1.ª vez (depois, o nome e a regra no letreiro).
			var intro: BossIntro = null if _intro_seen_before() else _boss_intro()
			if intro == null:
				_show_banner(tr("BOSS") + "\n" + tr(battle.enemy.name), 1.4, false, true)
				_say_after(_boss_line("intro"), _d(1.7) + 0.2, 3.4)
			else:
				var line := _boss_line("intro")   # a fala vem quando a entrada acaba (ou é saltada)
				intro.finished.connect(func(): _say_after(line, 0.15, 3.4), CONNECT_ONE_SHOT)
		elif String(battle.enemy.get("variant", "")) == "arena":
			_show_banner(tr("ARENA") + "\n" + tr(battle.enemy.name) + "  ·  " + tr("%d turnos") % battle.max_turns, 1.4, false, true)
		elif String(battle.enemy.get("variant", "")) == "nemesis":
			var n_intro := _boss_intro(tr("Nível %d") % int(battle.enemy.get("nemesis_level", 1)))
			if n_intro == null:
				_show_banner(tr("NÉMESIS") + "\n" + tr(battle.enemy.name) + "  ·  " + tr("Nível %d") % int(battle.enemy.get("nemesis_level", 1)), 1.4, false, true)
				_say_after(_boss_line("intro"), _d(1.7) + 0.2, 3.4)
			else:
				var n_line := _boss_line("intro")
				n_intro.finished.connect(func(): _say_after(n_line, 0.15, 3.4), CONNECT_ONE_SHOT)
		else:
			var vname := tr(VARIANT_NAMES.get(String(battle.enemy.get("variant", "scout")), "Batedor"))
			if battle.enemy.get("affixes") is Array and not (battle.enemy["affixes"] as Array).is_empty():
				vname += " " + GameState.affix_names(battle.enemy["affixes"])   # 0.13.0: "Elite Vampírico, Veloz"
			var who := tr(battle.enemy.name)
			if battle.is_pair():   # 0.18.0 (25): «Bandido e Lodo · Dupla»
				who += tr(" e ") + tr(String(battle.enemy2.get("name", "")))
			_show_banner(_stage_head() + "\n" + who + "  ·  " + vname, 1.1, false, true)
			_special_intro()

## O cabeçalho dos letreiros de entrada: «ATO II · ANTE 3»; 0.17.0: «TORRE DO ARQUIMAGO · ANDAR 12»,
## «CORRIDA DE BOSSES · BOSS 4/9» ou «TREINO».
func _stage_head() -> String:
	if GameState.puzzle_id == "training_boss":
		return tr("TREINO")
	if GameState.mode in ["tower", "rush"]:
		return tr(GameState.mode_name(GameState.mode)).to_upper() + " · " + GameState.stage_label().to_upper()
	return tr("ATO %s · ANTE %d") % [GameState.act_name(), GameState.ante]

## Entrada do boss/Némesis (0.12.0): ato, ante e a regra do boss por baixo do nome.
func _boss_intro(extra: String = "") -> BossIntro:
	var lines: PackedStringArray = [_stage_head() + (("  ·  " + extra) if extra != "" else "")]
	if String(battle.enemy.text) != "":
		lines.append(tr(String(battle.enemy.text)))
	var tint: Color = _portrait.tint if _portrait != null else Color(0.55, 0.42, 0.85)
	return BossIntro.play(self, battle.enemy, _portrait_archetype(), tint, "\n".join(lines))

## Modo canhoto: a coluna dos botões passa para a direita.
## 0.19.0 (24): os botões onde quiseres — com a mão dominante (como sempre), sempre à esquerda, sempre à direita ou
## em baixo, ao lado da mão (como no modo de uma mão). (27): a mão sobe ou desce.
func _apply_handedness() -> void:
	var middle: HBoxContainer = layout.get_node("Middle")
	var left_col: Control = middle.get_node("LeftCol")
	middle.move_child(left_col, middle.get_child_count() - 1 if buttons_side() == "right" else 0)
	layout.offset_bottom = -34.0 - float(Settings.opt("hand_offset"))
	_apply_one_hand()

## De que lado fica a coluna dos botões: "left" ou "right".
func buttons_side() -> String:
	var bb := String(Settings.opt("battle_buttons"))
	if bb == "left" or bb == "right":
		return bb
	return "right" if Settings.left_handed else "left"

## ATACAR, CANALIZAR e DESFAZER estão ao lado da mão (modo de uma mão ou «em baixo»)?
func _buttons_by_hand() -> bool:
	return Settings.one_hand or String(Settings.opt("battle_buttons")) == "bottom"

# --- 0.13.0: modo de uma mão ---
# ATACAR, CANALIZAR e DESFAZER descem para o lado da mão (o do polegar: direita, ou esquerda no modo
# canhoto), para jogar com o telemóvel numa só mão. Desligar devolve-os ao sítio de sempre.
var _hand_row: HBoxContainer = null
var _thumb_col: VBoxContainer = null
var _thumb_home: Array = []   # [[botão, pai, índice, altura mínima]]

func one_hand_active() -> bool:
	return _thumb_col != null

func _apply_one_hand() -> void:
	if _buttons_by_hand() and _thumb_col == null:
		_hand_row = HBoxContainer.new()
		_hand_row.name = "HandRow"
		_hand_row.add_theme_constant_override("separation", 12)
		var idx := hand_box.get_index()
		layout.add_child(_hand_row)
		layout.move_child(_hand_row, idx)
		layout.remove_child(hand_box)
		_hand_row.add_child(hand_box)
		hand_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_thumb_col = VBoxContainer.new()
		_thumb_col.name = "ThumbCol"
		_thumb_col.custom_minimum_size.x = 196
		_thumb_col.alignment = BoxContainer.ALIGNMENT_CENTER
		_thumb_col.add_theme_constant_override("separation", 6)
		_hand_row.add_child(_thumb_col)
		_thumb_home.clear()
		for b in [end_turn_btn, discard_btn, undo_btn]:   # guarda os lugares antes de tirar algum
			_thumb_home.append([b, (b as Node).get_parent(), (b as Node).get_index(), (b as Control).custom_minimum_size.y])
		for h in _thumb_home:
			var btn: Button = h[0]
			(h[1] as Node).remove_child(btn)
			_thumb_col.add_child(btn)
			btn.custom_minimum_size.y = maxf(btn.custom_minimum_size.y, 48.0)
	elif not _buttons_by_hand() and _thumb_col != null:
		for h in _thumb_home:
			var btn: Button = h[0]
			_thumb_col.remove_child(btn)
			(h[1] as Node).add_child(btn)
			(h[1] as Node).move_child(btn, mini(int(h[2]), (h[1] as Node).get_child_count() - 1))
			btn.custom_minimum_size.y = float(h[3])
		_thumb_home.clear()
		var idx := _hand_row.get_index()
		_hand_row.remove_child(hand_box)
		layout.add_child(hand_box)
		layout.move_child(hand_box, idx)
		hand_box.size_flags_horizontal = Control.SIZE_FILL
		_hand_row.queue_free()
		_hand_row = null
		_thumb_col = null
	if _hand_row != null:
		# O polegar: à direita da mão, ou à esquerda no modo canhoto (ou do lado escolhido para os botões).
		var thumb_left := Settings.left_handed if String(Settings.opt("battle_buttons")) in ["hand", "bottom"] else buttons_side() == "left"
		_hand_row.move_child(_thumb_col, 0 if thumb_left else _hand_row.get_child_count() - 1)

## Nome, emblema (inicial numa cor derivada do id) e texto do inimigo; moldura dourada nos bosses.
func _refresh_enemy_header() -> void:
	enemy_name.text = battle.enemy.name
	enemy_text.text = battle.enemy.text
	if battle.ascended and String(battle.enemy.get("rule2_text", "")) != "":
		enemy_text.text = String(battle.enemy.get("rule2_text", ""))
	# 0.13.0: afixos da Elite e a fase da Hidra por baixo do texto.
	var extra: Array[String] = []
	if battle.enemy.get("affixes") is Array:
		for af_id in battle.enemy["affixes"]:
			var af := CardDB.get_affix(String(af_id))
			if not af.is_empty():
				extra.append("◆ %s: %s" % [tr(String(af.get("name", ""))), tr(String(af.get("text", "")))])
	if String(battle.enemy.get("phase_text", "")) != "":
		extra.append(tr(String(battle.enemy["phase_text"])))
	if not extra.is_empty():
		enemy_text.text = tr(enemy_text.text) + ("\n" if enemy_text.text != "" else "") + "\n".join(PackedStringArray(extra))
	_enemy_text_base = tr(enemy_text.text)   # 0.19.0 (157): a regra com o efeito em ti vai por trás
	var id := String(battle.enemy.get("id", battle.enemy.name))
	var name_txt := tr(String(battle.enemy.name))
	emblem_label.text = name_txt.substr(0, 1).to_upper() if name_txt != "" else "?"
	var style: StyleBoxFlat = emblem.get_theme_stylebox("panel").duplicate()
	style.bg_color = Color.from_hsv(fmod(float(abs(id.hash())) / 1000.0, 1.0), 0.55, 0.75)
	emblem.add_theme_stylebox_override("panel", style)
	if _portrait != null:
		_portrait.archetype = _portrait_archetype()
		_portrait.tint = style.bg_color
		_portrait.boss = bool(battle.enemy.get("boss", false)) or String(battle.enemy.get("variant", "")) == "nemesis"
	_refresh_enemy_art()   # 0.16.0: a ilustração (com a expressão do boss) e o fundo esbatido do painel
	_refresh_defense()
	enemy_name.add_theme_color_override("font_color", Color(1.0, 0.5, 0.45) if battle.phase2 else Color.WHITE)
	if battle.enemy.get("boss", false):
		_ensure_hp_marker()
		var panel_style: StyleBoxFlat = enemy_panel.get_theme_stylebox("panel").duplicate()
		panel_style.border_color = UiKit.GOLD
		panel_style.border_width_left = 3
		panel_style.border_width_right = 3
		panel_style.border_width_top = 3
		panel_style.border_width_bottom = 3
		if battle.phase2:
			panel_style.border_color = Color(0.95, 0.35, 0.3)
		enemy_panel.add_theme_stylebox_override("panel", panel_style)

## Bosses: risca dourada a meio da barra de vida (abaixo dela o boss desperta). 0.13.0: os bosses com
## fases têm uma risca por fase (apagada depois de passar).
func _ensure_hp_marker() -> void:
	var phases: Array = battle.enemy.get("phases", []) if battle.enemy.get("phases") is Array else []
	var hidden := _hp_segments != null   # 0.16.0 (63): a barra em segmentos já mostra as fases
	if not phases.is_empty():
		var holder: Control = enemy_hp_bar.get_parent()
		for i in phases.size():
			var nm := "PhaseMark%d" % i
			var m: ColorRect = holder.get_node_or_null(nm)
			if m == null:
				m = ColorRect.new()
				m.name = nm
				m.mouse_filter = Control.MOUSE_FILTER_IGNORE
				var f := clampf(float((phases[i] as Dictionary).get("pct", 50)) / 100.0, 0.0, 1.0)
				m.anchor_left = f
				m.anchor_right = f
				m.anchor_bottom = 1.0
				m.offset_left = -2.0
				m.offset_right = 2.0
				m.offset_top = -4.0
				m.offset_bottom = 4.0
				holder.add_child(m)
			m.color = Color(1, 1, 1, 0.3) if battle.phase_index > i else UiKit.GOLD
			m.visible = not hidden
		return
	if _hp_marker == null:
		_hp_marker = ColorRect.new()
		_hp_marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_hp_marker.anchor_left = 0.5
		_hp_marker.anchor_right = 0.5
		_hp_marker.anchor_bottom = 1.0
		_hp_marker.offset_left = -2.0
		_hp_marker.offset_right = 2.0
		_hp_marker.offset_top = -4.0
		_hp_marker.offset_bottom = 4.0
		enemy_hp_bar.get_parent().add_child(_hp_marker)
	_hp_marker.color = Color(1, 1, 1, 0.3) if battle.phase2 else UiKit.GOLD
	_hp_marker.visible = not hidden

func _make_particles() -> void:
	_particles = CPUParticles2D.new()
	_particles.emitting = false
	_particles.one_shot = true
	_particles.explosiveness = 0.95
	_particles.amount = 48
	_particles.lifetime = 0.8
	_particles.spread = 180.0
	_particles.direction = Vector2(0, -1)
	_particles.gravity = Vector2(0, 700)
	_particles.initial_velocity_min = 220.0
	_particles.initial_velocity_max = 520.0
	_particles.scale_amount_min = 3.0
	_particles.scale_amount_max = 7.0
	_particles.color = Color(1.0, 0.85, 0.35)
	add_child(_particles)

## Chamas atrás das pílulas de Poder e Mult (o fundo das pílulas tapa a base; vêem-se a subir).
## Crescem com o ataque em relação à vida que falta ao inimigo: letal = fogo no máximo.
## 0.12.1: shader novo com ruído de textura (liso também nos telemóveis), núcleo quente, faúlhas, e o
## retângulo segue a pílula mesmo quando ela salta (escala).
static var _fire_noise: NoiseTexture2D

static func fire_noise() -> NoiseTexture2D:
	if _fire_noise == null:
		var fn := FastNoiseLite.new()
		fn.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
		fn.frequency = 0.012
		fn.fractal_octaves = 3
		fn.seed = 7
		_fire_noise = NoiseTexture2D.new()
		_fire_noise.width = 256
		_fire_noise.height = 256
		_fire_noise.seamless = true
		_fire_noise.normalize = true
		_fire_noise.noise = fn
	return _fire_noise

func _make_fire() -> void:
	_fire_still = Settings.performance_mode
	if _fire_layer != null and is_instance_valid(_fire_layer):
		remove_child(_fire_layer)
		_fire_layer.queue_free()
		_fire_rects.clear()
	_fire_layer = Control.new()
	_fire_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fire_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(_fire_layer)
	move_child(_fire_layer, layout.get_index())
	var looks := [[Vector3(0.22, 0.55, 1.0), Vector3(0.78, 0.95, 1.0), 0.0], [Vector3(1.0, 0.38, 0.1), Vector3(1.0, 0.92, 0.6), 0.47]]
	for look in looks:
		var r := ColorRect.new()
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		r.visible = false
		if _fire_still:
			var still := TextureRect.new()
			still.name = "FireStill"
			still.texture = fire_still_texture(look[0], look[1])
			still.stretch_mode = TextureRect.STRETCH_SCALE
			still.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			still.set_anchors_preset(Control.PRESET_FULL_RECT)
			still.mouse_filter = Control.MOUSE_FILTER_IGNORE
			r.color = Color(0, 0, 0, 0)
			r.add_child(still)
			_fire_layer.add_child(r)
			_fire_rects.append(r)
			continue
		var m := ShaderMaterial.new()
		m.shader = FIRE_SHADER
		m.set_shader_parameter("tint", look[0])
		m.set_shader_parameter("core", look[1])
		m.set_shader_parameter("seed", look[2])
		m.set_shader_parameter("noise_tex", fire_noise())
		m.set_shader_parameter("intensity", 0.0)
		r.material = m
		_fire_layer.add_child(r)
		_fire_rects.append(r)

## 209: a chama parada — um degradê do núcleo (em baixo) à ponta (em cima), feito uma vez por cor.
static var _fire_still_cache := {}

static func fire_still_texture(tint: Vector3, core: Vector3) -> Texture2D:
	var key := str(tint)
	if _fire_still_cache.has(key):
		return _fire_still_cache[key]
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.35, 0.75, 1.0])
	g.colors = PackedColorArray([Color(core.x, core.y, core.z, 0.8), Color(tint.x, tint.y, tint.z, 0.55), Color(tint.x, tint.y, tint.z, 0.12), Color(tint.x, tint.y, tint.z, 0.0)])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.width = 64
	gt.height = 64
	gt.fill = GradientTexture2D.FILL_RADIAL   # uma cúpula de luz que nasce do topo da pílula
	gt.fill_from = Vector2(0.5, 1.0)
	gt.fill_to = Vector2(0.5, 0.0)
	_fire_still_cache[key] = gt
	return gt

## 0..1: um ataque de 25 % da vida restante começa a arder; letal arde no máximo.
func _fire_for(total: float) -> float:
	var hp := float(maxi(1, int(battle.enemy.get("hp", 1))))
	return clampf((total / hp - 0.25) / 0.75, 0.0, 1.0)

func _process(delta: float) -> void:
	# 0.16.0 (72): enquanto há ataque, animação ou carta a ser arrastada, o jogo fica a 60 FPS.
	if _animating or _drag_ghost != null or (battle != null and battle.resolving):
		SceneRouter.keep_awake(0.6)
	if _hold_t >= 0.0:
		_hold_tick(delta)
	if _fps_probe_on:
		_fps_probe_tick()
	_fire_level = move_toward(_fire_level, _fire_target, delta * 1.6)
	if _fire_still != Settings.performance_mode:   # o modo de desempenho mudou a meio (por exemplo, sozinho com o calor)
		_make_fire()
	var on := _fire_level > 0.01
	for i in _fire_rects.size():
		var r := _fire_rects[i]
		r.visible = on
		if not on:
			continue
		var pill: Control = power_pill if i == 0 else mult_pill
		# Retângulo visto da pílula (com a escala dos saltos): as chamas nascem atrás do topo dela.
		var xf := pill.get_global_transform()
		var p0 := xf * Vector2.ZERO
		var p1 := xf * pill.size
		var pw := p1.x - p0.x
		var ph := p1.y - p0.y
		var h := ph * 2.1
		r.global_position = Vector2(p0.x - pw * 0.04, p0.y + ph * 0.5 - h)
		r.size = Vector2(pw * 1.08, h)
		if r.material is ShaderMaterial:
			(r.material as ShaderMaterial).set_shader_parameter("intensity", _fire_level)
		else:
			r.modulate.a = clampf(_fire_level * 1.2, 0.0, 1.0)

## Vida com um coração e mana em cristais (menos texto na coluna da esquerda).
func _make_status_icons() -> void:
	var row: HBoxContainer = player_label.get_parent()
	var heart := CardIcon.new("heart", Color(0.95, 0.35, 0.4), 24.0)
	heart.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(heart)
	row.move_child(heart, player_label.get_index())
	player_label.add_theme_font_size_override("font_size", 22)
	_mana_pips = ManaPips.new()
	_mana_pips.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(_mana_pips)
	row.move_child(_mana_pips, mana_label.get_index())
	mana_label.add_theme_font_size_override("font_size", 16)
	_set_life(GameState.player_hp, GameState.player_max_hp)

func _set_life(current: int, max_hp: int) -> void:
	player_label.text = "%d/%d" % [current, max_hp]
	player_label.tooltip_text = tr("Vida %d/%d") % [current, max_hp]

func _set_mana(available: int, total: int) -> void:
	mana_label.text = "%d/%d" % [available, total]
	if _mana_pips != null:
		_mana_pips.set_mana(available, total)

## Duração de uma animação com a velocidade das Configurações.
func _d(seconds: float) -> float:
	return Settings.dur(seconds)

# --- Construção / refresh ---

func _build_relics() -> void:
	for child in relics_bar.get_children():
		relics_bar.remove_child(child)
		child.queue_free()
	_relic_views.clear()
	var n := GameState.relic_ids.size() + GameState.boss_relics.size() + GameState.blessings.size()
	var w := _relic_width(n)
	for id in GameState.relic_ids:
		var view: RelicView = RELIC_VIEW.instantiate()
		relics_bar.add_child(view)
		view.setup(id)
		view.set_width(w)
		view.pressed.connect(_on_relic_pressed)
		view.drag_started.connect(_on_relic_drag_started)
		view.drag_moved.connect(_on_relic_drag_moved)
		view.drag_ended.connect(_on_relic_drag_ended)
		_relic_views[id] = view
		if id in GameState.stolen_relics:   # 0.13.0 Ladra de Relíquias
			view.modulate = Color(0.45, 0.45, 0.5, 0.55)
	# Relíquias de boss e Bênçãos (0.12.0): depois das normais (disparam a seguir na cascata), sem arrastar.
	for id in GameState.boss_relics + GameState.blessings:
		var bview: RelicView = RELIC_VIEW.instantiate()
		relics_bar.add_child(bview)
		bview.setup(id)
		bview.set_width(w)
		bview.pressed.connect(_on_relic_pressed)
		_relic_views[id] = bview
	_refresh_top_blocks()
	if not _animating and battle.effects != null:
		_refresh_preview()

## Largura de cada relíquia para caberem todas na barra de cima (sem empurrar o ecrã).
func _relic_width(_n: int) -> float:
	return TOP_ICON   # medalhões de tamanho fixo (o nome abre ao tocar); 0.18.0: 48 px, a barra de cima ficou mais baixa

func _refresh_all() -> void:
	# 0.13.0: o ATACAR só fica desligado enquanto o ataque corre ou durante o fundo do Mulligan.
	if not battle.resolving and not battle.finished and not _animating:
		end_turn_btn.disabled = battle.pending_bottom > 0
	_refresh_hand()
	_refresh_board()
	_refresh_spells()
	_refresh_enchantments()
	_refresh_defense()
	_refresh_items()
	_refresh_preview()
	_refresh_zone_buttons()
	for v in _relic_views.values():
		if _alive(v):
			(v as RelicView).refresh_value()
	_refresh_tool_buttons()
	_refresh_0150_status()
	_s5_refresh()   # 0.19.0 (secção 5)
	_check_tips()
	_queue_save()
	_maybe_offer_performance()

# --- Dicas (0.11.0): uma linha na primeira vez que aparece cada mecânica ---

var _tip_queue: Array[String] = []
var _tip_panel: Control
var _last_preview_chain := 0

## Procura coisas novas no ecrã (mão, Arena, inimigo) e pede a dica de cada uma (só a 1.ª vez).
func _check_tips() -> void:
	if not Settings.tips_enabled or battle.puzzle or battle.finished or _animating or not Stats.tutorial_done():
		return
	for c in battle.deck.hand:
		var d := c.data
		if d.is_land():
			_tip("land")
		if d.has_kicker():
			_tip("kicker")
		if BattleManager.has_reaction(c):
			_tip("reaction")
		if d.is_enchantment():
			_tip("enchantment")
		if d.is_equipment():
			_tip("equipment")
		if d.is_mythic():
			_tip("mythic")
		if d.is_curse():
			_tip("curse")
		if c.has_mission():
			_tip("mission")
		if d.tribe != "" and not d.token:
			_tip("tribe")
		if not d.keywords.is_empty():
			_tip("keyword")
		if c.seal() != "":
			_tip("seal")
		for e in d.effects:
			if String(e.get("action", "")) == "create_token":
				_tip("token")
			if String(e.get("trigger", "")) == "landfall":
				_tip("landfall")
		_keyword_tips(c)
		for t in mech_tags(d):   # 0.15.0: Energia, Coroa, Delírio, Domínio, Mana de Sangue
			_tip(t)
	for c in battle.board + battle.enchantments:
		if c.data.token:
			_tip("token")
		if not c.keywords().is_empty():
			_tip("keyword")
		_keyword_tips(c)
		for t in mech_tags(c.data):
			_tip(t)
	if battle.weak_color != "":   # 0.15.0
		_tip("weak")
	if not battle.ritual.is_empty():
		_tip("ritual")
	if not battle.deck.flashback_cards().is_empty():
		_tip("flashback")
	if not battle.minions.is_empty():
		_tip("minion")
	if float(battle.enemy.get("shield_pct", 0.0)) > 0.0:
		_tip("shield")
	if bool(battle.enemy.get("boss", false)):
		_tip("boss")
		match String(battle.enemy.get("id", "")):
			"boss_mirror":
				_tip("mirror")
			"boss_thief":
				_tip("thief")
			"boss_fog":
				_tip("fog")
	if String(battle.enemy.get("variant", "")) == "nemesis":
		_tip("nemesis")
	if battle.climate != "":
		_tip("climate")
	if not GameState.planeswalker.is_empty():
		_tip("planeswalker")
	if _last_preview_chain >= 2:
		_tip("chain")
	if _s4_cascade != null and not _s4_cascade.formations.is_empty():   # D12: a 1.ª formação no ataque previsto
		_tip("formation")

## 0.12.0: dica própria para Voar, Atropelar e Primeiro Golpe.
func _keyword_tips(c: CardInstance) -> void:
	for k in ["flying", "trample", "first_strike", "prowess", "persist"]:
		if c.has_keyword(k):
			_tip(k)

func _tip(id: String) -> void:
	if not Settings.tips_enabled or battle.puzzle or not Stats.tutorial_done():
		return
	if id in _tip_queue or GameState.tip_seen(id) or not CardDB.tips.has(id):
		return
	GameState.mark_tip_seen(id)
	_tip_queue.append(id)
	if not _alive(_tip_panel):
		_show_next_tip()

func _show_next_tip() -> void:
	if _tip_queue.is_empty() or not is_inside_tree():
		return
	var id: String = _tip_queue.pop_front()
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.12, 0.1, 0.2, 0.97), 12, UiKit.GOLD, 2, 8))
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	panel.z_index = 50
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(row)
	var tag := UiKit.label(tr("DICA"), 15, UiKit.GOLD)
	tag.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(tag)
	var text := UiKit.label(tr(String(CardDB.tips.get(id, ""))), 15, Color.WHITE, true)
	text.custom_minimum_size.x = clampf(_top_room() - 100.0, 360.0, 640.0)   # 0.13.0: no topo, em 2 linhas
	row.add_child(text)
	var x := UiKit.label("✕", 18, UiKit.TEXT_DIM)
	x.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(x)
	panel.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.pressed:
			_close_tip(panel))
	add_child(panel)
	_tip_panel = panel
	panel.modulate.a = 0.0
	await get_tree().process_frame
	if not is_instance_valid(panel) or not is_inside_tree():
		return
	# 0.13.0: no topo do ecrã, por cima das relíquias (entre o ORDENAR e o ouro): nunca tapa o cálculo,
	# os feitiços, o clima, o planeswalker nem a Arena.
	panel.reset_size()
	panel.global_position = _top_slot(panel.size, false)
	create_tween().tween_property(panel, "modulate:a", 1.0, _d(0.2))
	await get_tree().create_timer(7.0).timeout
	if is_inside_tree():
		_close_tip(panel)

func _close_tip(panel: Control) -> void:
	if not is_instance_valid(panel) or panel.is_queued_for_deletion():
		return
	panel.queue_free()
	if _tip_panel == panel:
		_tip_panel = null
	if not is_inside_tree():
		return
	await get_tree().create_timer(0.4).timeout
	_show_next_tip()

## Texto que depende do idioma (chamado quando as Configurações mudam).
func _turn_text() -> String:
	if GameState.mode in ["tower", "rush"] and GameState.puzzle_id == "":   # 0.17.0: andar / boss n.º
		return tr("Turno %d/%d") % [battle.turn, battle.max_turns + battle.extra_turns] + "  ·  " + GameState.stage_label() \
			+ "\n" + tr(GameState.mode_name(GameState.mode))
	var line1 := tr("Turno %d/%d  ·  Ante %d") % [battle.turn, battle.max_turns + battle.extra_turns, GameState.ante]
	if battle.puzzle:
		return line1.split("  ·  ")[0] + "\n" + tr("Quebra-cabeças")
	var line2 := tr("Ato %s") % GameState.act_name() + "  ·  " + tr(VARIANT_NAMES.get(String(battle.enemy.get("variant", "scout")), "Batedor"))
	if GameState.stake > 1:
		line2 += "  ·  " + tr("Selo %d") % GameState.stake
	return line1 + "\n" + line2

func _refresh_texts() -> void:
	if battle.enemy.is_empty():
		return
	_apply_handedness()
	turn_label.text = _turn_text()
	_refresh_pips()
	_set_gold(GameState.gold)
	if _lib_pile != null:
		_lib_pile.refresh_back()
	_set_life(GameState.player_hp, GameState.player_max_hp)
	_set_mana(battle.mana_available, battle.mana_total)
	_refresh_enemy_header()
	_refresh_discard_button()
	_refresh_zone_buttons()
	_refresh_planeswalker()
	if not _animating:
		_refresh_preview()
		for v in _hand_views.values():
			if _alive(v):
				v.size_scale = Settings.hand_scale_eff()
				v.refresh()
		for v in _board_views.values():
			if _alive(v):
				v.refresh()

func _refresh_zone_buttons() -> void:
	if _lib_pile != null:
		_refresh_piles()   # 0.16.0: o grimório e o cemitério são pilhas
	else:
		library_btn.text = tr("GRIMÓRIO %d") % battle.deck.library.size()
		var fb := 0
		for c in battle.flashback_cards():
			if battle.can_flashback(c):
				fb += 1
		graveyard_btn.text = tr("CEMITÉRIO %d") % battle.deck.graveyard.size() + (" ↺" if fb > 0 else "")
	undo_btn.disabled = _undo_stack.is_empty() or battle.resolving or battle.finished
	mulligan_btn.visible = battle.can_mulligan()
	mulligan_btn.text = tr("MULLIGAN") if battle.mulligans == 0 else tr("MULLIGAN (−%d)") % (battle.mulligans + 1)
	_refresh_planeswalker()

## Ordem da mão no ecrã: as outras cartas primeiro e os Terrenos juntos na ponta direita.
## 0.12.0: ORDENAR (Settings.hand_sort) — como vieram, por custo ou por tipo (e custo dentro do tipo).
func _hand_order() -> Array[CardInstance]:
	var out: Array[CardInstance] = []
	for c in battle.deck.hand:
		if not c.data.is_land():
			out.append(c)
	if Settings.hand_sort != "":
		var pos := {}
		for i in battle.deck.hand.size():
			pos[battle.deck.hand[i].uid] = i
		var by_type := Settings.hand_sort == "type"
		out.sort_custom(func(a: CardInstance, b: CardInstance):
			if by_type and _type_rank(a) != _type_rank(b):
				return _type_rank(a) < _type_rank(b)
			if a.data.cost != b.data.cost:
				return a.data.cost < b.data.cost
			return int(pos[a.uid]) < int(pos[b.uid]))
	for c in battle.deck.hand:
		if c.data.is_land():
			out.append(c)
	return out

static func _type_rank(c: CardInstance) -> int:
	if c.data.is_creature():
		return 0
	if c.data.is_spell():
		return 1
	if c.data.is_enchantment() or c.data.is_equipment():
		return 2
	return 3

func _refresh_hand() -> void:
	CardView.fog_hand = bool(battle.rule.get("hide_text", false))
	var ordered := _hand_order()
	# Se a mão é a mesma (mesmas cartas, mesma ordem), só atualiza as vistas — não interrompe animações.
	var live := hand_box.get_children().filter(func(c): return not c.is_queued_for_deletion())
	var same := _hand_views.size() == ordered.size() and live.size() == ordered.size()
	if same:
		var i := 0
		for card in ordered:
			if not _hand_views.has(card.uid) or live[i] != _hand_views[card.uid]:
				same = false
				break
			i += 1
	if same:
		for card in battle.deck.hand.duplicate():
			var v: CardView = _hand_views[card.uid]
			if _alive(v):
				v.size_scale = Settings.hand_scale_eff()   # 0.13.0: tamanho das cartas da mão
				v.refresh()
				v.playable = battle.can_play(card) or card.data.is_land() or _discard_mode or battle.pending_bottom > 0
				v.modulate = BOTTOM_TINT if battle.pending_bottom > 0 else (DISCARD_TINT if _discard_mode else Color.WHITE)
				v.delta = 0 if (_discard_mode or _animating or battle.pending_bottom > 0) else battle.preview_play(card)
				v.set_frozen(card.uid == battle.frozen_uid, battle.frozen_cost)   # 0.19.0 (112)
		_apply_selection()
		_refresh_preview()
		_refresh_zone_buttons()
		return
	var previous := _hand_views.keys()
	for child in hand_box.get_children():
		hand_box.remove_child(child)   # sai já da árvore: nunca se desenha em duplicado com as novas
		child.queue_free()
	_hand_views.clear()
	var stagger := 0.0
	var first_land := true
	for card in ordered:
		var view: CardView = CARD_VIEW.instantiate()
		view.size_scale = Settings.hand_scale_eff()   # 0.13.0: tamanho das cartas da mão (Configurações → Visual)
		if card.data.is_land() and first_land:
			first_land = false
			view.set_meta("fan_gap_before", true)   # espaço antes do grupo dos Terrenos
		hand_box.add_child(view)
		view.setup(card)
		view.playable = battle.can_play(card) or card.data.is_land() or _discard_mode or battle.pending_bottom > 0
		if battle.pending_bottom > 0:
			view.modulate = BOTTOM_TINT
		elif _discard_mode:
			view.modulate = DISCARD_TINT
		view.pressed.connect(_on_hand_card_tapped)
		view.long_pressed.connect(_on_card_long_pressed)
		view.draggable = true   # 0.12.1: segurar e arrastar muda a carta de lugar (ou joga-a lá em cima)
		view.drag_started.connect(_on_hand_drag_started)
		view.drag_moved.connect(_on_hand_drag_moved)
		view.drag_ended.connect(_on_hand_drag_ended)
		view.delta = 0 if (_discard_mode or _animating or battle.pending_bottom > 0) else battle.preview_play(card)
		_hand_views[card.uid] = view
		view.set_frozen(card.uid == battle.frozen_uid, battle.frozen_cost)   # 0.19.0 (112)
		if not (card.uid in previous):
			_animate_draw(view, stagger)
			stagger += 0.05
			if not previous.is_empty():
				view.flash_new()   # 0.19.0 (114): a carta que acabou de entrar brilha 2 s
	_apply_selection()
	_refresh_preview()
	_refresh_zone_buttons()

func _refresh_board() -> void:
	if _animating:
		return
	var creatures := battle.creatures()
	var live := board_box.get_children().filter(func(c): return not c.is_queued_for_deletion())
	var same := _board_views.size() == creatures.size() and live.size() == creatures.size()
	if same:
		var i := 0
		for card in creatures:
			if not _board_views.has(card.uid) or live[i] != _board_views[card.uid]:
				same = false
				break
			i += 1
	if same:
		for card in creatures:
			if _alive(_board_views[card.uid]):
				(_board_views[card.uid] as CardView).refresh()
				(_board_views[card.uid] as CardView).set_mirrored(card.uid == battle.mirror_uid)
				(_board_views[card.uid] as CardView).set_jailed(card.uid == battle.jailed_uid)
				(_board_views[card.uid] as CardView).set_equipment(_equip_of(card))   # 0.18.0 (19)
		_refresh_overlay()
		_s4_marks()
		_sync_arena_floor.call_deferred()
		return
	for child in board_box.get_children():
		board_box.remove_child(child)
		child.queue_free()
	_board_views.clear()
	for card in creatures:
		var view: CardView = CARD_VIEW.instantiate()
		board_box.add_child(view)
		view.setup(card)
		view.set_mirrored(card.uid == battle.mirror_uid)
		view.set_jailed(card.uid == battle.jailed_uid)
		view.set_equipment(_equip_of(card))   # 0.18.0 (19): a medalha do equipamento
		view.long_pressed.connect(_open_creature_menu)   # 0.19.0 (16): ver, mover para a ponta, equipar, ameaças
		if bool(Settings.opt("move_buttons")) or bool(Settings.opt("no_longpress")):
			view.pressed.connect(_open_creature_menu)   # 0.19.0 (283, 284): o menu com um toque (◀ ▶ sem arrastar)
		else:
			view.pressed.connect(_on_card_long_pressed)   # no tabuleiro um toque simples também abre em grande
		view.keyword_taps = true   # 0.13.0: tocar no ícone de uma palavra-chave explica-a
		view.keyword_tapped.connect(_on_keyword_tapped)
		view.draggable = true
		view.drag_started.connect(_on_board_drag_started)
		view.drag_moved.connect(_on_board_drag_moved)
		view.drag_ended.connect(_on_board_drag_ended)
		_board_views[card.uid] = view
	_refresh_overlay()
	_s4_marks()
	_sync_arena_floor.call_deferred()

func _refresh_spells() -> void:
	if _animating:
		return
	for chip in _spell_chips.values():
		if is_instance_valid(chip):
			spell_strip.remove_child(chip)
			chip.queue_free()
	_spell_chips.clear()
	spell_hint.visible = _strip_empty()
	_refresh_strip_look()
	var at := spell_hint.get_index() + 1
	for sp in battle.spells_this_turn:
		var chip := _make_chip(sp)
		spell_strip.add_child(chip)
		spell_strip.move_child(chip, at)
		at += 1
		_spell_chips[sp.uid] = chip
	_refresh_ench_sep()
	_fit_chips()

const CHIP_MIN_W := 44.0
const CHIP_MAX_W := 180.0

func _make_chip(sp: CardInstance, text_override: String = "", equip: bool = false, on_tap: Callable = Callable()) -> Control:
	var mini := _make_mini(sp, text_override != "", equip, on_tap)   # 0.16.0 (V33): mini-carta com a ilustração
	if mini != null:
		return mini
	var chip := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = CardView.COLORS.get(sp.data.primary_color(), CardView.COLORS.colorless)
	style.set_corner_radius_all(8)
	style.set_content_margin_all(6)
	chip.add_theme_stylebox_override("panel", style)
	chip.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	var label := Label.new()
	if text_override != "":
		label.text = text_override
	else:
		label.text = ("↺ " if sp.zone == CardInstance.Zone.EXILE else "") + ("%s  %d⚔" % [sp.data.display_name(), sp.data.power] if sp.data.power > 0 else sp.data.display_name())
	label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	label.add_theme_font_size_override("font_size", 15)
	label.add_theme_color_override("font_color", Color(0.08, 0.08, 0.1) if style.bg_color.get_luminance() > 0.45 else Color.WHITE)
	# Largura natural do texto (as fichas encolhem só quando não cabem todas — ver _fit_chips).
	var font := label.get_theme_font("font")
	var natural := font.get_string_size(label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, 15).x if font != null else label.text.length() * 8.0
	label.set_meta("natural_w", ceilf(natural) + 2.0)
	label.custom_minimum_size.x = clampf(ceilf(natural) + 2.0, CHIP_MIN_W, CHIP_MAX_W)
	chip.tooltip_text = sp.data.display_name()
	chip.add_child(label)
	return chip

## Reparte a largura da faixa pelas fichas de feitiços e encantamentos: cada uma mostra o nome
## inteiro (até CHIP_MAX_W) e só encolhe, com reticências, quando não cabem todas.
func _fit_chips() -> void:
	var labels: Array[Label] = []
	for dict in [_spell_chips, _ench_chips, _equip_chips]:
		for chip in dict.values():
			if is_instance_valid(chip) and chip.get_child_count() > 0:
				labels.append(chip.get_child(0) as Label)
	if labels.is_empty():
		return
	var room := spell_strip.size.x if spell_strip.size.x > 200.0 else 560.0
	if _chain_meter != null and _chain_meter.visible:
		room -= _chain_meter.get_combined_minimum_size().x + 16.0
	var per := room / float(labels.size()) - 8.0 - 12.0
	for label in labels:
		var natural: float = float(label.get_meta("natural_w", CHIP_MAX_W))
		label.custom_minimum_size.x = clampf(minf(natural, per), CHIP_MIN_W, CHIP_MAX_W)

## Mostra o que o ataque faria se atacasses agora.
func _refresh_preview() -> void:
	if _animating:
		return
	_what_if = false
	var lethal := _show_calc(battle.preview_attack(), false)
	_refresh_counter(lethal)
	_refresh_overlay()
	_check_no_plays()
	_refresh_lethal_glow(_last_preview_total)
	_refresh_synergy_lines()
	_s4_after_preview()

## Põe um ataque (previsto) no cálculo: formações, Poder × Mult, total, chamas, barra do inimigo e o
## botão ATACAR. what_if = true (0.13.0): é o ataque com a carta que estás a arrastar para a Arena
## (total a verde); ao largar ou sair da zona volta o de agora. Devolve se é letal.
func _show_calc(c: Cascade, what_if: bool) -> bool:
	if not what_if:
		_s4_cascade = c   # 0.19.0 (secção 4): o ataque previsto para as marcas, as relíquias e a barra
	if c.is_empty():
		formation_label.text = tr("Sem atacantes")
	elif c.formations.is_empty():
		formation_label.text = tr("Ataque")
	else:
		var names: Array[String] = []
		for i in c.formations.size():
			var lvl: int = c.formation_levels[i] if i < c.formation_levels.size() else 0
			names.append(tr(c.formations[i]) + ((" (%s %d)" % [tr("nv"), lvl]) if lvl > 0 else ""))
		formation_label.text = " · ".join(PackedStringArray(names))
	var extra_names: Array[String] = []
	for st in c.steps:
		if (st.source_kind == "tribe" or st.source_kind == "seal_set") and not (st.source_name in extra_names):
			extra_names.append(st.source_name)
	if not extra_names.is_empty() and not c.is_empty():
		formation_label.text += "  ·  " + " · ".join(PackedStringArray(extra_names))
	if what_if:
		formation_label.text = "▲ " + tr("Com esta carta") + ("  ·  " + formation_label.text if not c.formations.is_empty() else "")
	power_label.text = _num(c.power)
	mult_label.text = Cascade.fmt_mult(c.mult)
	var net := c.net_total()
	_set_total(_num(net))
	total_label.add_theme_color_override("font_color", Color(0.55, 1.0, 0.62) if what_if else Color(1.0, 0.92, 0.6))
	_last_preview_total = net
	_fire_target = _fire_for(net)
	_refresh_chain_meter()
	_refresh_ritual_glow()
	var lethal := net > 0 and net >= battle.hp_left()   # na Dupla, só com os dois no chão (senão o outro contra-ataca)
	# 0.18.0: o escudo em curto (◈ −X); o texto encolhe e nunca alarga a coluna (antes, com o escudo, o botão
	# chegava aos 380 px e empurrava o resto do ecrã).
	var shield_txt := ("  ·  ◈ −" + Cascade.fmt_int(c.shield)) if c.shield > 0 and c.total() > 0 else ""
	if lethal:
		_set_attack_text(tr("ATACAR") + "   " + _num(net) + "  ·  " + tr("LETAL"))
		end_turn_btn.add_theme_stylebox_override("normal", _lethal_style)
	else:
		_set_attack_text((tr("ATACAR") + "   " + _num(net) + shield_txt) if c.total() > 0 else tr("ATACAR"))
		end_turn_btn.add_theme_stylebox_override("normal", _attack_style)
	_refresh_hp_bars()
	return lethal

## 0.18.0: o texto do ATACAR encolhe com o comprimento e corta em «…» em vez de alargar a coluna.
## 0.20.0 (B7): depois, encolhe de 1 em 1 (até 13) enquanto o texto não couber (o inglês e o «toca outra vez»).
func _set_attack_text(t: String) -> void:
	end_turn_btn.text = t
	var n := t.length()
	var fs := 24 if n <= 16 else (20 if n <= 22 else 17)
	var sb := end_turn_btn.get_theme_stylebox("normal")
	var room := (end_turn_btn.size.x if end_turn_btn.size.x > 100.0 else 312.0) - sb.get_margin(SIDE_LEFT) - sb.get_margin(SIDE_RIGHT)
	var font := end_turn_btn.get_theme_font("font")
	while fs > 13 and font.get_string_size(t, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x > room:
		fs -= 1
	end_turn_btn.add_theme_font_size_override("font_size", fs)

## Total do ataque: a letra encolhe com números muito grandes (para nunca empurrar o ecrã).
func _set_total(text: String) -> void:
	total_label.text = text
	var n := text.length()
	total_label.add_theme_font_size_override("font_size", 46 if n <= 9 else (38 if n <= 12 else 30))

## Barra do inimigo: a parte clara (fantasma) é o dano do ataque atual.
func _refresh_hp_bars() -> void:
	var hp := int(battle.enemy.hp)
	enemy_hp_ghost.max_value = battle.enemy.max_hp
	enemy_hp_bar.max_value = battle.enemy.max_hp
	enemy_hp_ghost.value = hp
	if _animating:
		return
	enemy_hp_bar.value = max(0, hp - _last_preview_total)

## Contra-ataque previsto e intenção do inimigo para este turno.
func _refresh_counter(lethal: bool) -> void:
	if lethal:
		_s4_plan = {}
		counter_label.text = tr("O ataque é letal: não há contra-ataque.")
		counter_label.add_theme_color_override("font_color", Color(0.45, 0.9, 0.55))
		_refresh_intent(true, {})
		return
	counter_label.add_theme_color_override("font_color", Color(1, 0.6, 0.55))
	var p := battle.counter_plan()
	_s4_plan = p   # 0.19.0 (128)
	_refresh_intent(false, p)
	_refresh_charge_look()
	var parts: Array[String] = []
	var dmg := int(p["damage"])
	var b: CardInstance = p["blocker"]
	var chosen := int(p.get("chosen", BattleManager.BLOCK_AUTO))
	if battle.charge_mult > 1.0 and dmg > 0:
		parts.append(tr("Golpe carregado (×%s)!") % _fmt_mult(battle.charge_mult))
	if dmg <= 0 and battle.ward and int(battle.enemy.get("attack", 0)) > 0:
		parts.append(tr("Pergaminho de Proteção: o contra-ataque deste turno não te toca."))
	elif dmg <= 0:
		parts.append(tr("Não ataca."))
	elif b != null and bool(p.get("vigilant", false)):
		parts.append(tr("Ataca %d: %s bloqueia sem sofrer dano (Vigilância).") % [dmg, b.data.display_name()])
	elif b != null and bool(p["survives"]):
		parts.append(tr("Ataca %d: %s bloqueia e sobrevive.") % [dmg, b.data.display_name()])
	elif b != null:
		parts.append(tr("Ataca %d: %s bloqueia e morre.") % [dmg, b.data.display_name()])
		if int(p["player_damage"]) > 0:
			parts.append(tr("O resto passa: levas %d.") % int(p["player_damage"]))
	elif (p["deaths"] as Array).is_empty():
		if chosen == BattleManager.BLOCK_NONE:
			parts.append(tr("Ataca %d: escolheste não bloquear, levas %d.") % [dmg, int(p["player_damage"])])
		else:
			parts.append(tr("Ataca %d: ninguém bloqueia, levas tu %d.") % [dmg, int(p["player_damage"])])
	else:
		parts.append(tr("Ataca %d (letal): %d criatura(s) sacrificam-se, levas %d.") % [dmg, (p["deaths"] as Array).size(), int(p["player_damage"])])
	if dmg > 0 and not battle.board.is_empty():
		parts.append(tr("(Toca para escolher quem bloqueia.)") if chosen == BattleManager.BLOCK_AUTO else tr("(Escolheste quem bloqueia; toca para mudar.)"))
	var intents: Array[String] = []
	for a in battle.enemy_intent(battle.turn):
		var action := String(a.get("action", ""))
		var tmpl: String = ABILITY_INTENT.get(action, "")
		if tmpl == "":
			continue
		if action == "charge_attack":
			intents.append(tr(tmpl) % _fmt_mult(1.0 + float(a.get("value", 100)) / 100.0))
		else:
			intents.append(tr(tmpl) % int(a.get("value", 0)) if tmpl.contains("%d") else tr(tmpl))
	if not intents.is_empty():
		parts.append(tr("Depois: ") + "; ".join(PackedStringArray(intents)) + ".")
	if battle.woven_relic != "":   # 0.17.0 Tecelã de Espelhos
		parts.append(tr("Copiou %s: cada vez que dispara no teu ataque, o contra-ataque dela sobe 1.") % tr(String(CardDB.relics.get(battle.woven_relic, {}).get("name", ""))))
	counter_label.text = " ".join(PackedStringArray(parts))

## 0.13.0: o retrato pulsa a laranja quando o golpe deste turno está carregado ou o inimigo vai carregar.
func _refresh_charge_look() -> void:
	if _portrait == null or not _alive(_portrait):
		return
	var charging := battle.charge_mult > 1.0 and not battle.finished
	for a in battle.enemy_intent(battle.turn):
		if String(a.get("action", "")) == "charge_attack" and not battle.silenced:
			charging = true
	if _portrait.charging != charging:
		_portrait.charging = charging
		if charging and battle.charge_mult > 1.0:
			_tip("charge")

## ×2, ×1.5 (sem casas a mais).
static func _fmt_mult(m: float) -> String:
	return str(int(m)) if is_equal_approx(m, roundf(m)) else ("%.1f" % m)

# --- Intenção do inimigo em ícones (o texto completo abre ao tocar) ---

func _make_intent_row() -> void:
	var vbox: Control = counter_label.get_parent()
	_intent_row = HBoxContainer.new()
	_intent_row.add_theme_constant_override("separation", 6)
	_intent_row.custom_minimum_size.y = 40
	_intent_row.mouse_filter = Control.MOUSE_FILTER_STOP
	vbox.add_child(_intent_row)
	vbox.move_child(_intent_row, counter_label.get_index())
	counter_label.visible = false
	_intent_row.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed and not SceneRouter.has_overlay():
			_open_intent())

func _intent_chip(parts: Array, bg: Color, big: bool = false) -> PanelContainer:
	var chip := PanelContainer.new()
	chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if big:   # 0.16.0 (V29): por cima do retrato, maior e mais opaco
		chip.add_theme_stylebox_override("panel", UiKit.flat(Color(bg.darkened(0.2), 0.96), 12, Color(1, 1, 1, 0.22), 1, 7))
	else:
		chip.add_theme_stylebox_override("panel", UiKit.flat(bg, 8, Color(0, 0, 0, 0), 0, 6))
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 3)
	chip.add_child(row)
	for part in parts:
		if String(part[0]) != "":
			var icon := CardIcon.new(String(part[0]), part[1], 26.0 if big else 18.0)
			icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			row.add_child(icon)
		if String(part[2]) != "":
			var l := UiKit.label(String(part[2]), 21 if big else 17, Color.WHITE)
			if big:
				UiKit.outline_for(l, Color.WHITE, 4)
			l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
			row.add_child(l)
	return chip

func _refresh_intent(lethal: bool, p: Dictionary) -> void:
	if _intent_row == null:
		return
	var b: CardInstance = p.get("blocker")
	var og := overkill_preview(_last_preview_total) if lethal else 0
	var sig := ("L%d" % og) if lethal else ("%d|%d|" % [int(battle.ritual.get("turns", 0)), int(battle.enemy.get("hp", 0))]) + "%d|%d|%s|%s|%d|%d|%s|%s|%d" % [int(p.get("damage", 0)), b.uid if b != null else -9, str(p.get("survives", false)),
		str(p.get("vigilant", false)), (p.get("deaths", []) as Array).size(), int(p.get("player_damage", 0)), str(battle.enemy_intent(battle.turn)),
		str(battle.charge_mult), int(p.get("chosen", -1))]
	if sig == _intent_sig and _intent_row.get_child_count() > 0:
		return
	_intent_sig = sig
	for c in _intent_row.get_children():
		_intent_row.remove_child(c)
		c.queue_free()
	if lethal:
		var lparts: Array = [["check", Color(0.45, 0.95, 0.55), tr("Letal")]]
		if og > 0:   # 0.19.0 (108): o ouro do Excesso, já antes de atacar
			lparts.append(["coin", UiKit.COIN, tr("+%d ouro de excesso") % og])
		_intent_row.add_child(_intent_chip(lparts, Color(0.12, 0.3, 0.16), true))
		return
	var dmg := int(p.get("damage", 0))
	var chosen := int(p.get("chosen", BattleManager.BLOCK_AUTO))
	if dmg <= 0:
		_intent_row.add_child(_intent_chip([["shield", Color(0.7, 0.8, 1.0), tr("Não ataca")]], Color(0.16, 0.18, 0.28), true))
	else:
		var parts: Array = []
		if battle.charge_mult > 1.0:   # 0.13.0 golpe carregado
			parts.append(["instant", Color(1.0, 0.62, 0.2), "×" + _fmt_mult(battle.charge_mult)])
		parts.append(["swords", Color(1.0, 0.55, 0.5), str(dmg)])
		if b != null:
			parts.append(["shield", UiKit.GOLD if chosen >= 0 else Color(0.7, 0.85, 1.0), ""])
			if not bool(p.get("survives", false)):
				parts.append(["skull", Color(0.92, 0.92, 0.92), ""])
		elif not (p.get("deaths", []) as Array).is_empty():
			parts.append(["skull", Color(0.92, 0.92, 0.92), str((p["deaths"] as Array).size())])
		if int(p.get("player_damage", 0)) > 0:
			parts.append(["heart", Color(0.95, 0.35, 0.4), "−%d" % int(p["player_damage"])])
		if not battle.board.is_empty():
			parts.append(["", Color.WHITE, "›"])   # toca para escolher quem bloqueia
		var bg := Color(0.42, 0.2, 0.06) if battle.charge_mult > 1.0 else Color(0.3, 0.12, 0.14)
		_intent_row.add_child(_intent_chip(parts, bg, true))
	for a in battle.enemy_intent(battle.turn):
		var action := String(a.get("action", ""))
		var info: Array = INTENT_ICONS.get(action, [])
		if info.is_empty():
			continue
		var txt := str(int(a.get("value", 0))) if info[2] else ""
		if action == "charge_attack":
			txt = "×" + _fmt_mult(1.0 + float(a.get("value", 100)) / 100.0)
		_intent_row.add_child(_intent_chip([[info[0], info[1], txt]], Color(0.2, 0.16, 0.28), true))
	_intent_extra_chips()

# --- Detalhe da cascata (tocar no cálculo) ---

func _make_calc_tap() -> void:
	var calc: Control = power_pill.get_parent()
	calc.mouse_filter = Control.MOUSE_FILTER_STOP
	power_pill.mouse_filter = Control.MOUSE_FILTER_PASS
	mult_pill.mouse_filter = Control.MOUSE_FILTER_PASS
	calc.tooltip_text = tr("Toca para ver o detalhe do ataque")
	calc.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed:
			_open_breakdown())

func _open_breakdown() -> void:
	if _animating or SceneRouter.has_overlay():
		return
	var c := battle.preview_attack()
	var title := tr("Ataque previsto: %s") % Cascade.fmt_int(c.net_total())
	if c.is_empty():
		if _last_cascade == null or _last_cascade.is_empty():
			return
		c = _last_cascade
		title = tr("Último ataque: %s") % Cascade.fmt_int(c.net_total())
	Sfx.select()
	CascadeBreakdown.open(c, title, _replay_last_attack if _last_cascade != null and not _last_cascade.is_empty() else Callable())

func _translated(names: Array[String]) -> Array[String]:
	var out: Array[String] = []
	for n in names:
		out.append(tr(n))
	return out

func _refresh_discard_button() -> void:
	discard_btn.text = tr("CANALIZAR (%d)") % battle.discards_left
	discard_btn.disabled = battle.discards_left <= 0 or battle.resolving or battle.finished
	if discard_btn.disabled and _discard_mode:
		discard_btn.button_pressed = false

# --- Handlers ---

func _on_mana_changed(available: int, total: int) -> void:
	_set_mana(available, total)
	if battle.climate == "mana_eclipse" and total >= 5 and battle.turn > 0:   # 0.19.0 (130)
		_climate_notice("eclipse", tr("a mana não passa de 5."))
	_refresh_hand()

func _on_discards_changed(_left: int) -> void:
	_refresh_discard_button()

func _on_turn_started(t: int) -> void:
	if t > 1 and not _resumed:
		# 0.20.0 (B10): o resumo do turno dele fecha antes das linhas que são tuas (modo assistido, mana guardada);
		# o golpe carregado já não o substitui: vai para a fila, a seguir ao resumo.
		_show_enemy_recap()
		if battle.charge_mult > 1.0:
			_warn(tr("%s carregou um golpe: este turno ataca com ×%s!") % [tr(battle.enemy.name), _fmt_mult(battle.charge_mult)], Color(1.0, 0.6, 0.2), 3.2, false, true)
	turn_label.text = _turn_text()
	_refresh_pips()
	if battle.objective == "escape":   # 0.18.0: «Fuga 2/4»
		_refresh_defense()
	_refresh_info_row()
	end_turn_btn.disabled = false
	if t != _undo_turn:
		_undo_stack.clear()
		_undo_turn = t
	_assist_turn_snapshot(t)   # 0.19.0 (279, 280)
	_refresh_discard_button()
	_refresh_all()
	if not battle.finished and not battle.puzzle:
		GameState.save_run(battle.to_dict(), "battle")   # gravação automática a cada turno
	if t > 1 and not _resumed:
		if _is_last_turn():   # 0.20.0 (B7)
			_show_last_turn_banner()
		else:
			_show_banner(tr("TURNO %d") % t, 0.6, true)
		# 0.13.0: mana guardada do turno anterior.
		if battle.last_mana_saved > 0:
			_log(tr("Mana guardada: +%d neste turno.") % battle.last_mana_saved)
			if _mana_pips != null:
				_mana_pips.flash_saved(battle.last_mana_saved)
	if not _resumed:
		_climate_turn_notices(t)   # 0.19.0 (130)
	if battle.board.size() >= 2:
		_tip("order")
	_refresh_grid_btn()
	if _queued_tap_uid >= 0:
		_run_queued_tap.call_deferred()

func _on_enemy_hp(current: int, max_hp: int) -> void:
	enemy_hp_bar.max_value = max_hp
	enemy_hp_ghost.max_value = max_hp
	if _hp_tween != null and _hp_tween.is_valid():
		_hp_tween.kill()
	_hp_tween = create_tween().set_parallel(true)
	_hp_tween.tween_property(enemy_hp_ghost, "value", float(current), _d(0.45)).set_ease(Tween.EASE_OUT)
	_hp_tween.tween_property(enemy_hp_bar, "value", float(current if _animating else max(0, current - _last_preview_total)), _d(0.45)).set_ease(Tween.EASE_OUT)
	enemy_hp_label.text = "%s / %s" % [_num(current), _num(max_hp)]
	if GameState.puzzle_id == "training":
		enemy_hp_label.text = "∞"
	_refresh_enemy_art()

func _on_spell_cast(_card: CardInstance) -> void:
	_refresh_spells()

func _on_creature_died(card: CardInstance) -> void:
	# 0.12.0: o som da morte toca no Sfx (ouve o creature_died)
	if card.temp_copy:   # 0.15.0 Selo do Espelho
		_log(tr("A cópia de %s desaparece.") % tr(card.data.name))
	else:
		_log(tr("%s morreu.") % tr(card.data.name))
	if _board_views.has(card.uid) and is_instance_valid(_board_views[card.uid]):
		_animate_death(_board_views[card.uid])
	_refresh_board()
	_refresh_preview()
	_refresh_zone_buttons()

func _on_creature_blocked(card: CardInstance, amount: int) -> void:
	_log(tr("%s bloqueou %d de dano.") % [tr(card.data.name), amount])
	if _board_views.has(card.uid):
		var view: CardView = _board_views[card.uid]
		if is_instance_valid(view):
			view.refresh()
			_flash(view, Color(1.6, 1.6, 1.6))
			_bump(view, 0.9)

func _on_card_discarded(card: CardInstance) -> void:
	_log(tr("Canalizaste %s.") % tr(card.data.name))
	_refresh_zone_buttons()

func _on_card_grew(card: CardInstance, amount: int) -> void:
	var view: Control = _board_views.get(card.uid, _hand_views.get(card.uid))
	if view != null and is_instance_valid(view):
		if view is CardView:
			view.refresh()
		_pop(view, tr("Cresce +%d") % amount, COLOR_GROW)
	_refresh_preview()

func _on_hand_card_pressed(card: CardInstance) -> void:
	if battle.resolving or battle.finished:
		return
	if battle.pending_bottom > 0:
		if battle.bottom_card(card):
			Sfx.hit()
			if battle.pending_bottom > 0:
				_log(tr("Escolhe mais %d carta(s) para o fundo do grimório.") % battle.pending_bottom)
			else:
				_log(tr("Mão nova com %d cartas.") % battle.deck.hand.size() + " " + _play_help(false))
				GameState.save_run(battle.to_dict(), "battle")
			_refresh_all()
		return
	if _discard_mode:
		_channel_card(card)
		return
	var from_rect := Rect2()
	if _hand_views.has(card.uid) and is_instance_valid(_hand_views[card.uid]):
		from_rect = (_hand_views[card.uid] as Control).get_global_rect()
	if battle.can_play(card):
		_set_selection(-1)
		var kick := false
		if battle.can_kick(card):
			var choice := await _ask_kicker(card)
			if choice == "":
				return
			kick = choice == "kick"
			if not battle.can_play(card):
				return
		var equip_uid := -1   # 0.18.0 (19): a criatura que fica com o equipamento
		if card.data.is_equipment():
			equip_uid = _equip_drop_uid
			_equip_drop_uid = -1
			if equip_uid < 0 and battle.equip_targets(card).size() >= 2:
				var picked = await _ask_equip_target(card)
				if not (picked is int) or int(picked) < 0 or not battle.can_play(card):
					return
				equip_uid = int(picked)
		_push_undo()
		battle.play(card, kick, equip_uid)
		Sfx.select()
		Settings.haptic("play")   # 0.19.0 (30)
		hand_box.clear_hover()
		_refresh_all()
		_animate_play(card, from_rect)

## Canaliza uma carta da mão (com o aviso das raras): o modo CANALIZAR e, desde a 0.19.0 (1), largar a carta
## arrastada em cima do botão CANALIZAR.
func _channel_card(card: CardInstance) -> void:
	if not battle.can_discard(card):
		Sfx.deny()
		return
	if Settings.warn_rare and (card.data.rarity == "rare" or card.data.rarity == "mythic") and not battle.puzzle:
		var go_on := await _ask(tr("Canalizar uma rara?"), tr("%s é uma carta rara. Canalizá-la manda-a para o cemitério.") % card.data.display_name(), tr("CANALIZAR"))
		if go_on == "never":
			Settings.warn_rare = false
			Settings.save_settings()
		elif go_on != "yes":
			return
		if not battle.can_discard(card):
			return
	_push_undo()
	battle.discard(card)   # o som de canalizar toca no Sfx (card_discarded)
	Settings.haptic("play")
	discard_btn.button_pressed = false   # desliga o modo (toggled → _on_discard_toggled)
	_refresh_all()

## 0.12.1: um toque numa carta da mão escolhe-a (sobe, contorno dourado e "JOGAR"); outro toque na mesma
## joga-a. Também se joga arrastando-a para cima, até à Arena. Segurar abre-a em grande. Canalizar, o fundo
## do Mulligan e a opção "1 toque" (Configurações) continuam a jogar/escolher com um toque só.
func _on_hand_card_tapped(card: CardInstance) -> void:
	if battle.finished:
		return
	if battle.resolving:
		_queue_tap(card)   # 0.19.0 (6): acontece quando o turno voltar, em vez de se perder
		return
	if battle.pending_bottom > 0 or _discard_mode or Settings.play_taps == 1 or _selected_uid == card.uid:
		_set_selection(-1)
		_on_hand_card_pressed(card)
		return
	_set_selection(card.uid)
	if battle.can_play(card):
		Sfx.select()
		var short := battle.effects.cost_of(card) - battle.mana_available
		if short > 0 and card.data.phyrexian > 0:   # 0.15.0 Mana de Sangue: o que falta paga-se com vida
			_hint_line(tr("%s: toca outra vez para a jogar — pagas %d de vida pelo Mana de Sangue.") % [card.data.display_name(), short * battle.phyrexian_life_cost()])
		else:
			_hint_line(tr("%s: toca outra vez para a jogar (ou arrasta-a para cima).") % card.data.display_name())
	else:
		Sfx.deny()
		_hint_line(tr("Agora não dá para jogar %s.") % card.data.display_name())
		_warn(_block_reason_text(card), Color(0.95, 0.45, 0.4), 2.6, true)

## 0.13.0: porque é que a carta não se joga agora (com os números da mana).
func _block_reason_text(card: CardInstance) -> String:
	var why := battle.play_block_reason(card)
	if why == "Falta mana.":
		if card.data.phyrexian > 0:   # 0.15.0: nem com vida chega (o Mana de Sangue nunca usa a tua última vida)
			return tr("Falta mana: %s custa %d e tens %d (mais %d de Mana de Sangue, com vida).") % [card.data.display_name(), battle.effects.cost_of(card), battle.mana_available, battle.phyrexian_payable(card)]
		return tr("Falta mana: %s custa %d e tens %d.") % [card.data.display_name(), battle.effects.cost_of(card), battle.mana_available]
	return tr(why)

## Dica na linha de texto sem a guardar no histórico (some quando a escolha acaba).
func _hint_line(text: String) -> void:
	log_label.text = text
	log_label.modulate = Color(1, 0.85, 0.5)
	create_tween().tween_property(log_label, "modulate", Color.WHITE, 0.8)
	_sel_hint = true

## Como se joga uma carta (muda com a opção "Jogar uma carta" das Configurações).
func _play_help(mulligan: bool) -> String:
	if Settings.play_taps == 1:
		return tr("Toca numa carta para a jogar — ou faz Mulligan.") if mulligan else tr("Toca numa carta para a jogar.")
	return tr("Toca numa carta para a escolher e outra vez para a jogar — ou faz Mulligan.") if mulligan else tr("Toca numa carta para a escolher e outra vez para a jogar.")

func _set_selection(uid: int) -> void:
	if _selected_uid == uid:
		return
	_selected_uid = uid
	if uid < 0 and _sel_hint:
		_sel_hint = false
		log_label.text = _last_log
	_apply_selection()

## Contorno e "JOGAR" na carta escolhida; na mão ela fica levantada.
func _apply_selection() -> void:
	if _selected_uid >= 0 and not _hand_views.has(_selected_uid):
		_selected_uid = -1
	var sel: Control = null
	for uid in _hand_views:
		var v: CardView = _hand_views[uid]
		if not _alive(v):
			continue
		var on := int(uid) == _selected_uid
		v.set_selected(on, on and battle.can_play(v.card))
		if on:
			sel = v
	hand_box.set_selected(sel)
	_refresh_synergy_lines.call_deferred()
	_place_zoom_btn.call_deferred(sel)   # 0.19.0 (284)

## 0.19.0 (284): sem toques longos obrigatórios — a carta escolhida da mão ganha um botão VER (o que o toque
## longo fazia). Com «Sem toques longos» ligado.
var _zoom_btn: Button

func _place_zoom_btn(sel: Control) -> void:
	var on := bool(Settings.opt("no_longpress")) and sel != null and _alive(sel) and sel is CardView
	if not on:
		if _zoom_btn != null and _alive(_zoom_btn):
			_zoom_btn.visible = false
		return
	if _zoom_btn == null or not _alive(_zoom_btn):
		_zoom_btn = UiKit.button(tr("VER"), 48, 16, UiKit.BG_LIGHT, UiKit.GOLD)
		_zoom_btn.name = "ZoomSelected"
		_zoom_btn.custom_minimum_size.x = 96
		_zoom_btn.top_level = true
		_zoom_btn.z_index = 40
		_zoom_btn.pressed.connect(func():
			var v := _hand_views.get(_selected_uid) as CardView
			if v != null and _alive(v):
				Sfx.select()
				CardZoom.show_card(v.card))
		add_child(_zoom_btn)
	var r := sel.get_global_rect()
	_zoom_btn.visible = true
	_zoom_btn.global_position = Vector2(r.position.x + r.size.x / 2.0 - 48.0, maxf(4.0, r.position.y - 56.0))

## Há uma carta da mão (ou o "JOGAR" da escolhida) neste ponto do ecrã?
func _hand_card_at(pos: Vector2) -> bool:
	for v in _hand_views.values():
		if not _alive(v):
			continue
		var r := (v as Control).get_global_rect()
		if (v as CardView).is_selected():
			r = r.grow_individual(0, 34, 0, 0)
		if r.grow(4).has_point(pos):
			return true
	return false

## Arrastar uma carta da mão: fica a flutuar (maior) por cima do dedo; ao passar pelas outras muda de
## lugar (os Terrenos ficam no grupo deles, à direita); largada lá em cima, na Arena, é jogada.
func _on_hand_drag_started(card: CardInstance, pos: Vector2) -> void:
	if battle.resolving or battle.finished or _drag_ghost != null or _animating:
		return
	var view: Control = _hand_views.get(card.uid)
	if not _alive(view):
		return
	var top := SceneRouter.top_overlay()
	if top is CardZoom:
		(top as CardZoom).close()   # segurou (abriu em grande) e depois arrastou
	elif SceneRouter.has_overlay() or _alive(_modal):
		return
	_set_selection(-1)
	_hand_drag_card = card
	_drag_view = view
	_play_zone = false
	_discard_zone = false
	_drag_samples = [[Time.get_ticks_msec(), pos]]
	_drag_start_y = pos.y
	view.modulate.a = 0.3
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = view.size
	ghost.pivot_offset = ghost.size / 2.0
	ghost.scale = Vector2(1.15, 1.15)
	ghost.z_index = 45
	ghost.global_position = _hand_ghost_pos(pos, ghost)
	_drag_ghost = ghost
	_drag_last_x = pos.x
	_drag_shadow = Panel.new()
	_drag_shadow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := StyleBoxFlat.new()
	sh.bg_color = Color(0, 0, 0, 0.35)
	sh.set_corner_radius_all(14)
	sh.shadow_color = Color(0, 0, 0, 0.45)
	sh.shadow_size = 14
	_drag_shadow.add_theme_stylebox_override("panel", sh)
	_drag_shadow.size = view.size * 1.15
	_drag_shadow.z_index = 44
	add_child(_drag_shadow)
	_drag_shadow.global_position = ghost.global_position + Vector2(10, 14)
	Settings.haptic("select")
	Sfx.select()
	_show_drop_zones(card)

## A carta flutua um pouco acima do dedo (o dedo não a tapa).
func _hand_ghost_pos(pos: Vector2, ghost: Control) -> Vector2:
	return pos - ghost.size / 2.0 - Vector2(0, ghost.size.y * 0.4)

func _on_hand_drag_moved(card: CardInstance, pos: Vector2) -> void:
	if _drag_ghost == null or _hand_drag_card != card:
		return
	_drag_ghost.global_position = _hand_ghost_pos(pos, _drag_ghost)
	_tilt_ghost(pos)
	if _alive(_drag_shadow):
		_drag_shadow.global_position = _drag_ghost.global_position + Vector2(10, 14)
	_drag_samples.append([Time.get_ticks_msec(), pos])
	while _drag_samples.size() > 2 and Time.get_ticks_msec() - int(_drag_samples[0][0]) > 120:
		_drag_samples.pop_front()
	# 0.19.0 (1): por cima do CANALIZAR, larga-se para canalizar.
	var over_discard := _over_discard(pos, card)
	if over_discard != _discard_zone:
		_discard_zone = over_discard
		(_drag_ghost as CardView).modulate = DISCARD_TINT if over_discard else Color.WHITE
		discard_btn.modulate = Color(1.35, 1.2, 1.6) if over_discard else Color.WHITE
		if over_discard:
			Settings.haptic("select")
		_update_drop_zones()
	var zone := _in_play_zone(pos) and not over_discard
	if zone != _play_zone:
		_play_zone = zone
		_equip_hover_uid = -1
		_mark_equip_hover(-1)
		(_drag_ghost as CardView).set_selected(zone, _drag_playable(card))
		if zone:
			Settings.haptic("select")
			if _drag_playable(card):
				_show_what_if(card)   # 0.13.0: o cálculo mostra o ataque com esta carta
		elif _what_if:
			_refresh_preview()
		_sync_arena_floor()
		_update_drop_zones()
	if zone and card.data.is_equipment() and _drag_playable(card):   # 0.18.0: por cima de que criatura?
		var over := _equip_target_at(card, pos)
		if over != _equip_hover_uid:
			_equip_hover_uid = over
			_mark_equip_hover(over)
			_show_what_if(card, over)
	if zone or not _alive(_drag_view):
		return
	var index := _hand_slot_for_x(pos.x, _drag_view)
	if index >= 0 and index != _drag_view.get_index():
		hand_box.move_child(_drag_view, index)
		_update_fan_gaps()
		Sfx.tick()

func _on_hand_drag_ended(card: CardInstance, _pos: Vector2) -> void:
	if _hand_drag_card != card:
		return
	var channel := _discard_zone and _over_discard(_pos, card)
	var play := _play_zone and _drag_playable(card) and not channel
	if not play and not channel and _is_flick_up(_pos) and _drag_playable(card):
		play = true   # 0.19.0 (2): um gesto rápido para cima joga a carta sem a levar até à Arena
	_equip_drop_uid = _equip_target_at(card, _pos) if play and card.data.is_equipment() else -1   # 0.18.0
	_equip_hover_uid = -1
	_mark_equip_hover(-1)
	if _drag_ghost != null:
		_drag_ghost.queue_free()
		_drag_ghost = null
	if _alive(_drag_shadow):
		_drag_shadow.queue_free()
	_drag_shadow = null
	if _alive(_drag_view):
		(_drag_view as CardView).playable = (_drag_view as CardView).playable   # repõe a transparência
	_drag_view = null
	_hand_drag_card = null
	_play_zone = false
	_discard_zone = false
	discard_btn.modulate = Color.WHITE
	_hide_drop_zones()
	_sync_arena_floor()
	if _what_if:
		_refresh_preview()
	if channel:
		_commit_hand_order()
		_channel_card(card)
	elif play:
		_on_hand_card_pressed(card)
	else:
		_commit_hand_order()

# --- 0.19.0: arrastar a carta da mão (1, 2, 14) ---
var _discard_zone := false          # a carta arrastada está por cima do CANALIZAR
var _drag_samples: Array = []       # [ms, posição] dos últimos 120 ms do arrasto
var _drag_start_y := 0.0
var _drop_hint: PanelContainer      # 14: o que acontece se largares agora
var _cancel_zone: Panel             # 14: a zona de desistir (a própria mão)
const FLICK_SPEED := 1300.0         # px/s para cima

## A carta arrastada está por cima do botão CANALIZAR (e pode ser canalizada)?
func _over_discard(pos: Vector2, card: CardInstance) -> bool:
	if battle.pending_bottom > 0 or battle.discards_left <= 0 or discard_btn.disabled or not discard_btn.is_visible_in_tree():
		return false
	if not discard_btn.get_global_rect().grow(10.0).has_point(pos):
		return false
	return battle.can_discard(card)

## O dedo largou a carta num gesto rápido para cima (≥ 36 px e ≥ 1300 px/s, mais para cima do que para o lado)?
func _is_flick_up(pos: Vector2) -> bool:
	if _drag_start_y - pos.y < 36.0 or _drag_samples.size() < 2:
		return false
	var a: Array = _drag_samples[0]
	var b: Array = _drag_samples[_drag_samples.size() - 1]
	var dt := float(int(b[0]) - int(a[0])) / 1000.0
	if dt <= 0.0:
		return false
	var v := (Vector2(b[1]) - Vector2(a[1])) / dt
	return v.y <= -FLICK_SPEED and absf(v.y) > absf(v.x) * 1.2

## 14: enquanto arrastas, a mão fica marcada como a zona de desistir e uma etiqueta diz o que acontece ao largar.
func _show_drop_zones(card: CardInstance) -> void:
	_hide_drop_zones()
	_cancel_zone = Panel.new()
	_cancel_zone.name = "CancelZone"
	_cancel_zone.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_cancel_zone.z_index = 40
	_cancel_zone.add_theme_stylebox_override("panel", UiKit.flat(Color(0.05, 0.04, 0.08, 0.35), 16, Color(1, 1, 1, 0.35), 2, 0))
	add_child(_cancel_zone)
	var r := hand_box.get_global_rect()
	_cancel_zone.global_position = r.position + Vector2(PILE_PAD - 6.0, 0)
	_cancel_zone.size = Vector2(maxf(40.0, r.size.x - 2.0 * PILE_PAD + 12.0), r.size.y)
	var x := UiKit.label(tr("✕ Larga aqui para não jogar"), 16, Color(1, 1, 1, 0.75))
	x.name = "CancelText"
	x.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	x.offset_top = -30.0
	x.offset_bottom = -6.0
	x.offset_left = -170.0
	x.offset_right = 170.0
	x.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_cancel_zone.add_child(x)
	_cancel_zone.visible = false
	_drop_hint = PanelContainer.new()
	_drop_hint.name = "DropHint"
	_drop_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_drop_hint.z_index = 46
	_drop_hint.add_theme_stylebox_override("panel", UiKit.flat(Color(0.08, 0.06, 0.12, 0.92), 12, UiKit.GOLD, 2, 8))
	var l := UiKit.label("", 17, UiKit.GOLD)
	l.name = "Text"
	_drop_hint.add_child(l)
	add_child(_drop_hint)
	_drop_hint.set_meta("card", card)
	_update_drop_zones()

func _update_drop_zones() -> void:
	if not _alive(_drop_hint):
		return
	var card = _drop_hint.get_meta("card") if _drop_hint.has_meta("card") else null
	var l := _drop_hint.get_node("Text") as Label
	var text := ""
	var col := UiKit.GOLD
	if _discard_zone:
		text = tr("Larga para canalizar")
		col = DISCARD_TINT
	elif _play_zone:
		if card is CardInstance and _drag_playable(card):
			text = tr("▲ Larga para jogar")
			col = Color(0.55, 0.95, 0.6)
		else:
			text = tr("Agora não dá para a jogar — larga em baixo para desistir")
			col = Color(1.0, 0.6, 0.5)
	else:
		text = tr("Leva para cima para jogar · em CANALIZAR para canalizar")
		col = UiKit.TEXT_DIM
	l.text = text
	l.add_theme_color_override("font_color", col)
	_drop_hint.reset_size()
	var r := hand_box.get_global_rect()
	_drop_hint.global_position = Vector2(r.get_center().x - _drop_hint.size.x / 2.0, r.position.y - _drop_hint.size.y - 8.0)
	if _alive(_cancel_zone):
		_cancel_zone.visible = _play_zone or _discard_zone

func _hide_drop_zones() -> void:
	for n in [_drop_hint, _cancel_zone]:
		if _alive(n):
			(n as Node).queue_free()
	_drop_hint = null
	_cancel_zone = null

## Larga a carta arrastada sem a jogar (dois dedos no ecrã, por exemplo).
func _cancel_hand_drag() -> void:
	if _hand_drag_card == null:
		return
	_play_zone = false
	_discard_zone = false
	_drag_samples.clear()
	_on_hand_drag_ended(_hand_drag_card, Vector2(-9999, -9999))

## Zona de jogar: bem acima da mão (Arena e cálculo). Nunca no modo canalizar nem no fundo do Mulligan.
func _in_play_zone(pos: Vector2) -> bool:
	if _discard_mode or battle.pending_bottom > 0:
		return false
	return pos.y < hand_box.get_global_rect().position.y - 50.0

func _drag_playable(card: CardInstance) -> bool:
	return not _discard_mode and battle.pending_bottom == 0 and battle.can_play(card)

## Lugar na mão para a carta arrastada (pelo x do dedo), sem sair do grupo dela (Terrenos à direita).
func _hand_slot_for_x(x: float, dragged: Control) -> int:
	var kids := hand_box.get_children()
	var index := 0
	var non_lands := 0
	for c in kids:
		var cv := c as CardView
		if cv != null and cv.card != null and not cv.card.data.is_land():
			non_lands += 1
		if c == dragged:
			continue
		var ctl := c as Control
		if ctl != null and x > ctl.global_position.x + ctl.size.x / 2.0:
			index += 1
	var is_land := (dragged as CardView).card.data.is_land()
	var lo := non_lands if is_land else 0
	var hi := kids.size() - 1 if is_land else non_lands - 1
	return clampi(index, lo, maxi(lo, hi))

## O espaço antes do grupo dos Terrenos vai sempre para o primeiro Terreno.
func _update_fan_gaps() -> void:
	var first := true
	for c in hand_box.get_children():
		var cv := c as CardView
		if cv == null or cv.card == null:
			continue
		var land := cv.card.data.is_land()
		cv.set_meta("fan_gap_before", land and first)
		if land:
			first = false
	hand_box.queue_sort()

## A ordem em que a mão ficou passa a ser a da mão (ORDENAR → "A tua ordem").
func _commit_hand_order() -> void:
	var order: Array[CardInstance] = []
	for v in hand_box.get_children():
		var cv := v as CardView
		if cv != null and not cv.is_queued_for_deletion() and cv.card != null and cv.card in battle.deck.hand and not (cv.card in order):
			order.append(cv.card)
	for c in battle.deck.hand:
		if not (c in order):
			order.append(c)
	if order != battle.deck.hand:
		battle.deck.hand.assign(order)
		if Settings.hand_sort != "":
			Settings.hand_sort = ""
			Settings.save_settings()
		if _sort_btn != null:
			_refresh_tool_buttons()
	_refresh_hand()

func _push_undo() -> void:
	_undo_stack.append(battle.snapshot())
	if _undo_stack.size() > 12:
		_undo_stack.pop_front()

func _on_undo() -> void:
	if _undo_stack.is_empty() or battle.resolving or battle.finished:
		return
	var snap: Dictionary = _undo_stack.pop_back()
	discard_btn.button_pressed = false
	_resumed = true   # sem banner "TURNO N"
	var ok := battle.restore_snapshot(snap)
	_resumed = false
	if ok:
		Sfx.hit()
		_log(tr("Jogada desfeita."))
	_refresh_all()

func _on_card_long_pressed(card: CardInstance) -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	CardZoom.show_card_in(card, _zoom_list_for(card))   # 0.19.0 (10): deslizar passa à carta seguinte

## As cartas vizinhas de uma carta: a mão pela ordem do leque, ou as criaturas da Arena.
func _zoom_list_for(card: CardInstance) -> Array:
	if card in battle.deck.hand:
		var out: Array = []
		for v in hand_box.get_children():
			var cv := v as CardView
			if cv != null and not cv.is_queued_for_deletion() and cv.card != null:
				out.append(cv.card)
		return out
	if card in battle.board:
		return battle.creatures()
	return []

func _on_relic_pressed(id: String) -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	if bool(Settings.opt("move_buttons")) and id in GameState.relic_ids and GameState.relic_ids.size() >= 2:
		_open_relic_menu(id)   # 0.19.0 (283): mudar a ordem das relíquias sem arrastar
		return
	CardZoom.show_relic(id)

func _open_relic_menu(id: String) -> void:
	if _alive(_modal):
		return
	var box := _open_modal(tr(String(CardDB.relics.get(id, {}).get("name", id))), tr(String(CardDB.relics.get(id, {}).get("text", ""))))
	box.name = "RelicMenu"
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 10)
	box.add_child(row)
	var i := GameState.relic_ids.find(id)
	for a in [["left", "◀", i > 0], ["see", tr("VER EM GRANDE"), true], ["right", "▶", i < GameState.relic_ids.size() - 1]]:
		var b := UiKit.button(String(a[1]), 52, 18)
		b.name = "Relic_" + String(a[0])
		b.custom_minimum_size.x = 90 if String(a[0]) != "see" else 220
		b.disabled = not bool(a[2]) or battle.resolving
		b.pressed.connect(_close_modal.bind(String(a[0])))
		row.add_child(b)
	var res = await _modal_result()
	if not (res is String):
		return
	if String(res) == "see":
		CardZoom.show_relic(id)
	else:
		GameState.move_relic(id, i + (-1 if String(res) == "left" else 1))
		Sfx.select()
		_build_relics()
		_refresh_preview()
		if not battle.puzzle:
			GameState.save_run(battle.to_dict(), "battle")

func _open_library() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	ZoneViewer.open_library(tr("GRIMÓRIO"), battle.deck.library, maxi(0, battle.hand_size - battle.deck.hand.size()))

func _open_graveyard() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	var pickable := battle.flashback_cards().filter(func(c): return battle.can_flashback(c))
	if pickable.is_empty() or battle.resolving or battle.finished:
		ZoneViewer.open(tr("CEMITÉRIO"), battle.deck.graveyard, false, Callable(), Callable(), tr("EXÍLIO"), battle.deck.exile)
		return
	ZoneViewer.open(tr("CEMITÉRIO — ↺ toca num feitiço para o recapitular"), battle.deck.graveyard, false,
		func(card: CardInstance):
			if battle.can_flashback(card):
				_push_undo()
				battle.play_flashback(card)
				Sfx.boom()
				_refresh_all(),
		func(card: CardInstance): return battle.can_flashback(card),
		tr("EXÍLIO"), battle.deck.exile)

# --- Mulligan ---

func _on_mulligan() -> void:
	if not battle.can_mulligan() or SceneRouter.has_overlay():
		return
	Sfx.shuffle()
	Settings.vibrate(20)
	battle.mulligan()

func _on_mulligan_taken(count: int) -> void:
	_log(tr("Mão nova. Escolhe %d carta(s) para o fundo do grimório.") % count)
	_refresh_all()

# --- Dupla face, selos, recapitular, exílio ---

func _on_card_transformed(card: CardInstance) -> void:
	Sfx.boom()
	Settings.vibrate(40)
	_log(tr("%s virou!") % tr(card.data.name))
	var view: Control = _board_views.get(card.uid, _hand_views.get(card.uid))
	if _alive(view) and Settings.anim_scale() > 0.0:
		view.pivot_offset = view.size / 2.0
		_kill_tween(view, "flip_tw")
		var tw := create_tween()
		tw.tween_property(view, "scale:x", 0.0, _d(0.14)).set_ease(Tween.EASE_IN)
		tw.tween_callback(func():
			if _alive(view) and view is CardView:
				(view as CardView).refresh())
		tw.tween_property(view, "scale:x", 1.0, _d(0.16)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
		view.set_meta("flip_tw", tw)
		_pop(view, "⇄ " + tr("Transformação!"), COLOR_FORMATION)
	else:
		_refresh_all()
	_refresh_preview()

func _on_card_flashback(card: CardInstance) -> void:
	_log(tr("Recapitulaste %s — vai para o exílio.") % tr(card.data.name))

func _on_seal_triggered(card: CardInstance, seal: String) -> void:
	var view: Control = _board_views.get(card.uid, _hand_views.get(card.uid))
	var text := ""
	match seal:
		"tithe":
			text = tr("+3 ouro")
		"vitality":
			text = tr("+15 Poder")
		"phyrexian":
			text = tr("−10 Poder")
		"wisdom":
			text = tr("Formação +1")
	if text != "":
		_pop(view if _alive(view) else formation_label, "◉ " + text, COLOR_SEAL)

func _on_formation_leveled(id: String, level: int) -> void:
	_log(tr("%s sobe para o nível %d.") % [tr(String(CardDB.get_formation(id).get("name", id))), level])

func _on_card_exiled_run(card: CardInstance) -> void:
	_log(tr("%s foi exilada da run.") % tr(card.data.name))
	if _board_views.has(card.uid) and is_instance_valid(_board_views[card.uid]):
		_animate_death(_board_views[card.uid])
	_refresh_all()

func _on_boss_ascended(text: String) -> void:
	Sfx.hit()
	Settings.vibrate(80)
	_shake(12.0)
	# Vem logo a seguir ao despertar: o banner junta as duas coisas.
	_show_banner((tr("O BOSS DESPERTA") + "\n" if battle.phase2 else "") + tr("ASCENSÃO MÍTICA"), 1.3)
	_log(tr(text) if text != "" else tr("O boss ativa a 2.ª regra!"))
	_refresh_enemy_header()
	_refresh_discard_button()

## O boss passou abaixo de metade da vida: desperta (+ataque) e diz uma fala.
func _on_boss_phase2(line: String) -> void:
	Sfx.boom()
	Settings.vibrate(80)
	_shake(14.0)
	if _pending_phase_text != "":   # 0.13.0: bosses com várias fases dizem o que mudou
		_show_banner(tr("O BOSS DESPERTA") + "\n" + tr(_pending_phase_text), 1.3)
		_log(tr("%s despertou: %s") % [tr(battle.enemy.name), tr(_pending_phase_text)])
		_pending_phase_text = ""
	else:
		_show_banner(tr("O BOSS DESPERTA") + "\n" + tr("+%d de ataque") % BattleManager.PHASE2_ATTACK, 1.1)
		_log(tr("%s despertou: +%d de ataque.") % [tr(battle.enemy.name), BattleManager.PHASE2_ATTACK])
	_flash(enemy_panel, Color(2.0, 0.6, 0.5))
	_refresh_enemy_header()
	_refresh_preview()
	if _backdrop != null:
		_backdrop.set_phase2(true)   # 0.16.0 (56): o fundo puxa para vermelho e as partículas aceleram
	_sync_arena_floor()
	_say(line, 3.0)

## Coração de Vidro: um golpe mortal deixou-te com 1 de vida.
func _on_death_saved() -> void:
	Sfx.boom()
	Settings.vibrate(120)
	_show_banner(tr("CORAÇÃO DE VIDRO"), 1.2)
	_log(tr("O Coração de Vidro estilhaçou-se: ficas com 1 de vida."))
	_flash(player_label, Color(1.6, 1.8, 2.4))

func _on_contract_resolved(success: bool, text: String) -> void:
	if text != "":
		SceneRouter.toast(("✓ " if success else "✗ ") + text, 2.6)

## Devorador de Horizontes: a criatura mais à direita sai para o exílio.
func _on_creature_exiled(card: CardInstance) -> void:
	Sfx.hit()
	_log(tr("%s devorou %s.") % [tr(battle.enemy.name), tr(card.data.name)])
	if _board_views.has(card.uid) and is_instance_valid(_board_views[card.uid]):
		_animate_death(_board_views[card.uid])
	_refresh_board()
	_refresh_preview()
	_refresh_zone_buttons()

## Chuva de Meteoros: dano à criatura da 3.ª posição no fim do turno.
func _on_climate_hit(card: CardInstance, amount: int) -> void:
	_log(tr("%s: %s sofre %d de dano.") % [tr(battle.climate_name()), tr(card.data.name), amount])
	var view: Control = _board_views.get(card.uid)
	if _alive(view):
		if view is CardView:
			(view as CardView).refresh()
		_flash(view, Color(2.0, 0.9, 0.6))
		_pop(view, "−%d" % amount, Color(1.0, 0.45, 0.25))

# --- Falas do boss ---

func _boss_line(key: String) -> String:
	if not bool(battle.enemy.get("boss", false)) and String(battle.enemy.get("variant", "")) != "nemesis":
		return ""
	return String((battle.enemy.get("lines", {}) as Dictionary).get(key, ""))

func _say_after(text: String, delay: float, seconds: float = 3.0) -> void:
	if text == "":
		return
	if delay > 0.0:
		await get_tree().create_timer(delay).timeout
	if is_inside_tree() and not battle.finished:
		_say(text, seconds)

## Balão de fala ao lado do painel do inimigo (some sozinho e não bloqueia toques).
func _say(text: String, seconds: float = 3.0) -> void:
	if text == "" or not is_inside_tree():
		return
	if _bubble_tw != null and _bubble_tw.is_valid():
		_bubble_tw.kill()
	if _alive(_bubble):
		_bubble.queue_free()
	var b := PanelContainer.new()
	b.name = "BossBubble"
	var wait := bool(Settings.opt("boss_wait"))   # 0.19.0 (139): fica até lhe tocares
	b.mouse_filter = Control.MOUSE_FILTER_STOP if wait else Control.MOUSE_FILTER_IGNORE
	if wait:
		b.gui_input.connect(_on_bubble_tap.bind(b))
	b.add_theme_stylebox_override("panel", UiKit.flat(Color(0.97, 0.94, 0.88), 14, Color(0.25, 0.15, 0.3), 3, 12))
	var l := UiKit.label("«" + tr(text) + "»", 18, Color(0.14, 0.08, 0.16), true)
	l.custom_minimum_size.x = 300
	b.add_child(l)
	add_child(b)
	_bubble = b
	b.modulate.a = 0.0
	await get_tree().process_frame
	if not _alive(b):
		return
	b.reset_size()
	var er := enemy_panel.get_global_rect()
	var right_side := not Settings.left_handed
	var x := er.end.x + 16.0 if right_side else er.position.x - b.size.x - 16.0
	b.global_position = Vector2(x, er.position.y + 8.0)
	# Bico a apontar para o inimigo.
	var tail := Polygon2D.new()
	tail.color = Color(0.97, 0.94, 0.88)
	if right_side:
		tail.polygon = PackedVector2Array([Vector2(2, 16), Vector2(-16, 26), Vector2(2, 36)])
	else:
		tail.polygon = PackedVector2Array([Vector2(b.size.x - 2, 16), Vector2(b.size.x + 16, 26), Vector2(b.size.x - 2, 36)])
	b.add_child(tail)
	b.pivot_offset = Vector2(0.0 if right_side else b.size.x, 26.0)
	b.scale = Vector2(0.7, 0.7)
	_bubble_tw = create_tween()
	_bubble_tw.set_parallel(true)
	_bubble_tw.tween_property(b, "modulate:a", 1.0, 0.15)
	_bubble_tw.tween_property(b, "scale", Vector2.ONE, 0.22).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	if not wait:
		_bubble_tw.chain().tween_interval(seconds)
		_bubble_tw.chain().tween_property(b, "modulate:a", 0.0, 0.3)
		_bubble_tw.chain().tween_callback(b.queue_free)
	Sfx.blip(3)

func _on_bubble_tap(ev: InputEvent, b: Control) -> void:
	if ev is InputEventMouseButton and (ev as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT and not ev.pressed and _alive(b):
		b.queue_free()

# --- Linha de informação: clima, contrato e planeswalker ---

## Por cima do cálculo: chip do Clima Planar, chip do contrato ativo e o painel do planeswalker.
func _build_info_row() -> void:
	for c in pw_row.get_children():
		pw_row.remove_child(c)
		c.queue_free()
	_pw_buttons.clear()
	_pw_panel = null
	_pw_loyalty = null
	_pw_name = null
	_climate_chip = null
	_climate_label = null
	_contract_chip = null
	var any := false
	if battle.climate != "" and bool(Settings.opt("hud_climate")):   # 0.19.0 (141)
		var cdef := CardDB.get_climate(battle.climate)
		_climate_chip = UiKit.info_chip("climate", tr(String(cdef.get("name", ""))), COLOR_CLIMATE, func():
			CardZoom.show_climate(battle.climate, _climate_suffix()))
		_climate_label = _climate_chip.get_meta("label")
		pw_row.add_child(_climate_chip)
		any = true
	if not GameState.contract.is_empty() and not battle.puzzle and bool(Settings.opt("hud_contract")):
		var con: Dictionary = GameState.contract
		_contract_chip = UiKit.info_chip("contract", tr(String(con.get("name", ""))), UiKit.GOLD, func():
			CardZoom.show_contract(con))
		pw_row.add_child(_contract_chip)
		any = true
	var def := GameState.planeswalker_def()
	if not def.is_empty():
		_build_planeswalker(def, any or not bool(Settings.opt("hud_patron")))   # 141: sem o patrono em grande, fica compacto
		any = true
	pw_row.visible = any
	_add_mech_chip()   # 0.19.0 (131, 132)
	_refresh_info_row()

## Lua de Sangue: "· Dia" / "· Noite" conforme o turno.
func _climate_suffix() -> String:
	if battle.climate == "blood_moon":
		return "  ·  " + (tr("Noite") if battle.is_night() else tr("Dia"))
	return ""

func _refresh_info_row() -> void:
	if _climate_label != null and is_instance_valid(_climate_label):
		_climate_label.text = tr(battle.climate_name()) + _climate_suffix()
	_refresh_planeswalker()
	_refresh_mech_chip()

## 0.16.0 (V32): o patrono com o retrato (os 6 já existiam e nunca apareciam), a lealdade num mostrador e os
## botões +1, −2 e −6 com o efeito em ícone. Tocar no retrato ou no nome abre-o em grande.
func _build_planeswalker(def: Dictionary, compact: bool) -> void:
	var color: Color = CardView.COLORS.get(String(def.get("color", "colorless")), UiKit.GOLD)
	var pid := String(def.get("id", ""))
	var panel := PanelContainer.new()
	panel.name = "PatronPanel"
	# 0.18.0: margem de 3 px (antes 6): a linha do patrono passou de 58 para 52 px (a batalha cabe nos 720 px).
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.1, 0.08, 0.16, 0.95), 12, color, 2, 3))
	pw_row.add_child(panel)
	_pw_panel = panel
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	panel.add_child(row)
	var face := Control.new()
	face.name = "PatronFace"
	face.custom_minimum_size = Vector2(44, 44)
	face.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	face.mouse_filter = Control.MOUSE_FILTER_STOP
	face.tooltip_text = tr(String(def.get("name", "")))
	var art := ArtLib.texture("portrait", pid)
	face.draw.connect(func():
		var c := face.size / 2.0
		var rad := minf(face.size.x, face.size.y) / 2.0
		face.draw_circle(c, rad, Color(0.06, 0.05, 0.1))
		if art != null:
			ArtLib.draw_round(face, art, c, rad - 2.0)
		else:
			face.draw_circle(c, rad * 0.45, Color(color, 0.7))
		face.draw_arc(c, rad - 1.0, 0.0, TAU, 32, color, 2.0, true))
	var open_pw := func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed and not SceneRouter.has_overlay():
			Sfx.select()
			CardZoom.show_planeswalker(pid)
	face.gui_input.connect(open_pw)
	row.add_child(face)
	var info := VBoxContainer.new()
	info.add_theme_constant_override("separation", 0)
	info.custom_minimum_size.x = 118 if compact else 150
	info.mouse_filter = Control.MOUSE_FILTER_STOP
	info.gui_input.connect(open_pw)
	row.add_child(info)
	_pw_name = UiKit.label(tr(String(def.get("name", ""))).get_slice(",", 0), 15, color.lightened(0.2))
	_pw_name.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	info.add_child(_pw_name)
	var dial_row := HBoxContainer.new()
	dial_row.add_theme_constant_override("separation", 6)
	dial_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	info.add_child(dial_row)
	_pw_dial = Control.new()
	_pw_dial.name = "LoyaltyDial"
	_pw_dial.custom_minimum_size = Vector2(26, 26)
	_pw_dial.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_pw_dial.draw.connect(func():
		var mx := int(def.get("max_loyalty", 6))
		var l := GameState.planeswalker_loyalty()
		var c := _pw_dial.size / 2.0
		var rad := minf(_pw_dial.size.x, _pw_dial.size.y) / 2.0 - 2.0
		var gap := 0.18
		for k in mx:
			var a0 := -PI / 2.0 + TAU * k / mx + gap * 0.5
			var a1 := -PI / 2.0 + TAU * (k + 1) / mx - gap * 0.5
			_pw_dial.draw_arc(c, rad, a0, a1, 8, color.lightened(0.15) if k < l else Color(1, 1, 1, 0.15), 3.2, true)
		var font := get_theme_default_font()
		var txt := str(l)
		var ts := font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 13)
		_pw_dial.draw_string(font, c + Vector2(-ts.x * 0.5, 5.0), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE))
	dial_row.add_child(_pw_dial)
	_pw_loyalty = UiKit.label("", 13, UiKit.TEXT_DIM)
	_pw_loyalty.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	_pw_loyalty.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_pw_loyalty.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	dial_row.add_child(_pw_loyalty)
	var skills: Array = def.get("skills", [])
	for i in skills.size():
		var cost := int(skills[i].get("cost", 0))
		var b := _skill_button(cost, String(PW_EFFECT_ICONS.get(String(skills[i].get("action", "")), "star")))
		b.name = "PatronSkill%d" % i
		b.pressed.connect(_on_pw_skill.bind(i))
		b.tooltip_text = tr(String(skills[i].get("text", "")))
		row.add_child(b)
		_pw_buttons.append(b)

## 0.16.0 (a proposta que o AlizeOnMe aprovou): botão de habilidade do patrono em vidro escuro, com o contorno
## néon (verde quando sobe a lealdade, vermelho quando a gasta), o custo numa gema hexagonal à esquerda e o
## efeito em ícone; desligado fica cinzento, com um cadeado.

func _skill_button(cost: int, icon_kind: String) -> Button:
	var up := cost > 0
	var b := Button.new()
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(90, 46)
	b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var neon := Color(0.33, 0.86, 0.56) if up else Color(1.0, 0.43, 0.38)
	var bgs := {"normal": Color(0.11, 0.085, 0.17, 0.97), "hover": Color(0.15, 0.12, 0.23), "pressed": Color(0.2, 0.16, 0.3), "disabled": Color(0.09, 0.08, 0.12, 0.85)}
	for st_name in bgs:
		var st := StyleBoxFlat.new()
		st.set_corner_radius_all(12)
		st.set_border_width_all(2)
		st.bg_color = bgs[st_name]
		st.border_color = neon if st_name != "disabled" else Color(0.36, 0.34, 0.44)
		if st_name != "disabled":
			st.shadow_color = Color(neon, 0.3)
			st.shadow_size = 5
		b.add_theme_stylebox_override(st_name, st)
	var gem := SkillGem.new(cost)
	gem.name = "Gem"
	b.add_child(gem)
	gem.set_anchors_preset(Control.PRESET_CENTER_LEFT)
	gem.offset_left = -6.0
	gem.offset_right = 36.0
	gem.offset_top = -20.0
	gem.offset_bottom = 20.0
	var icon := CardIcon.new(icon_kind, Color(1, 1, 1, 0.92), 20.0)
	icon.name = "Icon"
	b.add_child(icon)
	icon.set_anchors_preset(Control.PRESET_CENTER_LEFT)
	icon.offset_left = 50.0
	icon.offset_right = 70.0
	icon.offset_top = -10.0
	icon.offset_bottom = 10.0
	var lock := CardIcon.new("lock", Color(0.82, 0.8, 0.9, 0.9), 13.0)
	lock.name = "Lock"
	b.add_child(lock)
	lock.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	lock.offset_left = -18.0
	lock.offset_right = -5.0
	lock.offset_top = 4.0
	lock.offset_bottom = 17.0
	lock.visible = false
	b.draw.connect(_skill_lock.bind(lock, icon, gem, b))
	return b

## O botão desligado: cadeado à vista, ícone apagado e a gema cinzenta.
func _skill_lock(lock, icon, gem, b) -> void:
	if not is_instance_valid(lock) or not is_instance_valid(b):
		return
	var off := (b as BaseButton).disabled
	(lock as Control).visible = off
	if is_instance_valid(icon):
		(icon as Control).modulate.a = 0.45 if off else 1.0
	if is_instance_valid(gem):
		(gem as SkillGem).off = off

func _refresh_planeswalker() -> void:
	var def := GameState.planeswalker_def()
	var has_panel := _pw_panel != null and is_instance_valid(_pw_panel)
	if def.is_empty():
		if has_panel:
			_build_info_row()
		return
	if not has_panel or _pw_buttons.size() != (def.get("skills", []) as Array).size():
		_build_info_row()
		return
	var max_l := int(def.get("max_loyalty", 6))
	var l := GameState.planeswalker_loyalty()
	_pw_loyalty.text = "%d/%d" % [l, max_l] + ("  ·  " + tr("usado") if battle.pw_used_this_turn else "")
	_pw_loyalty.tooltip_text = tr("Lealdade %d/%d") % [l, max_l]
	if _pw_dial != null and is_instance_valid(_pw_dial):
		_pw_dial.queue_redraw()
	for i in _pw_buttons.size():
		_pw_buttons[i].disabled = not battle.can_use_planeswalker(i)
		UiKit.explain(_pw_buttons[i], _pw_why.bind(i))   # 0.19.0 (121)

func _on_pw_skill(i: int) -> void:
	if not battle.can_use_planeswalker(i) or SceneRouter.has_overlay():
		return
	var skill: Dictionary = battle.planeswalker_skills()[i]
	_push_undo()
	if battle.use_planeswalker(i):
		Sfx.boom()
		Settings.vibrate(30)
		_log("✦ " + tr(String(skill.get("text", ""))))
		_pop(_pw_panel if _alive(_pw_panel) else pw_row, "✦ " + tr(String(GameState.planeswalker_def().get("name", ""))), COLOR_FORMATION)
		_refresh_all()

func _on_discard_toggled(on: bool) -> void:
	_discard_mode = on and battle.discards_left > 0
	if on and battle.discards_left <= 0:
		discard_btn.button_pressed = false
	for view in _hand_views.values():
		if is_instance_valid(view):
			view.modulate = DISCARD_TINT if _discard_mode else Color.WHITE
			view.playable = battle.can_play(view.card) or view.card.data.is_land() or _discard_mode
	if _discard_mode:
		_log(tr("Toca na carta a canalizar."))
		Sfx.select()

func _on_end_turn() -> void:
	if battle.resolving or battle.finished or _alive(_modal):
		return
	# 0.13.0: no fundo do Mulligan ainda não se pode atacar (antes o botão desligava-se e ficava preso).
	if battle.pending_bottom > 0:
		Sfx.deny()
		_warn(tr("Primeiro escolhe %d carta(s) para o fundo do grimório.") % battle.pending_bottom, Color(0.95, 0.45, 0.4), 2.6, true)
		return
	if not _confirm_attack():   # 0.20.0 (B7): antes do aviso da mana
		return
	if Settings.warn_mana and not battle.puzzle and battle.mana_available > 0:
		var best := 0
		for c in battle.deck.hand:
			if battle.can_play(c) and not c.data.is_land():
				best = maxi(best, battle.preview_play(c))
		if best > 0:
			var ans := await _ask(tr("Atacar sem gastar a mana?"), tr("Ainda tens %d de mana e cartas que aumentam o ataque (até +%s).") % [battle.mana_available, Cascade.fmt_int(best)], tr("ATACAR"))
			if ans == "never":
				Settings.warn_mana = false
				Settings.save_settings()
			elif ans != "yes":
				_refresh_preview()   # 0.20.0 (B7): o ATACAR deixa de dizer «toca outra vez», que já não vale
				return
			if battle.resolving or battle.finished:
				return
	_bump(end_turn_btn, 0.92)
	_enemy_log_from = _history.size()   # 0.19.0 (117): daqui para a frente é o turno do inimigo
	_enemy_turn_logging = battle.preview_attack().is_empty()
	end_turn_btn.disabled = true
	discard_btn.button_pressed = false
	discard_btn.disabled = true
	battle.end_turn()
	# Rede de segurança: se o turno não começou a resolver (o jogo recusou atacar), os botões voltam.
	if not battle.resolving and not battle.finished:
		end_turn_btn.disabled = false
		_refresh_discard_button()

# --- 0.20.0 (B7): último turno e ataques que perdem a run ---

## «Em run»: a condição com que o BattleManager grava a run (os enigmas, as lições e os treinos têm puzzle_id).
func _in_run() -> bool:
	return not battle.puzzle and GameState.puzzle_id == ""

## O último turno: se o inimigo não cair, perdes. Não existe na Fuga (ganha-se a sobreviver) nem no Treino com o boneco
## (vida infinita).
func _is_last_turn() -> bool:
	return battle.turn > 0 and battle.turns_left() <= 0 and battle.objective != "escape" and GameState.puzzle_id != "training"

## O ataque perde a run? "die": o contra-ataque previsto mata-te, sem o Coração de Vidro a salvar; "short": último turno
## e não é letal (a mesma conta do LETAL no _show_calc, com a vida dos dois na Dupla); "" se não perde. «MORRES» ganha, porque o contra-ataque vem antes
## da derrota por turnos. Os espinhos da Elite picam antes do contra-ataque (BattleManager.end_turn): o plano refaz-se com
## a vida que sobra, porque as criaturas podem sacrificar-se. O boss a despertar com o golpe ainda não conta.
## Na Dupla só se ganha com os dois no chão (hp_left); um golpe que derruba só o alvo não conta para o «MORRES»,
## porque o counter_plan soma os ataques dos dois e só o outro contra-ataca.
func _attack_risk(net: int, plan: Dictionary) -> String:
	if battle.finished or (net > 0 and net >= battle.hp_left()):
		return ""
	if net > 0 and net >= int(battle.enemy.hp):
		return "short" if _is_last_turn() else ""
	var hp := GameState.player_hp
	var thorns: int = mini(int(battle.rule.get("thorns", 0)), hp - 1) if net > 0 else 0   # (um ataque tapado pelo escudo também pica: fica de fora)
	if thorns > 0:
		hp -= thorns
		plan = battle.counter_plan(hp)
	var pd := int(plan.get("player_damage", 0))
	if pd > 0 and pd >= hp and not GameState.can_death_save():
		return "die"
	return "short" if _is_last_turn() else ""

## Em run, o ataque de agora perde a run (o ATACAR pede o 2.º toque): nada de «ataca!», brilho nem ataque automático.
func _risky_attack() -> bool:
	return _in_run() and _attack_risk(battle.preview_attack().net_total(), battle.counter_plan()) != ""

## O ATACAR à espera do 2.º toque; com «ATACAR a segurar», é segurar outra vez.
func _armed_attack_text() -> String:
	return tr("segura outra vez para atacar") if bool(Settings.opt("hold_attack")) else tr("toca outra vez para atacar")

## O aviso do 1.º toque, mais o que ainda há por usar (só o que existir).
func _attack_risk_text(risk: String) -> String:
	var head := tr("Este contra-ataque mata-te: perdes a run.") if risk == "die" else tr("Este ataque não chega: perdes a run.")
	var left: Array[String] = []
	if battle.discards_left > 0 and not battle.deck.hand.is_empty():
		left.append((tr("%d canalização") if battle.discards_left == 1 else tr("%d canalizações")) % battle.discards_left)
	for id in GameState.consumables:
		if battle.can_use_consumable(id):
			left.append(tr(String(CardDB.get_consumable(id).get("name", id))))
	for i in battle.planeswalker_skills().size():
		if battle.can_use_planeswalker(i):
			left.append(tr("o patrono"))
			break
	return head if left.is_empty() else head + "\n" + tr("Ainda tens por usar: %s.") % ", ".join(PackedStringArray(left))

## true se pode atacar já. Em run, um ataque que perde a run só sai ao 2.º toque dentro de CONFIRM_ATTACK_TIME; o 1.º
## muda o botão e avisa (o padrão do Shop._confirm). Na Arena, perder custa vida, nunca a run (GameState.finish_arena).
func _confirm_attack() -> bool:
	if not _in_run() or GameState.arena_battle:
		return true
	var risk := _attack_risk(battle.preview_attack().net_total(), battle.counter_plan())
	if risk == "" or _attack_armed:
		_attack_armed = false
		_attack_arm_token += 1
		return true
	_attack_armed = true
	_attack_arm_token += 1
	create_tween().tween_callback(_disarm_attack.bind(_attack_arm_token)).set_delay(CONFIRM_ATTACK_TIME)
	Sfx.select()
	_set_attack_text(_armed_attack_text())
	_warn(_attack_risk_text(risk), Color(0.95, 0.45, 0.4), CONFIRM_ATTACK_TIME, true)   # B10: logo, à frente do resumo
	return false

## Passados os 3 s sem o 2.º toque, o ATACAR volta ao normal.
func _disarm_attack(tok: int) -> void:
	if tok == _attack_arm_token and _attack_armed:
		_attack_armed = false
		_refresh_preview()

func _on_enemy_ability(enemy_name_str: String, action: String) -> void:
	_log("%s %s!" % [tr(enemy_name_str), tr(ABILITY_LOG.get(action, action))])
	_flash(enemy_panel, Color(1.3, 1.1, 1.5))
	_refresh_all()

func _on_damage_dealt(target: String, amount: int) -> void:
	if target == "enemy":
		_log(tr("Causaste %s de dano.") % Cascade.fmt_int(amount))
		_enemy_log_from = _history.size()
		_enemy_turn_logging = true
		_animate_enemy_hit(amount)
		if _portrait != null:
			_portrait.hit()
		# Peso do golpe: congela um instante e abana em proporção à vida máxima do inimigo.
		var pct := minf(1.0, float(amount) / maxf(1.0, float(battle.enemy.get("max_hp", 1))))
		if pct >= 0.2:
			SceneRouter.hit_stop(0.05 + 0.1 * pct)
		_shake(4.0 + 16.0 * pct)
		if not _hit_line_said and pct >= 0.25 and int(battle.enemy.hp) > 0:
			var will_awaken := not battle.phase2 and int(battle.enemy.hp) * 2 <= int(battle.enemy.max_hp)
			var line := _boss_line("hit")
			if line != "" and not will_awaken:
				_hit_line_said = true
				_say(line, 2.4)
	else:
		Sfx.hit()
		Settings.haptic("damage")   # 0.19.0 (30): dupla quando levas dano
		_animate_enemy_strike(amount)
		_shake(8.0)
		_fly_player_damage(amount)   # 0.16.0 (V35): o número voa até à vida
		_log(tr("Levaste %d de dano.") % amount)

func _on_battle_ended(victory: bool) -> void:
	pause_btn.disabled = true
	if GameState.puzzle_id == "training":
		_training_result()
		return
	if GameState.puzzle_id == "training_boss":   # 0.17.0 (88)
		_training_boss_result(victory)
		return
	if GameState.is_lesson_battle():
		var ok := victory or (String(_lesson_def.get("goal_type", "win")) == "react" and _lesson_reacted)
		_lesson_result(ok)
		return
	if battle.puzzle or GameState.puzzle_id != "":   # 0.13.0: um enigma nunca acaba como uma run
		if victory:
			Stats.on_puzzle_solved(GameState.puzzle_id)
			_show_banner(tr("RESOLVIDO!"), 1.2)
			Sfx.boom()
			CelebrationFx.play(self, get_viewport_rect(), "confetti")
		else:
			_show_banner(tr("NÃO CHEGOU"), 1.0)
		await _puzzle_result(victory)
		return
	if GameState.arena_battle:
		await _arena_result(victory)
		return
	if victory and GameState.mode in ["tower", "rush"]:   # 0.17.0: Torre do Arquimago / Corrida de Bosses
		await _side_mode_victory()
		return
	if victory:
		# 0.13.0: o inimigo afunda e racha, o golpe final abranda e há confetes.
		# 0.16.0 (57): o retrato do boss parte-se em cacos de vidro, com a luz da cor do baralho.
		if _portrait != null and _alive(_portrait):
			_portrait.charging = false
			if battle.escaped:   # 0.18.0 Fuga: o inimigo fica de pé (fugiste)
				pass
			elif not (bool(battle.enemy.get("boss", false)) and _shatter_portrait()):
				_portrait.defeat()
		SceneRouter.hit_stop(0.35, 0.3)
		CelebrationFx.play(self, get_viewport_rect(), "confetti")
		var last_words := _boss_line("defeat")
		var extra := 0.0
		var panel := _rewards_ok()   # 0.16.0 (V38): o ecrã de recompensas substitui os avisos
		var extra_reveals: Array = []
		if panel:
			if String(battle.enemy.get("variant", "")) == "nemesis" and GameState.last_reward_text != "":
				extra_reveals.append(["text", "☠ " + tr("Némesis vencida: %s") % GameState.last_reward_text])
			if GameState.last_milestone_text != "":
				extra_reveals.append(["text", "∞ " + tr("Marco do Infinito (ante %d): %s") % [GameState.ante, GameState.last_milestone_text]])
			if last_words != "":
				_say(last_words, 2.0)
				extra = _d(1.0)
		elif battle.overkill_gold > 0:   # 0.15.0 Excesso vira ouro
			SceneRouter.toast("✦ " + tr("Excesso: o golpe final passou da vida do inimigo (+%d ouro).") % battle.overkill_gold, 2.6)
		if battle.perfect_play and not panel:
			SceneRouter.toast("★ " + tr("Jogada perfeita: venceste com a mana toda gasta (+%d ouro).") % BattleManager.PERFECT_GOLD, 2.8)
			Sfx.level_up()
			extra += _d(0.4)
		if last_words != "" and not panel:
			_say(last_words, 2.0)
			extra = _d(1.3)
		if String(battle.enemy.get("variant", "")) == "nemesis" and GameState.last_reward_text != "" and not panel:
			SceneRouter.toast("☠ " + tr("Némesis vencida: %s") % GameState.last_reward_text, 2.8)
		if GameState.last_milestone_text != "" and not panel:
			SceneRouter.toast("∞ " + tr("Marco do Infinito (ante %d): %s") % [GameState.ante, GameState.last_milestone_text], 3.4, false)
			Sfx.level_up()
			extra += _d(0.8)
		if String(battle.enemy.get("variant", "")) == "elite" and not panel:
			if battle.elite_relic != "":
				SceneRouter.toast("★ " + tr("Elite vencida: recebes %s.") % tr(String(CardDB.relics.get(battle.elite_relic, {}).get("name", ""))), 2.6)
			else:
				SceneRouter.toast(tr("Elite vencida: +%d ouro (não tinhas lugar para outra relíquia).") % 10, 2.6)
			if battle.elite_item != "":   # 0.13.0: e uma poção ou pergaminho
				SceneRouter.toast("◆ " + tr("Recebes: %s.") % tr(String(CardDB.get_consumable(battle.elite_item).get("name", ""))), 2.6)
			var nafx := (battle.enemy.get("affixes", []) as Array).size() if battle.enemy.get("affixes") is Array else 0
			if nafx > 0:
				SceneRouter.toast(tr("Afixos vencidos: +%d ouro.") % (GameState.AFFIX_GOLD * nafx), 2.2)
		if GameState.ante >= GameState.max_ante and not GameState.endless:
			GameState.last_victory = true
			EventBus.run_ended.emit(true)
			_show_banner(tr("VITÓRIA"), 1.0)
			await get_tree().create_timer(_d(0.9) + extra).timeout
			if panel:
				await _show_rewards(tr("VITÓRIA"), extra_reveals)
			SceneRouter.go("run_over")
		else:
			var won_title := tr("FUGISTE!") if battle.escaped else tr("ANTE %d VENCIDO") % GameState.ante   # 0.18.0 Fuga
			_show_banner(won_title, 1.0)
			Sfx.boom()
			await get_tree().create_timer(_d(0.9) + extra).timeout
			if panel:
				await _show_rewards(won_title, extra_reveals)
			GameState.map_phase = "stop"
			# Boss que não acaba a run: Baú de Espólio (1 de 3 relíquias de boss) antes da paragem.
			if bool(battle.enemy.get("boss", false)) and not GameState.prepare_loot().is_empty():
				GameState.save_run({}, "loot")
				SceneRouter.go("loot")
			else:
				GameState.save_run({}, "map")
				SceneRouter.go("map")
	else:
		if await _offer_retry():   # 0.19.0 (280): modo assistido — repetir a batalha perdida, uma vez por run
			return
		GameState.last_victory = false
		EventBus.run_ended.emit(false)
		# 0.13.0: cinza a cair e o inimigo a rir-se (investida).
		CelebrationFx.play(self, get_viewport_rect(), "ash")
		if _portrait != null and _alive(_portrait):
			_portrait.attack()
		_show_banner(_defeat_banner(), 1.8, false, false, 1.2)
		await get_tree().create_timer(maxf(1.2, _d(1.2) + (0.6 if Settings.motion_ok() else 0.0))).timeout   # B9: lê-se também na «Instantânea»
		SceneRouter.go("run_over")

# --- Arrastar para reordenar (tabuleiro e relíquias) ---

func _on_board_drag_started(card: CardInstance, pos: Vector2) -> void:
	if battle.resolving or battle.finished or _drag_ghost != null:
		return
	var view: Control = _board_views.get(card.uid)
	if not _alive(view):
		return
	_drag_view = view
	view.modulate.a = 0.35
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = view.size
	ghost.pivot_offset = ghost.size / 2.0
	ghost.scale = Vector2(1.06, 1.06)
	ghost.rotation = 0.04
	ghost.global_position = pos - ghost.size / 2.0
	_drag_ghost = ghost
	_drag_last_x = pos.x
	# Sombra por baixo da carta levantada (fica a 12 px, como se a carta estivesse no ar).
	_drag_shadow = Panel.new()
	_drag_shadow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := StyleBoxFlat.new()
	sh.bg_color = Color(0, 0, 0, 0.35)
	sh.set_corner_radius_all(14)
	sh.shadow_color = Color(0, 0, 0, 0.45)
	sh.shadow_size = 14
	_drag_shadow.add_theme_stylebox_override("panel", sh)
	_drag_shadow.size = view.size
	add_child(_drag_shadow)
	move_child(_drag_shadow, ghost.get_index())
	_drag_shadow.global_position = ghost.global_position + Vector2(10, 14)
	Settings.vibrate(15)

func _on_board_drag_moved(card: CardInstance, pos: Vector2) -> void:
	if _drag_ghost == null:
		return
	_drag_ghost.global_position = pos - _drag_ghost.size / 2.0
	_tilt_ghost(pos)
	var index := _index_for_x(board_box, pos.x, _drag_view)
	var current := battle.board.find(card)
	if index != current and index >= 0:
		battle.move_creature(card, index)
		board_box.move_child(_drag_view, index)
		_refresh_preview()

func _on_board_drag_ended(_card: CardInstance, _pos: Vector2) -> void:
	if _drag_ghost != null:
		_drag_ghost.queue_free()
		_drag_ghost = null
	if _alive(_drag_shadow):
		_drag_shadow.queue_free()
	_drag_shadow = null
	if _alive(_drag_view):
		_drag_view.modulate.a = 1.0
		_bump(_drag_view, 1.08)
	_drag_view = null
	Sfx.select()
	_refresh_preview()

func _on_relic_drag_started(id: String, pos: Vector2) -> void:
	if battle.resolving or battle.finished or _drag_ghost != null:
		return
	var view: Control = _relic_views.get(id)
	if not _alive(view):
		return
	_drag_view = view
	view.modulate.a = 0.35
	var ghost: RelicView = RELIC_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(id)
	ghost.set_width(view.size.x)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = view.size
	ghost.global_position = pos - ghost.size / 2.0
	_drag_ghost = ghost
	# 0.19.0 (61): o ataque previsto muda enquanto arrastas — a diferença fica por baixo da relíquia.
	_relic_total0 = _last_preview_total
	var dl := Label.new()
	dl.name = "Delta"
	dl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dl.add_theme_font_size_override("font_size", 16)
	dl.add_theme_constant_override("outline_size", 5)
	dl.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	dl.position = Vector2(-10, ghost.size.y + 2.0)
	ghost.add_child(dl)

var _relic_total0 := 0

func _on_relic_drag_moved(id: String, pos: Vector2) -> void:
	if _drag_ghost == null:
		return
	_drag_ghost.global_position = pos - _drag_ghost.size / 2.0
	var index := mini(_index_for_x(relics_bar, pos.x, _drag_view), GameState.relic_ids.size() - 1)
	var current := GameState.relic_ids.find(id)
	if index != current and index >= 0:
		GameState.relic_ids.erase(id)
		GameState.relic_ids.insert(clampi(index, 0, GameState.relic_ids.size()), id)
		relics_bar.move_child(_drag_view, index)
		_refresh_preview()
		var dl := _drag_ghost.get_node_or_null("Delta") as Label
		if dl != null:
			var diff := _last_preview_total - _relic_total0
			dl.text = "" if diff == 0 else ("%s%s" % ["+" if diff > 0 else "−", _num(absi(diff))])
			dl.add_theme_color_override("font_color", Color(0.55, 0.95, 0.6) if diff > 0 else Color(1.0, 0.5, 0.45))

func _on_relic_drag_ended(_id: String, _pos: Vector2) -> void:
	_on_board_drag_ended(null, Vector2.ZERO)
	GameState.save_run(battle.to_dict(), "battle")

## Posição (índice) em que um item arrastado deve ficar numa fila horizontal, pela coordenada x.
func _index_for_x(box: Control, x: float, dragged: Control) -> int:
	var live := box.get_children().filter(func(c): return not c.is_queued_for_deletion())
	var index := 0
	for c in live:
		if c == dragged:
			continue
		var center: float = c.global_position.x + c.size.x / 2.0
		if x > center:
			index += 1
	return index

# --- Pausa ---

func _open_pause() -> void:
	if battle.finished or SceneRouter.has_overlay() or (_pause_menu != null and is_instance_valid(_pause_menu)):
		return
	Sfx.select()
	_pause_menu = PauseMenu.open(_pause_info(), _replay_last_attack if _last_cascade != null and not _last_cascade.is_empty() else Callable(), _exit_mode(), _pause_summary())
	_pause_menu.abandoned.connect(_on_abandon)
	_pause_menu.exited.connect(_on_exit_to_menu)
	if can_undo_node():   # 0.19.0 (199): tocaste no nó errado — voltar ao mapa antes de a batalha começar
		_pause_menu.add_action(tr("◀ OUTRO NÓ DO MAPA"), "UndoNode", undo_node)
	if can_rewind():   # 0.19.0 (279): modo assistido — voltar ao início do turno anterior, uma vez por batalha
		_pause_menu.add_action(tr("↺ REBOBINAR O TURNO"), "Rewind", rewind_turn)

## 0.14.2: SAIR PARA O MENU só nas runs (enigmas, lições e treino não se gravam) e nunca a meio do ataque
## (a cascata e o contra-ataque correm com battle.resolving; o botão liga-se no turno seguinte).
func _exit_mode() -> PauseMenu.Exit:
	if GameState.puzzle_id != "" or battle.puzzle:
		return PauseMenu.Exit.NONE
	return PauseMenu.Exit.WAIT if battle.resolving else PauseMenu.Exit.OK

## 0.14.2: grava a batalha tal como está (mão, Arena, mana, feitiços deste turno) e volta ao menu, sem
## abandonar a run: o CONTINUAR do menu retoma-a neste ponto.
func _on_exit_to_menu() -> void:
	if _save_for_exit():
		SceneRouter.go("main")

## Grava a batalha para o SAIR PARA O MENU (false se agora não se pode sair).
func _save_for_exit() -> bool:
	if battle.finished or _exit_mode() != PauseMenu.Exit.OK:
		return false
	GameState.save_run(battle.to_dict(), "battle")
	return true

## 0.16.0 (V47): o resumo da pausa em imagem (só nas runs; enigmas, lições e treino ficam com o texto).
func _pause_summary() -> Dictionary:
	if GameState.puzzle_id != "" or battle.puzzle or GameState.is_lesson_battle():
		return {}
	var ante_txt := tr("Ante %d de %d") % [GameState.ante, GameState.max_ante] if not GameState.endless else tr("Ante %d") % GameState.ante
	var line := tr("Ato %s") % GameState.act_name() + "  ·  " + ante_txt
	var bar_max := 0 if GameState.endless else GameState.max_ante
	if GameState.mode in ["tower", "rush"]:   # 0.17.0: andar da Torre / boss n.º da Corrida (a barra só na Corrida)
		line = tr(GameState.mode_name(GameState.mode)) + "  ·  " + GameState.stage_label()
		bar_max = GameState.max_ante if GameState.mode == "rush" else 0
	return {
		"deck": tr(GameState.deck_def.get("name", "")),
		"colors": GameState.deck_def.get("colors", []),
		"line": line + "  ·  " + tr("Turno %d/%d") % [battle.turn, battle.max_turns + battle.extra_turns],
		"ante": GameState.ante,
		"max_ante": bar_max,
		"stake": GameState.stake,
		"climate": tr(battle.climate_name()) if battle.climate != "" else "",
		"climate_id": battle.climate,
		"enemy": tr(VARIANT_NAMES.get(String(battle.enemy.get("variant", "scout")), "Batedor")),
		"foot": tr("Seed %d") % GameState.seed_value + "  ·  " + tr("Gravado sozinho em «%s» a cada jogada.") % GameState.slot_name(GameState.current_slot),
	}

func _pause_info() -> String:
	if GameState.puzzle_id == "training":
		return tr("Treino")
	if GameState.puzzle_id == "training_boss":
		return tr("Treino contra %s") % tr(String(battle.enemy.get("name", ""))) + "  ·  " + _turn_text().replace("\n", "  ·  ")
	if GameState.is_lesson_battle():
		return tr("Escola do Mago") + "  ·  " + tr(String(_lesson_def.get("name", "")))
	if battle.puzzle:
		return tr("Quebra-cabeças") + "  ·  " + tr(String(CardDB.get_puzzle(GameState.puzzle_id).get("name", "")))
	var info := "%s  ·  %s  ·  %s  ·  %s" % [
		tr(GameState.deck_def.get("name", "")),
		_turn_text().replace("\n", "  ·  "),
		tr("Selo %d") % GameState.stake if GameState.stake > 1 else tr("Selo 1"),
		tr("Seed %d") % GameState.seed_value,
	]
	if battle.climate != "":
		info += "  ·  " + tr(battle.climate_name())
	# 0.13.0: onde fica gravado (sozinho, no início de cada turno).
	info += "\n" + tr("Gravado sozinho em «%s» a cada jogada.") % GameState.slot_name(GameState.current_slot)
	var left := GameState.run_time_left_text()   # 0.19.0 (169)
	if left != "":
		info += "\n" + left
	return info

func _on_abandon() -> void:
	if GameState.puzzle_id in ["training", "training_boss"]:
		GameState.puzzle_id = ""
		SceneRouter.go("training")
		return
	if GameState.is_lesson_battle():
		GameState.puzzle_id = ""
		SceneRouter.go("school")
		return
	if battle.puzzle:
		GameState.puzzle_id = ""
		SceneRouter.go("puzzles")
		return
	GameState.abandon_run()
	SceneRouter.go("main")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		if _alive(_modal):
			if _modal.name == "PuzzleResult":   # 0.13.0: no fim do enigma, retroceder volta à lista
				GameState.puzzle_id = ""
				SceneRouter.go("puzzles")
				return
			_close_modal("")
			return
		_open_pause()
	elif what == NOTIFICATION_APPLICATION_PAUSED:
		_save_now()   # 0.15.0: a app foi para segundo plano (o Android pode fechá-la a seguir)
	elif what == NOTIFICATION_EXIT_TREE:
		Settings.set_battle_screen_on(false)
		CardView.fog_hand = false

# --- Cascata ---

## Tocar no ecrã durante a cascata salta a animação e mostra logo o total.
func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch or event is InputEventScreenDrag:
		_two_finger(event)
	if (event is InputEventMouseButton or event is InputEventKey or event is InputEventJoypadButton) and event.is_pressed():
		cancel_auto_end()   # 0.19.0 (184): qualquer toque (ou tecla, ou botão do comando) cancela o ataque automático
	if _animating and not _skip_cascade and event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_skip_cascade = true
		get_viewport().set_input_as_handled()   # o toque só salta; não abre cartas nem a pausa
		return
	# 0.12.1: tocar fora da mão larga a carta escolhida.
	if _selected_uid >= 0 and event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if not _hand_card_at((event as InputEventMouseButton).position):
			_set_selection(-1)

func _on_cascade_started(cascade: Cascade) -> void:
	EventBus.cascade_presented.emit(cascade)   # 0.13.0: a música cresce durante o ataque
	_set_selection(-1)
	_animating = true
	_refresh_lethal_glow(0)
	if _syn_lines != null:
		_syn_lines.clear()
	_last_attack_turn = battle.turn
	_set_attack_glow(false)
	if _overlay != null:
		_overlay.clear()
	_skip_cascade = false
	_last_cascade = cascade
	_s4_cascade_start()
	_fps_probe_start()
	if cascade.steps.size() >= 8:
		_tip("skip")
	end_turn_btn.disabled = true
	undo_btn.disabled = true
	enemy_hp_bar.value = enemy_hp_ghost.value   # durante a cascata a barra mostra a vida real
	for v in _hand_views.values():
		if _alive(v):
			v.delta = 0
	formation_label.text = tr("Ataque")
	power_label.text = "0"
	mult_label.text = "1"
	total_label.text = ""
	var shown_formations: Array[String] = []
	var i := 0
	var speed := Settings.anim_scale()
	var keep := summary_steps(cascade)   # 0.19.0 (189): numa cascata enorme, só os passos que mais contam
	var light := cascade_is_heavy(cascade)   # 0.19.0 (213): sem investidas, câmara nem explosões de cor por passo
	if not keep.is_empty():
		_show_banner(tr("CASCATA RESUMIDA") + "\n" + tr("%d passos · os %d maiores") % [cascade.steps.size(), keep.size()], 0.9, true)
	var si := -1
	var cam_flat := false
	for s in cascade.steps:
		si += 1
		if _skip_cascade:
			break
		if not keep.is_empty() and not keep.has(si):
			power_label.text = _num(s.power_after)
			mult_label.text = Cascade.fmt_mult(s.mult_after)
			continue
		var target := _view_for_step(s)
		var color := _color_for_step(s)
		_focus_step(target)   # 0.19.0 (118)
		if s.source_kind == "formation" and not s.retrigger:
			shown_formations.append(tr(s.source_name) + ((" (%s %d)" % [tr("nv"), s.level]) if s.level > 0 else ""))
			formation_label.text = " · ".join(PackedStringArray(shown_formations))
		if s.source_kind == "creature" and s.action == "power_add" and s.tag != "minion" and not light:
			_lunge(target)
		var creature_phase := s.source_kind in ["creature", "spell", "equipment"]   # o equipamento salta da criatura que o tem (EffectResolver._creature_steps)
		if not creature_phase and not cam_flat:   # 0.20.0 (B8): a câmara volta a 1× antes do 1.º passo que não é de criatura nem de feitiço
			cam_flat = true
			_cam_reset(true)
		if (s.source_kind == "creature" or s.source_kind == "spell") and not cam_flat and _alive(target) and target != enemy_panel and not light:
			_cam_focus(target)   # 0.16.0 (55): a câmara aproxima-se de quem dispara
		var prefix := "↻ " if s.retrigger else ""
		if s.tag == "seal":
			prefix = "◉ "
		elif s.tag == "edition" and EffectResolver.EDITIONS.has(s.source_id):
			prefix = String(EffectResolver.EDITIONS[s.source_id]["symbol"]) + " "
		elif s.tag == "minion":
			prefix = "◈ "
		elif s.source_kind == "planeswalker":
			prefix = "✦ "
		elif s.source_kind == "chain":
			prefix = "⚭ "
		_pop(target, prefix + s.label, color, s.action)   # 0.19.0 (104): +Mult e ×Mult com cor e tamanho próprios
		if s.source_card != null and s.tag != "minion" and _alive(target) and not light:
			ColorBurst.spawn(self, target.global_position + target.size / 2.0, s.source_card.data.primary_color())
		power_label.text = _num(s.power_after)
		mult_label.text = Cascade.fmt_mult(s.mult_after)
		_fire_target = _fire_for(s.power_after * s.mult_after)
		_bump(power_pill if s.action == "power_add" else mult_pill)
		Sfx.cascade_step(i, s.source_kind)
		if speed > 0.0:
			await get_tree().create_timer(maxf(0.09, 0.28 - i * 0.012) * speed).timeout
		elif i % 4 == 3:
			await get_tree().process_frame
		i += 1
	_focus_clear()
	if _skip_cascade:
		# Saltou: mostra já os números finais.
		power_label.text = _num(cascade.power)
		mult_label.text = Cascade.fmt_mult(cascade.mult)
		if not cascade.formation_ids.is_empty():
			var names: Array[String] = []
			for f in cascade.formations:
				names.append(tr(f))
			formation_label.text = " · ".join(PackedStringArray(names))
	_cam_reset()
	# Escudo do inimigo: trava os primeiros X do ataque.
	if cascade.shield > 0 and cascade.total() > 0:
		_pop(enemy_panel, "◈ " + tr("Escudo −%s") % Cascade.fmt_int(mini(cascade.shield, cascade.total())), Color(0.6, 0.8, 1.0))
	# O total conta a subir (cada vez mais depressa) e treme mais quanto mais perto do fim.
	var total := cascade.net_total()
	# 0.12.0: recorde (maior golpe de sempre) — a contagem abranda e no fim há um ecrã especial.
	var old_record := Stats.get_stat("best_attack")
	var record := not battle.puzzle and old_record > 0 and total > old_record
	var tick_time := 0.032 * (2.4 if record and Settings.motion_ok() else 1.0)
	if speed > 0.0 and total > 0 and not _skip_cascade:
		var ticks := 14
		total_label.pivot_offset = total_label.size / 2.0
		for k in range(1, ticks + 1):
			var t := float(k) / ticks
			_set_total(_num(int(round(total * t * t))))
			total_label.rotation = randf_range(-1.0, 1.0) * 0.07 * t
			total_label.scale = Vector2.ONE * (1.0 + 0.3 * t)
			Sfx.blip(mini(30, i + k))
			await get_tree().create_timer(tick_time * speed).timeout
			if _skip_cascade:
				break
		total_label.rotation = 0.0
		total_label.scale = Vector2.ONE
	_set_total(_num(total))
	_bump(total_label, 1.5)
	_particles.global_position = total_label.global_position + total_label.size / 2.0
	_particles.amount = maxi(4, FxBudget.grant(_particles, 48, 1.0))   # 0.19.0 (212): o teto comum de partículas
	if Settings.fx_ok("particles"):   # 0.19.0 (275)
		_particles.restart()
	if not _skip_cascade and total > 0:
		_attack_trails()
	AttackFx.spawn(self, total_label.global_position + total_label.size / 2.0, GameState.run_cosmetic("effect"))   # 0.19.0 (299, 300)
	Sfx.boom()
	Settings.haptic("lethal" if total >= battle.hp_left() and battle.hp_left() > 0 else "hit")   # 0.19.0 (30)
	_fire_target = _fire_for(cascade.net_total())
	_shake(6.0 + 10.0 * _fire_target)
	if record:
		await _celebrate_record(total, old_record)
	await get_tree().create_timer(_d(0.2 if _skip_cascade else 0.35)).timeout   # 0.19.0 (185): era 0.25 / 0.5 s
	_fps_probe_end()
	_animating = false
	_skip_cascade = false
	EventBus.cascade_finished.emit()

func _view_for_step(s: Cascade.Step) -> Control:
	match s.source_kind:
		"creature":
			if s.source_card != null and _board_views.has(s.source_card.uid):
				return _board_views[s.source_card.uid]
		"spell":
			if s.source_card != null and _spell_chips.has(s.source_card.uid):
				return _spell_chips[s.source_card.uid]
		"hand":
			if s.source_card != null and _hand_views.has(s.source_card.uid):
				return _hand_views[s.source_card.uid]
		"relic":
			if _relic_views.has(s.source_id):
				return _relic_views[s.source_id]
		"planeswalker":
			return _pw_panel if _alive(_pw_panel) else pw_row
		"climate":
			if s.source_card != null and _board_views.has(s.source_card.uid):
				return _board_views[s.source_card.uid]
			if _alive(_climate_chip):
				return _climate_chip
		"enchantment":
			if s.source_card != null and _ench_chips.has(s.source_card.uid) and _alive(_ench_chips[s.source_card.uid]):
				return _ench_chips[s.source_card.uid]
		"chain":
			if _alive(_chain_meter):
				return _chain_meter
		"rule":
			if s.source_card != null and _board_views.has(s.source_card.uid):
				return _board_views[s.source_card.uid]
		"weak":   # 0.15.0: o passo do Ponto fraco salta do chip do inimigo
			if _alive(_weak_chip):
				return _weak_chip
		"equipment":   # 0.18.0 (19): salta da criatura que o tem (ou da ficha do equipamento)
			var h := battle.equipment_holder(s.source_card) if s.source_card != null else null
			if h != null and _board_views.has(h.uid) and _alive(_board_views[h.uid]):
				return _board_views[h.uid]
			if s.source_card != null and _equip_chips.has(s.source_card.uid) and _alive(_equip_chips[s.source_card.uid]):
				return _equip_chips[s.source_card.uid]
	return formation_label

func _color_for_step(s: Cascade.Step) -> Color:
	if s.grow > 0:
		return COLOR_GROW
	if s.tag == "seal":
		return COLOR_SEAL
	if s.tag == "edition":
		return EffectResolver.edition_color(s.source_id)
	if s.source_kind == "climate" and s.action != "gold":
		return COLOR_CLIMATE
	if s.source_kind == "relic" and GameState.boss_relics.has(s.source_id):
		return COLOR_BOSS_RELIC
	if s.source_kind == "formation" or s.source_kind == "planeswalker":
		return COLOR_FORMATION
	if s.source_kind == "tribe":
		return COLOR_TRIBE
	if s.source_kind == "chain":
		return COLOR_CHAIN
	if s.source_kind == "enchantment":
		return COLOR_ENCHANT
	if s.source_kind == "equipment":
		return COLOR_EQUIP
	if s.source_kind == "seal_set":
		return COLOR_SEAL
	if s.source_kind == "weak":
		return COLOR_WEAK
	match s.action:
		"power_add":
			return COLOR_POWER
		"mult_mul":
			return COLOR_MULT_X
		"gold":
			return COLOR_GOLD
	return COLOR_MULT

# --- Animações ---

func _alive(view) -> bool:
	return view != null and is_instance_valid(view) and not view.is_queued_for_deletion()

## Mata o tween guardado em meta (se existir) para nunca haver dois a disputar a mesma propriedade.
func _kill_tween(view: Object, key: String) -> void:
	if view.has_meta(key):
		var old = view.get_meta(key)
		if old is Tween and (old as Tween).is_valid():
			(old as Tween).kill()

## Pop da vista + etiqueta a flutuar por cima dela.
func _pop(view: Control, text: String, color: Color, action: String = "") -> void:
	if not _alive(view):
		return
	_bump(view, 1.22)
	var label := Label.new()
	label.text = text
	var big := 1.35 if bool(Settings.opt("cascade_big")) else 1.0   # 0.19.0 (159)
	label.add_theme_font_size_override("font_size", roundi((33 if action == "mult_mul" else 26) * big))
	label.add_theme_color_override("font_color", POP_INK.get(action, Color.WHITE))
	label.add_theme_color_override("font_outline_color", color.darkened(0.35))
	label.add_theme_constant_override("outline_size", 8)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if bool(Settings.opt("cascade_bg")):   # 0.19.0 (160): uma pílula escura por trás, para se ler sobre as ilustrações
		var pill := StyleBoxFlat.new()
		pill.bg_color = Color(0.04, 0.03, 0.08, 0.72)
		pill.set_corner_radius_all(14)
		pill.content_margin_left = 10
		pill.content_margin_right = 10
		pill.content_margin_top = 0
		pill.content_margin_bottom = 2
		label.add_theme_stylebox_override("normal", pill)
	add_child(label)
	label.reset_size()
	var below := view is RelicView   # 0.20.0 (B8): nas relíquias da barra de cima, por baixo do medalhão (por cima saía do ecrã)
	var start := view.global_position + Vector2(view.size.x * 0.5 - label.size.x * 0.5, (view.size.y + 6.0) if below else -label.size.y * 0.6)
	label.global_position = start
	var tw := create_tween().set_parallel(true)
	tw.tween_property(label, "global_position:y", start.y + (14.0 if below else -46.0), _d(0.6)).set_ease(Tween.EASE_OUT)
	tw.tween_property(label, "modulate:a", 0.0, _d(0.6)).set_delay(_d(0.25))
	tw.chain().tween_callback(label.queue_free)

## Escala rápida e volta a 1. Mata o bump anterior da mesma vista para nunca ficar a meio.
func _bump(view: Control, amount: float = 1.18) -> void:
	if not _alive(view):
		return
	view.pivot_offset = view.size / 2.0
	_kill_tween(view, "bump_tw")
	view.scale = Vector2.ONE
	var tw := create_tween()
	tw.tween_property(view, "scale", Vector2.ONE * amount, _d(0.07))
	tw.tween_property(view, "scale", Vector2.ONE, _d(0.13)).set_ease(Tween.EASE_OUT)
	view.set_meta("bump_tw", tw)

## Investida: a criatura inclina-se e salta para a frente (rotação + escala, não mexe no layout).
func _lunge(view: Control) -> void:
	if not _alive(view):
		return
	view.pivot_offset = view.size / 2.0
	_kill_tween(view, "lunge_tw")
	view.rotation = 0.0
	var tw := create_tween()
	tw.tween_property(view, "rotation", -0.16, _d(0.06))
	tw.tween_property(view, "rotation", 0.0, _d(0.16)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	view.set_meta("lunge_tw", tw)

func _flash(view: Control, color: Color) -> void:
	if not _alive(view) or Settings.reduce_motion or not bool(Settings.opt("fx_flash")):
		return
	_kill_tween(view, "flash_tw")
	var base := Color.WHITE
	if view in _hand_views.values() and _discard_mode:
		base = DISCARD_TINT
	view.modulate = color
	var tw := create_tween()
	tw.tween_property(view, "modulate", base, _d(0.35))
	view.set_meta("flash_tw", tw)

func _shake(strength: float) -> void:
	if not Settings.fx_ok("shake") or Settings.shake_scale() <= 0.0:
		return   # 0.19.0 (275, 276): os abanões à parte, e com a força que escolheste
	strength *= Settings.shake_scale()
	var tw := create_tween()
	for i in 5:
		var off := Vector2(randf_range(-strength, strength), randf_range(-strength, strength)) * (1.0 - i / 5.0)
		tw.tween_property(layout, "position", _layout_base + off, 0.03)
	tw.tween_property(layout, "position", _layout_base, 0.04)

## Carta nova na mão: entra de baixo, a crescer.
func _animate_draw(view: CardView, delay: float) -> void:
	if await _animate_draw_from_pile(view, delay):   # 0.16.0 (V11): sai do grimório e vira-se
		return
	var target_alpha := view.modulate.a
	view.modulate.a = 0.0
	view.scale = Vector2(0.7, 0.7)
	await get_tree().process_frame
	if not _alive(view):
		return
	view.pivot_offset = view.size / 2.0
	var tw := create_tween().set_parallel(true)
	tw.tween_property(view, "modulate:a", target_alpha, _d(0.18)).set_delay(_d(delay))
	tw.tween_property(view, "scale", Vector2.ONE, _d(0.22)).set_delay(_d(delay)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)

## Carta jogada: um "fantasma" voa da posição na mão até ao sítio novo (tabuleiro, feitiços ou mana).
func _animate_play(card: CardInstance, from_rect: Rect2) -> void:
	if from_rect.size == Vector2.ZERO or Settings.anim_scale() <= 0.0:
		return
	await get_tree().process_frame   # deixa o layout colocar a vista nova
	var target: Control = null
	if card.data.is_creature():
		target = _board_views.get(card.uid)
	elif card.data.is_spell():
		target = _spell_chips.get(card.uid)
	elif card.data.is_enchantment():
		target = _ench_chips.get(card.uid)
	elif card.data.is_equipment():
		var h := battle.equipment_holder(card)
		target = _board_views.get(h.uid) if h != null else _equip_chips.get(card.uid)
	else:
		target = mana_label
	if not _alive(target):
		return
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = from_rect.size
	ghost.global_position = from_rect.position
	ghost.pivot_offset = ghost.size / 2.0
	var real_target := target
	if card.data.is_creature():
		real_target.modulate.a = 0.0
	var dest := target.global_position + (target.size - ghost.size) / 2.0
	var end_scale := Vector2.ONE if card.data.is_creature() else Vector2(0.35, 0.35)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(ghost, "global_position", dest, _d(0.24)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
	tw.tween_property(ghost, "scale", end_scale, _d(0.24)).set_ease(Tween.EASE_IN)
	tw.tween_property(ghost, "rotation", 0.08, _d(0.12))
	await tw.finished
	if _alive(real_target):
		real_target.modulate.a = 1.0
		if card.data.is_creature():
			_land_creature(real_target, card)   # 0.16.0 (62): assenta com um ressalto e um anel
		else:
			_bump(real_target, 1.12)
		if not card.data.is_creature():
			_flash(real_target, Color(1.8, 1.8, 1.8))
	if _alive(ghost):
		ghost.queue_free()
	Sfx.blip(0)

## Criatura morre (0.13.0): a carta desfaz-se em pó da cor dela, de cima para baixo (sem movimento: só
## desvanece).
func _animate_death(view: Control) -> void:
	if not _alive(view) or Settings.anim_scale() <= 0.0:
		return
	if view is CardView and _shatter_card(view as CardView):   # 0.16.0 (58): estala em cacos
		return
	var card: CardInstance = (view as CardView).card
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = view.size
	ghost.global_position = view.global_position
	ghost.pivot_offset = ghost.size / 2.0
	ghost.modulate = Color(1.0, 0.6, 0.55)
	var rect := Rect2(view.global_position, view.size)
	if Settings.motion_ok():
		DustFx.spawn(self, rect, CardView.COLORS.get(card.data.primary_color(), CardView.COLORS.colorless))
	var tw := create_tween().set_parallel(true)
	tw.tween_property(ghost, "modulate:a", 0.0, _d(0.45)).set_ease(Tween.EASE_IN)
	if Settings.motion_ok():
		tw.tween_property(ghost, "scale", Vector2(1.04, 0.9), _d(0.45))
		tw.tween_property(ghost, "global_position:y", ghost.global_position.y - 8.0, _d(0.45))
	tw.chain().tween_callback(ghost.queue_free)

## O inimigo encaixa o golpe: flash vermelho, abanão e o número de dano a voar do total até ele.
func _animate_enemy_hit(amount: int) -> void:
	_flash(enemy_panel, Color(2.0, 0.7, 0.7))
	_bump(enemy_panel, 0.94)
	var label := Label.new()
	label.text = "-" + Cascade.fmt_int(amount)
	label.add_theme_font_size_override("font_size", 44)
	label.add_theme_color_override("font_color", Color(1, 0.92, 0.6))
	label.add_theme_color_override("font_outline_color", Color(0.4, 0.1, 0.1))
	label.add_theme_constant_override("outline_size", 10)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(label)
	label.reset_size()
	label.global_position = total_label.global_position
	var dest := enemy_panel.global_position + Vector2(enemy_panel.size.x * 0.5 - label.size.x * 0.5, 40.0)
	var tw := create_tween()
	tw.tween_property(label, "global_position", dest, _d(0.35)).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
	tw.tween_callback(func(): _flash(enemy_hp_bar, Color(2.5, 1.5, 1.5)))
	tw.tween_property(label, "modulate:a", 0.0, _d(0.4))
	tw.tween_callback(label.queue_free)

## O inimigo contra-ataca: salta para a direita (rotação) e o ecrã abana.
## 0.12.0: as bordas do ecrã ficam vermelhas e três garras riscam-no (mais forte quanto maior o dano).
func _animate_enemy_strike(amount: int = 0) -> void:
	if not _alive(enemy_panel):
		return
	enemy_panel.pivot_offset = enemy_panel.size / 2.0
	var tw := create_tween()
	tw.tween_property(enemy_panel, "rotation", 0.06, _d(0.07))
	tw.tween_property(enemy_panel, "rotation", 0.0, _d(0.2)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	_flash(enemy_panel, Color(1.4, 1.4, 1.4))
	if amount > 0:
		if bool(Settings.opt("fx_flash")):   # 0.19.0 (275)
			DamageVignette.flash(self, float(amount) / maxf(1.0, float(GameState.player_max_hp)) * 3.0)

## Golpe final (0.12.0): cada criatura na Arena lança um cometa da sua cor ao inimigo.
func _attack_trails() -> void:
	if not _alive(enemy_panel):
		return
	var target := enemy_panel.global_position + enemy_panel.size * Vector2(0.5, 0.45)
	if _portrait != null and _alive(_portrait):
		target = _portrait.global_position + _portrait.size / 2.0
	var i := 0
	for c in battle.board:
		var view: Control = _board_views.get(c.uid)
		if not _alive(view):
			continue
		AttackTrail.fly(self, view.global_position + view.size / 2.0, target, c.data.primary_color(), i * 0.045)
		i += 1
		if i >= 8:
			break

## Banner central (ANTE N / TURNO N / VITÓRIA).
## minor = true (o "TURNO N"): não tapa um banner importante que ainda esteja no ecrã
## (despertar do boss, Coração de Vidro…).
## 0.16.0 («Faixa de luz»): com duas linhas, kicker_top = true quer dizer que a 1.ª é a pequena, por cima
## («ANTE 4» / «Turno 2», «BOSS» / nome); sem ele, a 1.ª é a grande e a 2.ª a pequena, por baixo
## («O Boss desperta» / «+2 DE ATAQUE»).
## 0.20.0 (B7): «ÚLTIMO TURNO» e, por baixo, a vida que falta ao inimigo (as duas, na Dupla), no mínimo 1,2 s.
## Não é minor, para nenhum outro o saltar. prefix vai antes do «faltam X» (o ante, ao retomar). Com um letreiro
## importante no ecrã (o boss a despertar ou o Coração de Vidro, no contra-ataque), espera que ele se leia.
func _show_last_turn_banner(prefix: String = "") -> void:
	var wait_ms: int = _banner_lock_until - Time.get_ticks_msec()
	if wait_ms > 0:
		create_tween().tween_callback(_late_last_turn_banner.bind(prefix)).set_delay(wait_ms / 1000.0)
		return
	_show_banner(tr("ÚLTIMO TURNO") + "\n" + prefix + tr("faltam %s") % _num(battle.hp_left()), _d(1.6), false, false, 1.2)

func _late_last_turn_banner(prefix: String) -> void:
	if not battle.finished and not battle.resolving and _is_last_turn():   # (já atacou: não aparece a meio da cascata)
		_show_last_turn_banner(prefix)

## 0.20.0 (B7): min_hold é o tempo mínimo, mesmo com letreiros curtos (o «ÚLTIMO TURNO» fica pelo menos 1,2 s).
func _show_banner(text: String, hold: float = 1.1, minor: bool = false, kicker_top: bool = false, min_hold: float = 0.0) -> void:
	if bool(Settings.opt("short_banners")):   # 0.19.0 (182): «Turno 2» e afins em meio segundo
		hold = minf(hold, 0.5)
	hold = maxf(hold, min_hold)
	var now := Time.get_ticks_msec()
	if minor and now < _banner_lock_until:
		return
	if not minor:
		_banner_lock_until = now + int((hold + _d(0.5)) * 1000.0)
	if _banner_tw != null and _banner_tw.is_valid():
		_banner_tw.kill()
	_banner_full = text
	var lines := text.split("\n", false)
	var main_txt := text
	var sub_txt := ""
	if lines.size() >= 2:
		main_txt = lines[1] if kicker_top else lines[0]
		sub_txt = lines[0] if kicker_top else lines[1]
	var tone := "red" if main_txt in [tr("DERROTA"), tr("NÃO CHEGOU"), tr("DERROTA NA ARENA"), tr("RITUAL INTERROMPIDO")] else "gold"
	banner.text = _banner_case(main_txt) if _band != null else text
	banner.visible = true
	_fit_banner(tone)
	banner.pivot_offset = banner.size / 2.0
	banner.scale = Vector2(0.86, 0.86)
	banner.modulate.a = 0.0
	var tw := create_tween()
	_banner_tw = tw
	tw.set_parallel(true)
	tw.tween_property(banner, "scale", Vector2.ONE, _d(0.3)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tw.tween_property(banner, "modulate:a", 1.0, _d(0.2))
	if _band != null:
		var font := banner.get_theme_font("font")
		var fs := banner.get_theme_font_size("font_size")
		var tw_main := font.get_string_size(banner.text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		var center_y := banner.get_global_rect().get_center().y - _band.global_position.y
		_band.setup(sub_txt, kicker_top, tone, center_y, tw_main)
		_band.visible = true
		_band.pivot_offset = Vector2(_band.size.x * 0.5, center_y)
		_band.scale = Vector2(0.7, 1.0)
		_band.modulate.a = 0.0
		tw.tween_property(_band, "scale", Vector2.ONE, _d(0.28)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUART)
		tw.tween_property(_band, "modulate:a", 1.0, _d(0.2))
	tw.chain().tween_interval(maxf(0.05, hold))   # 0.12.1: o tempo para ler não acelera com a velocidade
	tw.chain().tween_property(banner, "modulate:a", 0.0, _d(0.3))
	if _band != null:
		tw.parallel().tween_property(_band, "modulate:a", 0.0, _d(0.3))
	tw.chain().tween_callback(func():
		banner.visible = false
		if _band != null:
			_band.visible = false)

## «TURNO 2» → «Turno 2» (a letra do título fica mais bonita assim); as palavras pequenas ficam em minúsculas.
static func _banner_case(s: String) -> String:
	const SMALL := ["de", "da", "do", "das", "dos", "e", "em", "a", "o", "os", "as", "no", "na", "of", "the", "and", "in", "on", "to"]
	var out: Array[String] = []
	var words := s.split(" ", false)
	for i in words.size():
		var w := words[i]
		var low := w.to_lower()
		if i > 0 and low in SMALL:
			out.append(low)
		elif w.length() > 0:
			out.append(w.substr(0, 1).to_upper() + w.substr(1).to_lower())
	return " ".join(PackedStringArray(out))

## O texto grande cabe na largura do letreiro (encolhe até 44) e o dourado do shader acompanha o tamanho.
func _fit_banner(tone: String) -> void:
	if _band == null:
		return
	var font := banner.get_theme_font("font")
	var fs := 82
	while fs > 44 and font.get_string_size(banner.text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x > banner.size.x - 40.0:
		fs -= 4
	banner.add_theme_font_size_override("font_size", fs)
	var mat := banner.material as ShaderMaterial
	if mat == null:
		return
	var cap := fs * 0.68
	mat.set_shader_parameter("text_top", (banner.size.y - font.get_height(fs)) * 0.5 + font.get_ascent(fs) - cap)
	mat.set_shader_parameter("text_height", cap)
	var red := tone == "red"
	mat.set_shader_parameter("top_color", Color(1.0, 0.86, 0.82) if red else Color(1.0, 0.969, 0.839))
	mat.set_shader_parameter("mid_color", Color(1.0, 0.52, 0.44) if red else Color(0.969, 0.843, 0.498))
	mat.set_shader_parameter("low_color", Color(0.86, 0.24, 0.22) if red else Color(0.851, 0.643, 0.255))
	mat.set_shader_parameter("bottom_color", Color(0.56, 0.1, 0.12) if red else Color(0.659, 0.435, 0.122))

func _log(msg: String) -> void:
	_last_log = msg
	_sel_hint = false
	_history.append(("T%d  " % battle.turn if battle.turn > 0 else "") + msg)
	_history_kind.append("gold" if msg.contains(tr("ouro")) else ("enemy" if _enemy_log_from >= 0 and _enemy_turn_logging else "me"))   # 0.19.0 (155)
	if _history.size() > HISTORY_MAX:
		_history.pop_front()
		_history_kind.pop_front()
	log_label.text = msg
	log_label.modulate = Color(1, 0.85, 0.5)
	create_tween().tween_property(log_label, "modulate", Color.WHITE, 0.8)

# ---------------------------------------------------------------------------
# 0.10.0 — widgets novos
# ---------------------------------------------------------------------------

func _make_010_widgets() -> void:
	# Modo compacto: o tabuleiro encolhe com as cartas (sobra altura para ecrãs pequenos).
	if Settings.compact:
		(board_box.get_parent() as Control).custom_minimum_size.y = CardView.SIZE_COMPACT.y + 4
	# Fundo do ato (com as partículas do clima) por cima do fundo liso.
	var bg: Control = get_node("Background")
	_backdrop = BattleBackdrop.new()
	add_child(_backdrop)
	move_child(_backdrop, bg.get_index() + 1)
	# Retrato do inimigo no lugar do emblema com a inicial.
	emblem.visible = false
	_portrait = EnemyPortrait.new()
	_portrait.custom_minimum_size = Vector2(60, 60)
	_portrait.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var name_row: Control = emblem.get_parent()
	name_row.add_child(_portrait)
	name_row.move_child(_portrait, 0)
	# Turnos em pips no lugar das duas linhas de texto (o resto está na pausa).
	turn_label.visible = false
	_turn_pips = TurnPips.new()
	_turn_pips.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var top: Control = turn_label.get_parent()
	top.add_child(_turn_pips)
	top.move_child(_turn_pips, turn_label.get_index())
	# Encantamentos em jogo: à esquerda na faixa dos feitiços; o medidor da Cadeia à direita.
	_ench_box = HBoxContainer.new()
	_ench_box.add_theme_constant_override("separation", 6)
	spell_strip.add_child(_ench_box)
	spell_strip.move_child(_ench_box, 0)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	spell_strip.add_child(spacer)
	_chain_meter = ChainMeter.new()
	_chain_meter.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_chain_meter.tooltip_text = tr("Cadeia de cor")
	spell_strip.add_child(_chain_meter)
	# Escudo e lacaios do inimigo: por baixo da barra de vida.
	_defense_row = HFlowContainer.new()
	_defense_row.add_theme_constant_override("h_separation", 6)
	_defense_row.add_theme_constant_override("v_separation", 4)
	var vbox: Control = enemy_hp_label.get_parent()
	vbox.add_child(_defense_row)
	vbox.move_child(_defense_row, enemy_hp_label.get_index() + 1)
	# Histórico: tocar na linha de log mostra as últimas 30 ações.
	log_label.mouse_filter = Control.MOUSE_FILTER_STOP
	log_label.tooltip_text = tr("Toca para ver o histórico")
	log_label.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed:
			_open_history())

func _setup_backdrop() -> void:
	if _backdrop != null:
		_backdrop.setup(GameState.act_of_ante(GameState.ante) if not battle.puzzle else 1, battle.climate)
		_backdrop.modulate = CALM_BG if bool(Settings.opt("calm_bg")) else Color.WHITE   # 0.19.0 (119)
	if String(battle.climate) != "" and not battle.puzzle:
		Stats.mark_seen("climates", String(battle.climate))   # 0.16.1: para a Galeria (Lugares)

## Arquétipo do retrato: o do inimigo (enemies.json "portrait"); bonecos de treino e enigmas.
func _portrait_archetype() -> String:
	var a := String(battle.enemy.get("portrait", ""))
	if a != "":
		return a
	if battle.puzzle:
		return "dummy"
	var def := CardDB.enemy_def(String(battle.enemy.get("id", "")))
	return String(def.get("portrait", "brute"))

func _refresh_pips() -> void:
	if _turn_pips != null:
		_turn_pips.set_turns(battle.turn, battle.max_turns, battle.extra_turns, _is_last_turn())   # 0.20.0 (B7)

func _refresh_chain_meter() -> void:
	if _chain_meter == null:
		return
	var info := EffectResolver.chain_of(battle.attackers())
	_last_preview_chain = int(info["len"])
	_chain_meter.set_chain(int(info["len"]), String(info["color"]), EffectResolver.chain_needed(), battle.max_creatures())
	_chain_meter.visible = not battle.board.is_empty() and bool(Settings.opt("hud_chain"))   # 0.19.0 (141)

## Escudo (% da vida máxima travada por ataque) e lacaios (●● = golpes que ainda aguentam).
func _refresh_defense() -> void:
	if _defense_row == null:
		return
	_build_defense_chips(false)
	# 0.18.0: as defesas ficam numa só linha — se as palavras não couberem, só os ícones e os números (tocar
	# na linha explica tudo). Em duas linhas, o painel do inimigo empurrava a mão para fora do ecrã.
	var room := _defense_room()
	_defense_row.set_meta("room", room)
	if _defense_row.get_child_count() > 1 and _defense_need() > room:
		_build_defense_chips(true)
	_defense_row.visible = _defense_row.get_child_count() > 0
	if not _defense_row.resized.is_connected(_on_defense_resized):
		_defense_row.resized.connect(_on_defense_resized)
	_defense_row.mouse_filter = Control.MOUSE_FILTER_STOP
	if _defense_row.visible and not _defense_row.gui_input.is_connected(_on_defense_tap):
		_defense_row.gui_input.connect(_on_defense_tap)

## Os chips das defesas (escudo, lacaios, ponto fraco, ritual); `short`: sem as palavras.
func _build_defense_chips(short: bool) -> void:
	for c in _defense_row.get_children():
		_defense_row.remove_child(c)
		c.queue_free()
	var pct := float(battle.enemy.get("shield_pct", 0))
	if pct > 0.0:
		var stxt := ("%d%%" % int(pct)) if short else (tr("Escudo %d%%") % int(pct))
		var shield_chip := _intent_chip([["shield", Color(0.6, 0.8, 1.0), stxt]], Color(0.14, 0.2, 0.32))
		shield_chip.name = "ShieldChip"
		_defense_row.add_child(shield_chip)
	if not battle.minions.is_empty():
		var dots := ""
		for h in battle.minions:
			dots += "●".repeat(h) + " "
		var mtxt := dots.strip_edges() if short else tr("Lacaios") + " " + dots.strip_edges()
		var minion_chip := _intent_chip([["creature", Color(0.9, 0.75, 0.55), mtxt]], Color(0.26, 0.18, 0.12))
		minion_chip.name = "MinionChip"
		_defense_row.add_child(minion_chip)
	# 0.15.0: Ponto fraco (a cor) e o ritual do boss com a contagem.
	_weak_chip = null
	_ritual_chip = null
	if battle.weak_color != "" and not battle.puzzle:
		_weak_chip = _weak_point_chip(battle.weak_color, short)
		_defense_row.add_child(_weak_chip)
	var oc := _objective_chip(short)   # 0.18.0 (24): Emboscada, Cerco ou Fuga
	if oc != null:
		_defense_row.add_child(oc)
	if not battle.ritual.is_empty():
		var parts: Array = [["hourglass", COLOR_RITUAL, str(int(battle.ritual.get("turns", 0)))]]
		if not short:
			parts.append(["", Color.WHITE, tr("Ritual")])
		_ritual_chip = _intent_chip(parts, Color(0.24, 0.12, 0.32))
		_ritual_chip.name = "RitualChip"
		_defense_row.add_child(_ritual_chip)
		_refresh_ritual_glow()
	_defense_row.set_meta("short", short)

## A 1.ª escolha (curto ou com palavras) usa uma largura estimada: quando a linha ganha a largura a sério, volta
## a escolher.
func _on_defense_resized() -> void:
	if _defense_row == null or _defense_row.size.x <= 40.0:
		return
	if absf(_defense_row.size.x - float(_defense_row.get_meta("room", 0.0))) > 2.0:
		_refresh_defense.call_deferred()

## Largura que os chips das defesas pedem numa só linha.
func _defense_need() -> float:
	var need := 0.0
	for c in _defense_row.get_children():
		if c is Control:
			need += (c as Control).get_combined_minimum_size().x
	return need + 6.0 * maxf(0.0, _defense_row.get_child_count() - 1)

## Largura que a linha das defesas tem (antes do 1.º arranjo, a da coluna menos as margens do painel).
func _defense_room() -> float:
	if _defense_row.size.x > 40.0:
		return _defense_row.size.x
	var col := enemy_panel.get_parent() as Control
	return maxf(col.size.x, col.custom_minimum_size.x) - 24.0

func _on_defense_tap(ev: InputEvent) -> void:
	if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed and not SceneRouter.has_overlay():
		Sfx.select()
		var lines: Array[String] = []
		if battle.objective != "":   # 0.18.0 (24)
			lines.append(objective_text(battle.objective))
		if float(battle.enemy.get("shield_pct", 0)) > 0.0:
			lines.append(tr("Escudo: trava os primeiros %s de cada ataque (volta a encher todos os turnos).") % Cascade.fmt_int(battle.shield_amount()))
		if not battle.minions.is_empty():
			lines.append(tr("Lacaios: cada um trava o Poder base de uma das primeiras criaturas da Arena (as habilidades disparam na mesma) e cai ao fim de 2 bloqueios. Põe as criaturas fracas à frente."))
		if battle.weak_color != "" and not battle.puzzle:   # 0.15.0
			var per := BattleManager.WEAK_MULT * (2.0 if GameState.relic_passive("weak_double") > 0.0 else 1.0)
			lines.append(tr("Ponto fraco: %s. Cada carta dessa cor no ataque dá +%s Mult, num passo próprio da cascata.") % [tr(CardZoom.COLOR_NAMES.get(battle.weak_color, battle.weak_color)), Cascade.fmt_mult(per)])
		if not battle.ritual.is_empty():
			lines.append(tr("Ritual: %s daqui a %d turno(s). Um golpe de %s ou mais (15 %% da vida máxima) interrompe-o.") % [tr(String(battle.ritual.get("text", ""))), int(battle.ritual.get("turns", 0)), Cascade.fmt_int(battle.ritual_break_amount())])
		CardZoom.show_text(tr(battle.enemy.name), "\n\n".join(PackedStringArray(lines)), tr("Defesas do inimigo"), Color(0.6, 0.8, 1.0))

## Encantamentos em jogo: fichas na faixa dos feitiços (tocar abre a carta).
func _refresh_enchantments() -> void:
	if _ench_box == null:
		return
	for c in _ench_box.get_children():
		_ench_box.remove_child(c)
		c.queue_free()
	_ench_chips.clear()
	for en in battle.enchantments:
		var chip := _make_chip(en, "✧ ∞ " + en.data.display_name())
		if chip.has_meta("mini"):
			_ench_box.add_child(chip)
			_ench_chips[en.uid] = chip
			continue
		var style: StyleBoxFlat = chip.get_theme_stylebox("panel").duplicate()
		style.set_border_width_all(2)
		style.border_color = COLOR_ENCHANT
		chip.add_theme_stylebox_override("panel", style)
		chip.mouse_filter = Control.MOUSE_FILTER_STOP
		chip.gui_input.connect(func(ev: InputEvent):
			if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed and not SceneRouter.has_overlay():
				Sfx.select()
				CardZoom.show_card(en))
		_ench_box.add_child(chip)
		_ench_chips[en.uid] = chip
	_add_equipment_chips()   # 0.18.0 (19): os equipamentos a seguir aos encantamentos
	_refresh_ench_sep()   # 0.19.0 (115)
	if spell_hint != null:
		spell_hint.visible = _strip_empty()
	_refresh_strip_look()
	_fit_chips()

## 0.19.0 (155, 156): o histórico com o turno em cada linha e filtros (tudo, só tu, só o inimigo, só o ouro).
## 0.20.0 (B10): `kind` é o filtro com que abre ("all", "me", "enemy" ou "gold").
func _open_history(kind: String = "all") -> void:
	if SceneRouter.has_overlay() or _history.is_empty():
		return
	Sfx.select()
	var o := Control.new()
	o.name = "HistoryLog"
	o.set_anchors_preset(Control.PRESET_FULL_RECT)
	o.mouse_filter = Control.MOUSE_FILTER_STOP
	o.add_child(UiKit.dim(0.85))
	SceneRouter.show_overlay(o)
	var body := UiKit.window(o, 820, tr("Histórico da batalha"), Color(0.75, 0.72, 0.88), func(): UiKit.close_animated(o),
		tr("Últimas %d ações (a mais recente em cima)") % _history.size())
	var text := UiKit.label("", 17, Color(0.92, 0.9, 0.97), true)
	text.name = "Lines"
	text.max_lines_visible = 16
	var chips := UiKit.chip_row([["all", tr("Tudo")], ["me", tr("Só tu")], ["enemy", tr("Só o inimigo")], ["gold", tr("Só o ouro")]], kind,
		func(id: String): text.text = history_text(id))
	body.add_child(chips)
	body.add_child(text)
	text.text = history_text(kind)
	o.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and not ev.pressed and not (body.get_meta("panel") as Control).get_global_rect().has_point(ev.global_position):
			UiKit.close_animated(o))

func history_text(kind: String) -> String:
	var out: Array[String] = []
	for i in range(_history.size() - 1, -1, -1):
		if kind == "all" or (i < _history_kind.size() and _history_kind[i] == kind):
			out.append(_history[i])
	return "\n".join(PackedStringArray(out)) if not out.is_empty() else tr("Nada deste tipo nesta batalha.")

## Inclina a carta arrastada para o lado para onde o dedo a puxa (e a sombra acompanha).
func _tilt_ghost(pos: Vector2) -> void:
	var vx := pos.x - _drag_last_x
	_drag_last_x = pos.x
	if Settings.motion_ok():
		_drag_ghost.rotation = lerpf(_drag_ghost.rotation, clampf(vx * 0.012, -0.28, 0.28), 0.35)
	if _alive(_drag_shadow):
		_drag_shadow.global_position = _drag_ghost.global_position + Vector2(10, 14)
		_drag_shadow.rotation = _drag_ghost.rotation
		_drag_shadow.pivot_offset = _drag_shadow.size / 2.0

# --- Fichas, encantamentos, Reforço, Reação, escudo ---

func _on_token_created(card: CardInstance) -> void:
	_log(tr("Uma Ficha de %s entra na Arena.") % card.data.display_name())
	if not _animating:
		_refresh_board()
		_refresh_preview()

func _on_enchantment_played(card: CardInstance) -> void:
	_log(tr("%s fica em jogo.") % card.data.display_name())
	_refresh_enchantments()

func _on_card_kicked(card: CardInstance) -> void:
	_log(tr("%s com Reforço!") % card.data.display_name())

func _on_shield_hit(_amount: int) -> void:
	pass   # o número aparece na cascata (antes do total)

func _on_reaction_played(card: CardInstance) -> void:
	Sfx.boom()
	Settings.vibrate(40)
	_show_banner(tr("REAÇÃO") + "\n" + card.data.display_name(), 0.9, false, true)
	_log(tr("Reagiste com %s.") % card.data.display_name())
	_refresh_all()

## O inimigo vai contra-atacar e tens uma Mágica com Reação que podes pagar: reages ou não.
func _on_reaction_window(options: Array) -> void:
	var dmg := battle.enemy_attack()
	var box := _open_modal(tr("REAÇÃO"), tr("%s vai atacar com %d. Reages com a mana que sobrou (%d)?") % [tr(battle.enemy.name), dmg, battle.mana_available])
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	for c in options:
		var v: CardView = CARD_VIEW.instantiate()
		row.add_child(v)
		v.setup(c)
		v.pressed.connect(func(card: CardInstance): _close_modal(card))
		v.long_pressed.connect(func(card: CardInstance): CardZoom.show_card(card))
	var skip := UiKit.button(tr("NÃO REAGIR"), 54, 20)
	skip.custom_minimum_size.x = 260
	skip.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	skip.pressed.connect(func(): _close_modal(null))
	box.add_child(skip)
	_modal.set_meta("reaction", true)
	Sfx.select()

## Reforço: jogar normal ou pagar mais mana pelo efeito extra. Devolve "plain", "kick" ou "" (VOLTAR, tocar fora ou retroceder: a carta fica na mão).
func _ask_kicker(card: CardInstance) -> String:
	var base := battle.effects.cost_of(card)
	var extra := battle.kicker_cost(card)
	var box := _open_modal(card.data.display_name(), tr("Reforço: %s.") % card.data.display_kicker_text())
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 14)
	box.add_child(row)
	var plain := UiKit.button(tr("JOGAR (%d)") % base, 58, 20)
	plain.custom_minimum_size.x = 220
	plain.pressed.connect(func(): _close_modal("plain"))
	row.add_child(plain)
	var kick := UiKit.button(tr("COM REFORÇO (%d)") % (base + extra), 58, 20, Color(0.45, 0.32, 0.12), UiKit.GOLD)
	kick.custom_minimum_size.x = 260
	kick.pressed.connect(func(): _close_modal("kick"))
	row.add_child(kick)
	var gain_plain := battle.preview_play(card)
	var gain_kick := battle.preview_play(card, true)
	if gain_kick != gain_plain:
		var hint := UiKit.label(tr("Ataque: +%s normal · +%s com Reforço") % [Cascade.fmt_int(gain_plain), Cascade.fmt_int(gain_kick)], 17, UiKit.TEXT_DIM)
		hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(hint)
	# A5 (0.20.0, BJ13): VOLTAR, igual ao de «Equipar quem?»; tocar fora da janela faz o mesmo. A carta fica na mão.
	var back_btn := UiKit.button(tr("VOLTAR"), 50, 18)
	back_btn.name = "KickerBack"
	back_btn.custom_minimum_size.x = 180
	back_btn.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	back_btn.pressed.connect(_close_modal.bind(""))
	box.add_child(back_btn)
	_modal.gui_input.connect(_on_kicker_outside.bind(box.get_parent()))
	var res = await _modal_result()
	return String(res) if res is String else ""

## A5: largar o dedo fora do painel do Reforço é VOLTAR. O largar de um arrasto que abriu a janela não chega aqui: a
## CardView aceita-o (accept_event) antes de avisar a batalha.
func _on_kicker_outside(event: InputEvent, panel: Control) -> void:
	var mb := event as InputEventMouseButton
	if mb != null and not mb.pressed and mb.button_index == MOUSE_BUTTON_LEFT and not panel.get_global_rect().has_point(mb.global_position):
		_close_modal("")

## Aviso com "não avisar mais". Devolve "yes", "no" ou "never".
func _ask(title: String, body: String, yes_text: String) -> String:
	var box := _open_modal(title, body)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	var yes := UiKit.button(yes_text, 56, 20, UiKit.PRIMARY.darkened(0.2), UiKit.PRIMARY)
	yes.custom_minimum_size.x = 200
	yes.pressed.connect(func(): _close_modal("yes"))
	row.add_child(yes)
	var no := UiKit.button(tr("VOLTAR"), 56, 20)
	no.custom_minimum_size.x = 160
	no.pressed.connect(func(): _close_modal("no"))
	row.add_child(no)
	UiKit.hand_mirror(row)   # 0.19.0 (25)
	var never := UiKit.button(tr("NÃO AVISAR MAIS"), 48, 16)
	never.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	never.custom_minimum_size.x = 240
	never.pressed.connect(func(): _close_modal("never"))
	box.add_child(never)
	var res = await _modal_result()
	return String(res) if res is String else "no"

## Janela modal da batalha (por cima do layout; o botão "retroceder" fecha-a como "não").
func _open_modal(title: String, body: String) -> VBoxContainer:
	if _alive(_modal):
		_close_modal(null)
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	root.z_index = 60   # 0.13.0: por cima das setas, das etiquetas e das dicas
	root.add_child(UiKit.dim(0.6))
	add_child(root)
	_modal = root
	var panel := UiKit.centered_panel(root, 640, UiKit.BG, UiKit.GOLD)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	panel.add_child(box)
	var t := UiKit.label(title, 30, UiKit.GOLD)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(t)
	if body != "":
		var b := UiKit.label(body, 19, Color.WHITE, true)
		b.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(b)
	UiKit.pop_in(panel)
	return box

signal _modal_closed(result)

func _modal_result():
	return await _modal_closed

func _close_modal(result) -> void:
	if not _alive(_modal):
		return
	var was_reaction := bool(_modal.get_meta("reaction", false))
	_modal.queue_free()
	_modal = null
	Sfx.select()
	if was_reaction:
		EventBus.reaction_done.emit(result if result is CardInstance else null)
	else:
		_modal_closed.emit(result)

# --- Escola do Mago (0.11.0) ---

var _lesson_def: Dictionary = {}
var _lesson_reacted := false
var _lesson_panel: Control

func _on_lesson_reaction(_card: CardInstance) -> void:
	_lesson_reacted = true

## Explicação da lição por cima da batalha (fica até a fecharem).
func _show_lesson_panel(def: Dictionary) -> void:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.12, 0.1, 0.2, 0.96), 12, Color(0.5, 0.85, 0.55), 2, 12))
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	panel.z_index = 40
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(row)
	var col := VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_theme_constant_override("separation", 4)
	row.add_child(col)
	col.add_child(UiKit.label(tr("LIÇÃO · %s") % tr(String(def.get("name", ""))), 17, Color(0.6, 0.95, 0.65)))
	var intro := UiKit.label(tr(String(def.get("intro", ""))), 16, Color.WHITE, true)
	intro.custom_minimum_size.x = 600
	col.add_child(intro)
	col.add_child(UiKit.label(tr("Objetivo: %s") % tr(String(def.get("goal", ""))), 16, UiKit.GOLD, true))
	var x := UiKit.label("✕", 18, UiKit.TEXT_DIM)
	x.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	row.add_child(x)
	panel.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.pressed and is_instance_valid(panel):
			panel.queue_free())
	add_child(panel)
	_lesson_panel = panel
	await get_tree().process_frame
	if is_instance_valid(panel):
		panel.position = Vector2((get_viewport_rect().size.x - panel.size.x) / 2.0, 66.0)

## Fim da lição: concluída (próxima lição ou voltar à Escola) ou falhada (repetir).
func _lesson_result(ok: bool) -> void:
	await get_tree().create_timer(_d(0.6)).timeout
	if not is_inside_tree():
		return
	if is_instance_valid(_lesson_panel):
		_lesson_panel.queue_free()
	var id := GameState.puzzle_id
	var next_id := ""
	var idx := -1
	for i in CardDB.lessons.size():
		if String(CardDB.lessons[i].get("id", "")) == id:
			idx = i
	if idx >= 0 and idx + 1 < CardDB.lessons.size():
		next_id = String(CardDB.lessons[idx + 1].get("id", ""))
	if ok:
		GameState.mark_lesson_done(id)
		Sfx.boom()
	var box := _open_modal(tr("LIÇÃO CONCLUÍDA!") if ok else tr("QUASE!"), tr(String(_lesson_def.get("name", ""))) + "\n" + (tr("Muito bem.") if ok else tr("Objetivo: %s") % tr(String(_lesson_def.get("goal", "")))))
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	var options: Array = []
	if ok and next_id != "":
		options.append(["PRÓXIMA LIÇÃO", next_id])
	if not ok:
		options.append(["REPETIR", id])
	options.append(["ESCOLA", ""])
	for opt in options:
		var target := String(opt[1])
		var b := UiKit.button(tr(String(opt[0])), 56, 20, UiKit.PRIMARY.darkened(0.2) if target != "" else UiKit.BG_LIGHT, Color(0, 0, 0, 0))
		b.custom_minimum_size.x = 210
		b.pressed.connect(func():
			Sfx.select()
			if target != "":
				GameState.start_lesson(target)
				SceneRouter.go("battle")
			else:
				GameState.puzzle_id = ""
				SceneRouter.go("school"))
		row.add_child(b)

## Fim do turno de Treino: o dano do ataque e três saídas (repetir, editar, sair).
func _training_result() -> void:
	await get_tree().create_timer(_d(0.6)).timeout
	if not is_inside_tree():
		return
	var dmg := battle.best_hit
	var box := _open_modal(tr("TREINO"), tr("Dano do ataque: %s") % Cascade.fmt_int(dmg))
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	for opt in [["REPETIR", "battle"], ["EDITAR", "training"], ["SAIR", "main"]]:
		var b := UiKit.button(tr(String(opt[0])), 56, 20, UiKit.PRIMARY.darkened(0.2) if opt[1] == "battle" else UiKit.BG_LIGHT, Color(0, 0, 0, 0))
		b.custom_minimum_size.x = 180
		var target := String(opt[1])
		b.pressed.connect(func():
			Sfx.select()
			if target == "battle":
				GameState.start_training()
			else:
				GameState.puzzle_id = ""
			SceneRouter.go(target))
		row.add_child(b)
	Sfx.boom()

## 0.17.0 (83, 84): andar da Torre ou boss da Corrida vencido — sem ouro nem loja: o ecrã da Torre (o prémio
## do andar, ou o boss seguinte com 30 % de cura). O último boss da Corrida acaba a run (vitória).
func _side_mode_victory() -> void:
	if _portrait != null and _alive(_portrait):
		_portrait.charging = false
		if not (bool(battle.enemy.get("boss", false)) and _shatter_portrait()):
			_portrait.defeat()
	SceneRouter.hit_stop(0.35, 0.3)
	CelebrationFx.play(self, get_viewport_rect(), "confetti")
	var last_words := _boss_line("defeat")
	if last_words != "":
		_say(last_words, 2.0)
	var extra := _d(1.0) if last_words != "" else 0.0
	var side_gold := Economy.side_gold_for_win()   # 0.19.0 (87, 88): o ouro já entrou no fim da batalha
	if side_gold > 0:
		SceneRouter.toast(tr("+%d ouro") % side_gold, 1.8)
	if GameState.mode == "tower":
		_show_banner(tr("ANDAR %d VENCIDO") % GameState.ante, 1.0)
		Sfx.boom()
		await get_tree().create_timer(_d(0.9) + extra).timeout
		GameState.tower_prepare_offer()
		GameState.save_run({}, "tower")
		SceneRouter.go("tower")
		return
	GameState.rush_boss_won(battle.turn)
	if GameState.ante >= GameState.max_ante:
		GameState.last_victory = true
		EventBus.run_ended.emit(true)
		_show_banner(tr("CORRIDA COMPLETA"), 1.2)
		await get_tree().create_timer(_d(1.1) + extra).timeout
		SceneRouter.go("run_over")
		return
	_show_banner(tr("BOSS %d DE %d VENCIDO") % [GameState.ante, GameState.max_ante], 1.0)
	Sfx.boom()
	await get_tree().create_timer(_d(0.9) + extra).timeout
	GameState.rush_next()
	GameState.save_run({}, "tower")
	SceneRouter.go("tower")

## 0.17.0 (88): fim do Treino contra um boss — o resultado (turnos, vida, maior golpe) e REPETIR / EDITAR / SAIR.
func _training_boss_result(victory: bool) -> void:
	var foe := tr(String(battle.enemy.get("name", "")))
	if victory:
		if _portrait != null and _alive(_portrait):
			_portrait.charging = false
			if not _shatter_portrait():
				_portrait.defeat()
		CelebrationFx.play(self, get_viewport_rect(), "confetti")
		_show_banner(tr("BOSS VENCIDO"), 1.0)
	else:
		CelebrationFx.play(self, get_viewport_rect(), "ash")
		_show_banner(tr("DERROTA"), 1.0)
	await get_tree().create_timer(_d(1.1)).timeout
	if not is_inside_tree():
		return
	var line := (tr("Venceste %s em %d turno(s), com %d de vida.") % [foe, battle.turn, GameState.player_hp]) if victory \
		else tr("%s ficou com %d %% da vida.") % [foe, int(round(100.0 * float(battle.enemy.get("hp", 0)) / maxf(1.0, float(battle.enemy.get("max_hp", 1)))))]
	var box := _open_modal(tr("TREINO CONTRA BOSS"), line + "\n" + tr("Maior golpe: %s") % Cascade.fmt_int(battle.best_hit))
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	for opt in [["REPETIR", "battle"], ["EDITAR", "training"], ["SAIR", "main"]]:
		var b := UiKit.button(tr(String(opt[0])), 56, 20, UiKit.PRIMARY.darkened(0.2) if opt[1] == "battle" else UiKit.BG_LIGHT, Color(0, 0, 0, 0))
		b.custom_minimum_size.x = 180
		var target := String(opt[1])
		b.pressed.connect(func():
			Sfx.select()
			if target == "battle":
				GameState.start_boss_training()
			else:
				GameState.puzzle_id = ""
			SceneRouter.go(target))
		row.add_child(b)
	if victory:
		Sfx.victory()
	else:
		Sfx.defeat()


# ---------------------------------------------------------------------------
# 0.12.0 — conforto na batalha: velocidade (▶▶), ordenar a mão, melhor ordem da Arena, dica de
# jogada (Fácil), grimório com probabilidades e o ecrã do novo recorde.
# ---------------------------------------------------------------------------

var _speed_btn: Button
var _sort_btn: Button
var _order_btn: Button
var _hint_btn: Button
var _hint_tw: Tween

func _make_0120_widgets() -> void:
	# Na barra de cima, ao lado dos turnos: velocidade das animações e ordem da mão.
	var top: Control = turn_label.get_parent()
	_speed_btn = UiKit.button("", 48, 16)
	_speed_btn.name = "SpeedBtn"
	_speed_btn.custom_minimum_size.x = 100
	_speed_btn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_speed_btn.pressed.connect(_on_speed)
	top.add_child(_speed_btn)
	top.move_child(_speed_btn, _turn_pips.get_index() + 1)
	# 0.19.0 (271): silenciar num toque, na barra de cima.
	_mute_btn = UiKit.button("", 48, 16)
	_mute_btn.name = "MuteBtn"
	_mute_btn.custom_minimum_size.x = 52
	_mute_btn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_mute_btn.tooltip_text = tr("Silenciar ou voltar a ligar o som")
	_mute_icon = CardIcon.new("speaker_off" if Settings.is_muted() else "speaker", Color(0.88, 0.85, 0.96), 22.0)
	_mute_icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mute_icon.position = Vector2(15, 13)
	_mute_btn.add_child(_mute_icon)
	_mute_btn.pressed.connect(func():
		Settings.toggle_mute()
		_mute_icon.kind = "speaker_off" if Settings.is_muted() else "speaker"
		_mute_icon.queue_redraw())
	top.add_child(_mute_btn)
	top.move_child(_mute_btn, _speed_btn.get_index() + 1)
	_sort_btn = UiKit.button("", 48, 14)
	_sort_btn.name = "SortBtn"
	_sort_btn.custom_minimum_size.x = 118
	_sort_btn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_sort_btn.pressed.connect(_on_sort)
	top.add_child(_sort_btn)
	top.move_child(_sort_btn, _speed_btn.get_index() + 1)
	# Nas pontas da linha do cálculo: MELHOR ORDEM (à esquerda) e DICA (à direita, só no Fácil).
	var calc: HBoxContainer = power_pill.get_parent()
	var left := _calc_slot()
	calc.add_child(left)
	calc.move_child(left, 0)
	_order_btn = UiKit.button(tr("MELHOR\nORDEM"), 52, 14, UiKit.BG_LIGHT)
	_order_btn.name = "BestOrder"
	_order_btn.custom_minimum_size.x = 112
	_order_btn.pressed.connect(_on_best_order)
	left.add_child(_order_btn)
	var right := _calc_slot()
	calc.add_child(right)
	_hint_btn = UiKit.button(tr("DICA"), 52, 16, UiKit.BG_LIGHT, UiKit.GOLD)
	_hint_btn.name = "HintBtn"
	_hint_btn.custom_minimum_size.x = 112
	_hint_btn.pressed.connect(_on_hint)
	right.add_child(_hint_btn)
	banner.z_index = 5   # o letreiro (recorde, boss, turno) fica por cima das dicas
	# Cosméticos: tapete da Arena e molduras animadas (só na batalha).
	(board_box.get_parent() as Control).add_theme_stylebox_override("panel", ArenaMat.make(GameState.run_cosmetic("mat")))   # 0.19.0 (299, 300)
	CardView.frame_anim_on = true
	tree_exiting.connect(func(): CardView.frame_anim_on = false)
	for n in [_speed_btn, _sort_btn, _order_btn, _hint_btn]:
		(n as Node).owner = self
		(n as Node).unique_name_in_owner = true
	_refresh_tool_buttons()

## Lugar numa ponta da linha do cálculo, com o botão ao centro (as duas pontas crescem por igual, por
## isso o cálculo fica sempre ao centro, haja botões ou não).
func _calc_slot() -> Control:
	var slot := CenterContainer.new()
	slot.custom_minimum_size = Vector2(112, 52)
	slot.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	slot.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	slot.mouse_filter = Control.MOUSE_FILTER_PASS
	return slot

const SPEED_ICONS := {"normal": "▶  1×", "fast": "▶▶  2×", "instant": "▶▶  MÁX"}

func _refresh_tool_buttons() -> void:
	if _speed_btn == null:
		return
	_speed_btn.text = tr(String(SPEED_ICONS.get(Settings.anim_speed, "▶  1×")))
	_speed_btn.add_theme_color_override("font_color", UiKit.GOLD if Settings.anim_speed != "normal" else Color.WHITE)
	var sort_name := tr(String(Settings.HAND_SORT_NAMES.get(Settings.hand_sort, "Como vieram"))).to_lower()
	if _sort_btn.get_parent() == self:   # 0.16.0: junto da mão, só com o ícone
		_sort_btn.text = ""
		_sort_btn.tooltip_text = tr("ORDENAR") + ": " + sort_name
	else:
		_sort_btn.text = tr("ORDENAR") + "\n" + sort_name
	_order_btn.visible = battle.board.size() >= 2 and not battle.finished
	_order_btn.disabled = _animating or battle.resolving
	_hint_btn.visible = (GameState.difficulty == "facil" or bool(Settings.opt("hint_all"))) and Settings.play_hints and not battle.puzzle and not battle.finished   # 0.19.0 (281)
	_hint_btn.disabled = _animating or battle.resolving

## ▶ → ▶▶ → ▶▶▶: a mesma velocidade das Configurações, à mão durante a batalha.
func _on_speed() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	Settings.cycle_speed()
	Settings.save_settings()
	_refresh_tool_buttons()
	SceneRouter.toast(tr("Animações: %s") % Settings.speed_label())

func _on_sort() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	Settings.cycle_hand_sort()
	_refresh_hand()
	_refresh_tool_buttons()
	if _sort_btn != null and _sort_btn.get_parent() == self:
		_warn(tr("Ordenar a mão: %s") % tr(String(Settings.HAND_SORT_NAMES.get(Settings.hand_sort, "Como vieram"))).to_lower(), UiKit.GOLD, 1.4, true)

## Põe as criaturas na ordem que dá o maior ataque (pode desfazer-se).
func _on_best_order() -> void:
	if SceneRouter.has_overlay() or _animating or battle.resolving or battle.finished:
		return
	var r := battle.best_board_order()
	var gain := int(r["total"]) - int(r["current"])
	if gain <= 0:
		Sfx.select()
		_log(tr("A Arena já está na melhor ordem."))
		return
	_push_undo()
	if battle.apply_board_order(r["order"]):
		if not battle.puzzle:
			Stats.add("best_order_used")
		Sfx.boom()
		_refresh_board()
		_refresh_preview()
		_log(tr("Melhor ordem: +%s de dano.") % Cascade.fmt_int(gain))
		for v in _board_views.values():
			if _alive(v):
				_bump(v, 1.06)
		if not battle.puzzle:
			GameState.save_run(battle.to_dict(), "battle")

## Dica (Fácil): realça a melhor jogada agora.
func _on_hint() -> void:
	if SceneRouter.has_overlay() or _animating or battle.resolving or battle.finished:
		return
	Sfx.select()
	var h := battle.play_hint()
	if h.is_empty():
		return
	Stats.add("hints_used")
	var target: Control = null
	match String(h.get("kind", "")):
		"attack":
			target = end_turn_btn
			_log(tr("Dica: ataca agora — é letal!") if bool(h.get("lethal", false)) else tr("Dica: não há mais nada que suba o ataque — ataca."))
		"land":
			var land: CardInstance = h["card"]
			target = _hand_views.get(land.uid)
			_log(tr("Dica: joga primeiro o Terreno — dá mais mana."))
		"card":
			var c: CardInstance = h["card"]
			target = _hand_views.get(c.uid)
			_log(tr("Dica: joga %s (+%s de dano).") % [c.data.display_name(), Cascade.fmt_int(int(h.get("gain", 0)))])
		"order":
			target = _order_btn
			_log(tr("Dica: muda a ordem da Arena (+%s de dano).") % Cascade.fmt_int(int(h.get("gain", 0))))
	if _alive(target):
		_flash_hint(target)

## Brilho dourado a pulsar por cima do alvo da dica (3 vezes).
func _flash_hint(target: Control) -> void:
	if _hint_tw != null and _hint_tw.is_valid():
		_hint_tw.kill()
	var base := target.modulate
	_hint_tw = create_tween()
	for i in 3:
		_hint_tw.tween_property(target, "modulate", Color(1.5, 1.3, 0.6), _d(0.18) + 0.05)
		_hint_tw.tween_property(target, "modulate", base, _d(0.18) + 0.05)
	_bump(target, 1.1)

## Novo recorde: abranda, faísca dourada e um ecrã a dizer o recorde antigo.
func _celebrate_record(total: int, old: int) -> void:
	Sfx.boom()
	Settings.vibrate(80)
	if Settings.motion_ok():
		SceneRouter.hit_stop(0.4, 0.2)
		for k in 3:
			ColorBurst.spawn(self, total_label.global_position + total_label.size / 2.0 + Vector2(randf_range(-80, 80), randf_range(-20, 20)), "white")
	var short := bool(Settings.opt("short_celebrations")) and int(GameState.progress.get("records_celebrated", 0)) >= 1   # 0.19.0 (183)
	GameState.progress["records_celebrated"] = int(GameState.progress.get("records_celebrated", 0)) + 1
	_show_banner(tr("NOVO RECORDE!") + "\n" + tr("%s  ·  antes: %s") % [Cascade.fmt_int(total), Cascade.fmt_int(old)], 0.8 if short else 1.6)
	if not _skip_cascade:   # quem saltou a cascata não fica à espera (o letreiro fica no ecrã)
		await get_tree().create_timer(_d(0.5 if short else 1.2) + 0.2).timeout

## Uma carta deu uma palavra-chave: "+Voar" por cima da criatura.
func _on_keyword_granted(card: CardInstance, kw: String) -> void:
	_refresh_board()
	var view: Control = _board_views.get(card.uid)
	if _alive(view):
		_pop(view, "+" + tr(String(CardData.KEYWORD_NAMES.get(kw, kw))), UiKit.GOLD)
	_log(tr("%s ganha %s.") % [card.data.display_name(), tr(String(CardData.KEYWORD_NAMES.get(kw, kw)))])

func _on_landfall(_land: CardInstance) -> void:
	_log(tr("Chegada de Terreno!"))
	if battle.climate == "fertile_land":   # 0.19.0 (130)
		_climate_notice("fertile%d" % battle.turn, tr("+1 mana a mais neste turno."))
	_refresh_board()

## Fim da batalha da Arena (0.12.0): o resultado (relíquia e ouro, ou vida a menos) e segue o mapa.
func _arena_result(victory: bool) -> void:
	var txt := GameState.finish_arena(victory)
	if victory:
		Sfx.boom()
		_show_banner(tr("ARENA VENCIDA"), 1.0)
	else:
		Sfx.hit()
		_show_banner(tr("DERROTA NA ARENA"), 1.0)
	SceneRouter.toast(txt, 3.0)
	await get_tree().create_timer(_d(1.1)).timeout
	GameState.pending_event = ""
	GameState.next_ante()
	GameState.save_run({}, "map")
	SceneRouter.go("map")

# ---------------------------------------------------------------------------
# 0.13.0 — decisões na batalha: quem bloqueia, golpe carregado, ordem de disparo, total ao vivo,
# setas do inimigo, avisos no topo, palavras-chave explicadas, sem jogadas, jogada perfeita
# ---------------------------------------------------------------------------

## Etiqueta de cada ameaça na Arena: [texto, cor, seta?].
const THREAT_STYLE := {
	"block": ["BLOQUEIA", Color(0.3, 0.55, 0.95), false],
	"die": ["MORRE", Color(0.92, 0.25, 0.25), true],
	"jail": ["PRESA", Color(0.55, 0.55, 0.65), true],
	"mirror": ["COPIADA", Color(0.55, 0.68, 0.95), true],
	"destroy": ["DESTRUÍDA", Color(0.92, 0.25, 0.25), true],
	"burn": ["−%d", Color(0.95, 0.5, 0.15), false],
	"burn_die": ["MORRE", Color(0.92, 0.25, 0.25), true],
	"exile": ["EXILADA", Color(0.62, 0.35, 0.9), true],
	"meteor": ["−%d", Color(0.95, 0.5, 0.15), false],
	"meteor_die": ["MORRE", Color(0.92, 0.25, 0.25), true],
}

func _make_0130_widgets() -> void:
	_overlay = BattleOverlay.new()
	add_child(_overlay)
	_make_items_bar()

# --- 0.13.0: consumíveis (poções e pergaminhos) na barra de cima, ao lado do ouro ---

var _items_bar: HBoxContainer
var _pending_phase_text := ""

func _make_items_bar() -> void:
	var top: Control = turn_label.get_parent()
	_items_bar = HBoxContainer.new()
	_items_bar.name = "ItemsBar"
	_items_bar.add_theme_constant_override("separation", 6)
	_items_bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	top.add_child(_items_bar)
	top.move_child(_items_bar, gold_label.get_index())
	_refresh_items()

func _refresh_items() -> void:
	if _items_bar == null or not is_instance_valid(_items_bar):
		return
	UiKit.clear_children(_items_bar)
	var show := not battle.puzzle and GameState.puzzle_id == "" and GameState.consumable_slots() > 0
	_items_bar.visible = show
	if not show:
		return
	for i in GameState.consumable_slots():
		var b := Button.new()
		b.name = "Item%d" % i
		b.custom_minimum_size = Vector2(TOP_ICON, TOP_ICON)
		b.focus_mode = Control.FOCUS_NONE
		var filled := i < GameState.consumables.size()
		# 0.16.0: com poção, a ilustração num aro dourado a brilhar; vazio, um aro claro com um frasco apagado.
		var st := UiKit.flat(Color(0.14, 0.11, 0.22, 0.95), 26 if filled else 24, UiKit.GOLD if filled else Color(1, 1, 1, 0.26), 2 if not filled else 3, 0)
		if filled:
			st.shadow_color = Color(UiKit.GOLD, 0.35)
			st.shadow_size = 5
		else:
			st.draw_center = false   # só o aro (o fundo quase transparente deixava ver as costuras do polígono)
		for k in ["normal", "hover", "pressed", "disabled"]:
			b.add_theme_stylebox_override(k, st)
		if not filled:
			var ghost := CardIcon.new("potion", Color(1, 1, 1, 0.3), 24.0)
			ghost.name = "EmptyPotion"
			b.add_child(ghost)
			ghost.set_anchors_preset(Control.PRESET_CENTER)
			ghost.offset_left = -12.0
			ghost.offset_right = 12.0
			ghost.offset_top = -12.0
			ghost.offset_bottom = 12.0
		if filled:
			var id := GameState.consumables[i]
			var def := CardDB.get_consumable(id)
			var art := ArtLib.texture("item", id)
			if art != null:   # ilustração (assets/art/items) num círculo
				var holder := Control.new()
				holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
				holder.set_anchors_preset(Control.PRESET_FULL_RECT)
				holder.draw.connect(func(): ArtLib.draw_round(holder, art, holder.size / 2.0, minf(holder.size.x, holder.size.y) / 2.0 - 4.0))
				b.add_child(holder)
			else:
				var icon := CardIcon.new(String(def.get("kind", "potion")), Color(String(def.get("color", "#ffffff"))), 30.0)
				icon.set_anchors_preset(Control.PRESET_FULL_RECT)
				icon.offset_left = 10
				icon.offset_top = 10
				icon.offset_right = -10
				icon.offset_bottom = -10
				b.add_child(icon)
			b.tooltip_text = tr(String(def.get("name", id))) + ": " + tr(String(def.get("text", "")))
			b.modulate.a = 1.0 if battle.can_use_consumable(id) else 0.6
			b.pressed.connect(_open_item.bind(i))
		else:
			b.disabled = true
			b.tooltip_text = tr("Espaço para uma poção ou pergaminho (loja, Elites, eventos).")
		_items_bar.add_child(b)

## Tocar numa poção/pergaminho: o que faz e USAR.
func _open_item(index: int) -> void:
	if _alive(_modal) or battle.finished or _animating or index >= GameState.consumables.size():
		return
	Sfx.select()
	var id := GameState.consumables[index]
	var def := CardDB.get_consumable(id)
	var box := _open_modal(tr(String(def.get("name", id))), tr(String(def.get("text", ""))))
	var ok := battle.can_use_consumable(id)
	if not ok:
		var why := tr("Usa-se fora das batalhas (no mapa).") if String(def.get("use", "battle")) == "map" else tr("Agora não teria efeito.")
		var l := UiKit.label(why, 17, UiKit.TEXT_DIM)
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(l)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	var use := UiKit.button(tr("USAR"), 54, 20, UiKit.PRIMARY)
	use.name = "UseItem"
	use.custom_minimum_size.x = 200
	use.disabled = not ok
	use.pressed.connect(func(): _close_modal("use"))
	row.add_child(use)
	var close := UiKit.button(tr("FECHAR"), 54, 18)
	close.custom_minimum_size.x = 200
	close.pressed.connect(func(): _close_modal(null))
	row.add_child(close)
	var res = await _modal_result()
	if res is String and res == "use":
		_use_item(index)

func _use_item(index: int) -> void:
	if index >= GameState.consumables.size():
		return
	var id := GameState.consumables[index]
	var nm := tr(String(CardDB.get_consumable(id).get("name", id)))
	if not battle.use_consumable(index):
		return
	_undo_stack.clear()   # o consumível gasto não volta com o DESFAZER
	Sfx.boom()
	Settings.vibrate(30)
	_log(tr("Usaste: %s.") % nm)
	_pop(_items_bar, nm, UiKit.GOLD)
	_refresh_all()
	_refresh_items()
	_refresh_preview()

## Ladra de Relíquias: a relíquia fica apagada até ao fim da batalha.
func _on_relic_stolen(id: String) -> void:
	var nm := tr(String(CardDB.relics.get(id, {}).get("name", id)))
	_log(tr("%s desligou %s até ao fim da batalha.") % [tr(battle.enemy.name), nm])
	var v: Control = _relic_views.get(id)
	if _alive(v):
		_flash(v, Color(2.0, 1.6, 0.6))
		v.modulate = Color(0.45, 0.45, 0.5, 0.55)
	_refresh_preview()

## Hidra Tricéfala: mais uma fase (a fala e o letreiro vêm com o boss_phase2 que se segue).
func _on_boss_phase(_index: int, text: String) -> void:
	_pending_phase_text = text
	_ensure_hp_marker()

## Números de ordem (com 2+ criaturas) e o que o inimigo vai fazer a cada uma (com setas).
func _refresh_overlay() -> void:
	if _overlay == null:
		return
	if _animating or battle.finished or battle.resolving:
		_overlay.clear()
		return
	var badges: Array = []
	var order := battle.strike_order()
	if order.size() >= 2:
		for i in order.size():
			var v: Control = _board_views.get((order[i] as CardInstance).uid)
			if _alive(v):
				badges.append([v, i + 1])
	var threats: Array = []
	var lethal := _last_preview_total > 0 and _last_preview_total >= battle.hp_left()
	if Settings.show_threats and not lethal and not _what_if:
		var dy := {}
		for t in battle.threat_preview():
			var c: CardInstance = t["card"]
			var v: Control = _board_views.get(c.uid)
			var info: Array = THREAT_STYLE.get(String(t["kind"]), [])
			if not _alive(v) or info.is_empty():
				continue
			var text := tr(String(info[0]))
			if text.contains("%d"):
				text = text % int(t.get("value", 0))
			var off := float(dy.get(c.uid, 0.0))
			dy[c.uid] = off - 26.0
			threats.append({"node": v, "text": text, "color": info[1], "arrow": info[2], "dy": off})
	# 0.19.0 (111): de cada lacaio à criatura que ele trava no ataque previsto.
	if not _what_if and _s4_cascade != null:
		for st in _s4_cascade.steps:
			if st.tag == "minion" and st.source_card != null:
				var mv: Control = _board_views.get(st.source_card.uid)
				if _alive(mv):
					threats.append({"node": mv, "text": tr("LACAIO"), "color": Color(0.85, 0.62, 0.35), "arrow": true, "dy": -26.0 if lethal else 0.0, "minion": true})
	if _alive(_portrait):
		_overlay.from_y = _portrait.get_global_rect().get_center().y - enemy_panel.get_global_rect().position.y
	_overlay.set_data(enemy_panel, badges, threats)

## Tocar na intenção do inimigo: o texto todo e, se ele vai contra-atacar, quem bloqueia (automático,
## uma criatura à escolha ou ninguém), com o resultado de cada opção.
func _open_intent() -> void:
	if _alive(_modal) or battle.finished or _animating:
		return
	Sfx.select()
	var lethal := _last_preview_total > 0 and _last_preview_total >= battle.hp_left()
	var p := battle.counter_plan()
	var can_choose := not lethal and not battle.resolving and int(p["damage"]) > 0 and not battle.board.is_empty()
	var box := _open_modal(tr(battle.enemy.name), counter_label.text)
	if can_choose:
		var t := UiKit.label(tr("Quem bloqueia o contra-ataque?"), 20, UiKit.GOLD)
		t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(t)
		var grid := GridContainer.new()
		grid.columns = 2
		grid.add_theme_constant_override("h_separation", 10)
		grid.add_theme_constant_override("v_separation", 8)
		grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		box.add_child(grid)
		var opts: Array = [BattleManager.BLOCK_AUTO]
		for c in battle.board:
			opts.append(c.uid)
		opts.append(BattleManager.BLOCK_NONE)
		var keep := battle.chosen_blocker
		for uid in opts:
			battle.chosen_blocker = uid
			var plan := battle.counter_plan()
			var current: bool = uid == keep
			var btn := UiKit.wrap_button(_block_option_text(int(uid), plan), 62, 15,
				UiKit.PRIMARY.darkened(0.45) if current else UiKit.BTN_BG, UiKit.GOLD if current else Color(0, 0, 0, 0))
			btn.custom_minimum_size.x = 292
			btn.name = "Block_%s" % ("auto" if uid == BattleManager.BLOCK_AUTO else ("none" if uid == BattleManager.BLOCK_NONE else str(uid)))
			btn.pressed.connect(func(): _close_modal(int(uid)))
			grid.add_child(btn)
		battle.chosen_blocker = keep
	var close := UiKit.button(tr("FECHAR"), 50, 18)
	close.custom_minimum_size.x = 200
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close.pressed.connect(func(): _close_modal(null))
	box.add_child(close)
	var res = await _modal_result()
	if res is int:
		_choose_blocker(int(res))

## Aplica a escolha de quem bloqueia e diz o que vai acontecer.
func _choose_blocker(uid: int) -> void:
	if not battle.set_blocker(uid):
		return
	if not battle.puzzle:
		Stats.add("blocks_chosen")
	_refresh_preview()
	match uid:
		BattleManager.BLOCK_AUTO:
			_log(tr("Bloqueio automático."))
		BattleManager.BLOCK_NONE:
			_log(tr("Ninguém bloqueia: o golpe é para ti."))
		_:
			var i := battle._index_of_uid(uid)
			if i >= 0:
				_log(tr("%s vai bloquear o contra-ataque.") % battle.board[i].data.display_name())
				_bump(_board_views.get(uid), 1.08)

## Texto de uma opção do bloqueio: quem e o que acontece.
func _block_option_text(uid: int, plan: Dictionary) -> String:
	var head := ""
	match uid:
		BattleManager.BLOCK_AUTO:
			head = tr("Automático")
		BattleManager.BLOCK_NONE:
			head = tr("Ninguém")
		_:
			var i := battle._index_of_uid(uid)
			if i >= 0:
				head = "%s  (%d ♥)" % [_short(battle.board[i].data.display_name(), 22), battle.board[i].remaining()]
	var b: CardInstance = plan["blocker"]
	if uid == BattleManager.BLOCK_AUTO and b != null:
		head += ": " + _short(b.data.display_name(), 20)
	var bits: Array[String] = []
	if b != null:
		if bool(plan.get("vigilant", false)):
			bits.append(tr("sem dano (Vigilância)"))
		elif bool(plan["survives"]):
			bits.append(tr("sem dano") if int(plan["blocker_damage"]) <= 0 else tr("sobrevive"))
		else:
			bits.append(tr("morre"))
	var others := 0
	for c in plan["deaths"]:
		if c != b:
			others += 1
	if others > 0:
		bits.append(tr("morrem %d") % others)
	if int(plan["player_damage"]) > 0:
		bits.append(tr("levas %d") % int(plan["player_damage"]))
	elif b == null and others == 0:
		bits.append(tr("sem dano"))
	if uid == BattleManager.BLOCK_NONE and int(plan["damage"]) >= GameState.player_hp:
		bits.append(tr("seria letal: automático"))
	return head + "\n" + " · ".join(PackedStringArray(bits))

## Nome encurtado com reticências (botões estreitos).
static func _short(text: String, n: int) -> String:
	return text if text.length() <= n else text.substr(0, n - 1).strip_edges() + "…"

## Aviso curto no topo do ecrã, por cima das relíquias: nunca tapa o cálculo nem a Arena.
## 0.20.0 (B10): fica o «tempo dos avisos» (Settings.toast_seconds; 0 = até tocares). Os avisos aparecem um de cada vez:
## os outros esperam na fila (curta e sem repetidos). `now` (a resposta a um toque): o aviso aparece logo e o aviso de
## informação que estava no ecrã volta para a frente da fila. `history` (só o resumo do turno dele e o golpe carregado):
## tocar no aviso abre o histórico em «Só o inimigo»; os outros deixam passar o toque, menos os avisos de informação no
## «até tocares» (só para se fecharem). As respostas a um toque nunca apanham o toque: no «até tocares» ficam o tempo de base.
func _warn(text: String, color: Color = Color(0.95, 0.45, 0.4), seconds: float = 2.6, now: bool = false, history: bool = false) -> void:
	if not is_inside_tree():
		return
	var item := [text, color, seconds, now, history]
	if _alive(_notice):
		var cur: Array = _notice.get_meta("item")
		if not now:
			if String(cur[0]) != text and not _warn_queue.any(func(q: Array) -> bool: return String(q[0]) == text):
				_warn_queue.append(item)
				_trim_warn_queue()
			return
		if not bool(cur[3]):
			_warn_queue.push_front(cur)   # a informação não se perde; uma resposta a um toque antiga, sim
			_trim_warn_queue()
		_notice.queue_free()
	_show_warn(item)

## Fila cheia: sai o último aviso de informação a chegar; o resumo do inimigo e o golpe carregado (histórico) ficam.
func _trim_warn_queue() -> void:
	while _warn_queue.size() > WARN_QUEUE_MAX:
		var i := _warn_queue.size() - 1
		while i > 0 and bool(_warn_queue[i][4]):
			i -= 1
		_warn_queue.remove_at(i)

func _show_warn(item: Array) -> void:
	var hold := Settings.toast_seconds(float(item[2]))
	if hold <= 0.0 and bool(item[3]):
		hold = float(item[2])   # C6: a resposta a um toque não apanha o toque; no «até tocares» sai sozinha, com o tempo de base
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.12, 0.08, 0.14, 0.96), 12, item[1], 2, 10))
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if bool(item[4]) or hold <= 0.0:   # «até tocares»: um aviso de informação sem o toque ficava preso no ecrã (e a fila atrás dele)
		panel.mouse_filter = Control.MOUSE_FILTER_STOP
		panel.gui_input.connect(_on_notice_input.bind(panel))
	if bool(item[4]):
		panel.tooltip_text = tr("Toca para ver o histórico")
	panel.z_index = 50
	panel.name = "TopNotice"
	panel.set_meta("item", item)
	var l := UiKit.label(String(item[0]), 17, Color.WHITE)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	panel.add_child(l)
	add_child(panel)
	_notice = panel
	var room := _top_room() - 24.0
	var wrapped := l.get_minimum_size().x > room
	if wrapped:   # o resumo, com «Levaste» e 3 linhas, pode passar da largura livre (sobretudo em inglês)
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size.x = room
	panel.modulate.a = 0.0
	await get_tree().process_frame
	if wrapped and is_instance_valid(panel):
		await get_tree().process_frame   # o texto partido só tem a altura certa um frame depois (como no SceneRouter)
	if not is_instance_valid(panel) or not is_inside_tree():
		return
	panel.reset_size()
	panel.global_position = _top_slot(panel.size, _alive(_tip_panel))
	var tw := panel.create_tween()   # do próprio aviso: se sair antes (tocado, `now`), o tempo acaba com ele
	tw.tween_property(panel, "modulate:a", 1.0, 0.15)
	if hold <= 0.0:
		return   # «até tocares»
	tw.tween_interval(maxf(0.8, hold))
	tw.tween_property(panel, "modulate:a", 0.0, 0.3)
	tw.tween_callback(_end_warn.bind(panel))

## B10: o aviso do topo sai (acabou o tempo ou tocaste-lhe) e entra o seguinte da fila.
func _end_warn(panel: Control) -> void:
	if panel != _notice or not _alive(panel):
		return   # já tinha saído (o toque e o fim do tempo no mesmo frame)
	panel.queue_free()
	if not _warn_queue.is_empty() and is_inside_tree():
		_show_warn(_warn_queue.pop_front())

func _on_notice_input(ev: InputEvent, panel: Control) -> void:
	var mb := ev as InputEventMouseButton
	if mb != null and mb.button_index == MOUSE_BUTTON_LEFT and not mb.pressed:
		var history := bool((panel.get_meta("item") as Array)[4])
		_end_warn(panel)
		if history:
			_open_history("enemy")

## B10: o aviso do clima, no modo «até tocares», fecha-se com um toque.
func _close_on_tap(ev: InputEvent, panel: Control) -> void:
	var mb := ev as InputEventMouseButton
	if mb != null and mb.button_index == MOUSE_BUTTON_LEFT and not mb.pressed:
		panel.queue_free()

## Largura livre no topo, entre o ORDENAR e o ouro.
func _top_room() -> float:
	var span := _top_span()
	return maxf(200.0, span.y - span.x)

## [x mínimo, x máximo] livres no topo: depois do ORDENAR e antes do texto do ouro (o rótulo do ouro estica
## para a esquerda, por isso conta-se a largura do texto, encostado à direita).
func _top_span() -> Vector2:
	var vp := get_viewport_rect().size
	var lo := 8.0
	var hi := vp.x - 8.0
	if _top_left != null:   # 0.16.0: entre o bloco da esquerda e o da direita
		lo = maxf(lo, _top_left.get_global_rect().end.x + 8.0)
		if _top_right != null:
			hi = minf(hi, _top_right.get_global_rect().position.x - 8.0)
		return Vector2(lo, hi)
	if _sort_btn != null and _sort_btn.is_visible_in_tree():
		lo = maxf(lo, _sort_btn.get_global_rect().end.x + 8.0)
	if gold_label.is_visible_in_tree():
		var font := gold_label.get_theme_font("font")
		var fs := gold_label.get_theme_font_size("font_size")
		var w := font.get_string_size(gold_label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x if font != null else 110.0
		hi = minf(hi, gold_label.get_global_rect().end.x - w - 16.0)
	if _items_bar != null and is_instance_valid(_items_bar) and _items_bar.is_visible_in_tree() and _items_bar.get_child_count() > 0:
		hi = minf(hi, _items_bar.get_global_rect().position.x - 8.0)   # 0.13.0: as poções não ficam tapadas
	return Vector2(lo, hi)

## Lugar no topo, entre os botões da barra (ORDENAR) e o ouro, centrado na coluna do meio. below_tip:
## por baixo da dica que esteja aberta.
func _top_slot(sz: Vector2, below_tip: bool) -> Vector2:
	var vp := get_viewport_rect().size
	var span := _top_span()
	var lo := span.x
	var hi := span.y
	var strip: Control = spell_strip.get_parent_control()
	var cx := strip.get_global_rect().get_center().x
	var x := clampf(cx - sz.x / 2.0, lo, maxf(lo, hi - sz.x))
	if x + sz.x > vp.x - 8.0:
		x = maxf(8.0, vp.x - 8.0 - sz.x)
	var y := 6.0
	if below_tip and _alive(_tip_panel):
		y = _tip_panel.get_global_rect().end.y + 4.0
	return Vector2(x, y)

## Tocar no ícone de uma palavra-chave (Arena): o que ela faz, num balão por cima do ícone.
func _on_keyword_tapped(_card: CardInstance, kw: String, at: Rect2) -> void:
	if SceneRouter.has_overlay() or _alive(_modal):
		return
	Sfx.select()
	if _alive(_kw_bubble):
		_kw_bubble.queue_free()
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.1, 0.09, 0.16, 0.97), 10, UiKit.GOLD, 2, 10))
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.z_index = 55
	panel.name = "KeywordBubble"
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(row)
	var icon := CardIcon.new(kw, UiKit.GOLD, 26.0)
	icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(icon)
	var l := UiKit.label(tr(String(CardData.KEYWORD_TEXT.get(kw, CardData.KEYWORD_NAMES.get(kw, kw)))), 16, Color.WHITE, true)
	l.custom_minimum_size.x = 300
	row.add_child(l)
	add_child(panel)
	_kw_bubble = panel
	panel.modulate.a = 0.0
	await get_tree().process_frame
	if not is_instance_valid(panel) or not is_inside_tree():
		return
	panel.reset_size()
	var vp := get_viewport_rect().size
	var pos := Vector2(at.get_center().x - panel.size.x / 2.0, at.position.y - panel.size.y - 10.0)
	if pos.y < 6.0:
		pos.y = at.end.y + 10.0
	panel.global_position = Vector2(clampf(pos.x, 8.0, vp.x - panel.size.x - 8.0), clampf(pos.y, 6.0, vp.y - panel.size.y - 6.0))
	var tw := create_tween()
	tw.tween_property(panel, "modulate:a", 1.0, 0.12)
	tw.tween_interval(3.2)
	tw.tween_property(panel, "modulate:a", 0.0, 0.3)
	tw.tween_callback(func():
		if is_instance_valid(panel):
			panel.queue_free())

## Enquanto arrastas uma carta para a Arena, o cálculo mostra o ataque com ela (total a verde).
func _show_what_if(card: CardInstance, target_uid: int = -1) -> void:
	var c := battle.preview_cascade_with(card, false, target_uid)
	if c == null:
		return
	_what_if = true
	_show_calc(c, true)
	if _overlay != null:
		_overlay.clear()

## Sem jogadas possíveis: um aviso no topo (uma vez por turno) e o ATACAR a brilhar. Não quando o ataque perde a run
## (o ATACAR diz «NÃO CHEGA»/«MORRES» e pede o 2.º toque).
func _check_no_plays() -> void:
	var none := _no_plays_left() and not _risky_attack()
	_set_attack_glow(none)
	if none and _no_plays_turn != battle.turn and not battle.puzzle and not battle.can_mulligan():
		_no_plays_turn = battle.turn
		var txt := tr("Já não tens jogadas: ataca!") if battle.discards_left <= 0 else tr("Já não tens jogadas: ataca (ou canaliza uma carta).")
		if bool(Settings.opt("auto_end")) and battle.discards_left <= 0 and battle.mana_available <= 0:
			_start_auto_end()   # 0.19.0 (184)
		else:
			_warn(txt, UiKit.GOLD, 3.0)

func _no_plays_left() -> bool:
	if battle.resolving or battle.finished or _animating or battle.pending_bottom > 0 or battle.turn < 1 or _discard_mode:
		return false
	for c in battle.deck.hand:
		if battle.can_play(c):
			return false
	for c in battle.deck.flashback_cards():
		if battle.can_flashback(c):
			return false
	for i in battle.planeswalker_skills().size():
		if battle.can_use_planeswalker(i):
			return false
	return true

## ATACAR a pulsar (brilho), quando já só resta atacar.
func _set_attack_glow(on: bool) -> void:
	var running := _attack_glow != null and _attack_glow.is_valid()
	if on == running:
		return
	if running:
		_attack_glow.kill()
	_attack_glow = null
	end_turn_btn.self_modulate = Color.WHITE
	if not on:
		return
	if not Settings.motion_ok():
		end_turn_btn.self_modulate = Color(1.2, 1.15, 0.95)
		return
	_attack_glow = create_tween().set_loops()
	_attack_glow.tween_property(end_turn_btn, "self_modulate", Color(1.4, 1.28, 0.85), 0.55).set_trans(Tween.TRANS_SINE)
	_attack_glow.tween_property(end_turn_btn, "self_modulate", Color.WHITE, 0.55).set_trans(Tween.TRANS_SINE)

## O inimigo investe: o retrato avança e, se alguém bloqueia, faíscas na criatura.
func _on_enemy_attacking(damage: int, blocker) -> void:
	if _portrait != null and _alive(_portrait):
		_portrait.attack()
	if not Settings.motion_ok() or Settings.anim_scale() <= 0.0 or damage <= 0:
		return
	_bump(enemy_panel, 1.06)
	if blocker is CardInstance and _board_views.has(blocker.uid):
		var v: Control = _board_views[blocker.uid]
		if _alive(v):
			SparkFx.spawn(self, v.global_position + Vector2(v.size.x * 0.5, v.size.y * 0.35))

## 0.13.0: rever o último ataque desta batalha, passo a passo (a mesma janela do "maior golpe").
func _replay_last_attack() -> void:
	if _last_cascade == null or _last_cascade.is_empty() or not is_inside_tree():
		return
	var snap := GameState.cascade_snapshot(_last_cascade, _last_cascade.net_total())
	snap["title"] = tr("O ÚLTIMO ATAQUE") + "  ·  " + tr("Turno %d") % _last_attack_turn
	if not battle.puzzle:
		Stats.add("replays")
	CascadeReplay.open(snap)

## 0.13.0: fim de um enigma — RESOLVIDO (próximo enigma) ou NÃO CHEGOU (quanto faltou e TENTAR OUTRA VEZ).
func _puzzle_result(victory: bool) -> void:
	await get_tree().create_timer(_d(0.9) + 0.2).timeout
	if not is_inside_tree():
		return
	var id := GameState.puzzle_id
	var def := CardDB.get_puzzle(id)
	var next_id := ""
	for i in CardDB.puzzles.size():
		if String(CardDB.puzzles[i].get("id", "")) == id and i + 1 < CardDB.puzzles.size():
			next_id = String(CardDB.puzzles[i + 1].get("id", ""))
	var body := tr(String(def.get("name", "")))
	if not victory:
		var hp := int(battle.enemy.get("hp", 0))
		body += "\n" + tr("Faltaram %s de dano.") % Cascade.fmt_int(hp) if hp > 0 else ""
	var box := _open_modal(tr("RESOLVIDO!") if victory else tr("NÃO CHEGOU"), body)
	_modal.name = "PuzzleResult"
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	var options: Array = []
	if victory and next_id != "":
		options.append(["PRÓXIMO ENIGMA", next_id, "NextPuzzle"])
	if not victory:
		options.append(["TENTAR OUTRA VEZ", id, "RetryPuzzle"])
	options.append(["ENIGMAS", "", "PuzzleList"])
	for opt in options:
		var target := String(opt[1])
		var b := UiKit.button(tr(String(opt[0])), 56, 20, UiKit.PRIMARY.darkened(0.2) if target != "" else UiKit.BG_LIGHT, Color(0, 0, 0, 0))
		b.name = String(opt[2])
		b.custom_minimum_size.x = 230
		b.pressed.connect(func():
			Sfx.select()
			if target != "":
				GameState.reset_for_side_battle(target)
				SceneRouter.go("battle")
			else:
				GameState.puzzle_id = ""
				SceneRouter.go("puzzles"))
		row.add_child(b)

# --- 0.15.0: Energia, Coroa, Mana de Sangue, Persistir, Veteranos, Excesso, Ponto fraco, Rituais e gravação ---

static var _mech_cache: Dictionary = {}

## Mecânicas novas que uma carta usa ("energy", "crown", "delirium", "domain", "phyrexian" = Mana de Sangue):
## para as dicas e para mostrar a Energia a 0 quando há cartas que a usam.
static func mech_tags(d: CardData) -> Array:
	if d == null:
		return []
	if _mech_cache.has(d.id):
		return _mech_cache[d.id]
	var out: Array = []
	var blob := JSON.stringify(d.effects) + " " + " ".join(PackedStringArray(d.rules))
	for t in ["energy", "crown", "delirium", "domain"]:
		if t in blob:
			out.append(t)
	if d.phyrexian > 0:
		out.append("phyrexian")
	_mech_cache[d.id] = out
	return out

func _make_0150_widgets() -> void:
	var row: HBoxContainer = player_label.get_parent()
	row.add_theme_constant_override("separation", 8)   # cabe a Energia na mesma linha
	# Coroa: pequena, por cima do coração (não ocupa lugar na linha).
	var heart: Control = null
	for ch in row.get_children():
		if ch is CardIcon and (ch as CardIcon).kind == "heart":
			heart = ch
	_crown_icon = CardIcon.new("crown", UiKit.GOLD, 17.0)
	_crown_icon.name = "CrownIcon"
	_crown_icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_crown_icon.visible = false
	if heart != null:
		heart.add_child(_crown_icon)
		_crown_icon.position = Vector2(11, -12)
		_crown_icon.size = Vector2(17, 17)
	else:
		row.add_child(_crown_icon)
	# Energia: ⚡ e o número, logo a seguir à mana (só aparece quando tens Energia ou cartas que a usam).
	_energy_box = HBoxContainer.new()
	_energy_box.name = "EnergyBox"
	_energy_box.add_theme_constant_override("separation", 1)
	_energy_box.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_energy_box.mouse_filter = Control.MOUSE_FILTER_STOP
	var bolt := CardIcon.new("energy", Color(1.0, 0.86, 0.3), 20.0)
	bolt.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bolt.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_energy_box.add_child(bolt)
	_energy_label = UiKit.label("0", 18, Color(1.0, 0.9, 0.5))
	_energy_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_energy_box.add_child(_energy_label)
	_energy_box.visible = false
	row.add_child(_energy_box)
	_energy_box.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed and not SceneRouter.has_overlay():
			Sfx.select()
			CardZoom.show_text(tr("Energia") + "  ⚡ %d" % battle.energy, tr(String(CardDB.tips.get("energy", ""))), tr("Recurso desta batalha"), Color(1.0, 0.86, 0.3)))
	# No Infinito a vida do inimigo aparece abreviada: tocar mostra o número exato.
	enemy_hp_label.mouse_filter = Control.MOUSE_FILTER_STOP
	enemy_hp_label.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed and GameState.endless and not battle.enemy.is_empty():
			_hint_line(tr("Vida do inimigo: %s / %s") % [Cascade.fmt_int(int(battle.enemy.hp)), Cascade.fmt_int(int(battle.enemy.max_hp))]))
	_save_timer = Timer.new()
	_save_timer.one_shot = true
	_save_timer.wait_time = 0.4
	_save_timer.timeout.connect(_save_now)
	add_child(_save_timer)
	EventBus.energy_changed.connect(func(_e): _refresh_0150_status())
	EventBus.crown_changed.connect(_on_crown_changed)
	EventBus.phyrexian_paid.connect(_on_phyrexian_paid)
	EventBus.creature_persisted.connect(_on_creature_persisted)
	EventBus.veteran_star.connect(_on_veteran_star)
	EventBus.overkill_gold.connect(_on_overkill_gold)
	EventBus.ritual_changed.connect(func(_r): _refresh_defense())
	EventBus.ritual_resolved.connect(_on_ritual_resolved)
	EventBus.ritual_broken.connect(_on_ritual_broken)

## Número do ecrã da batalha: no Infinito passa a 1,2 M (o detalhe do ataque mostra o valor exato).
func _num(n: int) -> String:
	return Cascade.fmt_short(n) if Settings.short_numbers(GameState.endless) else Cascade.fmt_int(n)   # 0.19.0 (146)

func _refresh_0150_status() -> void:
	if _energy_box != null:
		var uses := battle.energy > 0
		if not uses and battle.deck != null:
			var pool: Array = []
			pool.append_array(battle.deck.hand)
			pool.append_array(battle.board)
			pool.append_array(battle.enchantments)
			for c in pool:
				if "energy" in mech_tags(c.data):
					uses = true
					break
		_energy_box.visible = uses
		_energy_label.text = str(battle.energy)
		_energy_box.tooltip_text = tr("Energia: %d") % battle.energy
	if _crown_icon != null:
		_crown_icon.visible = battle.crown

## Ponto fraco: chip com a mira e a cor (com o símbolo da cor no modo daltónico).
func _weak_point_chip(col: String, short: bool = false) -> PanelContainer:
	var chip := _intent_chip([["weak", COLOR_WEAK, ""]], Color(0.3, 0.15, 0.1))
	chip.name = "WeakChip"
	var row: HBoxContainer = chip.get_child(0)
	var pip := CardIcon.new("pip", CardFace.palette(col).get("pip", Color.WHITE), 18.0)
	pip.mana_color = col
	pip.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(pip)
	if not short:
		var l := UiKit.label(tr("Fraco"), 17, Color.WHITE)
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(l)
	return chip

## O chip do ritual brilha a dourado quando o ataque previsto chega para o interromper.
func _refresh_ritual_glow() -> void:
	if not _alive(_ritual_chip) or battle.ritual.is_empty():
		_ritual_hot = false
		return
	var hot := _last_preview_total >= battle.ritual_break_amount()
	_ritual_chip.add_theme_stylebox_override("panel", UiKit.flat(Color(0.24, 0.12, 0.32), 8, UiKit.GOLD if hot else Color(0, 0, 0, 0), 2 if hot else 0, 6))
	if hot and not _ritual_hot:
		_bump(_ritual_chip, 1.15)
	_ritual_hot = hot

func _on_crown_changed(on: bool) -> void:
	_refresh_0150_status()
	if on:
		_log(tr("Ganhaste a Coroa: +1 carta no início de cada turno, até levares dano."))
		_pop(player_label, tr("Coroa"), UiKit.GOLD)
		Sfx.level_up()
	elif not battle.finished:
		_log(tr("Perdeste a Coroa."))
		_pop(player_label, tr("Coroa perdida"), Color(0.95, 0.45, 0.4))

func _on_phyrexian_paid(card: CardInstance, life: int) -> void:
	_log(tr("Mana de Sangue: pagaste %d de vida para jogar %s.") % [life, card.data.display_name()])
	_pop(player_label, "−%d" % life, Color(0.85, 0.2, 0.3))
	_flash(player_label, Color(1.8, 0.7, 0.8))

func _on_creature_persisted(card: CardInstance) -> void:
	var bonus := GameState.relic_passive("persist_bonus") > 0.0
	_log(tr("%s persiste: volta à Arena com %s Poder.") % [tr(card.data.name), ("+%d" if bonus else "−%d") % BattleManager.PERSIST_POWER])
	var view: Control = _board_views.get(card.uid)
	if _alive(view):
		if view is CardView:
			(view as CardView).refresh()
		_flash(view, Color(0.9, 1.6, 1.0))
		_pop(view, tr("Persiste!"), Color(0.45, 0.85, 0.5))
	_refresh_preview()

func _on_veteran_star(card: CardInstance, stars: int) -> void:
	_log(tr("%s é veterana: estrela %d de %d (+%d Poder até ao fim da run).") % [tr(card.data.name), stars, BattleManager.VETERAN_STARS, BattleManager.VETERAN_POWER])
	var view: Control = _board_views.get(card.uid)
	if _alive(view):
		if view is CardView:
			(view as CardView).refresh()
		_pop(view, "★ " + tr("Veterano"), UiKit.GOLD)
	Sfx.level_up()
	_tip("veteran")

func _on_overkill_gold(g: int) -> void:
	_log(tr("Excesso: +%d ouro.") % g)
	_pop(gold_label, "+%d" % g, COLOR_GOLD)

func _on_ritual_resolved(text: String) -> void:
	Sfx.hit()
	_shake(8.0)
	_flash(enemy_panel, Color(1.6, 1.0, 2.0))
	_show_banner(tr("RITUAL") + "\n" + tr(text), 1.2, false, true)
	_log(tr("Ritual de %s: %s.") % [tr(battle.enemy.name), tr(text)])
	_refresh_all()

func _on_ritual_broken() -> void:
	Sfx.level_up()
	_show_banner(tr("RITUAL INTERROMPIDO"), 1.1)
	_log(tr("Interrompeste o ritual de %s!") % tr(battle.enemy.name))
	_flash(enemy_panel, Color(1.8, 1.8, 1.0))

## Grava a batalha depois de cada jogada (com 0,4 s de atraso, para juntar jogadas seguidas): se o Android
## fechar a app a meio do turno, a run volta a este ponto e não ao início do turno.
func _queue_save() -> void:
	if _save_timer == null or battle.puzzle or GameState.puzzle_id != "" or battle.finished:
		return
	_save_timer.start()

func _save_now() -> void:
	if not is_inside_tree() or battle.finished or battle.resolving or battle.puzzle or GameState.puzzle_id != "" or battle.enemy.is_empty():
		return
	GameState.save_run(battle.to_dict(), "battle")

# ---------------------------------------------------------------------------
# 0.16.0 — visual novo da batalha: barra de cima em blocos (V40), inimigo maior com a ilustração esbatida
# por trás e a intenção por cima do retrato (V28, V29), botões com ícones (V39), moeda e coração (V34),
# grimório e cemitério em pilha nas pontas da mão (V11, V31), feitiços em miniatura (V33), lugares,
# sombras e anéis na Arena (V30, 61, 62), patrono com retrato (V32), dano a voar até à vida (V35), fita
# por trás dos letreiros (V36), ecrã de recompensas (V38), câmara na cascata (55), 2.ª fase (56), boss e
# criaturas em estilhaços (57, 58), setas de sinergia (59), brilho de letal (60), vida do boss por
# segmentos (63) e as 3 expressões dos bosses (51).
# ---------------------------------------------------------------------------

const TOP_BLOCK_BG := Color(0.07, 0.06, 0.11, 0.8)
## 0.18.0: a batalha tem de caber nos 720 px de altura a 100 % (no telemóvel do AlizeOnMe a mão e a barra de cima
## ficavam cortadas): medalhões e poções de 48 px, retrato do inimigo que encolhe (PORTRAIT_MIN…130 px) com o
## espaço que sobra, defesas do inimigo numa só linha e a linha das formações sem partir em duas.
const TOP_ICON := 48.0
const PORTRAIT_MIN := 72.0
const PILE_SIZE := Vector2(62, 88)
const PILE_PAD := 74.0
const SPELL_MINI := Vector2(60, 36)
const PW_EFFECT_ICONS := {"buff_hand_color": "swords", "mult_add": "mult", "cheap_hand": "mana", "draw": "cards", "channel_draw": "replay",
	"extra_turn_mult": "hourglass", "buff_strongest": "swords", "enemy_max_hp_pct": "skull", "mult_mul_pay_life": "blood",
	"grow_random_board": "persist", "buff_board_mult": "swords", "mult_mul_grow": "mult", "heal": "heart", "mult_per_attacker": "mult",
	"mult_mul_shield": "shield", "create_token": "creature", "mult_per_token": "mult", "token_rally": "creature"}

var _top_left: PanelContainer
var _top_center: PanelContainer
var _top_right: PanelContainer
var _coin_icon: CardIcon
var _heart_icon: CardIcon
var _lib_pile: PileView
var _grave_pile: PileView
var _arena_floor: ArenaSlots
var _portrait_box: Control
var _portrait_big := 130.0
var _pair_portrait: EnemyPortrait   # 0.18.0 (25): o outro inimigo da Dupla (toca para o escolher)
var _pair_bar: Control
var _enemy_bg: Texture2D
var _enemy_bg_id := ""
var _band: LightBand
var _banner_full := ""          # o texto do último letreiro, como foi pedido (o Label mostra só a linha grande)
const BANNER_FONT := preload("res://assets/fonts/NewRocker-Regular.ttf")
const BANNER_SHADER := preload("res://assets/shaders/title_gold.gdshader")
var _syn_lines: SynergyLines
var _hp_segments: HpSegments
var _cam_zoom := 1.0
var _cam_center := Vector2.ZERO
var _cam_tw: Tween
var _lethal_uids: Dictionary = {}
var _rewards: Control
var _warm_art: Array[Texture2D] = []

func _top_block(nm: String) -> PanelContainer:
	var p := PanelContainer.new()
	p.name = nm
	p.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	p.add_theme_stylebox_override("panel", UiKit.flat(TOP_BLOCK_BG, 14, Color(1, 1, 1, 0.07), 1, 5))
	return p

## Ícone desenhado dentro de um botão, à esquerda (o texto fica centrado no resto) ou ao centro (sem texto).
func _btn_icon(b: Button, kind: String, color: Color, px: float, centered: bool) -> CardIcon:
	var icon := CardIcon.new(kind, color, px)
	icon.name = "Icon"
	b.add_child(icon)
	# Preso por âncoras (ao centro, ou à esquerda a meia altura): acompanha o botão sem código, mesmo quando o
	# botão muda de sítio ou de tamanho.
	icon.set_anchors_preset(Control.PRESET_CENTER if centered else Control.PRESET_CENTER_LEFT)
	icon.offset_left = -px * 0.5 if centered else 14.0
	icon.offset_right = px * 0.5 if centered else 14.0 + px
	icon.offset_top = -px * 0.5
	icon.offset_bottom = px * 0.5
	b.draw.connect(_btn_icon_alpha.bind(icon, b))
	_btn_icon_alpha(icon, b)
	if not centered:
		for st in ["normal", "hover", "pressed", "disabled", "focus"]:
			var sb := b.get_theme_stylebox(st)
			if sb != null:
				var c: StyleBox = sb.duplicate()
				c.content_margin_left = px + 22.0
				b.add_theme_stylebox_override(st, c)
	return icon

## Muda um nó de pai sem perder os nomes únicos (%Nome): ao sair da árvore, o Godot esquece o dono do nó e
## dos filhos dele, e o get_node("%…") deixava de os encontrar (o SmokeTest usa-o).
func _move_to(n: Node, new_parent: Node, index: int = -1) -> void:
	var owned: Array[Node] = []
	_collect_owned(n, owned)
	if n.get_parent() != null:
		n.get_parent().remove_child(n)
	new_parent.add_child(n)
	if index >= 0:
		new_parent.move_child(n, index)
	if not (new_parent == self or is_ancestor_of(new_parent)):
		push_warning("_move_to: %s ainda não está na cena; os nomes únicos ficam perdidos" % new_parent.name)
		return
	for o in owned:
		o.owner = self

func _collect_owned(n: Node, out: Array[Node]) -> void:
	if n.owner == self:
		out.append(n)
	for c in n.get_children():
		_collect_owned(c, out)

## O ícone de um botão desligado fica apagado (como o texto).
func _btn_icon_alpha(icon, b) -> void:
	if is_instance_valid(icon) and is_instance_valid(b):
		(icon as Control).modulate.a = 0.4 if (b as BaseButton).disabled else 1.0

## Peças da cena que mudam de sítio — corre antes do modo canhoto e do de uma mão (que as voltam a arrumar).
func _make_0160_layout() -> void:
	# V39: CANALIZAR e DESFAZER na mesma linha; o grimório e o cemitério saem da coluna (passam a pilhas).
	var zones: HBoxContainer = undo_btn.get_parent()
	_move_to(discard_btn, zones, 0)
	discard_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	discard_btn.custom_minimum_size.y = 46
	undo_btn.size_flags_horizontal = Control.SIZE_FILL
	undo_btn.custom_minimum_size = Vector2(58, 46)
	undo_btn.text = ""
	undo_btn.tooltip_text = tr("DESFAZER")
	_btn_icon(undo_btn, "undo", Color.WHITE, 24.0, true)
	for b in [library_btn, graveyard_btn]:
		_move_to(b, self)
		b.text = ""
		b.custom_minimum_size = PILE_SIZE
		b.size = PILE_SIZE
		b.size_flags_horizontal = Control.SIZE_FILL
		var clear := StyleBoxEmpty.new()
		for st in ["normal", "hover", "pressed", "disabled", "focus"]:
			b.add_theme_stylebox_override(st, clear)
		b.z_index = 6
	_lib_pile = PileView.new("library")
	_lib_pile.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	library_btn.add_child(_lib_pile)
	_grave_pile = PileView.new("graveyard")
	_grave_pile.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	graveyard_btn.add_child(_grave_pile)
	library_btn.tooltip_text = tr("Grimório")
	graveyard_btn.tooltip_text = tr("Cemitério")
	hand_box.resized.connect(_place_piles)
	resized.connect(_place_piles)

## Pilhas nas pontas da mão (com o modo de uma mão, a mão é mais estreita e as pilhas acompanham-na).
func _place_piles() -> void:
	if _lib_pile == null or not is_inside_tree():
		return
	var r := hand_box.get_global_rect()
	if r.size.x < 10.0:
		return
	# Presas ao fundo da mão (a parte de cima da mão sobe e desce com as linhas da previsão).
	var bottom := minf(r.end.y, get_viewport_rect().size.y)
	var y := maxf(r.position.y, bottom - PILE_SIZE.y - 32.0)
	library_btn.size = PILE_SIZE
	graveyard_btn.size = PILE_SIZE
	library_btn.global_position = Vector2(r.position.x + 2.0, y)
	graveyard_btn.global_position = Vector2(r.end.x - PILE_SIZE.x - 2.0, y)
	hand_box.pad_left = PILE_PAD
	hand_box.pad_right = PILE_PAD
	if _sort_btn != null and _sort_btn.get_parent() == self:
		_sort_btn.size = Vector2(PILE_SIZE.x, 40)
		_sort_btn.global_position = Vector2(r.position.x + 2.0, y - 46.0)

## Os blocos, o retrato grande e o resto que depende dos widgets das versões anteriores.
func _make_0160_widgets() -> void:
	var top: HBoxContainer = turn_label.get_parent()
	top.custom_minimum_size.y = 0   # 0.18.0: a altura é a dos blocos (58 px; antes 68)
	# 0.18.0: a linha das formações nunca parte em duas (depois do ataque crescia e empurrava a mão para baixo);
	# o que não couber acaba em «…» e a lista inteira está no detalhe do ataque (tocar no cálculo).
	formation_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	formation_label.max_lines_visible = -1
	formation_label.clip_text = true
	formation_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	# V40: pausa, turnos e velocidade num bloco à esquerda; relíquias ao centro; poções e ouro à direita.
	_top_left = _top_block("TopLeft")
	var lrow := HBoxContainer.new()
	lrow.add_theme_constant_override("separation", 10)
	_top_left.add_child(lrow)
	top.add_child(_top_left)
	top.move_child(_top_left, 0)
	pause_btn.text = ""
	pause_btn.tooltip_text = tr("PAUSA")
	pause_btn.custom_minimum_size = Vector2(54, 46)
	_btn_icon(pause_btn, "pause", Color.WHITE, 22.0, true)
	for n in [pause_btn, _turn_pips, _speed_btn]:
		if n != null:
			_move_to(n, lrow)
	_speed_btn.custom_minimum_size = Vector2(84, 46)
	_top_center = _top_block("TopCenter")
	_top_center.size_flags_horizontal = Control.SIZE_EXPAND | Control.SIZE_SHRINK_CENTER
	var ci := relics_bar.get_index()
	top.add_child(_top_center)   # (já na árvore: o _move_to devolve o dono aos nós)
	top.move_child(_top_center, ci)
	_move_to(relics_bar, _top_center)
	relics_bar.size_flags_horizontal = Control.SIZE_FILL
	_top_right = _top_block("TopRight")
	var rrow := HBoxContainer.new()
	rrow.add_theme_constant_override("separation", 8)
	_top_right.add_child(rrow)
	top.add_child(_top_right)
	if _items_bar != null:
		_move_to(_items_bar, rrow)
	_coin_icon = CardIcon.new("coin", UiKit.COIN, 30.0)
	_coin_icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	rrow.add_child(_coin_icon)
	_move_to(gold_label, rrow)
	gold_label.custom_minimum_size = Vector2(44, 0)
	gold_label.add_theme_font_size_override("font_size", 26)
	gold_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	# O ORDENAR passa para junto da mão (em cima do grimório), só com o ícone.
	if _sort_btn != null:
		_move_to(_sort_btn, self)
		_sort_btn.z_index = 6
		_sort_btn.size_flags_vertical = Control.SIZE_FILL
		_sort_btn.custom_minimum_size = Vector2(PILE_SIZE.x, 40)
		_btn_icon(_sort_btn, "sort", Color.WHITE, 22.0, true)
	_set_gold(GameState.gold)
	_refresh_top_blocks()
	# V28 + V29: nome por cima, retrato de ~130 px com a intenção por cima dele, vida logo por baixo.
	var vbox: VBoxContainer = enemy_hp_label.get_parent()
	var name_row: Control = emblem.get_parent()
	_move_to(enemy_name, vbox, 0)
	enemy_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	enemy_name.add_theme_font_size_override("font_size", 22)
	UiKit.outline_for(enemy_name, Color.WHITE, 6)
	name_row.visible = false
	_portrait_box = Control.new()
	_portrait_box.name = "PortraitBox"
	_portrait_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_portrait_big = 104.0 if Settings.compact else 130.0
	# 0.18.0: a caixa só exige o retrato mínimo e fica com o espaço que sobra na coluna (o retrato cresce até
	# _portrait_big): assim o painel do inimigo nunca empurra a mão para fora do ecrã.
	_portrait_box.custom_minimum_size = Vector2(0, PORTRAIT_MIN + 8.0)
	_portrait_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(_portrait_box)
	vbox.move_child(_portrait_box, 1)
	if _portrait != null:
		_move_to(_portrait, _portrait_box)
		_portrait.custom_minimum_size = Vector2(_portrait_big, _portrait_big)
		_portrait.size = Vector2(_portrait_big, _portrait_big)
	if _intent_row != null:
		_move_to(_intent_row, _portrait_box)
		_intent_row.custom_minimum_size.y = 0
		_intent_row.minimum_size_changed.connect(_layout_portrait_box)
	_portrait_box.resized.connect(_layout_portrait_box)
	# A vida por dentro da barra.
	var hp_stack: Control = enemy_hp_bar.get_parent()
	hp_stack.custom_minimum_size.y = 26
	_move_to(enemy_hp_label, hp_stack)
	enemy_hp_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	enemy_hp_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	enemy_hp_label.add_theme_font_size_override("font_size", 16)
	UiKit.outline_for(enemy_hp_label, Color.WHITE, 5)
	enemy_text.add_theme_font_size_override("font_size", 13)
	_hp_segments = HpSegments.new()
	hp_stack.add_child(_hp_segments)
	_hp_segments.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hp_stack.move_child(enemy_hp_label, -1)   # o número por cima das divisórias e das rachas
	if _hp_marker != null and is_instance_valid(_hp_marker):
		_hp_marker.visible = false
	enemy_panel.draw.connect(_draw_enemy_bg)
	# V39: ATACAR com as espadas e CANALIZAR com a seta em círculo.
	_btn_icon(end_turn_btn, "swords", Color(1, 1, 1, 0.95), 26.0, false)
	end_turn_btn.add_theme_font_size_override("font_size", 24)
	end_turn_btn.clip_text = true
	end_turn_btn.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	_attack_style = end_turn_btn.get_theme_stylebox("normal")
	_lethal_style = _attack_style.duplicate()
	_lethal_style.bg_color = Color(0.2, 0.68, 0.32)
	_danger_style = _attack_style.duplicate()   # 0.20.0 (B7): as mesmas margens do ícone das espadas
	_danger_style.bg_color = Color(0.74, 0.18, 0.18)
	_btn_icon(discard_btn, "replay", Color.WHITE, 22.0, false)
	discard_btn.add_theme_font_size_override("font_size", 19)
	# V34: coração maior (treme quando levas dano).
	for c in player_label.get_parent().get_children():
		if c is CardIcon and (c as CardIcon).kind == "heart":
			_heart_icon = c
	if _heart_icon != null:
		_heart_icon.custom_minimum_size = Vector2(30, 30)
	# V30 + 61 + 62: o chão da Arena (por cima do tapete, por baixo das criaturas).
	var scroll: Control = board_box.get_parent()
	_arena_floor = ArenaSlots.new()
	_arena_floor.name = "ArenaFloor"
	scroll.add_child(_arena_floor)
	scroll.move_child(_arena_floor, 0)
	scroll.resized.connect(_sync_arena_floor)
	if scroll is ScrollContainer:   # as sombras seguem as cartas quando a Arena desliza
		(scroll as ScrollContainer).get_h_scroll_bar().value_changed.connect(func(_v: float): _sync_arena_floor())
	# V36 («Faixa de luz», a escolha do AlizeOnMe): a faixa por trás dos letreiros e o texto grande em dourado.
	_band = LightBand.new()
	_band.name = "BannerBand"
	_band.visible = false
	_band.z_index = banner.z_index
	add_child(_band)
	_band.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	move_child(_band, banner.get_index())
	banner.add_theme_font_override("font", BANNER_FONT)
	banner.add_theme_color_override("font_color", Color.WHITE)   # branco: o shader troca-o pelo dourado
	banner.add_theme_color_override("font_outline_color", Color(0.1, 0.05, 0.12))
	banner.add_theme_constant_override("outline_size", 10)
	banner.add_theme_color_override("font_shadow_color", Color(0.02, 0.01, 0.04, 0.7))
	banner.add_theme_constant_override("shadow_offset_x", 0)
	banner.add_theme_constant_override("shadow_offset_y", 5)
	banner.add_theme_constant_override("shadow_outline_size", 0)
	var bmat := ShaderMaterial.new()
	bmat.shader = BANNER_SHADER
	banner.material = bmat
	# 59: setas de sinergia.
	_syn_lines = SynergyLines.new()
	add_child(_syn_lines)
	tree_exiting.connect(func(): _cam_set(1.0, Vector2.ZERO))
	_layout_portrait_box()
	_place_piles.call_deferred()

## O bloco das relíquias fica sempre no meio (empurra o do ouro para a direita); sem relíquias não tem fundo.
func _refresh_top_blocks() -> void:
	if _top_center == null:
		return
	if not _top_center.has_meta("full_style"):
		_top_center.set_meta("full_style", _top_center.get_theme_stylebox("panel"))
	var empty := relics_bar.get_child_count() == 0
	_top_center.add_theme_stylebox_override("panel", StyleBoxEmpty.new() if empty else _top_center.get_meta("full_style"))

func _set_gold(g: int) -> void:
	gold_label.text = str(g) if _coin_icon != null else tr("Ouro %d") % g
	gold_label.tooltip_text = tr("Ouro %d") % g

## Retrato ao centro da caixa; a intenção por cima dele, centrada, a meio do bordo de cima.
func _layout_portrait_box() -> void:
	if _portrait_box == null or _portrait == null:
		return
	var w := _portrait_box.size.x
	# 0.18.0: o retrato ocupa a altura que a caixa tem (entre PORTRAIT_MIN e _portrait_big), ao centro.
	var side := clampf(minf(_portrait_box.size.y - 8.0, w - 4.0), PORTRAIT_MIN, _portrait_big)
	var ps := Vector2(side, side)
	_portrait.custom_minimum_size = ps
	_portrait.size = ps
	var top := maxf(6.0, (_portrait_box.size.y - side) * 0.5)
	var cx := w * 0.5
	if _pair_portrait != null and _pair_portrait.visible:   # 0.18.0 (25) Dupla: o alvo à esquerda, o outro mais pequeno
		cx = w * 0.4
		var small := roundf(side * 0.62)
		_pair_portrait.custom_minimum_size = Vector2(small, small)
		_pair_portrait.size = Vector2(small, small)
		# (por baixo da intenção do inimigo, que fica por cima do alvo, e sem passar do fundo da caixa)
		var py := maxf(top + (side - small) * 0.5 - 4.0, top + 26.0)
		py = minf(py, _portrait_box.size.y - small - 10.0)
		_pair_portrait.position = Vector2(cx + side * 0.5 + 10.0, py)
		_pair_bar.size = Vector2(small, 6.0)
		_pair_bar.position = _pair_portrait.position + Vector2(0, small + 3.0)
	_portrait.position = Vector2(cx - ps.x * 0.5, top)
	if _intent_row != null and is_instance_valid(_intent_row):
		var ms := _intent_row.get_combined_minimum_size()
		_intent_row.size = ms
		_intent_row.position = Vector2(clampf(cx - ms.x * 0.5, 0.0, maxf(0.0, w - ms.x)), top - 12.0)

## V28: a ilustração do inimigo, esbatida e escura, a encher o painel (por baixo do conteúdo).
func _draw_enemy_bg() -> void:
	if _enemy_bg == null or Settings.high_contrast:
		return
	var r := Rect2(Vector2(2, 2), enemy_panel.size - Vector2(4, 4))
	ArtLib.draw_rounded(enemy_panel, _enemy_bg, r, 9.0, 0.35, Color(0.62, 0.56, 0.68, 0.9))
	var shade := PackedVector2Array([r.position, Vector2(r.end.x, r.position.y), r.end, Vector2(r.position.x, r.end.y)])
	var a := Color(0.05, 0.04, 0.08, 0.35)
	var b := Color(0.05, 0.04, 0.08, 0.82)
	enemy_panel.draw_polygon(shade, PackedColorArray([a, a, b, b]))

## 51: a expressão do boss — calmo, ferido (abaixo de metade da vida) e furioso (depois de despertar; nos
## bosses sem 2.ª fase, abaixo de um quarto). Só muda se houver a ilustração dessa expressão.
func _expression_art() -> String:
	var base := String(battle.enemy.get("art", "")) if String(battle.enemy.get("art", "")) != "" else String(battle.enemy.get("id", ""))
	if not bool(battle.enemy.get("boss", false)) and String(battle.enemy.get("variant", "")) != "nemesis":
		return base
	var hp := float(battle.enemy.get("hp", 0))
	var mx := maxf(1.0, float(battle.enemy.get("max_hp", 1)))
	var has_phase2 := battle.enemy.has("rule2") or bool(battle.enemy.get("boss", false)) and String(battle.enemy.get("rule2_text", "")) != ""
	var angry := battle.phase2 or (not has_phase2 and hp <= mx * 0.25)
	if angry and hp > 0.0 and ArtLib.has("portrait", base + "_angry"):
		return base + "_angry"
	if hp <= mx * 0.5 and hp > 0.0 and ArtLib.has("portrait", base + "_hurt"):
		return base + "_hurt"
	return base

func _refresh_enemy_art() -> void:
	if _portrait == null or battle.enemy.is_empty():
		return
	var base := String(battle.enemy.get("art", "")) if String(battle.enemy.get("art", "")) != "" else String(battle.enemy.get("id", ""))
	_portrait.art_id = _expression_art()
	if base != _enemy_bg_id:
		_enemy_bg_id = base
		_enemy_bg = ArtLib.blurred("portrait", base) if Settings.show_art else null
		enemy_panel.queue_redraw()
	if _hp_segments != null:
		var phases = battle.enemy.get("phases")
		var passed := battle.phase_index if phases is Array and not (phases as Array).is_empty() else (1 if battle.phase2 else 0)
		_hp_segments.set_marks(_hp_marks(), passed)

## 63: onde a barra de vida se parte (as fases do boss; a metade nos bosses que despertam).
func _hp_marks() -> Array[float]:
	var out: Array[float] = []
	if not bool(battle.enemy.get("boss", false)):
		return out
	var phases = battle.enemy.get("phases")
	if phases is Array and not (phases as Array).is_empty():
		for ph in phases:
			if ph is Dictionary:
				out.append(clampf(float((ph as Dictionary).get("pct", 50)) / 100.0, 0.0, 1.0))
	if out.is_empty():
		out.append(0.5)
	return out

## V30/61: o chão da Arena acompanha as criaturas (e acende o lugar da criatura arrastada).
func _sync_arena_floor() -> void:
	if _arena_floor == null:
		return
	var rects: Array[Rect2] = []
	for c in battle.creatures():
		var v: Control = _board_views.get(c.uid)
		if _alive(v):
			rects.append(v.get_global_rect())
	var lit := -1
	if _hand_drag_card != null and _hand_drag_card.data.is_creature() and _play_zone and _drag_playable(_hand_drag_card):
		lit = battle.creatures().size()
	var cs := CardView.SIZE_COMPACT if Settings.compact else CardView.SIZE_NORMAL
	_arena_floor.set_state(battle.max_creatures(), lit, rects, cs)
	_arena_floor.cracked = battle.phase2 and bool(battle.enemy.get("boss", false))

## V11/V31: o número e a carta de cima das pilhas.
func _refresh_piles() -> void:
	if _lib_pile == null:
		return
	var fb := 0
	for c in battle.flashback_cards():
		if battle.can_flashback(c):
			fb += 1
	_lib_pile.set_state(battle.deck.library.size())
	var gy := battle.deck.graveyard
	_grave_pile.set_state(gy.size(), gy[gy.size() - 1].data if not gy.is_empty() else null, fb > 0)
	library_btn.tooltip_text = tr("GRIMÓRIO %d") % battle.deck.library.size()
	graveyard_btn.tooltip_text = tr("CEMITÉRIO %d") % gy.size()

## V11: a carta comprada sai do grimório (as tuas costas) e vira-se ao chegar à mão.
func _animate_draw_from_pile(view: CardView, delay: float) -> bool:
	if _lib_pile == null or not Settings.fx_ok("flips") or Settings.anim_scale() <= 0.0 or not _alive(library_btn):
		return false
	var target_alpha := view.modulate.a
	view.modulate.a = 0.0
	await get_tree().process_frame
	if not _alive(view):
		return true
	var back := CardBack.new()
	back.back_id = GameState.run_back()   # 0.16.1 (V12): as costas deste baralho
	back.mouse_filter = Control.MOUSE_FILTER_IGNORE
	back.z_index = 30
	add_child(back)
	var from := _lib_pile.get_global_rect()
	back.size = view.size
	back.pivot_offset = back.size / 2.0
	back.global_position = from.get_center() - back.size / 2.0
	back.scale = Vector2(from.size.x / maxf(1.0, view.size.x), from.size.x / maxf(1.0, view.size.x))
	var dest := view.global_position
	var d := _d(0.2)
	var tw := back.create_tween()   # morre com as costas (a mão pode ser refeita a meio)
	tw.tween_interval(_d(delay))
	tw.set_parallel(true)
	tw.tween_property(back, "global_position", dest, d).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
	tw.tween_property(back, "scale", Vector2(0.0, 1.0), d).set_ease(Tween.EASE_IN)
	tw.set_parallel(false)
	tw.tween_callback(_finish_draw_from_pile.bind(back, weakref(view), target_alpha))
	return true

## A carta chegou à mão: as costas saem e a carta vira-se (a vista pode já não existir: a mão foi refeita).
func _finish_draw_from_pile(back: Node, view_ref: WeakRef, target_alpha: float) -> void:
	if is_instance_valid(back):
		back.queue_free()
	var view = view_ref.get_ref()
	if view == null or not _alive(view):
		return
	var v := view as Control
	v.modulate.a = target_alpha
	v.pivot_offset = v.size / 2.0
	v.scale = Vector2(0.0, 1.0)
	var t2 := v.create_tween()
	t2.tween_property(v, "scale", Vector2.ONE, _d(0.14)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)

## V33: mini-carta com um recorte da ilustração (feitiços deste turno e encantamentos em jogo). Sem
## ilustração (ou com as ilustrações desligadas) fica a ficha de texto de sempre.
func _make_mini(sp: CardInstance, enchant: bool, equip: bool = false, on_tap: Callable = Callable()) -> Control:
	var tex := ArtLib.card_art(sp.data.id)
	if tex == null:
		return null
	var col: Color = CardView.COLORS.get(sp.data.primary_color(), CardView.COLORS.colorless)
	var mini := Control.new()
	mini.name = "Mini_" + sp.data.id
	mini.custom_minimum_size = SPELL_MINI
	mini.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	mini.mouse_filter = Control.MOUSE_FILTER_STOP
	mini.tooltip_text = sp.data.display_name()
	mini.set_meta("mini", true)
	var power := sp.data.power
	var again := sp.zone == CardInstance.Zone.EXILE
	mini.draw.connect(func():
		var r := Rect2(Vector2.ZERO, mini.size)
		ArtLib.draw_rounded(mini, tex, r.grow(-2.0), 6.0, 0.4)
		var st := StyleBoxFlat.new()
		st.draw_center = false
		st.set_border_width_all(2)
		st.border_color = COLOR_EQUIP if equip else (COLOR_ENCHANT if enchant else col)
		st.set_corner_radius_all(8)
		mini.draw_style_box(st, r)
		var font := get_theme_default_font()
		if power > 0:
			var txt := str(power)
			var tsz := font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 12)
			var pill := Rect2(Vector2(r.end.x - tsz.x - 10.0, r.end.y - 16.0), Vector2(tsz.x + 8.0, 14.0))
			var ps := StyleBoxFlat.new()
			ps.bg_color = Color(COLOR_POWER, 0.95)
			ps.set_corner_radius_all(7)
			mini.draw_style_box(ps, pill)
			mini.draw_string(font, Vector2(pill.position.x + 4.0, pill.end.y - 3.0), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(0.05, 0.05, 0.1))
		if enchant or again:
			var mark := ("⚒" if equip else "✧") if enchant else "↺"
			mini.draw_string(font, Vector2(4, 13), mark, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)
		if enchant and not equip:   # 0.19.0 (115): os encantamentos ficam (∞), os feitiços são só deste turno
			mini.draw_string(font, Vector2(r.end.x - 15.0, 14.0), "∞", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, COLOR_ENCHANT.lightened(0.35)))
	mini.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed and not SceneRouter.has_overlay():
			Sfx.select()
			if on_tap.is_valid():
				on_tap.call()
			else:
				CardZoom.show_card(sp))
	return mini

## A faixa dos feitiços: escura só quando tem alguma coisa (V33).
func _refresh_strip_look() -> void:
	var panel: PanelContainer = spell_strip.get_parent()
	var empty := _strip_empty()
	if not panel.has_meta("full_style"):
		panel.set_meta("full_style", panel.get_theme_stylebox("panel"))
	panel.add_theme_stylebox_override("panel", StyleBoxEmpty.new() if empty else panel.get_meta("full_style"))
	if spell_hint != null:
		spell_hint.visible = false

## 60: as cartas da mão que, jogadas, matam o inimigo neste turno ganham um contorno dourado a pulsar.
func _refresh_lethal_glow(net: int) -> void:
	var hp := battle.hp_left()
	var on_now: Dictionary = {}
	if hp > 0 and net < hp and not _animating and not battle.resolving and not battle.finished and not _discard_mode and battle.pending_bottom == 0:
		for uid in _hand_views:
			var v: CardView = _hand_views[uid]
			if _alive(v) and v.delta > 0 and net + v.delta >= hp and battle.can_play(v.card):
				on_now[uid] = true
	for uid in _hand_views:
		var v: CardView = _hand_views[uid]
		if _alive(v):
			v.set_lethal(on_now.has(uid))
	if not on_now.is_empty() and on_now.size() != _lethal_uids.size():
		_tip("lethal_card")
	_lethal_uids = on_now

## 59: ao escolher uma carta da mão, linhas finas ligam-na às criaturas com que interage.
func _refresh_synergy_lines() -> void:
	if _syn_lines == null:
		return
	var v: CardView = _hand_views.get(_selected_uid)
	if _selected_uid < 0 or not _alive(v) or _animating or Settings.performance_mode:
		_syn_lines.clear()
		return
	var links := _synergy_targets(v.card)
	var to: Array[Vector2] = []
	for c in links:
		var bv: Control = _board_views.get(c.uid)
		if _alive(bv):
			var r := bv.get_global_rect()
			to.append(Vector2(r.get_center().x, r.end.y - 6.0))
	if to.is_empty():
		_syn_lines.clear()
		return
	var r0 := v.get_global_rect()
	var col: Color = CardView.COLORS.get(v.card.data.primary_color(), UiKit.GOLD)
	_syn_lines.set_links(Vector2(r0.get_center().x, r0.position.y - 30.0), to, col.lightened(0.25))

## Com que criaturas da Arena uma carta da mão interage: a vizinha da esquerda (as novas ficam na ponta
## direita), as que reativa ou fortalece, as que contam para ela (filtros de cor, palavra-chave, tribo) e as
## que contam com ela (as que ganham com feitiços, com a criatura à direita…).
func _synergy_targets(card: CardInstance) -> Array[CardInstance]:
	var board := battle.creatures()
	var out: Array[CardInstance] = []
	if board.is_empty():
		return out
	var d := card.data
	var add := func(c: CardInstance):
		if c != null and not (c in out) and c.uid != card.uid:
			out.append(c)
	for e in d.effects:
		var action := String(e.get("action", ""))
		var value = e.get("value", null)
		var target := String(e.get("target", ""))
		var per := String(e.get("per", ""))
		if action == "retrigger":
			match str(value):
				"left", "last_creature":
					add.call(board[board.size() - 1])
				"first":
					add.call(board[0])
				"all":
					for c in board:
						add.call(c)
		if target == "left" or action in ["grow_left", "destroy_left", "buff_left"] or per == "neighbors":
			add.call(board[board.size() - 1])
		elif target == "first":
			add.call(board[0])
		elif target == "board" or action in ["grow_board", "buff_power", "grant_keyword"]:
			for c in board:
				add.call(c)
		if per == "attacker" or (e.get("cond") is Dictionary and (e["cond"] as Dictionary).has("count")):
			var f = e.get("filter", null)
			if e.get("cond") is Dictionary and (e["cond"] as Dictionary).get("count") is Dictionary:
				f = ((e["cond"] as Dictionary)["count"] as Dictionary).get("filter", f)
			if f is Dictionary and not (f as Dictionary).is_empty():
				for c in board:
					if battle.effects.filter_ok(f, c):
						add.call(c)
	# Quem conta com esta carta.
	for c in board:
		for e in c.data.effects:
			var per := String(e.get("per", ""))
			var action := String(e.get("action", ""))
			var f = e.get("filter", null)
			# Sem filtro conta qualquer carta; com filtro (custo, cor, tribo…), só as que passam.
			var fits: bool = not (f is Dictionary) or (f as Dictionary).is_empty() or battle.effects.filter_ok(f, card)
			if fits and (per == "played" or (per == "spell" and d.is_spell()) or (per == "attacker" and d.is_creature())):
				add.call(c)
			if action in ["buff_right", "destroy_right"] and c == board[board.size() - 1] and d.is_creature():
				add.call(c)
	return out

## 55: a câmara aproxima-se um pouco da carta que dispara (5–8 %) e volta ao sítio no total.
func _cam_set(z: float, c: Vector2) -> void:
	_cam_zoom = z
	_cam_center = c
	var vp := get_viewport()
	if vp == null:
		return
	vp.canvas_transform = Transform2D(0.0, Vector2(z, z), 0.0, c - c * z) if z != 1.0 else Transform2D.IDENTITY

func _cam_focus(target: Control, z: float = 1.06) -> void:
	if not Settings.motion_ok() or Settings.performance_mode or not _alive(target):
		return
	var screen := get_viewport_rect().get_center()
	var goal := screen.lerp(target.get_global_rect().get_center(), 0.55)
	if _cam_tw != null and _cam_tw.is_valid():
		_cam_tw.kill()
	var z0 := _cam_zoom
	var c0 := _cam_center if _cam_zoom != 1.0 else goal
	_cam_tw = create_tween()
	_cam_tw.tween_method(func(t: float): _cam_set(lerpf(z0, z, t), c0.lerp(goal, t)), 0.0, 1.0, _d(0.12)).set_ease(Tween.EASE_OUT)

func _cam_reset(instant: bool = false) -> void:
	if _cam_tw != null and _cam_tw.is_valid():
		_cam_tw.kill()
	if instant or _cam_zoom == 1.0 or not Settings.motion_ok():
		_cam_set(1.0, Vector2.ZERO)
		return
	var z0 := _cam_zoom
	var c0 := _cam_center
	_cam_tw = create_tween()
	_cam_tw.tween_method(func(t: float): _cam_set(lerpf(z0, 1.0, t), c0), 0.0, 1.0, _d(0.18)).set_ease(Tween.EASE_IN_OUT)
	_cam_tw.tween_callback(func(): _cam_set(1.0, Vector2.ZERO))

## V35: o dano que levas voa do inimigo até à tua vida; o coração treme quando chega.
func _fly_player_damage(amount: int) -> void:
	if amount <= 0:
		return
	var label := Label.new()
	label.text = "−%d" % amount
	label.add_theme_font_size_override("font_size", 38)
	label.add_theme_color_override("font_color", Color(1.0, 0.45, 0.45))
	label.add_theme_color_override("font_outline_color", Color(0.25, 0.02, 0.04))
	label.add_theme_constant_override("outline_size", 9)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.z_index = 40
	add_child(label)
	label.reset_size()
	var from := (_portrait.get_global_rect().get_center() if _portrait != null and _alive(_portrait) else enemy_panel.get_global_rect().get_center()) - label.size / 2.0
	var heart_c := (_heart_icon.get_global_rect().get_center() if _heart_icon != null else player_label.get_global_rect().get_center())
	label.global_position = from
	if Settings.anim_scale() <= 0.0:
		label.queue_free()
		_shake_heart()
		return
	var tw := create_tween()
	tw.tween_property(label, "global_position", heart_c - label.size / 2.0 + Vector2(18, -6), _d(0.38)).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
	tw.tween_callback(_shake_heart)
	tw.tween_property(label, "modulate:a", 0.0, _d(0.25))
	tw.tween_callback(label.queue_free)

func _shake_heart() -> void:
	if _heart_icon == null or not _alive(_heart_icon):
		return
	_flash(player_label, Color(2.0, 0.6, 0.6))
	if not Settings.motion_ok():
		return
	_heart_icon.pivot_offset = _heart_icon.size / 2.0
	var tw := create_tween()
	for k in 4:
		tw.tween_property(_heart_icon, "rotation", 0.32 if k % 2 == 0 else -0.32, 0.045)
	tw.tween_property(_heart_icon, "rotation", 0.0, 0.06)
	var t2 := create_tween()
	t2.tween_property(_heart_icon, "scale", Vector2(1.35, 1.35), 0.08)
	t2.tween_property(_heart_icon, "scale", Vector2.ONE, 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)

## 62: a criatura assenta na Arena com um pequeno ressalto e um anel da cor dela.
func _land_creature(view: Control, card: CardInstance) -> void:
	if not _alive(view):
		return
	if _arena_floor != null:
		_arena_floor.ring(view.get_global_rect(), CardView.COLORS.get(card.data.primary_color(), CardView.COLORS.colorless))
	if not Settings.motion_ok():
		return
	view.pivot_offset = Vector2(view.size.x * 0.5, view.size.y)
	_kill_tween(view, "bump_tw")
	var tw := create_tween()
	tw.tween_property(view, "scale", Vector2(1.06, 0.94), _d(0.06))
	tw.tween_property(view, "scale", Vector2(0.98, 1.03), _d(0.08))
	tw.tween_property(view, "scale", Vector2.ONE, _d(0.12)).set_ease(Tween.EASE_OUT)
	view.set_meta("bump_tw", tw)

## 58: a criatura que morre estala e desfaz-se em cacos (a própria carta, desenhada uma vez).
func _shatter_card(view: CardView) -> bool:
	if not Settings.motion_ok() or Settings.anim_scale() <= 0.0 or Settings.performance_mode or not _alive(view):
		return false
	var card: CardInstance = view.card
	var rect := view.get_global_rect()
	var make := func() -> Control:
		var g: CardView = CARD_VIEW.instantiate()
		g.setup(card)
		g.mouse_filter = Control.MOUSE_FILTER_IGNORE
		return g
	ShatterFx.from_control(self, make, rect, 3)
	return true

## 57: o retrato do boss vencido parte-se em cacos, com a luz da cor do baralho por trás.
func _shatter_portrait() -> bool:
	if _portrait == null or not _alive(_portrait):
		return false
	var tex := _portrait.art_texture()
	if tex == null:
		return false
	var deck_cols: Array = GameState.deck_def.get("colors", [])
	var light: Color = CardView.COLORS.get(String(deck_cols[0]) if not deck_cols.is_empty() else "colorless", UiKit.GOLD)
	var r := _portrait.get_global_rect()
	var fx := ShatterFx.from_texture(self, tex, r.grow(-r.size.x * 0.05), Color(light.lightened(0.2), 0.9), true, 5)
	if fx == null:
		return false
	_portrait.modulate.a = 0.0
	return true

## V38: no fim da batalha, um painel com o ouro a contar, os bónus e a relíquia ou poção a revelar.
## Sem animações (modo instantâneo) e nos testes não abre: ficam os avisos de sempre (devolve false).
func _rewards_ok() -> bool:
	return Settings.anim_scale() > 0.0 and DisplayServer.get_name() != "headless" and not (battle.reward_summary.get("lines", []) as Array).is_empty()

func _show_rewards(title: String, extra_reveals: Array) -> void:
	var r := battle.reward_summary
	var reveals: Array = (r.get("reveals", []) as Array).duplicate()
	reveals.append_array(extra_reveals)
	if bool(Settings.opt("rewards_toast")):   # 0.19.0 (188): um aviso pequeno e o mapa logo a seguir
		SceneRouter.toast(rewards_toast_text(title, r, reveals), 3.2, true)
		return
	_rewards = BattleRewards.open(self, title, r.get("lines", []), reveals, int(r.get("gold_before", GameState.gold)), int(r.get("gold_after", GameState.gold)))
	await (_rewards as BattleRewards).done
	_rewards = null

# --- 0.16.0 (82): telemóveis fracos ---
## Na primeira cascata (uma vez por instalação) mede quantas imagens por segundo o telemóvel consegue a sério.
## Abaixo de 40, quando a batalha acalma, oferece o modo de desempenho (menos efeitos, 30 FPS). Não mede com o
## limite de 30 FPS escolhido nas Configurações, sem animações, nem com a cascata saltada (fica para a seguinte).
const SLOW_FPS := 40.0
var _fps_probe_on := false
var _fps_probe_frames := 0
var _fps_probe_usec := 0
var _fps_probe_last := 0
var _perf_offer_pending := false

func _fps_probe_start() -> void:
	_fps_probe_on = not Settings.performance_mode and not Settings.perf_offer_done and Settings.fps_cap != 30 \
			and Settings.anim_scale() > 0.0 and DisplayServer.get_name() != "headless" and not battle.puzzle
	_fps_probe_frames = 0
	_fps_probe_usec = 0
	_fps_probe_last = Time.get_ticks_usec()

func _fps_probe_tick() -> void:
	var now := Time.get_ticks_usec()
	var dt := now - _fps_probe_last
	_fps_probe_last = now
	if dt > 0 and dt < 500000:   # um salto grande é a app em segundo plano: não conta
		_fps_probe_frames += 1
		_fps_probe_usec += dt

func _fps_probe_end() -> void:
	if not _fps_probe_on:
		return
	_fps_probe_on = false
	if _skip_cascade or _fps_probe_usec < 1200000 or _fps_probe_frames < 12:
		return
	Settings.perf_offer_done = true
	Settings.save_settings()
	if probe_fps() < SLOW_FPS:
		_perf_offer_pending = true

## FPS medidos na cascata (0 sem medição).
func probe_fps() -> float:
	return _fps_probe_frames * 1000000.0 / float(_fps_probe_usec) if _fps_probe_usec > 0 else 0.0

func _maybe_offer_performance() -> void:
	if not _perf_offer_pending or battle.resolving or battle.finished or _animating or _alive(_modal) or SceneRouter.has_overlay():
		return
	_perf_offer_pending = false
	offer_performance_mode()

## A janela «O jogo está lento neste telemóvel» (também usada pelo SmokeTest). Devolve true se ligou o modo.
func offer_performance_mode() -> bool:
	var box := _open_modal(tr("O jogo está lento neste telemóvel"), tr("O modo de desempenho tira alguns efeitos e fixa o jogo a 30 FPS: fica mais fluido e gasta menos bateria. Podes mudar isto nas Configurações."))
	if _alive(_modal):
		_modal.name = "PerfOffer"
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	var on := UiKit.button(tr("LIGAR"), 56, 20, UiKit.PRIMARY.darkened(0.2), UiKit.PRIMARY)
	on.name = "PerfOn"
	on.custom_minimum_size.x = 200
	on.pressed.connect(func(): _close_modal("on"))
	row.add_child(on)
	var later := UiKit.button(tr("AGORA NÃO"), 56, 20)
	later.name = "PerfLater"
	later.custom_minimum_size.x = 200
	later.pressed.connect(func(): _close_modal("no"))
	row.add_child(later)
	var res = await _modal_result()
	if res is String and String(res) == "on":
		Settings.performance_mode = true
		Settings.apply()
		Settings.save_settings()
		SceneRouter.toast(tr("Modo de desempenho ligado"))
		return true
	return false



# ---------------------------------------------------------------------------
# 0.18.0 — batalhas com outro objetivo (24: Emboscada, Cerco, Fuga) e a Dupla (25: dois inimigos de uma vez)
# ---------------------------------------------------------------------------

const OBJECTIVE_ICONS := {"ambush": "first_strike", "siege": "flag", "escape": "speed"}
const COLOR_OBJECTIVE := Color(0.55, 0.85, 1.0)

func _connect_0180() -> void:
	EventBus.equipment_changed.connect(_on_equipment_changed)   # 0.18.0 (19)
	EventBus.ambushed.connect(_on_ambushed)
	EventBus.siege_healed.connect(_on_siege_healed)
	EventBus.pair_enemy_fell.connect(_on_pair_fell)
	EventBus.target_changed.connect(_on_target_changed)

## A regra de uma batalha com outro objetivo, numa frase.
static func objective_text(obj: String) -> String:
	match obj:
		"ambush":
			return TranslationServer.translate("Emboscada: o inimigo ataca antes do teu 1.º turno. Vencer dá +%d %% de ouro.") % GameState.AMBUSH_GOLD_PCT
		"siege":
			return TranslationServer.translate("Cerco: no fim de cada turno o inimigo cura %d %% da vida máxima, mas tens +%d turno (e +%d ouro).") % [int(GameState.SIEGE_HEAL_PCT), GameState.SIEGE_TURNS, GameState.SIEGE_GOLD]
		"escape":
			return TranslationServer.translate("Fuga: basta sobreviveres %d turnos. Se o venceres mesmo assim, +%d %% de ouro.") % [GameState.ESCAPE_TURNS, GameState.ESCAPE_KILL_PCT]
	return ""

## Depois do letreiro de entrada (e ao retomar): a regra no histórico, a Dupla e o golpe da Emboscada.
func _special_intro() -> void:
	if battle.objective != "":
		_log(objective_text(battle.objective))
		_tip(battle.objective)
	elif battle.is_pair():
		_log(tr("Dupla: os dois contra-atacam. Toca no retrato pequeno para mudar de alvo; o excesso do golpe passa para o outro."))
		_tip("pair")
	_refresh_pair_ui()
	if battle.ambush_pending:
		await get_tree().create_timer(_d(1.3)).timeout
		if is_inside_tree() and not battle.finished and battle.ambush_pending:
			battle.ambush_strike()

## O chip do objetivo na linha das defesas («Fuga 2/4»; curto: só o ícone e o progresso).
func _objective_chip(short: bool) -> PanelContainer:
	var obj := battle.objective
	if obj == "" or battle.puzzle or not bool(Settings.opt("hud_objective")):   # 0.19.0 (141)
		return null
	var txt := tr(String(VARIANT_NAMES.get(obj, obj)))
	if obj == "escape":
		var prog := "%d/%d" % [clampi(battle.turn, 1, GameState.ESCAPE_TURNS), GameState.ESCAPE_TURNS]
		txt = prog if short else txt + " " + prog
	elif short:
		txt = ""
	var chip := _intent_chip([[String(OBJECTIVE_ICONS.get(obj, "flag")), COLOR_OBJECTIVE, txt]], Color(0.1, 0.22, 0.3))
	chip.name = "ObjectiveChip"
	return chip

func _on_ambushed(dmg: int) -> void:
	_log(tr("Emboscada! %s atacou antes de ti: −%d de vida.") % [tr(String(battle.enemy.name)), dmg])
	_show_banner(tr("EMBOSCADA!"), 0.8, true)
	if _portrait != null and _alive(_portrait):
		_portrait.attack()

func _on_siege_healed(amount: int) -> void:
	_pop(enemy_panel, "+" + Cascade.fmt_int(amount), Color(0.5, 1.0, 0.62))
	_log(tr("Cerco: %s recupera %s de vida.") % [tr(String(battle.enemy.name)), Cascade.fmt_int(amount)])
	_refresh_hp_bars()

## Dupla: o retrato pequeno do outro inimigo (com a vida por baixo); tocar nele muda o alvo.
func _refresh_pair_ui() -> void:
	if _portrait_box == null:
		return
	if not battle.is_pair():
		if _pair_portrait != null:
			_pair_portrait.visible = false
			_pair_bar.visible = false
		return
	if _pair_portrait == null:
		_pair_portrait = EnemyPortrait.new()
		_pair_portrait.name = "PairPortrait"
		_pair_portrait.breathing = false
		_pair_portrait.mouse_filter = Control.MOUSE_FILTER_STOP
		_pair_portrait.gui_input.connect(_on_pair_input)
		_portrait_box.add_child(_pair_portrait)
		_pair_bar = Control.new()
		_pair_bar.name = "PairBar"
		_pair_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_pair_bar.draw.connect(_draw_pair_bar)
		_portrait_box.add_child(_pair_bar)
	var e2 := battle.enemy2
	var id := String(e2.get("id", ""))
	_pair_portrait.archetype = String(CardDB.enemy_def(id).get("portrait", "brute"))
	_pair_portrait.tint = Color.from_hsv(fmod(float(abs(id.hash())) / 1000.0, 1.0), 0.55, 0.75)
	_pair_portrait.art_id = id
	var alive := battle.pair_alive()
	_pair_portrait.modulate = Color.WHITE if alive else Color(0.5, 0.5, 0.55, 0.85)
	_pair_portrait.tooltip_text = (tr("Toca para atacar %s") if alive else tr("%s caiu")) % tr(String(e2.get("name", "")))
	_pair_portrait.visible = true
	_pair_bar.visible = true
	_pair_bar.queue_redraw()
	_layout_portrait_box()

func _draw_pair_bar() -> void:
	if _pair_bar == null:
		return
	var e2 := battle.enemy2
	var r := Rect2(Vector2.ZERO, _pair_bar.size)
	_pair_bar.draw_rect(r, Color(0.08, 0.06, 0.1, 0.9))
	var pct := clampf(float(e2.get("hp", 0)) / maxf(1.0, float(e2.get("max_hp", 1))), 0.0, 1.0)
	if pct > 0.0:
		_pair_bar.draw_rect(Rect2(r.position, Vector2(r.size.x * pct, r.size.y)), Color(0.86, 0.22, 0.24))

func _on_pair_input(ev: InputEvent) -> void:
	if not (ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed):
		return
	if SceneRouter.has_overlay() or _animating:
		return
	if battle.switch_target():
		Sfx.select()
	else:
		Sfx.deny()

func _on_target_changed() -> void:
	_log(tr("Alvo: %s.") % tr(String(battle.enemy.name)))
	_refresh_enemy_header()
	_refresh_pair_ui()
	_refresh_all()

func _on_pair_fell(fallen: Dictionary) -> void:
	_log(tr("%s caiu! %s passa a ser o alvo.") % [tr(String(fallen.get("name", ""))), tr(String(battle.enemy.name))])
	Sfx.boom()
	_refresh_enemy_header()
	_refresh_pair_ui()
	if _pair_portrait != null:
		_pair_portrait.defeat()

# --- 0.18.0 (19): Equipamentos ---
# Jogar: largado em cima de uma criatura fica nela; tocado, com várias criaturas, abre a escolha (com o ataque
# de cada opção); com uma só, vai para ela; sem nenhuma, fica à espera. Na Arena, a criatura mostra a medalha do
# equipamento; na faixa dos feitiços fica a ficha dele (tocar: onde está, o que dá e mudá-lo por 1 de mana).

const COLOR_EQUIP := Color(0.95, 0.72, 0.42)   # bronze: fichas, medalha e passos da cascata
var _equip_chips: Dictionary = {}   # uid -> Control (fichas a seguir às dos encantamentos)
var _equip_drop_uid: int = -1       # a criatura em cima da qual se largou o equipamento arrastado
var _equip_hover_uid: int = -1      # a criatura por baixo do equipamento enquanto o arrastas

## A faixa dos feitiços está vazia (sem feitiços deste turno, encantamentos nem equipamentos)?
func _strip_empty() -> bool:
	return battle.spells_this_turn.is_empty() and battle.enchantments.is_empty() and battle.equipment.is_empty()

func _equip_of(creature: CardInstance) -> CardInstance:
	var l := battle.equipment_on(creature)
	return l[0] if not l.is_empty() else null

## As fichas dos equipamentos (o _refresh_enchantments já limpou a caixa): à espera de uma criatura ficam esbatidas.
func _add_equipment_chips() -> void:
	_equip_chips.clear()
	for eq in battle.equipment:
		var holder := battle.equipment_holder(eq)
		var label := "⚒ " + eq.data.display_name()
		var chip := _make_chip(eq, label, true, _open_equip_menu.bind(eq))
		chip.name = "Equip_" + eq.data.id
		if not chip.has_meta("mini"):
			var style: StyleBoxFlat = chip.get_theme_stylebox("panel").duplicate()
			style.set_border_width_all(2)
			style.border_color = COLOR_EQUIP
			chip.add_theme_stylebox_override("panel", style)
			chip.mouse_filter = Control.MOUSE_FILTER_STOP
			chip.gui_input.connect(_on_equip_chip_input.bind(eq))
		if holder == null:
			chip.modulate = Color(1, 1, 1, 0.55)
			chip.tooltip_text = tr("%s: à espera de uma criatura (toca para a equipar por %d de mana).") % [eq.data.display_name(), BattleManager.EQUIP_MOVE_COST]
		else:
			chip.tooltip_text = tr("%s: em %s.") % [eq.data.display_name(), holder.data.display_name()]
		_ench_box.add_child(chip)
		_equip_chips[eq.uid] = chip

func _on_equip_chip_input(ev: InputEvent, eq: CardInstance) -> void:
	if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
		if ev.pressed:
			_eq_pressing = true
			_eq_press = ev.global_position
			return
		_eq_pressing = false
		if _eq_drag != null:
			_end_equip_drag(ev.global_position)
			return
		if not SceneRouter.has_overlay():
			Sfx.select()
			_open_equip_menu(eq)
		return
	if ev is InputEventMouseMotion:
		if _eq_drag != null:
			_move_equip_drag(ev.global_position)
		elif _eq_pressing and ev.global_position.distance_to(_eq_press) > Settings.drag_px():
			_start_equip_drag(eq, ev.global_position)

func _on_equipment_changed(card: CardInstance, holder: CardInstance, why: String) -> void:
	match why:
		"play":
			if holder != null:
				_log(tr("%s fica em %s.") % [card.data.display_name(), holder.data.display_name()])
			else:
				_log(tr("%s fica à espera de uma criatura (equipa-a depois por %d de mana).") % [card.data.display_name(), BattleManager.EQUIP_MOVE_COST])
		"move":
			_log(tr("%s passa para %s.") % [card.data.display_name(), holder.data.display_name()])
		"drop":
			_log(tr("%s fica sem dono: toca nele para o passar a outra criatura (%d de mana).") % [card.data.display_name(), BattleManager.EQUIP_MOVE_COST])
			# (a Arena refaz-se no creature_died, depois da animação da morte: aqui só a faixa)
			_refresh_enchantments()

## O ataque se o equipamento ficasse nesta criatura (da mão: como se o jogasses; em jogo: mudando-o).
func _equip_total(eq: CardInstance, t: CardInstance) -> int:
	if eq.zone == CardInstance.Zone.HAND:
		var c := battle.preview_cascade_with(eq, false, t.uid)
		return c.net_total() if c != null else 0
	return battle.equip_preview_total(eq, t)

## Uma grelha com um botão por criatura: «Nome  →  ataque»; a melhor fica a dourado. O toque fecha a janela
## com o uid escolhido.
func _equip_target_grid(eq: CardInstance, targets: Array[CardInstance], enabled: bool) -> GridContainer:
	var grid := GridContainer.new()
	grid.name = "EquipTargets"
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 8)
	grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	var totals := {}
	var best_uid := -1
	var best := -1
	for t in targets:
		var tot := _equip_total(eq, t)
		totals[t.uid] = tot
		if tot > best:
			best = tot
			best_uid = t.uid
	for t in targets:
		var txt := "%s  →  %s" % [t.data.display_name(), _num(int(totals[t.uid]))]
		var b := UiKit.button(txt, 52, 17, Color(0.4, 0.28, 0.12) if t.uid == best_uid else UiKit.BTN_BG, UiKit.GOLD if t.uid == best_uid else Color(0, 0, 0, 0))
		b.name = "EquipTo_%d" % t.uid
		b.custom_minimum_size.x = 280
		b.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		b.clip_text = true
		b.disabled = not enabled
		b.pressed.connect(_close_modal.bind(t.uid))
		grid.add_child(b)
	return grid

## Jogar um equipamento com várias criaturas que o podem receber: quem fica com ele? (-1 = voltar)
func _ask_equip_target(card: CardInstance):
	var box := _open_modal(tr("Equipar quem?"), "%s: %s" % [card.data.display_name(), card.data.display_text()])
	box.add_child(_equip_target_grid(card, battle.equip_targets(card), true))
	var hint := UiKit.label(tr("O número é o ataque deste turno com o equipamento nessa criatura."), 15, UiKit.TEXT_DIM, true)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(hint)
	var back := UiKit.button(tr("VOLTAR"), 50, 18)
	back.custom_minimum_size.x = 180
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	back.pressed.connect(_close_modal.bind(-1))
	box.add_child(back)
	return await _modal_result()

## Tocar num equipamento: onde está, o que dá e, por 1 de mana, mudá-lo (ou equipá-lo, se está à espera).
func _open_equip_menu(eq: CardInstance) -> void:
	if _alive(_modal) or battle.finished or _animating or not (eq in battle.equipment):
		return
	var holder := battle.equipment_holder(eq)
	var where := (tr("Está em %s.") % holder.data.display_name()) if holder != null else tr("Está à espera de uma criatura.")
	var box := _open_modal("⚒ " + eq.data.display_name(), where + "\n" + eq.data.display_text())
	box.name = "EquipMenu"
	var targets := battle.equip_targets(eq)
	if not targets.is_empty() and not battle.resolving:
		var cost := BattleManager.EQUIP_MOVE_COST
		var head := UiKit.label((tr("Mudar para outra criatura (%d de mana):") if holder != null else tr("Equipar uma criatura (%d de mana):")) % cost, 19, UiKit.GOLD)
		head.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(head)
		var can := battle.can_move_equipment(eq)
		box.add_child(_equip_target_grid(eq, targets, can))
		if not can:
			var why := UiKit.label(tr("Precisas de %d de mana (tens %d).") % [cost, battle.mana_available], 16, UiKit.TEXT_DIM)
			why.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			box.add_child(why)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	var see := UiKit.button(tr("VER A CARTA"), 50, 18)
	see.custom_minimum_size.x = 200
	see.pressed.connect(_close_modal.bind("card"))
	row.add_child(see)
	var close := UiKit.button(tr("FECHAR"), 50, 18)
	close.custom_minimum_size.x = 160
	close.pressed.connect(_close_modal.bind(null))
	row.add_child(close)
	var res = await _modal_result()
	if res is String and String(res) == "card":
		CardZoom.show_card(eq)
		return
	if not (res is int) or int(res) < 0:
		return
	var target: CardInstance = null
	for c in battle.board:
		if c.uid == int(res):
			target = c
	if target == null or not battle.can_move_equipment(eq, target):
		return
	_push_undo()
	if battle.move_equipment(eq, target):
		Sfx.play_card()
		Settings.vibrate(15)
		_refresh_all()
		var v: Control = _board_views.get(target.uid)
		if _alive(v):
			_bump(v, 1.08)
			_flash(v, Color(1.5, 1.3, 1.0))

## A criatura (que pode receber este equipamento) debaixo do dedo; -1 se nenhuma.
func _equip_target_at(card: CardInstance, pos: Vector2) -> int:
	for t in battle.equip_targets(card):
		var v: Control = _board_views.get(t.uid)
		if _alive(v) and v.get_global_rect().grow(6.0).has_point(pos):
			return t.uid
	return -1

## Enquanto arrastas um equipamento, a criatura por baixo do dedo fica acesa.
func _mark_equip_hover(uid: int) -> void:
	for k in _board_views:
		var v: Control = _board_views[k]
		if _alive(v):
			v.modulate = Color(1.25, 1.12, 0.9) if int(k) == uid else Color.WHITE

# --- 0.19.0: controlos da batalha (5, 6, 8, 12, 13, 15, 16, 17, 18) ---

const HOLD_ATTACK_S := 0.5
var _hold_t := -1.0               # < 0: ninguém a segurar o ATACAR
var _hold_fired := false          # o ATACAR já disparou ao fim do meio segundo (o largar não conta)
var _hold_bar: ColorRect
var _queued_tap_uid := -1         # 6: carta tocada durante o turno do inimigo
var _queued_tries := 0
var _touches: Dictionary = {}     # 8: índice do dedo → [onde tocou, onde está]
var _two_t0 := 0
var _two_done := false
var _eq_drag: CardInstance = null # 12: equipamento a ser arrastado
var _eq_press := Vector2.ZERO
var _eq_pressing := false
var _eq_ghost: Control
var _grid_btn: Button             # 15: a mão toda em grelha
const GRID_HAND_MIN := 8

func _make_0190_widgets() -> void:
	# 15: com 8 ou mais cartas, a mão em grelha (por cima do cemitério, como o ORDENAR por cima do grimório).
	_grid_btn = UiKit.button("", 40, 14)
	_grid_btn.name = "HandGridBtn"
	_grid_btn.tooltip_text = tr("Ver a mão toda")
	_grid_btn.z_index = 6
	_grid_btn.custom_minimum_size = Vector2(PILE_SIZE.x, 40)
	_grid_btn.set_meta("no_big", true)
	_btn_icon(_grid_btn, "cards", Color.WHITE, 22.0, true)
	_grid_btn.pressed.connect(_open_hand_grid)
	add_child(_grid_btn)
	_grid_btn.visible = false
	hand_box.resized.connect(_place_grid_btn)
	# 13: deslizar no retrato do inimigo para o lado troca o alvo na Dupla.
	if _portrait_box != null:
		SwipeArea.attach(self, _portrait_box, _on_portrait_swipe)

func _place_grid_btn() -> void:
	if _grid_btn == null or not is_inside_tree():
		return
	var r := hand_box.get_global_rect()
	if r.size.x < 10.0:
		return
	var bottom := minf(r.end.y, get_viewport_rect().size.y)
	var y := maxf(r.position.y, bottom - PILE_SIZE.y - 32.0)
	_grid_btn.size = Vector2(PILE_SIZE.x, 40)
	_grid_btn.global_position = Vector2(r.end.x - PILE_SIZE.x - 2.0, y - 46.0)

func _refresh_grid_btn() -> void:
	if _grid_btn == null:
		return
	_grid_btn.visible = battle.deck.hand.size() >= GRID_HAND_MIN and not battle.finished
	if _grid_btn.visible:
		_place_grid_btn()

## 15: a mão toda numa grelha: tocar numa carta joga-a (ou canaliza-a, ou põe-na no fundo do Mulligan).
func _open_hand_grid() -> void:
	if SceneRouter.has_overlay() or _alive(_modal) or battle.finished:
		return
	Sfx.select()
	var cards: Array[CardInstance] = []
	for c in _zoom_list_for(battle.deck.hand[0] if not battle.deck.hand.is_empty() else null):
		cards.append(c)
	var title := tr("A TUA MÃO")
	if _discard_mode:
		title = tr("CANALIZAR: escolhe a carta")
	elif battle.pending_bottom > 0:
		title = tr("PARA O FUNDO DO GRIMÓRIO")
	ZoneViewer.open(title, cards, false, func(c: CardInstance): _on_hand_card_pressed(c))

# 5: ATACAR a segurar.
func _on_end_turn_pressed() -> void:
	if bool(Settings.opt("hold_attack")):
		if _hold_fired:
			_hold_fired = false
			return   # já atacou ao fim do meio segundo
		if not (battle.resolving or battle.finished):
			Sfx.deny()
			_warn(tr("Segura o ATACAR meio segundo para atacar."), UiKit.GOLD, 1.6, true)
		return
	_on_end_turn()

func _on_end_turn_down() -> void:
	_hold_fired = false
	if not bool(Settings.opt("hold_attack")) or end_turn_btn.disabled or battle.resolving or battle.finished:
		return
	_hold_t = 0.0
	if _hold_bar == null:
		_hold_bar = ColorRect.new()
		_hold_bar.name = "HoldBar"
		_hold_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_hold_bar.color = Color(1.0, 0.86, 0.35, 0.38)
		end_turn_btn.add_child(_hold_bar)
	_hold_bar.position = Vector2.ZERO
	_hold_bar.size = Vector2(0.0, end_turn_btn.size.y)
	_hold_bar.visible = true

func _on_end_turn_up() -> void:
	_hold_t = -1.0
	if _hold_bar != null:
		_hold_bar.visible = false

func _hold_tick(delta: float) -> void:
	_hold_t += delta
	if _hold_bar != null:
		_hold_bar.size = Vector2(end_turn_btn.size.x * clampf(_hold_t / HOLD_ATTACK_S, 0.0, 1.0), end_turn_btn.size.y)
	if _hold_t >= HOLD_ATTACK_S:
		_hold_t = -1.0
		_hold_fired = true
		if _hold_bar != null:
			_hold_bar.visible = false
		Settings.haptic("play")
		_on_end_turn()

# 6: toques guardados.
func _queue_tap(card: CardInstance) -> void:
	_queued_tap_uid = card.uid
	_queued_tries = 0
	Sfx.tick()
	_hint_line(tr("Toque guardado: %s (quando voltar a ser a tua vez).") % card.data.display_name())

func _run_queued_tap() -> void:
	if _queued_tap_uid < 0 or battle.finished:
		_queued_tap_uid = -1
		return
	if battle.resolving or _animating:
		_queued_tries += 1
		if _queued_tries < 30:
			get_tree().create_timer(0.1).timeout.connect(_run_queued_tap, CONNECT_ONE_SHOT)
		else:
			_queued_tap_uid = -1
		return
	var uid := _queued_tap_uid
	_queued_tap_uid = -1
	for c in battle.deck.hand:
		if c.uid == uid:
			_on_hand_card_tapped(c)
			return

# 8: dois dedos — tocar abre a pausa; deslizar para a esquerda desfaz.
func _two_finger(event: InputEvent) -> void:
	if not bool(Settings.opt("two_finger")):
		_touches.clear()
		return
	if event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed:
			_touches[st.index] = [st.position, st.position]
			if _touches.size() == 2:
				_two_t0 = Time.get_ticks_msec()
				_two_done = false
				_cancel_hand_drag()   # o 1.º dedo pode ter pegado numa carta
			return
		if _touches.size() == 2 and not _two_done and _touches.has(st.index):
			_two_done = true
			_finish_two_finger()
		_touches.erase(st.index)
	elif event is InputEventScreenDrag:
		var sd := event as InputEventScreenDrag
		if _touches.has(sd.index):
			(_touches[sd.index] as Array)[1] = sd.position

func _finish_two_finger() -> void:
	if SceneRouter.has_overlay() or _alive(_modal) or battle.finished:
		return
	var moves: Array[Vector2] = []
	for k in _touches:
		var t: Array = _touches[k]
		moves.append(Vector2(t[1]) - Vector2(t[0]))
	if moves.size() < 2:
		return
	var left := moves.all(func(m: Vector2): return m.x <= -80.0 and absf(m.x) > absf(m.y))
	var still := moves.all(func(m: Vector2): return m.length() <= 30.0)
	if left:
		if not _undo_stack.is_empty():
			_on_undo()
		else:
			Sfx.deny()
			_warn(tr("Não há jogadas para desfazer."), UiKit.TEXT_DIM, 1.4, true)
	elif still and Time.get_ticks_msec() - _two_t0 <= 500:
		_open_pause()

# 12: arrastar um equipamento para outra criatura (1 de mana, como no menu dele).
func _start_equip_drag(eq: CardInstance, pos: Vector2) -> void:
	if battle.resolving or battle.finished or _animating or SceneRouter.has_overlay() or _alive(_modal) or not (eq in battle.equipment):
		return
	_eq_drag = eq
	var chip := PanelContainer.new()
	chip.name = "EquipGhost"
	chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	chip.z_index = 45
	chip.add_theme_stylebox_override("panel", UiKit.flat(Color(0.2, 0.13, 0.06, 0.95), 12, COLOR_EQUIP, 2, 8))
	chip.add_child(UiKit.label("⚒ " + eq.data.display_name(), 17, COLOR_EQUIP))
	add_child(chip)
	_eq_ghost = chip
	_move_equip_drag(pos)
	Settings.haptic("select")
	Sfx.select()

func _move_equip_drag(pos: Vector2) -> void:
	if _eq_drag == null:
		return
	if _alive(_eq_ghost):
		_eq_ghost.reset_size()
		_eq_ghost.global_position = pos - Vector2(_eq_ghost.size.x / 2.0, _eq_ghost.size.y + 18.0)
	var over := _equip_target_at(_eq_drag, pos)
	if over != _equip_hover_uid:
		_equip_hover_uid = over
		_mark_equip_hover(over)
		if over >= 0:
			Settings.haptic("select")

func _end_equip_drag(pos: Vector2) -> void:
	var eq := _eq_drag
	_eq_drag = null
	if _alive(_eq_ghost):
		_eq_ghost.queue_free()
	_eq_ghost = null
	var uid := _equip_target_at(eq, pos) if eq != null else -1
	_equip_hover_uid = -1
	_mark_equip_hover(-1)
	if eq == null or uid < 0:
		return
	var target: CardInstance = null
	for c in battle.board:
		if c.uid == uid:
			target = c
	if target == null or target == battle.equipment_holder(eq):
		return
	if not battle.can_move_equipment(eq, target):
		Sfx.deny()
		_warn(tr("Precisas de %d de mana (tens %d).") % [BattleManager.EQUIP_MOVE_COST, battle.mana_available], Color(0.95, 0.45, 0.4), 2.6, true)
		return
	_push_undo()
	if battle.move_equipment(eq, target):
		Sfx.play_card()
		Settings.haptic("play")
		_refresh_all()
		var v: Control = _board_views.get(target.uid)
		if _alive(v):
			_bump(v, 1.08)
			_flash(v, Color(1.5, 1.3, 1.0))

# 13: deslizar no retrato troca o alvo na Dupla.
func _on_portrait_swipe(_direction: int) -> void:
	if not battle.is_pair() or SceneRouter.has_overlay() or _animating or _alive(_modal):
		return
	if battle.switch_target():
		Sfx.select()
		Settings.haptic("select")
	else:
		Sfx.deny()

# 16: toque longo numa criatura da Arena: ver em grande, passar para uma ponta, equipar e o que a ameaça.
func _open_creature_menu(card: CardInstance) -> void:
	if SceneRouter.has_overlay() or _alive(_modal) or battle.finished or _animating or not (card in battle.board):
		return
	Sfx.select()
	var box := _open_modal(card.data.display_name(), card.data.display_text())
	box.name = "CreatureMenu"
	var grid := GridContainer.new()
	grid.name = "Actions"
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 8)
	grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	box.add_child(grid)
	var actions: Array = [["see", tr("VER EM GRANDE"), true]]
	var creatures := battle.creatures()
	var idx := creatures.find(card)
	if creatures.size() >= 2:
		# 0.19.0 (283): uma casa de cada vez, sem arrastar.
		actions.append(["left", tr("◀ UMA CASA PARA A ESQUERDA"), idx > 0 and not battle.resolving])
		actions.append(["right", tr("UMA CASA PARA A DIREITA ▶"), idx < creatures.size() - 1 and not battle.resolving])
		actions.append(["first", tr("PASSAR PARA A PONTA ESQUERDA"), idx > 0 and not battle.resolving])
		actions.append(["last", tr("PASSAR PARA A PONTA DIREITA"), idx < creatures.size() - 1 and not battle.resolving])
	for eq in battle.equipment:
		if battle.equipment_holder(eq) != card and card in battle.equip_targets(eq):
			actions.append(["eq:%d" % eq.uid, tr("EQUIPAR: %s (%d de mana)") % [eq.data.display_name(), BattleManager.EQUIP_MOVE_COST], battle.can_move_equipment(eq, card)])
	for a in actions:
		var b := UiKit.button(String(a[1]), 52, 16)
		b.name = "Act_" + String(a[0]).replace(":", "_")
		b.custom_minimum_size.x = 290
		b.disabled = not bool(a[2])
		b.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		b.clip_text = true
		b.pressed.connect(_close_modal.bind(String(a[0])))
		grid.add_child(b)
	# O que a ameaça neste turno (as mesmas setas do tabuleiro).
	var threats: Array[String] = []
	for t in battle.threat_preview():
		if (t["card"] as CardInstance) == card:
			var info: Array = THREAT_STYLE.get(String(t["kind"]), [])
			if not info.is_empty():
				var txt := tr(String(info[0]))
				threats.append(txt % int(t.get("value", 0)) if txt.contains("%d") else txt)
	var th := UiKit.label((tr("Ameaça: %s.") % ", ".join(PackedStringArray(threats))) if not threats.is_empty() else tr("Nada a ameaça neste turno."), 17,
		Color(1.0, 0.6, 0.5) if not threats.is_empty() else UiKit.TEXT_DIM, true)
	th.name = "Threats"
	th.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(th)
	var close := UiKit.button(tr("FECHAR"), 50, 18)
	close.custom_minimum_size.x = 160
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close.pressed.connect(_close_modal.bind(null))
	box.add_child(close)
	var res = await _modal_result()
	if not (res is String) or not (card in battle.board):
		return
	var r := String(res)
	if r == "see":
		CardZoom.show_card_in(card, battle.creatures())
	elif r in ["first", "last", "left", "right"]:
		var cur := battle.creatures().find(card)
		var to := 0 if r == "first" else (battle.creatures().size() - 1 if r == "last" else clampi(cur + (-1 if r == "left" else 1), 0, battle.creatures().size() - 1))
		battle.move_creature(card, to)
		Sfx.select()
		_refresh_board()
		_refresh_preview()
		if not battle.puzzle:
			GameState.save_run(battle.to_dict(), "battle")
	elif r.begins_with("eq:"):
		var uid := int(r.substr(3))
		for eq in battle.equipment:
			if eq.uid == uid and battle.can_move_equipment(eq, card):
				_push_undo()
				if battle.move_equipment(eq, card):
					Sfx.play_card()
					Settings.haptic("play")
					_refresh_all()

# 17 + 18: teclado e comando (os botões do comando: A joga a carta escolhida, X ataca, Y canaliza, Back desfaz,
# Start pausa; o direcional e os gatilhos escolhem a carta). O B / Esc fazem o «retroceder» (a pausa).
func _unhandled_input(event: InputEvent) -> void:
	if battle == null or battle.finished or SceneRouter.has_overlay() or _alive(_modal):
		return
	if event is InputEventKey and (event as InputEventKey).pressed and not (event as InputEventKey).echo:
		var k := (event as InputEventKey).keycode
		var used := true
		match k:
			KEY_SPACE:
				_on_end_turn()
			KEY_C:
				_toggle_channel()
			KEY_Z:
				_on_undo()
			KEY_ENTER, KEY_KP_ENTER:
				_tap_selected()
			KEY_LEFT:
				_move_selection(-1)
			KEY_RIGHT:
				_move_selection(1)
			_:
				if k >= KEY_1 and k <= KEY_9:
					_tap_nth(k - KEY_1)
				else:
					used = false
		if used:
			get_viewport().set_input_as_handled()
	elif event is InputEventJoypadButton and (event as InputEventJoypadButton).pressed:
		var used := true
		match (event as InputEventJoypadButton).button_index:
			JOY_BUTTON_A:
				_tap_selected()
			JOY_BUTTON_X:
				_on_end_turn()
			JOY_BUTTON_Y:
				_toggle_channel()
			JOY_BUTTON_BACK:
				_on_undo()
			JOY_BUTTON_START:
				_open_pause()
			JOY_BUTTON_LEFT_SHOULDER, JOY_BUTTON_DPAD_LEFT:
				_move_selection(-1)
			JOY_BUTTON_RIGHT_SHOULDER, JOY_BUTTON_DPAD_RIGHT:
				_move_selection(1)
			_:
				used = false
		if used:
			get_viewport().set_input_as_handled()

func _toggle_channel() -> void:
	if discard_btn.disabled or battle.resolving:
		Sfx.deny()
		return
	discard_btn.button_pressed = not discard_btn.button_pressed

## As cartas da mão pela ordem do leque.
func _hand_in_order() -> Array:
	return _zoom_list_for(battle.deck.hand[0]) if not battle.deck.hand.is_empty() else []

func _move_selection(step: int) -> void:
	var cards := _hand_in_order()
	if cards.is_empty():
		return
	var i := -1
	for k in cards.size():
		if (cards[k] as CardInstance).uid == _selected_uid:
			i = k
	i = (0 if step >= 0 else cards.size() - 1) if i < 0 else wrapi(i + step, 0, cards.size())
	var c: CardInstance = cards[i]
	_set_selection(c.uid)
	Sfx.tick()
	_hint_line("%s — %s" % [c.data.display_name(), tr("A / Enter para jogar") if battle.can_play(c) else tr(_block_reason_text(c))])

func _tap_selected() -> void:
	if _selected_uid < 0:
		_move_selection(1)
		return
	for c in battle.deck.hand:
		if c.uid == _selected_uid:
			_set_selection(-1)
			_on_hand_card_pressed(c)
			return

func _tap_nth(n: int) -> void:
	var cards := _hand_in_order()
	if n >= 0 and n < cards.size():
		_on_hand_card_tapped(cards[n])

# ---------------------------------------------------------------------------
# 0.19.0 (secção 4) — clareza visual: o que vai acontecer, à vista antes de atacar (101–134)
# ---------------------------------------------------------------------------

## Nomes curtos das formações para as marcas das cartas (105, 106).
const FORMATION_SHORT := {"pair": "Pacto", "two_pair": "Pacto ×2", "trips": "Tríade", "full_house": "Casa Cheia", "quads": "Quadra",
	"band": "Bando", "storm": "Tempestade", "curve": "Curva", "devotion": "Devoção", "horde": "Horda", "wubrg": "Prismática"}
const COST_FORMATIONS := ["pair", "two_pair", "trips", "full_house", "quads"]
const COLOR_HAND_GLOW := Color(1.0, 0.8, 0.3, 0.9)
const CALM_BG := Color(0.55, 0.55, 0.62)
## 104: a cor das letras que voam na cascata (o contorno continua a ser o de quem dispara).
const POP_INK := {"power_add": Color(0.8, 0.94, 1.0), "mult_add": Color(1.0, 0.78, 0.84), "mult_mul": Color(0.94, 0.8, 1.0),
	"gold": Color(1.0, 0.95, 0.68)}
const TYPE_NAMES := {"creature": "Criatura", "spell": "Feitiço", "land": "Terreno", "enchantment": "Encantamento"}

var _s4_cascade: Cascade              # o ataque previsto (o de agora, sem a carta que se arrasta)
var _s4_plan: Dictionary = {}         # o contra-ataque previsto (128)
var _s4_closers: Dictionary = {}      # uid da carta da mão → a formação que ela fecha (106)
var _s4_closer_sig := ""
var _need_text := ""                  # 109: «faltam X» (vai para o texto da vida do inimigo)
var _shield_bar: Control              # 110
var _mech_chip: PanelContainer        # 131, 132
var _mech_label: Label
var _mech_deck_tags: Dictionary = {}
var _focus_on := false                # 118
var _enemy_log_from := -1             # 117: onde começa o turno do inimigo no histórico
var _enemy_recap: Array = []
var _enemy_turn_logging := false      # 155: as linhas que entram agora são do turno do inimigo
var _history_kind: Array[String] = []
var _climate_told := {}               # 130: avisos do clima já dados nesta batalha
var _climate_notice_node: Control

func _make_s4_widgets() -> void:
	# 110: a parte da vida que o escudo trava, desenhada na própria barra.
	_shield_bar = Control.new()
	_shield_bar.name = "ShieldBar"
	_shield_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	enemy_hp_bar.get_parent().add_child(_shield_bar)
	_shield_bar.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_shield_bar.draw.connect(_draw_shield_bar)
	_s4_explain()

## Depois de cada previsão: falta para LETAL, escudo na barra, vida a perder no ATACAR, relíquias, marcas, poções e
## contadores.
func _s4_after_preview() -> void:
	if battle == null or battle.enemy.is_empty() or _animating:
		return
	var c := _s4_cascade
	var hp := battle.hp_left()   # na Dupla, o «faltam» é o que falta para ganhar (como o letreiro do último turno)
	var net := _last_preview_total
	var lethal := net > 0 and net >= hp
	# 109: quanto falta para LETAL, no texto da vida do inimigo.
	_need_text = (tr("faltam %s") % _num(hp - net)) if net > 0 and not lethal and hp > 0 and not battle.finished else ""
	_hp_text()
	if _shield_bar != null:   # 110
		_shield_bar.queue_redraw()
	# 128: a vida que vais perder no contra-ataque previsto, no próprio ATACAR.
	var pd := int(_s4_plan.get("player_damage", 0)) if not lethal else 0
	# 0.20.0 (B7): um ataque que perde a run diz porquê, a vermelho; em run, o 1.º toque pede o 2.º (_confirm_attack).
	var risk := _attack_risk(net, _s4_plan)
	if risk == "":
		_attack_armed = false
	if _attack_armed:
		_set_attack_text(_armed_attack_text())
	elif risk == "die":
		_set_attack_text(tr("ATACAR") + "  ·  " + tr("MORRES"))
	elif risk == "short":
		_set_attack_text(tr("ATACAR") + "  ·  " + tr("NÃO CHEGA"))
	elif pd > 0 and not _what_if and not battle.finished:
		_set_attack_text(end_turn_btn.text + "  ·  −%d♥" % pd)
	if risk != "":
		end_turn_btn.add_theme_stylebox_override("normal", _danger_style)
	if _turn_pips != null and _turn_pips.last != _is_last_turn():
		_refresh_pips()   # um turno extra a meio (Pergaminho do Tempo) deixa de ser o último
	_s4_relic_previews(c)
	_s4_marks()
	_s4_item_glow(c, hp, net)
	_refresh_mech_chip()

func _draw_shield_bar() -> void:
	if battle == null or battle.enemy.is_empty() or _animating or battle.finished:
		return
	var sh := battle.shield_amount()
	var mx := maxf(1.0, float(battle.enemy.get("max_hp", 1)))
	var hp := float(battle.enemy.get("hp", 0))
	if sh <= 0 or hp <= 0.0:
		return
	var blocked := float(sh)
	if _s4_cascade != null and _s4_cascade.total() > 0:
		blocked = float(mini(sh, _s4_cascade.total()))
	var right := clampf(hp - float(_last_preview_total), 0.0, mx)
	var left := clampf(right - blocked, 0.0, mx)
	if right - left <= 0.0:
		return
	var w := _shield_bar.size.x
	var r := Rect2(Vector2(w * left / mx, 0.0), Vector2(maxf(2.0, w * (right - left) / mx), _shield_bar.size.y))
	_shield_bar.draw_rect(r, Color(0.55, 0.78, 1.0, 0.6))
	if Settings.colorblind:   # 0.19.0 (264): o escudo às riscas (não só azul)
		var x := r.position.x - r.size.y
		while x < r.end.x:
			var a := Vector2(maxf(x, r.position.x), r.end.y - maxf(0.0, r.position.x - x))
			var b := Vector2(minf(x + r.size.y, r.end.x), r.position.y + maxf(0.0, x + r.size.y - r.end.x))
			_shield_bar.draw_line(a, b, Color(1, 1, 1, 0.55), 1.5)
			x += 7.0
	_shield_bar.draw_rect(r, Color(0.85, 0.94, 1.0, 0.95), false, 1.5)

## 108: o ouro do Excesso que o ataque previsto daria (a mesma conta do BattleManager._overkill).
func overkill_preview(net: int) -> int:
	if battle.puzzle or GameState.puzzle_id != "":
		return 0
	var hp := battle.hp_left()   # como o BattleManager._overkill (hp_before conta os dois na Dupla)
	var extra := net - hp
	if extra <= 0 or hp <= 0:
		return 0
	var last: Dictionary = battle.enemy2 if battle.pair_alive() else battle.enemy   # o _overkill corre depois da troca do _pair_fall
	var g := mini(BattleManager.OVERKILL_MAX, int(float(extra) / maxf(1.0, float(last.get("max_hp", 1)) * BattleManager.OVERKILL_STEP)))
	if g > 0 and GameState.relic_passive("overkill_double") > 0.0:
		g *= 2
	return maxi(0, g)

## 116: o ritual que acaba neste turno e a cura do Cerco também vão para a fila, e as ações levam o número da
## ordem em que acontecem (ataque → habilidades → ritual → cura).
func _intent_extra_chips() -> void:
	if not battle.ritual.is_empty() and int(battle.ritual.get("turns", 0)) <= 1:
		_intent_row.add_child(_intent_chip([["hourglass", COLOR_RITUAL, tr("Ritual")]], Color(0.24, 0.12, 0.32), true))
	if battle.objective == "siege" and int(battle.enemy.get("hp", 0)) < int(battle.enemy.get("max_hp", 0)):
		var h := int(ceil(float(battle.enemy.get("max_hp", 0)) * GameState.SIEGE_HEAL_PCT / 100.0))
		_intent_row.add_child(_intent_chip([["heart", Color(0.45, 0.95, 0.55), "+" + _num(h)]], Color(0.12, 0.26, 0.16), true))
	var chips := _intent_row.get_children()
	if chips.size() < 2:
		return
	for i in chips.size():
		var row := (chips[i] as PanelContainer).get_child(0) as HBoxContainer
		var n := UiKit.label("%d" % (i + 1), 13, Color(1, 1, 1, 0.55))
		n.name = "Order"
		n.mouse_filter = Control.MOUSE_FILTER_IGNORE
		n.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(n)
		row.move_child(n, 0)

## 103: o que cada relíquia vai dar no ataque previsto, num selo por cima dela.
func _s4_relic_previews(c: Cascade) -> void:
	var sums := {}   # id → [Poder, +Mult, ×Mult, ouro]
	if c != null:
		for st in c.steps:
			if st.source_kind != "relic" or st.source_id == "":
				continue
			var e: Array = sums.get(st.source_id, [0.0, 0.0, 1.0, 0.0])
			match st.action:
				"power_add":
					e[0] = float(e[0]) + float(st.value)
				"mult_add":
					e[1] = float(e[1]) + float(st.value)
				"mult_mul":
					e[2] = float(e[2]) * float(st.value)
				"gold":
					e[3] = float(e[3]) + float(st.value)
			sums[st.source_id] = e
	for id in _relic_views:
		var v = _relic_views[id]
		if not _alive(v):
			continue
		var e: Array = sums.get(id, [])
		var txt := ""
		var col := Color.WHITE
		if not e.is_empty():
			if float(e[2]) > 1.0001:
				txt = "×" + Cascade.fmt_mult(float(e[2]))
				col = COLOR_MULT_X.lightened(0.35)
			elif absf(float(e[1])) > 0.0001:
				txt = "+" + Cascade.fmt_mult(float(e[1]))
				col = COLOR_MULT.lightened(0.35)
			elif absf(float(e[0])) > 0.0001:
				txt = "+" + _num(int(e[0]))
				col = COLOR_POWER.lightened(0.3)
			elif absf(float(e[3])) > 0.0001:
				txt = "+%d" % int(e[3])
				col = COLOR_GOLD
		(v as RelicView).set_preview(txt, col)

## 105: as criaturas da Arena que fazem uma formação no ataque previsto (uid → nome curto).
func _formation_members(c: Cascade) -> Dictionary:
	var out := {}
	if c == null or c.formation_ids.is_empty():
		return out
	var creatures := battle.creatures()
	var cost_counts := {}
	var color_counts := {}
	for a in creatures:
		if not a.data.token and not a.data.wild_cost:
			cost_counts[a.data.cost] = int(cost_counts.get(a.data.cost, 0)) + 1
		if not a.data.wild_color:
			for col in a.data.colors:
				color_counts[col] = int(color_counts.get(col, 0)) + 1
	var best_col := ""
	var best := 0
	for k in color_counts:
		if int(color_counts[k]) > best:
			best = int(color_counts[k])
			best_col = String(k)
	var names := {}
	for fid in c.formation_ids:
		var nm := tr(String(FORMATION_SHORT.get(fid, fid)))
		for a in creatures:
			var inside := false
			if fid in COST_FORMATIONS:
				inside = not a.data.token and (a.data.wild_cost or int(cost_counts.get(a.data.cost, 0)) >= 2)
			elif fid == "devotion":
				inside = a.data.wild_color or best_col in a.data.colors
			elif fid in ["band", "horde", "curve", "wubrg"]:
				inside = true
			if inside:
				if not names.has(a.uid):
					names[a.uid] = []
				(names[a.uid] as Array).append(nm)
	for uid in names:
		var l: Array = names[uid]
		out[uid] = String(l[0]) + ((" +%d" % (l.size() - 1)) if l.size() > 1 else "")
	return out

## 106: as cartas da mão que, jogadas agora, juntam uma formação nova (só se volta a contar quando a mão, a Arena, a
## mana ou os feitiços mudam).
func _update_closers(c: Cascade) -> void:
	var board_ids: Array = []
	for x in battle.creatures():
		board_ids.append(x.uid)
	var sig := "%s|%s|%d|%d|%d|%s" % [str(_hand_views.keys()), str(board_ids), battle.mana_available, battle.spells_this_turn.size(), battle.turn,
		str(c.formation_ids) if c != null else ""]
	if sig == _s4_closer_sig:
		return
	_s4_closer_sig = sig
	_s4_closers.clear()
	if c == null or battle.finished or battle.resolving or _discard_mode:
		return
	for uid in _hand_views:
		var v = _hand_views[uid]
		if not _alive(v):
			continue
		var card: CardInstance = (v as CardView).card
		if card == null or not (card.data.is_creature() or card.data.is_spell()) or not battle.can_play(card):
			continue
		var c2 := battle.preview_cascade_with(card)
		if c2 == null:
			continue
		for fid in c2.formation_ids:
			if not (fid in c.formation_ids):
				_s4_closers[uid] = tr(String(FORMATION_SHORT.get(fid, fid)))
				break

## Marcas nas cartas: formação (105) na Arena; formação que fecha (106), cor fraca (107) e o brilho [Na Mão] (129)
## na mão.
func _s4_marks() -> void:
	if battle == null or battle.enemy.is_empty():
		return
	var c := _s4_cascade
	var members := _formation_members(c) if not _animating else {}
	for uid in _board_views:
		var bv = _board_views[uid]
		if _alive(bv):
			var m: Array = []
			if members.has(uid):
				m.append({"text": "◆ " + String(members[uid]), "color": COLOR_FORMATION})
			(bv as CardView).set_marks(m)
	var hand_bonus := {}
	if c != null and not _animating:
		for st in c.steps:
			if st.source_kind == "hand" and st.source_card != null:
				hand_bonus[st.source_card.uid] = true
	_update_closers(c)
	var weak_on := battle.weak_color != "" and not battle.puzzle
	for uid in _hand_views:
		var v = _hand_views[uid]
		if not _alive(v):
			continue
		var cv := v as CardView
		var m: Array = []
		if _s4_closers.has(uid):
			m.append({"text": tr("◆ fecha %s") % String(_s4_closers[uid]), "color": COLOR_FORMATION})
		if weak_on and cv.card != null and battle.weak_color in cv.card.data.colors:
			m.append({"text": "✦ " + tr("Fraco"), "color": COLOR_WEAK})
		cv.set_marks(m)
		cv.hand_glow = COLOR_HAND_GLOW if hand_bonus.has(uid) and not _discard_mode and battle.pending_bottom == 0 else Color(0, 0, 0, 0)

## 133: as poções e pergaminhos que, usados agora, acabam a batalha ganham um aro verde.
func _s4_item_glow(c: Cascade, hp: int, net: int) -> void:
	if _items_bar == null or not is_instance_valid(_items_bar) or not _items_bar.visible:
		return
	for i in GameState.consumables.size():
		var b := _items_bar.get_node_or_null("Item%d" % i) as Button
		if b == null:
			continue
		var hot := item_gives_lethal(GameState.consumables[i], c, hp, net)
		if bool(b.get_meta("lethal", false)) == hot:
			continue
		b.set_meta("lethal", hot)
		var base := b.get_theme_stylebox("normal") as StyleBoxFlat
		if base == null:
			continue
		var st := base.duplicate() as StyleBoxFlat
		st.border_color = Color(0.45, 1.0, 0.55) if hot else UiKit.GOLD
		st.shadow_color = Color(0.45, 1.0, 0.55, 0.65) if hot else Color(UiKit.GOLD, 0.35)
		st.shadow_size = 11 if hot else 5
		for k in ["normal", "hover", "pressed", "disabled"]:
			b.add_theme_stylebox_override(k, st)
		if hot:
			_bump(b, 1.15)

## Se a poção ou o pergaminho, usado agora, chega para acabar a batalha (com o ataque previsto).
func item_gives_lethal(id: String, c: Cascade, hp: int, net: int) -> bool:
	if hp <= 0 or net >= hp or battle.finished or not battle.can_use_consumable(id):
		return false
	var eff: Dictionary = CardDB.get_consumable(id).get("effect", {}) if CardDB.get_consumable(id).get("effect") is Dictionary else {}
	if int(eff.get("damage_pct", 0)) > 0:
		var dmg := int(round(float(battle.enemy.get("max_hp", 0)) * float(eff["damage_pct"]) / 100.0))
		return dmg >= hp or (net > 0 and net >= hp - dmg)
	if c == null or c.is_empty():
		return false
	if float(eff.get("attack_mult", 0.0)) > 0.0:
		return int(round(c.power * c.mult * float(eff["attack_mult"]) * c.damage_mult)) - c.shield >= hp
	if int(eff.get("power", 0)) > 0:
		var n := battle.creatures().size()
		return n > 0 and int(round((c.power + int(eff["power"]) * n) * c.mult * c.damage_mult)) - c.shield >= hp
	return false

## A vida do inimigo e, com um ataque previsto que não chega, quanto falta (109).
func _hp_text() -> void:
	if GameState.puzzle_id == "training" or battle.enemy.is_empty():
		return
	var base := "%s / %s" % [_num(int(battle.enemy.get("hp", 0))), _num(int(battle.enemy.get("max_hp", 0)))]
	if _need_text == "":
		enemy_hp_label.text = base
		enemy_hp_label.add_theme_font_size_override("font_size", 16)
		return
	var full := base + "  ·  " + _need_text
	enemy_hp_label.text = full if full.length() <= 30 else _num(int(battle.enemy.get("hp", 0))) + "  ·  " + _need_text
	enemy_hp_label.add_theme_font_size_override("font_size", 15)

func _s4_cascade_start() -> void:
	_need_text = ""
	_hp_text()
	for v in _relic_views.values():
		if _alive(v):
			(v as RelicView).set_preview("")
	for v in _hand_views.values():
		if _alive(v):
			(v as CardView).hand_glow = Color(0, 0, 0, 0)
	if _shield_bar != null:
		_shield_bar.queue_redraw()

# --- 118: foco na cascata ---

func _focus_views() -> Array:
	var out: Array = []
	for d in [_board_views, _relic_views, _spell_chips, _ench_chips, _equip_chips, _hand_views]:
		for v in d.values():
			if _alive(v):
				out.append(v)
	return out

func _focus_step(target: Control) -> void:
	if not bool(Settings.opt("focus_cascade")):
		return
	var views := _focus_views()
	if not (target in views):
		_focus_clear()
		return
	for v in views:
		(v as CanvasItem).modulate = Color.WHITE if v == target else Color(0.42, 0.42, 0.48)
	_focus_on = true

func _focus_clear() -> void:
	if not _focus_on:
		return
	_focus_on = false
	for v in _focus_views():
		(v as CanvasItem).modulate = Color.WHITE
	for id in GameState.stolen_relics:
		if _relic_views.has(id) and _alive(_relic_views[id]):
			(_relic_views[id] as CanvasItem).modulate = Color(0.45, 0.45, 0.5, 0.55)

# --- 115: encantamentos separados dos feitiços do turno ---

func _refresh_ench_sep() -> void:
	if _ench_box == null:
		return
	var sep := _ench_box.get_node_or_null("EnchSep") as Control
	var want := not battle.spells_this_turn.is_empty() and not (battle.enchantments.is_empty() and battle.equipment.is_empty())
	if sep == null and want:
		var r := ColorRect.new()
		r.name = "EnchSep"
		r.color = Color(COLOR_ENCHANT, 0.6)
		r.custom_minimum_size = Vector2(2, 38)
		r.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_ench_box.add_child(r)
		sep = r
	if sep != null:
		_ench_box.move_child(sep, -1)
		sep.visible = want

# --- 117: o turno do inimigo em 3 segundos ---

func _show_enemy_recap() -> void:
	_enemy_turn_logging = false
	if _enemy_log_from < 0 or battle.finished:
		return
	var from := clampi(_enemy_log_from, 0, _history.size())
	_enemy_log_from = -1
	var took := tr("Levaste %d de dano.").get_slice("%d", 0)   # B10: «Levaste » / «You took »: o dano levado vem primeiro
	var lines: Array = []
	var rest: Array = []
	for i in range(from, _history.size()):
		var l := String(_history[i])
		var cut := l.find("  ")
		if l.begins_with("T") and cut > 0 and cut <= 4:
			l = l.substr(cut + 2)
		if l.begins_with(took):
			lines.append(l)
		else:
			rest.append(l)
	lines.append_array(rest)
	_enemy_recap = lines
	if lines.is_empty():
		return
	_warn(tr("No turno dele: ") + "  ·  ".join(PackedStringArray(lines.slice(0, 3))), Color(0.75, 0.6, 1.0), 3.0, false, true)   # até 3 linhas

# --- 130: o clima a agir ---

func _climate_turn_notices(t: int) -> void:
	match battle.climate:
		"aether_tide":
			if t == 1:
				_climate_notice("aether1", tr("os feitiços custam 0 neste turno."))
			elif t == 4 or t == 5:
				_climate_notice("aether%d" % t, tr("os feitiços custam +1 neste turno."))
		"scorching_sands":
			if t == 4:
				_climate_notice("sands", tr("a mão só se repõe até 5 cartas, mas o ataque ganha ×1,5 Mult."))
		"high_tide":
			if t == 1:
				_climate_notice("tide", tr("tens mais 1 carta na mão, mas o inimigo ataca +1."))
		"eternal_winter":
			if t == 1:
				_climate_notice("winter", tr("não podes canalizar nesta batalha."))
		"mana_eclipse":
			if battle.mana_total >= 5:
				_climate_notice("eclipse", tr("a mana não passa de 5."))

func _climate_notice(key: String, text: String) -> void:
	if battle.climate == "" or battle.puzzle or _climate_told.has(key) or not is_inside_tree():
		return
	_climate_told[key] = true
	if _alive(_climate_notice_node):
		_climate_notice_node.queue_free()
	var panel := PanelContainer.new()
	panel.name = "ClimateNotice"
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.z_index = 50
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.05, 0.13, 0.15, 0.95), 12, COLOR_CLIMATE, 2, 8))
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 8)
	panel.add_child(row)
	var ic := CardIcon.new("climate", COLOR_CLIMATE, 22.0)
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(ic)
	var nm := tr(String(CardDB.get_climate(battle.climate).get("name", "")))
	var l := UiKit.label(nm + ": " + text, 16, Color.WHITE)
	l.name = "Text"
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(l)
	var hold := Settings.toast_seconds(2.6)   # 0.20.0 (B10): o «tempo dos avisos» (era Settings.dur(2.6): 1 s na velocidade máxima)
	if hold <= 0.0:   # «até tocares»: só aqui apanha o toque, para se fechar
		panel.mouse_filter = Control.MOUSE_FILTER_STOP
		panel.gui_input.connect(_close_on_tap.bind(panel))
	add_child(panel)
	_climate_notice_node = panel
	panel.modulate.a = 0.0
	await get_tree().process_frame
	if not is_instance_valid(panel) or not is_inside_tree():
		return
	panel.reset_size()
	var pos := _top_slot(panel.size, false)
	panel.global_position = Vector2(pos.x, 58.0)
	var tw := create_tween()
	tw.tween_property(panel, "modulate:a", 1.0, 0.15)
	if hold <= 0.0:
		return
	tw.tween_interval(hold)
	tw.tween_property(panel, "modulate:a", 0.0, 0.3)
	tw.tween_callback(func():
		if is_instance_valid(panel):
			panel.queue_free())

# --- 131, 132: contadores das mecânicas num só sítio ---

func _add_mech_chip() -> void:
	_mech_chip = UiKit.info_chip("star", "", Color(0.85, 0.8, 1.0), _open_mech_info)
	_mech_chip.name = "MechChip"
	_mech_label = _mech_chip.get_meta("label")
	pw_row.add_child(_mech_chip)
	_refresh_mech_chip()

func _mech_tags_in_deck() -> Dictionary:
	if _mech_deck_tags.is_empty() and battle.deck != null:
		var pool: Array = []
		pool.append_array(battle.deck.library)
		pool.append_array(battle.deck.hand)
		pool.append_array(battle.deck.graveyard)
		pool.append_array(battle.board)
		pool.append_array(battle.enchantments)
		for c in pool:
			for t in mech_tags((c as CardInstance).data):
				_mech_deck_tags[t] = true
			if (c as CardInstance).data.has_keyword("prowess"):
				_mech_deck_tags["prowess"] = true
		_mech_deck_tags["_done"] = true
	return _mech_deck_tags

func _vet_stars_on_board() -> int:
	var stars := 0
	for c in battle.board:
		stars += c.vet_stars()
	return stars

func _prowess_on() -> bool:
	if battle.has_rule("all_prowess"):
		return true
	for c in battle.board:
		if c.has_keyword("prowess"):
			return true
	return false

## Os contadores curtos (para o chip): só os das mecânicas que esta batalha usa.
func mech_entries() -> Array[String]:
	var out: Array[String] = []
	if battle == null or battle.deck == null:
		return out
	var tags := _mech_tags_in_deck()
	if _prowess_on():
		out.append(tr("Destreza +%d") % battle.spells_this_turn.size())
	if tags.has("energy") or battle.energy > 0:
		out.append(tr("Energia %d") % battle.energy)
	if battle.crown:
		out.append(tr("Coroa"))
	var stars := _vet_stars_on_board()
	if stars > 0:
		out.append(tr("Veteranos ★%d") % stars)
	if tags.has("delirium") or battle.has_rule("always_delirium"):
		out.append(tr("Delírio ✓") if battle.has_delirium() else tr("Delírio %d/4") % mini(4, battle.graveyard_types()))
	if tags.has("domain") or battle.has_rule("full_domain"):
		out.append(tr("Domínio %d/5") % mini(5, battle.domain_count()))
	return out

func _refresh_mech_chip() -> void:
	if not _alive(_mech_chip) or battle == null or battle.deck == null:
		return
	var parts := mech_entries()
	_mech_label.text = "  ·  ".join(PackedStringArray(parts))
	_mech_chip.visible = not parts.is_empty()
	var any := false
	for c in pw_row.get_children():
		if c is Control and (c as Control).visible and not c.is_queued_for_deletion():
			any = true
	pw_row.visible = any

## O que cada contador quer dizer e, no Delírio e no Domínio, o que já está e o que falta.
func mech_details() -> Array[String]:
	var lines: Array[String] = []
	var tags := _mech_tags_in_deck()
	if _prowess_on():
		lines.append(tr("Destreza: %d feitiço(s) neste turno; cada criatura com Destreza dá +1 Mult por feitiço.") % battle.spells_this_turn.size())
	if tags.has("energy") or battle.energy > 0:
		lines.append(tr("Energia: %d. Ganha-se com cartas e gasta-se em efeitos; dura a batalha.") % battle.energy)
	if battle.crown:
		lines.append(tr("Coroa: +1 carta no início de cada turno, até levares dano."))
	var stars := _vet_stars_on_board()
	if stars > 0:
		lines.append(tr("Veteranos: %d estrela(s) nas criaturas da Arena (+%d Poder cada, até ao fim da run).") % [stars, BattleManager.VETERAN_POWER])
	if tags.has("delirium") or battle.has_rule("always_delirium"):
		var have: Array[String] = []
		var miss: Array[String] = []
		var seen := {}
		for g in battle.deck.graveyard:
			seen["spell" if g.data.is_spell() else g.data.type] = true
		for t in BattleManager.DELIRIUM_TYPES:
			(have if seen.has(t) else miss).append(tr(String(TYPE_NAMES.get(t, t))))
		if battle.has_delirium():
			lines.append(tr("Delírio ativo: os 4 tipos de carta estão no cemitério."))
		elif have.is_empty():
			lines.append(tr("Delírio: o cemitério está vazio; faltam %s.") % ", ".join(PackedStringArray(miss)))
		else:
			lines.append(tr("Delírio: no cemitério há %s; faltam %s.") % [", ".join(PackedStringArray(have)), ", ".join(PackedStringArray(miss))])
	if tags.has("domain") or battle.has_rule("full_domain"):
		var played: Array[String] = []
		var left: Array[String] = []
		for col in CardZoom.COLOR_NAMES:
			(played if col in battle.land_colors else left).append(tr(String(CardZoom.COLOR_NAMES[col])))
		if battle.domain_count() >= 5:
			lines.append(tr("Domínio completo: Terrenos das 5 cores."))
		elif played.is_empty():
			lines.append(tr("Domínio: ainda sem Terrenos; faltam %s.") % ", ".join(PackedStringArray(left)))
		else:
			lines.append(tr("Domínio: Terrenos de %s; faltam %s.") % [", ".join(PackedStringArray(played)), ", ".join(PackedStringArray(left))])
	return lines

func _open_mech_info() -> void:
	CardZoom.show_text(tr("Contadores"), "\n\n".join(PackedStringArray(mech_details())), tr("Mecânicas desta batalha"), Color(0.85, 0.8, 1.0))

# --- 121: os botões desligados dizem porquê ---

func _pw_why(i: int) -> String:
	if battle.resolving or _animating:
		return tr("Espera que o ataque acabe.")
	if battle.pw_used_this_turn:
		return tr("O patrono já agiu neste turno.")
	var skills := battle.planeswalker_skills()
	if i < skills.size() and int(skills[i].get("cost", 0)) < 0:
		return tr("Falta lealdade: precisa de %d.") % -int(skills[i].get("cost", 0))
	return ""

func _s4_explain() -> void:
	UiKit.explain(end_turn_btn, func() -> String:
		if battle.resolving or _animating:
			return tr("Espera que o ataque acabe.")
		if battle.finished:
			return tr("A batalha acabou.")
		return "")
	UiKit.explain(undo_btn, func() -> String:
		if battle.resolving or _animating:
			return tr("Espera que o ataque acabe.")
		if _undo_stack.is_empty():
			return tr("Nada para desfazer neste turno.")
		return "")
	UiKit.explain(discard_btn, func() -> String:
		if battle.resolving or _animating:
			return tr("Espera que o ataque acabe.")
		if battle.climate == "eternal_winter":
			return tr("O Inverno Eterno não deixa canalizar.")
		if battle.discards_left <= 0:
			return tr("Já não podes canalizar neste turno.")
		return "")


# ---------------------------------------------------------------------------
# 0.19.0 (secção 5) — legibilidade e HUD (135–168)
# ---------------------------------------------------------------------------

var _enemy_text_base := ""
var _enemy_collapsed := false
var _relic_count: Label
var _icon_caps: Array = []

func _make_s5_widgets() -> void:
	# 147: algarismos todos da mesma largura no cálculo (o total a contar não dança).
	var tnum := FontVariation.new()
	tnum.base_font = total_label.get_theme_font("font")
	tnum.opentype_features = {TextServerManager.get_primary_interface().name_to_tag("tnum"): 1}
	for l in [total_label, power_label, mult_label]:
		(l as Label).add_theme_font_override("font", tnum)
	end_turn_btn.set_meta("own_long_press", true)   # 143: segurar o ATACAR é a jogada (não abre a explicação)
	# 162: tocar no nome do inimigo recolhe o painel (o retrato e o texto) e volta a abri-lo.
	enemy_name.mouse_filter = Control.MOUSE_FILTER_STOP
	enemy_name.tooltip_text = tr("Toca para recolher ou abrir o painel do inimigo.")
	enemy_name.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and (ev as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT and not ev.pressed and not SceneRouter.has_overlay():
			toggle_enemy_panel())
	_refresh_icon_captions()
	Settings.changed.connect(_refresh_icon_captions)

## Depois de cada _refresh_all: a regra do boss com o efeito em ti, o contrato a contar e as relíquias.
func _s5_refresh() -> void:
	if battle == null or battle.enemy.is_empty():
		return
	var eff := rule_effect_text()
	if _enemy_text_base != "" or eff != "":
		# o efeito em ti à frente (o texto da regra é comprido e corta no fim)
		enemy_text.text = (eff + ("  ·  " if _enemy_text_base != "" else "") if eff != "" else "") + _enemy_text_base
	if _alive(_contract_chip) and not GameState.contract.is_empty():
		var lab: Label = _contract_chip.get_meta("label")
		var prog := contract_progress()
		lab.text = tr(String(GameState.contract.get("name", ""))) + ("  ·  " + prog if prog != "" else "")
	# 153: quantas relíquias tens (e cabem), ao lado da prateleira (a prateleira refaz-se: a etiqueta volta).
	if not _alive(_relic_count) or _relic_count.get_parent() != relics_bar:
		_relic_count = UiKit.label("", 12, Color(0.85, 0.8, 1.0, 0.85))
		_relic_count.name = "RelicCount"
		_relic_count.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_relic_count.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
		relics_bar.add_child(_relic_count)
	_relic_count.text = "%d/%d" % [GameState.relic_ids.size(), GameState.max_relics()]
	relics_bar.move_child(_relic_count, -1)

## 157: o efeito da regra do inimigo em ti, agora («(tens 14 de ouro)»).
func rule_effect_text() -> String:
	var r: Dictionary = battle.rule
	if battle.silenced or r.is_empty():
		return ""
	if int(r.get("gold_tax", 0)) > 0:
		return tr("(tens %d de ouro)") % GameState.gold
	if int(r.get("attack_per_graveyard", 0)) > 0:
		return tr("(agora: +%d de ataque)") % int(battle.deck.graveyard.size() / int(r["attack_per_graveyard"]))
	if int(r.get("max_creatures", 0)) > 0:
		return tr("(%d de %d na Arena)") % [battle.creatures().size(), int(r["max_creatures"])]
	if int(r.get("discards_minus", 0)) > 0:
		return tr("(podes canalizar %d)") % battle.discards_left
	if r.has("hand_size") or int(r.get("hand_shrink", 0)) > 0:
		return tr("(a mão repõe-se até %d)") % battle.hand_size
	if int(r.get("creature_cost_plus", 0)) > 0:
		return tr("(as tuas criaturas custam +%d)") % int(r["creature_cost_plus"])
	return ""

## 158: como vai o contrato nesta batalha («2 de 3 formações»; ✓ ou ✗ nos de «sem…»).
func contract_progress() -> String:
	var cond: Dictionary = GameState.contract.get("cond", {}) if GameState.contract.get("cond") is Dictionary else {}
	if cond.has("win_by_turn"):
		return tr("turno %d de %d") % [battle.turn, int(cond["win_by_turn"])]
	if bool(cond.get("no_channel", false)):
		return "✓" if battle.discards_used == 0 else "✗"
	if bool(cond.get("no_damage", false)):
		return "✓" if battle.life_lost == 0 else "✗"
	if bool(cond.get("no_lands", false)):
		return "✓" if battle.lands_played == 0 else "✗"
	if cond.has("big_hit_pct"):
		return tr("%d%% de %d%%") % [int(battle.best_hit_pct), int(cond["big_hit_pct"])]
	if cond.has("formations"):
		return tr("%d de %d formações") % [battle.max_formations, int(cond["formations"])]
	if cond.has("attackers"):
		return tr("%d de %d atacantes") % [battle.max_attackers, int(cond["attackers"])]
	if cond.has("flashbacks"):
		return tr("%d de %d recapitulações") % [battle.flashbacks_used, int(cond["flashbacks"])]
	return ""

## 162: recolhe (ou abre) o painel do inimigo — fica o nome, a vida e a intenção.
func toggle_enemy_panel() -> void:
	_enemy_collapsed = not _enemy_collapsed
	Sfx.select()
	if _portrait != null:
		_portrait.visible = not _enemy_collapsed
	if _pair_portrait != null:
		_pair_portrait.visible = not _enemy_collapsed and battle.pair_alive()
	enemy_text.visible = not _enemy_collapsed
	if _portrait_box != null:
		_portrait_box.custom_minimum_size.y = 44.0 if _enemy_collapsed else PORTRAIT_MIN + 8.0
		_portrait_box.size_flags_vertical = Control.SIZE_SHRINK_BEGIN if _enemy_collapsed else Control.SIZE_EXPAND_FILL
	enemy_name.text = tr(String(battle.enemy.name)) + ("  ▾" if _enemy_collapsed else "")
	_layout_portrait_box.call_deferred()
	_refresh_overlay.call_deferred()

func enemy_collapsed() -> bool:
	return _enemy_collapsed

## 142: nomes por baixo dos ícones (opção).
func _refresh_icon_captions() -> void:
	for c in _icon_caps:
		if is_instance_valid(c):
			c.queue_free()
	_icon_caps.clear()
	if not bool(Settings.opt("icon_labels")):
		return
	for pair in [[pause_btn, tr("Pausa")], [undo_btn, tr("Desfazer")], [library_btn, tr("Grimório")], [graveyard_btn, tr("Cemitério")], [_grid_btn, tr("Grelha")]]:
		var b: Control = pair[0]
		if b == null or not is_instance_valid(b):
			continue
		var l := UiKit.label(String(pair[1]), 11, Color(0.9, 0.88, 0.96, 0.85))
		l.name = "IconCaption"
		l.mouse_filter = Control.MOUSE_FILTER_IGNORE
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
		l.add_theme_constant_override("outline_size", 4)
		l.z_index = 6
		b.add_child(l)
		l.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
		l.offset_left = -40.0
		l.offset_right = 40.0
		l.offset_top = 0.0
		l.offset_bottom = 15.0
		_icon_caps.append(l)

func icon_captions() -> int:
	return _icon_caps.size()


# ---------------------------------------------------------------------------
# 0.19.0 (secção 6) — respeito pelo tempo e pela sessão
# ---------------------------------------------------------------------------

## 181: a entrada de cinema do boss já foi vista (com a opção ligada; marca-a na 1.ª vez).
func _intro_seen_before() -> bool:
	var id := String(battle.enemy.get("id", ""))
	if not (GameState.progress.get("intros_seen") is Array):
		GameState.progress["intros_seen"] = []
	var seen: Array = GameState.progress["intros_seen"]
	var before := id in seen
	if not before and id != "":
		seen.append(id)
	return before and bool(Settings.opt("intro_once"))

## 189: numa cascata com muitos passos (mais de 40, ou mais de 24 no Infinito), os índices dos que se mostram:
## formações, ×Mult e os maiores (no máximo 14). Vazio = mostra-se tudo.
func summary_steps(c: Cascade) -> Dictionary:
	var n := c.steps.size()
	if n <= 40 and not (GameState.endless and n > 24):
		return {}
	var keep := {}
	var scored: Array = []
	for i in n:
		var st: Cascade.Step = c.steps[i]
		if st.source_kind == "formation" or st.action == "mult_mul":
			keep[i] = true
		elif st.action in ["power_add", "mult_add"]:
			var gain := float(st.value) * (st.mult_after if st.action == "power_add" else float(st.power_after))
			scored.append([gain, i])
	scored.sort_custom(func(a, b): return float(a[0]) > float(b[0]))
	for k in scored:
		if keep.size() >= 14:
			break
		keep[int(k[1])] = true
	keep[n - 1] = true
	return keep

# --- 0.19.0 (279, 280): modo assistido — rebobinar o turno e repetir a batalha perdida ---
var _turn_snap: Dictionary = {}       # início deste turno: {"battle", "run"}
var _rewind_snap: Dictionary = {}     # início do turno anterior (o que já atacou)
var _battle_snap: Dictionary = {}     # início da batalha (ou de quando a retomaste)

func _assist_turn_snapshot(t: int) -> void:
	if battle.puzzle or GameState.puzzle_id != "" or battle.finished:
		return
	var snap := {"battle": battle.to_dict(), "run": GameState.shop_snapshot(), "hp": GameState.player_hp}
	if _battle_snap.is_empty():
		_battle_snap = snap
	if t > 1 and not _turn_snap.is_empty():
		_rewind_snap = _turn_snap
		if bool(Settings.opt("assist_rewind")) and not _rewind_used():
			_log(tr("↺ Modo assistido: podes rebobinar o turno anterior na pausa (uma vez por batalha)."))
	_turn_snap = snap

func _rewind_key() -> String:
	return "rewind_%d_%s" % [GameState.ante, GameState.map_phase]

func _rewind_used() -> bool:
	return bool(GameState.run_log.get(_rewind_key(), false))

func can_rewind() -> bool:
	return bool(Settings.opt("assist_rewind")) and not _rewind_snap.is_empty() and not _rewind_used() and not battle.resolving \
		and not battle.finished and GameState.puzzle_id == ""

func rewind_turn() -> void:
	if not can_rewind():
		return
	Sfx.select()
	_restore_snap(_rewind_snap, _rewind_key())

## mark: chave do run_log a gravar (o restore repõe o run_log do início da batalha, por isso marca-se depois).
func _restore_snap(snap: Dictionary, mark: String = "") -> void:
	GameState.restore_shop_snapshot(snap["run"])
	if mark != "":
		GameState.run_log[mark] = true
	GameState.player_hp = int(snap.get("hp", GameState.player_hp))
	var st: Dictionary = (snap["battle"] as Dictionary).duplicate(true)
	GameState.pending_battle = st
	GameState.save_run(st, "battle")
	SceneRouter.go("battle")

func _offer_retry() -> bool:
	if not bool(Settings.opt("assist_retry")) or _battle_snap.is_empty() or bool(GameState.run_log.get("retry_used", false)) \
			or GameState.puzzle_id != "" or GameState.mode in ["tower", "rush"]:
		return false
	_show_banner(_defeat_banner(), 1.0)
	await get_tree().create_timer(_d(1.0)).timeout
	var d := ChoiceDialog.open(tr("REPETIR A BATALHA?"), tr("Modo assistido: podes recomeçar esta batalha desde o início, uma vez nesta run (em vez de a run acabar)."),
		[[tr("REPETIR A BATALHA"), "retry", true], [tr("ACABAR A RUN"), "end"]], Color(1.0, 0.62, 0.55))
	d.name = "RetryOffer"
	d.buttons_only = true   # A2 (TR3): tocar fora ou retroceder não pode acabar a run
	var v = await d.chosen
	if v != "retry":
		return false
	_restore_snap(_battle_snap, "retry_used")
	return true

## 0.20.0 (B9): «DERROTA» e, por baixo, porquê.
func _defeat_banner() -> String:
	return tr("DERROTA") + "\n" + GameState.loss_cause(battle.loss_report())

## 213: uma cascata com muitos passos (mais de 24) leva menos efeitos por passo (ficam os números e o som).
func cascade_is_heavy(c: Cascade) -> bool:
	return c != null and c.steps.size() > 24

## 184: sem mana nem jogadas, ataca sozinho daqui a 1 s (tocar no ecrã cancela).
var _auto_end_id := 0

func _start_auto_end() -> void:
	_auto_end_id += 1
	var id := _auto_end_id
	_warn(tr("Sem jogadas: ataque automático em 1 s (toca para cancelar)."), UiKit.GOLD, 1.2, true)
	await get_tree().create_timer(Settings.dur(1.0) + 0.05).timeout
	if id != _auto_end_id or not is_inside_tree() or battle.finished or battle.resolving or SceneRouter.has_overlay() or not _no_plays_left() \
			or _risky_attack():   # nunca ataca nem arma o 2.º toque num ataque que perde a run
		return
	_on_end_turn()

func cancel_auto_end() -> void:
	_auto_end_id += 1

## 188: o resumo das recompensas num aviso («VITÓRIA · +12 ouro · Tambor de Guerra»).
func rewards_toast_text(title: String, r: Dictionary, reveals: Array) -> String:
	var parts: Array[String] = [title]
	var g := int(r.get("gold_after", GameState.gold)) - int(r.get("gold_before", GameState.gold))
	if g != 0:
		parts.append(tr("+%d ouro") % g)
	for rv in reveals:
		if rv is Array and (rv as Array).size() >= 2:
			var kind := String(rv[0])
			var id := String(rv[1])
			if kind == "relic":
				parts.append(tr(String(CardDB.relics.get(id, {}).get("name", id))))
			elif kind == "text":
				parts.append(id)
			else:
				parts.append(tr(String(CardDB.get_consumable(id).get("name", id))))
	return "  ·  ".join(PackedStringArray(parts))

## 199: dá para voltar ao mapa e escolher outro nó (no 1.º turno, antes de jogares alguma coisa).
func can_undo_node() -> bool:
	return GameState.can_undo_node() and not _resumed and battle.turn == 1 and not battle.finished and not battle.resolving \
		and battle.board.is_empty() and battle.spells_this_turn.is_empty() and battle.lands_played == 0 and battle.discards_used == 0 \
		and GameState.puzzle_id == ""

func undo_node() -> void:
	if not can_undo_node():
		return
	Sfx.select()
	if GameState.undo_node_choice():
		SceneRouter.go("map")
