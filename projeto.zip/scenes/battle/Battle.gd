extends Control
## Cena de batalha (horizontal). Liga a UI ao BattleManager através do EventBus e anima:
## cartas a voar da mão para o tabuleiro, compra, investida das criaturas na cascata,
## impacto no inimigo, número de dano a voar, partículas no total, banner de ante.
## Grava a run no início de cada turno (BattleManager.to_dict) e retoma-a se houver uma
## batalha pendente em GameState.pending_battle. Pausa, carta em grande e grimório/cemitério
## abrem como overlays (SceneRouter.show_overlay) sem destruir a cena.
## 0.10.0: mão em leque (FanHand), relíquias em medalhões, turnos em pips, retrato do inimigo,
## fundo por ato com o clima, medidor da Cadeia, encantamentos na faixa dos feitiços, escudo e
## lacaios do inimigo, janela de Reação, escolha do Reforço, avisos opcionais, histórico (tocar na
## linha de log), efeitos por cor na cascata e Némesis com falas.

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const RELIC_VIEW := preload("res://scenes/ui/RelicView.tscn")
const FIRE_SHADER := preload("res://assets/shaders/fire.gdshader")

const COLOR_POWER := Color(0.22, 0.74, 0.97)
const COLOR_MULT := Color(0.96, 0.25, 0.37)
const COLOR_MULT_X := Color(0.72, 0.35, 0.95)
const COLOR_FORMATION := Color(0.98, 0.75, 0.25)
const COLOR_GROW := Color(0.35, 0.85, 0.45)
const COLOR_GOLD := Color(0.98, 0.85, 0.3)
const COLOR_SEAL := Color(0.9, 0.5, 0.9)
const COLOR_CLIMATE := Color(0.35, 0.8, 0.85)
const COLOR_BOSS_RELIC := Color(0.95, 0.4, 0.4)
const DISCARD_TINT := Color(0.8, 0.6, 1.0)
const BOTTOM_TINT := Color(0.6, 0.8, 1.0)
const VARIANT_NAMES := {"scout": "Batedor", "guard": "Guarda", "elite": "Elite", "boss": "Boss", "nemesis": "Némesis", "arena": "Campeão da Arena"}
const COLOR_TRIBE := Color(0.55, 0.9, 0.75)
const COLOR_CHAIN := Color(1.0, 0.62, 0.3)
const COLOR_ENCHANT := Color(0.75, 0.6, 1.0)
const HISTORY_MAX := 30

const ABILITY_LOG := {
	"steal_gold": "roubou-te ouro",
	"heal_self": "curou-se",
	"destroy_strongest": "destruiu a tua criatura mais forte",
	"damage_all_creatures": "feriu todas as tuas criaturas",
	"discard_random": "fez-te descartar uma carta",
	"gold_tax": "cobrou-te ouro",
	"heal_self_pct": "recuperou vida",
	"steal_card": "roubou-te a carta mais cara da mão",
	"mirror_best": "copiou a tua criatura mais forte",
	"grow_attack": "ficou mais forte",
	"drain_mana": "sugou-te mana para o próximo turno",
	"grow_shield": "reforçou o escudo",
	"jail_strongest": "prendeu a tua criatura mais forte",
	"shuffle_board": "baralhou a ordem da tua Arena",
	"punish_channel": "castigou a canalização",
	"charge_attack": "está a carregar um golpe forte",
	"steal_relic": "desligou-te uma relíquia",
}

@onready var battle: BattleManager = $BattleManager
@onready var layout: Control = $Layout
@onready var hand_box: FanHand = %Hand
@onready var board_box: HBoxContainer = %Board
@onready var spell_strip: HBoxContainer = %SpellStrip
@onready var spell_hint: Label = %SpellHint
@onready var relics_bar: HBoxContainer = %RelicsBar
@onready var turn_label: Label = %TurnLabel
@onready var gold_label: Label = %GoldLabel
@onready var pause_btn: Button = %PauseBtn
@onready var enemy_panel: Control = %EnemyPanel
@onready var enemy_name: Label = %EnemyName
@onready var enemy_hp_bar: ProgressBar = %EnemyHPBar
@onready var enemy_hp_ghost: ProgressBar = %EnemyHPGhost
@onready var enemy_hp_label: Label = %EnemyHPLabel
@onready var enemy_text: Label = %EnemyText
@onready var counter_label: Label = %CounterLabel
@onready var emblem: PanelContainer = %Emblem
@onready var emblem_label: Label = %EmblemLabel
@onready var log_label: Label = %LogLabel
@onready var undo_btn: Button = %UndoBtn
@onready var player_label: Label = %PlayerLabel
@onready var mana_label: Label = %ManaLabel
@onready var end_turn_btn: Button = %EndTurn
@onready var discard_btn: Button = %DiscardBtn
@onready var library_btn: Button = %LibraryBtn
@onready var graveyard_btn: Button = %GraveyardBtn
@onready var formation_label: Label = %FormationLabel
@onready var power_label: Label = %PowerLabel
@onready var mult_label: Label = %MultLabel
@onready var total_label: Label = %TotalLabel
@onready var power_pill: Control = %PowerPill
@onready var mult_pill: Control = %MultPill
@onready var banner: Label = %Banner
@onready var mulligan_btn: Button = %MulliganBtn
@onready var pw_row: HBoxContainer = %PwRow

var _board_views: Dictionary = {}   # uid -> CardView
var _hand_views: Dictionary = {}    # uid -> CardView
var _spell_chips: Dictionary = {}   # uid -> Control
var _relic_views: Dictionary = {}   # relic_id -> RelicView
var _animating: bool = false
var _skip_cascade: bool = false   # 0.11.0: tocar no ecrã durante a cascata salta para o total
var _discard_mode: bool = false
var _layout_base: Vector2
var _particles: CPUParticles2D
var _hp_tween: Tween
var _pause_menu: PauseMenu
var _resumed: bool = false
var _undo_stack: Array[Dictionary] = []
var _undo_turn: int = 0
var _drag_ghost: Control
var _drag_view: Control
var _attack_style: StyleBoxFlat
var _lethal_style: StyleBoxFlat
var _last_preview_total: int = 0
var _pw_buttons: Array[Button] = []
var _pw_loyalty: Label
var _pw_name: Label
var _pw_panel: Control
var _climate_chip: Control
var _climate_label: Label
var _contract_chip: Control
var _bubble: Control
var _bubble_tw: Tween
var _banner_tw: Tween
var _banner_lock_until: int = 0
var _hp_marker: ColorRect
var _fire_layer: Control
var _fire_rects: Array[ColorRect] = []
var _fire_level: float = 0.0
var _fire_target: float = 0.0
var _hit_line_said: bool = false
var _mana_pips: ManaPips
var _intent_row: HBoxContainer
var _intent_sig: String = ""
var _last_cascade: Cascade
# 0.10.0
var _backdrop: BattleBackdrop
var _portrait: EnemyPortrait
var _turn_pips: TurnPips
var _chain_meter: ChainMeter
var _ench_box: HBoxContainer
var _ench_chips: Dictionary = {}   # uid -> Control
var _defense_row: HBoxContainer
var _history: Array[String] = []
var _modal: Control                # janela de Reação / escolha do Reforço / aviso
var _drag_shadow: Panel
var _drag_last_x: float = 0.0
# 0.12.1: mão — carta escolhida (1.º toque) e carta a ser arrastada (a flutuar).
var _selected_uid: int = -1
var _sel_hint: bool = false     # a linha de texto mostra a dica da carta escolhida (não vai para o histórico)
var _last_log: String = ""      # última mensagem a sério (volta quando a escolha acaba)
var _hand_drag_card: CardInstance = null
var _play_zone: bool = false
# 0.13.0
var _overlay: BattleOverlay          # números de ordem, etiquetas e setas do inimigo por cima da Arena
var _notice: Control                 # aviso curto no topo (não tapa o cálculo)
var _what_if: bool = false           # o cálculo mostra o ataque com a carta arrastada
var _no_plays_turn: int = 0          # turno em que já se avisou "sem jogadas"
var _attack_glow: Tween              # ATACAR a brilhar quando não há mais jogadas
var _kw_bubble: Control              # explicação de uma palavra-chave (tocar no ícone)
var _last_attack_turn: int = 0       # turno do último ataque (para o "rever")

## Ícones da intenção do inimigo: ação → [ícone, cor, mostra o valor?]
const INTENT_ICONS := {
	"steal_gold": ["coin", Color(0.98, 0.8, 0.3), true],
	"heal_self": ["cross", Color(0.45, 0.9, 0.5), true],
	"destroy_strongest": ["skull", Color(0.92, 0.92, 0.92), false],
	"damage_all_creatures": ["burst", Color(1.0, 0.6, 0.3), true],
	"discard_random": ["card", Color(0.8, 0.6, 1.0), true],
	"heal_self_pct": ["cross", Color(0.45, 0.9, 0.5), true],
	"grow_attack": ["creature", Color(1.0, 0.45, 0.4), true],
	"drain_mana": ["mana", Color(0.6, 0.75, 1.0), true],
	"grow_shield": ["shield", Color(0.7, 0.85, 1.0), true],
	"jail_strongest": ["lock", Color(0.75, 0.75, 0.85), false],
	"shuffle_board": ["card", Color(0.95, 0.7, 1.0), false],
	"mirror_best": ["mirror", Color(0.78, 0.86, 1.0), false],
	"steal_card": ["card", Color(0.98, 0.8, 0.3), false],
	"charge_attack": ["instant", Color(1.0, 0.62, 0.2), false],
	"steal_relic": ["relic", Color(0.98, 0.8, 0.3), false],
}

const ABILITY_INTENT := {
	"steal_gold": "rouba %d ouro",
	"heal_self": "cura-se %d",
	"destroy_strongest": "destrói a tua criatura mais forte",
	"damage_all_creatures": "%d de dano às tuas criaturas",
	"discard_random": "descarta-te %d carta(s)",
	"heal_self_pct": "cura-se %d%% da vida",
	"steal_card": "rouba a tua carta mais cara",
	"mirror_best": "copia a tua criatura mais forte",
	"grow_attack": "o ataque dele sobe %d",
	"drain_mana": "tens −%d de mana no próximo turno",
	"grow_shield": "o escudo sobe %d%%",
	"jail_strongest": "prende a tua criatura mais forte (não ataca no turno seguinte)",
	"shuffle_board": "baralha a ordem da tua Arena",
	"charge_attack": "carrega um golpe forte: no turno seguinte ataca com ×%s",
	"steal_relic": "desliga a tua relíquia mais à esquerda até ao fim da batalha",
}

func _ready() -> void:
	_layout_base = layout.position
	EventBus.enemy_hp_changed.connect(_on_enemy_hp)
	EventBus.player_hp_changed.connect(_set_life)
	EventBus.gold_changed.connect(func(g): gold_label.text = tr("Ouro %d") % g)
	EventBus.mana_changed.connect(_on_mana_changed)
	EventBus.discards_changed.connect(_on_discards_changed)
	EventBus.turn_started.connect(_on_turn_started)
	EventBus.card_drawn.connect(func(_c): _refresh_hand())
	EventBus.hand_changed.connect(_refresh_hand)
	EventBus.spell_cast.connect(_on_spell_cast)
	EventBus.creature_died.connect(_on_creature_died)
	EventBus.creature_blocked.connect(_on_creature_blocked)
	EventBus.creature_mirrored.connect(func(_c): _refresh_board())
	EventBus.card_stolen.connect(func(c: CardInstance):
		_log(tr("Roubada: %s (volta depois da batalha).") % c.data.display_name())
		_refresh_hand())
	EventBus.card_discarded.connect(_on_card_discarded)
	EventBus.card_grew.connect(_on_card_grew)
	EventBus.enemy_ability_used.connect(_on_enemy_ability)
	EventBus.damage_dealt.connect(_on_damage_dealt)
	EventBus.cascade_started.connect(_on_cascade_started)
	EventBus.battle_ended.connect(_on_battle_ended)
	EventBus.relics_changed.connect(_build_relics)
	EventBus.mulligan_taken.connect(_on_mulligan_taken)
	EventBus.card_transformed.connect(_on_card_transformed)
	EventBus.card_flashback.connect(_on_card_flashback)
	EventBus.seal_triggered.connect(_on_seal_triggered)
	EventBus.formation_leveled.connect(_on_formation_leveled)
	EventBus.planeswalker_changed.connect(_refresh_planeswalker)
	EventBus.card_exiled_run.connect(_on_card_exiled_run)
	EventBus.boss_ascended.connect(_on_boss_ascended)
	EventBus.boss_phase2.connect(_on_boss_phase2)
	EventBus.boss_phase.connect(_on_boss_phase)
	EventBus.relic_stolen.connect(_on_relic_stolen)
	EventBus.consumables_changed.connect(_refresh_items)
	EventBus.death_saved.connect(_on_death_saved)
	EventBus.contract_resolved.connect(_on_contract_resolved)
	EventBus.creature_exiled.connect(_on_creature_exiled)
	EventBus.climate_hit.connect(_on_climate_hit)
	EventBus.gold_changed.connect(func(_g): battle.on_gold_changed())
	EventBus.token_created.connect(_on_token_created)
	EventBus.enchantment_played.connect(_on_enchantment_played)
	EventBus.card_kicked.connect(_on_card_kicked)
	EventBus.reaction_window.connect(_on_reaction_window)
	EventBus.reaction_played.connect(_on_reaction_played)
	EventBus.shield_hit.connect(_on_shield_hit)
	EventBus.minions_changed.connect(func(_n): _refresh_defense())
	EventBus.keyword_granted.connect(_on_keyword_granted)
	EventBus.landfall.connect(_on_landfall)
	EventBus.creature_jailed.connect(func(_c): _refresh_board())
	EventBus.board_shuffled.connect(func():
		_refresh_board()
		_refresh_preview())
	EventBus.enemy_attacking.connect(_on_enemy_attacking)
	Settings.changed.connect(_refresh_texts)
	end_turn_btn.pressed.connect(_on_end_turn)
	mulligan_btn.pressed.connect(_on_mulligan)
	discard_btn.toggled.connect(_on_discard_toggled)
	pause_btn.pressed.connect(_open_pause)
	library_btn.pressed.connect(_open_library)
	graveyard_btn.pressed.connect(_open_graveyard)
	undo_btn.pressed.connect(_on_undo)
	_apply_handedness()
	_attack_style = end_turn_btn.get_theme_stylebox("normal")
	_lethal_style = _attack_style.duplicate()
	_lethal_style.bg_color = Color(0.2, 0.68, 0.32)
	_make_particles()
	_make_fire()
	_make_status_icons()
	_make_intent_row()
	_make_calc_tap()
	_make_010_widgets()
	_make_0120_widgets()
	_make_0130_widgets()
	Settings.set_battle_screen_on(true)
	# Contorno escuro no texto por cima do cálculo: continua legível com as chamas atrás.
	for l in [log_label, formation_label]:
		l.add_theme_color_override("font_outline_color", Color(0.06, 0.04, 0.09))
		l.add_theme_constant_override("outline_size", 6)

	_build_relics()
	gold_label.text = tr("Ouro %d") % GameState.gold
	# Quebra-cabeças: mão fixa, 1 turno; sem gravação nem mapa.
	if GameState.puzzle_id != "":
		var training := GameState.puzzle_id == "training"
		var lesson := GameState.is_lesson_battle()
		var pdef := GameState.training_def() if training else (CardDB.get_lesson(GameState.puzzle_id) if lesson else CardDB.get_puzzle(GameState.puzzle_id))
		_resumed = true
		battle.start_puzzle(pdef)
		_resumed = false
		_refresh_enemy_header()
		_build_info_row()
		_setup_backdrop()
		_refresh_all()
		if training:
			_log(tr("Treino: joga a mão e ataca. O boneco aguenta tudo."))
			_show_banner(tr("TREINO"), 1.0)
		elif lesson:
			_lesson_def = pdef
			EventBus.reaction_played.connect(_on_lesson_reaction)
			_log(tr("Objetivo: %s") % tr(String(pdef.get("goal", ""))))
			_show_banner(tr("LIÇÃO") + "\n" + tr(String(pdef.get("name", ""))), 1.2)
			_show_lesson_panel(pdef)
		else:
			_log(tr("Um só turno: encontra o ataque certo."))
			_show_banner(tr("ENIGMA") + "\n" + tr(String(pdef.get("name", ""))), 1.4)
		return
	# Retoma uma batalha gravada a meio, se houver; senão começa uma nova neste ante.
	var resumed := false
	if not GameState.pending_battle.is_empty():
		var state := GameState.pending_battle
		GameState.pending_battle = {}
		_resumed = true   # sem banner "TURNO N" durante o restore
		resumed = battle.restore(state)
		_resumed = false
	if not resumed:
		if GameState.arena_battle:
			battle.start(GameState.pick_arena_enemy())   # 0.12.0: paragem Arena (batalha extra)
		else:
			if not GameState.map_choice.has("battle"):
				GameState.choose_battle("boss" if GameState.is_boss_ante(GameState.ante) else "scout")
			battle.start(GameState.pick_enemy(GameState.ante))
	_refresh_enemy_header()
	_build_info_row()
	_setup_backdrop()
	_refresh_all()
	if not resumed and not Stats.tutorial_done() and GameState.ante == 1 and battle.turn == 1:
		TutorialOverlay.open(self)
	if resumed:
		_log(tr("Run retomada no turno %d.") % battle.turn)
		_show_banner(tr("ANTE %d") % GameState.ante + "\n" + tr("TURNO %d") % battle.turn)
	else:
		_log(_play_help(battle.can_mulligan()))
		if battle.enemy.get("boss", false):
			# 0.12.0: entrada de cinema (retrato a cair, rugido); sem animações fica o letreiro.
			var intro := _boss_intro()
			if intro == null:
				_show_banner(tr("BOSS") + "\n" + tr(battle.enemy.name), 1.4)
				_say_after(_boss_line("intro"), _d(1.7) + 0.2, 3.4)
			else:
				var line := _boss_line("intro")   # a fala vem quando a entrada acaba (ou é saltada)
				intro.finished.connect(func(): _say_after(line, 0.15, 3.4), CONNECT_ONE_SHOT)
		elif String(battle.enemy.get("variant", "")) == "arena":
			_show_banner(tr("ARENA") + "\n" + tr(battle.enemy.name) + "  ·  " + tr("%d turnos") % battle.max_turns, 1.4)
		elif String(battle.enemy.get("variant", "")) == "nemesis":
			var n_intro := _boss_intro(tr("Nível %d") % int(battle.enemy.get("nemesis_level", 1)))
			if n_intro == null:
				_show_banner(tr("NÉMESIS") + "\n" + tr(battle.enemy.name) + "  ·  " + tr("Nível %d") % int(battle.enemy.get("nemesis_level", 1)), 1.4)
				_say_after(_boss_line("intro"), _d(1.7) + 0.2, 3.4)
			else:
				var n_line := _boss_line("intro")
				n_intro.finished.connect(func(): _say_after(n_line, 0.15, 3.4), CONNECT_ONE_SHOT)
		else:
			var vname := tr(VARIANT_NAMES.get(String(battle.enemy.get("variant", "scout")), "Batedor"))
			if battle.enemy.get("affixes") is Array and not (battle.enemy["affixes"] as Array).is_empty():
				vname += " " + GameState.affix_names(battle.enemy["affixes"])   # 0.13.0: "Elite Vampírico, Veloz"
			_show_banner(tr("ATO %s · ANTE %d") % [GameState.act_name(), GameState.ante] + "\n" + tr(battle.enemy.name) + "  ·  " + vname)

## Entrada do boss/Némesis (0.12.0): ato, ante e a regra do boss por baixo do nome.
func _boss_intro(extra: String = "") -> BossIntro:
	var lines: PackedStringArray = [tr("ATO %s · ANTE %d") % [GameState.act_name(), GameState.ante] + (("  ·  " + extra) if extra != "" else "")]
	if String(battle.enemy.text) != "":
		lines.append(tr(String(battle.enemy.text)))
	var tint: Color = _portrait.tint if _portrait != null else Color(0.55, 0.42, 0.85)
	return BossIntro.play(self, battle.enemy, _portrait_archetype(), tint, "\n".join(lines))

## Modo canhoto: a coluna dos botões passa para a direita.
func _apply_handedness() -> void:
	var middle: HBoxContainer = layout.get_node("Middle")
	var left_col: Control = middle.get_node("LeftCol")
	middle.move_child(left_col, middle.get_child_count() - 1 if Settings.left_handed else 0)
	_apply_one_hand()

# --- 0.13.0: modo de uma mão ---
# ATACAR, CANALIZAR e DESFAZER descem para o lado da mão (o do polegar: direita, ou esquerda no modo
# canhoto), para jogar com o telemóvel numa só mão. Desligar devolve-os ao sítio de sempre.
var _hand_row: HBoxContainer = null
var _thumb_col: VBoxContainer = null
var _thumb_home: Array = []   # [[botão, pai, índice, altura mínima]]

func one_hand_active() -> bool:
	return _thumb_col != null

func _apply_one_hand() -> void:
	if Settings.one_hand and _thumb_col == null:
		_hand_row = HBoxContainer.new()
		_hand_row.name = "HandRow"
		_hand_row.add_theme_constant_override("separation", 12)
		var idx := hand_box.get_index()
		layout.add_child(_hand_row)
		layout.move_child(_hand_row, idx)
		layout.remove_child(hand_box)
		_hand_row.add_child(hand_box)
		hand_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_thumb_col = VBoxContainer.new()
		_thumb_col.name = "ThumbCol"
		_thumb_col.custom_minimum_size.x = 196
		_thumb_col.alignment = BoxContainer.ALIGNMENT_CENTER
		_thumb_col.add_theme_constant_override("separation", 6)
		_hand_row.add_child(_thumb_col)
		_thumb_home.clear()
		for b in [end_turn_btn, discard_btn, undo_btn]:   # guarda os lugares antes de tirar algum
			_thumb_home.append([b, (b as Node).get_parent(), (b as Node).get_index(), (b as Control).custom_minimum_size.y])
		for h in _thumb_home:
			var btn: Button = h[0]
			(h[1] as Node).remove_child(btn)
			_thumb_col.add_child(btn)
			btn.custom_minimum_size.y = maxf(btn.custom_minimum_size.y, 48.0)
	elif not Settings.one_hand and _thumb_col != null:
		for h in _thumb_home:
			var btn: Button = h[0]
			_thumb_col.remove_child(btn)
			(h[1] as Node).add_child(btn)
			(h[1] as Node).move_child(btn, mini(int(h[2]), (h[1] as Node).get_child_count() - 1))
			btn.custom_minimum_size.y = float(h[3])
		_thumb_home.clear()
		var idx := _hand_row.get_index()
		_hand_row.remove_child(hand_box)
		layout.add_child(hand_box)
		layout.move_child(hand_box, idx)
		hand_box.size_flags_horizontal = Control.SIZE_FILL
		_hand_row.queue_free()
		_hand_row = null
		_thumb_col = null
	if _hand_row != null:
		# O polegar: à direita da mão, ou à esquerda no modo canhoto.
		_hand_row.move_child(_thumb_col, 0 if Settings.left_handed else _hand_row.get_child_count() - 1)

## Nome, emblema (inicial numa cor derivada do id) e texto do inimigo; moldura dourada nos bosses.
func _refresh_enemy_header() -> void:
	enemy_name.text = battle.enemy.name
	enemy_text.text = battle.enemy.text
	if battle.ascended and String(battle.enemy.get("rule2_text", "")) != "":
		enemy_text.text = String(battle.enemy.get("rule2_text", ""))
	# 0.13.0: afixos da Elite e a fase da Hidra por baixo do texto.
	var extra: Array[String] = []
	if battle.enemy.get("affixes") is Array:
		for af_id in battle.enemy["affixes"]:
			var af := CardDB.get_affix(String(af_id))
			if not af.is_empty():
				extra.append("◆ %s: %s" % [tr(String(af.get("name", ""))), tr(String(af.get("text", "")))])
	if String(battle.enemy.get("phase_text", "")) != "":
		extra.append(tr(String(battle.enemy["phase_text"])))
	if not extra.is_empty():
		enemy_text.text = tr(enemy_text.text) + ("\n" if enemy_text.text != "" else "") + "\n".join(PackedStringArray(extra))
	var id := String(battle.enemy.get("id", battle.enemy.name))
	var name_txt := tr(String(battle.enemy.name))
	emblem_label.text = name_txt.substr(0, 1).to_upper() if name_txt != "" else "?"
	var style: StyleBoxFlat = emblem.get_theme_stylebox("panel").duplicate()
	style.bg_color = Color.from_hsv(fmod(float(abs(id.hash())) / 1000.0, 1.0), 0.55, 0.75)
	emblem.add_theme_stylebox_override("panel", style)
	if _portrait != null:
		_portrait.archetype = _portrait_archetype()
		_portrait.tint = style.bg_color
		_portrait.boss = bool(battle.enemy.get("boss", false)) or String(battle.enemy.get("variant", "")) == "nemesis"
		_portrait.art_id = String(battle.enemy.get("art", "")) if String(battle.enemy.get("art", "")) != "" else String(battle.enemy.get("id", ""))
	_refresh_defense()
	enemy_name.add_theme_color_override("font_color", Color(1.0, 0.5, 0.45) if battle.phase2 else Color.WHITE)
	if battle.enemy.get("boss", false):
		_ensure_hp_marker()
		var panel_style: StyleBoxFlat = enemy_panel.get_theme_stylebox("panel").duplicate()
		panel_style.border_color = UiKit.GOLD
		panel_style.border_width_left = 3
		panel_style.border_width_right = 3
		panel_style.border_width_top = 3
		panel_style.border_width_bottom = 3
		if battle.phase2:
			panel_style.border_color = Color(0.95, 0.35, 0.3)
		enemy_panel.add_theme_stylebox_override("panel", panel_style)

## Bosses: risca dourada a meio da barra de vida (abaixo dela o boss desperta). 0.13.0: os bosses com
## fases têm uma risca por fase (apagada depois de passar).
func _ensure_hp_marker() -> void:
	var phases: Array = battle.enemy.get("phases", []) if battle.enemy.get("phases") is Array else []
	if not phases.is_empty():
		var holder: Control = enemy_hp_bar.get_parent()
		for i in phases.size():
			var nm := "PhaseMark%d" % i
			var m: ColorRect = holder.get_node_or_null(nm)
			if m == null:
				m = ColorRect.new()
				m.name = nm
				m.mouse_filter = Control.MOUSE_FILTER_IGNORE
				var f := clampf(float((phases[i] as Dictionary).get("pct", 50)) / 100.0, 0.0, 1.0)
				m.anchor_left = f
				m.anchor_right = f
				m.anchor_bottom = 1.0
				m.offset_left = -2.0
				m.offset_right = 2.0
				m.offset_top = -4.0
				m.offset_bottom = 4.0
				holder.add_child(m)
			m.color = Color(1, 1, 1, 0.3) if battle.phase_index > i else UiKit.GOLD
		return
	if _hp_marker == null:
		_hp_marker = ColorRect.new()
		_hp_marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_hp_marker.anchor_left = 0.5
		_hp_marker.anchor_right = 0.5
		_hp_marker.anchor_bottom = 1.0
		_hp_marker.offset_left = -2.0
		_hp_marker.offset_right = 2.0
		_hp_marker.offset_top = -4.0
		_hp_marker.offset_bottom = 4.0
		enemy_hp_bar.get_parent().add_child(_hp_marker)
	_hp_marker.color = Color(1, 1, 1, 0.3) if battle.phase2 else UiKit.GOLD

func _make_particles() -> void:
	_particles = CPUParticles2D.new()
	_particles.emitting = false
	_particles.one_shot = true
	_particles.explosiveness = 0.95
	_particles.amount = 48
	_particles.lifetime = 0.8
	_particles.spread = 180.0
	_particles.direction = Vector2(0, -1)
	_particles.gravity = Vector2(0, 700)
	_particles.initial_velocity_min = 220.0
	_particles.initial_velocity_max = 520.0
	_particles.scale_amount_min = 3.0
	_particles.scale_amount_max = 7.0
	_particles.color = Color(1.0, 0.85, 0.35)
	add_child(_particles)

## Chamas atrás das pílulas de Poder e Mult (o fundo das pílulas tapa a base; vêem-se a subir).
## Crescem com o ataque em relação à vida que falta ao inimigo: letal = fogo no máximo.
## 0.12.1: shader novo com ruído de textura (liso também nos telemóveis), núcleo quente, faúlhas, e o
## retângulo segue a pílula mesmo quando ela salta (escala).
static var _fire_noise: NoiseTexture2D

static func fire_noise() -> NoiseTexture2D:
	if _fire_noise == null:
		var fn := FastNoiseLite.new()
		fn.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
		fn.frequency = 0.012
		fn.fractal_octaves = 3
		fn.seed = 7
		_fire_noise = NoiseTexture2D.new()
		_fire_noise.width = 256
		_fire_noise.height = 256
		_fire_noise.seamless = true
		_fire_noise.normalize = true
		_fire_noise.noise = fn
	return _fire_noise

func _make_fire() -> void:
	_fire_layer = Control.new()
	_fire_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fire_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(_fire_layer)
	move_child(_fire_layer, layout.get_index())
	var looks := [[Vector3(0.22, 0.55, 1.0), Vector3(0.78, 0.95, 1.0), 0.0], [Vector3(1.0, 0.38, 0.1), Vector3(1.0, 0.92, 0.6), 0.47]]
	for look in looks:
		var r := ColorRect.new()
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		r.visible = false
		var m := ShaderMaterial.new()
		m.shader = FIRE_SHADER
		m.set_shader_parameter("tint", look[0])
		m.set_shader_parameter("core", look[1])
		m.set_shader_parameter("seed", look[2])
		m.set_shader_parameter("noise_tex", fire_noise())
		m.set_shader_parameter("intensity", 0.0)
		r.material = m
		_fire_layer.add_child(r)
		_fire_rects.append(r)

## 0..1: um ataque de 25 % da vida restante começa a arder; letal arde no máximo.
func _fire_for(total: float) -> float:
	var hp := float(maxi(1, int(battle.enemy.get("hp", 1))))
	return clampf((total / hp - 0.25) / 0.75, 0.0, 1.0)

func _process(delta: float) -> void:
	_fire_level = move_toward(_fire_level, _fire_target, delta * 1.6)
	var on := _fire_level > 0.01
	for i in _fire_rects.size():
		var r := _fire_rects[i]
		r.visible = on
		if not on:
			continue
		var pill: Control = power_pill if i == 0 else mult_pill
		# Retângulo visto da pílula (com a escala dos saltos): as chamas nascem atrás do topo dela.
		var xf := pill.get_global_transform()
		var p0 := xf * Vector2.ZERO
		var p1 := xf * pill.size
		var pw := p1.x - p0.x
		var ph := p1.y - p0.y
		var h := ph * 2.1
		r.global_position = Vector2(p0.x - pw * 0.04, p0.y + ph * 0.5 - h)
		r.size = Vector2(pw * 1.08, h)
		(r.material as ShaderMaterial).set_shader_parameter("intensity", _fire_level)

## Vida com um coração e mana em cristais (menos texto na coluna da esquerda).
func _make_status_icons() -> void:
	var row: HBoxContainer = player_label.get_parent()
	var heart := CardIcon.new("heart", Color(0.95, 0.35, 0.4), 24.0)
	heart.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(heart)
	row.move_child(heart, player_label.get_index())
	player_label.add_theme_font_size_override("font_size", 22)
	_mana_pips = ManaPips.new()
	_mana_pips.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(_mana_pips)
	row.move_child(_mana_pips, mana_label.get_index())
	mana_label.add_theme_font_size_override("font_size", 16)
	_set_life(GameState.player_hp, GameState.player_max_hp)

func _set_life(current: int, max_hp: int) -> void:
	player_label.text = "%d/%d" % [current, max_hp]
	player_label.tooltip_text = tr("Vida %d/%d") % [current, max_hp]

func _set_mana(available: int, total: int) -> void:
	mana_label.text = "%d/%d" % [available, total]
	if _mana_pips != null:
		_mana_pips.set_mana(available, total)

## Duração de uma animação com a velocidade das Configurações.
func _d(seconds: float) -> float:
	return Settings.dur(seconds)

# --- Construção / refresh ---

func _build_relics() -> void:
	for child in relics_bar.get_children():
		relics_bar.remove_child(child)
		child.queue_free()
	_relic_views.clear()
	var n := GameState.relic_ids.size() + GameState.boss_relics.size() + GameState.blessings.size()
	var w := _relic_width(n)
	for id in GameState.relic_ids:
		var view: RelicView = RELIC_VIEW.instantiate()
		relics_bar.add_child(view)
		view.setup(id)
		view.set_width(w)
		view.pressed.connect(_on_relic_pressed)
		view.drag_started.connect(_on_relic_drag_started)
		view.drag_moved.connect(_on_relic_drag_moved)
		view.drag_ended.connect(_on_relic_drag_ended)
		_relic_views[id] = view
		if id in GameState.stolen_relics:   # 0.13.0 Ladra de Relíquias
			view.modulate = Color(0.45, 0.45, 0.5, 0.55)
	# Relíquias de boss e Bênçãos (0.12.0): depois das normais (disparam a seguir na cascata), sem arrastar.
	for id in GameState.boss_relics + GameState.blessings:
		var bview: RelicView = RELIC_VIEW.instantiate()
		relics_bar.add_child(bview)
		bview.setup(id)
		bview.set_width(w)
		bview.pressed.connect(_on_relic_pressed)
		_relic_views[id] = bview
	if not _animating and battle.effects != null:
		_refresh_preview()

## Largura de cada relíquia para caberem todas na barra de cima (sem empurrar o ecrã).
func _relic_width(_n: int) -> float:
	return RelicView.SIZE   # medalhões: tamanho fixo (o nome abre ao tocar)

func _refresh_all() -> void:
	# 0.13.0: o ATACAR só fica desligado enquanto o ataque corre ou durante o fundo do Mulligan.
	if not battle.resolving and not battle.finished and not _animating:
		end_turn_btn.disabled = battle.pending_bottom > 0
	_refresh_hand()
	_refresh_board()
	_refresh_spells()
	_refresh_enchantments()
	_refresh_defense()
	_refresh_items()
	_refresh_preview()
	_refresh_zone_buttons()
	for v in _relic_views.values():
		if _alive(v):
			(v as RelicView).refresh_value()
	_refresh_tool_buttons()
	_check_tips()

# --- Dicas (0.11.0): uma linha na primeira vez que aparece cada mecânica ---

var _tip_queue: Array[String] = []
var _tip_panel: Control
var _last_preview_chain := 0

## Procura coisas novas no ecrã (mão, Arena, inimigo) e pede a dica de cada uma (só a 1.ª vez).
func _check_tips() -> void:
	if not Settings.tips_enabled or battle.puzzle or battle.finished or _animating or not Stats.tutorial_done():
		return
	for c in battle.deck.hand:
		var d := c.data
		if d.is_land():
			_tip("land")
		if d.has_kicker():
			_tip("kicker")
		if BattleManager.has_reaction(c):
			_tip("reaction")
		if d.is_enchantment():
			_tip("enchantment")
		if d.is_mythic():
			_tip("mythic")
		if d.is_curse():
			_tip("curse")
		if c.has_mission():
			_tip("mission")
		if d.tribe != "" and not d.token:
			_tip("tribe")
		if not d.keywords.is_empty():
			_tip("keyword")
		if c.seal() != "":
			_tip("seal")
		for e in d.effects:
			if String(e.get("action", "")) == "create_token":
				_tip("token")
			if String(e.get("trigger", "")) == "landfall":
				_tip("landfall")
		_keyword_tips(c)
	for c in battle.board:
		if c.data.token:
			_tip("token")
		if not c.keywords().is_empty():
			_tip("keyword")
		_keyword_tips(c)
	if not battle.deck.flashback_cards().is_empty():
		_tip("flashback")
	if not battle.minions.is_empty():
		_tip("minion")
	if float(battle.enemy.get("shield_pct", 0.0)) > 0.0:
		_tip("shield")
	if bool(battle.enemy.get("boss", false)):
		_tip("boss")
		match String(battle.enemy.get("id", "")):
			"boss_mirror":
				_tip("mirror")
			"boss_thief":
				_tip("thief")
			"boss_fog":
				_tip("fog")
	if String(battle.enemy.get("variant", "")) == "nemesis":
		_tip("nemesis")
	if battle.climate != "":
		_tip("climate")
	if not GameState.planeswalker.is_empty():
		_tip("planeswalker")
	if _last_preview_chain >= 2:
		_tip("chain")

## 0.12.0: dica própria para Voar, Atropelar e Primeiro Golpe.
func _keyword_tips(c: CardInstance) -> void:
	for k in ["flying", "trample", "first_strike"]:
		if c.has_keyword(k):
			_tip(k)

func _tip(id: String) -> void:
	if not Settings.tips_enabled or battle.puzzle or not Stats.tutorial_done():
		return
	if id in _tip_queue or GameState.tip_seen(id) or not CardDB.tips.has(id):
		return
	GameState.mark_tip_seen(id)
	_tip_queue.append(id)
	if not _alive(_tip_panel):
		_show_next_tip()

func _show_next_tip() -> void:
	if _tip_queue.is_empty() or not is_inside_tree():
		return
	var id: String = _tip_queue.pop_front()
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.12, 0.1, 0.2, 0.97), 12, UiKit.GOLD, 2, 8))
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	panel.z_index = 50
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(row)
	var tag := UiKit.label(tr("DICA"), 15, UiKit.GOLD)
	tag.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(tag)
	var text := UiKit.label(tr(String(CardDB.tips.get(id, ""))), 15, Color.WHITE, true)
	text.custom_minimum_size.x = clampf(_top_room() - 100.0, 360.0, 640.0)   # 0.13.0: no topo, em 2 linhas
	row.add_child(text)
	var x := UiKit.label("✕", 18, UiKit.TEXT_DIM)
	x.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(x)
	panel.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.pressed:
			_close_tip(panel))
	add_child(panel)
	_tip_panel = panel
	panel.modulate.a = 0.0
	await get_tree().process_frame
	if not is_instance_valid(panel) or not is_inside_tree():
		return
	# 0.13.0: no topo do ecrã, por cima das relíquias (entre o ORDENAR e o ouro): nunca tapa o cálculo,
	# os feitiços, o clima, o planeswalker nem a Arena.
	panel.reset_size()
	panel.global_position = _top_slot(panel.size, false)
	create_tween().tween_property(panel, "modulate:a", 1.0, _d(0.2))
	await get_tree().create_timer(7.0).timeout
	if is_inside_tree():
		_close_tip(panel)

func _close_tip(panel: Control) -> void:
	if not is_instance_valid(panel) or panel.is_queued_for_deletion():
		return
	panel.queue_free()
	if _tip_panel == panel:
		_tip_panel = null
	if not is_inside_tree():
		return
	await get_tree().create_timer(0.4).timeout
	_show_next_tip()

## Texto que depende do idioma (chamado quando as Configurações mudam).
func _turn_text() -> String:
	var line1 := tr("Turno %d/%d  ·  Ante %d") % [battle.turn, battle.max_turns + battle.extra_turns, GameState.ante]
	if battle.puzzle:
		return line1.split("  ·  ")[0] + "\n" + tr("Quebra-cabeças")
	var line2 := tr("Ato %s") % GameState.act_name() + "  ·  " + tr(VARIANT_NAMES.get(String(battle.enemy.get("variant", "scout")), "Batedor"))
	if GameState.stake > 1:
		line2 += "  ·  " + tr("Selo %d") % GameState.stake
	return line1 + "\n" + line2

func _refresh_texts() -> void:
	if battle.enemy.is_empty():
		return
	_apply_handedness()
	turn_label.text = _turn_text()
	_refresh_pips()
	gold_label.text = tr("Ouro %d") % GameState.gold
	_set_life(GameState.player_hp, GameState.player_max_hp)
	_set_mana(battle.mana_available, battle.mana_total)
	_refresh_enemy_header()
	_refresh_discard_button()
	_refresh_zone_buttons()
	_refresh_planeswalker()
	if not _animating:
		_refresh_preview()
		for v in _hand_views.values():
			if _alive(v):
				v.size_scale = Settings.hand_scale
				v.refresh()
		for v in _board_views.values():
			if _alive(v):
				v.refresh()

func _refresh_zone_buttons() -> void:
	library_btn.text = tr("GRIMÓRIO %d") % battle.deck.library.size()
	var fb := 0
	for c in battle.flashback_cards():
		if battle.can_flashback(c):
			fb += 1
	graveyard_btn.text = tr("CEMITÉRIO %d") % battle.deck.graveyard.size() + (" ↺" if fb > 0 else "")
	undo_btn.disabled = _undo_stack.is_empty() or battle.resolving or battle.finished
	mulligan_btn.visible = battle.can_mulligan()
	mulligan_btn.text = tr("MULLIGAN") if battle.mulligans == 0 else tr("MULLIGAN (−%d)") % (battle.mulligans + 1)
	_refresh_planeswalker()

## Ordem da mão no ecrã: as outras cartas primeiro e os Terrenos juntos na ponta direita.
## 0.12.0: ORDENAR (Settings.hand_sort) — como vieram, por custo ou por tipo (e custo dentro do tipo).
func _hand_order() -> Array[CardInstance]:
	var out: Array[CardInstance] = []
	for c in battle.deck.hand:
		if not c.data.is_land():
			out.append(c)
	if Settings.hand_sort != "":
		var pos := {}
		for i in battle.deck.hand.size():
			pos[battle.deck.hand[i].uid] = i
		var by_type := Settings.hand_sort == "type"
		out.sort_custom(func(a: CardInstance, b: CardInstance):
			if by_type and _type_rank(a) != _type_rank(b):
				return _type_rank(a) < _type_rank(b)
			if a.data.cost != b.data.cost:
				return a.data.cost < b.data.cost
			return int(pos[a.uid]) < int(pos[b.uid]))
	for c in battle.deck.hand:
		if c.data.is_land():
			out.append(c)
	return out

static func _type_rank(c: CardInstance) -> int:
	if c.data.is_creature():
		return 0
	if c.data.is_spell():
		return 1
	if c.data.is_enchantment():
		return 2
	return 3

func _refresh_hand() -> void:
	CardView.fog_hand = bool(battle.rule.get("hide_text", false))
	var ordered := _hand_order()
	# Se a mão é a mesma (mesmas cartas, mesma ordem), só atualiza as vistas — não interrompe animações.
	var live := hand_box.get_children().filter(func(c): return not c.is_queued_for_deletion())
	var same := _hand_views.size() == ordered.size() and live.size() == ordered.size()
	if same:
		var i := 0
		for card in ordered:
			if not _hand_views.has(card.uid) or live[i] != _hand_views[card.uid]:
				same = false
				break
			i += 1
	if same:
		for card in battle.deck.hand.duplicate():
			var v: CardView = _hand_views[card.uid]
			if _alive(v):
				v.size_scale = Settings.hand_scale   # 0.13.0: tamanho das cartas da mão
				v.refresh()
				v.playable = battle.can_play(card) or card.data.is_land() or _discard_mode or battle.pending_bottom > 0
				v.modulate = BOTTOM_TINT if battle.pending_bottom > 0 else (DISCARD_TINT if _discard_mode else Color.WHITE)
				v.delta = 0 if (_discard_mode or _animating or battle.pending_bottom > 0) else battle.preview_play(card)
		_apply_selection()
		_refresh_preview()
		_refresh_zone_buttons()
		return
	var previous := _hand_views.keys()
	for child in hand_box.get_children():
		hand_box.remove_child(child)   # sai já da árvore: nunca se desenha em duplicado com as novas
		child.queue_free()
	_hand_views.clear()
	var stagger := 0.0
	var first_land := true
	for card in ordered:
		var view: CardView = CARD_VIEW.instantiate()
		view.size_scale = Settings.hand_scale   # 0.13.0: tamanho das cartas da mão (Configurações → Visual)
		if card.data.is_land() and first_land:
			first_land = false
			view.set_meta("fan_gap_before", true)   # espaço antes do grupo dos Terrenos
		hand_box.add_child(view)
		view.setup(card)
		view.playable = battle.can_play(card) or card.data.is_land() or _discard_mode or battle.pending_bottom > 0
		if battle.pending_bottom > 0:
			view.modulate = BOTTOM_TINT
		elif _discard_mode:
			view.modulate = DISCARD_TINT
		view.pressed.connect(_on_hand_card_tapped)
		view.long_pressed.connect(_on_card_long_pressed)
		view.draggable = true   # 0.12.1: segurar e arrastar muda a carta de lugar (ou joga-a lá em cima)
		view.drag_started.connect(_on_hand_drag_started)
		view.drag_moved.connect(_on_hand_drag_moved)
		view.drag_ended.connect(_on_hand_drag_ended)
		view.delta = 0 if (_discard_mode or _animating or battle.pending_bottom > 0) else battle.preview_play(card)
		_hand_views[card.uid] = view
		if not (card.uid in previous):
			_animate_draw(view, stagger)
			stagger += 0.05
	_apply_selection()
	_refresh_preview()
	_refresh_zone_buttons()

func _refresh_board() -> void:
	if _animating:
		return
	var creatures := battle.creatures()
	var live := board_box.get_children().filter(func(c): return not c.is_queued_for_deletion())
	var same := _board_views.size() == creatures.size() and live.size() == creatures.size()
	if same:
		var i := 0
		for card in creatures:
			if not _board_views.has(card.uid) or live[i] != _board_views[card.uid]:
				same = false
				break
			i += 1
	if same:
		for card in creatures:
			if _alive(_board_views[card.uid]):
				(_board_views[card.uid] as CardView).refresh()
				(_board_views[card.uid] as CardView).set_mirrored(card.uid == battle.mirror_uid)
				(_board_views[card.uid] as CardView).set_jailed(card.uid == battle.jailed_uid)
		_refresh_overlay()
		return
	for child in board_box.get_children():
		board_box.remove_child(child)
		child.queue_free()
	_board_views.clear()
	for card in creatures:
		var view: CardView = CARD_VIEW.instantiate()
		board_box.add_child(view)
		view.setup(card)
		view.set_mirrored(card.uid == battle.mirror_uid)
		view.set_jailed(card.uid == battle.jailed_uid)
		view.long_pressed.connect(_on_card_long_pressed)
		view.pressed.connect(_on_card_long_pressed)   # no tabuleiro um toque simples também abre em grande
		view.keyword_taps = true   # 0.13.0: tocar no ícone de uma palavra-chave explica-a
		view.keyword_tapped.connect(_on_keyword_tapped)
		view.draggable = true
		view.drag_started.connect(_on_board_drag_started)
		view.drag_moved.connect(_on_board_drag_moved)
		view.drag_ended.connect(_on_board_drag_ended)
		_board_views[card.uid] = view
	_refresh_overlay()

func _refresh_spells() -> void:
	if _animating:
		return
	for chip in _spell_chips.values():
		if is_instance_valid(chip):
			spell_strip.remove_child(chip)
			chip.queue_free()
	_spell_chips.clear()
	spell_hint.visible = battle.spells_this_turn.is_empty() and battle.enchantments.is_empty()
	var at := spell_hint.get_index() + 1
	for sp in battle.spells_this_turn:
		var chip := _make_chip(sp)
		spell_strip.add_child(chip)
		spell_strip.move_child(chip, at)
		at += 1
		_spell_chips[sp.uid] = chip
	_fit_chips()

const CHIP_MIN_W := 44.0
const CHIP_MAX_W := 180.0

func _make_chip(sp: CardInstance, text_override: String = "") -> Control:
	var chip := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = CardView.COLORS.get(sp.data.primary_color(), CardView.COLORS.colorless)
	style.set_corner_radius_all(8)
	style.set_content_margin_all(6)
	chip.add_theme_stylebox_override("panel", style)
	chip.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	var label := Label.new()
	if text_override != "":
		label.text = text_override
	else:
		label.text = ("↺ " if sp.zone == CardInstance.Zone.EXILE else "") + ("%s  %d⚔" % [sp.data.display_name(), sp.data.power] if sp.data.power > 0 else sp.data.display_name())
	label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	label.add_theme_font_size_override("font_size", 15)
	label.add_theme_color_override("font_color", Color(0.08, 0.08, 0.1) if style.bg_color.get_luminance() > 0.45 else Color.WHITE)
	# Largura natural do texto (as fichas encolhem só quando não cabem todas — ver _fit_chips).
	var font := label.get_theme_font("font")
	var natural := font.get_string_size(label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, 15).x if font != null else label.text.length() * 8.0
	label.set_meta("natural_w", ceilf(natural) + 2.0)
	label.custom_minimum_size.x = clampf(ceilf(natural) + 2.0, CHIP_MIN_W, CHIP_MAX_W)
	chip.tooltip_text = sp.data.display_name()
	chip.add_child(label)
	return chip

## Reparte a largura da faixa pelas fichas de feitiços e encantamentos: cada uma mostra o nome
## inteiro (até CHIP_MAX_W) e só encolhe, com reticências, quando não cabem todas.
func _fit_chips() -> void:
	var labels: Array[Label] = []
	for dict in [_spell_chips, _ench_chips]:
		for chip in dict.values():
			if is_instance_valid(chip) and chip.get_child_count() > 0:
				labels.append(chip.get_child(0) as Label)
	if labels.is_empty():
		return
	var room := spell_strip.size.x if spell_strip.size.x > 200.0 else 560.0
	if _chain_meter != null and _chain_meter.visible:
		room -= _chain_meter.get_combined_minimum_size().x + 16.0
	var per := room / float(labels.size()) - 8.0 - 12.0
	for label in labels:
		var natural: float = float(label.get_meta("natural_w", CHIP_MAX_W))
		label.custom_minimum_size.x = clampf(minf(natural, per), CHIP_MIN_W, CHIP_MAX_W)

## Mostra o que o ataque faria se atacasses agora.
func _refresh_preview() -> void:
	if _animating:
		return
	_what_if = false
	var lethal := _show_calc(battle.preview_attack(), false)
	_refresh_counter(lethal)
	_refresh_overlay()
	_check_no_plays()

## Põe um ataque (previsto) no cálculo: formações, Poder × Mult, total, chamas, barra do inimigo e o
## botão ATACAR. what_if = true (0.13.0): é o ataque com a carta que estás a arrastar para a Arena
## (total a verde); ao largar ou sair da zona volta o de agora. Devolve se é letal.
func _show_calc(c: Cascade, what_if: bool) -> bool:
	if c.is_empty():
		formation_label.text = tr("Sem atacantes")
	elif c.formations.is_empty():
		formation_label.text = tr("Ataque")
	else:
		var names: Array[String] = []
		for i in c.formations.size():
			var lvl: int = c.formation_levels[i] if i < c.formation_levels.size() else 0
			names.append(tr(c.formations[i]) + ((" (%s %d)" % [tr("nv"), lvl]) if lvl > 0 else ""))
		formation_label.text = " · ".join(PackedStringArray(names))
	var extra_names: Array[String] = []
	for st in c.steps:
		if (st.source_kind == "tribe" or st.source_kind == "seal_set") and not (st.source_name in extra_names):
			extra_names.append(st.source_name)
	if not extra_names.is_empty() and not c.is_empty():
		formation_label.text += "  ·  " + " · ".join(PackedStringArray(extra_names))
	if what_if:
		formation_label.text = "▲ " + tr("Com esta carta") + ("  ·  " + formation_label.text if not c.formations.is_empty() else "")
	power_label.text = Cascade.fmt_int(c.power)
	mult_label.text = Cascade.fmt_mult(c.mult)
	var net := c.net_total()
	_set_total(Cascade.fmt_int(net))
	total_label.add_theme_color_override("font_color", Color(0.55, 1.0, 0.62) if what_if else Color(1.0, 0.92, 0.6))
	_last_preview_total = net
	_fire_target = _fire_for(net)
	_refresh_chain_meter()
	var lethal := net > 0 and net >= int(battle.enemy.hp)
	var shield_txt := ("  ·  " + tr("Escudo −%s") % Cascade.fmt_int(c.shield)) if c.shield > 0 and c.total() > 0 else ""
	if lethal:
		end_turn_btn.text = tr("ATACAR") + "   " + Cascade.fmt_int(net) + "  ·  " + tr("LETAL")
		end_turn_btn.add_theme_stylebox_override("normal", _lethal_style)
	else:
		end_turn_btn.text = (tr("ATACAR") + "   " + Cascade.fmt_int(net) + shield_txt) if c.total() > 0 else tr("ATACAR")
		end_turn_btn.add_theme_stylebox_override("normal", _attack_style)
	_refresh_hp_bars()
	return lethal

## Total do ataque: a letra encolhe com números muito grandes (para nunca empurrar o ecrã).
func _set_total(text: String) -> void:
	total_label.text = text
	var n := text.length()
	total_label.add_theme_font_size_override("font_size", 46 if n <= 9 else (38 if n <= 12 else 30))

## Barra do inimigo: a parte clara (fantasma) é o dano do ataque atual.
func _refresh_hp_bars() -> void:
	var hp := int(battle.enemy.hp)
	enemy_hp_ghost.max_value = battle.enemy.max_hp
	enemy_hp_bar.max_value = battle.enemy.max_hp
	enemy_hp_ghost.value = hp
	if _animating:
		return
	enemy_hp_bar.value = max(0, hp - _last_preview_total)

## Contra-ataque previsto e intenção do inimigo para este turno.
func _refresh_counter(lethal: bool) -> void:
	if lethal:
		counter_label.text = tr("O ataque é letal: não há contra-ataque.")
		counter_label.add_theme_color_override("font_color", Color(0.45, 0.9, 0.55))
		_refresh_intent(true, {})
		return
	counter_label.add_theme_color_override("font_color", Color(1, 0.6, 0.55))
	var p := battle.counter_plan()
	_refresh_intent(false, p)
	_refresh_charge_look()
	var parts: Array[String] = []
	var dmg := int(p["damage"])
	var b: CardInstance = p["blocker"]
	var chosen := int(p.get("chosen", BattleManager.BLOCK_AUTO))
	if battle.charge_mult > 1.0 and dmg > 0:
		parts.append(tr("Golpe carregado (×%s)!") % _fmt_mult(battle.charge_mult))
	if dmg <= 0 and battle.ward and int(battle.enemy.get("attack", 0)) > 0:
		parts.append(tr("Pergaminho de Proteção: o contra-ataque deste turno não te toca."))
	elif dmg <= 0:
		parts.append(tr("Não ataca."))
	elif b != null and bool(p.get("vigilant", false)):
		parts.append(tr("Ataca %d: %s bloqueia sem sofrer dano (Vigilância).") % [dmg, b.data.display_name()])
	elif b != null and bool(p["survives"]):
		parts.append(tr("Ataca %d: %s bloqueia e sobrevive.") % [dmg, b.data.display_name()])
	elif b != null:
		parts.append(tr("Ataca %d: %s bloqueia e morre.") % [dmg, b.data.display_name()])
		if int(p["player_damage"]) > 0:
			parts.append(tr("O resto passa: levas %d.") % int(p["player_damage"]))
	elif (p["deaths"] as Array).is_empty():
		if chosen == BattleManager.BLOCK_NONE:
			parts.append(tr("Ataca %d: escolheste não bloquear, levas %d.") % [dmg, int(p["player_damage"])])
		else:
			parts.append(tr("Ataca %d: ninguém bloqueia, levas tu %d.") % [dmg, int(p["player_damage"])])
	else:
		parts.append(tr("Ataca %d (letal): %d criatura(s) sacrificam-se, levas %d.") % [dmg, (p["deaths"] as Array).size(), int(p["player_damage"])])
	if dmg > 0 and not battle.board.is_empty():
		parts.append(tr("(Toca para escolher quem bloqueia.)") if chosen == BattleManager.BLOCK_AUTO else tr("(Escolheste quem bloqueia; toca para mudar.)"))
	var intents: Array[String] = []
	for a in battle.enemy_intent(battle.turn):
		var action := String(a.get("action", ""))
		var tmpl: String = ABILITY_INTENT.get(action, "")
		if tmpl == "":
			continue
		if action == "charge_attack":
			intents.append(tr(tmpl) % _fmt_mult(1.0 + float(a.get("value", 100)) / 100.0))
		else:
			intents.append(tr(tmpl) % int(a.get("value", 0)) if tmpl.contains("%d") else tr(tmpl))
	if not intents.is_empty():
		parts.append(tr("Depois: ") + "; ".join(PackedStringArray(intents)) + ".")
	counter_label.text = " ".join(PackedStringArray(parts))

## 0.13.0: o retrato pulsa a laranja quando o golpe deste turno está carregado ou o inimigo vai carregar.
func _refresh_charge_look() -> void:
	if _portrait == null or not _alive(_portrait):
		return
	var charging := battle.charge_mult > 1.0 and not battle.finished
	for a in battle.enemy_intent(battle.turn):
		if String(a.get("action", "")) == "charge_attack" and not battle.silenced:
			charging = true
	if _portrait.charging != charging:
		_portrait.charging = charging
		if charging and battle.charge_mult > 1.0:
			_tip("charge")

## ×2, ×1.5 (sem casas a mais).
static func _fmt_mult(m: float) -> String:
	return str(int(m)) if is_equal_approx(m, roundf(m)) else ("%.1f" % m)

# --- Intenção do inimigo em ícones (o texto completo abre ao tocar) ---

func _make_intent_row() -> void:
	var vbox: Control = counter_label.get_parent()
	_intent_row = HBoxContainer.new()
	_intent_row.add_theme_constant_override("separation", 6)
	_intent_row.custom_minimum_size.y = 40
	_intent_row.mouse_filter = Control.MOUSE_FILTER_STOP
	vbox.add_child(_intent_row)
	vbox.move_child(_intent_row, counter_label.get_index())
	counter_label.visible = false
	_intent_row.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed and not SceneRouter.has_overlay():
			_open_intent())

func _intent_chip(parts: Array, bg: Color) -> PanelContainer:
	var chip := PanelContainer.new()
	chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	chip.add_theme_stylebox_override("panel", UiKit.flat(bg, 8, Color(0, 0, 0, 0), 0, 6))
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 3)
	chip.add_child(row)
	for part in parts:
		if String(part[0]) != "":
			var icon := CardIcon.new(String(part[0]), part[1], 18.0)
			icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			row.add_child(icon)
		if String(part[2]) != "":
			var l := UiKit.label(String(part[2]), 17, Color.WHITE)
			l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
			row.add_child(l)
	return chip

func _refresh_intent(lethal: bool, p: Dictionary) -> void:
	if _intent_row == null:
		return
	var b: CardInstance = p.get("blocker")
	var sig := "L" if lethal else "%d|%d|%s|%s|%d|%d|%s|%s|%d" % [int(p.get("damage", 0)), b.uid if b != null else -9, str(p.get("survives", false)),
		str(p.get("vigilant", false)), (p.get("deaths", []) as Array).size(), int(p.get("player_damage", 0)), str(battle.enemy_intent(battle.turn)),
		str(battle.charge_mult), int(p.get("chosen", -1))]
	if sig == _intent_sig and _intent_row.get_child_count() > 0:
		return
	_intent_sig = sig
	for c in _intent_row.get_children():
		_intent_row.remove_child(c)
		c.queue_free()
	if lethal:
		_intent_row.add_child(_intent_chip([["check", Color(0.45, 0.95, 0.55), tr("Letal: sem contra-ataque")]], Color(0.12, 0.3, 0.16)))
		return
	var dmg := int(p.get("damage", 0))
	var chosen := int(p.get("chosen", BattleManager.BLOCK_AUTO))
	if dmg <= 0:
		_intent_row.add_child(_intent_chip([["shield", Color(0.7, 0.8, 1.0), tr("Não ataca")]], Color(0.16, 0.18, 0.28)))
	else:
		var parts: Array = []
		if battle.charge_mult > 1.0:   # 0.13.0 golpe carregado
			parts.append(["instant", Color(1.0, 0.62, 0.2), "×" + _fmt_mult(battle.charge_mult)])
		parts.append(["creature", Color(1.0, 0.55, 0.5), str(dmg)])
		if b != null:
			parts.append(["shield", UiKit.GOLD if chosen >= 0 else Color(0.7, 0.85, 1.0), ""])
			if not bool(p.get("survives", false)):
				parts.append(["skull", Color(0.92, 0.92, 0.92), ""])
		elif not (p.get("deaths", []) as Array).is_empty():
			parts.append(["skull", Color(0.92, 0.92, 0.92), str((p["deaths"] as Array).size())])
		if int(p.get("player_damage", 0)) > 0:
			parts.append(["heart", Color(0.95, 0.35, 0.4), "−%d" % int(p["player_damage"])])
		if not battle.board.is_empty():
			parts.append(["", Color.WHITE, "›"])   # toca para escolher quem bloqueia
		var bg := Color(0.42, 0.2, 0.06) if battle.charge_mult > 1.0 else Color(0.3, 0.12, 0.14)
		_intent_row.add_child(_intent_chip(parts, bg))
	for a in battle.enemy_intent(battle.turn):
		var action := String(a.get("action", ""))
		var info: Array = INTENT_ICONS.get(action, [])
		if info.is_empty():
			continue
		var txt := str(int(a.get("value", 0))) if info[2] else ""
		if action == "charge_attack":
			txt = "×" + _fmt_mult(1.0 + float(a.get("value", 100)) / 100.0)
		_intent_row.add_child(_intent_chip([[info[0], info[1], txt]], Color(0.2, 0.16, 0.28)))

# --- Detalhe da cascata (tocar no cálculo) ---

func _make_calc_tap() -> void:
	var calc: Control = power_pill.get_parent()
	calc.mouse_filter = Control.MOUSE_FILTER_STOP
	power_pill.mouse_filter = Control.MOUSE_FILTER_PASS
	mult_pill.mouse_filter = Control.MOUSE_FILTER_PASS
	calc.tooltip_text = tr("Toca para ver o detalhe do ataque")
	calc.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed:
			_open_breakdown())

func _open_breakdown() -> void:
	if _animating or SceneRouter.has_overlay():
		return
	var c := battle.preview_attack()
	var title := tr("Ataque previsto: %s") % Cascade.fmt_int(c.net_total())
	if c.is_empty():
		if _last_cascade == null or _last_cascade.is_empty():
			return
		c = _last_cascade
		title = tr("Último ataque: %s") % Cascade.fmt_int(c.net_total())
	Sfx.select()
	CascadeBreakdown.open(c, title, _replay_last_attack if _last_cascade != null and not _last_cascade.is_empty() else Callable())

func _translated(names: Array[String]) -> Array[String]:
	var out: Array[String] = []
	for n in names:
		out.append(tr(n))
	return out

func _refresh_discard_button() -> void:
	discard_btn.text = tr("CANALIZAR (%d)") % battle.discards_left
	discard_btn.disabled = battle.discards_left <= 0 or battle.resolving or battle.finished
	if discard_btn.disabled and _discard_mode:
		discard_btn.button_pressed = false

# --- Handlers ---

func _on_mana_changed(available: int, total: int) -> void:
	_set_mana(available, total)
	_refresh_hand()

func _on_discards_changed(_left: int) -> void:
	_refresh_discard_button()

func _on_turn_started(t: int) -> void:
	turn_label.text = _turn_text()
	_refresh_pips()
	_refresh_info_row()
	end_turn_btn.disabled = false
	if t != _undo_turn:
		_undo_stack.clear()
		_undo_turn = t
	_refresh_discard_button()
	_refresh_all()
	if not battle.finished and not battle.puzzle:
		GameState.save_run(battle.to_dict(), "battle")   # gravação automática a cada turno
	if t > 1 and not _resumed:
		_show_banner(tr("TURNO %d") % t, 0.6, true)
		# 0.13.0: mana guardada do turno anterior e golpe carregado a caminho.
		if battle.last_mana_saved > 0:
			_log(tr("Mana guardada: +%d neste turno.") % battle.last_mana_saved)
			if _mana_pips != null:
				_mana_pips.flash_saved(battle.last_mana_saved)
		if battle.charge_mult > 1.0:
			_warn(tr("%s carregou um golpe: este turno ataca com ×%s!") % [tr(battle.enemy.name), _fmt_mult(battle.charge_mult)], Color(1.0, 0.6, 0.2), 3.2)
	if battle.board.size() >= 2:
		_tip("order")

func _on_enemy_hp(current: int, max_hp: int) -> void:
	enemy_hp_bar.max_value = max_hp
	enemy_hp_ghost.max_value = max_hp
	if _hp_tween != null and _hp_tween.is_valid():
		_hp_tween.kill()
	_hp_tween = create_tween().set_parallel(true)
	_hp_tween.tween_property(enemy_hp_ghost, "value", float(current), _d(0.45)).set_ease(Tween.EASE_OUT)
	_hp_tween.tween_property(enemy_hp_bar, "value", float(current if _animating else max(0, current - _last_preview_total)), _d(0.45)).set_ease(Tween.EASE_OUT)
	enemy_hp_label.text = "%s / %s" % [Cascade.fmt_int(current), Cascade.fmt_int(max_hp)]
	if GameState.puzzle_id == "training":
		enemy_hp_label.text = "∞"

func _on_spell_cast(_card: CardInstance) -> void:
	_refresh_spells()

func _on_creature_died(card: CardInstance) -> void:
	# 0.12.0: o som da morte toca no Sfx (ouve o creature_died)
	_log(tr("%s morreu.") % tr(card.data.name))
	if _board_views.has(card.uid) and is_instance_valid(_board_views[card.uid]):
		_animate_death(_board_views[card.uid])
	_refresh_board()
	_refresh_preview()
	_refresh_zone_buttons()

func _on_creature_blocked(card: CardInstance, amount: int) -> void:
	_log(tr("%s bloqueou %d de dano.") % [tr(card.data.name), amount])
	if _board_views.has(card.uid):
		var view: CardView = _board_views[card.uid]
		if is_instance_valid(view):
			view.refresh()
			_flash(view, Color(1.6, 1.6, 1.6))
			_bump(view, 0.9)

func _on_card_discarded(card: CardInstance) -> void:
	_log(tr("Canalizaste %s.") % tr(card.data.name))
	_refresh_zone_buttons()

func _on_card_grew(card: CardInstance, amount: int) -> void:
	var view: Control = _board_views.get(card.uid, _hand_views.get(card.uid))
	if view != null and is_instance_valid(view):
		if view is CardView:
			view.refresh()
		_pop(view, tr("Cresce +%d") % amount, COLOR_GROW)
	_refresh_preview()

func _on_hand_card_pressed(card: CardInstance) -> void:
	if battle.resolving or battle.finished:
		return
	if battle.pending_bottom > 0:
		if battle.bottom_card(card):
			Sfx.hit()
			if battle.pending_bottom > 0:
				_log(tr("Escolhe mais %d carta(s) para o fundo do grimório.") % battle.pending_bottom)
			else:
				_log(tr("Mão nova com %d cartas.") % battle.deck.hand.size() + " " + _play_help(false))
				GameState.save_run(battle.to_dict(), "battle")
			_refresh_all()
		return
	if _discard_mode:
		if battle.can_discard(card):
			if Settings.warn_rare and (card.data.rarity == "rare" or card.data.rarity == "mythic") and not battle.puzzle:
				var go_on := await _ask(tr("Canalizar uma rara?"), tr("%s é uma carta rara. Canalizá-la manda-a para o cemitério.") % card.data.display_name(), tr("CANALIZAR"))
				if go_on == "never":
					Settings.warn_rare = false
					Settings.save_settings()
				elif go_on != "yes":
					return
				if not battle.can_discard(card):
					return
			_push_undo()
			battle.discard(card)   # o som de canalizar toca no Sfx (card_discarded)
			Settings.vibrate(20)
			discard_btn.button_pressed = false   # desliga o modo (toggled → _on_discard_toggled)
			_refresh_all()
		return
	var from_rect := Rect2()
	if _hand_views.has(card.uid) and is_instance_valid(_hand_views[card.uid]):
		from_rect = (_hand_views[card.uid] as Control).get_global_rect()
	if battle.can_play(card):
		_set_selection(-1)
		var kick := false
		if battle.can_kick(card):
			var choice := await _ask_kicker(card)
			if choice == "":
				return
			kick = choice == "kick"
			if not battle.can_play(card):
				return
		_push_undo()
		battle.play(card, kick)
		Sfx.select()
		hand_box.clear_hover()
		_refresh_all()
		_animate_play(card, from_rect)

## 0.12.1: um toque numa carta da mão escolhe-a (sobe, contorno dourado e "JOGAR"); outro toque na mesma
## joga-a. Também se joga arrastando-a para cima, até à Arena. Segurar abre-a em grande. Canalizar, o fundo
## do Mulligan e a opção "1 toque" (Configurações) continuam a jogar/escolher com um toque só.
func _on_hand_card_tapped(card: CardInstance) -> void:
	if battle.resolving or battle.finished:
		return
	if battle.pending_bottom > 0 or _discard_mode or Settings.play_taps == 1 or _selected_uid == card.uid:
		_set_selection(-1)
		_on_hand_card_pressed(card)
		return
	_set_selection(card.uid)
	if battle.can_play(card):
		Sfx.select()
		_hint_line(tr("%s: toca outra vez para a jogar (ou arrasta-a para cima).") % card.data.display_name())
	else:
		Sfx.deny()
		_hint_line(tr("Agora não dá para jogar %s.") % card.data.display_name())
		_warn(_block_reason_text(card))

## 0.13.0: porque é que a carta não se joga agora (com os números da mana).
func _block_reason_text(card: CardInstance) -> String:
	var why := battle.play_block_reason(card)
	if why == "Falta mana.":
		return tr("Falta mana: %s custa %d e tens %d.") % [card.data.display_name(), battle.effects.cost_of(card), battle.mana_available]
	return tr(why)

## Dica na linha de texto sem a guardar no histórico (some quando a escolha acaba).
func _hint_line(text: String) -> void:
	log_label.text = text
	log_label.modulate = Color(1, 0.85, 0.5)
	create_tween().tween_property(log_label, "modulate", Color.WHITE, 0.8)
	_sel_hint = true

## Como se joga uma carta (muda com a opção "Jogar uma carta" das Configurações).
func _play_help(mulligan: bool) -> String:
	if Settings.play_taps == 1:
		return tr("Toca numa carta para a jogar — ou faz Mulligan.") if mulligan else tr("Toca numa carta para a jogar.")
	return tr("Toca numa carta para a escolher e outra vez para a jogar — ou faz Mulligan.") if mulligan else tr("Toca numa carta para a escolher e outra vez para a jogar.")

func _set_selection(uid: int) -> void:
	if _selected_uid == uid:
		return
	_selected_uid = uid
	if uid < 0 and _sel_hint:
		_sel_hint = false
		log_label.text = _last_log
	_apply_selection()

## Contorno e "JOGAR" na carta escolhida; na mão ela fica levantada.
func _apply_selection() -> void:
	if _selected_uid >= 0 and not _hand_views.has(_selected_uid):
		_selected_uid = -1
	var sel: Control = null
	for uid in _hand_views:
		var v: CardView = _hand_views[uid]
		if not _alive(v):
			continue
		var on := int(uid) == _selected_uid
		v.set_selected(on, on and battle.can_play(v.card))
		if on:
			sel = v
	hand_box.set_selected(sel)

## Há uma carta da mão (ou o "JOGAR" da escolhida) neste ponto do ecrã?
func _hand_card_at(pos: Vector2) -> bool:
	for v in _hand_views.values():
		if not _alive(v):
			continue
		var r := (v as Control).get_global_rect()
		if (v as CardView).is_selected():
			r = r.grow_individual(0, 34, 0, 0)
		if r.grow(4).has_point(pos):
			return true
	return false

## Arrastar uma carta da mão: fica a flutuar (maior) por cima do dedo; ao passar pelas outras muda de
## lugar (os Terrenos ficam no grupo deles, à direita); largada lá em cima, na Arena, é jogada.
func _on_hand_drag_started(card: CardInstance, pos: Vector2) -> void:
	if battle.resolving or battle.finished or _drag_ghost != null or _animating:
		return
	var view: Control = _hand_views.get(card.uid)
	if not _alive(view):
		return
	var top := SceneRouter.top_overlay()
	if top is CardZoom:
		(top as CardZoom).close()   # segurou (abriu em grande) e depois arrastou
	elif SceneRouter.has_overlay() or _alive(_modal):
		return
	_set_selection(-1)
	_hand_drag_card = card
	_drag_view = view
	_play_zone = false
	view.modulate.a = 0.3
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = view.size
	ghost.pivot_offset = ghost.size / 2.0
	ghost.scale = Vector2(1.15, 1.15)
	ghost.z_index = 45
	ghost.global_position = _hand_ghost_pos(pos, ghost)
	_drag_ghost = ghost
	_drag_last_x = pos.x
	_drag_shadow = Panel.new()
	_drag_shadow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := StyleBoxFlat.new()
	sh.bg_color = Color(0, 0, 0, 0.35)
	sh.set_corner_radius_all(14)
	sh.shadow_color = Color(0, 0, 0, 0.45)
	sh.shadow_size = 14
	_drag_shadow.add_theme_stylebox_override("panel", sh)
	_drag_shadow.size = view.size * 1.15
	_drag_shadow.z_index = 44
	add_child(_drag_shadow)
	_drag_shadow.global_position = ghost.global_position + Vector2(10, 14)
	Settings.vibrate(15)
	Sfx.select()

## A carta flutua um pouco acima do dedo (o dedo não a tapa).
func _hand_ghost_pos(pos: Vector2, ghost: Control) -> Vector2:
	return pos - ghost.size / 2.0 - Vector2(0, ghost.size.y * 0.4)

func _on_hand_drag_moved(card: CardInstance, pos: Vector2) -> void:
	if _drag_ghost == null or _hand_drag_card != card:
		return
	_drag_ghost.global_position = _hand_ghost_pos(pos, _drag_ghost)
	_tilt_ghost(pos)
	if _alive(_drag_shadow):
		_drag_shadow.global_position = _drag_ghost.global_position + Vector2(10, 14)
	var zone := _in_play_zone(pos)
	if zone != _play_zone:
		_play_zone = zone
		(_drag_ghost as CardView).set_selected(zone, _drag_playable(card))
		if zone:
			Settings.vibrate(10)
			if _drag_playable(card):
				_show_what_if(card)   # 0.13.0: o cálculo mostra o ataque com esta carta
		elif _what_if:
			_refresh_preview()
	if zone or not _alive(_drag_view):
		return
	var index := _hand_slot_for_x(pos.x, _drag_view)
	if index >= 0 and index != _drag_view.get_index():
		hand_box.move_child(_drag_view, index)
		_update_fan_gaps()
		Sfx.tick()

func _on_hand_drag_ended(card: CardInstance, _pos: Vector2) -> void:
	if _hand_drag_card != card:
		return
	var play := _play_zone and _drag_playable(card)
	if _drag_ghost != null:
		_drag_ghost.queue_free()
		_drag_ghost = null
	if _alive(_drag_shadow):
		_drag_shadow.queue_free()
	_drag_shadow = null
	if _alive(_drag_view):
		(_drag_view as CardView).playable = (_drag_view as CardView).playable   # repõe a transparência
	_drag_view = null
	_hand_drag_card = null
	_play_zone = false
	if _what_if:
		_refresh_preview()
	if play:
		_on_hand_card_pressed(card)
	else:
		_commit_hand_order()

## Zona de jogar: bem acima da mão (Arena e cálculo). Nunca no modo canalizar nem no fundo do Mulligan.
func _in_play_zone(pos: Vector2) -> bool:
	if _discard_mode or battle.pending_bottom > 0:
		return false
	return pos.y < hand_box.get_global_rect().position.y - 50.0

func _drag_playable(card: CardInstance) -> bool:
	return not _discard_mode and battle.pending_bottom == 0 and battle.can_play(card)

## Lugar na mão para a carta arrastada (pelo x do dedo), sem sair do grupo dela (Terrenos à direita).
func _hand_slot_for_x(x: float, dragged: Control) -> int:
	var kids := hand_box.get_children()
	var index := 0
	var non_lands := 0
	for c in kids:
		var cv := c as CardView
		if cv != null and cv.card != null and not cv.card.data.is_land():
			non_lands += 1
		if c == dragged:
			continue
		var ctl := c as Control
		if ctl != null and x > ctl.global_position.x + ctl.size.x / 2.0:
			index += 1
	var is_land := (dragged as CardView).card.data.is_land()
	var lo := non_lands if is_land else 0
	var hi := kids.size() - 1 if is_land else non_lands - 1
	return clampi(index, lo, maxi(lo, hi))

## O espaço antes do grupo dos Terrenos vai sempre para o primeiro Terreno.
func _update_fan_gaps() -> void:
	var first := true
	for c in hand_box.get_children():
		var cv := c as CardView
		if cv == null or cv.card == null:
			continue
		var land := cv.card.data.is_land()
		cv.set_meta("fan_gap_before", land and first)
		if land:
			first = false
	hand_box.queue_sort()

## A ordem em que a mão ficou passa a ser a da mão (ORDENAR → "A tua ordem").
func _commit_hand_order() -> void:
	var order: Array[CardInstance] = []
	for v in hand_box.get_children():
		var cv := v as CardView
		if cv != null and not cv.is_queued_for_deletion() and cv.card != null and cv.card in battle.deck.hand and not (cv.card in order):
			order.append(cv.card)
	for c in battle.deck.hand:
		if not (c in order):
			order.append(c)
	if order != battle.deck.hand:
		battle.deck.hand.assign(order)
		if Settings.hand_sort != "":
			Settings.hand_sort = ""
			Settings.save_settings()
		if _sort_btn != null:
			_refresh_tool_buttons()
	_refresh_hand()

func _push_undo() -> void:
	_undo_stack.append(battle.snapshot())
	if _undo_stack.size() > 12:
		_undo_stack.pop_front()

func _on_undo() -> void:
	if _undo_stack.is_empty() or battle.resolving or battle.finished:
		return
	var snap: Dictionary = _undo_stack.pop_back()
	discard_btn.button_pressed = false
	_resumed = true   # sem banner "TURNO N"
	var ok := battle.restore_snapshot(snap)
	_resumed = false
	if ok:
		Sfx.hit()
		_log(tr("Jogada desfeita."))
	_refresh_all()

func _on_card_long_pressed(card: CardInstance) -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	CardZoom.show_card(card)

func _on_relic_pressed(id: String) -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	CardZoom.show_relic(id)

func _open_library() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	ZoneViewer.open_library(tr("GRIMÓRIO"), battle.deck.library, maxi(0, battle.hand_size - battle.deck.hand.size()))

func _open_graveyard() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	var pickable := battle.flashback_cards().filter(func(c): return battle.can_flashback(c))
	if pickable.is_empty() or battle.resolving or battle.finished:
		ZoneViewer.open(tr("CEMITÉRIO"), battle.deck.graveyard, false, Callable(), Callable(), tr("EXÍLIO"), battle.deck.exile)
		return
	ZoneViewer.open(tr("CEMITÉRIO — ↺ toca num feitiço para o recapitular"), battle.deck.graveyard, false,
		func(card: CardInstance):
			if battle.can_flashback(card):
				_push_undo()
				battle.play_flashback(card)
				Sfx.boom()
				_refresh_all(),
		func(card: CardInstance): return battle.can_flashback(card),
		tr("EXÍLIO"), battle.deck.exile)

# --- Mulligan ---

func _on_mulligan() -> void:
	if not battle.can_mulligan() or SceneRouter.has_overlay():
		return
	Sfx.shuffle()
	Settings.vibrate(20)
	battle.mulligan()

func _on_mulligan_taken(count: int) -> void:
	_log(tr("Mão nova. Escolhe %d carta(s) para o fundo do grimório.") % count)
	_refresh_all()

# --- Dupla face, selos, recapitular, exílio ---

func _on_card_transformed(card: CardInstance) -> void:
	Sfx.boom()
	Settings.vibrate(40)
	_log(tr("%s virou!") % tr(card.data.name))
	var view: Control = _board_views.get(card.uid, _hand_views.get(card.uid))
	if _alive(view) and Settings.anim_scale() > 0.0:
		view.pivot_offset = view.size / 2.0
		_kill_tween(view, "flip_tw")
		var tw := create_tween()
		tw.tween_property(view, "scale:x", 0.0, _d(0.14)).set_ease(Tween.EASE_IN)
		tw.tween_callback(func():
			if _alive(view) and view is CardView:
				(view as CardView).refresh())
		tw.tween_property(view, "scale:x", 1.0, _d(0.16)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
		view.set_meta("flip_tw", tw)
		_pop(view, "⇄ " + tr("Transformação!"), COLOR_FORMATION)
	else:
		_refresh_all()
	_refresh_preview()

func _on_card_flashback(card: CardInstance) -> void:
	_log(tr("Recapitulaste %s — vai para o exílio.") % tr(card.data.name))

func _on_seal_triggered(card: CardInstance, seal: String) -> void:
	var view: Control = _board_views.get(card.uid, _hand_views.get(card.uid))
	var text := ""
	match seal:
		"tithe":
			text = tr("+3 ouro")
		"vitality":
			text = tr("+15 Poder")
		"phyrexian":
			text = tr("−10 Poder")
		"wisdom":
			text = tr("Formação +1")
	if text != "":
		_pop(view if _alive(view) else formation_label, "◉ " + text, COLOR_SEAL)

func _on_formation_leveled(id: String, level: int) -> void:
	_log(tr("%s sobe para o nível %d.") % [tr(String(CardDB.get_formation(id).get("name", id))), level])

func _on_card_exiled_run(card: CardInstance) -> void:
	_log(tr("%s foi exilada da run.") % tr(card.data.name))
	if _board_views.has(card.uid) and is_instance_valid(_board_views[card.uid]):
		_animate_death(_board_views[card.uid])
	_refresh_all()

func _on_boss_ascended(text: String) -> void:
	Sfx.hit()
	Settings.vibrate(80)
	_shake(12.0)
	# Vem logo a seguir ao despertar: o banner junta as duas coisas.
	_show_banner((tr("O BOSS DESPERTA") + "\n" if battle.phase2 else "") + tr("ASCENSÃO MÍTICA"), 1.3)
	_log(tr(text) if text != "" else tr("O boss ativa a 2.ª regra!"))
	_refresh_enemy_header()
	_refresh_discard_button()

## O boss passou abaixo de metade da vida: desperta (+ataque) e diz uma fala.
func _on_boss_phase2(line: String) -> void:
	Sfx.boom()
	Settings.vibrate(80)
	_shake(14.0)
	if _pending_phase_text != "":   # 0.13.0: bosses com várias fases dizem o que mudou
		_show_banner(tr("O BOSS DESPERTA") + "\n" + tr(_pending_phase_text), 1.3)
		_log(tr("%s despertou: %s") % [tr(battle.enemy.name), tr(_pending_phase_text)])
		_pending_phase_text = ""
	else:
		_show_banner(tr("O BOSS DESPERTA") + "\n" + tr("+%d de ataque") % BattleManager.PHASE2_ATTACK, 1.1)
		_log(tr("%s despertou: +%d de ataque.") % [tr(battle.enemy.name), BattleManager.PHASE2_ATTACK])
	_flash(enemy_panel, Color(2.0, 0.6, 0.5))
	_refresh_enemy_header()
	_refresh_preview()
	_say(line, 3.0)

## Coração de Vidro: um golpe mortal deixou-te com 1 de vida.
func _on_death_saved() -> void:
	Sfx.boom()
	Settings.vibrate(120)
	_show_banner(tr("CORAÇÃO DE VIDRO"), 1.2)
	_log(tr("O Coração de Vidro estilhaçou-se: ficas com 1 de vida."))
	_flash(player_label, Color(1.6, 1.8, 2.4))

func _on_contract_resolved(success: bool, text: String) -> void:
	if text != "":
		SceneRouter.toast(("✓ " if success else "✗ ") + text, 2.6)

## Devorador de Horizontes: a criatura mais à direita sai para o exílio.
func _on_creature_exiled(card: CardInstance) -> void:
	Sfx.hit()
	_log(tr("%s devorou %s.") % [tr(battle.enemy.name), tr(card.data.name)])
	if _board_views.has(card.uid) and is_instance_valid(_board_views[card.uid]):
		_animate_death(_board_views[card.uid])
	_refresh_board()
	_refresh_preview()
	_refresh_zone_buttons()

## Chuva de Meteoros: dano à criatura da 3.ª posição no fim do turno.
func _on_climate_hit(card: CardInstance, amount: int) -> void:
	_log(tr("%s: %s sofre %d de dano.") % [tr(battle.climate_name()), tr(card.data.name), amount])
	var view: Control = _board_views.get(card.uid)
	if _alive(view):
		if view is CardView:
			(view as CardView).refresh()
		_flash(view, Color(2.0, 0.9, 0.6))
		_pop(view, "−%d" % amount, Color(1.0, 0.45, 0.25))

# --- Falas do boss ---

func _boss_line(key: String) -> String:
	if not bool(battle.enemy.get("boss", false)) and String(battle.enemy.get("variant", "")) != "nemesis":
		return ""
	return String((battle.enemy.get("lines", {}) as Dictionary).get(key, ""))

func _say_after(text: String, delay: float, seconds: float = 3.0) -> void:
	if text == "":
		return
	if delay > 0.0:
		await get_tree().create_timer(delay).timeout
	if is_inside_tree() and not battle.finished:
		_say(text, seconds)

## Balão de fala ao lado do painel do inimigo (some sozinho e não bloqueia toques).
func _say(text: String, seconds: float = 3.0) -> void:
	if text == "" or not is_inside_tree():
		return
	if _bubble_tw != null and _bubble_tw.is_valid():
		_bubble_tw.kill()
	if _alive(_bubble):
		_bubble.queue_free()
	var b := PanelContainer.new()
	b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_theme_stylebox_override("panel", UiKit.flat(Color(0.97, 0.94, 0.88), 14, Color(0.25, 0.15, 0.3), 3, 12))
	var l := UiKit.label("«" + tr(text) + "»", 18, Color(0.14, 0.08, 0.16), true)
	l.custom_minimum_size.x = 300
	b.add_child(l)
	add_child(b)
	_bubble = b
	b.modulate.a = 0.0
	await get_tree().process_frame
	if not _alive(b):
		return
	b.reset_size()
	var er := enemy_panel.get_global_rect()
	var right_side := not Settings.left_handed
	var x := er.end.x + 16.0 if right_side else er.position.x - b.size.x - 16.0
	b.global_position = Vector2(x, er.position.y + 8.0)
	# Bico a apontar para o inimigo.
	var tail := Polygon2D.new()
	tail.color = Color(0.97, 0.94, 0.88)
	if right_side:
		tail.polygon = PackedVector2Array([Vector2(2, 16), Vector2(-16, 26), Vector2(2, 36)])
	else:
		tail.polygon = PackedVector2Array([Vector2(b.size.x - 2, 16), Vector2(b.size.x + 16, 26), Vector2(b.size.x - 2, 36)])
	b.add_child(tail)
	b.pivot_offset = Vector2(0.0 if right_side else b.size.x, 26.0)
	b.scale = Vector2(0.7, 0.7)
	_bubble_tw = create_tween()
	_bubble_tw.set_parallel(true)
	_bubble_tw.tween_property(b, "modulate:a", 1.0, 0.15)
	_bubble_tw.tween_property(b, "scale", Vector2.ONE, 0.22).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	_bubble_tw.chain().tween_interval(seconds)
	_bubble_tw.chain().tween_property(b, "modulate:a", 0.0, 0.3)
	_bubble_tw.chain().tween_callback(b.queue_free)
	Sfx.blip(3)

# --- Linha de informação: clima, contrato e planeswalker ---

## Por cima do cálculo: chip do Clima Planar, chip do contrato ativo e o painel do planeswalker.
func _build_info_row() -> void:
	for c in pw_row.get_children():
		pw_row.remove_child(c)
		c.queue_free()
	_pw_buttons.clear()
	_pw_panel = null
	_pw_loyalty = null
	_pw_name = null
	_climate_chip = null
	_climate_label = null
	_contract_chip = null
	var any := false
	if battle.climate != "":
		var cdef := CardDB.get_climate(battle.climate)
		_climate_chip = UiKit.info_chip("climate", tr(String(cdef.get("name", ""))), COLOR_CLIMATE, func():
			CardZoom.show_climate(battle.climate, _climate_suffix()))
		_climate_label = _climate_chip.get_meta("label")
		pw_row.add_child(_climate_chip)
		any = true
	if not GameState.contract.is_empty() and not battle.puzzle:
		var con: Dictionary = GameState.contract
		_contract_chip = UiKit.info_chip("contract", tr(String(con.get("name", ""))), UiKit.GOLD, func():
			CardZoom.show_contract(con))
		pw_row.add_child(_contract_chip)
		any = true
	var def := GameState.planeswalker_def()
	if not def.is_empty():
		_build_planeswalker(def, any)
		any = true
	pw_row.visible = any
	_refresh_info_row()

## Lua de Sangue: "· Dia" / "· Noite" conforme o turno.
func _climate_suffix() -> String:
	if battle.climate == "blood_moon":
		return "  ·  " + (tr("Noite") if battle.is_night() else tr("Dia"))
	return ""

func _refresh_info_row() -> void:
	if _climate_label != null and is_instance_valid(_climate_label):
		_climate_label.text = tr(battle.climate_name()) + _climate_suffix()
	_refresh_planeswalker()

func _build_planeswalker(def: Dictionary, compact: bool) -> void:
	var color: Color = CardView.COLORS.get(String(def.get("color", "colorless")), UiKit.GOLD)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.12, 0.1, 0.18), 10, color, 2, 6))
	pw_row.add_child(panel)
	_pw_panel = panel
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	panel.add_child(row)
	var info := VBoxContainer.new()
	info.add_theme_constant_override("separation", 0)
	info.custom_minimum_size.x = 180 if compact else 230
	row.add_child(info)
	_pw_name = UiKit.label("✦ " + tr(String(def.get("name", ""))), 15, color)
	_pw_name.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	info.add_child(_pw_name)
	_pw_loyalty = UiKit.label("", 14, UiKit.TEXT_DIM)
	_pw_loyalty.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	info.add_child(_pw_loyalty)
	var zoom := Button.new()
	zoom.text = "?"
	zoom.custom_minimum_size = Vector2(34, 34)
	zoom.add_theme_font_size_override("font_size", 16)
	zoom.pressed.connect(func():
		if not SceneRouter.has_overlay():
			Sfx.select()
			CardZoom.show_planeswalker(String(def.get("id", ""))))
	row.add_child(zoom)
	var skills: Array = def.get("skills", [])
	for i in skills.size():
		var cost := int(skills[i].get("cost", 0))
		var b := UiKit.button(("+%d" if cost > 0 else "%d") % cost, 36, 16, color.darkened(0.35), color)
		b.custom_minimum_size.x = 62
		b.pressed.connect(_on_pw_skill.bind(i))
		b.tooltip_text = tr(String(skills[i].get("text", "")))
		row.add_child(b)
		_pw_buttons.append(b)

func _refresh_planeswalker() -> void:
	var def := GameState.planeswalker_def()
	var has_panel := _pw_panel != null and is_instance_valid(_pw_panel)
	if def.is_empty():
		if has_panel:
			_build_info_row()
		return
	if not has_panel or _pw_buttons.size() != (def.get("skills", []) as Array).size():
		_build_info_row()
		return
	var max_l := int(def.get("max_loyalty", 6))
	var l := GameState.planeswalker_loyalty()
	var pips := ""
	for i in max_l:
		pips += "●" if i < l else "○"
	_pw_loyalty.text = tr("Lealdade %d/%d") % [l, max_l] + "  " + pips + ("  ·  " + tr("usado") if battle.pw_used_this_turn else "")
	for i in _pw_buttons.size():
		_pw_buttons[i].disabled = not battle.can_use_planeswalker(i)

func _on_pw_skill(i: int) -> void:
	if not battle.can_use_planeswalker(i) or SceneRouter.has_overlay():
		return
	var skill: Dictionary = battle.planeswalker_skills()[i]
	_push_undo()
	if battle.use_planeswalker(i):
		Sfx.boom()
		Settings.vibrate(30)
		_log("✦ " + tr(String(skill.get("text", ""))))
		_pop(_pw_panel if _alive(_pw_panel) else pw_row, "✦ " + tr(String(GameState.planeswalker_def().get("name", ""))), COLOR_FORMATION)
		_refresh_all()

func _on_discard_toggled(on: bool) -> void:
	_discard_mode = on and battle.discards_left > 0
	if on and battle.discards_left <= 0:
		discard_btn.button_pressed = false
	for view in _hand_views.values():
		if is_instance_valid(view):
			view.modulate = DISCARD_TINT if _discard_mode else Color.WHITE
			view.playable = battle.can_play(view.card) or view.card.data.is_land() or _discard_mode
	if _discard_mode:
		_log(tr("Toca na carta a canalizar."))
		Sfx.select()

func _on_end_turn() -> void:
	if battle.resolving or battle.finished or _alive(_modal):
		return
	# 0.13.0: no fundo do Mulligan ainda não se pode atacar (antes o botão desligava-se e ficava preso).
	if battle.pending_bottom > 0:
		Sfx.deny()
		_warn(tr("Primeiro escolhe %d carta(s) para o fundo do grimório.") % battle.pending_bottom)
		return
	if Settings.warn_mana and not battle.puzzle and battle.mana_available > 0:
		var best := 0
		for c in battle.deck.hand:
			if battle.can_play(c) and not c.data.is_land():
				best = maxi(best, battle.preview_play(c))
		if best > 0:
			var ans := await _ask(tr("Atacar sem gastar a mana?"), tr("Ainda tens %d de mana e cartas que aumentam o ataque (até +%s).") % [battle.mana_available, Cascade.fmt_int(best)], tr("ATACAR"))
			if ans == "never":
				Settings.warn_mana = false
				Settings.save_settings()
			elif ans != "yes":
				return
			if battle.resolving or battle.finished:
				return
	_bump(end_turn_btn, 0.92)
	end_turn_btn.disabled = true
	discard_btn.button_pressed = false
	discard_btn.disabled = true
	battle.end_turn()
	# Rede de segurança: se o turno não começou a resolver (o jogo recusou atacar), os botões voltam.
	if not battle.resolving and not battle.finished:
		end_turn_btn.disabled = false
		_refresh_discard_button()

func _on_enemy_ability(enemy_name_str: String, action: String) -> void:
	_log("%s %s!" % [tr(enemy_name_str), tr(ABILITY_LOG.get(action, action))])
	_flash(enemy_panel, Color(1.3, 1.1, 1.5))
	_refresh_all()

func _on_damage_dealt(target: String, amount: int) -> void:
	if target == "enemy":
		_log(tr("Causaste %s de dano.") % Cascade.fmt_int(amount))
		_animate_enemy_hit(amount)
		if _portrait != null:
			_portrait.hit()
		# Peso do golpe: congela um instante e abana em proporção à vida máxima do inimigo.
		var pct := minf(1.0, float(amount) / maxf(1.0, float(battle.enemy.get("max_hp", 1))))
		if pct >= 0.2:
			SceneRouter.hit_stop(0.05 + 0.1 * pct)
		_shake(4.0 + 16.0 * pct)
		if not _hit_line_said and pct >= 0.25 and int(battle.enemy.hp) > 0:
			var will_awaken := not battle.phase2 and int(battle.enemy.hp) * 2 <= int(battle.enemy.max_hp)
			var line := _boss_line("hit")
			if line != "" and not will_awaken:
				_hit_line_said = true
				_say(line, 2.4)
	else:
		Sfx.hit()
		Settings.vibrate(60)
		_animate_enemy_strike(amount)
		_shake(8.0)
		_flash(player_label, Color(2.0, 0.6, 0.6))
		_log(tr("Levaste %d de dano.") % amount)

func _on_battle_ended(victory: bool) -> void:
	pause_btn.disabled = true
	if GameState.puzzle_id == "training":
		_training_result()
		return
	if GameState.is_lesson_battle():
		var ok := victory or (String(_lesson_def.get("goal_type", "win")) == "react" and _lesson_reacted)
		_lesson_result(ok)
		return
	if battle.puzzle or GameState.puzzle_id != "":   # 0.13.0: um enigma nunca acaba como uma run
		if victory:
			Stats.on_puzzle_solved(GameState.puzzle_id)
			_show_banner(tr("RESOLVIDO!"), 1.2)
			Sfx.boom()
			CelebrationFx.play(self, get_viewport_rect(), "confetti")
		else:
			_show_banner(tr("NÃO CHEGOU"), 1.0)
		await _puzzle_result(victory)
		return
	if GameState.arena_battle:
		await _arena_result(victory)
		return
	if victory:
		# 0.13.0: o inimigo afunda e racha, o golpe final abranda e há confetes.
		if _portrait != null and _alive(_portrait):
			_portrait.charging = false
			_portrait.defeat()
		SceneRouter.hit_stop(0.35, 0.3)
		CelebrationFx.play(self, get_viewport_rect(), "confetti")
		var last_words := _boss_line("defeat")
		var extra := 0.0
		if battle.perfect_play:
			SceneRouter.toast("★ " + tr("Jogada perfeita: venceste com a mana toda gasta (+%d ouro).") % BattleManager.PERFECT_GOLD, 2.8)
			Sfx.level_up()
			extra += _d(0.4)
		if last_words != "":
			_say(last_words, 2.0)
			extra = _d(1.3)
		if String(battle.enemy.get("variant", "")) == "nemesis" and GameState.last_reward_text != "":
			SceneRouter.toast("☠ " + tr("Némesis vencida: %s") % GameState.last_reward_text, 2.8)
		if GameState.last_milestone_text != "":
			SceneRouter.toast("∞ " + tr("Marco do Infinito (ante %d): %s") % [GameState.ante, GameState.last_milestone_text], 3.4, false)
			Sfx.level_up()
			extra += _d(0.8)
		if String(battle.enemy.get("variant", "")) == "elite":
			if battle.elite_relic != "":
				SceneRouter.toast("★ " + tr("Elite vencida: recebes %s.") % tr(String(CardDB.relics.get(battle.elite_relic, {}).get("name", ""))), 2.6)
			else:
				SceneRouter.toast(tr("Elite vencida: +%d ouro (não tinhas lugar para outra relíquia).") % 10, 2.6)
			if battle.elite_item != "":   # 0.13.0: e uma poção ou pergaminho
				SceneRouter.toast("◆ " + tr("Recebes: %s.") % tr(String(CardDB.get_consumable(battle.elite_item).get("name", ""))), 2.6)
			var nafx := (battle.enemy.get("affixes", []) as Array).size() if battle.enemy.get("affixes") is Array else 0
			if nafx > 0:
				SceneRouter.toast(tr("Afixos vencidos: +%d ouro.") % (GameState.AFFIX_GOLD * nafx), 2.2)
		if GameState.ante >= GameState.max_ante and not GameState.endless:
			GameState.last_victory = true
			EventBus.run_ended.emit(true)
			_show_banner(tr("VITÓRIA"), 1.0)
			await get_tree().create_timer(_d(0.9) + extra).timeout
			SceneRouter.go("run_over")
		else:
			_show_banner(tr("ANTE %d VENCIDO") % GameState.ante, 1.0)
			Sfx.boom()
			await get_tree().create_timer(_d(0.9) + extra).timeout
			GameState.map_phase = "stop"
			# Boss que não acaba a run: Baú de Espólio (1 de 3 relíquias de boss) antes da paragem.
			if bool(battle.enemy.get("boss", false)) and not GameState.prepare_loot().is_empty():
				GameState.save_run({}, "loot")
				SceneRouter.go("loot")
			else:
				GameState.save_run({}, "map")
				SceneRouter.go("map")
	else:
		GameState.last_victory = false
		EventBus.run_ended.emit(false)
		# 0.13.0: cinza a cair e o inimigo a rir-se (investida).
		CelebrationFx.play(self, get_viewport_rect(), "ash")
		if _portrait != null and _alive(_portrait):
			_portrait.attack()
		_show_banner(tr("DERROTA"), 1.0)
		await get_tree().create_timer(_d(1.0) + (0.6 if Settings.motion_ok() else 0.0)).timeout
		SceneRouter.go("run_over")

# --- Arrastar para reordenar (tabuleiro e relíquias) ---

func _on_board_drag_started(card: CardInstance, pos: Vector2) -> void:
	if battle.resolving or battle.finished or _drag_ghost != null:
		return
	var view: Control = _board_views.get(card.uid)
	if not _alive(view):
		return
	_drag_view = view
	view.modulate.a = 0.35
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = view.size
	ghost.pivot_offset = ghost.size / 2.0
	ghost.scale = Vector2(1.06, 1.06)
	ghost.rotation = 0.04
	ghost.global_position = pos - ghost.size / 2.0
	_drag_ghost = ghost
	_drag_last_x = pos.x
	# Sombra por baixo da carta levantada (fica a 12 px, como se a carta estivesse no ar).
	_drag_shadow = Panel.new()
	_drag_shadow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := StyleBoxFlat.new()
	sh.bg_color = Color(0, 0, 0, 0.35)
	sh.set_corner_radius_all(14)
	sh.shadow_color = Color(0, 0, 0, 0.45)
	sh.shadow_size = 14
	_drag_shadow.add_theme_stylebox_override("panel", sh)
	_drag_shadow.size = view.size
	add_child(_drag_shadow)
	move_child(_drag_shadow, ghost.get_index())
	_drag_shadow.global_position = ghost.global_position + Vector2(10, 14)
	Settings.vibrate(15)

func _on_board_drag_moved(card: CardInstance, pos: Vector2) -> void:
	if _drag_ghost == null:
		return
	_drag_ghost.global_position = pos - _drag_ghost.size / 2.0
	_tilt_ghost(pos)
	var index := _index_for_x(board_box, pos.x, _drag_view)
	var current := battle.board.find(card)
	if index != current and index >= 0:
		battle.move_creature(card, index)
		board_box.move_child(_drag_view, index)
		_refresh_preview()

func _on_board_drag_ended(_card: CardInstance, _pos: Vector2) -> void:
	if _drag_ghost != null:
		_drag_ghost.queue_free()
		_drag_ghost = null
	if _alive(_drag_shadow):
		_drag_shadow.queue_free()
	_drag_shadow = null
	if _alive(_drag_view):
		_drag_view.modulate.a = 1.0
		_bump(_drag_view, 1.08)
	_drag_view = null
	Sfx.select()
	_refresh_preview()

func _on_relic_drag_started(id: String, pos: Vector2) -> void:
	if battle.resolving or battle.finished or _drag_ghost != null:
		return
	var view: Control = _relic_views.get(id)
	if not _alive(view):
		return
	_drag_view = view
	view.modulate.a = 0.35
	var ghost: RelicView = RELIC_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(id)
	ghost.set_width(view.size.x)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = view.size
	ghost.global_position = pos - ghost.size / 2.0
	_drag_ghost = ghost

func _on_relic_drag_moved(id: String, pos: Vector2) -> void:
	if _drag_ghost == null:
		return
	_drag_ghost.global_position = pos - _drag_ghost.size / 2.0
	var index := mini(_index_for_x(relics_bar, pos.x, _drag_view), GameState.relic_ids.size() - 1)
	var current := GameState.relic_ids.find(id)
	if index != current and index >= 0:
		GameState.relic_ids.erase(id)
		GameState.relic_ids.insert(clampi(index, 0, GameState.relic_ids.size()), id)
		relics_bar.move_child(_drag_view, index)
		_refresh_preview()

func _on_relic_drag_ended(_id: String, _pos: Vector2) -> void:
	_on_board_drag_ended(null, Vector2.ZERO)
	GameState.save_run(battle.to_dict(), "battle")

## Posição (índice) em que um item arrastado deve ficar numa fila horizontal, pela coordenada x.
func _index_for_x(box: Control, x: float, dragged: Control) -> int:
	var live := box.get_children().filter(func(c): return not c.is_queued_for_deletion())
	var index := 0
	for c in live:
		if c == dragged:
			continue
		var center: float = c.global_position.x + c.size.x / 2.0
		if x > center:
			index += 1
	return index

# --- Pausa ---

func _open_pause() -> void:
	if battle.finished or SceneRouter.has_overlay() or (_pause_menu != null and is_instance_valid(_pause_menu)):
		return
	Sfx.select()
	_pause_menu = PauseMenu.open(_pause_info(), _replay_last_attack if _last_cascade != null and not _last_cascade.is_empty() else Callable())
	_pause_menu.abandoned.connect(_on_abandon)

func _pause_info() -> String:
	if GameState.puzzle_id == "training":
		return tr("Treino")
	if GameState.is_lesson_battle():
		return tr("Escola do Mago") + "  ·  " + tr(String(_lesson_def.get("name", "")))
	if battle.puzzle:
		return tr("Quebra-cabeças") + "  ·  " + tr(String(CardDB.get_puzzle(GameState.puzzle_id).get("name", "")))
	var info := "%s  ·  %s  ·  %s  ·  %s" % [
		tr(GameState.deck_def.get("name", "")),
		_turn_text().replace("\n", "  ·  "),
		tr("Selo %d") % GameState.stake if GameState.stake > 1 else tr("Selo 1"),
		tr("Seed %d") % GameState.seed_value,
	]
	if battle.climate != "":
		info += "  ·  " + tr(battle.climate_name())
	# 0.13.0: onde fica gravado (sozinho, no início de cada turno).
	info += "\n" + tr("Gravado sozinho em «%s» no início de cada turno.") % GameState.slot_name(GameState.current_slot)
	return info

func _on_abandon() -> void:
	if GameState.puzzle_id == "training":
		GameState.puzzle_id = ""
		SceneRouter.go("training")
		return
	if GameState.is_lesson_battle():
		GameState.puzzle_id = ""
		SceneRouter.go("school")
		return
	if battle.puzzle:
		GameState.puzzle_id = ""
		SceneRouter.go("puzzles")
		return
	GameState.abandon_run()
	SceneRouter.go("main")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		if _alive(_modal):
			if _modal.name == "PuzzleResult":   # 0.13.0: no fim do enigma, retroceder volta à lista
				GameState.puzzle_id = ""
				SceneRouter.go("puzzles")
				return
			_close_modal("")
			return
		_open_pause()
	elif what == NOTIFICATION_EXIT_TREE:
		Settings.set_battle_screen_on(false)
		CardView.fog_hand = false

# --- Cascata ---

## Tocar no ecrã durante a cascata salta a animação e mostra logo o total.
func _input(event: InputEvent) -> void:
	if _animating and not _skip_cascade and event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_skip_cascade = true
		get_viewport().set_input_as_handled()   # o toque só salta; não abre cartas nem a pausa
		return
	# 0.12.1: tocar fora da mão larga a carta escolhida.
	if _selected_uid >= 0 and event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if not _hand_card_at((event as InputEventMouseButton).position):
			_set_selection(-1)

func _on_cascade_started(cascade: Cascade) -> void:
	EventBus.cascade_presented.emit(cascade)   # 0.13.0: a música cresce durante o ataque
	_set_selection(-1)
	_animating = true
	_last_attack_turn = battle.turn
	_set_attack_glow(false)
	if _overlay != null:
		_overlay.clear()
	_skip_cascade = false
	_last_cascade = cascade
	if cascade.steps.size() >= 8:
		_tip("skip")
	end_turn_btn.disabled = true
	undo_btn.disabled = true
	enemy_hp_bar.value = enemy_hp_ghost.value   # durante a cascata a barra mostra a vida real
	for v in _hand_views.values():
		if _alive(v):
			v.delta = 0
	formation_label.text = tr("Ataque")
	power_label.text = "0"
	mult_label.text = "1"
	total_label.text = ""
	var shown_formations: Array[String] = []
	var i := 0
	var speed := Settings.anim_scale()
	for s in cascade.steps:
		if _skip_cascade:
			break
		var target := _view_for_step(s)
		var color := _color_for_step(s)
		if s.source_kind == "formation" and not s.retrigger:
			shown_formations.append(tr(s.source_name) + ((" (%s %d)" % [tr("nv"), s.level]) if s.level > 0 else ""))
			formation_label.text = " · ".join(PackedStringArray(shown_formations))
		if s.source_kind == "creature" and s.action == "power_add" and s.tag != "minion":
			_lunge(target)
		var prefix := "↻ " if s.retrigger else ""
		if s.tag == "seal":
			prefix = "◉ "
		elif s.tag == "edition" and EffectResolver.EDITIONS.has(s.source_id):
			prefix = String(EffectResolver.EDITIONS[s.source_id]["symbol"]) + " "
		elif s.tag == "minion":
			prefix = "◈ "
		elif s.source_kind == "planeswalker":
			prefix = "✦ "
		elif s.source_kind == "chain":
			prefix = "⚭ "
		_pop(target, prefix + s.label, color)
		if s.source_card != null and s.tag != "minion" and _alive(target):
			ColorBurst.spawn(self, target.global_position + target.size / 2.0, s.source_card.data.primary_color())
		power_label.text = Cascade.fmt_int(s.power_after)
		mult_label.text = Cascade.fmt_mult(s.mult_after)
		_fire_target = _fire_for(s.power_after * s.mult_after)
		_bump(power_pill if s.action == "power_add" else mult_pill)
		Sfx.cascade_step(i, s.source_kind)
		if speed > 0.0:
			await get_tree().create_timer(maxf(0.09, 0.28 - i * 0.012) * speed).timeout
		elif i % 4 == 3:
			await get_tree().process_frame
		i += 1
	if _skip_cascade:
		# Saltou: mostra já os números finais.
		power_label.text = Cascade.fmt_int(cascade.power)
		mult_label.text = Cascade.fmt_mult(cascade.mult)
		if not cascade.formation_ids.is_empty():
			var names: Array[String] = []
			for f in cascade.formations:
				names.append(tr(f))
			formation_label.text = " · ".join(PackedStringArray(names))
	# Escudo do inimigo: trava os primeiros X do ataque.
	if cascade.shield > 0 and cascade.total() > 0:
		_pop(enemy_panel, "◈ " + tr("Escudo −%s") % Cascade.fmt_int(mini(cascade.shield, cascade.total())), Color(0.6, 0.8, 1.0))
	# O total conta a subir (cada vez mais depressa) e treme mais quanto mais perto do fim.
	var total := cascade.net_total()
	# 0.12.0: recorde (maior golpe de sempre) — a contagem abranda e no fim há um ecrã especial.
	var old_record := Stats.get_stat("best_attack")
	var record := not battle.puzzle and old_record > 0 and total > old_record
	var tick_time := 0.032 * (2.4 if record and Settings.motion_ok() else 1.0)
	if speed > 0.0 and total > 0 and not _skip_cascade:
		var ticks := 14
		total_label.pivot_offset = total_label.size / 2.0
		for k in range(1, ticks + 1):
			var t := float(k) / ticks
			_set_total(Cascade.fmt_int(int(round(total * t * t))))
			total_label.rotation = randf_range(-1.0, 1.0) * 0.07 * t
			total_label.scale = Vector2.ONE * (1.0 + 0.3 * t)
			Sfx.blip(mini(30, i + k))
			await get_tree().create_timer(tick_time * speed).timeout
			if _skip_cascade:
				break
		total_label.rotation = 0.0
		total_label.scale = Vector2.ONE
	_set_total(Cascade.fmt_int(total))
	_bump(total_label, 1.5)
	_particles.global_position = total_label.global_position + total_label.size / 2.0
	_particles.restart()
	if not _skip_cascade and total > 0:
		_attack_trails()
	AttackFx.spawn(self, total_label.global_position + total_label.size / 2.0, Settings.attack_fx)
	Sfx.boom()
	Settings.vibrate(50)
	_fire_target = _fire_for(cascade.net_total())
	_shake(6.0 + 10.0 * _fire_target)
	if record:
		await _celebrate_record(total, old_record)
	await get_tree().create_timer(_d(0.25 if _skip_cascade else 0.5)).timeout
	_animating = false
	_skip_cascade = false
	EventBus.cascade_finished.emit()

func _view_for_step(s: Cascade.Step) -> Control:
	match s.source_kind:
		"creature":
			if s.source_card != null and _board_views.has(s.source_card.uid):
				return _board_views[s.source_card.uid]
		"spell":
			if s.source_card != null and _spell_chips.has(s.source_card.uid):
				return _spell_chips[s.source_card.uid]
		"hand":
			if s.source_card != null and _hand_views.has(s.source_card.uid):
				return _hand_views[s.source_card.uid]
		"relic":
			if _relic_views.has(s.source_id):
				return _relic_views[s.source_id]
		"planeswalker":
			return _pw_panel if _alive(_pw_panel) else pw_row
		"climate":
			if s.source_card != null and _board_views.has(s.source_card.uid):
				return _board_views[s.source_card.uid]
			if _alive(_climate_chip):
				return _climate_chip
		"enchantment":
			if s.source_card != null and _ench_chips.has(s.source_card.uid) and _alive(_ench_chips[s.source_card.uid]):
				return _ench_chips[s.source_card.uid]
		"chain":
			if _alive(_chain_meter):
				return _chain_meter
		"rule":
			if s.source_card != null and _board_views.has(s.source_card.uid):
				return _board_views[s.source_card.uid]
	return formation_label

func _color_for_step(s: Cascade.Step) -> Color:
	if s.grow > 0:
		return COLOR_GROW
	if s.tag == "seal":
		return COLOR_SEAL
	if s.tag == "edition":
		return EffectResolver.edition_color(s.source_id)
	if s.source_kind == "climate" and s.action != "gold":
		return COLOR_CLIMATE
	if s.source_kind == "relic" and GameState.boss_relics.has(s.source_id):
		return COLOR_BOSS_RELIC
	if s.source_kind == "formation" or s.source_kind == "planeswalker":
		return COLOR_FORMATION
	if s.source_kind == "tribe":
		return COLOR_TRIBE
	if s.source_kind == "chain":
		return COLOR_CHAIN
	if s.source_kind == "enchantment":
		return COLOR_ENCHANT
	if s.source_kind == "seal_set":
		return COLOR_SEAL
	match s.action:
		"power_add":
			return COLOR_POWER
		"mult_mul":
			return COLOR_MULT_X
		"gold":
			return COLOR_GOLD
	return COLOR_MULT

# --- Animações ---

func _alive(view) -> bool:
	return view != null and is_instance_valid(view) and not view.is_queued_for_deletion()

## Mata o tween guardado em meta (se existir) para nunca haver dois a disputar a mesma propriedade.
func _kill_tween(view: Object, key: String) -> void:
	if view.has_meta(key):
		var old = view.get_meta(key)
		if old is Tween and (old as Tween).is_valid():
			(old as Tween).kill()

## Pop da vista + etiqueta a flutuar por cima dela.
func _pop(view: Control, text: String, color: Color) -> void:
	if not _alive(view):
		return
	_bump(view, 1.22)
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", 26)
	label.add_theme_color_override("font_color", Color.WHITE)
	label.add_theme_color_override("font_outline_color", color.darkened(0.35))
	label.add_theme_constant_override("outline_size", 8)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(label)
	label.reset_size()
	var start := view.global_position + Vector2(view.size.x * 0.5 - label.size.x * 0.5, -label.size.y * 0.6)
	label.global_position = start
	var tw := create_tween().set_parallel(true)
	tw.tween_property(label, "global_position:y", start.y - 46.0, _d(0.6)).set_ease(Tween.EASE_OUT)
	tw.tween_property(label, "modulate:a", 0.0, _d(0.6)).set_delay(_d(0.25))
	tw.chain().tween_callback(label.queue_free)

## Escala rápida e volta a 1. Mata o bump anterior da mesma vista para nunca ficar a meio.
func _bump(view: Control, amount: float = 1.18) -> void:
	if not _alive(view):
		return
	view.pivot_offset = view.size / 2.0
	_kill_tween(view, "bump_tw")
	view.scale = Vector2.ONE
	var tw := create_tween()
	tw.tween_property(view, "scale", Vector2.ONE * amount, _d(0.07))
	tw.tween_property(view, "scale", Vector2.ONE, _d(0.13)).set_ease(Tween.EASE_OUT)
	view.set_meta("bump_tw", tw)

## Investida: a criatura inclina-se e salta para a frente (rotação + escala, não mexe no layout).
func _lunge(view: Control) -> void:
	if not _alive(view):
		return
	view.pivot_offset = view.size / 2.0
	_kill_tween(view, "lunge_tw")
	view.rotation = 0.0
	var tw := create_tween()
	tw.tween_property(view, "rotation", -0.16, _d(0.06))
	tw.tween_property(view, "rotation", 0.0, _d(0.16)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	view.set_meta("lunge_tw", tw)

func _flash(view: Control, color: Color) -> void:
	if not _alive(view) or Settings.reduce_motion:
		return
	_kill_tween(view, "flash_tw")
	var base := Color.WHITE
	if view in _hand_views.values() and _discard_mode:
		base = DISCARD_TINT
	view.modulate = color
	var tw := create_tween()
	tw.tween_property(view, "modulate", base, _d(0.35))
	view.set_meta("flash_tw", tw)

func _shake(strength: float) -> void:
	if not Settings.motion_ok():
		return
	var tw := create_tween()
	for i in 5:
		var off := Vector2(randf_range(-strength, strength), randf_range(-strength, strength)) * (1.0 - i / 5.0)
		tw.tween_property(layout, "position", _layout_base + off, 0.03)
	tw.tween_property(layout, "position", _layout_base, 0.04)

## Carta nova na mão: entra de baixo, a crescer.
func _animate_draw(view: CardView, delay: float) -> void:
	var target_alpha := view.modulate.a
	view.modulate.a = 0.0
	view.scale = Vector2(0.7, 0.7)
	await get_tree().process_frame
	if not _alive(view):
		return
	view.pivot_offset = view.size / 2.0
	var tw := create_tween().set_parallel(true)
	tw.tween_property(view, "modulate:a", target_alpha, _d(0.18)).set_delay(_d(delay))
	tw.tween_property(view, "scale", Vector2.ONE, _d(0.22)).set_delay(_d(delay)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)

## Carta jogada: um "fantasma" voa da posição na mão até ao sítio novo (tabuleiro, feitiços ou mana).
func _animate_play(card: CardInstance, from_rect: Rect2) -> void:
	if from_rect.size == Vector2.ZERO or Settings.anim_scale() <= 0.0:
		return
	await get_tree().process_frame   # deixa o layout colocar a vista nova
	var target: Control = null
	if card.data.is_creature():
		target = _board_views.get(card.uid)
	elif card.data.is_spell():
		target = _spell_chips.get(card.uid)
	elif card.data.is_enchantment():
		target = _ench_chips.get(card.uid)
	else:
		target = mana_label
	if not _alive(target):
		return
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = from_rect.size
	ghost.global_position = from_rect.position
	ghost.pivot_offset = ghost.size / 2.0
	var real_target := target
	if card.data.is_creature():
		real_target.modulate.a = 0.0
	var dest := target.global_position + (target.size - ghost.size) / 2.0
	var end_scale := Vector2.ONE if card.data.is_creature() else Vector2(0.35, 0.35)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(ghost, "global_position", dest, _d(0.24)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
	tw.tween_property(ghost, "scale", end_scale, _d(0.24)).set_ease(Tween.EASE_IN)
	tw.tween_property(ghost, "rotation", 0.08, _d(0.12))
	await tw.finished
	if _alive(real_target):
		real_target.modulate.a = 1.0
		_bump(real_target, 1.12)
		if not card.data.is_creature():
			_flash(real_target, Color(1.8, 1.8, 1.8))
	if _alive(ghost):
		ghost.queue_free()
	Sfx.blip(0)

## Criatura morre (0.13.0): a carta desfaz-se em pó da cor dela, de cima para baixo (sem movimento: só
## desvanece).
func _animate_death(view: Control) -> void:
	if not _alive(view) or Settings.anim_scale() <= 0.0:
		return
	var card: CardInstance = (view as CardView).card
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = view.size
	ghost.global_position = view.global_position
	ghost.pivot_offset = ghost.size / 2.0
	ghost.modulate = Color(1.0, 0.6, 0.55)
	var rect := Rect2(view.global_position, view.size)
	if Settings.motion_ok():
		DustFx.spawn(self, rect, CardView.COLORS.get(card.data.primary_color(), CardView.COLORS.colorless))
	var tw := create_tween().set_parallel(true)
	tw.tween_property(ghost, "modulate:a", 0.0, _d(0.45)).set_ease(Tween.EASE_IN)
	if Settings.motion_ok():
		tw.tween_property(ghost, "scale", Vector2(1.04, 0.9), _d(0.45))
		tw.tween_property(ghost, "global_position:y", ghost.global_position.y - 8.0, _d(0.45))
	tw.chain().tween_callback(ghost.queue_free)

## O inimigo encaixa o golpe: flash vermelho, abanão e o número de dano a voar do total até ele.
func _animate_enemy_hit(amount: int) -> void:
	_flash(enemy_panel, Color(2.0, 0.7, 0.7))
	_bump(enemy_panel, 0.94)
	var label := Label.new()
	label.text = "-" + Cascade.fmt_int(amount)
	label.add_theme_font_size_override("font_size", 44)
	label.add_theme_color_override("font_color", Color(1, 0.92, 0.6))
	label.add_theme_color_override("font_outline_color", Color(0.4, 0.1, 0.1))
	label.add_theme_constant_override("outline_size", 10)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(label)
	label.reset_size()
	label.global_position = total_label.global_position
	var dest := enemy_panel.global_position + Vector2(enemy_panel.size.x * 0.5 - label.size.x * 0.5, 40.0)
	var tw := create_tween()
	tw.tween_property(label, "global_position", dest, _d(0.35)).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
	tw.tween_callback(func(): _flash(enemy_hp_bar, Color(2.5, 1.5, 1.5)))
	tw.tween_property(label, "modulate:a", 0.0, _d(0.4))
	tw.tween_callback(label.queue_free)

## O inimigo contra-ataca: salta para a direita (rotação) e o ecrã abana.
## 0.12.0: as bordas do ecrã ficam vermelhas e três garras riscam-no (mais forte quanto maior o dano).
func _animate_enemy_strike(amount: int = 0) -> void:
	if not _alive(enemy_panel):
		return
	enemy_panel.pivot_offset = enemy_panel.size / 2.0
	var tw := create_tween()
	tw.tween_property(enemy_panel, "rotation", 0.06, _d(0.07))
	tw.tween_property(enemy_panel, "rotation", 0.0, _d(0.2)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	_flash(enemy_panel, Color(1.4, 1.4, 1.4))
	if amount > 0:
		DamageVignette.flash(self, float(amount) / maxf(1.0, float(GameState.player_max_hp)) * 3.0)

## Golpe final (0.12.0): cada criatura na Arena lança um cometa da sua cor ao inimigo.
func _attack_trails() -> void:
	if not _alive(enemy_panel):
		return
	var target := enemy_panel.global_position + enemy_panel.size * Vector2(0.5, 0.45)
	if _portrait != null and _alive(_portrait):
		target = _portrait.global_position + _portrait.size / 2.0
	var i := 0
	for c in battle.board:
		var view: Control = _board_views.get(c.uid)
		if not _alive(view):
			continue
		AttackTrail.fly(self, view.global_position + view.size / 2.0, target, c.data.primary_color(), i * 0.045)
		i += 1
		if i >= 8:
			break

## Banner central (ANTE N / TURNO N / VITÓRIA).
## minor = true (o "TURNO N"): não tapa um banner importante que ainda esteja no ecrã
## (despertar do boss, Coração de Vidro…).
func _show_banner(text: String, hold: float = 1.1, minor: bool = false) -> void:
	var now := Time.get_ticks_msec()
	if minor and now < _banner_lock_until:
		return
	if not minor:
		_banner_lock_until = now + int((hold + _d(0.5)) * 1000.0)
	if _banner_tw != null and _banner_tw.is_valid():
		_banner_tw.kill()
	banner.text = text
	banner.visible = true
	banner.pivot_offset = banner.size / 2.0
	banner.scale = Vector2(0.6, 0.6)
	banner.modulate.a = 0.0
	var tw := create_tween()
	_banner_tw = tw
	tw.set_parallel(true)
	tw.tween_property(banner, "scale", Vector2.ONE, _d(0.3)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tw.tween_property(banner, "modulate:a", 1.0, _d(0.2))
	tw.chain().tween_interval(maxf(0.05, hold))   # 0.12.1: o tempo para ler não acelera com a velocidade
	tw.chain().tween_property(banner, "modulate:a", 0.0, _d(0.3))
	tw.chain().tween_callback(func(): banner.visible = false)

func _log(msg: String) -> void:
	_last_log = msg
	_sel_hint = false
	_history.append(("T%d  " % battle.turn if battle.turn > 0 else "") + msg)
	if _history.size() > HISTORY_MAX:
		_history.pop_front()
	log_label.text = msg
	log_label.modulate = Color(1, 0.85, 0.5)
	create_tween().tween_property(log_label, "modulate", Color.WHITE, 0.8)

# ---------------------------------------------------------------------------
# 0.10.0 — widgets novos
# ---------------------------------------------------------------------------

func _make_010_widgets() -> void:
	# Modo compacto: o tabuleiro encolhe com as cartas (sobra altura para ecrãs pequenos).
	if Settings.compact:
		(board_box.get_parent() as Control).custom_minimum_size.y = CardView.SIZE_COMPACT.y + 4
	# Fundo do ato (com as partículas do clima) por cima do fundo liso.
	var bg: Control = get_node("Background")
	_backdrop = BattleBackdrop.new()
	add_child(_backdrop)
	move_child(_backdrop, bg.get_index() + 1)
	# Retrato do inimigo no lugar do emblema com a inicial.
	emblem.visible = false
	_portrait = EnemyPortrait.new()
	_portrait.custom_minimum_size = Vector2(60, 60)
	_portrait.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var name_row: Control = emblem.get_parent()
	name_row.add_child(_portrait)
	name_row.move_child(_portrait, 0)
	# Turnos em pips no lugar das duas linhas de texto (o resto está na pausa).
	turn_label.visible = false
	_turn_pips = TurnPips.new()
	_turn_pips.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var top: Control = turn_label.get_parent()
	top.add_child(_turn_pips)
	top.move_child(_turn_pips, turn_label.get_index())
	# Encantamentos em jogo: à esquerda na faixa dos feitiços; o medidor da Cadeia à direita.
	_ench_box = HBoxContainer.new()
	_ench_box.add_theme_constant_override("separation", 6)
	spell_strip.add_child(_ench_box)
	spell_strip.move_child(_ench_box, 0)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	spell_strip.add_child(spacer)
	_chain_meter = ChainMeter.new()
	_chain_meter.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_chain_meter.tooltip_text = tr("Cadeia de cor")
	spell_strip.add_child(_chain_meter)
	# Escudo e lacaios do inimigo: por baixo da barra de vida.
	_defense_row = HBoxContainer.new()
	_defense_row.add_theme_constant_override("separation", 6)
	var vbox: Control = enemy_hp_label.get_parent()
	vbox.add_child(_defense_row)
	vbox.move_child(_defense_row, enemy_hp_label.get_index() + 1)
	# Histórico: tocar na linha de log mostra as últimas 30 ações.
	log_label.mouse_filter = Control.MOUSE_FILTER_STOP
	log_label.tooltip_text = tr("Toca para ver o histórico")
	log_label.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed:
			_open_history())

func _setup_backdrop() -> void:
	if _backdrop != null:
		_backdrop.setup(GameState.act_of_ante(GameState.ante) if not battle.puzzle else 1, battle.climate)

## Arquétipo do retrato: o do inimigo (enemies.json "portrait"); bonecos de treino e enigmas.
func _portrait_archetype() -> String:
	var a := String(battle.enemy.get("portrait", ""))
	if a != "":
		return a
	if battle.puzzle:
		return "dummy"
	var def := CardDB.enemy_def(String(battle.enemy.get("id", "")))
	return String(def.get("portrait", "brute"))

func _refresh_pips() -> void:
	if _turn_pips != null:
		_turn_pips.set_turns(battle.turn, battle.max_turns, battle.extra_turns)

func _refresh_chain_meter() -> void:
	if _chain_meter == null:
		return
	var info := EffectResolver.chain_of(battle.attackers())
	_last_preview_chain = int(info["len"])
	_chain_meter.set_chain(int(info["len"]), String(info["color"]), EffectResolver.chain_needed(), battle.max_creatures())
	_chain_meter.visible = not battle.board.is_empty()

## Escudo (% da vida máxima travada por ataque) e lacaios (●● = golpes que ainda aguentam).
func _refresh_defense() -> void:
	if _defense_row == null:
		return
	for c in _defense_row.get_children():
		_defense_row.remove_child(c)
		c.queue_free()
	var pct := float(battle.enemy.get("shield_pct", 0))
	if pct > 0.0:
		_defense_row.add_child(_intent_chip([["shield", Color(0.6, 0.8, 1.0), tr("Escudo %d%%") % int(pct)]], Color(0.14, 0.2, 0.32)))
	if not battle.minions.is_empty():
		var dots := ""
		for h in battle.minions:
			dots += "●".repeat(h) + " "
		_defense_row.add_child(_intent_chip([["creature", Color(0.9, 0.75, 0.55), tr("Lacaios") + " " + dots.strip_edges()]], Color(0.26, 0.18, 0.12)))
	_defense_row.visible = _defense_row.get_child_count() > 0
	_defense_row.mouse_filter = Control.MOUSE_FILTER_STOP
	if _defense_row.visible and not _defense_row.gui_input.is_connected(_on_defense_tap):
		_defense_row.gui_input.connect(_on_defense_tap)

func _on_defense_tap(ev: InputEvent) -> void:
	if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed and not SceneRouter.has_overlay():
		Sfx.select()
		var lines: Array[String] = []
		if float(battle.enemy.get("shield_pct", 0)) > 0.0:
			lines.append(tr("Escudo: trava os primeiros %s de cada ataque (volta a encher todos os turnos).") % Cascade.fmt_int(battle.shield_amount()))
		if not battle.minions.is_empty():
			lines.append(tr("Lacaios: cada um trava o Poder base de uma das primeiras criaturas da Arena (as habilidades disparam na mesma) e cai ao fim de 2 bloqueios. Põe as criaturas fracas à frente."))
		CardZoom.show_text(tr(battle.enemy.name), "\n\n".join(PackedStringArray(lines)), tr("Defesas do inimigo"), Color(0.6, 0.8, 1.0))

## Encantamentos em jogo: fichas na faixa dos feitiços (tocar abre a carta).
func _refresh_enchantments() -> void:
	if _ench_box == null:
		return
	for c in _ench_box.get_children():
		_ench_box.remove_child(c)
		c.queue_free()
	_ench_chips.clear()
	for en in battle.enchantments:
		var chip := _make_chip(en, "✧ " + en.data.display_name())
		var style: StyleBoxFlat = chip.get_theme_stylebox("panel").duplicate()
		style.set_border_width_all(2)
		style.border_color = COLOR_ENCHANT
		chip.add_theme_stylebox_override("panel", style)
		chip.mouse_filter = Control.MOUSE_FILTER_STOP
		chip.gui_input.connect(func(ev: InputEvent):
			if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed and not SceneRouter.has_overlay():
				Sfx.select()
				CardZoom.show_card(en))
		_ench_box.add_child(chip)
		_ench_chips[en.uid] = chip
	if spell_hint != null:
		spell_hint.visible = battle.spells_this_turn.is_empty() and battle.enchantments.is_empty()
	_fit_chips()

func _open_history() -> void:
	if SceneRouter.has_overlay() or _history.is_empty():
		return
	Sfx.select()
	var lines := _history.duplicate()
	lines.reverse()
	CardZoom.show_text(tr("Histórico da batalha"), "\n".join(PackedStringArray(lines)), tr("Últimas %d ações (a mais recente em cima)") % lines.size(), UiKit.TEXT_DIM)

## Inclina a carta arrastada para o lado para onde o dedo a puxa (e a sombra acompanha).
func _tilt_ghost(pos: Vector2) -> void:
	var vx := pos.x - _drag_last_x
	_drag_last_x = pos.x
	if Settings.motion_ok():
		_drag_ghost.rotation = lerpf(_drag_ghost.rotation, clampf(vx * 0.012, -0.28, 0.28), 0.35)
	if _alive(_drag_shadow):
		_drag_shadow.global_position = _drag_ghost.global_position + Vector2(10, 14)
		_drag_shadow.rotation = _drag_ghost.rotation
		_drag_shadow.pivot_offset = _drag_shadow.size / 2.0

# --- Fichas, encantamentos, Reforço, Reação, escudo ---

func _on_token_created(card: CardInstance) -> void:
	_log(tr("Uma Ficha de %s entra na Arena.") % card.data.display_name())
	if not _animating:
		_refresh_board()
		_refresh_preview()

func _on_enchantment_played(card: CardInstance) -> void:
	_log(tr("%s fica em jogo.") % card.data.display_name())
	_refresh_enchantments()

func _on_card_kicked(card: CardInstance) -> void:
	_log(tr("%s com Reforço!") % card.data.display_name())

func _on_shield_hit(_amount: int) -> void:
	pass   # o número aparece na cascata (antes do total)

func _on_reaction_played(card: CardInstance) -> void:
	Sfx.boom()
	Settings.vibrate(40)
	_show_banner(tr("REAÇÃO") + "\n" + card.data.display_name(), 0.9)
	_log(tr("Reagiste com %s.") % card.data.display_name())
	_refresh_all()

## O inimigo vai contra-atacar e tens uma Mágica com Reação que podes pagar: reages ou não.
func _on_reaction_window(options: Array) -> void:
	var dmg := battle.enemy_attack()
	var box := _open_modal(tr("REAÇÃO"), tr("%s vai atacar com %d. Reages com a mana que sobrou (%d)?") % [tr(battle.enemy.name), dmg, battle.mana_available])
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	for c in options:
		var v: CardView = CARD_VIEW.instantiate()
		row.add_child(v)
		v.setup(c)
		v.pressed.connect(func(card: CardInstance): _close_modal(card))
		v.long_pressed.connect(func(card: CardInstance): CardZoom.show_card(card))
	var skip := UiKit.button(tr("NÃO REAGIR"), 54, 20)
	skip.custom_minimum_size.x = 260
	skip.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	skip.pressed.connect(func(): _close_modal(null))
	box.add_child(skip)
	_modal.set_meta("reaction", true)
	Sfx.select()

## Reforço: jogar normal ou pagar mais mana pelo efeito extra. Devolve "plain", "kick" ou "" (cancelar).
func _ask_kicker(card: CardInstance) -> String:
	var base := battle.effects.cost_of(card)
	var extra := battle.kicker_cost(card)
	var box := _open_modal(card.data.display_name(), tr("Reforço: %s.") % card.data.display_kicker_text())
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 14)
	box.add_child(row)
	var plain := UiKit.button(tr("JOGAR (%d)") % base, 58, 20)
	plain.custom_minimum_size.x = 220
	plain.pressed.connect(func(): _close_modal("plain"))
	row.add_child(plain)
	var kick := UiKit.button(tr("COM REFORÇO (%d)") % (base + extra), 58, 20, Color(0.45, 0.32, 0.12), UiKit.GOLD)
	kick.custom_minimum_size.x = 260
	kick.pressed.connect(func(): _close_modal("kick"))
	row.add_child(kick)
	var gain_plain := battle.preview_play(card)
	var gain_kick := battle.preview_play(card, true)
	if gain_kick != gain_plain:
		var hint := UiKit.label(tr("Ataque: +%s normal · +%s com Reforço") % [Cascade.fmt_int(gain_plain), Cascade.fmt_int(gain_kick)], 17, UiKit.TEXT_DIM)
		hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(hint)
	var res = await _modal_result()
	return String(res) if res is String else ""

## Aviso com "não avisar mais". Devolve "yes", "no" ou "never".
func _ask(title: String, body: String, yes_text: String) -> String:
	var box := _open_modal(title, body)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	var yes := UiKit.button(yes_text, 56, 20, UiKit.PRIMARY.darkened(0.2), UiKit.PRIMARY)
	yes.custom_minimum_size.x = 200
	yes.pressed.connect(func(): _close_modal("yes"))
	row.add_child(yes)
	var no := UiKit.button(tr("VOLTAR"), 56, 20)
	no.custom_minimum_size.x = 160
	no.pressed.connect(func(): _close_modal("no"))
	row.add_child(no)
	var never := UiKit.button(tr("NÃO AVISAR MAIS"), 48, 16)
	never.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	never.custom_minimum_size.x = 240
	never.pressed.connect(func(): _close_modal("never"))
	box.add_child(never)
	var res = await _modal_result()
	return String(res) if res is String else "no"

## Janela modal da batalha (por cima do layout; o botão "retroceder" fecha-a como "não").
func _open_modal(title: String, body: String) -> VBoxContainer:
	if _alive(_modal):
		_close_modal(null)
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	root.z_index = 60   # 0.13.0: por cima das setas, das etiquetas e das dicas
	root.add_child(UiKit.dim(0.6))
	add_child(root)
	_modal = root
	var panel := UiKit.centered_panel(root, 640, UiKit.BG, UiKit.GOLD)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	panel.add_child(box)
	var t := UiKit.label(title, 30, UiKit.GOLD)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(t)
	if body != "":
		var b := UiKit.label(body, 19, Color.WHITE, true)
		b.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(b)
	UiKit.pop_in(panel)
	return box

signal _modal_closed(result)

func _modal_result():
	return await _modal_closed

func _close_modal(result) -> void:
	if not _alive(_modal):
		return
	var was_reaction := bool(_modal.get_meta("reaction", false))
	_modal.queue_free()
	_modal = null
	Sfx.select()
	if was_reaction:
		EventBus.reaction_done.emit(result if result is CardInstance else null)
	else:
		_modal_closed.emit(result)

# --- Escola do Mago (0.11.0) ---

var _lesson_def: Dictionary = {}
var _lesson_reacted := false
var _lesson_panel: Control

func _on_lesson_reaction(_card: CardInstance) -> void:
	_lesson_reacted = true

## Explicação da lição por cima da batalha (fica até a fecharem).
func _show_lesson_panel(def: Dictionary) -> void:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.12, 0.1, 0.2, 0.96), 12, Color(0.5, 0.85, 0.55), 2, 12))
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	panel.z_index = 40
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(row)
	var col := VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_theme_constant_override("separation", 4)
	row.add_child(col)
	col.add_child(UiKit.label(tr("LIÇÃO · %s") % tr(String(def.get("name", ""))), 17, Color(0.6, 0.95, 0.65)))
	var intro := UiKit.label(tr(String(def.get("intro", ""))), 16, Color.WHITE, true)
	intro.custom_minimum_size.x = 600
	col.add_child(intro)
	col.add_child(UiKit.label(tr("Objetivo: %s") % tr(String(def.get("goal", ""))), 16, UiKit.GOLD, true))
	var x := UiKit.label("✕", 18, UiKit.TEXT_DIM)
	x.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	row.add_child(x)
	panel.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.pressed and is_instance_valid(panel):
			panel.queue_free())
	add_child(panel)
	_lesson_panel = panel
	await get_tree().process_frame
	if is_instance_valid(panel):
		panel.position = Vector2((get_viewport_rect().size.x - panel.size.x) / 2.0, 66.0)

## Fim da lição: concluída (próxima lição ou voltar à Escola) ou falhada (repetir).
func _lesson_result(ok: bool) -> void:
	await get_tree().create_timer(_d(0.6)).timeout
	if not is_inside_tree():
		return
	if is_instance_valid(_lesson_panel):
		_lesson_panel.queue_free()
	var id := GameState.puzzle_id
	var next_id := ""
	var idx := -1
	for i in CardDB.lessons.size():
		if String(CardDB.lessons[i].get("id", "")) == id:
			idx = i
	if idx >= 0 and idx + 1 < CardDB.lessons.size():
		next_id = String(CardDB.lessons[idx + 1].get("id", ""))
	if ok:
		GameState.mark_lesson_done(id)
		Sfx.boom()
	var box := _open_modal(tr("LIÇÃO CONCLUÍDA!") if ok else tr("QUASE!"), tr(String(_lesson_def.get("name", ""))) + "\n" + (tr("Muito bem.") if ok else tr("Objetivo: %s") % tr(String(_lesson_def.get("goal", "")))))
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	var options: Array = []
	if ok and next_id != "":
		options.append(["PRÓXIMA LIÇÃO", next_id])
	if not ok:
		options.append(["REPETIR", id])
	options.append(["ESCOLA", ""])
	for opt in options:
		var target := String(opt[1])
		var b := UiKit.button(tr(String(opt[0])), 56, 20, UiKit.PRIMARY.darkened(0.2) if target != "" else UiKit.BG_LIGHT, Color(0, 0, 0, 0))
		b.custom_minimum_size.x = 210
		b.pressed.connect(func():
			Sfx.select()
			if target != "":
				GameState.start_lesson(target)
				SceneRouter.go("battle")
			else:
				GameState.puzzle_id = ""
				SceneRouter.go("school"))
		row.add_child(b)

## Fim do turno de Treino: o dano do ataque e três saídas (repetir, editar, sair).
func _training_result() -> void:
	await get_tree().create_timer(_d(0.6)).timeout
	if not is_inside_tree():
		return
	var dmg := battle.best_hit
	var box := _open_modal(tr("TREINO"), tr("Dano do ataque: %s") % Cascade.fmt_int(dmg))
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	for opt in [["REPETIR", "battle"], ["EDITAR", "training"], ["SAIR", "main"]]:
		var b := UiKit.button(tr(String(opt[0])), 56, 20, UiKit.PRIMARY.darkened(0.2) if opt[1] == "battle" else UiKit.BG_LIGHT, Color(0, 0, 0, 0))
		b.custom_minimum_size.x = 180
		var target := String(opt[1])
		b.pressed.connect(func():
			Sfx.select()
			if target == "battle":
				GameState.start_training()
			else:
				GameState.puzzle_id = ""
			SceneRouter.go(target))
		row.add_child(b)
	Sfx.boom()


# ---------------------------------------------------------------------------
# 0.12.0 — conforto na batalha: velocidade (▶▶), ordenar a mão, melhor ordem da Arena, dica de
# jogada (Fácil), grimório com probabilidades e o ecrã do novo recorde.
# ---------------------------------------------------------------------------

var _speed_btn: Button
var _sort_btn: Button
var _order_btn: Button
var _hint_btn: Button
var _hint_tw: Tween

func _make_0120_widgets() -> void:
	# Na barra de cima, ao lado dos turnos: velocidade das animações e ordem da mão.
	var top: Control = turn_label.get_parent()
	_speed_btn = UiKit.button("", 48, 16)
	_speed_btn.name = "SpeedBtn"
	_speed_btn.custom_minimum_size.x = 100
	_speed_btn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_speed_btn.pressed.connect(_on_speed)
	top.add_child(_speed_btn)
	top.move_child(_speed_btn, _turn_pips.get_index() + 1)
	_sort_btn = UiKit.button("", 48, 14)
	_sort_btn.name = "SortBtn"
	_sort_btn.custom_minimum_size.x = 118
	_sort_btn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_sort_btn.pressed.connect(_on_sort)
	top.add_child(_sort_btn)
	top.move_child(_sort_btn, _speed_btn.get_index() + 1)
	# Nas pontas da linha do cálculo: MELHOR ORDEM (à esquerda) e DICA (à direita, só no Fácil).
	var calc: HBoxContainer = power_pill.get_parent()
	var left := _calc_slot()
	calc.add_child(left)
	calc.move_child(left, 0)
	_order_btn = UiKit.button(tr("MELHOR\nORDEM"), 52, 14, UiKit.BG_LIGHT)
	_order_btn.name = "BestOrder"
	_order_btn.custom_minimum_size.x = 112
	_order_btn.pressed.connect(_on_best_order)
	left.add_child(_order_btn)
	var right := _calc_slot()
	calc.add_child(right)
	_hint_btn = UiKit.button(tr("DICA"), 52, 16, UiKit.BG_LIGHT, UiKit.GOLD)
	_hint_btn.name = "HintBtn"
	_hint_btn.custom_minimum_size.x = 112
	_hint_btn.pressed.connect(_on_hint)
	right.add_child(_hint_btn)
	banner.z_index = 5   # o letreiro (recorde, boss, turno) fica por cima das dicas
	# Cosméticos: tapete da Arena e molduras animadas (só na batalha).
	(board_box.get_parent() as Control).add_theme_stylebox_override("panel", ArenaMat.make(Settings.arena_mat))
	CardView.frame_anim_on = true
	tree_exiting.connect(func(): CardView.frame_anim_on = false)
	for n in [_speed_btn, _sort_btn, _order_btn, _hint_btn]:
		(n as Node).owner = self
		(n as Node).unique_name_in_owner = true
	_refresh_tool_buttons()

## Lugar numa ponta da linha do cálculo, com o botão ao centro (as duas pontas crescem por igual, por
## isso o cálculo fica sempre ao centro, haja botões ou não).
func _calc_slot() -> Control:
	var slot := CenterContainer.new()
	slot.custom_minimum_size = Vector2(112, 52)
	slot.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	slot.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	slot.mouse_filter = Control.MOUSE_FILTER_PASS
	return slot

const SPEED_ICONS := {"normal": "▶  1×", "fast": "▶▶  2×", "instant": "▶▶  MÁX"}

func _refresh_tool_buttons() -> void:
	if _speed_btn == null:
		return
	_speed_btn.text = tr(String(SPEED_ICONS.get(Settings.anim_speed, "▶  1×")))
	_speed_btn.add_theme_color_override("font_color", UiKit.GOLD if Settings.anim_speed != "normal" else Color.WHITE)
	_sort_btn.text = tr("ORDENAR") + "\n" + tr(String(Settings.HAND_SORT_NAMES.get(Settings.hand_sort, "Como vieram"))).to_lower()
	_order_btn.visible = battle.board.size() >= 2 and not battle.finished
	_order_btn.disabled = _animating or battle.resolving
	_hint_btn.visible = GameState.difficulty == "facil" and Settings.play_hints and not battle.puzzle and not battle.finished
	_hint_btn.disabled = _animating or battle.resolving

## ▶ → ▶▶ → ▶▶▶: a mesma velocidade das Configurações, à mão durante a batalha.
func _on_speed() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	Settings.cycle_speed()
	Settings.save_settings()
	_refresh_tool_buttons()
	SceneRouter.toast(tr("Animações: %s") % Settings.speed_label())

func _on_sort() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	Settings.cycle_hand_sort()
	_refresh_hand()
	_refresh_tool_buttons()

## Põe as criaturas na ordem que dá o maior ataque (pode desfazer-se).
func _on_best_order() -> void:
	if SceneRouter.has_overlay() or _animating or battle.resolving or battle.finished:
		return
	var r := battle.best_board_order()
	var gain := int(r["total"]) - int(r["current"])
	if gain <= 0:
		Sfx.select()
		_log(tr("A Arena já está na melhor ordem."))
		return
	_push_undo()
	if battle.apply_board_order(r["order"]):
		if not battle.puzzle:
			Stats.add("best_order_used")
		Sfx.boom()
		_refresh_board()
		_refresh_preview()
		_log(tr("Melhor ordem: +%s de dano.") % Cascade.fmt_int(gain))
		for v in _board_views.values():
			if _alive(v):
				_bump(v, 1.06)
		if not battle.puzzle:
			GameState.save_run(battle.to_dict(), "battle")

## Dica (Fácil): realça a melhor jogada agora.
func _on_hint() -> void:
	if SceneRouter.has_overlay() or _animating or battle.resolving or battle.finished:
		return
	Sfx.select()
	var h := battle.play_hint()
	if h.is_empty():
		return
	Stats.add("hints_used")
	var target: Control = null
	match String(h.get("kind", "")):
		"attack":
			target = end_turn_btn
			_log(tr("Dica: ataca agora — é letal!") if bool(h.get("lethal", false)) else tr("Dica: não há mais nada que suba o ataque — ataca."))
		"land":
			var land: CardInstance = h["card"]
			target = _hand_views.get(land.uid)
			_log(tr("Dica: joga primeiro o Terreno — dá mais mana."))
		"card":
			var c: CardInstance = h["card"]
			target = _hand_views.get(c.uid)
			_log(tr("Dica: joga %s (+%s de dano).") % [c.data.display_name(), Cascade.fmt_int(int(h.get("gain", 0)))])
		"order":
			target = _order_btn
			_log(tr("Dica: muda a ordem da Arena (+%s de dano).") % Cascade.fmt_int(int(h.get("gain", 0))))
	if _alive(target):
		_flash_hint(target)

## Brilho dourado a pulsar por cima do alvo da dica (3 vezes).
func _flash_hint(target: Control) -> void:
	if _hint_tw != null and _hint_tw.is_valid():
		_hint_tw.kill()
	var base := target.modulate
	_hint_tw = create_tween()
	for i in 3:
		_hint_tw.tween_property(target, "modulate", Color(1.5, 1.3, 0.6), _d(0.18) + 0.05)
		_hint_tw.tween_property(target, "modulate", base, _d(0.18) + 0.05)
	_bump(target, 1.1)

## Novo recorde: abranda, faísca dourada e um ecrã a dizer o recorde antigo.
func _celebrate_record(total: int, old: int) -> void:
	Sfx.boom()
	Settings.vibrate(80)
	if Settings.motion_ok():
		SceneRouter.hit_stop(0.4, 0.2)
		for k in 3:
			ColorBurst.spawn(self, total_label.global_position + total_label.size / 2.0 + Vector2(randf_range(-80, 80), randf_range(-20, 20)), "white")
	_show_banner(tr("NOVO RECORDE!") + "\n" + tr("%s  ·  antes: %s") % [Cascade.fmt_int(total), Cascade.fmt_int(old)], 1.6)
	if not _skip_cascade:   # quem saltou a cascata não fica à espera (o letreiro fica no ecrã)
		await get_tree().create_timer(_d(1.2) + 0.2).timeout

## Uma carta deu uma palavra-chave: "+Voar" por cima da criatura.
func _on_keyword_granted(card: CardInstance, kw: String) -> void:
	_refresh_board()
	var view: Control = _board_views.get(card.uid)
	if _alive(view):
		_pop(view, "+" + tr(String(CardData.KEYWORD_NAMES.get(kw, kw))), UiKit.GOLD)
	_log(tr("%s ganha %s.") % [card.data.display_name(), tr(String(CardData.KEYWORD_NAMES.get(kw, kw)))])

func _on_landfall(_land: CardInstance) -> void:
	_log(tr("Chegada de Terreno!"))
	_refresh_board()

## Fim da batalha da Arena (0.12.0): o resultado (relíquia e ouro, ou vida a menos) e segue o mapa.
func _arena_result(victory: bool) -> void:
	var txt := GameState.finish_arena(victory)
	if victory:
		Sfx.boom()
		_show_banner(tr("ARENA VENCIDA"), 1.0)
	else:
		Sfx.hit()
		_show_banner(tr("DERROTA NA ARENA"), 1.0)
	SceneRouter.toast(txt, 3.0)
	await get_tree().create_timer(_d(1.1)).timeout
	GameState.pending_event = ""
	GameState.next_ante()
	GameState.save_run({}, "map")
	SceneRouter.go("map")

# ---------------------------------------------------------------------------
# 0.13.0 — decisões na batalha: quem bloqueia, golpe carregado, ordem de disparo, total ao vivo,
# setas do inimigo, avisos no topo, palavras-chave explicadas, sem jogadas, jogada perfeita
# ---------------------------------------------------------------------------

## Etiqueta de cada ameaça na Arena: [texto, cor, seta?].
const THREAT_STYLE := {
	"block": ["BLOQUEIA", Color(0.3, 0.55, 0.95), false],
	"die": ["MORRE", Color(0.92, 0.25, 0.25), true],
	"jail": ["PRESA", Color(0.55, 0.55, 0.65), true],
	"mirror": ["COPIADA", Color(0.55, 0.68, 0.95), true],
	"destroy": ["DESTRUÍDA", Color(0.92, 0.25, 0.25), true],
	"burn": ["−%d", Color(0.95, 0.5, 0.15), false],
	"burn_die": ["MORRE", Color(0.92, 0.25, 0.25), true],
	"exile": ["EXILADA", Color(0.62, 0.35, 0.9), true],
	"meteor": ["−%d", Color(0.95, 0.5, 0.15), false],
	"meteor_die": ["MORRE", Color(0.92, 0.25, 0.25), true],
}

func _make_0130_widgets() -> void:
	_overlay = BattleOverlay.new()
	add_child(_overlay)
	_make_items_bar()

# --- 0.13.0: consumíveis (poções e pergaminhos) na barra de cima, ao lado do ouro ---

var _items_bar: HBoxContainer
var _pending_phase_text := ""

func _make_items_bar() -> void:
	var top: Control = turn_label.get_parent()
	_items_bar = HBoxContainer.new()
	_items_bar.name = "ItemsBar"
	_items_bar.add_theme_constant_override("separation", 6)
	_items_bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	top.add_child(_items_bar)
	top.move_child(_items_bar, gold_label.get_index())
	_refresh_items()

func _refresh_items() -> void:
	if _items_bar == null or not is_instance_valid(_items_bar):
		return
	UiKit.clear_children(_items_bar)
	var show := not battle.puzzle and GameState.puzzle_id == "" and GameState.consumable_slots() > 0
	_items_bar.visible = show
	if not show:
		return
	for i in GameState.consumable_slots():
		var b := Button.new()
		b.name = "Item%d" % i
		b.custom_minimum_size = Vector2(52, 52)
		b.focus_mode = Control.FOCUS_NONE
		var filled := i < GameState.consumables.size()
		var st := UiKit.flat(Color(0.14, 0.11, 0.22, 0.95) if filled else Color(0.1, 0.09, 0.15, 0.6), 26, UiKit.GOLD if filled else Color(0.35, 0.32, 0.45), 2, 0)
		for k in ["normal", "hover", "pressed", "disabled"]:
			b.add_theme_stylebox_override(k, st)
		if filled:
			var id := GameState.consumables[i]
			var def := CardDB.get_consumable(id)
			var art := ArtLib.texture("item", id)
			if art != null:   # ilustração (assets/art/items) num círculo
				var holder := Control.new()
				holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
				holder.set_anchors_preset(Control.PRESET_FULL_RECT)
				holder.draw.connect(func(): ArtLib.draw_round(holder, art, holder.size / 2.0, minf(holder.size.x, holder.size.y) / 2.0 - 4.0))
				b.add_child(holder)
			else:
				var icon := CardIcon.new(String(def.get("kind", "potion")), Color(String(def.get("color", "#ffffff"))), 30.0)
				icon.set_anchors_preset(Control.PRESET_FULL_RECT)
				icon.offset_left = 10
				icon.offset_top = 10
				icon.offset_right = -10
				icon.offset_bottom = -10
				b.add_child(icon)
			b.tooltip_text = tr(String(def.get("name", id))) + ": " + tr(String(def.get("text", "")))
			b.modulate.a = 1.0 if battle.can_use_consumable(id) else 0.6
			b.pressed.connect(_open_item.bind(i))
		else:
			b.disabled = true
			b.tooltip_text = tr("Espaço para uma poção ou pergaminho (loja, Elites, eventos).")
		_items_bar.add_child(b)

## Tocar numa poção/pergaminho: o que faz e USAR.
func _open_item(index: int) -> void:
	if _alive(_modal) or battle.finished or _animating or index >= GameState.consumables.size():
		return
	Sfx.select()
	var id := GameState.consumables[index]
	var def := CardDB.get_consumable(id)
	var box := _open_modal(tr(String(def.get("name", id))), tr(String(def.get("text", ""))))
	var ok := battle.can_use_consumable(id)
	if not ok:
		var why := tr("Usa-se fora das batalhas (no mapa).") if String(def.get("use", "battle")) == "map" else tr("Agora não teria efeito.")
		var l := UiKit.label(why, 17, UiKit.TEXT_DIM)
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(l)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	var use := UiKit.button(tr("USAR"), 54, 20, UiKit.PRIMARY)
	use.name = "UseItem"
	use.custom_minimum_size.x = 200
	use.disabled = not ok
	use.pressed.connect(func(): _close_modal("use"))
	row.add_child(use)
	var close := UiKit.button(tr("FECHAR"), 54, 18)
	close.custom_minimum_size.x = 200
	close.pressed.connect(func(): _close_modal(null))
	row.add_child(close)
	var res = await _modal_result()
	if res is String and res == "use":
		_use_item(index)

func _use_item(index: int) -> void:
	if index >= GameState.consumables.size():
		return
	var id := GameState.consumables[index]
	var nm := tr(String(CardDB.get_consumable(id).get("name", id)))
	if not battle.use_consumable(index):
		return
	_undo_stack.clear()   # o consumível gasto não volta com o DESFAZER
	Sfx.boom()
	Settings.vibrate(30)
	_log(tr("Usaste: %s.") % nm)
	_pop(_items_bar, nm, UiKit.GOLD)
	_refresh_all()
	_refresh_items()
	_refresh_preview()

## Ladra de Relíquias: a relíquia fica apagada até ao fim da batalha.
func _on_relic_stolen(id: String) -> void:
	var nm := tr(String(CardDB.relics.get(id, {}).get("name", id)))
	_log(tr("%s desligou %s até ao fim da batalha.") % [tr(battle.enemy.name), nm])
	var v: Control = _relic_views.get(id)
	if _alive(v):
		_flash(v, Color(2.0, 1.6, 0.6))
		v.modulate = Color(0.45, 0.45, 0.5, 0.55)
	_refresh_preview()

## Hidra Tricéfala: mais uma fase (a fala e o letreiro vêm com o boss_phase2 que se segue).
func _on_boss_phase(_index: int, text: String) -> void:
	_pending_phase_text = text
	_ensure_hp_marker()

## Números de ordem (com 2+ criaturas) e o que o inimigo vai fazer a cada uma (com setas).
func _refresh_overlay() -> void:
	if _overlay == null:
		return
	if _animating or battle.finished or battle.resolving:
		_overlay.clear()
		return
	var badges: Array = []
	var order := battle.strike_order()
	if order.size() >= 2:
		for i in order.size():
			var v: Control = _board_views.get((order[i] as CardInstance).uid)
			if _alive(v):
				badges.append([v, i + 1])
	var threats: Array = []
	var lethal := _last_preview_total > 0 and _last_preview_total >= int(battle.enemy.hp)
	if Settings.show_threats and not lethal and not _what_if:
		var dy := {}
		for t in battle.threat_preview():
			var c: CardInstance = t["card"]
			var v: Control = _board_views.get(c.uid)
			var info: Array = THREAT_STYLE.get(String(t["kind"]), [])
			if not _alive(v) or info.is_empty():
				continue
			var text := tr(String(info[0]))
			if text.contains("%d"):
				text = text % int(t.get("value", 0))
			var off := float(dy.get(c.uid, 0.0))
			dy[c.uid] = off - 26.0
			threats.append({"node": v, "text": text, "color": info[1], "arrow": info[2], "dy": off})
	if _alive(_portrait):
		_overlay.from_y = _portrait.get_global_rect().get_center().y - enemy_panel.get_global_rect().position.y
	_overlay.set_data(enemy_panel, badges, threats)

## Tocar na intenção do inimigo: o texto todo e, se ele vai contra-atacar, quem bloqueia (automático,
## uma criatura à escolha ou ninguém), com o resultado de cada opção.
func _open_intent() -> void:
	if _alive(_modal) or battle.finished or _animating:
		return
	Sfx.select()
	var lethal := _last_preview_total > 0 and _last_preview_total >= int(battle.enemy.hp)
	var p := battle.counter_plan()
	var can_choose := not lethal and not battle.resolving and int(p["damage"]) > 0 and not battle.board.is_empty()
	var box := _open_modal(tr(battle.enemy.name), counter_label.text)
	if can_choose:
		var t := UiKit.label(tr("Quem bloqueia o contra-ataque?"), 20, UiKit.GOLD)
		t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(t)
		var grid := GridContainer.new()
		grid.columns = 2
		grid.add_theme_constant_override("h_separation", 10)
		grid.add_theme_constant_override("v_separation", 8)
		grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		box.add_child(grid)
		var opts: Array = [BattleManager.BLOCK_AUTO]
		for c in battle.board:
			opts.append(c.uid)
		opts.append(BattleManager.BLOCK_NONE)
		var keep := battle.chosen_blocker
		for uid in opts:
			battle.chosen_blocker = uid
			var plan := battle.counter_plan()
			var current: bool = uid == keep
			var btn := UiKit.wrap_button(_block_option_text(int(uid), plan), 62, 15,
				UiKit.PRIMARY.darkened(0.45) if current else UiKit.BTN_BG, UiKit.GOLD if current else Color(0, 0, 0, 0))
			btn.custom_minimum_size.x = 292
			btn.name = "Block_%s" % ("auto" if uid == BattleManager.BLOCK_AUTO else ("none" if uid == BattleManager.BLOCK_NONE else str(uid)))
			btn.pressed.connect(func(): _close_modal(int(uid)))
			grid.add_child(btn)
		battle.chosen_blocker = keep
	var close := UiKit.button(tr("FECHAR"), 50, 18)
	close.custom_minimum_size.x = 200
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close.pressed.connect(func(): _close_modal(null))
	box.add_child(close)
	var res = await _modal_result()
	if res is int:
		_choose_blocker(int(res))

## Aplica a escolha de quem bloqueia e diz o que vai acontecer.
func _choose_blocker(uid: int) -> void:
	if not battle.set_blocker(uid):
		return
	if not battle.puzzle:
		Stats.add("blocks_chosen")
	_refresh_preview()
	match uid:
		BattleManager.BLOCK_AUTO:
			_log(tr("Bloqueio automático."))
		BattleManager.BLOCK_NONE:
			_log(tr("Ninguém bloqueia: o golpe é para ti."))
		_:
			var i := battle._index_of_uid(uid)
			if i >= 0:
				_log(tr("%s vai bloquear o contra-ataque.") % battle.board[i].data.display_name())
				_bump(_board_views.get(uid), 1.08)

## Texto de uma opção do bloqueio: quem e o que acontece.
func _block_option_text(uid: int, plan: Dictionary) -> String:
	var head := ""
	match uid:
		BattleManager.BLOCK_AUTO:
			head = tr("Automático")
		BattleManager.BLOCK_NONE:
			head = tr("Ninguém")
		_:
			var i := battle._index_of_uid(uid)
			if i >= 0:
				head = "%s  (%d ♥)" % [_short(battle.board[i].data.display_name(), 22), battle.board[i].remaining()]
	var b: CardInstance = plan["blocker"]
	if uid == BattleManager.BLOCK_AUTO and b != null:
		head += ": " + _short(b.data.display_name(), 20)
	var bits: Array[String] = []
	if b != null:
		if bool(plan.get("vigilant", false)):
			bits.append(tr("sem dano (Vigilância)"))
		elif bool(plan["survives"]):
			bits.append(tr("sem dano") if int(plan["blocker_damage"]) <= 0 else tr("sobrevive"))
		else:
			bits.append(tr("morre"))
	var others := 0
	for c in plan["deaths"]:
		if c != b:
			others += 1
	if others > 0:
		bits.append(tr("morrem %d") % others)
	if int(plan["player_damage"]) > 0:
		bits.append(tr("levas %d") % int(plan["player_damage"]))
	elif b == null and others == 0:
		bits.append(tr("sem dano"))
	if uid == BattleManager.BLOCK_NONE and int(plan["damage"]) >= GameState.player_hp:
		bits.append(tr("seria letal: automático"))
	return head + "\n" + " · ".join(PackedStringArray(bits))

## Nome encurtado com reticências (botões estreitos).
static func _short(text: String, n: int) -> String:
	return text if text.length() <= n else text.substr(0, n - 1).strip_edges() + "…"

## Aviso curto no topo do ecrã, por cima das relíquias: nunca tapa o cálculo nem a Arena.
func _warn(text: String, color: Color = Color(0.95, 0.45, 0.4), seconds: float = 2.6) -> void:
	if not is_inside_tree():
		return
	if _alive(_notice):
		_notice.queue_free()
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.12, 0.08, 0.14, 0.96), 12, color, 2, 10))
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.z_index = 50
	panel.name = "TopNotice"
	var l := UiKit.label(text, 17, Color.WHITE)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	panel.add_child(l)
	add_child(panel)
	_notice = panel
	panel.modulate.a = 0.0
	await get_tree().process_frame
	if not is_instance_valid(panel) or not is_inside_tree():
		return
	panel.reset_size()
	panel.global_position = _top_slot(panel.size, _alive(_tip_panel))
	var tw := create_tween()
	tw.tween_property(panel, "modulate:a", 1.0, 0.15)
	tw.tween_interval(maxf(0.8, seconds))
	tw.tween_property(panel, "modulate:a", 0.0, 0.3)
	tw.tween_callback(func():
		if is_instance_valid(panel):
			panel.queue_free())

## Largura livre no topo, entre o ORDENAR e o ouro.
func _top_room() -> float:
	var span := _top_span()
	return maxf(200.0, span.y - span.x)

## [x mínimo, x máximo] livres no topo: depois do ORDENAR e antes do texto do ouro (o rótulo do ouro estica
## para a esquerda, por isso conta-se a largura do texto, encostado à direita).
func _top_span() -> Vector2:
	var vp := get_viewport_rect().size
	var lo := 8.0
	var hi := vp.x - 8.0
	if _sort_btn != null and _sort_btn.is_visible_in_tree():
		lo = maxf(lo, _sort_btn.get_global_rect().end.x + 8.0)
	if gold_label.is_visible_in_tree():
		var font := gold_label.get_theme_font("font")
		var fs := gold_label.get_theme_font_size("font_size")
		var w := font.get_string_size(gold_label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x if font != null else 110.0
		hi = minf(hi, gold_label.get_global_rect().end.x - w - 16.0)
	if _items_bar != null and is_instance_valid(_items_bar) and _items_bar.is_visible_in_tree() and _items_bar.get_child_count() > 0:
		hi = minf(hi, _items_bar.get_global_rect().position.x - 8.0)   # 0.13.0: as poções não ficam tapadas
	return Vector2(lo, hi)

## Lugar no topo, entre os botões da barra (ORDENAR) e o ouro, centrado na coluna do meio. below_tip:
## por baixo da dica que esteja aberta.
func _top_slot(sz: Vector2, below_tip: bool) -> Vector2:
	var vp := get_viewport_rect().size
	var span := _top_span()
	var lo := span.x
	var hi := span.y
	var strip: Control = spell_strip.get_parent_control()
	var cx := strip.get_global_rect().get_center().x
	var x := clampf(cx - sz.x / 2.0, lo, maxf(lo, hi - sz.x))
	if x + sz.x > vp.x - 8.0:
		x = maxf(8.0, vp.x - 8.0 - sz.x)
	var y := 6.0
	if below_tip and _alive(_tip_panel):
		y = _tip_panel.get_global_rect().end.y + 4.0
	return Vector2(x, y)

## Tocar no ícone de uma palavra-chave (Arena): o que ela faz, num balão por cima do ícone.
func _on_keyword_tapped(_card: CardInstance, kw: String, at: Rect2) -> void:
	if SceneRouter.has_overlay() or _alive(_modal):
		return
	Sfx.select()
	if _alive(_kw_bubble):
		_kw_bubble.queue_free()
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.1, 0.09, 0.16, 0.97), 10, UiKit.GOLD, 2, 10))
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.z_index = 55
	panel.name = "KeywordBubble"
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(row)
	var icon := CardIcon.new(kw, UiKit.GOLD, 26.0)
	icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(icon)
	var l := UiKit.label(tr(String(CardData.KEYWORD_TEXT.get(kw, CardData.KEYWORD_NAMES.get(kw, kw)))), 16, Color.WHITE, true)
	l.custom_minimum_size.x = 300
	row.add_child(l)
	add_child(panel)
	_kw_bubble = panel
	panel.modulate.a = 0.0
	await get_tree().process_frame
	if not is_instance_valid(panel) or not is_inside_tree():
		return
	panel.reset_size()
	var vp := get_viewport_rect().size
	var pos := Vector2(at.get_center().x - panel.size.x / 2.0, at.position.y - panel.size.y - 10.0)
	if pos.y < 6.0:
		pos.y = at.end.y + 10.0
	panel.global_position = Vector2(clampf(pos.x, 8.0, vp.x - panel.size.x - 8.0), clampf(pos.y, 6.0, vp.y - panel.size.y - 6.0))
	var tw := create_tween()
	tw.tween_property(panel, "modulate:a", 1.0, 0.12)
	tw.tween_interval(3.2)
	tw.tween_property(panel, "modulate:a", 0.0, 0.3)
	tw.tween_callback(func():
		if is_instance_valid(panel):
			panel.queue_free())

## Enquanto arrastas uma carta para a Arena, o cálculo mostra o ataque com ela (total a verde).
func _show_what_if(card: CardInstance) -> void:
	var c := battle.preview_cascade_with(card)
	if c == null:
		return
	_what_if = true
	_show_calc(c, true)
	if _overlay != null:
		_overlay.clear()

## Sem jogadas possíveis: um aviso no topo (uma vez por turno) e o ATACAR a brilhar.
func _check_no_plays() -> void:
	var none := _no_plays_left()
	_set_attack_glow(none)
	if none and _no_plays_turn != battle.turn and not battle.puzzle and not battle.can_mulligan():
		_no_plays_turn = battle.turn
		var txt := tr("Já não tens jogadas: ataca!") if battle.discards_left <= 0 else tr("Já não tens jogadas: ataca (ou canaliza uma carta).")
		_warn(txt, UiKit.GOLD, 3.0)

func _no_plays_left() -> bool:
	if battle.resolving or battle.finished or _animating or battle.pending_bottom > 0 or battle.turn < 1 or _discard_mode:
		return false
	for c in battle.deck.hand:
		if battle.can_play(c):
			return false
	for c in battle.deck.flashback_cards():
		if battle.can_flashback(c):
			return false
	for i in battle.planeswalker_skills().size():
		if battle.can_use_planeswalker(i):
			return false
	return true

## ATACAR a pulsar (brilho), quando já só resta atacar.
func _set_attack_glow(on: bool) -> void:
	var running := _attack_glow != null and _attack_glow.is_valid()
	if on == running:
		return
	if running:
		_attack_glow.kill()
	_attack_glow = null
	end_turn_btn.self_modulate = Color.WHITE
	if not on:
		return
	if not Settings.motion_ok():
		end_turn_btn.self_modulate = Color(1.2, 1.15, 0.95)
		return
	_attack_glow = create_tween().set_loops()
	_attack_glow.tween_property(end_turn_btn, "self_modulate", Color(1.4, 1.28, 0.85), 0.55).set_trans(Tween.TRANS_SINE)
	_attack_glow.tween_property(end_turn_btn, "self_modulate", Color.WHITE, 0.55).set_trans(Tween.TRANS_SINE)

## O inimigo investe: o retrato avança e, se alguém bloqueia, faíscas na criatura.
func _on_enemy_attacking(damage: int, blocker) -> void:
	if _portrait != null and _alive(_portrait):
		_portrait.attack()
	if not Settings.motion_ok() or Settings.anim_scale() <= 0.0 or damage <= 0:
		return
	_bump(enemy_panel, 1.06)
	if blocker is CardInstance and _board_views.has(blocker.uid):
		var v: Control = _board_views[blocker.uid]
		if _alive(v):
			SparkFx.spawn(self, v.global_position + Vector2(v.size.x * 0.5, v.size.y * 0.35))

## 0.13.0: rever o último ataque desta batalha, passo a passo (a mesma janela do "maior golpe").
func _replay_last_attack() -> void:
	if _last_cascade == null or _last_cascade.is_empty() or not is_inside_tree():
		return
	var snap := GameState.cascade_snapshot(_last_cascade, _last_cascade.net_total())
	snap["title"] = tr("O ÚLTIMO ATAQUE") + "  ·  " + tr("Turno %d") % _last_attack_turn
	if not battle.puzzle:
		Stats.add("replays")
	CascadeReplay.open(snap)

## 0.13.0: fim de um enigma — RESOLVIDO (próximo enigma) ou NÃO CHEGOU (quanto faltou e TENTAR OUTRA VEZ).
func _puzzle_result(victory: bool) -> void:
	await get_tree().create_timer(_d(0.9) + 0.2).timeout
	if not is_inside_tree():
		return
	var id := GameState.puzzle_id
	var def := CardDB.get_puzzle(id)
	var next_id := ""
	for i in CardDB.puzzles.size():
		if String(CardDB.puzzles[i].get("id", "")) == id and i + 1 < CardDB.puzzles.size():
			next_id = String(CardDB.puzzles[i + 1].get("id", ""))
	var body := tr(String(def.get("name", "")))
	if not victory:
		var hp := int(battle.enemy.get("hp", 0))
		body += "\n" + tr("Faltaram %s de dano.") % Cascade.fmt_int(hp) if hp > 0 else ""
	var box := _open_modal(tr("RESOLVIDO!") if victory else tr("NÃO CHEGOU"), body)
	_modal.name = "PuzzleResult"
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	box.add_child(row)
	var options: Array = []
	if victory and next_id != "":
		options.append(["PRÓXIMO ENIGMA", next_id, "NextPuzzle"])
	if not victory:
		options.append(["TENTAR OUTRA VEZ", id, "RetryPuzzle"])
	options.append(["ENIGMAS", "", "PuzzleList"])
	for opt in options:
		var target := String(opt[1])
		var b := UiKit.button(tr(String(opt[0])), 56, 20, UiKit.PRIMARY.darkened(0.2) if target != "" else UiKit.BG_LIGHT, Color(0, 0, 0, 0))
		b.name = String(opt[2])
		b.custom_minimum_size.x = 230
		b.pressed.connect(func():
			Sfx.select()
			if target != "":
				GameState.reset_for_side_battle(target)
				SceneRouter.go("battle")
			else:
				GameState.puzzle_id = ""
				SceneRouter.go("puzzles"))
		row.add_child(b)
