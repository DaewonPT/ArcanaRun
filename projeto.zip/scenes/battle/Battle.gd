extends Control
## Cena de batalha (horizontal). Liga a UI ao BattleManager através do EventBus e anima:
## cartas a voar da mão para o tabuleiro, compra, investida das criaturas na cascata,
## impacto no inimigo, número de dano a voar, partículas no total, banner de ante.
## Grava a run no início de cada turno (BattleManager.to_dict) e retoma-a se houver uma
## batalha pendente em GameState.pending_battle. Pausa, carta em grande e grimório/cemitério
## abrem como overlays (SceneRouter.show_overlay) sem destruir a cena.

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const RELIC_VIEW := preload("res://scenes/ui/RelicView.tscn")

const COLOR_POWER := Color(0.22, 0.74, 0.97)
const COLOR_MULT := Color(0.96, 0.25, 0.37)
const COLOR_MULT_X := Color(0.72, 0.35, 0.95)
const COLOR_FORMATION := Color(0.98, 0.75, 0.25)
const COLOR_GROW := Color(0.35, 0.85, 0.45)
const COLOR_GOLD := Color(0.98, 0.85, 0.3)
const DISCARD_TINT := Color(0.8, 0.6, 1.0)

const ABILITY_LOG := {
	"steal_gold": "roubou-te ouro",
	"heal_self": "curou-se",
	"destroy_strongest": "destruiu a tua criatura mais forte",
	"damage_all_creatures": "feriu todas as tuas criaturas",
	"discard_random": "fez-te descartar uma carta",
}

@onready var battle: BattleManager = $BattleManager
@onready var layout: Control = $Layout
@onready var hand_box: HBoxContainer = %Hand
@onready var board_box: HBoxContainer = %Board
@onready var spell_strip: HBoxContainer = %SpellStrip
@onready var spell_hint: Label = %SpellHint
@onready var relics_bar: HBoxContainer = %RelicsBar
@onready var turn_label: Label = %TurnLabel
@onready var gold_label: Label = %GoldLabel
@onready var pause_btn: Button = %PauseBtn
@onready var enemy_panel: Control = %EnemyPanel
@onready var enemy_name: Label = %EnemyName
@onready var enemy_hp_bar: ProgressBar = %EnemyHPBar
@onready var enemy_hp_ghost: ProgressBar = %EnemyHPGhost
@onready var enemy_hp_label: Label = %EnemyHPLabel
@onready var enemy_text: Label = %EnemyText
@onready var counter_label: Label = %CounterLabel
@onready var emblem: PanelContainer = %Emblem
@onready var emblem_label: Label = %EmblemLabel
@onready var log_label: Label = %LogLabel
@onready var undo_btn: Button = %UndoBtn
@onready var player_label: Label = %PlayerLabel
@onready var mana_label: Label = %ManaLabel
@onready var end_turn_btn: Button = %EndTurn
@onready var discard_btn: Button = %DiscardBtn
@onready var library_btn: Button = %LibraryBtn
@onready var graveyard_btn: Button = %GraveyardBtn
@onready var formation_label: Label = %FormationLabel
@onready var power_label: Label = %PowerLabel
@onready var mult_label: Label = %MultLabel
@onready var total_label: Label = %TotalLabel
@onready var power_pill: Control = %PowerPill
@onready var mult_pill: Control = %MultPill
@onready var banner: Label = %Banner

var _board_views: Dictionary = {}   # uid -> CardView
var _hand_views: Dictionary = {}    # uid -> CardView
var _spell_chips: Dictionary = {}   # uid -> Control
var _relic_views: Dictionary = {}   # relic_id -> RelicView
var _animating: bool = false
var _discard_mode: bool = false
var _layout_base: Vector2
var _particles: CPUParticles2D
var _hp_tween: Tween
var _pause_menu: PauseMenu
var _resumed: bool = false
var _undo_stack: Array[Dictionary] = []
var _undo_turn: int = 0
var _drag_ghost: Control
var _drag_view: Control
var _attack_style: StyleBoxFlat
var _lethal_style: StyleBoxFlat
var _last_preview_total: int = 0

const ABILITY_INTENT := {
	"steal_gold": "rouba %d ouro",
	"heal_self": "cura-se %d",
	"destroy_strongest": "destrói a tua criatura mais forte",
	"damage_all_creatures": "%d de dano às tuas criaturas",
	"discard_random": "descarta-te %d carta(s)",
}

func _ready() -> void:
	_layout_base = layout.position
	EventBus.enemy_hp_changed.connect(_on_enemy_hp)
	EventBus.player_hp_changed.connect(func(c, m): player_label.text = tr("Vida %d/%d") % [c, m])
	EventBus.gold_changed.connect(func(g): gold_label.text = tr("Ouro %d") % g)
	EventBus.mana_changed.connect(_on_mana_changed)
	EventBus.discards_changed.connect(_on_discards_changed)
	EventBus.turn_started.connect(_on_turn_started)
	EventBus.card_drawn.connect(func(_c): _refresh_hand())
	EventBus.hand_changed.connect(_refresh_hand)
	EventBus.spell_cast.connect(_on_spell_cast)
	EventBus.creature_died.connect(_on_creature_died)
	EventBus.creature_blocked.connect(_on_creature_blocked)
	EventBus.card_discarded.connect(_on_card_discarded)
	EventBus.card_grew.connect(_on_card_grew)
	EventBus.enemy_ability_used.connect(_on_enemy_ability)
	EventBus.damage_dealt.connect(_on_damage_dealt)
	EventBus.cascade_started.connect(_on_cascade_started)
	EventBus.battle_ended.connect(_on_battle_ended)
	EventBus.relics_changed.connect(_build_relics)
	Settings.changed.connect(_refresh_texts)
	end_turn_btn.pressed.connect(_on_end_turn)
	discard_btn.toggled.connect(_on_discard_toggled)
	pause_btn.pressed.connect(_open_pause)
	library_btn.pressed.connect(_open_library)
	graveyard_btn.pressed.connect(_open_graveyard)
	undo_btn.pressed.connect(_on_undo)
	_apply_handedness()
	_attack_style = end_turn_btn.get_theme_stylebox("normal")
	_lethal_style = _attack_style.duplicate()
	_lethal_style.bg_color = Color(0.2, 0.68, 0.32)
	_make_particles()

	_build_relics()
	gold_label.text = tr("Ouro %d") % GameState.gold
	# Retoma uma batalha gravada a meio, se houver; senão começa uma nova neste ante.
	var resumed := false
	if not GameState.pending_battle.is_empty():
		var state := GameState.pending_battle
		GameState.pending_battle = {}
		_resumed = true   # sem banner "TURNO N" durante o restore
		resumed = battle.restore(state)
		_resumed = false
	if not resumed:
		battle.start(GameState.pick_enemy(GameState.ante))
	_refresh_enemy_header()
	_refresh_all()
	if not resumed and not Stats.tutorial_done() and GameState.ante == 1 and battle.turn == 1:
		TutorialOverlay.open(self)
	if resumed:
		_log(tr("Run retomada no turno %d.") % battle.turn)
		_show_banner(tr("ANTE %d") % GameState.ante + "\n" + tr("TURNO %d") % battle.turn)
	else:
		_log(tr("Toca numa carta para a jogar."))
		if battle.enemy.get("boss", false):
			_show_banner(tr("BOSS") + "\n" + tr(battle.enemy.name), 1.4)
		else:
			_show_banner(tr("ANTE %d") % GameState.ante + "\n" + tr(battle.enemy.name))

## Modo canhoto: a coluna dos botões passa para a direita.
func _apply_handedness() -> void:
	var middle: HBoxContainer = layout.get_node("Middle")
	var left_col: Control = middle.get_node("LeftCol")
	middle.move_child(left_col, middle.get_child_count() - 1 if Settings.left_handed else 0)

## Nome, emblema (inicial numa cor derivada do id) e texto do inimigo; moldura dourada nos bosses.
func _refresh_enemy_header() -> void:
	enemy_name.text = battle.enemy.name
	enemy_text.text = battle.enemy.text
	var id := String(battle.enemy.get("id", battle.enemy.name))
	var name_txt := tr(String(battle.enemy.name))
	emblem_label.text = name_txt.substr(0, 1).to_upper() if name_txt != "" else "?"
	var style: StyleBoxFlat = emblem.get_theme_stylebox("panel").duplicate()
	style.bg_color = Color.from_hsv(fmod(float(abs(id.hash())) / 1000.0, 1.0), 0.55, 0.75)
	emblem.add_theme_stylebox_override("panel", style)
	if battle.enemy.get("boss", false):
		var panel_style: StyleBoxFlat = enemy_panel.get_theme_stylebox("panel").duplicate()
		panel_style.border_color = UiKit.GOLD
		panel_style.border_width_left = 3
		panel_style.border_width_right = 3
		panel_style.border_width_top = 3
		panel_style.border_width_bottom = 3
		enemy_panel.add_theme_stylebox_override("panel", panel_style)

func _make_particles() -> void:
	_particles = CPUParticles2D.new()
	_particles.emitting = false
	_particles.one_shot = true
	_particles.explosiveness = 0.95
	_particles.amount = 48
	_particles.lifetime = 0.8
	_particles.spread = 180.0
	_particles.direction = Vector2(0, -1)
	_particles.gravity = Vector2(0, 700)
	_particles.initial_velocity_min = 220.0
	_particles.initial_velocity_max = 520.0
	_particles.scale_amount_min = 3.0
	_particles.scale_amount_max = 7.0
	_particles.color = Color(1.0, 0.85, 0.35)
	add_child(_particles)

## Duração de uma animação com a velocidade das Configurações.
func _d(seconds: float) -> float:
	return Settings.dur(seconds)

# --- Construção / refresh ---

func _build_relics() -> void:
	for child in relics_bar.get_children():
		child.queue_free()
	_relic_views.clear()
	for id in GameState.relic_ids:
		var view: RelicView = RELIC_VIEW.instantiate()
		relics_bar.add_child(view)
		view.setup(id)
		view.pressed.connect(_on_relic_pressed)
		view.drag_started.connect(_on_relic_drag_started)
		view.drag_moved.connect(_on_relic_drag_moved)
		view.drag_ended.connect(_on_relic_drag_ended)
		_relic_views[id] = view
	if not _animating and battle.effects != null:
		_refresh_preview()

func _refresh_all() -> void:
	_refresh_hand()
	_refresh_board()
	_refresh_spells()
	_refresh_preview()
	_refresh_zone_buttons()

## Texto que depende do idioma (chamado quando as Configurações mudam).
func _refresh_texts() -> void:
	if battle.enemy.is_empty():
		return
	_apply_handedness()
	turn_label.text = tr("Turno %d/%d  ·  Ante %d") % [battle.turn, battle.max_turns + battle.extra_turns, GameState.ante]
	gold_label.text = tr("Ouro %d") % GameState.gold
	player_label.text = tr("Vida %d/%d") % [GameState.player_hp, GameState.player_max_hp]
	mana_label.text = tr("Mana %d/%d") % [battle.mana_available, battle.mana_total]
	_refresh_enemy_header()
	_refresh_discard_button()
	_refresh_zone_buttons()
	if not _animating:
		_refresh_preview()
		for v in _hand_views.values():
			if _alive(v):
				v.refresh()
		for v in _board_views.values():
			if _alive(v):
				v.refresh()

func _refresh_zone_buttons() -> void:
	library_btn.text = tr("GRIMÓRIO %d") % battle.deck.library.size()
	graveyard_btn.text = tr("CEMITÉRIO %d") % battle.deck.graveyard.size()
	undo_btn.disabled = _undo_stack.is_empty() or battle.resolving or battle.finished

func _refresh_hand() -> void:
	# Se a mão é a mesma (mesmas cartas, mesma ordem), só atualiza as vistas — não interrompe animações.
	var live := hand_box.get_children().filter(func(c): return not c.is_queued_for_deletion())
	var same := _hand_views.size() == battle.deck.hand.size() and live.size() == battle.deck.hand.size()
	if same:
		var i := 0
		for card in battle.deck.hand:
			if not _hand_views.has(card.uid) or live[i] != _hand_views[card.uid]:
				same = false
				break
			i += 1
	if same:
		for card in battle.deck.hand.duplicate():
			var v: CardView = _hand_views[card.uid]
			if _alive(v):
				v.refresh()
				v.playable = battle.can_play(card) or card.data.is_land() or _discard_mode
				v.delta = 0 if (_discard_mode or _animating) else battle.preview_play(card)
		_refresh_preview()
		_refresh_zone_buttons()
		return
	var previous := _hand_views.keys()
	for child in hand_box.get_children():
		child.queue_free()
	_hand_views.clear()
	var stagger := 0.0
	for card in battle.deck.hand.duplicate():
		var view: CardView = CARD_VIEW.instantiate()
		hand_box.add_child(view)
		view.setup(card)
		view.playable = battle.can_play(card) or card.data.is_land() or _discard_mode
		if _discard_mode:
			view.modulate = DISCARD_TINT
		view.pressed.connect(_on_hand_card_pressed)
		view.long_pressed.connect(_on_card_long_pressed)
		view.delta = 0 if (_discard_mode or _animating) else battle.preview_play(card)
		_hand_views[card.uid] = view
		if not (card.uid in previous):
			_animate_draw(view, stagger)
			stagger += 0.05
	_refresh_preview()
	_refresh_zone_buttons()

func _refresh_board() -> void:
	if _animating:
		return
	var creatures := battle.creatures()
	var live := board_box.get_children().filter(func(c): return not c.is_queued_for_deletion())
	var same := _board_views.size() == creatures.size() and live.size() == creatures.size()
	if same:
		var i := 0
		for card in creatures:
			if not _board_views.has(card.uid) or live[i] != _board_views[card.uid]:
				same = false
				break
			i += 1
	if same:
		for card in creatures:
			if _alive(_board_views[card.uid]):
				(_board_views[card.uid] as CardView).refresh()
		return
	for child in board_box.get_children():
		child.queue_free()
	_board_views.clear()
	for card in creatures:
		var view: CardView = CARD_VIEW.instantiate()
		board_box.add_child(view)
		view.setup(card)
		view.long_pressed.connect(_on_card_long_pressed)
		view.pressed.connect(_on_card_long_pressed)   # no tabuleiro um toque simples também abre em grande
		view.draggable = true
		view.drag_started.connect(_on_board_drag_started)
		view.drag_moved.connect(_on_board_drag_moved)
		view.drag_ended.connect(_on_board_drag_ended)
		_board_views[card.uid] = view

func _refresh_spells() -> void:
	if _animating:
		return
	for child in spell_strip.get_children():
		if child != spell_hint:
			child.queue_free()
	_spell_chips.clear()
	spell_hint.visible = battle.spells_this_turn.is_empty()
	for sp in battle.spells_this_turn:
		var chip := _make_chip(sp)
		spell_strip.add_child(chip)
		_spell_chips[sp.uid] = chip

func _make_chip(sp: CardInstance) -> Control:
	var chip := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = CardView.COLORS.get(sp.data.primary_color(), CardView.COLORS.colorless)
	style.set_corner_radius_all(8)
	style.set_content_margin_all(6)
	chip.add_theme_stylebox_override("panel", style)
	var label := Label.new()
	label.text = "%s  %d⚔" % [tr(sp.data.name), sp.data.power] if sp.data.power > 0 else tr(sp.data.name)
	label.add_theme_font_size_override("font_size", 15)
	label.add_theme_color_override("font_color", Color(0.08, 0.08, 0.1) if style.bg_color.get_luminance() > 0.45 else Color.WHITE)
	chip.add_child(label)
	return chip

## Mostra o que o ataque faria se atacasses agora.
func _refresh_preview() -> void:
	if _animating:
		return
	var c := battle.preview_attack()
	if c.is_empty():
		formation_label.text = tr("Sem atacantes")
	elif c.formations.is_empty():
		formation_label.text = tr("Ataque")
	else:
		formation_label.text = " · ".join(PackedStringArray(_translated(c.formations)))
	power_label.text = Cascade.fmt_int(c.power)
	mult_label.text = Cascade.fmt_mult(c.mult)
	total_label.text = Cascade.fmt_int(c.total())
	_last_preview_total = c.total()
	var lethal := c.total() > 0 and c.total() >= int(battle.enemy.hp)
	if lethal:
		end_turn_btn.text = tr("ATACAR") + "   " + Cascade.fmt_int(c.total()) + "  ·  " + tr("LETAL")
		end_turn_btn.add_theme_stylebox_override("normal", _lethal_style)
	else:
		end_turn_btn.text = tr("ATACAR") + "   " + Cascade.fmt_int(c.total()) if c.total() > 0 else tr("ATACAR")
		end_turn_btn.add_theme_stylebox_override("normal", _attack_style)
	_refresh_hp_bars()
	_refresh_counter(lethal)

## Barra do inimigo: a parte clara (fantasma) é o dano do ataque atual.
func _refresh_hp_bars() -> void:
	var hp := int(battle.enemy.hp)
	enemy_hp_ghost.max_value = battle.enemy.max_hp
	enemy_hp_bar.max_value = battle.enemy.max_hp
	enemy_hp_ghost.value = hp
	if _animating:
		return
	enemy_hp_bar.value = max(0, hp - _last_preview_total)

## Contra-ataque previsto e intenção do inimigo para este turno.
func _refresh_counter(lethal: bool) -> void:
	if lethal:
		counter_label.text = tr("O ataque é letal: não há contra-ataque.")
		counter_label.add_theme_color_override("font_color", Color(0.45, 0.9, 0.55))
		return
	counter_label.add_theme_color_override("font_color", Color(1, 0.6, 0.55))
	var p := battle.preview_enemy_phase()
	var parts: Array[String] = []
	if int(p["damage"]) <= 0:
		parts.append(tr("Não ataca."))
	elif p["blocker"] != null:
		parts.append(tr("Ataca %d: %s bloqueia e sobrevive.") % [int(p["damage"]), tr((p["blocker"] as CardInstance).data.name)])
	elif (p["deaths"] as Array).is_empty():
		parts.append(tr("Ataca %d: ninguém bloqueia, levas tu %d.") % [int(p["damage"]), int(p["player_damage"])])
	else:
		parts.append(tr("Ataca %d (letal): %d criatura(s) sacrificam-se, levas %d.") % [int(p["damage"]), (p["deaths"] as Array).size(), int(p["player_damage"])])
	var intents: Array[String] = []
	for a in battle.enemy_intent(battle.turn):
		var tmpl: String = ABILITY_INTENT.get(String(a.get("action", "")), "")
		if tmpl == "":
			continue
		intents.append(tr(tmpl) % int(a.get("value", 0)) if tmpl.contains("%d") else tr(tmpl))
	if not intents.is_empty():
		parts.append(tr("Depois: ") + "; ".join(PackedStringArray(intents)) + ".")
	counter_label.text = " ".join(PackedStringArray(parts))

func _translated(names: Array[String]) -> Array[String]:
	var out: Array[String] = []
	for n in names:
		out.append(tr(n))
	return out

func _refresh_discard_button() -> void:
	discard_btn.text = tr("CANALIZAR (%d)") % battle.discards_left
	discard_btn.disabled = battle.discards_left <= 0 or battle.resolving or battle.finished
	if discard_btn.disabled and _discard_mode:
		discard_btn.button_pressed = false

# --- Handlers ---

func _on_mana_changed(available: int, total: int) -> void:
	mana_label.text = tr("Mana %d/%d") % [available, total]
	_refresh_hand()

func _on_discards_changed(_left: int) -> void:
	_refresh_discard_button()

func _on_turn_started(t: int) -> void:
	turn_label.text = tr("Turno %d/%d  ·  Ante %d") % [t, battle.max_turns + battle.extra_turns, GameState.ante]
	end_turn_btn.disabled = false
	if t != _undo_turn:
		_undo_stack.clear()
		_undo_turn = t
	_refresh_discard_button()
	_refresh_all()
	if not battle.finished:
		GameState.save_run(battle.to_dict(), "battle")   # gravação automática a cada turno
	if t > 1 and not _resumed:
		_show_banner(tr("TURNO %d") % t, 0.6)

func _on_enemy_hp(current: int, max_hp: int) -> void:
	enemy_hp_bar.max_value = max_hp
	enemy_hp_ghost.max_value = max_hp
	if _hp_tween != null and _hp_tween.is_valid():
		_hp_tween.kill()
	_hp_tween = create_tween().set_parallel(true)
	_hp_tween.tween_property(enemy_hp_ghost, "value", float(current), _d(0.45)).set_ease(Tween.EASE_OUT)
	_hp_tween.tween_property(enemy_hp_bar, "value", float(current if _animating else max(0, current - _last_preview_total)), _d(0.45)).set_ease(Tween.EASE_OUT)
	enemy_hp_label.text = "%s / %s" % [Cascade.fmt_int(current), Cascade.fmt_int(max_hp)]

func _on_spell_cast(_card: CardInstance) -> void:
	_refresh_spells()

func _on_creature_died(card: CardInstance) -> void:
	Sfx.hit()
	_log(tr("%s morreu.") % tr(card.data.name))
	if _board_views.has(card.uid) and is_instance_valid(_board_views[card.uid]):
		_animate_death(_board_views[card.uid])
	_refresh_board()
	_refresh_preview()
	_refresh_zone_buttons()

func _on_creature_blocked(card: CardInstance, amount: int) -> void:
	_log(tr("%s bloqueou %d de dano.") % [tr(card.data.name), amount])
	if _board_views.has(card.uid):
		var view: CardView = _board_views[card.uid]
		if is_instance_valid(view):
			view.refresh()
			_flash(view, Color(1.6, 1.6, 1.6))
			_bump(view, 0.9)

func _on_card_discarded(card: CardInstance) -> void:
	_log(tr("Canalizaste %s.") % tr(card.data.name))
	_refresh_zone_buttons()

func _on_card_grew(card: CardInstance, amount: int) -> void:
	var view: Control = _board_views.get(card.uid, _hand_views.get(card.uid))
	if view != null and is_instance_valid(view):
		if view is CardView:
			view.refresh()
		_pop(view, tr("Cresce +%d") % amount, COLOR_GROW)
	_refresh_preview()

func _on_hand_card_pressed(card: CardInstance) -> void:
	if battle.resolving or battle.finished:
		return
	if _discard_mode:
		if battle.can_discard(card):
			_push_undo()
			battle.discard(card)
			Sfx.hit()
			Settings.vibrate(20)
			discard_btn.button_pressed = false   # desliga o modo (toggled → _on_discard_toggled)
			_refresh_all()
		return
	var from_rect := Rect2()
	if _hand_views.has(card.uid) and is_instance_valid(_hand_views[card.uid]):
		from_rect = (_hand_views[card.uid] as Control).get_global_rect()
	if battle.can_play(card):
		_push_undo()
		battle.play(card)
		Sfx.select()
		_refresh_all()
		_animate_play(card, from_rect)

func _push_undo() -> void:
	_undo_stack.append(battle.snapshot())
	if _undo_stack.size() > 12:
		_undo_stack.pop_front()

func _on_undo() -> void:
	if _undo_stack.is_empty() or battle.resolving or battle.finished:
		return
	var snap: Dictionary = _undo_stack.pop_back()
	discard_btn.button_pressed = false
	_resumed = true   # sem banner "TURNO N"
	var ok := battle.restore_snapshot(snap)
	_resumed = false
	if ok:
		Sfx.hit()
		_log(tr("Jogada desfeita."))
	_refresh_all()

func _on_card_long_pressed(card: CardInstance) -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	CardZoom.show_card(card)

func _on_relic_pressed(id: String) -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	CardZoom.show_relic(id)

func _open_library() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	ZoneViewer.open(tr("GRIMÓRIO"), battle.deck.library, true)

func _open_graveyard() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	ZoneViewer.open(tr("CEMITÉRIO"), battle.deck.graveyard, false)

func _on_discard_toggled(on: bool) -> void:
	_discard_mode = on and battle.discards_left > 0
	if on and battle.discards_left <= 0:
		discard_btn.button_pressed = false
	for view in _hand_views.values():
		if is_instance_valid(view):
			view.modulate = DISCARD_TINT if _discard_mode else Color.WHITE
			view.playable = battle.can_play(view.card) or view.card.data.is_land() or _discard_mode
	if _discard_mode:
		_log(tr("Toca na carta a canalizar."))
		Sfx.select()

func _on_end_turn() -> void:
	if battle.resolving or battle.finished:
		return
	_bump(end_turn_btn, 0.92)
	end_turn_btn.disabled = true
	discard_btn.button_pressed = false
	discard_btn.disabled = true
	battle.end_turn()

func _on_enemy_ability(enemy_name_str: String, action: String) -> void:
	_log("%s %s!" % [tr(enemy_name_str), tr(ABILITY_LOG.get(action, action))])
	_flash(enemy_panel, Color(1.3, 1.1, 1.5))
	_refresh_all()

func _on_damage_dealt(target: String, amount: int) -> void:
	if target == "enemy":
		_log(tr("Causaste %s de dano.") % Cascade.fmt_int(amount))
		_animate_enemy_hit(amount)
	else:
		Sfx.hit()
		Settings.vibrate(60)
		_animate_enemy_strike()
		_shake(8.0)
		_flash(player_label, Color(2.0, 0.6, 0.6))
		_log(tr("Levaste %d de dano.") % amount)

func _on_battle_ended(victory: bool) -> void:
	pause_btn.disabled = true
	if victory:
		if GameState.ante >= GameState.max_ante and not GameState.endless:
			GameState.last_victory = true
			EventBus.run_ended.emit(true)
			_show_banner(tr("VITÓRIA"), 1.0)
			await get_tree().create_timer(_d(0.9)).timeout
			SceneRouter.go("run_over")
		else:
			_show_banner(tr("ANTE %d VENCIDO") % GameState.ante, 1.0)
			Sfx.boom()
			await get_tree().create_timer(_d(0.9)).timeout
			if GameState.has_event_after(GameState.ante):
				var ev := GameState.pick_event()
				if ev != "":
					GameState.pending_event = ev
					GameState.save_run({}, "event")
					SceneRouter.go("event")
					return
			SceneRouter.go("shop")
	else:
		GameState.last_victory = false
		EventBus.run_ended.emit(false)
		_show_banner(tr("DERROTA"), 1.0)
		await get_tree().create_timer(_d(1.0)).timeout
		SceneRouter.go("run_over")

# --- Arrastar para reordenar (tabuleiro e relíquias) ---

func _on_board_drag_started(card: CardInstance, pos: Vector2) -> void:
	if battle.resolving or battle.finished or _drag_ghost != null:
		return
	var view: Control = _board_views.get(card.uid)
	if not _alive(view):
		return
	_drag_view = view
	view.modulate.a = 0.35
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = view.size
	ghost.pivot_offset = ghost.size / 2.0
	ghost.scale = Vector2(1.06, 1.06)
	ghost.rotation = 0.04
	ghost.global_position = pos - ghost.size / 2.0
	_drag_ghost = ghost
	Settings.vibrate(15)

func _on_board_drag_moved(card: CardInstance, pos: Vector2) -> void:
	if _drag_ghost == null:
		return
	_drag_ghost.global_position = pos - _drag_ghost.size / 2.0
	var index := _index_for_x(board_box, pos.x, _drag_view)
	var current := battle.board.find(card)
	if index != current and index >= 0:
		battle.move_creature(card, index)
		board_box.move_child(_drag_view, index)
		_refresh_preview()

func _on_board_drag_ended(_card: CardInstance, _pos: Vector2) -> void:
	if _drag_ghost != null:
		_drag_ghost.queue_free()
		_drag_ghost = null
	if _alive(_drag_view):
		_drag_view.modulate.a = 1.0
		_bump(_drag_view, 1.08)
	_drag_view = null
	Sfx.select()
	_refresh_preview()

func _on_relic_drag_started(id: String, pos: Vector2) -> void:
	if battle.resolving or battle.finished or _drag_ghost != null:
		return
	var view: Control = _relic_views.get(id)
	if not _alive(view):
		return
	_drag_view = view
	view.modulate.a = 0.35
	var ghost: RelicView = RELIC_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(id)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = view.size
	ghost.global_position = pos - ghost.size / 2.0
	_drag_ghost = ghost

func _on_relic_drag_moved(id: String, pos: Vector2) -> void:
	if _drag_ghost == null:
		return
	_drag_ghost.global_position = pos - _drag_ghost.size / 2.0
	var index := _index_for_x(relics_bar, pos.x, _drag_view)
	var current := GameState.relic_ids.find(id)
	if index != current and index >= 0:
		GameState.relic_ids.erase(id)
		GameState.relic_ids.insert(clampi(index, 0, GameState.relic_ids.size()), id)
		relics_bar.move_child(_drag_view, index)
		_refresh_preview()

func _on_relic_drag_ended(_id: String, _pos: Vector2) -> void:
	_on_board_drag_ended(null, Vector2.ZERO)
	GameState.save_run(battle.to_dict(), "battle")

## Posição (índice) em que um item arrastado deve ficar numa fila horizontal, pela coordenada x.
func _index_for_x(box: Control, x: float, dragged: Control) -> int:
	var live := box.get_children().filter(func(c): return not c.is_queued_for_deletion())
	var index := 0
	for c in live:
		if c == dragged:
			continue
		var center: float = c.global_position.x + c.size.x / 2.0
		if x > center:
			index += 1
	return index

# --- Pausa ---

func _open_pause() -> void:
	if battle.finished or SceneRouter.has_overlay() or (_pause_menu != null and is_instance_valid(_pause_menu)):
		return
	Sfx.select()
	_pause_menu = PauseMenu.open(_pause_info())
	_pause_menu.abandoned.connect(_on_abandon)

func _pause_info() -> String:
	return "%s  ·  %s  ·  %s" % [
		GameState.deck_def.get("name", ""),
		tr("Turno %d/%d  ·  Ante %d") % [battle.turn, battle.max_turns + battle.extra_turns, GameState.ante],
		tr("Seed %d") % GameState.seed_value,
	]

func _on_abandon() -> void:
	GameState.abandon_run()
	SceneRouter.go("main")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		_open_pause()

# --- Cascata ---

func _on_cascade_started(cascade: Cascade) -> void:
	_animating = true
	end_turn_btn.disabled = true
	undo_btn.disabled = true
	enemy_hp_bar.value = enemy_hp_ghost.value   # durante a cascata a barra mostra a vida real
	for v in _hand_views.values():
		if _alive(v):
			v.delta = 0
	formation_label.text = tr("Ataque")
	power_label.text = "0"
	mult_label.text = "1"
	total_label.text = ""
	var shown_formations: Array[String] = []
	var i := 0
	var speed := Settings.anim_scale()
	for s in cascade.steps:
		var target := _view_for_step(s)
		var color := _color_for_step(s)
		if s.source_kind == "formation" and not s.retrigger:
			shown_formations.append(tr(s.source_name))
			formation_label.text = " · ".join(PackedStringArray(shown_formations))
		if s.source_kind == "creature" and s.action == "power_add":
			_lunge(target)
		_pop(target, ("↻ " if s.retrigger else "") + s.label, color)
		power_label.text = Cascade.fmt_int(s.power_after)
		mult_label.text = Cascade.fmt_mult(s.mult_after)
		_bump(power_pill if s.action == "power_add" else mult_pill)
		Sfx.blip(i)
		if speed > 0.0:
			await get_tree().create_timer(maxf(0.09, 0.28 - i * 0.012) * speed).timeout
		elif i % 4 == 3:
			await get_tree().process_frame
		i += 1
	total_label.text = Cascade.fmt_int(cascade.total())
	_bump(total_label, 1.5)
	_particles.global_position = total_label.global_position + total_label.size / 2.0
	_particles.restart()
	Sfx.boom()
	Settings.vibrate(50)
	_shake(10.0)
	await get_tree().create_timer(_d(0.5)).timeout
	_animating = false
	EventBus.cascade_finished.emit()

func _view_for_step(s: Cascade.Step) -> Control:
	match s.source_kind:
		"creature":
			if s.source_card != null and _board_views.has(s.source_card.uid):
				return _board_views[s.source_card.uid]
		"spell":
			if s.source_card != null and _spell_chips.has(s.source_card.uid):
				return _spell_chips[s.source_card.uid]
		"hand":
			if s.source_card != null and _hand_views.has(s.source_card.uid):
				return _hand_views[s.source_card.uid]
		"relic":
			if _relic_views.has(s.source_id):
				return _relic_views[s.source_id]
	return formation_label

func _color_for_step(s: Cascade.Step) -> Color:
	if s.grow > 0:
		return COLOR_GROW
	if s.source_kind == "formation":
		return COLOR_FORMATION
	match s.action:
		"power_add":
			return COLOR_POWER
		"mult_mul":
			return COLOR_MULT_X
		"gold":
			return COLOR_GOLD
	return COLOR_MULT

# --- Animações ---

func _alive(view) -> bool:
	return view != null and is_instance_valid(view) and not view.is_queued_for_deletion()

## Mata o tween guardado em meta (se existir) para nunca haver dois a disputar a mesma propriedade.
func _kill_tween(view: Object, key: String) -> void:
	if view.has_meta(key):
		var old = view.get_meta(key)
		if old is Tween and (old as Tween).is_valid():
			(old as Tween).kill()

## Pop da vista + etiqueta a flutuar por cima dela.
func _pop(view: Control, text: String, color: Color) -> void:
	if not _alive(view):
		return
	_bump(view, 1.22)
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", 26)
	label.add_theme_color_override("font_color", Color.WHITE)
	label.add_theme_color_override("font_outline_color", color.darkened(0.35))
	label.add_theme_constant_override("outline_size", 8)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(label)
	label.reset_size()
	var start := view.global_position + Vector2(view.size.x * 0.5 - label.size.x * 0.5, -label.size.y * 0.6)
	label.global_position = start
	var tw := create_tween().set_parallel(true)
	tw.tween_property(label, "global_position:y", start.y - 46.0, _d(0.6)).set_ease(Tween.EASE_OUT)
	tw.tween_property(label, "modulate:a", 0.0, _d(0.6)).set_delay(_d(0.25))
	tw.chain().tween_callback(label.queue_free)

## Escala rápida e volta a 1. Mata o bump anterior da mesma vista para nunca ficar a meio.
func _bump(view: Control, amount: float = 1.18) -> void:
	if not _alive(view):
		return
	view.pivot_offset = view.size / 2.0
	_kill_tween(view, "bump_tw")
	view.scale = Vector2.ONE
	var tw := create_tween()
	tw.tween_property(view, "scale", Vector2.ONE * amount, _d(0.07))
	tw.tween_property(view, "scale", Vector2.ONE, _d(0.13)).set_ease(Tween.EASE_OUT)
	view.set_meta("bump_tw", tw)

## Investida: a criatura inclina-se e salta para a frente (rotação + escala, não mexe no layout).
func _lunge(view: Control) -> void:
	if not _alive(view):
		return
	view.pivot_offset = view.size / 2.0
	_kill_tween(view, "lunge_tw")
	view.rotation = 0.0
	var tw := create_tween()
	tw.tween_property(view, "rotation", -0.16, _d(0.06))
	tw.tween_property(view, "rotation", 0.0, _d(0.16)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	view.set_meta("lunge_tw", tw)

func _flash(view: Control, color: Color) -> void:
	if not _alive(view):
		return
	_kill_tween(view, "flash_tw")
	var base := Color.WHITE
	if view in _hand_views.values() and _discard_mode:
		base = DISCARD_TINT
	view.modulate = color
	var tw := create_tween()
	tw.tween_property(view, "modulate", base, _d(0.35))
	view.set_meta("flash_tw", tw)

func _shake(strength: float) -> void:
	if Settings.anim_scale() <= 0.0:
		return
	var tw := create_tween()
	for i in 5:
		var off := Vector2(randf_range(-strength, strength), randf_range(-strength, strength)) * (1.0 - i / 5.0)
		tw.tween_property(layout, "position", _layout_base + off, 0.03)
	tw.tween_property(layout, "position", _layout_base, 0.04)

## Carta nova na mão: entra de baixo, a crescer.
func _animate_draw(view: CardView, delay: float) -> void:
	var target_alpha := view.modulate.a
	view.modulate.a = 0.0
	view.scale = Vector2(0.7, 0.7)
	await get_tree().process_frame
	if not _alive(view):
		return
	view.pivot_offset = view.size / 2.0
	var tw := create_tween().set_parallel(true)
	tw.tween_property(view, "modulate:a", target_alpha, _d(0.18)).set_delay(_d(delay))
	tw.tween_property(view, "scale", Vector2.ONE, _d(0.22)).set_delay(_d(delay)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)

## Carta jogada: um "fantasma" voa da posição na mão até ao sítio novo (tabuleiro, feitiços ou mana).
func _animate_play(card: CardInstance, from_rect: Rect2) -> void:
	if from_rect.size == Vector2.ZERO or Settings.anim_scale() <= 0.0:
		return
	await get_tree().process_frame   # deixa o layout colocar a vista nova
	var target: Control = null
	if card.data.is_creature():
		target = _board_views.get(card.uid)
	elif card.data.is_spell():
		target = _spell_chips.get(card.uid)
	else:
		target = mana_label
	if not _alive(target):
		return
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup(card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = from_rect.size
	ghost.global_position = from_rect.position
	ghost.pivot_offset = ghost.size / 2.0
	var real_target := target
	if card.data.is_creature():
		real_target.modulate.a = 0.0
	var dest := target.global_position + (target.size - ghost.size) / 2.0
	var end_scale := Vector2.ONE if card.data.is_creature() else Vector2(0.35, 0.35)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(ghost, "global_position", dest, _d(0.24)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUAD)
	tw.tween_property(ghost, "scale", end_scale, _d(0.24)).set_ease(Tween.EASE_IN)
	tw.tween_property(ghost, "rotation", 0.08, _d(0.12))
	await tw.finished
	if _alive(real_target):
		real_target.modulate.a = 1.0
		_bump(real_target, 1.12)
		if not card.data.is_creature():
			_flash(real_target, Color(1.8, 1.8, 1.8))
	if _alive(ghost):
		ghost.queue_free()
	Sfx.blip(0)

## Criatura morre: uma cópia cai e desvanece.
func _animate_death(view: Control) -> void:
	if not _alive(view) or Settings.anim_scale() <= 0.0:
		return
	var ghost: CardView = CARD_VIEW.instantiate()
	add_child(ghost)
	ghost.setup((view as CardView).card)
	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.size = view.size
	ghost.global_position = view.global_position
	ghost.pivot_offset = ghost.size / 2.0
	ghost.modulate = Color(1.0, 0.5, 0.5)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(ghost, "global_position:y", ghost.global_position.y + 60.0, _d(0.4)).set_ease(Tween.EASE_IN)
	tw.tween_property(ghost, "rotation", 0.5, _d(0.4))
	tw.tween_property(ghost, "modulate:a", 0.0, _d(0.4))
	tw.chain().tween_callback(ghost.queue_free)

## O inimigo encaixa o golpe: flash vermelho, abanão e o número de dano a voar do total até ele.
func _animate_enemy_hit(amount: int) -> void:
	_flash(enemy_panel, Color(2.0, 0.7, 0.7))
	_bump(enemy_panel, 0.94)
	var label := Label.new()
	label.text = "-" + Cascade.fmt_int(amount)
	label.add_theme_font_size_override("font_size", 44)
	label.add_theme_color_override("font_color", Color(1, 0.92, 0.6))
	label.add_theme_color_override("font_outline_color", Color(0.4, 0.1, 0.1))
	label.add_theme_constant_override("outline_size", 10)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(label)
	label.reset_size()
	label.global_position = total_label.global_position
	var dest := enemy_panel.global_position + Vector2(enemy_panel.size.x * 0.5 - label.size.x * 0.5, 40.0)
	var tw := create_tween()
	tw.tween_property(label, "global_position", dest, _d(0.35)).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
	tw.tween_callback(func(): _flash(enemy_hp_bar, Color(2.5, 1.5, 1.5)))
	tw.tween_property(label, "modulate:a", 0.0, _d(0.4))
	tw.tween_callback(label.queue_free)

## O inimigo contra-ataca: salta para a direita (rotação) e o ecrã abana.
func _animate_enemy_strike() -> void:
	if not _alive(enemy_panel):
		return
	enemy_panel.pivot_offset = enemy_panel.size / 2.0
	var tw := create_tween()
	tw.tween_property(enemy_panel, "rotation", 0.06, _d(0.07))
	tw.tween_property(enemy_panel, "rotation", 0.0, _d(0.2)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	_flash(enemy_panel, Color(1.4, 1.4, 1.4))

## Banner central (ANTE N / TURNO N / VITÓRIA).
func _show_banner(text: String, hold: float = 1.1) -> void:
	banner.text = text
	banner.visible = true
	banner.pivot_offset = banner.size / 2.0
	banner.scale = Vector2(0.6, 0.6)
	banner.modulate.a = 0.0
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(banner, "scale", Vector2.ONE, _d(0.3)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tw.tween_property(banner, "modulate:a", 1.0, _d(0.2))
	tw.chain().tween_interval(maxf(0.05, _d(hold)))
	tw.chain().tween_property(banner, "modulate:a", 0.0, _d(0.3))
	tw.chain().tween_callback(func(): banner.visible = false)

func _log(msg: String) -> void:
	log_label.text = msg
	log_label.modulate = Color(1, 0.85, 0.5)
	create_tween().tween_property(log_label, "modulate", Color.WHITE, 0.8)
