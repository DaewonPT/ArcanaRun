class_name PauseMenu
extends Control
## Menu de pausa da batalha: Continuar, Configurações, Como Jogar, Sair para o menu, Abandonar run (com
## confirmação). Fica por cima da batalha sem a destruir; a run já está gravada no início do turno.
## 0.14.2: SAIR PARA O MENU grava a batalha tal como está e volta ao menu (continua-se em CONTINUAR).

signal resumed
signal abandoned
signal exited   # 0.14.2: sair para o menu sem abandonar a run

## 0.14.2: o botão SAIR PARA O MENU — não aparece (enigmas, lições, treino), pode-se usar, ou espera pelo
## fim do ataque (fica desligado até começar o turno seguinte).
enum Exit { NONE, OK, WAIT }

var _info: Label
var _abandon_btn: Button
var _exit_btn: Button
var _confirming := false
var _confirm_id := 0

## 0.13.0: replay (opcional) mostra "REVER ATAQUE" ao lado de VER BARALHO.
## 0.16.0 (V47): summary (opcional) põe por cima um resumo em imagem — {deck, colors, line, ante, max_ante,
## stake, climate, climate_id, enemy, foot}; sem ele (enigmas, lições, treino) fica só o texto.
static func open(info_text: String, replay: Callable = Callable(), exit_mode: Exit = Exit.NONE, summary: Dictionary = {}) -> PauseMenu:
	var m := PauseMenu.new()
	SceneRouter.show_overlay(m)
	m._replay = replay
	m._exit_mode = exit_mode
	m._summary = summary
	m._build(info_text)
	return m

var _replay: Callable
var _exit_mode: Exit = Exit.NONE
var _summary: Dictionary = {}

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.72))

func _build(info_text: String) -> void:
	# 0.16.0 (V44 + V47): a moldura comum e, nas runs, o resumo em imagem; os botões com ícones.
	var body := UiKit.window(self, 500, tr("Pausa"), UiKit.GOLD, close)
	var panel: Control = body.get_meta("panel")
	if not _summary.is_empty():
		body.add_child(_summary_view())
	var resume := UiKit.button(tr("CONTINUAR"), 60, 24, UiKit.PRIMARY, Color(0, 0, 0, 0))
	resume.name = "ResumeBtn"
	resume.set_meta("haptic", true)
	UiKit.button_icon(resume, "play", Color.WHITE, 22.0, false)
	UiKit.gold_plate(resume, true)
	resume.pressed.connect(func(): Sfx.select(); close())
	body.add_child(resume)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	if GameState.puzzle_id == "":
		var deck_btn := UiKit.button(tr("VER BARALHO (%d)") % GameState.deck.size(), 54, 20)
		deck_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		UiKit.button_icon(deck_btn, "cards", Color(0.88, 0.85, 0.96), 20.0, false)
		deck_btn.pressed.connect(func(): Sfx.select(); ZoneViewer.open_deck(tr("O TEU BARALHO")))
		row.add_child(deck_btn)
	if _replay.is_valid():
		var replay_btn := UiKit.button(tr("REVER ATAQUE"), 54, 20)
		replay_btn.name = "ReplayBtn"
		replay_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		UiKit.button_icon(replay_btn, "replay", Color(0.88, 0.85, 0.96), 20.0, false)
		replay_btn.pressed.connect(func():
			Sfx.select()
			var cb := _replay
			close()
			cb.call())
		row.add_child(replay_btn)
	if row.get_child_count() > 0:
		body.add_child(row)
	var row2 := HBoxContainer.new()
	row2.add_theme_constant_override("separation", 10)
	body.add_child(row2)
	var settings := UiKit.button(tr("CONFIGURAÇÕES"), 54, 19)
	settings.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	UiKit.button_icon(settings, "gear", Color(0.88, 0.85, 0.96), 20.0, false)
	settings.pressed.connect(func(): Sfx.select(); SettingsMenu.open())
	row2.add_child(settings)
	var howto := UiKit.button(tr("COMO JOGAR"), 54, 19)
	howto.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	UiKit.button_icon(howto, "book", Color(0.88, 0.85, 0.96), 20.0, false)
	howto.pressed.connect(func(): Sfx.select(); HowToPlay.open_overlay())
	row2.add_child(howto)
	if _exit_mode != Exit.NONE:
		_exit_btn = UiKit.button(tr("SAIR PARA O MENU"), 54, 21)
		_exit_btn.name = "ExitBtn"
		UiKit.button_icon(_exit_btn, "menu", Color(0.88, 0.85, 0.96), 20.0, false)
		_exit_btn.pressed.connect(_on_exit)
		body.add_child(_exit_btn)
		if _exit_mode == Exit.WAIT:
			_set_exit_waiting(true)
			EventBus.turn_started.connect(_on_turn_started)
	_abandon_btn = UiKit.button(tr("ABANDONAR RUN"), 54, 21, UiKit.DANGER, Color(0, 0, 0, 0))
	UiKit.button_icon(_abandon_btn, "flag", Color.WHITE, 20.0, false)
	_abandon_btn.pressed.connect(_on_abandon)
	body.add_child(_abandon_btn)
	_info = UiKit.label(String(_summary.get("foot", info_text)) if not _summary.is_empty() else info_text, 14 if not _summary.is_empty() else 17, UiKit.TEXT_DIM, true)
	_info.name = "Info"
	_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	body.add_child(_info)
	UiKit.pop_in(panel)
	Settings.changed.connect(_refresh_texts)

## V47: o sigilo das cores do baralho, o nome, o ato/ante/turno, os antes numa barra e o Selo, o clima e o
## inimigo em pastilhas (o clima abre-se ao tocar).
func _summary_view() -> Control:
	var v := VBoxContainer.new()
	v.name = "Summary"
	v.add_theme_constant_override("separation", 8)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 12)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(top)
	var cols: Array = _summary.get("colors", [])
	var disc := Control.new()
	disc.name = "DeckColors"
	disc.custom_minimum_size = Vector2(48, 48)
	disc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	disc.draw.connect(func():
		var c := disc.size * 0.5
		var r := minf(disc.size.x, disc.size.y) * 0.5 - 3.0
		var n := maxi(1, cols.size())
		for k in n:
			var col: Color = CardView.COLORS.get(String(cols[k]) if k < cols.size() else "colorless", CardView.COLORS.colorless)
			var pts := PackedVector2Array([c])
			for i in 13:
				var a := -PI / 2.0 + TAU * (k + float(i) / 12.0) / n
				pts.append(c + Vector2(cos(a), sin(a)) * r)
			disc.draw_colored_polygon(pts, col)
		var st := StyleBoxFlat.new()
		st.draw_center = false
		st.set_border_width_all(3)
		st.border_color = UiKit.GOLD
		st.set_corner_radius_all(24)
		disc.draw_style_box(st, Rect2(Vector2.ZERO, disc.size)))
	top.add_child(disc)
	var names := VBoxContainer.new()
	names.add_theme_constant_override("separation", 0)
	names.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	names.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(names)
	names.add_child(UiKit.label(String(_summary.get("deck", "")), 21, Color.WHITE))
	names.add_child(UiKit.label(String(_summary.get("line", "")), 14, UiKit.TEXT_DIM))
	var mx := int(_summary.get("max_ante", 0))
	var ante := int(_summary.get("ante", 1))
	if mx > 1 and mx <= 16:
		var bar := Control.new()
		bar.name = "AnteBar"
		bar.custom_minimum_size = Vector2(0, 12)
		bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
		bar.tooltip_text = tr("Ante %d de %d") % [ante, mx]
		bar.draw.connect(func():
			var gap := 4.0
			var w := (bar.size.x - gap * (mx - 1)) / mx
			for k in mx:
				var r := Rect2(Vector2(k * (w + gap), 1.0), Vector2(w, 10.0))
				var st := StyleBoxFlat.new()
				st.set_corner_radius_all(5)
				if k + 1 < ante:
					st.bg_color = Color(0.92, 0.66, 0.24)
				elif k + 1 == ante:
					st.bg_color = Color(1.0, 0.83, 0.42)
					st.shadow_color = Color(1.0, 0.83, 0.42, 0.6)
					st.shadow_size = 4
				else:
					st.bg_color = Color(1, 1, 1, 0.1)
				bar.draw_style_box(st, r))
		v.add_child(bar)
	var pills := HBoxContainer.new()
	pills.add_theme_constant_override("separation", 8)
	pills.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(pills)
	pills.add_child(_pill("seal", tr("Selo %d") % int(_summary.get("stake", 1)), Color(0.78, 0.5, 1.0)))
	var climate := String(_summary.get("climate", ""))
	if climate != "":
		var cp := _pill("climate", climate, Color(0.4, 0.84, 0.86))
		cp.name = "ClimatePill"
		cp.mouse_filter = Control.MOUSE_FILTER_STOP
		var cid := String(_summary.get("climate_id", ""))
		cp.gui_input.connect(func(ev: InputEvent):
			if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed:
				accept_event()
				Sfx.select()
				CardZoom.show_climate(cid))
		pills.add_child(cp)
	if String(_summary.get("enemy", "")) != "":
		pills.add_child(_pill("skull", String(_summary.get("enemy", "")), Color(1.0, 0.62, 0.55)))
	return v

func _pill(kind: String, text: String, col: Color) -> PanelContainer:
	var p := PanelContainer.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_theme_stylebox_override("panel", UiKit.flat(Color(1, 1, 1, 0.06), 16, Color(1, 1, 1, 0.12), 1, 6))
	var row := UiKit.icon_text(kind, text, 15, Color(0.9, 0.88, 0.95), col)
	p.add_child(row)
	return p

func set_info(text: String) -> void:
	if _info:
		_info.text = text

func _refresh_texts() -> void:
	if _abandon_btn and not _confirming:
		_abandon_btn.text = tr("ABANDONAR RUN")
	if _exit_btn:
		_set_exit_waiting(_exit_btn.disabled)

## 0.14.2: a meio do ataque o SAIR fica desligado (assim não dá para refazer um ataque que correu mal).
func _set_exit_waiting(waiting: bool) -> void:
	if _exit_btn == null or not is_instance_valid(_exit_btn):
		return
	_exit_btn.disabled = waiting
	_exit_btn.text = tr("SAIR PARA O MENU (no fim do ataque)") if waiting else tr("SAIR PARA O MENU")
	_exit_btn.add_theme_font_size_override("font_size", 20 if waiting else 24)

## O ataque acabou e começou o turno seguinte: já se pode sair.
func _on_turn_started(_t: int) -> void:
	_set_exit_waiting(false)

func _on_exit() -> void:
	if _exit_btn == null or _exit_btn.disabled or is_queued_for_deletion():
		return
	Sfx.select()
	exited.emit()
	queue_free()

func _on_abandon() -> void:
	if _confirming:
		Sfx.hit()
		abandoned.emit()
		queue_free()
		return
	Sfx.select()
	_confirming = true
	_confirm_id += 1
	var id := _confirm_id
	_abandon_btn.text = tr("TENS A CERTEZA? TOCA OUTRA VEZ")
	await get_tree().create_timer(3.0).timeout
	if id == _confirm_id and is_instance_valid(_abandon_btn) and not is_queued_for_deletion():
		_confirming = false
		_abandon_btn.text = tr("ABANDONAR RUN")

func _gui_input(event: InputEvent) -> void:
	# Toque fora do painel = continuar.
	if event is InputEventMouseButton and not event.pressed:
		accept_event()
		close()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	resumed.emit()
	UiKit.close_animated(self)
