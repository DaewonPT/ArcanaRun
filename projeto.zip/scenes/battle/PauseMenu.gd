class_name PauseMenu
extends Control
## Menu de pausa da batalha: Continuar, Configurações, Como Jogar, Abandonar run (com confirmação).
## Fica por cima da batalha sem a destruir; a run já está gravada no início do turno.

signal resumed
signal abandoned

var _info: Label
var _abandon_btn: Button
var _confirming := false
var _confirm_id := 0

static func open(info_text: String) -> PauseMenu:
	var m := PauseMenu.new()
	SceneRouter.show_overlay(m)
	m._build(info_text)
	return m

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.72))

func _build(info_text: String) -> void:
	var panel := UiKit.centered_panel(self, 520)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	panel.add_child(vbox)
	var title := UiKit.label(tr("PAUSA"), 44, UiKit.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	_info = UiKit.label(info_text, 18, UiKit.TEXT_DIM, true)
	_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(_info)

	var resume := UiKit.button(tr("CONTINUAR"), 66, 26, UiKit.PRIMARY, Color(0, 0, 0, 0))
	resume.pressed.connect(func(): Sfx.select(); close())
	vbox.add_child(resume)
	var settings := UiKit.button(tr("CONFIGURAÇÕES"), 60, 24)
	settings.pressed.connect(func(): Sfx.select(); SettingsMenu.open())
	vbox.add_child(settings)
	var howto := UiKit.button(tr("COMO JOGAR"), 60, 24)
	howto.pressed.connect(func(): Sfx.select(); HowToPlay.open_overlay())
	vbox.add_child(howto)
	if GameState.puzzle_id == "":
		var deck_btn := UiKit.button(tr("VER BARALHO (%d)") % GameState.deck.size(), 60, 24)
		deck_btn.pressed.connect(func(): Sfx.select(); ZoneViewer.open_deck(tr("O TEU BARALHO")))
		vbox.add_child(deck_btn)
	_abandon_btn = UiKit.button(tr("ABANDONAR RUN"), 60, 24, UiKit.DANGER, Color(0, 0, 0, 0))
	_abandon_btn.pressed.connect(_on_abandon)
	vbox.add_child(_abandon_btn)
	UiKit.pop_in(panel)
	Settings.changed.connect(_refresh_texts)

func set_info(text: String) -> void:
	if _info:
		_info.text = text

func _refresh_texts() -> void:
	if _abandon_btn and not _confirming:
		_abandon_btn.text = tr("ABANDONAR RUN")

func _on_abandon() -> void:
	if _confirming:
		Sfx.hit()
		abandoned.emit()
		queue_free()
		return
	Sfx.select()
	_confirming = true
	_confirm_id += 1
	var id := _confirm_id
	_abandon_btn.text = tr("TENS A CERTEZA? TOCA OUTRA VEZ")
	await get_tree().create_timer(3.0).timeout
	if id == _confirm_id and is_instance_valid(_abandon_btn) and not is_queued_for_deletion():
		_confirming = false
		_abandon_btn.text = tr("ABANDONAR RUN")

func _gui_input(event: InputEvent) -> void:
	# Toque fora do painel = continuar.
	if event is InputEventMouseButton and not event.pressed:
		accept_event()
		close()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	resumed.emit()
	queue_free()
