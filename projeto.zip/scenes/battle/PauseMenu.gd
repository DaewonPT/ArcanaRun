class_name PauseMenu
extends Control
## Menu de pausa da batalha: Continuar, Configurações, Como Jogar, Sair para o menu, Abandonar run (com
## confirmação). Fica por cima da batalha sem a destruir; a run já está gravada no início do turno.
## 0.14.2: SAIR PARA O MENU grava a batalha tal como está e volta ao menu (continua-se em CONTINUAR).

signal resumed
signal abandoned
signal exited   # 0.14.2: sair para o menu sem abandonar a run

## 0.14.2: o botão SAIR PARA O MENU — não aparece (enigmas, lições, treino), pode-se usar, ou espera pelo
## fim do ataque (fica desligado até começar o turno seguinte).
enum Exit { NONE, OK, WAIT }

var _info: Label
var _abandon_btn: Button
var _exit_btn: Button
var _confirming := false
var _confirm_id := 0

## 0.13.0: replay (opcional) mostra "REVER ATAQUE" ao lado de VER BARALHO.
static func open(info_text: String, replay: Callable = Callable(), exit_mode: Exit = Exit.NONE) -> PauseMenu:
	var m := PauseMenu.new()
	SceneRouter.show_overlay(m)
	m._replay = replay
	m._exit_mode = exit_mode
	m._build(info_text)
	return m

var _replay: Callable
var _exit_mode: Exit = Exit.NONE

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.72))

func _build(info_text: String) -> void:
	var panel := UiKit.centered_panel(self, 520)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	panel.add_child(vbox)
	var title := UiKit.label(tr("PAUSA"), 44, UiKit.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	_info = UiKit.label(info_text, 18, UiKit.TEXT_DIM, true)
	_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(_info)

	var resume := UiKit.button(tr("CONTINUAR"), 66, 26, UiKit.PRIMARY, Color(0, 0, 0, 0))
	resume.pressed.connect(func(): Sfx.select(); close())
	vbox.add_child(resume)
	var settings := UiKit.button(tr("CONFIGURAÇÕES"), 60, 24)
	settings.pressed.connect(func(): Sfx.select(); SettingsMenu.open())
	vbox.add_child(settings)
	var howto := UiKit.button(tr("COMO JOGAR"), 60, 24)
	howto.pressed.connect(func(): Sfx.select(); HowToPlay.open_overlay())
	vbox.add_child(howto)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	if GameState.puzzle_id == "":
		var deck_btn := UiKit.button(tr("VER BARALHO (%d)") % GameState.deck.size(), 60, 22)
		deck_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		deck_btn.pressed.connect(func(): Sfx.select(); ZoneViewer.open_deck(tr("O TEU BARALHO")))
		row.add_child(deck_btn)
	if _replay.is_valid():
		var replay_btn := UiKit.button(tr("REVER ATAQUE"), 60, 22)
		replay_btn.name = "ReplayBtn"
		replay_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		replay_btn.pressed.connect(func():
			Sfx.select()
			var cb := _replay
			close()
			cb.call())
		row.add_child(replay_btn)
	if row.get_child_count() > 0:
		vbox.add_child(row)
	if _exit_mode != Exit.NONE:
		_exit_btn = UiKit.button(tr("SAIR PARA O MENU"), 60, 24)
		_exit_btn.name = "ExitBtn"
		_exit_btn.pressed.connect(_on_exit)
		vbox.add_child(_exit_btn)
		if _exit_mode == Exit.WAIT:
			_set_exit_waiting(true)
			EventBus.turn_started.connect(_on_turn_started)
	_abandon_btn = UiKit.button(tr("ABANDONAR RUN"), 60, 24, UiKit.DANGER, Color(0, 0, 0, 0))
	_abandon_btn.pressed.connect(_on_abandon)
	vbox.add_child(_abandon_btn)
	UiKit.pop_in(panel)
	Settings.changed.connect(_refresh_texts)

func set_info(text: String) -> void:
	if _info:
		_info.text = text

func _refresh_texts() -> void:
	if _abandon_btn and not _confirming:
		_abandon_btn.text = tr("ABANDONAR RUN")
	if _exit_btn:
		_set_exit_waiting(_exit_btn.disabled)

## 0.14.2: a meio do ataque o SAIR fica desligado (assim não dá para refazer um ataque que correu mal).
func _set_exit_waiting(waiting: bool) -> void:
	if _exit_btn == null or not is_instance_valid(_exit_btn):
		return
	_exit_btn.disabled = waiting
	_exit_btn.text = tr("SAIR PARA O MENU (no fim do ataque)") if waiting else tr("SAIR PARA O MENU")
	_exit_btn.add_theme_font_size_override("font_size", 20 if waiting else 24)

## O ataque acabou e começou o turno seguinte: já se pode sair.
func _on_turn_started(_t: int) -> void:
	_set_exit_waiting(false)

func _on_exit() -> void:
	if _exit_btn == null or _exit_btn.disabled or is_queued_for_deletion():
		return
	Sfx.select()
	exited.emit()
	queue_free()

func _on_abandon() -> void:
	if _confirming:
		Sfx.hit()
		abandoned.emit()
		queue_free()
		return
	Sfx.select()
	_confirming = true
	_confirm_id += 1
	var id := _confirm_id
	_abandon_btn.text = tr("TENS A CERTEZA? TOCA OUTRA VEZ")
	await get_tree().create_timer(3.0).timeout
	if id == _confirm_id and is_instance_valid(_abandon_btn) and not is_queued_for_deletion():
		_confirming = false
		_abandon_btn.text = tr("ABANDONAR RUN")

func _gui_input(event: InputEvent) -> void:
	# Toque fora do painel = continuar.
	if event is InputEventMouseButton and not event.pressed:
		accept_event()
		close()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	resumed.emit()
	queue_free()
