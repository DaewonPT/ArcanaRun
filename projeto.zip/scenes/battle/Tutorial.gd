class_name TutorialOverlay
extends Control
## Tutorial guiado da primeira batalha: um painel com instruções e uma seta a apontar para o
## alvo. Não bloqueia os toques — o jogador faz mesmo as jogadas; cada passo avança com o sinal
## correspondente (carta jogada, ataque, canalização) ou com CONTINUAR. Vive dentro da cena
## Battle (não na camada de overlays), para a pausa e o zoom continuarem a funcionar.

var _battle: Control
var _panel: PanelContainer
var _text: Label
var _next_btn: Button
var _arrow: Label
var _step := 0
var _steps: Array = []
var _waiting_turn := false
var _from := "mulligan"   # D12: passo por onde começa (batalha retomada)
var _bounce_tw: Tween     # o vaivém da seta (um só de cada vez)

static func open(battle_scene: Control, from_step: String = "mulligan") -> TutorialOverlay:
	var t := TutorialOverlay.new()
	t._battle = battle_scene
	t._from = from_step
	battle_scene.add_child(t)
	return t

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _ready() -> void:
	# Os números («Tens %d turnos», «Tens %d por batalha») só se escrevem quando o passo aparece (_step_text).
	_steps = [
		{"id": "mulligan", "target": "%MulliganBtn", "text": tr("Se a mão não te agradar, MULLIGAN dá-te uma mão nova (uma carta vai para o fundo). Só no turno 1, antes de jogares."), "signal": "", "until": ["mulligan_taken", "card_played", "card_discarded", "cascade_started", "turn_started"]},
		{"id": "play", "target": "hand", "text": tr("Bem-vindo. Toca numa carta jogável para a escolher e toca outra vez (ou arrasta-a para cima) para a pôr no tabuleiro. O número verde em cada carta é quanto o teu ataque sobe se a jogares."), "signal": "card_played", "until": ["cascade_started"]},
		{"id": "attack", "target": "%EndTurn", "text": tr("Agora carrega em ATACAR. As criaturas e os feitiços somam Poder × Mult numa cascata — vê a barra do inimigo encher-se de claro antes de atacar."), "signal": "cascade_started"},
		{"id": "mult", "target": "%MultPill", "text": tr("O Poder soma-se e o Mult multiplica. O Mult vem das cartas, das relíquias e das FORMAÇÕES, que são combinações de cartas na Arena. A ordem na Arena conta: arrasta para trocar."), "signal": "", "after_turn": true},
		{"id": "enemy", "target": "%EnemyPanel", "text": tr("O inimigo contra-atacou. Neste painel vês quem bloqueia, quanto levas e o que ele faz a seguir. A tua vida atravessa a run inteira — cura-se na loja."), "signal": ""},
		{"id": "channel", "target": "%DiscardBtn", "text": tr("CANALIZAR: liga o botão e toca numa carta da mão para a trocar por outra. Tens %d por batalha."), "signal": "card_discarded", "skippable": true},
		{"id": "undo", "target": "%UndoBtn", "text": tr("DESFAZER anula a última jogada do turno. Segurar uma carta mostra-a em grande; arrasta as cartas da mão e as criaturas do tabuleiro para lhes mudar a ordem."), "signal": ""},
		{"id": "graveyard", "target": "%GraveyardBtn", "text": tr("Feitiços com ↺ lançam-se do CEMITÉRIO uma segunda vez. Depois da batalha escolhes o caminho no mapa. Boa sorte."), "signal": ""},
	]
	for i in _steps.size():
		if String(_steps[i]["id"]) == _from:
			_step = i
	_build()
	EventBus.card_played.connect(func(_c): _on_signal("card_played"))
	EventBus.cascade_started.connect(func(_c): _on_signal("cascade_started"))
	EventBus.card_discarded.connect(func(_c): _on_signal("card_discarded"))
	EventBus.mulligan_taken.connect(func(_n): _on_signal("mulligan_taken"))   # o botão some: segue para «jogar uma carta»
	EventBus.turn_started.connect(_on_turn_started)
	EventBus.battle_ended.connect(func(_v): _finish())
	_show_step()

func _build() -> void:
	_panel = PanelContainer.new()
	_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	_panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.1, 0.09, 0.16, 0.97), 14, UiKit.GOLD, 2, 14))
	_panel.custom_minimum_size = Vector2(560, 0)
	add_child(_panel)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	_panel.add_child(vbox)
	var head := HBoxContainer.new()
	vbox.add_child(head)
	var title := UiKit.label(tr("TUTORIAL"), 16, UiKit.GOLD)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	var skip := UiKit.button(tr("SALTAR TUTORIAL"), 34, 14)
	skip.pressed.connect(func(): Sfx.select(); _finish())
	head.add_child(skip)
	_text = UiKit.label("", 18, Color.WHITE, true)
	vbox.add_child(_text)
	_next_btn = UiKit.button(tr("CONTINUAR  ▶"), 44, 18, UiKit.PRIMARY, Color(0, 0, 0, 0))
	_next_btn.pressed.connect(func(): Sfx.select(); _advance())
	vbox.add_child(_next_btn)
	_arrow = Label.new()
	_arrow.text = "▼"
	_arrow.add_theme_font_size_override("font_size", 40)
	_arrow.add_theme_color_override("font_color", UiKit.GOLD)
	_arrow.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	_arrow.add_theme_constant_override("outline_size", 8)
	_arrow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_arrow)

func _target_control() -> Control:
	var key := String(_steps[_step].get("target", ""))
	if key == "hand":
		var hand: Container = _battle.get_node("%Hand")
		for v in hand.get_children():
			if v is CardView and v.playable and not v.card.data.is_land():
				return v
		return hand
	return _battle.get_node(key)

func _show_step() -> void:
	if _step >= _steps.size():
		_finish()
		return
	var st: Dictionary = _steps[_step]
	if String(st.get("id", "")) == "channel" and _channels() == 0:   # Inverno Eterno: não há canalizações nesta batalha
		_step += 1
		_show_step()
		return
	_text.text = _step_text(st)
	var needs_signal := String(st.get("signal", "")) != ""
	_next_btn.visible = not needs_signal or bool(st.get("skippable", false))
	_next_btn.text = tr("SALTAR PASSO  ▶") if (needs_signal and bool(st.get("skippable", false))) else tr("CONTINUAR  ▶")
	_waiting_turn = bool(st.get("after_turn", false))
	_panel.visible = not _waiting_turn
	_arrow.visible = not _waiting_turn
	await get_tree().process_frame
	_place()
	UiKit.pop_in(_panel)

## Canalizações desta batalha (as que há mais as já gastas).
func _channels() -> int:
	var bm: BattleManager = _battle.get("battle")
	return bm.discards_left + bm.discards_used

## O texto de um passo, com os números da batalha como estão agora (um turno extra ou um ataque antes do passo
## mudam-nos depois de o tutorial abrir).
func _step_text(st: Dictionary) -> String:
	var bm: BattleManager = _battle.get("battle")
	var txt := String(st.get("text", ""))
	match String(st.get("id", "")):
		"attack":
			return txt + " " + tr("Tens %d turnos para o derrotar.") % (bm.max_turns + bm.extra_turns)
		"channel":
			return txt % _channels()
	return txt

## Espera que o letreiro do turno («TURNO 2») saia: desenha-se por cima da seta. No máximo 3 s.
func _banner_gone() -> void:
	var banner := _battle.get("banner") as Control
	var limit := Time.get_ticks_msec() + 3000
	while banner != null and is_instance_valid(banner) and banner.visible and Time.get_ticks_msec() < limit:
		await get_tree().process_frame

## Painel no topo do centro (sobre o tabuleiro); seta por cima do alvo.
func _place() -> void:
	if not is_inside_tree():
		return
	var vp := get_viewport().get_visible_rect().size
	_panel.reset_size()
	_panel.global_position = Vector2(vp.x * 0.5 - _panel.size.x * 0.5 + 150.0, 78.0)
	var target := _target_control()
	if target == null or not is_instance_valid(target):
		_arrow.visible = false
		return
	var r := target.get_global_rect()
	_arrow.reset_size()
	# Seta a apontar para baixo, encostada ao topo do alvo; se o alvo está no topo, aponta para cima.
	if r.position.y > 140.0:
		_arrow.text = "▼"
		_arrow.global_position = Vector2(r.position.x + r.size.x * 0.5 - _arrow.size.x * 0.5, r.position.y - _arrow.size.y - 2.0)
	else:
		_arrow.text = "▲"
		_arrow.global_position = Vector2(r.position.x + r.size.x * 0.5 - _arrow.size.x * 0.5, r.end.y + 2.0)
	_bounce()

func _bounce() -> void:
	_stop_bounce()   # D12: dois _show_step seguidos não deixam dois tweens a mexer na seta
	_bounce_tw = create_tween().set_loops()
	_bounce_tw.tween_property(_arrow, "position:y", _arrow.position.y - 8.0, 0.35).set_ease(Tween.EASE_IN_OUT)
	_bounce_tw.tween_property(_arrow, "position:y", _arrow.position.y, 0.35).set_ease(Tween.EASE_IN_OUT)

func _stop_bounce() -> void:
	if _bounce_tw != null and _bounce_tw.is_valid():
		_bounce_tw.kill()
	_bounce_tw = null

func _on_signal(sig: String) -> void:
	# D12: os passos com esse sinal no «until» deixam de fazer sentido (jogar, canalizar ou atacar no MULLIGAN, atacar
	# sem jogar); um ATACAR no MULLIGAN passa o MULLIGAN e o «jogar», e o ATACAR à espera dele avança a seguir.
	while _step < _steps.size() and sig in (_steps[_step].get("until", []) as Array):
		_advance()
	if _step < _steps.size() and String(_steps[_step].get("signal", "")) == sig:
		_advance()

func _on_turn_started(_t: int) -> void:
	_on_signal("turn_started")   # D12: ATACAR sem nada na Arena não faz cascata; no turno 2 o MULLIGAN já passou
	# O passo do Mult espera que o contra-ataque aconteça (início do turno seguinte) para aparecer.
	if _waiting_turn:
		_waiting_turn = false
		var step := _step
		await get_tree().process_frame   # o letreiro do turno aparece neste frame
		await _banner_gone()
		if not is_inside_tree() or _step != step:   # saltou o tutorial ou o passo andou enquanto esperava
			return
		_panel.visible = true
		_arrow.visible = true
		await get_tree().process_frame
		_place()
		UiKit.pop_in(_panel)
	elif _step < _steps.size():
		_place()

func _advance() -> void:
	_stop_bounce()
	_step += 1
	_show_step()

func _finish() -> void:
	if is_queued_for_deletion():
		return
	Stats.set_tutorial_done(true)
	queue_free()
