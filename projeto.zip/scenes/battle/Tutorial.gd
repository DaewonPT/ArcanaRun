class_name TutorialOverlay
extends Control
## Tutorial guiado da primeira batalha: um painel com instruções e uma seta a apontar para o
## alvo. Não bloqueia os toques — o jogador faz mesmo as jogadas; cada passo avança com o sinal
## correspondente (carta jogada, ataque, canalização) ou com CONTINUAR. Vive dentro da cena
## Battle (não na camada de overlays), para a pausa e o zoom continuarem a funcionar.

var _battle: Control
var _panel: PanelContainer
var _text: Label
var _next_btn: Button
var _arrow: Label
var _step := 0
var _steps: Array = []
var _waiting_turn := false

static func open(battle_scene: Control) -> TutorialOverlay:
	var t := TutorialOverlay.new()
	t._battle = battle_scene
	battle_scene.add_child(t)
	return t

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _ready() -> void:
	_steps = [
		{"target": "hand", "text": tr("Bem-vindo. Toca numa carta jogável para a escolher e toca outra vez (ou arrasta-a para cima) para a pôr no tabuleiro. O número verde em cada carta é quanto o teu ataque sobe se a jogares."), "signal": "card_played"},
		{"target": "%EndTurn", "text": tr("Agora carrega em ATACAR. As criaturas e os feitiços somam Poder × Mult numa cascata — vê a barra do inimigo encher-se de claro antes de atacar."), "signal": "cascade_started"},
		{"target": "%EnemyPanel", "text": tr("O inimigo contra-atacou. Neste painel vês quem bloqueia, quanto levas e o que ele faz a seguir. A tua vida atravessa a run inteira — cura-se na loja."), "signal": "", "after_turn": true},
		{"target": "%DiscardBtn", "text": tr("CANALIZAR: liga o botão e toca numa carta da mão para a trocar por outra. Tens 3 por batalha."), "signal": "card_discarded", "skippable": true},
		{"target": "%UndoBtn", "text": tr("DESFAZER anula a última jogada do turno. Segurar uma carta mostra-a em grande; arrasta as cartas da mão e as criaturas do tabuleiro para lhes mudar a ordem."), "signal": ""},
		{"target": "%GraveyardBtn", "text": tr("No turno 1 podes fazer MULLIGAN (mão nova, uma carta para o fundo). Feitiços com ↺ lançam-se do CEMITÉRIO uma segunda vez. Depois da batalha escolhes o caminho no mapa. Boa sorte."), "signal": ""},
	]
	_build()
	EventBus.card_played.connect(func(_c): _on_signal("card_played"))
	EventBus.cascade_started.connect(func(_c): _on_signal("cascade_started"))
	EventBus.card_discarded.connect(func(_c): _on_signal("card_discarded"))
	EventBus.turn_started.connect(_on_turn_started)
	EventBus.battle_ended.connect(func(_v): _finish())
	_show_step()

func _build() -> void:
	_panel = PanelContainer.new()
	_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	_panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.1, 0.09, 0.16, 0.97), 14, UiKit.GOLD, 2, 14))
	_panel.custom_minimum_size = Vector2(560, 0)
	add_child(_panel)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	_panel.add_child(vbox)
	var head := HBoxContainer.new()
	vbox.add_child(head)
	var title := UiKit.label(tr("TUTORIAL"), 16, UiKit.GOLD)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	var skip := UiKit.button(tr("SALTAR TUTORIAL"), 34, 14)
	skip.pressed.connect(func(): Sfx.select(); _finish())
	head.add_child(skip)
	_text = UiKit.label("", 18, Color.WHITE, true)
	vbox.add_child(_text)
	_next_btn = UiKit.button(tr("CONTINUAR  ▶"), 44, 18, UiKit.PRIMARY, Color(0, 0, 0, 0))
	_next_btn.pressed.connect(func(): Sfx.select(); _advance())
	vbox.add_child(_next_btn)
	_arrow = Label.new()
	_arrow.text = "▼"
	_arrow.add_theme_font_size_override("font_size", 40)
	_arrow.add_theme_color_override("font_color", UiKit.GOLD)
	_arrow.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	_arrow.add_theme_constant_override("outline_size", 8)
	_arrow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_arrow)

func _target_control() -> Control:
	var key := String(_steps[_step].get("target", ""))
	if key == "hand":
		var hand: Container = _battle.get_node("%Hand")
		for v in hand.get_children():
			if v is CardView and v.playable and not v.card.data.is_land():
				return v
		return hand
	return _battle.get_node(key)

func _show_step() -> void:
	if _step >= _steps.size():
		_finish()
		return
	var st: Dictionary = _steps[_step]
	_text.text = String(st.get("text", ""))
	var needs_signal := String(st.get("signal", "")) != ""
	_next_btn.visible = not needs_signal or bool(st.get("skippable", false))
	_next_btn.text = tr("SALTAR PASSO  ▶") if (needs_signal and bool(st.get("skippable", false))) else tr("CONTINUAR  ▶")
	_waiting_turn = bool(st.get("after_turn", false))
	_panel.visible = not _waiting_turn
	_arrow.visible = not _waiting_turn
	await get_tree().process_frame
	_place()
	UiKit.pop_in(_panel)

## Painel no topo do centro (sobre o tabuleiro); seta por cima do alvo.
func _place() -> void:
	if not is_inside_tree():
		return
	var vp := get_viewport().get_visible_rect().size
	_panel.reset_size()
	_panel.global_position = Vector2(vp.x * 0.5 - _panel.size.x * 0.5 + 150.0, 78.0)
	var target := _target_control()
	if target == null or not is_instance_valid(target):
		_arrow.visible = false
		return
	var r := target.get_global_rect()
	_arrow.reset_size()
	# Seta a apontar para baixo, encostada ao topo do alvo; se o alvo está no topo, aponta para cima.
	if r.position.y > 140.0:
		_arrow.text = "▼"
		_arrow.global_position = Vector2(r.position.x + r.size.x * 0.5 - _arrow.size.x * 0.5, r.position.y - _arrow.size.y - 2.0)
	else:
		_arrow.text = "▲"
		_arrow.global_position = Vector2(r.position.x + r.size.x * 0.5 - _arrow.size.x * 0.5, r.end.y + 2.0)
	_bounce()

func _bounce() -> void:
	var tw := create_tween().set_loops()
	tw.tween_property(_arrow, "position:y", _arrow.position.y - 8.0, 0.35).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(_arrow, "position:y", _arrow.position.y, 0.35).set_ease(Tween.EASE_IN_OUT)
	_arrow.set_meta("tw", tw)

func _on_signal(sig: String) -> void:
	if _step < _steps.size() and String(_steps[_step].get("signal", "")) == sig:
		_advance()

func _on_turn_started(_t: int) -> void:
	# O passo 3 espera que o contra-ataque aconteça (início do turno seguinte) para aparecer.
	if _waiting_turn:
		_waiting_turn = false
		_panel.visible = true
		_arrow.visible = true
		await get_tree().process_frame
		_place()
		UiKit.pop_in(_panel)
	elif _step < _steps.size():
		_place()

func _advance() -> void:
	if _arrow.has_meta("tw"):
		var tw = _arrow.get_meta("tw")
		if tw is Tween and (tw as Tween).is_valid():
			(tw as Tween).kill()
	_step += 1
	_show_step()

func _finish() -> void:
	if is_queued_for_deletion():
		return
	Stats.set_tutorial_done(true)
	queue_free()
