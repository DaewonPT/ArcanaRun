class_name BattleRewards
extends Control
## 0.16.0 (V38): ecrã de recompensas no fim de uma batalha ganha — em vez dos avisos que passavam, um painel com
## as linhas do ouro a aparecer uma a uma (vitória, turnos que sobraram, jogada perfeita, Excesso, Elite…), o
## ouro a contar até ao novo total, com moedas a saltar, e a relíquia ou a poção ganha a revelar-se.
## CONTINUAR (ou um toque fora do painel, depois de a contagem acabar) fecha; um toque durante a contagem
## salta para o fim.

signal done

const LINE_NAMES := {
	"victory": "Vitória",
	"turns": "Turnos que sobraram",
	"perfect": "Jogada perfeita",
	"overkill": "Excesso do golpe final",
	"thief": "Relíquias recuperadas",
	"affixes": "Afixos da Elite",
	"elite": "Elite sem lugar para relíquia",
	"other": "Relíquias, Vales e contratos",
	"ambush": "Emboscada (+50 %)",          # 0.18.0 (24)
	"siege": "Cerco",
	"escaped": "Fuga",
	"escape_kill": "Venceste em vez de fugir (+50 %)",
}

var _lines: Array = []
var _reveals: Array = []
var _gold0 := 0
var _gold1 := 0
var _title := ""
var _body: VBoxContainer
var _gold_label: Label
var _coin: CardIcon
var _btn: Button
var _counting := true
var _skip := false
var _closed := false

static func open(_host: Node, title: String, lines: Array, reveals: Array, gold_before: int, gold_after: int) -> BattleRewards:
	var o := BattleRewards.new()
	o._title = title
	o._lines = lines
	o._reveals = reveals
	o._gold0 = gold_before
	o._gold1 = gold_after
	SceneRouter.show_overlay(o)
	o._build()
	return o

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.55))

func _build() -> void:
	_body = UiKit.window(self, 560, _title, UiKit.GOLD)
	var panel: Control = _body.get_meta("panel")
	var list := VBoxContainer.new()
	list.name = "Lines"
	list.add_theme_constant_override("separation", 6)
	list.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_body.add_child(list)
	for ln in _lines:
		var row := HBoxContainer.new()
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_theme_constant_override("separation", 10)
		var kind := String(ln[0])
		var txt := tr(String(LINE_NAMES.get(kind, kind)))
		if kind == "turns" and ln.size() > 2:
			txt += " (%d)" % int(ln[2])
		var name_l := UiKit.label(txt, 20, Color.WHITE)
		name_l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(name_l)
		var amt := int(ln[1])
		var price := UiKit.price(amt, amt >= 0, 20)
		(price.get_meta("label") as Label).text = ("+%d" % amt) if amt >= 0 else str(amt)
		row.add_child(price)
		row.modulate.a = 0.0
		list.add_child(row)
	var sep := ColorRect.new()
	sep.color = Color(UiKit.GOLD, 0.35)
	sep.custom_minimum_size = Vector2(0, 2)
	sep.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_body.add_child(sep)
	var total := HBoxContainer.new()
	total.alignment = BoxContainer.ALIGNMENT_CENTER
	total.add_theme_constant_override("separation", 10)
	total.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_body.add_child(total)
	_coin = CardIcon.new("coin", UiKit.COIN, 38.0)
	_coin.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	total.add_child(_coin)
	_gold_label = UiKit.label(str(_gold0), 40, UiKit.COIN)
	_gold_label.name = "GoldTotal"
	total.add_child(_gold_label)
	if not _reveals.is_empty():
		var rev := HBoxContainer.new()
		rev.name = "Reveals"
		rev.alignment = BoxContainer.ALIGNMENT_CENTER
		rev.add_theme_constant_override("separation", 18)
		rev.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_body.add_child(rev)
		for r in _reveals:
			var item := _reveal_item(r)
			if item != null:
				item.modulate.a = 0.0
				rev.add_child(item)
	_btn = UiKit.button(tr("CONTINUAR"), 58, 24, UiKit.PRIMARY)
	_btn.name = "Continue"
	_btn.set_meta("haptic", true)
	UiKit.gold_plate(_btn, true)
	_btn.pressed.connect(_finish)
	_body.add_child(_btn)
	UiKit.pop_in(panel)
	_play()

## Uma recompensa a revelar: relíquia (medalhão com a ilustração), poção/pergaminho ou só texto.
func _reveal_item(r: Array) -> Control:
	var kind := String(r[0])
	var box := VBoxContainer.new()
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_theme_constant_override("separation", 4)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	if kind == "text":
		var l := UiKit.label(String(r[1]), 18, UiKit.GOLD, true)
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.custom_minimum_size.x = 460
		box.add_child(l)
		return box
	var id := String(r[1])
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(86, 86)
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var art := ArtLib.texture("relic" if kind == "relic" else "item", id)
	var name_txt := ""
	var ring := UiKit.GOLD
	if kind == "relic":
		var def: Dictionary = CardDB.relics.get(id, {})
		name_txt = tr(String(def.get("name", id)))
		ring = RelicView.ring_color(def)
	else:
		var cdef := CardDB.get_consumable(id)
		name_txt = tr(String(cdef.get("name", id)))
	holder.draw.connect(func():
		var c := holder.size / 2.0
		var rad := minf(holder.size.x, holder.size.y) / 2.0
		holder.draw_circle(c, rad, Color(0.1, 0.08, 0.16))
		if art != null:
			ArtLib.draw_round(holder, art, c, rad - 4.0)
		else:
			holder.draw_circle(c, rad * 0.4, Color(ring, 0.6))
		holder.draw_arc(c, rad - 2.0, 0.0, TAU, 40, ring, 3.0, true))
	box.add_child(holder)
	var l2 := UiKit.label(name_txt, 16, Color.WHITE)
	l2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(l2)
	return box

func _play() -> void:
	var list: Control = _body.get_node("Lines")
	var shown := _gold0
	for row in list.get_children():
		if _closed:
			return
		var amt := 0
		var idx := row.get_index()
		if idx < _lines.size():
			amt = int(_lines[idx][1])
		_fade_in(row)
		Sfx.blip(mini(20, idx * 2))
		if not _skip:
			await get_tree().create_timer(Settings.dur(0.22)).timeout
		shown += amt
		await _count_to(shown)
	await _count_to(_gold1)
	if _body.has_node("Reveals"):
		for item in _body.get_node("Reveals").get_children():
			if _closed:
				return
			_fade_in(item, true)
			Sfx.level_up()
			if not _skip:
				await get_tree().create_timer(Settings.dur(0.3)).timeout
	_counting = false

func _count_to(target: int) -> void:
	var from := int(_gold_label.text) if _gold_label.text.is_valid_int() else _gold0
	if from == target or _skip or _closed:
		_gold_label.text = str(target)
		return
	var steps := clampi(absi(target - from), 1, 12)
	for k in range(1, steps + 1):
		if _skip or _closed:
			break
		_gold_label.text = str(from + int(round(float(target - from) * k / steps)))
		_pop_coin()
		await get_tree().create_timer(Settings.dur(0.035)).timeout
	_gold_label.text = str(target)

func _pop_coin() -> void:
	if not Settings.motion_ok() or _coin == null or not is_instance_valid(_coin):
		return
	var c := CardIcon.new("coin", UiKit.COIN, 18.0)
	add_child(c)
	c.global_position = _coin.global_position + Vector2(randf_range(0, 20), 0)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(c, "global_position:y", c.global_position.y - randf_range(30, 60), 0.35).set_ease(Tween.EASE_OUT)
	tw.tween_property(c, "global_position:x", c.global_position.x + randf_range(-30, 30), 0.35)
	tw.tween_property(c, "modulate:a", 0.0, 0.35).set_delay(0.12)
	tw.chain().tween_callback(c.queue_free)

func _fade_in(node: Control, pop: bool = false) -> void:
	if _skip or not Settings.motion_ok():
		node.modulate.a = 1.0
		return
	var tw := create_tween().set_parallel(true)
	tw.tween_property(node, "modulate:a", 1.0, Settings.dur(0.18))
	if pop:
		node.pivot_offset = node.size / 2.0
		node.scale = Vector2(0.4, 0.4)
		tw.tween_property(node, "scale", Vector2.ONE, Settings.dur(0.3)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and not event.pressed:
		accept_event()
		if _counting:
			_skip = true
		else:
			_finish()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		_finish()

func _finish() -> void:
	if _closed:
		return
	_closed = true
	Sfx.select()
	done.emit()
	UiKit.close_animated(self)
