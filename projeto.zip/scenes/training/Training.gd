extends Control
## TREINO: escolhes a mão (até 6 cartas), as relíquias (até 5) e a mana, e atacas um Boneco de
## Treino com vida infinita durante um turno. No fim vês o dano e podes repetir, editar ou sair.
## Serve para testar combos; não mexe na run gravada nem nas estatísticas de runs.

const MAX_HAND := 6
const COLOR_FILTERS := ["all", "white", "blue", "black", "red", "green", "colorless"]
const FILTER_NAMES := {"all": "Todas", "white": "Branco", "blue": "Azul", "black": "Preto", "red": "Vermelho", "green": "Verde", "colorless": "Incolor"}

var _hand: Array[String] = []
var _relics: Array[String] = []
var _mana: int = 5
var _filter := "all"
var _hand_row: HBoxContainer
var _hand_title: Label
var _mana_label: Label
var _relic_btn: Button
var _grid: GridContainer
var _filter_buttons: Dictionary = {}
var _relic_mode := false
var _list_title: Label

func _ready() -> void:
	var t: Dictionary = GameState.training
	for id in t.get("hand", []):
		if CardDB.get_card(String(id)) != null:
			_hand.append(String(id))
	for id in t.get("relics", []):
		if CardDB.relics.has(String(id)):
			_relics.append(String(id))
	_mana = clampi(int(t.get("mana", 5)), 1, BattleManager.MAX_MANA)
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	margin.add_child(vbox)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var back := UiKit.menu_button(48, 18)
	back.custom_minimum_size.x = 120
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("TREINO"), 26, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(title)
	var sub := UiKit.label(tr("Boneco com vida infinita · um turno · testa os teus combos"), 16, UiKit.TEXT_DIM)
	sub.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	sub.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sub.clip_text = true
	header.add_child(sub)
	var go := UiKit.button(tr("TREINAR"), 52, 22, UiKit.PRIMARY, Color(0, 0, 0, 0))
	go.custom_minimum_size.x = 180
	go.pressed.connect(_start)
	header.add_child(go)

	# Mão escolhida, mana e relíquias.
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 12)
	vbox.add_child(top)
	_hand_title = UiKit.label("", 18, UiKit.GOLD)
	_hand_title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_hand_title.custom_minimum_size.x = 120
	top.add_child(_hand_title)
	_hand_row = HBoxContainer.new()
	_hand_row.add_theme_constant_override("separation", 6)
	_hand_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(_hand_row)
	# Filtro por cor, mana e relíquias; por baixo a lista (cartas ou relíquias).
	var filters := HBoxContainer.new()
	filters.add_theme_constant_override("separation", 6)
	vbox.add_child(filters)
	for f in COLOR_FILTERS:
		var b := UiKit.button(tr(FILTER_NAMES[f]), 44, 15)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.clip_text = true
		b.custom_minimum_size.x = 64
		b.pressed.connect(func(): Sfx.select(); _filter = f; _refresh_list())
		filters.add_child(b)
		_filter_buttons[f] = b
	var minus := UiKit.button("−", 44, 22)
	minus.custom_minimum_size.x = 48
	minus.pressed.connect(func(): _mana = maxi(1, _mana - 1); _refresh_top())
	filters.add_child(minus)
	_mana_label = UiKit.label("", 17)
	_mana_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_mana_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_mana_label.custom_minimum_size.x = 84
	filters.add_child(_mana_label)
	var plus := UiKit.button("+", 44, 22)
	plus.custom_minimum_size.x = 48
	plus.pressed.connect(func(): _mana = mini(BattleManager.MAX_MANA, _mana + 1); _refresh_top())
	filters.add_child(plus)
	_relic_btn = UiKit.button("", 44, 16)
	_relic_btn.custom_minimum_size.x = 190
	_relic_btn.pressed.connect(func(): Sfx.select(); _relic_mode = not _relic_mode; _refresh_list())
	filters.add_child(_relic_btn)
	_list_title = UiKit.label("", 15, UiKit.TEXT_DIM)
	vbox.add_child(_list_title)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)
	_grid = GridContainer.new()
	_grid.columns = 4
	_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_grid.add_theme_constant_override("h_separation", 8)
	_grid.add_theme_constant_override("v_separation", 8)
	scroll.add_child(_grid)
	_refresh_top()
	_refresh_list()

func _refresh_top() -> void:
	_hand_title.text = tr("Mão %d/%d") % [_hand.size(), MAX_HAND]
	for c in _hand_row.get_children():
		_hand_row.remove_child(c)
		c.queue_free()
	for i in _hand.size():
		var cd := CardDB.get_card(_hand[i])
		var col: Color = CardView.COLORS.get(cd.primary_color(), CardView.COLORS.colorless)
		var b := UiKit.button(cd.display_name() + "  ✕", 44, 14, col.darkened(0.45), col)
		b.clip_text = true
		b.custom_minimum_size.x = 80
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.tooltip_text = tr("Toca para tirar da mão")
		b.pressed.connect(func(): Sfx.select(); _hand.remove_at(i); _refresh_top())
		_hand_row.add_child(b)
	if _hand.is_empty():
		_hand_row.add_child(UiKit.label(tr("Toca nas cartas em baixo para as pôr na mão."), 16, UiKit.TEXT_DIM))
	_mana_label.text = tr("Mana %d") % _mana
	_relic_btn.text = (tr("◀ CARTAS") if _relic_mode else tr("RELÍQUIAS (%d/%d)") % [_relics.size(), GameState.MAX_RELICS])

func _refresh_list() -> void:
	_refresh_top()
	for f in _filter_buttons:
		var on := String(f) == _filter
		(_filter_buttons[f] as Button).add_theme_color_override("font_color", UiKit.GOLD if on else UiKit.TEXT_DIM)
	for c in _grid.get_children():
		_grid.remove_child(c)
		c.queue_free()
	if _relic_mode:
		_list_title.text = tr("Escolhe até %d relíquias") % GameState.MAX_RELICS
		var all: Array = CardDB.relics.values().filter(func(r): return CardDB.is_relic_available(r))
		all.sort_custom(func(a, b): return tr(String(a.get("name", ""))) < tr(String(b.get("name", ""))))
		for r in all:
			var id := String(r.get("id", ""))
			var chosen := id in _relics
			var ring := RelicView.ring_color(r)
			var b := UiKit.button(("✓ " if chosen else "") + tr(String(r.get("name", id))), 52, 15, ring.darkened(0.6) if chosen else UiKit.BG_LIGHT, ring if chosen else Color(0, 0, 0, 0))
			b.clip_text = true
			b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			b.tooltip_text = tr(String(r.get("text", "")))
			b.pressed.connect(func():
				Sfx.select()
				if id in _relics:
					_relics.erase(id)
				elif _relics.size() < GameState.MAX_RELICS:
					_relics.append(id)
				_refresh_list())
			_grid.add_child(b)
		return
	_list_title.text = tr("Toca para pôr na mão")
	var cards: Array = CardDB.collectible_cards().filter(func(c: CardData):
		if not CardDB.is_available(c) or c.is_curse():
			return false
		if _filter == "all":
			return true
		if _filter == "colorless":
			return c.colors.is_empty()
		return _filter in c.colors)
	cards.sort_custom(func(a: CardData, b: CardData): return a.num < b.num)
	for c in cards:
		var col: Color = CardView.COLORS.get(c.primary_color(), CardView.COLORS.colorless)
		var stats := " · %d⚔" % c.power if c.power > 0 else ""
		var b := UiKit.button("%s  (%d%s)" % [c.display_name(), c.cost, stats], 48, 14, col.darkened(0.55), col.darkened(0.1))
		b.clip_text = true
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.tooltip_text = tr(c.text)
		b.pressed.connect(func():
			if _hand.size() < MAX_HAND:
				Sfx.select()
				_hand.append(c.id)
				_refresh_top()
			else:
				Sfx.deny())
		_grid.add_child(b)

func _start() -> void:
	if _hand.is_empty():
		Sfx.deny()
		_hand_title.add_theme_color_override("font_color", Color(1, 0.5, 0.45))
		return
	Sfx.boom()
	GameState.training = {"hand": _hand.duplicate(), "relics": _relics.duplicate(), "mana": _mana}
	GameState.start_training()
	SceneRouter.go("battle")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
