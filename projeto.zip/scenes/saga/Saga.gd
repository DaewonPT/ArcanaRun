extends Control
## HISTÓRIA, em dois livros (data/saga.json, campo "book"):
##  • Livro I · Os Cinco Planos: cinco capítulos, um por cor; acabar um abre o seguinte.
##  • Livro II · As Dez Guildas (0.12.0): um capítulo por guilda (os baralhos 06–15), todos abertos
##    depois de acabar 3 capítulos do Livro I.
##  • Livro III · O Rival (0.13.0): cinco capítulos seguidos com os baralhos 16–20 contra a Némesis, os
##    rivais e as planeswalkers caídas, e um fim (epílogo) contra o Arquiteto do Zero. Abre com 3 do Livro II.
## Cada capítulo é uma run curta de 4 antes com o baralho, cartas extra, uma regra especial e um boss
## próprio com falas; acabar dá um cosmético. Não conta para a campanha.

const ROMAN := ["I", "II", "III", "IV", "V"]
const BOOK_NAMES := {1: "LIVRO I · OS CINCO PLANOS", 2: "LIVRO II · AS DEZ FAÇÕES", 3: "LIVRO III · O RIVAL"}
const BOOK_TEXT := {
	1: "Cinco capítulos curtos (4 antes), um por cor, cada um com uma regra especial e um boss que fala. Acaba um para abrir o seguinte.",
	2: "Dez capítulos, um por fação, com os baralhos de duas cores. Abre ao acabares 3 capítulos do Livro I; depois podes jogá-los por qualquer ordem.",
	3: "Cinco capítulos seguidos: a Némesis, os rivais e as patronas caídas — e, no fim, quem os mandou. Abre ao acabares 3 capítulos do Livro II.",
}

static var _book := 1        # livro aberto (fica igual ao voltar a este ecrã)
var _detail: VBoxContainer
var _cards_box: Control
var _tabs: Array[Button] = []
var _desc: Label

func _ready() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	margin.add_child(vbox)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var back := UiKit.button(tr("◀ MENU"), 48, 18)
	back.custom_minimum_size.x = 120
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("HISTÓRIA"), 26, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(title)
	for b in BOOK_NAMES.keys():
		var t := UiKit.button(tr(BOOK_NAMES[b]), 48, 15)
		t.name = "Book%d" % b
		t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		t.pressed.connect(func(): Sfx.select(); _show_book(b))
		header.add_child(t)
		_tabs.append(t)
	var done := 0
	for ch in CardDB.saga:
		if GameState.saga_done(String(ch.get("id", ""))):
			done += 1
	var counter := UiKit.label(tr("Capítulos: %d/%d") % [done, CardDB.saga.size()], 18, UiKit.TEXT_DIM)
	counter.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(counter)
	_desc = UiKit.label("", 16, UiKit.TEXT_DIM, true)
	vbox.add_child(_desc)
	_cards_box = VBoxContainer.new()
	_cards_box.add_theme_constant_override("separation", 10)
	vbox.add_child(_cards_box)
	_detail = VBoxContainer.new()
	_detail.add_theme_constant_override("separation", 8)
	_detail.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(_detail)
	_show_book(_book if GameState.saga_book_open(_book) else 1)

## Mostra os capítulos de um livro (5 por fila) e o detalhe do primeiro por acabar.
func _show_book(book: int) -> void:
	_book = book
	for i in _tabs.size():
		var on := i + 1 == book
		var st := UiKit.flat(UiKit.GOLD.darkened(0.55) if on else UiKit.BG_LIGHT, 12, UiKit.GOLD if on else Color(0, 0, 0, 0), 2 if on else 0, 10)
		_tabs[i].add_theme_stylebox_override("normal", st)
		_tabs[i].add_theme_stylebox_override("hover", st)
		_tabs[i].add_theme_color_override("font_color", UiKit.GOLD if on else UiKit.TEXT_DIM)
	_desc.text = tr(BOOK_TEXT.get(book, ""))
	if not GameState.saga_book_open(book):
		_desc.text += "  " + (tr("(Fechado: acaba %d capítulos do Livro I.)") if book == 2 else tr("(Fechado: acaba %d capítulos do Livro II.)")) % GameState.SAGA_BOOK_UNLOCK
	UiKit.clear_children(_cards_box)
	var indices: Array[int] = []
	for i in CardDB.saga.size():
		if GameState.saga_book(i) == book:
			indices.append(i)
	var row: HBoxContainer = null
	for k in indices.size():
		if k % 5 == 0:
			row = HBoxContainer.new()
			row.add_theme_constant_override("separation", 12)
			row.alignment = BoxContainer.ALIGNMENT_CENTER
			_cards_box.add_child(row)
		row.add_child(_chapter_card(indices[k], indices.size() > 5))
	var first := indices[0] if not indices.is_empty() else 0
	for i in indices:
		if GameState.saga_unlocked(i) and not GameState.saga_done(String(CardDB.saga[i].get("id", ""))):
			first = i
			break
	_show_detail(first)

func _chapter_card(i: int, small: bool = false) -> Control:
	var ch: Dictionary = CardDB.saga[i]
	var id := String(ch.get("id", ""))
	var open := GameState.saga_unlocked(i)
	var done := GameState.saga_done(id)
	var col: Color = CardView.COLORS.get(String(ch.get("color", "colorless")), UiKit.GOLD)
	var b := Button.new()
	b.name = "Chapter_" + id
	b.custom_minimum_size = Vector2(228, 116 if small else 168)
	b.focus_mode = Control.FOCUS_NONE
	var bg := col.darkened(0.55) if open else Color(0.12, 0.11, 0.16)
	var st := UiKit.flat(bg, 14, UiKit.GOLD if done else (col if open else Color(0.3, 0.28, 0.4)), 3 if done else 2, 10)
	b.add_theme_stylebox_override("normal", st)
	b.add_theme_stylebox_override("hover", st)
	b.add_theme_stylebox_override("pressed", UiKit.flat(bg.lightened(0.12), 14, col, 3, 10))
	b.add_theme_stylebox_override("disabled", st)
	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_FULL_RECT)
	box.offset_left = 12
	box.offset_right = -12
	box.offset_top = 10
	box.offset_bottom = -10
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_theme_constant_override("separation", 4)
	b.add_child(box)
	var sigil := CardSigil.new()
	sigil.card_id = id
	sigil.colors = ch.get("colors", [String(ch.get("color", ""))])
	sigil.ink = Color(col.lightened(0.3), 0.55 if open else 0.15)
	sigil.custom_minimum_size = Vector2(0, 34 if small else 64)
	sigil.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(sigil)
	var name_l := UiKit.label(tr(String(ch.get("name", ""))), 16 if small else 18, Color.WHITE if open else Color(0.55, 0.55, 0.6), true)
	name_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(name_l)
	var state := tr("✓ Concluído") if done else (tr("Disponível") if open else tr("Bloqueado"))
	var s_l := UiKit.label(state, 14, UiKit.GOLD if done else (col.lightened(0.3) if open else Color(0.5, 0.5, 0.55)))
	s_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(s_l)
	b.pressed.connect(func(): Sfx.select(); _show_detail(i))
	return b

func _show_detail(i: int) -> void:
	for c in _detail.get_children():
		_detail.remove_child(c)
		c.queue_free()
	if i < 0 or i >= CardDB.saga.size():
		return
	var ch: Dictionary = CardDB.saga[i]
	var id := String(ch.get("id", ""))
	var open := GameState.saga_unlocked(i)
	var col: Color = CardView.COLORS.get(String(ch.get("color", "colorless")), UiKit.GOLD)
	var panel := PanelContainer.new()
	panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.12, 0.1, 0.18), 14, col.darkened(0.2), 2, 16))
	_detail.add_child(panel)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	panel.add_child(row)
	var texts := VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.add_theme_constant_override("separation", 8)
	row.add_child(texts)
	texts.add_child(UiKit.label(tr(String(ch.get("name", ""))), 26, col.lightened(0.35)))
	var locked_txt := tr("Acaba o capítulo anterior para abrir este.")
	if not GameState.saga_book_open(GameState.saga_book(i)):
		locked_txt = tr("Acaba %d capítulos do Livro I para abrir o Livro II.") % GameState.SAGA_BOOK_UNLOCK if GameState.saga_book(i) == 2 else tr("Acaba %d capítulos do Livro II para abrir o Livro III.") % GameState.SAGA_BOOK_UNLOCK
	texts.add_child(UiKit.label(tr(String(ch.get("intro", ""))) if open else locked_txt, 17, Color.WHITE, true))
	var deck := CardDB.get_deck(String(ch.get("deck_id", "")))
	var info := tr("Baralho: %s") % tr(String(deck.get("name", ""))) + "  ·  " + tr("%d antes") % int(ch.get("antes", 4))
	var boss := CardDB.enemy_def(String(ch.get("boss", "")))
	if not boss.is_empty():
		info += "  ·  " + tr("Boss: %s") % tr(String(boss.get("name", "")))
	texts.add_child(UiKit.label(info, 16, UiKit.TEXT_DIM, true))
	texts.add_child(UiKit.label(tr("Regra: %s") % tr(String(ch.get("rule_text", ""))), 17, UiKit.GOLD, true))
	var extra: Array[String] = []
	for cid in ch.get("add_cards", []):
		var cd := CardDB.get_card(String(cid))
		if cd != null:
			extra.append(cd.display_name())
	if not extra.is_empty():
		texts.add_child(UiKit.label(tr("Cartas extra: %s") % ", ".join(PackedStringArray(extra)), 16, UiKit.TEXT_DIM, true))
	# Prémio: as costas de carta (amostra) e o botão para começar.
	var side := VBoxContainer.new()
	side.add_theme_constant_override("separation", 8)
	side.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_child(side)
	# 0.13.0: o retrato do boss do capítulo (ilustração, se houver; senão o retrato desenhado).
	if not boss.is_empty() and open:
		var bp := EnemyPortrait.new()
		bp.name = "BossPortrait"
		bp.custom_minimum_size = Vector2(128, 128)
		bp.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		bp.mouse_filter = Control.MOUSE_FILTER_IGNORE
		bp.archetype = String(boss.get("portrait", "brute"))
		bp.tint = col
		bp.boss = true
		bp.art_id = String(boss.get("art", "")) if String(boss.get("art", "")) != "" else String(boss.get("id", ""))
		side.add_child(bp)
	var rw: Dictionary = ch.get("reward", {})
	if String(rw.get("type", "")) == "back":
		var cap := UiKit.label(tr("Prémio"), 15, UiKit.TEXT_DIM)
		cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		side.add_child(cap)
		var back := CardBack.new()
		back.back_id = String(rw.get("id", "classic"))
		back.custom_minimum_size = Vector2(84, 120)
		back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		side.add_child(back)
		var bn := UiKit.label(tr(String(CardDB.get_cosmetic("back", String(rw.get("id", ""))).get("name", ""))), 14, UiKit.TEXT_DIM)
		bn.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		side.add_child(bn)
	elif not rw.is_empty():
		# 0.12.0: tapetes da Arena, molduras e efeitos de ataque.
		var pl := UiKit.label(tr("Prémio") + "\n" + Stats.unlock_label(rw, "%s: %s"), 15, UiKit.GOLD, true)
		pl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		pl.custom_minimum_size.x = 230
		side.add_child(pl)
	var play := UiKit.button(tr("COMEÇAR") if not GameState.saga_done(id) else tr("JOGAR OUTRA VEZ"), 58, 22, UiKit.PRIMARY if open else UiKit.BG_LIGHT, Color(0, 0, 0, 0))
	play.custom_minimum_size.x = 230
	play.disabled = not open
	play.pressed.connect(_start.bind(id))
	side.add_child(play)

func _start(id: String) -> void:
	Sfx.boom()
	GameState.claim_slot_for_new_run()
	GameState.new_saga_run(id)
	GameState.save_run({}, "map")
	SceneRouter.go("map")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
