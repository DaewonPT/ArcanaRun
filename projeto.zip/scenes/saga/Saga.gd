extends Control
## HISTÓRIA: cinco capítulos (data/saga.json), um por cor. Cada um é uma run curta de 4 antes com o
## baralho da cor, cartas extra, uma regra especial e um boss próprio com falas. Acabar um capítulo
## abre o seguinte e dá umas costas de carta (cosmético). Não conta para a campanha.

const ROMAN := ["I", "II", "III", "IV", "V"]

var _detail: VBoxContainer

func _ready() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	margin.add_child(vbox)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var back := UiKit.button(tr("◀ MENU"), 48, 18)
	back.custom_minimum_size.x = 120
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("HISTÓRIA  ·  Os Cinco Planos"), 26, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	var done := 0
	for ch in CardDB.saga:
		if GameState.saga_done(String(ch.get("id", ""))):
			done += 1
	var counter := UiKit.label(tr("Capítulos: %d/%d") % [done, CardDB.saga.size()], 18, UiKit.TEXT_DIM)
	counter.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(counter)
	vbox.add_child(UiKit.label(tr("Cinco capítulos curtos (4 antes), um por cor, cada um com uma regra especial e um boss que fala. Acaba um para abrir o seguinte."), 16, UiKit.TEXT_DIM, true))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	vbox.add_child(row)
	for i in CardDB.saga.size():
		row.add_child(_chapter_card(i))
	_detail = VBoxContainer.new()
	_detail.add_theme_constant_override("separation", 8)
	_detail.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(_detail)
	var first := 0
	for i in CardDB.saga.size():
		if GameState.saga_unlocked(i) and not GameState.saga_done(String(CardDB.saga[i].get("id", ""))):
			first = i
			break
	_show_detail(first)

func _chapter_card(i: int) -> Control:
	var ch: Dictionary = CardDB.saga[i]
	var id := String(ch.get("id", ""))
	var open := GameState.saga_unlocked(i)
	var done := GameState.saga_done(id)
	var col: Color = CardView.COLORS.get(String(ch.get("color", "colorless")), UiKit.GOLD)
	var b := Button.new()
	b.custom_minimum_size = Vector2(228, 168)
	b.focus_mode = Control.FOCUS_NONE
	var bg := col.darkened(0.55) if open else Color(0.12, 0.11, 0.16)
	var st := UiKit.flat(bg, 14, UiKit.GOLD if done else (col if open else Color(0.3, 0.28, 0.4)), 3 if done else 2, 10)
	b.add_theme_stylebox_override("normal", st)
	b.add_theme_stylebox_override("hover", st)
	b.add_theme_stylebox_override("pressed", UiKit.flat(bg.lightened(0.12), 14, col, 3, 10))
	b.add_theme_stylebox_override("disabled", st)
	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_FULL_RECT)
	box.offset_left = 12
	box.offset_right = -12
	box.offset_top = 10
	box.offset_bottom = -10
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_theme_constant_override("separation", 4)
	b.add_child(box)
	var sigil := CardSigil.new()
	sigil.card_id = id
	sigil.colors = [String(ch.get("color", ""))]
	sigil.ink = Color(col.lightened(0.3), 0.55 if open else 0.15)
	sigil.custom_minimum_size = Vector2(0, 64)
	sigil.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(sigil)
	var name_l := UiKit.label(tr(String(ch.get("name", ""))), 18, Color.WHITE if open else Color(0.55, 0.55, 0.6), true)
	name_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(name_l)
	var state := tr("✓ Concluído") if done else (tr("Disponível") if open else tr("Bloqueado"))
	var s_l := UiKit.label(state, 14, UiKit.GOLD if done else (col.lightened(0.3) if open else Color(0.5, 0.5, 0.55)))
	s_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(s_l)
	b.pressed.connect(func(): Sfx.select(); _show_detail(i))
	return b

func _show_detail(i: int) -> void:
	for c in _detail.get_children():
		_detail.remove_child(c)
		c.queue_free()
	if i < 0 or i >= CardDB.saga.size():
		return
	var ch: Dictionary = CardDB.saga[i]
	var id := String(ch.get("id", ""))
	var open := GameState.saga_unlocked(i)
	var col: Color = CardView.COLORS.get(String(ch.get("color", "colorless")), UiKit.GOLD)
	var panel := PanelContainer.new()
	panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.12, 0.1, 0.18), 14, col.darkened(0.2), 2, 16))
	_detail.add_child(panel)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	panel.add_child(row)
	var texts := VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.add_theme_constant_override("separation", 8)
	row.add_child(texts)
	texts.add_child(UiKit.label(tr(String(ch.get("name", ""))), 26, col.lightened(0.35)))
	texts.add_child(UiKit.label(tr(String(ch.get("intro", ""))) if open else tr("Acaba o capítulo anterior para abrir este."), 18, Color.WHITE, true))
	var deck := CardDB.get_deck(String(ch.get("deck_id", "")))
	var info := tr("Baralho: %s") % tr(String(deck.get("name", ""))) + "  ·  " + tr("%d antes") % int(ch.get("antes", 4))
	var boss := CardDB.enemy_def(String(ch.get("boss", "")))
	if not boss.is_empty():
		info += "  ·  " + tr("Boss: %s") % tr(String(boss.get("name", "")))
	texts.add_child(UiKit.label(info, 16, UiKit.TEXT_DIM, true))
	texts.add_child(UiKit.label(tr("Regra: %s") % tr(String(ch.get("rule_text", ""))), 17, UiKit.GOLD, true))
	var extra: Array[String] = []
	for cid in ch.get("add_cards", []):
		var cd := CardDB.get_card(String(cid))
		if cd != null:
			extra.append(cd.display_name())
	if not extra.is_empty():
		texts.add_child(UiKit.label(tr("Cartas extra: %s") % ", ".join(PackedStringArray(extra)), 16, UiKit.TEXT_DIM, true))
	# Prémio: as costas de carta (amostra) e o botão para começar.
	var side := VBoxContainer.new()
	side.add_theme_constant_override("separation", 8)
	side.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_child(side)
	var rw: Dictionary = ch.get("reward", {})
	if String(rw.get("type", "")) == "back":
		var cap := UiKit.label(tr("Prémio"), 15, UiKit.TEXT_DIM)
		cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		side.add_child(cap)
		var back := CardBack.new()
		back.back_id = String(rw.get("id", "classic"))
		back.custom_minimum_size = Vector2(84, 120)
		back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		side.add_child(back)
		var bn := UiKit.label(tr(String(CardDB.get_cosmetic("back", String(rw.get("id", ""))).get("name", ""))), 14, UiKit.TEXT_DIM)
		bn.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		side.add_child(bn)
	var play := UiKit.button(tr("COMEÇAR") if not GameState.saga_done(id) else tr("JOGAR OUTRA VEZ"), 58, 22, UiKit.PRIMARY if open else UiKit.BG_LIGHT, Color(0, 0, 0, 0))
	play.custom_minimum_size.x = 230
	play.disabled = not open
	play.pressed.connect(_start.bind(id))
	side.add_child(play)

func _start(id: String) -> void:
	Sfx.boom()
	GameState.clear_saved_run()
	GameState.new_saga_run(id)
	GameState.save_run({}, "map")
	SceneRouter.go("map")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
