extends Control
## Quebra-Cabeças do Mago: cenários fixos (data/puzzles.json) com 1 turno, 0 canalizações e uma
## mão/Arena predefinidas. A vida do inimigo é exatamente o melhor ataque possível: só a linha
## certa resolve. Os resolvidos ficam marcados no progresso (Stats.is_puzzle_solved).

func _ready() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	margin.add_child(vbox)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var back := UiKit.menu_button(48, 18)
	back.custom_minimum_size.x = 120
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("QUEBRA-CABEÇAS DO MAGO"), 26, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	var solved := 0
	for p in CardDB.puzzles:
		if Stats.is_puzzle_solved(String(p.get("id", ""))):
			solved += 1
	var counter := UiKit.label(tr("Resolvidos: %d/%d") % [solved, CardDB.puzzles.size()], 18, UiKit.TEXT_DIM)
	counter.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(counter)
	vbox.add_child(UiKit.label(tr("Um turno, sem canalizações, mão fixa. A vida do inimigo é exatamente o melhor ataque possível — encontra a linha certa."), 16, UiKit.TEXT_DIM, true))

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 8)
	scroll.add_child(list)
	var i := 1
	for p in CardDB.puzzles:
		var id := String(p.get("id", ""))
		var done := Stats.is_puzzle_solved(id)
		var b := UiKit.wrap_button("%d · %s%s  —  %s\n%s  ·  %s  ·  %s" % [i, tr(String(p.get("name", ""))), "  ✓" if done else "", tr(String(p.get("enemy_name", ""))), tr("Vida %s") % Cascade.fmt_int(int(p.get("hp", 0))), tr("Mana %d") % int(p.get("mana", 0)), tr(String(p.get("text", "")))], 78, 18, UiKit.BG_LIGHT if not done else Color(0.16, 0.3, 0.2), Color(0.5, 0.85, 0.55) if done else UiKit.BORDER)
		b.pressed.connect(_start.bind(id))
		list.add_child(b)
		i += 1

func _start(id: String) -> void:
	Sfx.boom()
	# Estado neutro para a batalha do enigma (não mexe na run gravada em disco nem nas estatísticas de runs).
	GameState.reset_for_side_battle(id)
	SceneRouter.go("battle")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
