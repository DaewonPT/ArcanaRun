extends Control
## 0.17.0 (83, 84): o ecrã entre batalhas da Torre do Arquimago e da Corrida de Bosses (não há mapa nem loja).
##  • Torre, andar vencido (GameState.tower_phase == "reward"): o prémio — 1 de 3 cartas, 1 de 2 relíquias (de
##    boss nos andares de boss) ou descansar (+30 % da vida máxima). Escolhido, passa-se ao andar seguinte.
##  • A caminho da batalha ("climb"): quem espera no andar — retrato, regra, vida e ataque — e SUBIR.
##  • Corrida: o boss seguinte e ENFRENTAR (a cura de 30 % já veio com a vitória anterior).
## À esquerda, a torre: os andares à volta do atual (os de boss com coroa) ou a lista dos bosses da Corrida, com
## os turnos de cada um. Tudo fica gravado (save_run(…, "tower")): MENU volta ao menu sem abandonar a run.

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const RELIC_VIEW := preload("res://scenes/ui/RelicView.tscn")
const ACCENT_TOWER := Color(0.74, 0.62, 1.0)
const ACCENT_RUSH := Color(1.0, 0.58, 0.44)
const LEFT_W := 250.0
const FLOORS_SHOWN := 10

var _busy := false
var _accent := ACCENT_TOWER
var _root: MarginContainer

func _ready() -> void:
	if not (GameState.mode in ["tower", "rush"]):
		SceneRouter.go.call_deferred("main")
		return
	_accent = ACCENT_TOWER if GameState.mode == "tower" else ACCENT_RUSH
	GameState.save_run({}, "tower")
	_build_backdrop()
	_build()

func _tower() -> bool:
	return GameState.mode == "tower"

func _reward_phase() -> bool:
	return _tower() and GameState.tower_phase == "reward" and not GameState.tower_offer.is_empty()

# --- Fundo ---

func _build_backdrop() -> void:
	var tex: Texture2D = ArtLib.texture("background", "tower" if _tower() else "rush")
	if tex == null:
		tex = ArtLib.texture("background", "act_E" if _tower() else "act_4")
	if tex != null:
		var art := TextureRect.new()
		art.name = "Art"
		art.texture = tex
		art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		art.set_anchors_preset(Control.PRESET_FULL_RECT)
		art.mouse_filter = Control.MOUSE_FILTER_IGNORE
		art.modulate = Color(0.5, 0.47, 0.58)
		add_child(art)
	var shade := ColorRect.new()
	shade.name = "Shade"
	shade.color = Color(0.03, 0.02, 0.06, 0.45)
	shade.set_anchors_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(shade)

# --- Ecrã ---

func _build() -> void:
	if _root != null and is_instance_valid(_root):
		remove_child(_root)
		_root.queue_free()
	_root = MarginContainer.new()
	_root.name = "Root"
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		_root.add_theme_constant_override("margin_" + side, 24)
	_root.add_theme_constant_override("margin_top", 10)
	_root.add_theme_constant_override("margin_bottom", 30)
	add_child(_root)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	_root.add_child(vbox)
	vbox.add_child(_top_bar())
	var body := HBoxContainer.new()
	body.name = "Body"
	body.add_theme_constant_override("separation", 18)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(body)
	var left := _panel(Color(0.07, 0.05, 0.12, 0.86))
	left.name = "Left"
	left.custom_minimum_size.x = LEFT_W - (40.0 if _reward_phase() else 0.0)   # o prémio precisa de mais largura
	body.add_child(left)
	var lbox := VBoxContainer.new()
	lbox.add_theme_constant_override("separation", 6)
	left.add_child(lbox)
	if _tower():
		_build_floors(lbox)
	else:
		_build_bosses(lbox)
	var right := VBoxContainer.new()
	right.name = "Right"
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 10)
	body.add_child(right)
	if _reward_phase():
		_build_reward(right)
	else:
		_build_next(right)
	UiKit.hand_mirror(body)   # 0.19.0 (25): com a mão esquerda, os andares passam para a direita

func _top_bar() -> HBoxContainer:
	var top := HBoxContainer.new()
	top.name = "Top"
	top.add_theme_constant_override("separation", 12)
	var menu := UiKit.menu_button(48, 18)
	menu.name = "Menu"
	menu.pressed.connect(_on_menu)
	top.add_child(menu)
	var title := UiKit.label(tr(GameState.mode_name(GameState.mode)).to_upper(), 26, _accent)
	title.theme_type_variation = &"TitleLabel"
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	top.add_child(title)
	var stage := UiKit.label(GameState.stage_label(), 19, UiKit.TEXT_DIM)
	stage.name = "Stage"
	stage.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	top.add_child(stage)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(spacer)
	var hp := UiKit.info_chip("heart", tr("Vida %d/%d") % [GameState.player_hp, GameState.player_max_hp], Color(1.0, 0.45, 0.5), func(): pass, 48)
	hp.name = "HpChip"
	top.add_child(hp)
	var gold := UiKit.info_chip("coin", str(GameState.gold), UiKit.COIN, func(): pass, 48)   # 0.19.0 (87, 88)
	gold.name = "GoldChip"
	gold.tooltip_text = tr("Ouro das batalhas: gasta-se na loja da Torre (andares de boss) e no Mercador da Corrida (de 3 em 3 bosses).")
	top.add_child(gold)
	var n_rel := GameState.relic_ids.size() + GameState.boss_relics.size()
	var rel := UiKit.info_chip("relic", tr("Relíquias: %d") % n_rel, UiKit.GOLD, _open_run_info, 48)   # 0.19.0 (58)
	rel.name = "RelicChip"
	top.add_child(rel)
	var deck := UiKit.button(tr("BARALHO (%d)") % GameState.deck.size(), 48, 16)
	deck.name = "DeckBtn"
	UiKit.button_icon(deck, "cards", Color(0.88, 0.85, 0.96), 20.0, false)
	deck.pressed.connect(func():
		if not SceneRouter.has_overlay():
			Sfx.select()
			ZoneViewer.open_deck(tr("O TEU BARALHO")))
	top.add_child(deck)
	return top

func _panel(bg: Color, border: Color = Color(1, 1, 1, 0.1)) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UiKit.flat(bg, 14, border, 1, 12))
	return p

# --- Esquerda: os andares da Torre ---

func _build_floors(box: VBoxContainer) -> void:
	var cap := UiKit.label(tr("ANDARES"), 16, _accent)
	cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(cap)
	var cur := GameState.ante
	var lo := maxi(1, cur - 4)
	var hi := lo + FLOORS_SHOWN - 1
	var floors := VBoxContainer.new()
	floors.name = "Floors"
	floors.add_theme_constant_override("separation", 5)
	floors.size_flags_vertical = Control.SIZE_EXPAND_FILL
	floors.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_child(floors)
	for f in range(hi, lo - 1, -1):
		floors.add_child(_floor_row(f, cur))
	var best := GameState.tower_best()
	var rec := UiKit.label(tr("Recorde: andar %d") % best if best > 0 else tr("Ainda sem recorde"), 15, UiKit.TEXT_DIM)
	rec.name = "Record"
	rec.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(rec)

func _floor_row(f: int, cur: int) -> Control:
	var boss := f % GameState.TOWER_BOSS_EVERY == 0
	var done := f < cur or (f == cur and GameState.tower_phase == "reward")
	var now := f == cur
	var bg := Color(0.12, 0.1, 0.18, 0.9)
	var border := Color(1, 1, 1, 0.08)
	if now:
		bg = Color(_accent.darkened(0.55), 0.95)
		border = _accent
	elif boss:
		border = Color(UiKit.GOLD, 0.55)
	var p := PanelContainer.new()
	p.name = "Floor%d" % f
	p.custom_minimum_size.y = 46 if now else 40
	p.add_theme_stylebox_override("panel", UiKit.flat(bg, 10, border, 2 if now else 1, 6))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_child(row)
	var kind := "check" if done else ("crown" if boss else "swords")
	var icol := Color(0.6, 0.9, 0.6) if done else (UiKit.GOLD if boss else Color(1, 1, 1, 0.55))
	row.add_child(CardIcon.new(kind, icol, 20.0))
	var txt := tr("Andar %d") % f + ("  ·  " + tr("Boss") if boss else "")
	var l := UiKit.label(txt, 17 if now else 15, Color.WHITE if (now or not done) else Color(0.75, 0.75, 0.8))
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.clip_text = true
	l.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	row.add_child(l)
	if now:
		var tag := UiKit.label(tr("vencido") if done else tr("agora"), 13, UiKit.GOLD if not done else Color(0.6, 0.9, 0.6))
		tag.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(tag)
	return p

# --- Esquerda: os bosses da Corrida ---

func _build_bosses(box: VBoxContainer) -> void:
	var cap := UiKit.label(tr("BOSSES"), 16, _accent)
	cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(cap)
	var scroll := ScrollContainer.new()
	scroll.name = "BossScroll"
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	box.add_child(scroll)
	var list := VBoxContainer.new()
	list.name = "Bosses"
	list.add_theme_constant_override("separation", 4)
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(list)
	var cur := GameState.ante
	for i in GameState.rush_list.size():
		var n := i + 1
		var id := GameState.rush_list[i]
		var def := CardDB.enemy_def(id)
		var row := HBoxContainer.new()
		row.name = "Boss%d" % n
		row.add_theme_constant_override("separation", 8)
		row.custom_minimum_size.y = 42
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var portrait := EnemyPortrait.new()
		portrait.custom_minimum_size = Vector2(38, 38)
		portrait.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE
		portrait.archetype = String(def.get("portrait", "brute"))
		portrait.tint = Color.from_hsv(fmod(float(abs(id.hash())) / 1000.0, 1.0), 0.55, 0.75)
		portrait.boss = true
		portrait.breathing = false
		portrait.art_id = id
		if n < cur:
			portrait.modulate = Color(0.6, 0.6, 0.65)
		row.add_child(portrait)
		var l := UiKit.label("%d. %s" % [n, tr(String(def.get("name", id)))], 14, UiKit.GOLD if n == cur else (Color(0.7, 0.7, 0.75) if n < cur else Color.WHITE))
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		l.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		l.clip_text = true
		row.add_child(l)
		if n < cur and i < GameState.rush_turns.size():
			var t := UiKit.label(tr("%d t.") % GameState.rush_turns[i], 13, Color(0.6, 0.9, 0.6))
			t.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
			row.add_child(t)
		list.add_child(row)
	var total := GameState.rush_total_turns()
	var summary := tr("Turnos: %d  ·  média %s") % [total, GameState.fmt_dec(GameState.rush_avg_turns())] if not GameState.rush_turns.is_empty() else tr("Ouro: média até 2,5 turnos · prata: até 3,5.")
	var s := UiKit.label(summary, 14, UiKit.TEXT_DIM, true)
	s.name = "RushSummary"
	s.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(s)

# --- Direita: o prémio do andar (Torre) ---

func _build_reward(box: VBoxContainer) -> void:
	var offer: Dictionary = GameState.tower_offer
	var boss := bool(offer.get("boss", false))
	var head := UiKit.label(tr("ANDAR %d VENCIDO") % GameState.ante, 30, UiKit.GOLD)
	head.name = "RewardTitle"
	head.theme_type_variation = &"TitleLabel"
	box.add_child(head)
	box.add_child(UiKit.label(tr("Escolhe um prémio: uma carta para o baralho, uma relíquia ou descansar."), 17, UiKit.TEXT_DIM, true))
	if Economy.side_shop_open():   # 0.19.0 (87): a loja da Torre nos andares de boss
		box.add_child(_shop_button())
	var row := HBoxContainer.new()
	row.name = "Rewards"
	row.add_theme_constant_override("separation", 14)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_child(row)
	# Cartas.
	var cards := _section(row, tr("UMA CARTA"), Color(0.55, 0.75, 1.0))
	var crow := HBoxContainer.new()
	crow.add_theme_constant_override("separation", 10)
	cards.add_child(crow)
	for id in offer.get("cards", []):
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 6)
		crow.add_child(col)
		var v: CardView = CARD_VIEW.instantiate()
		v.name = "Card_" + String(id)
		col.add_child(v)
		v.setup(CardDB.new_instance(String(id)))
		v.pressed.connect(_zoom)
		v.long_pressed.connect(_zoom)
		var take := UiKit.button(tr("LEVAR"), 44, 16, UiKit.PRIMARY, Color(0, 0, 0, 0))
		take.name = "TakeCard_" + String(id)
		take.pressed.connect(_take.bind("card", String(id)))
		col.add_child(take)
	# Relíquias.
	var relics := _section(row, tr("RELÍQUIA DE BOSS") if boss else tr("UMA RELÍQUIA"), UiKit.GOLD)
	relics.get_parent().size_flags_horizontal = Control.SIZE_EXPAND_FILL   # o painel fica com a largura que sobra
	var ids: Array = offer.get("relics", [])
	if ids.is_empty():
		relics.add_child(UiKit.label(tr("Já tens todas as relíquias que havia para oferecer."), 15, UiKit.TEXT_DIM, true))
	for id in ids:
		var r: Dictionary = CardDB.relics.get(String(id), {})
		var rrow := HBoxContainer.new()
		rrow.add_theme_constant_override("separation", 10)
		relics.add_child(rrow)
		var medal: RelicView = RELIC_VIEW.instantiate()
		medal.name = "Relic_" + String(id)
		medal.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		rrow.add_child(medal)
		medal.setup(String(id))
		var info := VBoxContainer.new()
		info.add_theme_constant_override("separation", 2)
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		rrow.add_child(info)
		var rn := UiKit.label(tr(String(r.get("name", id))), 16, UiKit.GOLD, true)
		rn.max_lines_visible = 2
		info.add_child(rn)
		var t := UiKit.label(tr(String(r.get("text", ""))), 13, Color(0.9, 0.88, 0.95), true)
		t.max_lines_visible = 4
		info.add_child(t)
		var take := UiKit.button(tr("LEVAR"), 44, 15, UiKit.BTN_BG, UiKit.GOLD)
		take.name = "TakeRelic_" + String(id)
		take.custom_minimum_size.x = 96
		take.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		take.pressed.connect(_take.bind("relic", String(id)))
		rrow.add_child(take)
	if not boss and GameState.relic_ids.size() >= GameState.max_relics() and not ids.is_empty():
		relics.add_child(UiKit.label(tr("Tens as relíquias cheias: escolhes a que sai."), 13, UiKit.TEXT_DIM, true))
	# Descanso.
	var rest := _section(row, tr("DESCANSAR"), Color(1.0, 0.62, 0.4))
	rest.custom_minimum_size.x = 150
	var fire := CardIcon.new("campfire", Color(1.0, 0.62, 0.4), 64.0)
	fire.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	rest.add_child(fire)
	var h := int(offer.get("heal", GameState.tower_heal_amount()))
	var after := mini(GameState.player_max_hp, GameState.player_hp + h)
	var hl := UiKit.label(tr("+%d de vida") % h + "\n" + "%d → %d" % [GameState.player_hp, after], 17, Color.WHITE, true)
	hl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	rest.add_child(hl)
	var rb := UiKit.button(tr("DESCANSAR"), 48, 17, Color(0.4, 0.22, 0.12), Color(1.0, 0.62, 0.4))
	rb.name = "Rest"
	rb.pressed.connect(_take.bind("rest", ""))
	rest.add_child(rb)

func _section(row: HBoxContainer, title: String, color: Color) -> VBoxContainer:
	var p := _panel(Color(0.08, 0.06, 0.13, 0.9), Color(color, 0.45))
	p.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	row.add_child(p)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	p.add_child(v)
	var t := UiKit.label(title, 17, color)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(t)
	return v

func _take(kind: String, id: String) -> void:
	if _busy or SceneRouter.has_overlay():
		return
	if kind == "relic" and not bool(GameState.tower_offer.get("boss", false)) and GameState.relic_ids.size() >= GameState.max_relics():
		Sfx.select()
		RelicSwap.open(id, func(out: String):
			if out != "":
				_do_take("relic", id, out))
		return
	_do_take(kind, id)

func _do_take(kind: String, id: String, replace: String = "") -> void:
	var txt := GameState.tower_take(kind, id, replace)
	if txt == "":
		Sfx.deny()
		return
	_busy = true
	if kind == "rest":
		Sfx.heal()
	else:
		Sfx.reward()
	SceneRouter.toast(txt, 2.2)
	GameState.save_run({}, "tower")
	_build()
	_busy = false

# --- Direita: quem espera (Torre e Corrida) ---

func _build_next(box: VBoxContainer) -> void:
	var tower := _tower()
	var a := GameState.ante
	var def: Dictionary = GameState.tower_enemy_def(a) if tower else GameState.rush_def(a)
	var boss := bool(def.get("boss", false))
	var head_txt := (tr("ANDAR %d") % a + ("  ·  " + tr("BOSS") if boss else "")) if tower else tr("BOSS %d DE %d") % [a, GameState.max_ante]
	var head := UiKit.label(head_txt, 30, UiKit.GOLD if boss else _accent)
	head.name = "NextTitle"
	head.theme_type_variation = &"TitleLabel"
	box.add_child(head)
	var card := _panel(Color(0.08, 0.06, 0.13, 0.9), Color(UiKit.GOLD if boss else _accent, 0.5))
	card.name = "Foe"
	box.add_child(card)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	card.add_child(row)
	var portrait := EnemyPortrait.new()
	portrait.name = "FoePortrait"
	portrait.custom_minimum_size = Vector2(180, 180)
	portrait.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE
	portrait.archetype = String(def.get("portrait", "brute"))
	portrait.tint = Color.from_hsv(fmod(float(abs(String(def.get("id", "")).hash())) / 1000.0, 1.0), 0.55, 0.75)
	portrait.boss = boss
	portrait.art_id = String(def.get("id", ""))
	row.add_child(portrait)
	var info := VBoxContainer.new()
	info.add_theme_constant_override("separation", 6)
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_child(info)
	var name_l := UiKit.label(tr(String(def.get("name", ""))), 30, UiKit.GOLD if boss else Color.WHITE, true)
	name_l.name = "FoeName"
	info.add_child(name_l)
	var text := String(def.get("text", ""))
	if text != "":
		info.add_child(UiKit.label(tr(text), 18, Color(0.92, 0.9, 0.96), true))
	if boss and String(def.get("rule2_text", "")) != "":
		info.add_child(UiKit.label(tr(String(def.get("rule2_text", ""))), 15, Color(1.0, 0.7, 0.55), true))
	var base := GameState.tower_hp(a) if tower else GameState.enemy_hp_for_ante(GameState.RUSH_HP_ANTE)
	if tower and boss:
		base = int(round(base * GameState.TOWER_BOSS_HP))
	var hp := int(round(base * float(def.get("hp_mult", 1.0)) * (1.0 + GameState.relic_passive("enemy_hp_pct") / 100.0)))
	var facts := tr("Vida %s  ·  Ataque %d  ·  %d turnos") % [Cascade.fmt_short(hp), int(def.get("attack", 0)), GameState.turns_for_ante(a)]
	var fl := UiKit.label(facts, 17, UiKit.TEXT_DIM)
	fl.name = "FoeFacts"
	info.add_child(fl)
	var note := ""
	if tower:
		var to_boss := GameState.TOWER_BOSS_EVERY - ((a - 1) % GameState.TOWER_BOSS_EVERY) - 1
		note = tr("O boss seguinte está no andar %d.") % (a + to_boss) if not boss else tr("Vence-o e escolhes uma relíquia de boss.")
	elif a > 1:
		note = tr("Curaste %d de vida ao vencer o boss anterior.") % GameState.rush_heal_amount()
	else:
		note = tr("Entre bosses curas 30 % da vida máxima. Sem loja: conta só o teu baralho.")
	var nl := UiKit.label(note, 16, UiKit.TEXT_DIM, true)
	nl.name = "Note"
	box.add_child(nl)
	if not tower and Economy.side_shop_open():   # 0.19.0 (88): o Mercador da Corrida, de 3 em 3 bosses
		box.add_child(_shop_button())
	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(spacer)
	var go := UiKit.button(tr("SUBIR AO ANDAR %d") % a if tower else (tr("ENFRENTAR O BOSS")), 64, 24, UiKit.PRIMARY, Color(0, 0, 0, 0))
	go.name = "Fight"
	go.custom_minimum_size.x = 380
	go.size_flags_horizontal = Control.SIZE_SHRINK_END
	go.set_meta("haptic", true)
	UiKit.gold_plate(go, true)
	go.pressed.connect(_fight)
	box.add_child(go)

func _fight() -> void:
	if _busy or SceneRouter.has_overlay():
		return
	_busy = true
	Sfx.boom()
	GameState.map_choice = {"battle": "boss" if GameState.is_boss_ante(GameState.ante) else "scout"}
	GameState.save_run({}, "tower")
	SceneRouter.go("battle")

## 87, 88: o botão da loja (abre a SideShop).
func _shop_button() -> Button:
	var b := UiKit.button(tr("LOJA DA TORRE") if _tower() else tr("MERCADOR DA CORRIDA"), 52, 18, UiKit.BG_LIGHT, UiKit.GOLD)
	b.name = "SideShopBtn"
	b.custom_minimum_size.x = 300
	b.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	UiKit.button_icon(b, "shop", UiKit.GOLD, 22.0, false)
	b.pressed.connect(func():
		if not SceneRouter.has_overlay():
			Sfx.select()
			SideShop.open(_build))
	return b

# --- Outros ---

func _zoom(c: CardInstance) -> void:
	if not SceneRouter.has_overlay():
		CardZoom.show_card(c)

## 0.19.0 (58): «A minha run» (relíquias, a ordem delas, formações…).
func _open_run_info() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	RunInfo.open("relics", func(): GameState.save_run({}, "tower"))

func _show_relics() -> void:
	var all: Array = GameState.relic_ids.duplicate()
	all.append_array(GameState.boss_relics)
	if all.is_empty():
		SceneRouter.toast(tr("Ainda não tens relíquias."), 1.8)
		return
	var lines: Array[String] = []
	for id in all:
		var r: Dictionary = CardDB.relics.get(String(id), {})
		lines.append("• %s — %s" % [tr(String(r.get("name", id))), tr(String(r.get("text", "")))])
	ChoiceDialog.open(tr("AS TUAS RELÍQUIAS"), "\n".join(PackedStringArray(lines)), [[tr("FECHAR"), null, true]])

func _on_menu() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	GameState.save_run({}, "tower")
	SceneRouter.go("main")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		_on_menu()
