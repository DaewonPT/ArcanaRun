extends Control
## TALENTOS (0.11.0): pontos ganhos no fim de cada run (1 por ante vencido, +2 se venceres) que
## compram vantagens permanentes (data/talents.json). Valem em todas as runs menos nos Desafios;
## podem desligar-se, e os pontos podem ser devolvidos.
## 0.12.0: árvore com 3 ramos (Economia, Combate, Sobrevivência), 6 talentos cada; os do nível 2 pedem
## 5 pontos gastos no ramo e os do nível 3 pedem 12.
## 0.16.1 (V53, escolha A do AlizeOnMe): a árvore desenhada — em cada ramo, os níveis um por baixo do outro,
## com os talentos em medalhões (o ícone de talents.json "icon"), os níveis comprados em pontos por baixo
## e linhas a ligar os níveis. Tocar num talento mostra-o na barra de baixo (o que dá agora e no próximo
## nível) com COMPRAR. Por trás, o fundo do menu, sossegado (V57).

const BRANCH_COLORS := {"economy": Color(0.98, 0.78, 0.3), "combat": Color(1.0, 0.5, 0.45), "survival": Color(0.5, 0.9, 0.6)}
const NODE := 66.0
const LOCKED := Color(0.42, 0.4, 0.48)

var _points_label: Label
var _columns: HBoxContainer
var _toggle: Button
var _reset: Button
var _confirm_reset := false
var _detail: PanelContainer
var _sel := "t_gold"

func _ready() -> void:
	var backdrop := MenuBackdrop.new()
	backdrop.name = "MenuBackdrop"
	backdrop.quiet = true
	add_child(backdrop)
	move_child(backdrop, mini(1, get_child_count() - 1))
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 10)
	margin.add_theme_constant_override("margin_bottom", 22)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var back := UiKit.menu_button(52, 20)
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("TALENTOS"), 30, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(title)
	var star := CardIcon.new("star", UiKit.GOLD, 22.0)
	star.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	header.add_child(star)
	_points_label = UiKit.label("", 21, UiKit.GOLD)
	_points_label.name = "Points"
	_points_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_points_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(_points_label)
	_toggle = UiKit.button("", 52, 17)
	_toggle.name = "Toggle"
	_toggle.custom_minimum_size.x = 220
	_toggle.pressed.connect(func():
		Sfx.select()
		GameState.set_talents_enabled(not GameState.talents_enabled())
		_refresh())
	header.add_child(_toggle)
	_reset = UiKit.button("", 52, 17)
	_reset.name = "Reset"
	_reset.custom_minimum_size.x = 210
	_reset.pressed.connect(_on_reset)
	header.add_child(_reset)
	_columns = HBoxContainer.new()
	_columns.name = "Tree"
	_columns.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_columns.add_theme_constant_override("separation", 18)
	vbox.add_child(_columns)
	_detail = PanelContainer.new()
	_detail.name = "TalentDetail"
	_detail.custom_minimum_size = Vector2(0, 78)
	_detail.add_theme_stylebox_override("panel", UiKit.flat(Color(0.075, 0.06, 0.12, 0.92), 14, Color(0.42, 0.36, 0.6, 0.85), 2, 12))
	vbox.add_child(_detail)
	SwipeArea.attach(self, _columns, _on_swipe)   # 0.19.0 (9): deslizar passa ao ramo ao lado
	_refresh()

## 0.19.0 (9): deslizar para o lado escolhe o talento do mesmo nível no ramo ao lado.
func _on_swipe(direction: int) -> void:
	var cur := {}
	for t in CardDB.talents:
		if String(t.get("id", "")) == _sel:
			cur = t
	var branches: Array = GameState.TALENT_BRANCHES.map(func(b): return String(b))
	var nb := String(SwipeArea.step_id(branches, String(cur.get("branch", branches[0])), direction))
	if nb == String(cur.get("branch", "")):
		return
	var tier := int(cur.get("tier", 1))
	var pick := ""
	for t in CardDB.talents:
		if String(t.get("branch", "")) == nb and (pick == "" or int(t.get("tier", 1)) == tier):
			if pick == "" or int(t.get("tier", 1)) == tier:
				pick = String(t.get("id", ""))
				if int(t.get("tier", 1)) == tier:
					break
	if pick != "":
		Sfx.select()
		_sel = pick
		_refresh()

func _refresh() -> void:
	_points_label.text = tr("%d pontos") % GameState.talent_points()
	_toggle.text = tr("Talentos: LIGADOS") if GameState.talents_enabled() else tr("Talentos: DESLIGADOS")
	_toggle.add_theme_color_override("font_color", Color(0.6, 0.95, 0.65) if GameState.talents_enabled() else UiKit.TEXT_DIM)
	_reset.text = tr("TENS A CERTEZA?") if _confirm_reset else tr("DEVOLVER PONTOS")
	UiKit.clear_children(_columns)
	for branch in GameState.TALENT_BRANCHES:
		_columns.add_child(_branch_column(String(branch)))
	_show_detail()

## Um ramo: o nome e os pontos gastos, e os três níveis (um por linha) ligados por um traço.
func _branch_column(branch: String) -> VBoxContainer:
	var bcol: Color = BRANCH_COLORS.get(branch, UiKit.GOLD)
	var col := VBoxContainer.new()
	col.name = "Branch_" + branch
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 2)
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 10)
	col.add_child(head)
	var name_l := UiKit.label(tr(String(GameState.TALENT_BRANCH_NAMES.get(branch, branch))).to_upper(), 20, bcol)
	head.add_child(name_l)
	var spent := UiKit.label(tr("%d pontos gastos") % GameState.talent_branch_spent(branch), 14, UiKit.TEXT_DIM)
	spent.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	spent.size_flags_vertical = Control.SIZE_FILL
	head.add_child(spent)
	var rows: Array[Control] = []
	for tier in [1, 2, 3]:
		var need := int(GameState.TALENT_TIER_POINTS.get(tier, 0))
		var tl := UiKit.label(tr("NÍVEL %d") % tier if need == 0 else tr("NÍVEL %d · %d pontos neste ramo") % [tier, need], 12, UiKit.TEXT_DIM)
		tl.name = "Tier_%d" % tier
		col.add_child(tl)
		var row := HBoxContainer.new()
		row.name = "Row_%d" % tier
		row.alignment = BoxContainer.ALIGNMENT_CENTER
		row.add_theme_constant_override("separation", 14)
		col.add_child(row)
		rows.append(row)
		var list: Array = CardDB.talents.filter(func(t): return String(t.get("branch", "")) == branch and int(t.get("tier", 1)) == tier)
		for t in list:
			row.add_child(_talent_node(t, bcol))
	# Traço tracejado entre os níveis (na cor do ramo se o nível de baixo já está aberto).
	col.draw.connect(func():
		for i in range(rows.size() - 1):
			var a: Control = rows[i]
			var b: Control = rows[i + 1]
			var x := col.size.x * 0.5
			var y0 := a.position.y + a.size.y - 34.0
			var y1 := b.position.y + 6.0
			var open := GameState.talent_branch_spent(branch) >= int(GameState.TALENT_TIER_POINTS.get(i + 2, 0))
			var c := Color(bcol, 0.7) if open else Color(LOCKED, 0.5)
			var y := y0
			while y < y1:
				col.draw_line(Vector2(x, y), Vector2(x, minf(y + 6.0, y1)), c, 2.0)
				y += 11.0)
	return col

## Medalhão de um talento: o ícone num círculo (aro na cor do ramo; cinzento se o nível está fechado),
## os níveis em pontos por baixo e o nome.
func _talent_node(t: Dictionary, bcol: Color) -> Button:
	var id := String(t.get("id", ""))
	var lv := GameState.talent_level(id)
	var max_lv := (t.get("values", []) as Array).size()
	var open := GameState.talent_tier_open(id)
	var b := Button.new()
	b.name = "Talent_" + id
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(118, 130)
	var empty := StyleBoxEmpty.new()
	for st in ["normal", "hover", "pressed", "hover_pressed", "disabled", "focus"]:
		b.add_theme_stylebox_override(st, empty)
	var ring := bcol if open else LOCKED
	var sel := id == _sel
	b.draw.connect(func():
		var c := Vector2(b.size.x * 0.5, 6.0 + NODE * 0.5)
		var r := NODE * 0.5
		if sel:
			b.draw_texture_rect(MenuBackdrop.glow_texture(), Rect2(c - Vector2(r, r) * 1.7, Vector2(r, r) * 3.4), false, Color(UiKit.GOLD, 0.4))
		b.draw_circle(c, r, Color(0.09, 0.07, 0.15) if lv == 0 else Color(ring.darkened(0.62), 1.0))
		b.draw_arc(c, r - 2.0, 0.0, TAU, 48, UiKit.GOLD if sel else Color(ring, 0.95 if open else 0.5), 3.5 if (sel or lv >= max_lv) else 2.5, true)
		# os níveis: pontos cheios (comprados) e vazios
		var gap := 13.0
		var y := c.y + r + 10.0
		for i in max_lv:
			var p := Vector2(c.x + (i - (max_lv - 1) * 0.5) * gap, y)
			if i < lv:
				b.draw_circle(p, 4.5, UiKit.GOLD)
			else:
				b.draw_arc(p, 4.0, 0.0, TAU, 16, Color(1, 1, 1, 0.45 if open else 0.25), 1.4, true))
	var icon := CardIcon.new(String(t.get("icon", "star")), ring.lightened(0.15) if open else LOCKED, 30.0)
	icon.position = Vector2((118.0 - 30.0) * 0.5, 6.0 + (NODE - 30.0) * 0.5)
	icon.size = Vector2(30, 30)
	b.add_child(icon)
	var name_l := UiKit.label(tr(String(t.get("name", ""))), 13, Color.WHITE if open else UiKit.TEXT_DIM, true)
	name_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_l.max_lines_visible = 2
	name_l.clip_text = true
	name_l.position = Vector2(0, 6.0 + NODE + 18.0)
	name_l.size = Vector2(118, 40)
	b.add_child(name_l)
	b.pressed.connect(func():
		Sfx.select()
		_sel = id
		_refresh())
	return b

## Valor de um talento como aparece no texto ("5", "0.5").
static func _fmt(v) -> String:
	var f := float(v)
	return str(int(f)) if is_equal_approx(f, round(f)) else String.num(f, 1)

## O texto do talento num nível (1 = o primeiro).
static func talent_text(t: Dictionary, level: int) -> String:
	var tmpl := TranslationServer.translate(String(t.get("text", "")))
	var values: Array = t.get("values", [])
	if values.is_empty() or not (tmpl.contains("%d") or tmpl.contains("%s")):
		return tmpl
	return tmpl.replace("%d", "%s") % _fmt(values[clampi(level, 1, values.size()) - 1])

## A barra de baixo: o talento escolhido, o que dá (agora e no próximo nível) e COMPRAR.
func _show_detail() -> void:
	UiKit.clear_children(_detail)
	var t := CardDB.get_talent(_sel)
	if t.is_empty():
		return
	var id := _sel
	var lv := GameState.talent_level(id)
	var values: Array = t.get("values", [])
	var max_lv := values.size()
	var open := GameState.talent_tier_open(id)
	var bcol: Color = BRANCH_COLORS.get(String(t.get("branch", "")), UiKit.GOLD)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	_detail.add_child(row)
	var medal := Control.new()
	medal.custom_minimum_size = Vector2(52, 52)
	medal.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	medal.draw.connect(func():
		medal.draw_circle(medal.size * 0.5, 25.0, Color(0.09, 0.07, 0.15))
		medal.draw_arc(medal.size * 0.5, 24.0, 0.0, TAU, 40, bcol if open else LOCKED, 2.5, true))
	var icon := CardIcon.new(String(t.get("icon", "star")), bcol.lightened(0.15) if open else LOCKED, 26.0)
	icon.position = Vector2(13, 13)
	icon.size = Vector2(26, 26)
	medal.add_child(icon)
	row.add_child(medal)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_theme_constant_override("separation", 2)
	row.add_child(col)
	var pips := ""
	for i in max_lv:
		pips += "●" if i < lv else "○"
	var title := UiKit.label("%s   %s" % [tr(String(t.get("name", ""))), pips], 19, Color.WHITE)
	title.name = "DetailName"
	col.add_child(title)
	var desc := talent_text(t, maxi(lv, 1))
	if max_lv > 1:
		var steps: PackedStringArray = []
		for v in values:
			steps.append(_fmt(v))
		desc += "   " + tr("Níveis: %s") % " → ".join(steps)
	if lv >= max_lv and max_lv > 0:
		desc += "  " + tr("(no máximo)")
	var earned := Economy.talent_gold(id)   # 0.19.0 (99)
	if earned > 0:
		desc += "  " + tr("Já rendeu +%d ouro nas tuas runs.") % earned
	if not open:
		var tier := int(t.get("tier", 1))
		desc = tr("Nível %d: precisa de %d pontos gastos neste ramo.") % [tier, int(GameState.TALENT_TIER_POINTS.get(tier, 0))] + "  " + desc
	var dl := UiKit.label(desc, 14, UiKit.TEXT_DIM, true)
	dl.name = "DetailText"
	col.add_child(dl)
	var cost := GameState.talent_next_cost(id)
	var label := tr("NO MÁXIMO") if cost < 0 else (tr("FECHADO") if not open else tr("COMPRAR · %d") % cost)
	var can := cost >= 0 and open and GameState.talent_points() >= cost
	var buy := UiKit.button(label, 52, 18, UiKit.PRIMARY if can else UiKit.BG_LIGHT, Color(0, 0, 0, 0))
	buy.name = "Buy"
	buy.custom_minimum_size.x = 200
	buy.disabled = not can
	buy.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	if can:
		UiKit.gold_plate(buy, true)
	buy.pressed.connect(func():
		if GameState.buy_talent(id):
			Sfx.level_up()
			_refresh())
	row.add_child(buy)

func _on_reset() -> void:
	if not _confirm_reset:
		_confirm_reset = true
		Sfx.select()
		_refresh()
		await get_tree().create_timer(3.0).timeout
		if is_inside_tree() and _confirm_reset:
			_confirm_reset = false
			_refresh()
		return
	_confirm_reset = false
	GameState.reset_talents()
	Sfx.hit()
	_refresh()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
