extends Control
## TALENTOS (0.11.0): pontos ganhos no fim de cada run (1 por ante vencido, +2 se venceres) que
## compram vantagens permanentes (data/talents.json). Valem em todas as runs menos nos Desafios;
## podem desligar-se, e os pontos podem ser devolvidos.
## 0.12.0: árvore com 3 ramos (Economia, Combate, Sobrevivência), 6 talentos cada; os do nível 2 pedem
## 5 pontos gastos no ramo e os do nível 3 pedem 12.

const BRANCH_COLORS := {"economy": Color(0.98, 0.78, 0.3), "combat": Color(1.0, 0.5, 0.45), "survival": Color(0.5, 0.9, 0.6)}

var _points_label: Label
var _columns: HBoxContainer
var _toggle: Button
var _reset: Button
var _confirm_reset := false

func _ready() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 30)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var back := UiKit.button(tr("◀ MENU"), 48, 18)
	back.custom_minimum_size.x = 120
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("TALENTOS"), 26, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(title)
	_points_label = UiKit.label("", 20, UiKit.GOLD)
	_points_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_points_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(_points_label)
	_toggle = UiKit.button("", 48, 16)
	_toggle.custom_minimum_size.x = 230
	_toggle.pressed.connect(func():
		Sfx.select()
		GameState.set_talents_enabled(not GameState.talents_enabled())
		_refresh())
	header.add_child(_toggle)
	_reset = UiKit.button("", 48, 16)
	_reset.custom_minimum_size.x = 200
	_reset.pressed.connect(_on_reset)
	header.add_child(_reset)
	var info := UiKit.label(tr("Ganhas 1 ponto por cada ante vencido (+2 se venceres a run). Os talentos do nível 2 de cada ramo pedem 5 pontos gastos nesse ramo; os do nível 3 pedem 12. Valem em todas as runs, menos nos Desafios."), 14, UiKit.TEXT_DIM, true)
	vbox.add_child(info)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)
	_columns = HBoxContainer.new()
	_columns.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_columns.add_theme_constant_override("separation", 12)
	scroll.add_child(_columns)
	_refresh()

func _refresh() -> void:
	_points_label.text = tr("Pontos: %d") % GameState.talent_points()
	_toggle.text = tr("Talentos: LIGADOS") if GameState.talents_enabled() else tr("Talentos: DESLIGADOS")
	_toggle.add_theme_color_override("font_color", Color(0.6, 0.95, 0.65) if GameState.talents_enabled() else UiKit.TEXT_DIM)
	_reset.text = tr("TENS A CERTEZA?") if _confirm_reset else tr("DEVOLVER PONTOS")
	UiKit.clear_children(_columns)
	for branch in GameState.TALENT_BRANCHES:
		var col := VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.add_theme_constant_override("separation", 8)
		col.name = "Branch_" + String(branch)
		_columns.add_child(col)
		var bcol: Color = BRANCH_COLORS.get(branch, UiKit.GOLD)
		var head := UiKit.label("%s  ·  %s" % [tr(String(GameState.TALENT_BRANCH_NAMES.get(branch, branch))).to_upper(), tr("%d pontos gastos") % GameState.talent_branch_spent(String(branch))], 18, bcol)
		col.add_child(head)
		var list: Array = CardDB.talents.filter(func(t): return String(t.get("branch", "")) == String(branch))
		list.sort_custom(func(a, b): return int(a.get("tier", 1)) < int(b.get("tier", 1)))
		for t in list:
			col.add_child(_talent_tile(t, bcol))

## Valor de um talento como aparece no texto ("5", "0.5").
static func _fmt(v) -> String:
	var f := float(v)
	return str(int(f)) if is_equal_approx(f, round(f)) else String.num(f, 1)

func _talent_tile(t: Dictionary, bcol: Color) -> Control:
	var id := String(t.get("id", ""))
	var lv := GameState.talent_level(id)
	var values: Array = t.get("values", [])
	var max_lv := values.size()
	var cost := GameState.talent_next_cost(id)
	var open := GameState.talent_tier_open(id)
	var panel := PanelContainer.new()
	panel.name = "Talent_" + id
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var bg := Color(0.16, 0.3, 0.2) if lv > 0 else (UiKit.BG_LIGHT if open else Color(0.11, 0.1, 0.15))
	panel.add_theme_stylebox_override("panel", UiKit.flat(bg, 12, bcol if lv >= max_lv else Color(0, 0, 0, 0), 2 if lv >= max_lv else 0, 8))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	panel.add_child(row)
	var texts := VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.add_theme_constant_override("separation", 0)
	row.add_child(texts)
	var pips := ""
	for i in max_lv:
		pips += "●" if i < lv else "○"
	var tier := int(t.get("tier", 1))
	texts.add_child(UiKit.label("%s  %s" % [tr(String(t.get("name", ""))), pips], 17, Color.WHITE if open else UiKit.TEXT_DIM))
	var tmpl := tr(String(t.get("text", "")))
	var shown = values[maxi(lv, 1) - 1] if not values.is_empty() else 0
	var desc := tmpl
	if tmpl.contains("%d") or tmpl.contains("%s"):
		desc = tmpl.replace("%d", "%s") % _fmt(shown)
		if lv > 0 and lv < max_lv:
			desc += "  " + tr("(próximo: %s)") % _fmt(values[lv])
	if not open:
		desc = tr("Nível %d: precisa de %d pontos gastos neste ramo.") % [tier, int(GameState.TALENT_TIER_POINTS.get(tier, 0))] + "  " + desc
	var d := UiKit.label(desc, 13, UiKit.TEXT_DIM, true)
	texts.add_child(d)
	var label := tr("NO MÁXIMO") if cost < 0 else (tr("FECHADO") if not open else tr("COMPRAR · %d") % cost)
	var can := cost >= 0 and open and GameState.talent_points() >= cost
	var buy := UiKit.button(label, 48, 14, UiKit.PRIMARY.darkened(0.2) if can else UiKit.BG_LIGHT, Color(0, 0, 0, 0))
	buy.name = "Buy"
	buy.custom_minimum_size.x = 112
	buy.disabled = not can
	buy.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	buy.pressed.connect(func():
		if GameState.buy_talent(id):
			Sfx.level_up()
			_refresh())
	row.add_child(buy)
	return panel

func _on_reset() -> void:
	if not _confirm_reset:
		_confirm_reset = true
		Sfx.select()
		_refresh()
		await get_tree().create_timer(3.0).timeout
		if is_inside_tree() and _confirm_reset:
			_confirm_reset = false
			_refresh()
		return
	_confirm_reset = false
	GameState.reset_talents()
	Sfx.hit()
	_refresh()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
