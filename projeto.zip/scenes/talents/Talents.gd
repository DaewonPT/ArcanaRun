extends Control
## TALENTOS (0.11.0): pontos ganhos no fim de cada run (1 por ante vencido, +2 se venceres) que
## compram vantagens permanentes (data/talents.json): ouro e vida no início, juros, descontos na loja,
## cura depois dos bosses, Poder nas criaturas iniciais, uma relíquia e uma canalização extra.
## Valem em todas as runs menos nos Desafios; podem desligar-se, e os pontos podem ser devolvidos.

var _points_label: Label
var _grid: GridContainer
var _toggle: Button
var _reset: Button
var _confirm_reset := false

func _ready() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	margin.add_child(vbox)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var back := UiKit.button(tr("◀ MENU"), 48, 18)
	back.custom_minimum_size.x = 120
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("TALENTOS"), 26, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	_points_label = UiKit.label("", 20, UiKit.GOLD)
	_points_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(_points_label)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	vbox.add_child(row)
	var info := UiKit.label(tr("Ganhas 1 ponto por cada ante vencido (+2 se venceres a run). Os talentos valem em todas as runs, menos nos Desafios."), 15, UiKit.TEXT_DIM, true)
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(info)
	_toggle = UiKit.button("", 48, 16)
	_toggle.custom_minimum_size.x = 230
	_toggle.pressed.connect(func():
		Sfx.select()
		GameState.set_talents_enabled(not GameState.talents_enabled())
		_refresh())
	row.add_child(_toggle)
	_reset = UiKit.button("", 48, 16)
	_reset.custom_minimum_size.x = 200
	_reset.pressed.connect(_on_reset)
	row.add_child(_reset)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)
	_grid = GridContainer.new()
	_grid.columns = 2
	_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_grid.add_theme_constant_override("h_separation", 12)
	_grid.add_theme_constant_override("v_separation", 10)
	scroll.add_child(_grid)
	_refresh()

func _refresh() -> void:
	_points_label.text = tr("Pontos: %d") % GameState.talent_points()
	_toggle.text = tr("Talentos: LIGADOS") if GameState.talents_enabled() else tr("Talentos: DESLIGADOS")
	_toggle.add_theme_color_override("font_color", Color(0.6, 0.95, 0.65) if GameState.talents_enabled() else UiKit.TEXT_DIM)
	_reset.text = tr("TENS A CERTEZA?") if _confirm_reset else tr("DEVOLVER PONTOS")
	for c in _grid.get_children():
		_grid.remove_child(c)
		c.queue_free()
	for t in CardDB.talents:
		_grid.add_child(_talent_tile(t))

func _talent_tile(t: Dictionary) -> Control:
	var id := String(t.get("id", ""))
	var lv := GameState.talent_level(id)
	var values: Array = t.get("values", [])
	var max_lv := values.size()
	var cost := GameState.talent_next_cost(id)
	var panel := PanelContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.16, 0.3, 0.2) if lv > 0 else UiKit.BG_LIGHT, 12, UiKit.GOLD if lv >= max_lv else Color(0, 0, 0, 0), 2 if lv >= max_lv else 0, 12))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	panel.add_child(row)
	var texts := VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.add_theme_constant_override("separation", 2)
	row.add_child(texts)
	var pips := ""
	for i in max_lv:
		pips += "●" if i < lv else "○"
	texts.add_child(UiKit.label("%s  %s" % [tr(String(t.get("name", ""))), pips], 19, Color.WHITE))
	var tmpl := tr(String(t.get("text", "")))
	var shown: int = int(values[maxi(lv, 1) - 1]) if not values.is_empty() else 0
	var desc := tmpl % shown if tmpl.contains("%d") else tmpl
	if lv > 0 and lv < max_lv and tmpl.contains("%d"):
		desc += "  " + tr("(próximo: %d)") % int(values[lv])
	texts.add_child(UiKit.label(desc, 15, UiKit.TEXT_DIM, true))
	var buy := UiKit.button(tr("NO MÁXIMO") if cost < 0 else tr("COMPRAR · %d") % cost, 50, 16, UiKit.PRIMARY.darkened(0.2) if cost >= 0 and GameState.talent_points() >= cost else UiKit.BG_LIGHT, Color(0, 0, 0, 0))
	buy.custom_minimum_size.x = 150
	buy.disabled = cost < 0 or GameState.talent_points() < cost
	buy.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	buy.pressed.connect(func():
		if GameState.buy_talent(id):
			Sfx.boom()
			_refresh())
	row.add_child(buy)
	return panel

func _on_reset() -> void:
	if not _confirm_reset:
		_confirm_reset = true
		Sfx.select()
		_refresh()
		await get_tree().create_timer(3.0).timeout
		if is_inside_tree() and _confirm_reset:
			_confirm_reset = false
			_refresh()
		return
	_confirm_reset = false
	GameState.reset_talents()
	Sfx.hit()
	_refresh()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
