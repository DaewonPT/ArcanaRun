extends Control
## Baú de Espólio: depois de vencer um boss que não acaba a run, escolhe 1 de 3 relíquias de boss.
## São fortes mas têm um custo, e ficam num espaço à parte (não contam para o limite de 5).
## As ofertas ficam em GameState.loot_offer (gravadas): fechar a app aqui mostra as mesmas.

const PANEL_COLOR := Color(0.2, 0.1, 0.12)
const BORDER := Color(0.85, 0.3, 0.3)

var _picked := false
var _cards: HBoxContainer

func _ready() -> void:
	if GameState.loot_offer.is_empty():
		GameState.prepare_loot()
	GameState.save_run({}, "loot")
	if GameState.loot_offer.is_empty():
		_leave_when_ready()
		return
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 60)
	margin.add_theme_constant_override("margin_top", 24)
	margin.add_theme_constant_override("margin_bottom", 40)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 14)
	margin.add_child(vbox)
	var title := UiKit.label(tr("BAÚ DE ESPÓLIO"), 44, UiKit.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	var sub := UiKit.label(tr("O boss caiu. Do que deixou para trás, leva uma coisa — o poder dos bosses tem sempre um preço."), 20, UiKit.TEXT_DIM, true)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(sub)
	var center := CenterContainer.new()
	center.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(center)
	_cards = HBoxContainer.new()
	_cards.add_theme_constant_override("separation", 22)
	center.add_child(_cards)
	var delay := 0.0
	for id in GameState.loot_offer:
		var r: Dictionary = CardDB.relics.get(id, {})
		var b := Button.new()
		b.custom_minimum_size = Vector2(330, 300)
		b.focus_mode = Control.FOCUS_NONE
		var style := UiKit.flat(PANEL_COLOR, 18, BORDER, 3, 18)
		b.add_theme_stylebox_override("normal", style)
		b.add_theme_stylebox_override("hover", style)
		b.add_theme_stylebox_override("pressed", UiKit.flat(PANEL_COLOR.lightened(0.15), 18, UiKit.GOLD, 4, 18))
		b.add_theme_stylebox_override("disabled", UiKit.flat(PANEL_COLOR.darkened(0.4), 18, Color(0.3, 0.2, 0.2), 2, 18))
		var inner := VBoxContainer.new()
		inner.set_anchors_preset(Control.PRESET_FULL_RECT)
		inner.offset_left = 20
		inner.offset_right = -20
		inner.offset_top = 18
		inner.offset_bottom = -18
		inner.mouse_filter = Control.MOUSE_FILTER_IGNORE
		inner.add_theme_constant_override("separation", 10)
		b.add_child(inner)
		var icon := CardIcon.new("relic", UiKit.GOLD, 46.0)
		icon.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		inner.add_child(icon)
		var name_l := UiKit.label(tr(String(r.get("name", id))), 26, UiKit.GOLD, true)
		name_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		inner.add_child(name_l)
		var kind := UiKit.label(tr("Relíquia de boss"), 15, Color(0.9, 0.55, 0.55))
		kind.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		inner.add_child(kind)
		var text := UiKit.label(tr(String(r.get("text", ""))), 20, Color.WHITE, true)
		text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		text.size_flags_vertical = Control.SIZE_EXPAND_FILL
		inner.add_child(text)
		b.pressed.connect(_on_pick.bind(String(id)))
		_cards.add_child(b)
		_appear(b, delay)
		delay += 0.12
	var brow := HBoxContainer.new()
	brow.alignment = BoxContainer.ALIGNMENT_CENTER
	brow.add_theme_constant_override("separation", 16)
	vbox.add_child(brow)
	var skip := UiKit.button(tr("NÃO LEVAR NADA"), 50, 18)
	skip.custom_minimum_size.x = 260
	skip.pressed.connect(func():
		if _picked:
			return
		_picked = true
		Sfx.select()
		GameState.loot_offer.clear()
		_continue())
	brow.add_child(skip)
	# 0.19.0 (82): renovar o baú uma vez, a pagar.
	var price := GameState.shop_price(Economy.LOOT_RENEW_PRICE)
	var renew := UiKit.button(tr("RENOVAR O BAÚ · %d") % price, 50, 18)
	renew.name = "Renew"
	renew.custom_minimum_size.x = 260
	UiKit.button_icon(renew, "replay", Color.WHITE, 20.0, false)
	renew.disabled = Economy.loot_renewed() or GameState.gold < price
	renew.tooltip_text = tr("Troca as 3 relíquias por outras 3 (uma vez por baú).")
	renew.pressed.connect(renew_loot)
	brow.add_child(renew)
	Sfx.boom()

## 82: RENOVAR (também usado pelos testes): paga e mostra outras 3 relíquias de boss.
func renew_loot() -> void:
	if _picked or not Economy.renew_loot():
		Sfx.deny()
		return
	Sfx.shuffle()
	GameState.save_run({}, "loot")
	SceneRouter.go("loot")

func _appear(view: Control, delay: float) -> void:
	view.modulate.a = 0.0
	await get_tree().process_frame
	if not is_instance_valid(view):
		return
	view.pivot_offset = view.size / 2.0
	view.scale = Vector2(0.8, 0.8)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(view, "modulate:a", 1.0, Settings.dur(0.25)).set_delay(Settings.dur(delay))
	tw.tween_property(view, "scale", Vector2.ONE, Settings.dur(0.3)).set_delay(Settings.dur(delay)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)

func _on_pick(id: String) -> void:
	if _picked:
		return
	_picked = true
	GameState.add_boss_relic(id)
	Sfx.boom()
	Settings.vibrate(40)
	for b in _cards.get_children():
		(b as Button).disabled = true
	SceneRouter.toast(tr("%s é tua.") % tr(String(CardDB.relics.get(id, {}).get("name", id))), 2.0)
	await get_tree().create_timer(Settings.dur(0.6) + 0.05).timeout
	_continue()

## Sem nada para oferecer: segue para o mapa assim que a troca de cena acabar.
func _leave_when_ready() -> void:
	while SceneRouter.is_busy():
		await get_tree().process_frame
	_continue()

func _continue() -> void:
	GameState.save_run({}, "map")
	SceneRouter.go("map")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		Sfx.select()
