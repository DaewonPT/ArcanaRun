extends Control
## Evento (nó do mapa): uma situação da campanha com 2–4 escolhas. Os efeitos vêm de data/events.json:
##   gold ±N · heal N|"full" (negativo = perde vida, nunca abaixo de 1) · max_hp ±N ·
##   relic "random" · card "rare"|"random" · remove_cards N · grow_random N · mult_random X ·
##   recolor N (Fonte de Mana: até N cartas passam à cor principal) · fuse 1 (Altar: sacrifica uma
##   carta, outra herda os efeitos e metade do Poder dela) · seal <id> (uma carta à escolha recebe o
##   selo) · well 1 (Poço: 1 carta sai, entram 2 comuns das tuas cores com o Selo da Fúria) ·
##   swap_cost5 1 (Feira: 1 carta sai, entra uma de custo 5 de qualquer cor) · curse N (Maldições) ·
##   contract <id> · guess <cor> (Circo) · gamble "gold"|"life" + cost (Tribunal: gira a roda "wheel") ·
##   forge_plus 1 (Acampamento → Forjar: uma carta à escolha passa à versão "+")
## 0.13.0: edition shiny|holo|poly (Forja das Edições: uma Criatura ou feitiço à escolha) · card_choice "rare"
##   (Biblioteca: 1 de 3 cartas das tuas cores) · consumable "random"|"potion"|"scroll"|<id> · later
##   {"in": N, "effects": {...}, "text"} (consequência daqui a N antes, ver GameState.add_later).
## Opções dinâmicas ("dynamic"): "contracts" (3 contratos ao acaso) e "guess_color" (3 cores).
## As escolhas que pedem uma carta fazem-no antes de cobrar o custo: cancelar não custa nada.
## Grava-se ao entrar ("event"); ao sair avança o ante e volta ao mapa.

const CURSE_ID := "c314"
const COLOR_IDS := ["white", "blue", "black", "red", "green"]

## 0.12.0 Santuário: preço de cada Bênção (os mesmos efeitos dos eventos; "_text" é o que aparece).
const BLESSING_PRICES := {
	"bless_strength": {"max_hp": -4, "_text": "−4 de vida máxima"},
	"bless_wealth": {"curse": 1, "_text": "uma Maldição no baralho"},
	"bless_insight": {"gold": -10, "_text": "10 ouro"},
	"bless_fury": {"heal": -6, "_text": "6 de vida"},
	"bless_earth": {"gold": -8, "_text": "8 ouro"},
}

var _event: Dictionary = {}
var _options_box: VBoxContainer
var _result: Label
var _continue: Button
var _chosen := false
var _hidden_card: CardData = null      # Circo das Ilusões: a carta escondida
var _cancelled := false                 # o jogador cancelou a escolha de carta: volta às opções
var _options_cache: Array = []
var _art: Texture2D                     # 0.16.0 (52): a ilustração do evento (guardada: o desenho só leva o RID)

func _ready() -> void:
	_event = CardDB.get_event(GameState.pending_event)
	if _event.is_empty():
		_continue_run()
		return
	GameState.save_run({}, "event")
	Stats.on_event_seen()
	_build()

func _build() -> void:
	# As opções primeiro: o número delas decide a altura da ilustração.
	var options := _options()
	_options_cache = options
	var eid := String(_event.get("id", GameState.pending_event))
	Stats.mark_seen("events", eid)   # 0.16.1: para a Galeria (Lugares)
	var art_id := String(_event.get("art", eid))   # 0.17.0: as histórias em cadeia usam ilustrações de outros eventos
	_art = ArtLib.texture("event", art_id)
	if _art != null:
		_add_backdrop(art_id)
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 120)
	margin.add_theme_constant_override("margin_top", 20)
	margin.add_theme_constant_override("margin_bottom", 36)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	margin.add_child(vbox)

	var head_txt := tr("ANTE %d VENCIDO  ·  ATO %s") % [GameState.ante, GameState.act_name()]
	if String(_event.get("chain", "")) != "":   # 0.17.0: história em cadeia
		head_txt += "  ·  " + tr("HISTÓRIA · PARTE %d DE %d") % [int(_event.get("part", 1)), GameState.CHAIN_PARTS]
	var header := UiKit.label(head_txt, 18, UiKit.TEXT_DIM)
	vbox.add_child(header)
	var title := UiKit.label(tr(String(_event.get("title", ""))), 42, UiKit.GOLD)
	var banner: Control = null
	if _art != null:
		banner = _make_banner(title, options.size())
		vbox.add_child(banner)
	else:
		vbox.add_child(title)
	var body := UiKit.label(tr(String(_event.get("text", ""))), 21, Color.WHITE, true)
	vbox.add_child(body)
	# V59: vida, ouro e relíquias com os ícones (em vez de só palavras).
	var status := HBoxContainer.new()
	status.name = "Status"
	status.add_theme_constant_override("separation", 26)
	status.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var hp_row := UiKit.icon_text("heart", "%d/%d" % [GameState.player_hp, GameState.player_max_hp], 18, UiKit.TEXT_DIM, Color(0.92, 0.3, 0.36))
	hp_row.tooltip_text = tr("Vida %d/%d") % [GameState.player_hp, GameState.player_max_hp]
	status.add_child(hp_row)
	status.add_child(UiKit.icon_text("coin", str(GameState.gold), 18, UiKit.TEXT_DIM, UiKit.COIN))
	status.add_child(UiKit.icon_text("relic", "%d/%d" % [GameState.relic_ids.size(), GameState.max_relics()], 18, UiKit.TEXT_DIM, Color(0.75, 0.65, 1.0)))
	vbox.add_child(status)

	_options_box = VBoxContainer.new()
	_options_box.add_theme_constant_override("separation", 8)
	_options_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(_options_box)
	# 0.19.0 (67): a roda do Tribunal — cada setor com a mesma hipótese.
	var wheel: Array = _event.get("wheel", [])
	if not wheel.is_empty():
		var names: Array[String] = []
		for w in wheel:
			names.append(tr(String((w as Dictionary).get("label", ""))))
		var wl := UiKit.label(tr("Na roda (%d setores, %s %% cada): %s.") % [wheel.size(), GameState.fmt_dec(snappedf(100.0 / wheel.size(), 0.1)), ", ".join(PackedStringArray(names))], 17, UiKit.TEXT_DIM, true)
		wl.name = "WheelOdds"
		vbox.add_child(wl)
	var i := 0
	for opt in options:
		var effects: Dictionary = opt.get("effects", {})
		# 0.16.0: o texto da opção parte em duas linhas quando é comprido (antes ficava cortado).
		var opt_txt := "%s  —  %s" % [tr(String(opt.get("label", ""))), String(opt.get("text_tr", tr(String(opt.get("text", "")))))]
		if effects.get("chance") is Dictionary and not opt_txt.contains("%"):   # 0.19.0 (68): a hipótese de ganhar
			opt_txt += "  ·  " + tr("%d %% de ganhar") % int(round(float((effects["chance"] as Dictionary).get("p", 0.5)) * 100.0))
		# 0.20.0 (D13): a altura cresce com o «Texto dos menus» (2 linhas de letra maior não cabiam nos 58/64 px).
		var b := UiKit.wrap_button(opt_txt, roundi((58 if options.size() > 3 else 64) * Settings.menu_text_scale()), 18 if options.size() > 3 else 20, UiKit.PRIMARY if i == 0 else UiKit.BG_LIGHT, Color(0, 0, 0, 0) if i == 0 else UiKit.BORDER)
		b.disabled = not _affordable(effects)
		if String(_event.get("id", "")) == "node_treasure":   # 0.19.0 (85): a cor do baú diz o que tem
			var chest := chest_color(effects)
			if chest.a > 0.0:
				UiKit.button_icon(b, "chest", chest, 30.0, false)
				UiKit.wrap_label(b).offset_left = 56
		b.pressed.connect(_on_option.bind(opt, b))
		_options_box.add_child(b)
		i += 1

	_result = UiKit.label("", 21, Color(0.6, 0.95, 0.7), true)
	_result.visible = false
	vbox.add_child(_result)
	_continue = UiKit.button(tr("CONTINUAR  ▶"), 66, 26, UiKit.PRIMARY, Color(0, 0, 0, 0))
	_continue.visible = false
	_continue.pressed.connect(func(): Sfx.select(); _continue_run())
	vbox.add_child(_continue)
	UiKit.gold_plate(_continue, true)
	UiKit.pop_in(banner if banner != null else title)

## 52: a ilustração do evento numa faixa larga, com o título por cima da parte de baixo, escurecida.
func _make_banner(title: Label, n_options: int) -> Control:
	var banner := Control.new()
	banner.name = "EventArt"
	# 0.20.0 (D13): com o «Texto dos menus» maior a ilustração dá a altura que as opções e o texto ganham (a 130 %:
	# 131 px com 4 opções, 190 px com menos), para tudo continuar a caber em 720.
	var grow := Settings.menu_text_scale() - 1.0
	banner.custom_minimum_size = Vector2(0, roundf(218.0 - grow * 290.0) if n_options > 3 else roundf(262.0 - grow * 240.0))
	banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	banner.draw.connect(_draw_banner.bind(banner))
	banner.add_child(title)
	title.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	title.offset_left = 26
	title.offset_right = -26
	title.offset_top = -70
	title.offset_bottom = -12
	title.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	UiKit.outline_for(title, UiKit.GOLD, 8)
	return banner

func _draw_banner(b: Control) -> void:
	if _art == null:
		return
	var r := Rect2(Vector2.ZERO, b.size)
	ArtLib.draw_rounded(b, _art, r, 16.0, 0.42)
	# A metade de baixo escurece até ao fundo (o título lê-se), sem sair dos cantos redondos.
	var y0 := r.size.y * 0.4
	var full := ArtLib.rounded_rect_points(r, 16.0, 5)
	var below := PackedVector2Array([Vector2(-2, y0), Vector2(r.size.x + 2, y0), Vector2(r.size.x + 2, r.size.y + 2), Vector2(-2, r.size.y + 2)])
	for poly in Geometry2D.intersect_polygons(full, below):
		var cols := PackedColorArray()
		for q in poly:
			cols.append(Color(0.05, 0.04, 0.09, 0.9 * clampf((q.y - y0) / maxf(1.0, r.size.y - y0), 0.0, 1.0)))
		b.draw_polygon(poly, cols)
	var frame := StyleBoxFlat.new()
	frame.draw_center = false
	frame.set_corner_radius_all(16)
	frame.set_border_width_all(2)
	frame.border_color = Color(UiKit.GOLD, 0.7)
	b.draw_style_box(frame, r)
	UiKit.draw_gold_corners(b)

## Por trás de tudo, a mesma ilustração esbatida e escura (sem ela, ou em alto contraste, fica a cor lisa).
func _add_backdrop(eid: String) -> void:
	if Settings.high_contrast:
		return
	var blur := ArtLib.blurred("event", eid)
	if blur == null:
		return
	var bg := TextureRect.new()
	bg.name = "EventBackdrop"
	bg.texture = blur
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.modulate = Color(0.34, 0.31, 0.4)
	add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	move_child(bg, mini(1, get_child_count() - 1))

## Opções do evento: as dinâmicas (contratos, cores) primeiro, depois as do JSON.
func _options() -> Array:
	var out: Array = []
	match String(_event.get("dynamic", "")):
		"contracts":
			var pool: Array = CardDB.contracts.duplicate()
			for i in 3:
				if pool.is_empty():
					break
				var c: Dictionary = pool[GameState.rng.randi_range(0, pool.size() - 1)]
				pool.erase(c)
				var reward := GameState.reward_text(c.get("reward", {}))
				out.append({"label": String(c.get("name", "")), "text_tr": tr(String(c.get("text", ""))) + ("  " + tr("Recompensa: %s.") % reward if reward != "" else ""),
					"effects": {"contract": String(c.get("id", ""))}})
		"sanctuary":
			# 0.12.0: duas Bênçãos que ainda não tens, cada uma com o seu preço.
			var pool: Array = BLESSING_PRICES.keys().filter(func(id): return not (id in GameState.blessings))
			for i in 2:
				if pool.is_empty():
					break
				var bid: String = pool[GameState.rng.randi_range(0, pool.size() - 1)]
				pool.erase(bid)
				var price: Dictionary = BLESSING_PRICES[bid]
				var effects: Dictionary = price.duplicate()
				effects["blessing"] = bid
				var r: Dictionary = CardDB.relics.get(bid, {})
				out.append({"label": String(r.get("name", bid)), "text_tr": tr(String(r.get("text", ""))).trim_prefix(tr("Bênção: ")) + "  " + tr("Preço: %s.") % tr(String(price.get("_text", ""))),
					"effects": effects})
		"guess_color":
			var colored: Array = []
			for e in GameState.deck:
				var d := CardDB.get_card(String(e.get("id", "")))
				if d != null and not d.is_colorless():
					colored.append(d)
			if not colored.is_empty():
				_hidden_card = colored[GameState.rng.randi_range(0, colored.size() - 1)]
				var right := String(_hidden_card.colors[GameState.rng.randi_range(0, _hidden_card.colors.size() - 1)])
				var others: Array = COLOR_IDS.filter(func(col): return not (col in _hidden_card.colors))
				var cols: Array = [right]
				for i in 2:
					if others.is_empty():
						break
					var pick: String = others[GameState.rng.randi_range(0, others.size() - 1)]
					others.erase(pick)
					cols.append(pick)
				# Ordem das cores baralhada (a certa não fica sempre em primeiro).
				for i in range(cols.size() - 1, 0, -1):
					var j := GameState.rng.randi_range(0, i)
					var tmp = cols[i]
					cols[i] = cols[j]
					cols[j] = tmp
				for col in cols:
					out.append({"label": String(CardZoom.COLOR_NAMES.get(col, col)), "text": "Se acertares: uma relíquia. Se falhares: uma Maldição.", "effects": {"guess": col}})
	# 0.17.0 histórias em cadeia: "if" = a opção só aparece se uma parte anterior registou essa escolha.
	for o in _event.get("options", []):
		var need := String((o as Dictionary).get("if", "")) if o is Dictionary else ""
		if need != "" and not (need in GameState.chain_tags):
			continue
		out.append(o)
	return out

## 0.19.0 (85): ouro — dourado; carta — azul; relíquia — roxo a brilhar.
static func chest_color(effects: Dictionary) -> Color:
	if effects.has("relic"):
		return Color(0.82, 0.55, 1.0)
	if effects.has("card") or effects.has("card_choice"):
		return Color(0.45, 0.7, 1.0)
	if int(effects.get("gold", 0)) > 0:
		return UiKit.COIN
	return Color(0, 0, 0, 0)

## As opções dependem do ouro/vida atuais (depois de cancelar uma escolha, voltam a avaliar-se).
func _refresh_affordable() -> void:
	var options := _options_cache
	for i in mini(options.size(), _options_box.get_child_count()):
		(_options_box.get_child(i) as Button).disabled = not _affordable(options[i].get("effects", {}))

func _affordable(effects: Dictionary) -> bool:
	var gold := int(effects.get("gold", 0))
	if gold < 0 and GameState.gold < -gold:
		return false
	if (effects.has("remove_cards") or effects.has("fuse") or effects.has("well")) and GameState.deck.size() <= 6:
		return false
	if effects.has("recolor") and GameState.main_color() == "":
		return false
	if effects.has("heal") and not (effects["heal"] is String) and int(effects["heal"]) < 0 and GameState.player_hp <= -int(effects["heal"]):
		return false
	if effects.has("max_hp") and int(effects["max_hp"]) < 0 and GameState.player_max_hp + int(effects["max_hp"]) < 5:
		return false
	if effects.has("card_keyword") and _keyword_candidates(String(effects["card_keyword"])) == 0:
		return false
	if effects.has("duplicate_random") and GameState.deck.is_empty():
		return false
	if effects.has("edition") and _edition_candidates(String(effects["edition"])) == 0:
		return false
	if effects.has("consumable") and not GameState.can_add_consumable():
		return false
	if effects.has("gamble"):
		var cost := int(effects.get("cost", 0))
		if String(effects["gamble"]) == "gold" and GameState.gold < cost:
			return false
		if String(effects["gamble"]) == "life" and GameState.player_hp <= cost:
			return false
	return true

func _on_option(opt: Dictionary, button: Button) -> void:
	if _chosen:
		return
	_chosen = true
	Sfx.select()
	# Fica só a opção escolhida (dá espaço ao resultado).
	for b in _options_box.get_children():
		(b as Button).disabled = true
		if b != button:
			(b as Button).visible = false
	var lines: Array[String] = []
	_cancelled = false
	await _apply(opt.get("effects", {}), lines)
	if not is_inside_tree():
		return
	if _cancelled:
		# Cancelou a escolha da carta: nada foi cobrado, as opções voltam.
		_chosen = false
		for b in _options_box.get_children():
			(b as Button).visible = true
			(b as Button).disabled = false
		_refresh_affordable()
		return
	_result.text = "\n".join(PackedStringArray(lines)) if not lines.is_empty() else tr("Nada acontece.")
	_result.visible = true
	_continue.visible = true
	GameState.chain_option_chosen(_event, opt)   # 0.17.0: histórias em cadeia
	GameState.pending_event = ""
	GameState.save_run({}, "map")

func _apply(effects: Dictionary, lines: Array[String]) -> void:
	# 1. Escolhas de cartas (antes de qualquer custo: cancelar não custa nada).
	var seal_target: CardInstance = null
	if effects.has("seal"):
		seal_target = await _pick_card(tr("FORJA — escolhe a carta a selar"), Callable())
		if seal_target == null:
			_cancelled = true
			return
	var well_card: CardInstance = null
	if effects.has("well"):
		well_card = await _pick_card(tr("POÇO — escolhe a carta a atirar"), Callable())
		if well_card == null:
			_cancelled = true
			return
	var forge_card: CardInstance = null
	if effects.has("forge_plus"):
		forge_card = await _pick_card(tr("FORJA — escolhe a carta que passa à versão +"), func(c: CardInstance): return not c.data.plus and not c.data.is_land() and not c.data.is_curse() and not c.data.token)
		if forge_card == null:
			_cancelled = true
			return
	var ed_card: CardInstance = null
	if effects.has("edition"):
		var ed := String(effects["edition"])
		ed_card = await _pick_card(tr("FORJA — escolhe a carta que fica %s") % EffectResolver.edition_name(ed).to_upper(), func(c: CardInstance): return _edition_ok(c, ed))
		if ed_card == null:
			_cancelled = true
			return
	var chosen_card: CardData = null
	if effects.has("card_choice"):
		chosen_card = await _choose_offer(String(effects["card_choice"]))
		if chosen_card == null:
			_cancelled = true
			return
	var kw_card: CardInstance = null
	if effects.has("card_keyword"):
		var kw := String(effects["card_keyword"])
		kw_card = await _pick_card(tr("%s — escolhe a criatura") % tr(String(CardData.KEYWORD_NAMES.get(kw, kw))).to_upper(), func(c: CardInstance): return c.data.is_creature() and not c.data.token and not c.has_keyword(kw))
		if kw_card == null:
			_cancelled = true
			return
	var swap_card: CardInstance = null
	if effects.has("swap_cost5"):
		swap_card = await _pick_card(tr("FEIRA — escolhe a carta a trocar"), Callable())
		if swap_card == null:
			_cancelled = true
			return
	var removed: Array[CardInstance] = []
	var to_remove := int(effects.get("remove_cards", 0))
	for i in to_remove:
		if GameState.deck.size() - removed.size() <= 6:
			break
		var exclude := removed.map(func(c): return c.entry_index)
		var card := await _pick_card(tr("REMOVER — escolhe a carta (%d/%d)") % [i + 1, to_remove], func(c: CardInstance): return not (c.entry_index in exclude))
		if card == null:
			break
		removed.append(card)
	if to_remove > 0 and removed.is_empty():
		_cancelled = true
		return

	# 2. Custos e ganhos simples.
	var gold := int(effects.get("gold", 0))
	if gold != 0:
		GameState.add_gold(gold)
		lines.append((tr("+%d ouro") if gold > 0 else tr("%d ouro")) % gold)
	if effects.has("heal"):
		var h = effects["heal"]
		if h is String and h == "full":
			GameState.heal(GameState.player_max_hp)
			lines.append(tr("Vida restaurada por completo."))
		else:
			var n := int(h)
			if n < 0:
				GameState.player_hp = max(1, GameState.player_hp + n)
				EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)
				lines.append(tr("Perdes %d de vida.") % -n)
			else:
				GameState.heal(n)
				lines.append(tr("Curas %d.") % n)
	if effects.has("max_hp"):
		var m := int(effects["max_hp"])
		GameState.change_max_hp(m)
		if m > 0:
			GameState.heal(m)
		lines.append(tr("Vida máxima %s%d (agora %d).") % ["+" if m > 0 else "", m, GameState.player_max_hp])
	if effects.has("relic"):
		_give_relic(String(effects["relic"]), lines)
	if effects.has("card"):
		var kind := String(effects["card"])
		var c := CardDB.random_card_for_deck(GameState.rng, "rare" if kind == "rare" else "")
		if c != null:
			GameState.add_card(c.id)
			lines.append(tr("%s juntou-se ao baralho.") % tr(c.name))
	if effects.has("grow_random") and not GameState.deck.is_empty():
		var e: Dictionary = GameState.deck[GameState.rng.randi_range(0, GameState.deck.size() - 1)]
		e["power_bonus"] = int(e.get("power_bonus", 0)) + int(effects["grow_random"])
		lines.append(tr("%s: +%d Poder permanente.") % [tr(CardDB.get_card(String(e["id"])).name), int(effects["grow_random"])])
	if effects.has("mult_random") and not GameState.deck.is_empty():
		var e: Dictionary = GameState.deck[GameState.rng.randi_range(0, GameState.deck.size() - 1)]
		e["mult_bonus"] = float(e.get("mult_bonus", 0.0)) + float(effects["mult_random"])
		lines.append(tr("%s: +%s Mult permanente.") % [tr(CardDB.get_card(String(e["id"])).name), Cascade.fmt_mult(float(effects["mult_random"]))])
	if int(effects.get("curse", 0)) > 0:
		for i in int(effects["curse"]):
			GameState.add_card(CURSE_ID)
		lines.append(tr("Recebes uma %s.") % tr(CardDB.get_card(CURSE_ID).name))
	# 0.12.0
	if effects.has("mult_random2") and not GameState.deck.is_empty():
		var e2: Dictionary = GameState.deck[GameState.rng.randi_range(0, GameState.deck.size() - 1)]
		e2["mult_bonus"] = float(e2.get("mult_bonus", 0.0)) + float(effects["mult_random2"])
		lines.append(tr("%s: +%s Mult permanente.") % [tr(CardDB.get_card(String(e2["id"])).name), Cascade.fmt_mult(float(effects["mult_random2"]))])
	if int(effects.get("talent", 0)) > 0:
		GameState.progress["talent_points"] = GameState.talent_points() + int(effects["talent"])
		GameState.save_progress()
		lines.append(tr("+%d pontos de talento.") % int(effects["talent"]))
	if int(effects.get("weaken_next", 0)) > 0:
		GameState.next_enemy_weaken += int(effects["weaken_next"])
		lines.append(tr("O inimigo da próxima batalha começa com −%d%% de vida.") % int(effects["weaken_next"]))
	if int(effects.get("duplicate_random", 0)) > 0:
		var pool: Array = []
		for i in GameState.deck.size():
			var cd := CardDB.get_card(String(GameState.deck[i].get("id", "")))
			if cd != null and not cd.is_curse() and not cd.token:
				pool.append(i)
		if not pool.is_empty():
			var src: Dictionary = GameState.deck[pool[GameState.rng.randi_range(0, pool.size() - 1)]]
			GameState.deck.append(src.duplicate(true))
			lines.append(tr("%s ganhou uma cópia.") % tr(CardDB.get_card(String(src["id"])).name))
	if int(effects.get("special_land", 0)) > 0:
		var lands: Array = CardDB.cards_for_colors(GameState.deck_colors()).filter(func(cd: CardData): return cd.special_land)
		if lands.is_empty():
			lands = CardDB.cards.values().filter(func(cd: CardData): return cd.special_land)
		if not lands.is_empty():
			var land: CardData = lands[GameState.rng.randi_range(0, lands.size() - 1)]
			GameState.add_card(land.id)
			lines.append(tr("%s juntou-se ao baralho.") % tr(land.name))
	if effects.has("blessing") and GameState.add_blessing(String(effects["blessing"])):
		lines.append(tr("Recebes a %s.") % tr(String(CardDB.relics[String(effects["blessing"])].get("name", ""))))
	# 0.13.0
	if ed_card != null and GameState.set_edition(ed_card.entry_index, String(effects["edition"])):
		lines.append(tr("%s ficou %s: %s") % [tr(ed_card.data.name), EffectResolver.edition_name(String(effects["edition"])), EffectResolver.edition_text(String(effects["edition"]))])
	if chosen_card != null:
		GameState.add_card(chosen_card.id)
		lines.append(tr("%s juntou-se ao baralho.") % tr(chosen_card.name))
	if effects.has("consumable"):
		lines.append_array(GameState.apply_simple_effects({"consumable": String(effects["consumable"])}))
	if effects.get("later") is Dictionary:
		var lt: Dictionary = effects["later"]
		var n := maxi(1, int(lt.get("in", 2)))
		GameState.add_later(n, lt.get("effects", {}) as Dictionary, String(lt.get("text", "")), String(_event.get("title", "")))
		lines.append((tr("No próximo ante, algo vai acontecer.") if n == 1 else tr("Daqui a %d antes, algo vai acontecer.") % n) + " " + tr("(Vê em Promessas, no mapa.)"))
	if kw_card != null:
		var kw2 := String(effects["card_keyword"])
		var entry: Dictionary = GameState.deck[kw_card.entry_index]
		var kws: Array = (entry.get("keywords_plus", []) as Array).duplicate()
		if not (kw2 in kws):
			kws.append(kw2)
		entry["keywords_plus"] = kws
		lines.append(tr("%s ganhou %s para sempre.") % [tr(kw_card.data.name), tr(String(CardData.KEYWORD_NAMES.get(kw2, kw2)))])

	# 3. Efeitos com cartas escolhidas (aplicados por ordem decrescente de índice).
	if forge_card != null and GameState.forge_plus(forge_card.entry_index):
		var plus_name := CardDB.new_instance(forge_card.data.id, GameState.deck[forge_card.entry_index]).data.display_name()
		lines.append(tr("%s foi forjada: agora é %s (efeitos ×1,5).") % [tr(forge_card.data.name), plus_name])
	if seal_target != null:
		var sd := CardDB.get_seal(String(effects["seal"]))
		GameState.deck[seal_target.entry_index]["seal"] = String(effects["seal"])
		GameState.log_deck("seal", seal_target.data.id, String(effects["seal"]))   # 0.19.0 (56)
		lines.append(tr("%s recebeu o %s.") % [tr(seal_target.data.name), tr(String(sd.get("name", effects["seal"])))])
	var to_delete: Array[int] = []
	if well_card != null:
		to_delete.append(well_card.entry_index)
		var pool := CardDB.cards_for_colors(GameState.deck_colors()).filter(func(cd: CardData): return cd.rarity == "common")
		if pool.is_empty():
			pool = CardDB.cards_for_colors(GameState.deck_colors())
		if not pool.is_empty():
			var pick: CardData = pool[GameState.rng.randi_range(0, pool.size() - 1)]
			for i in 2:
				GameState.add_card(pick.id)
				GameState.deck[GameState.deck.size() - 1]["seal"] = "fury"
			lines.append(tr("%s afunda no poço; sobem 2× %s com o Selo da Fúria.") % [tr(well_card.data.name), tr(pick.name)])
	if swap_card != null:
		to_delete.append(swap_card.entry_index)
		var fives: Array = CardDB.cards.values().filter(func(cd: CardData): return cd.cost == 5 and not cd.is_land() and not cd.is_curse() and CardDB.is_available(cd))
		if not fives.is_empty():
			var pick: CardData = fives[GameState.rng.randi_range(0, fives.size() - 1)]
			GameState.add_card(pick.id)
			lines.append(tr("Trocaste %s por %s.") % [tr(swap_card.data.name), tr(pick.name)])
	for card in removed:
		to_delete.append(card.entry_index)
		lines.append(tr("%s removida do baralho.") % tr(card.data.name))
	to_delete.sort()
	for i in range(to_delete.size() - 1, -1, -1):
		var idx := to_delete[i]
		if idx >= 0 and idx < GameState.deck.size():
			GameState.deck.remove_at(idx)

	# 4. Fonte de Mana: até N cartas passam à cor principal do baralho.
	var to_recolor := int(effects.get("recolor", 0))
	var main := GameState.main_color()
	for i in to_recolor:
		if main == "":
			break
		var card := await _pick_card(tr("FONTE DE MANA — escolhe a carta (%d/%d)") % [i + 1, to_recolor], func(c: CardInstance): return not c.data.is_colorless() and c.data.colors != [main])
		if card == null:
			break
		GameState.deck[card.entry_index]["colors"] = [main]
		lines.append(tr("%s passou a %s.") % [tr(card.data.name), tr(CardZoom.COLOR_NAMES.get(main, main))])
	# 5. Altar Profano: sacrifica uma carta; outra herda os efeitos dela e metade do Poder.
	if int(effects.get("fuse", 0)) > 0 and GameState.deck.size() > 6:
		var victim := await _pick_card(tr("ALTAR — escolhe a carta a sacrificar"), Callable())
		if victim != null:
			var receiver := await _pick_card(tr("ALTAR — quem herda a habilidade de %s?") % tr(victim.data.name), func(c: CardInstance): return c.entry_index != victim.entry_index)
			if receiver != null:
				var target: Dictionary = GameState.deck[receiver.entry_index]
				var extra: Array = (target.get("extra_effects", []) as Array).duplicate(true)
				extra.append_array(victim.data.effects.duplicate(true))
				target["extra_effects"] = extra
				target["extra_text"] = (String(target.get("extra_text", "")) + " " + victim.data.text).strip_edges()
				target["power_bonus"] = int(target.get("power_bonus", 0)) + int(victim.power() / 2)
				lines.append(tr("%s herdou a habilidade de %s (+%d Poder).") % [tr(receiver.data.name), tr(victim.data.name), int(victim.power() / 2)])
				GameState.deck.remove_at(victim.entry_index)
				GameState.log_deck("fuse", receiver.data.id, victim.data.id)   # 0.19.0 (56)

	# 6. Contrato, adivinha a cor, roda do Tribunal.
	if effects.has("contract"):
		GameState.set_contract(String(effects["contract"]))
		lines.append(tr("Contrato aceite: %s. Vale para a próxima batalha.") % tr(String(GameState.contract.get("name", ""))))
	if effects.has("guess") and _hidden_card != null:
		var guess := String(effects["guess"])
		var cols: Array[String] = []
		for col in _hidden_card.colors:
			cols.append(tr(CardZoom.COLOR_NAMES.get(col, col)))
		lines.append(tr("Debaixo do chapéu estava %s (%s).") % [tr(_hidden_card.name), "/".join(PackedStringArray(cols))])
		if guess in _hidden_card.colors:
			lines.append(tr("Acertaste!"))
			_give_relic("random", lines)
		else:
			GameState.add_card(CURSE_ID)
			lines.append(tr("Falhaste. Recebes uma %s.") % tr(CardDB.get_card(CURSE_ID).name))
	if effects.has("gamble"):
		await _gamble(effects, lines)
	# 0.12.0: sorte — {"p": probabilidade de ganhar, "win": {...}, "lose": {...}, "win_text", "lose_text"}.
	if effects.get("chance") is Dictionary:
		var ch: Dictionary = effects["chance"]
		var won := GameState.rng.randf() < float(ch.get("p", 0.5))
		var t := String(ch.get("win_text" if won else "lose_text", ""))
		if t != "":
			lines.append(tr(t))
		var sub: Dictionary = ch.get("win" if won else "lose", {})
		if not sub.is_empty():
			await _apply(sub, lines)

func _give_relic(kind: String, lines: Array[String]) -> void:
	var id := kind
	if id == "random":
		id = GameState.random_new_relic()
	elif id == "legendary":
		id = GameState.random_legendary_relic()
	if id != "" and GameState.add_relic(id):
		lines.append(tr("Recebes a relíquia %s.") % tr(String(CardDB.relics[id].get("name", id))))
	elif id != "":
		var refund := GameState.relic_sell_price(id) * 2
		GameState.add_gold(refund)
		lines.append(tr("Sem espaço para relíquias: recebes %d ouro em vez disso.") % refund)

## Tribunal dos Deuses: paga a oferenda, sorteia o setor e gira a roda; aplica o resultado.
func _gamble(effects: Dictionary, lines: Array[String]) -> void:
	var cost := int(effects.get("cost", 0))
	if String(effects["gamble"]) == "gold":
		GameState.spend_gold(cost, "event")
		lines.append(tr("Ofereces %d ouro.") % cost)
	else:
		GameState.player_hp = max(1, GameState.player_hp - cost)
		EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)
		lines.append(tr("Ofereces %d de vida.") % cost)
	var wheel: Array = _event.get("wheel", [])
	if wheel.is_empty():
		return
	var index := GameState.rng.randi_range(0, wheel.size() - 1)
	Stats.on_tribunal_spin()
	# O resultado aplica-se e grava-se antes de a roda girar: fechar a app a meio não o perde.
	var sub: Array[String] = []
	await _apply(wheel[index].get("effects", {}), sub)
	GameState.pending_event = ""
	GameState.save_run({}, "map")
	var labels: Array[String] = []
	for w in wheel:
		labels.append(tr(String(w.get("label", ""))))
	if not bool(Settings.opt("wheel_fast")):   # 0.19.0 (187): o resultado já está decidido — sem girar, mostra-se logo
		var spinner := SpinWheel.open(labels, index)
		await spinner.finished
	lines.append(tr("A roda parou em: %s.") % labels[index])
	lines.append_array(sub)

## Escolha de uma carta do baralho (fecha com null se o jogador cancelar).
func _pick_card(title: String, filter: Callable) -> CardInstance:
	var picked := [null]
	var viewer := ZoneViewer.open_deck(title, func(card: CardInstance): picked[0] = card, filter)
	var done := [false]
	viewer.tree_exited.connect(func(): done[0] = true)
	while not done[0]:
		await get_tree().process_frame
	return picked[0]

## Avança o ante e volta ao mapa.
func _continue_run() -> void:
	GameState.pending_event = ""
	GameState.next_ante()
	GameState.save_run({}, "map")
	SceneRouter.go("map")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		Sfx.select()

## 0.13.0: uma Criatura ou feitiço (não Ficha) que ainda não tenha esta edição.
static func _edition_ok(c: CardInstance, ed: String) -> bool:
	return (c.data.is_creature() or c.data.is_spell()) and not c.data.token and not c.data.is_curse() and c.edition() != ed

func _edition_candidates(ed: String) -> int:
	var n := 0
	for i in GameState.deck.size():
		var e: Dictionary = GameState.deck[i]
		var cd := CardDB.get_card(String(e.get("id", "")))
		if cd != null and (cd.is_creature() or cd.is_spell()) and not cd.token and String(e.get("edition", "")) != ed:
			n += 1
	return n

## Biblioteca: escolhe 1 de 3 cartas (raras das tuas cores). Devolve null se cancelares.
func _choose_offer(kind: String) -> CardData:
	var cards: Array[CardInstance] = []
	var used: Array[String] = []
	for i in 12:
		if cards.size() >= 3:
			break
		var cd := CardDB.random_card_for_deck(GameState.rng, "rare" if kind == "rare" else "")
		if cd == null or cd.id in used:
			continue
		used.append(cd.id)
		cards.append(CardDB.new_instance(cd.id))
	if cards.is_empty():
		return null
	var picked := [null]
	var viewer := ZoneViewer.open(tr("BIBLIOTECA — escolhe 1 de %d") % cards.size(), cards, false, func(card: CardInstance): picked[0] = card)
	var done := [false]
	viewer.tree_exited.connect(func(): done[0] = true)
	while not done[0]:
		await get_tree().process_frame
	return (picked[0] as CardInstance).data if picked[0] != null else null

## Criaturas do baralho que ainda não têm esta palavra-chave (para o evento a poder dar).
func _keyword_candidates(kw: String) -> int:
	var n := 0
	for e in GameState.deck:
		var cd := CardDB.get_card(String(e.get("id", "")))
		if cd != null and cd.is_creature() and not cd.token and not (kw in cd.keywords) and not (kw in (e.get("keywords_plus", []) as Array)):
			n += 1
	return n
