extends Control
## Evento (nó do mapa): uma situação da campanha com 2–3 escolhas. Os efeitos vêm de data/events.json:
##   gold ±N · heal N|"full" (negativo = perde vida, nunca abaixo de 1) · max_hp ±N ·
##   relic "random" · card "rare"|"random" · remove_cards N · grow_random N · mult_random X ·
##   recolor N (Fonte de Mana: até N cartas passam à cor principal) · fuse 1 (Altar: sacrifica uma
##   carta, outra herda os efeitos e metade do Poder dela)
## Grava-se ao entrar ("event"); ao sair avança o ante e volta ao mapa.

var _event: Dictionary = {}
var _options_box: VBoxContainer
var _result: Label
var _continue: Button
var _chosen := false

func _ready() -> void:
	_event = CardDB.get_event(GameState.pending_event)
	if _event.is_empty():
		_continue_run()
		return
	GameState.save_run({}, "event")
	Stats.on_event_seen()
	_build()

func _build() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 120)
	margin.add_theme_constant_override("margin_top", 24)
	margin.add_theme_constant_override("margin_bottom", 40)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 14)
	margin.add_child(vbox)

	var header := UiKit.label(tr("ANTE %d VENCIDO  ·  ATO %s") % [GameState.ante, GameState.act_name()], 18, UiKit.TEXT_DIM)
	vbox.add_child(header)
	var title := UiKit.label(tr(String(_event.get("title", ""))), 44, UiKit.GOLD)
	vbox.add_child(title)
	var body := UiKit.label(tr(String(_event.get("text", ""))), 22, Color.WHITE, true)
	vbox.add_child(body)
	var status := UiKit.label(tr("Vida %d/%d") % [GameState.player_hp, GameState.player_max_hp] + "   ·   " + tr("Ouro: %d") % GameState.gold + "   ·   " + tr("Relíquias: %d/%d") % [GameState.relic_ids.size(), GameState.MAX_RELICS], 18, UiKit.TEXT_DIM)
	vbox.add_child(status)

	_options_box = VBoxContainer.new()
	_options_box.add_theme_constant_override("separation", 10)
	_options_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(_options_box)
	var i := 0
	for opt in _event.get("options", []):
		var effects: Dictionary = opt.get("effects", {})
		var b := UiKit.button("%s  —  %s" % [tr(String(opt.get("label", ""))), tr(String(opt.get("text", "")))], 64, 21, UiKit.PRIMARY if i == 0 else UiKit.BG_LIGHT, Color(0, 0, 0, 0) if i == 0 else UiKit.BORDER)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.disabled = not _affordable(effects)
		b.pressed.connect(_on_option.bind(opt))
		_options_box.add_child(b)
		i += 1

	_result = UiKit.label("", 22, Color(0.6, 0.95, 0.7), true)
	_result.visible = false
	vbox.add_child(_result)
	_continue = UiKit.button(tr("CONTINUAR  ▶"), 66, 26, UiKit.PRIMARY, Color(0, 0, 0, 0))
	_continue.visible = false
	_continue.pressed.connect(func(): Sfx.select(); _continue_run())
	vbox.add_child(_continue)
	UiKit.pop_in(title)

func _affordable(effects: Dictionary) -> bool:
	var gold := int(effects.get("gold", 0))
	if gold < 0 and GameState.gold < -gold:
		return false
	if (effects.has("remove_cards") or effects.has("fuse")) and GameState.deck.size() <= 6:
		return false
	if effects.has("recolor") and GameState.main_color() == "":
		return false
	return true

func _on_option(opt: Dictionary) -> void:
	if _chosen:
		return
	_chosen = true
	Sfx.select()
	for b in _options_box.get_children():
		(b as Button).disabled = true
	var lines: Array[String] = []
	await _apply(opt.get("effects", {}), lines)
	_result.text = "\n".join(PackedStringArray(lines)) if not lines.is_empty() else tr("Nada acontece.")
	_result.visible = true
	_continue.visible = true
	GameState.pending_event = ""
	GameState.save_run({}, "map")

func _apply(effects: Dictionary, lines: Array[String]) -> void:
	var gold := int(effects.get("gold", 0))
	if gold != 0:
		GameState.add_gold(gold)
		lines.append((tr("+%d ouro") if gold > 0 else tr("%d ouro")) % gold)
	if effects.has("heal"):
		var h = effects["heal"]
		if h is String and h == "full":
			GameState.heal(GameState.player_max_hp)
			lines.append(tr("Vida restaurada por completo."))
		else:
			var n := int(h)
			if n < 0:
				GameState.player_hp = max(1, GameState.player_hp + n)
				EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)
				lines.append(tr("Perdes %d de vida.") % -n)
			else:
				GameState.heal(n)
				lines.append(tr("Curas %d.") % n)
	if effects.has("max_hp"):
		var m := int(effects["max_hp"])
		GameState.change_max_hp(m)
		if m > 0:
			GameState.heal(m)
		lines.append(tr("Vida máxima %s%d (agora %d).") % ["+" if m > 0 else "", m, GameState.player_max_hp])
	if effects.has("relic"):
		var id := String(effects["relic"])
		if id == "random":
			id = GameState.random_new_relic()
		if id != "" and GameState.add_relic(id):
			lines.append(tr("Recebes a relíquia %s.") % tr(String(CardDB.relics[id].get("name", id))))
		elif id != "":
			var refund := GameState.relic_sell_price(id) * 2
			GameState.add_gold(refund)
			lines.append(tr("Sem espaço para relíquias: recebes %d ouro em vez disso.") % refund)
	if effects.has("card"):
		var kind := String(effects["card"])
		var c := CardDB.random_card_for_deck(GameState.rng, "rare" if kind == "rare" else "")
		if c != null:
			GameState.add_card(c.id)
			lines.append(tr("%s juntou-se ao baralho.") % tr(c.name))
	if effects.has("grow_random") and not GameState.deck.is_empty():
		var e: Dictionary = GameState.deck[GameState.rng.randi_range(0, GameState.deck.size() - 1)]
		e["power_bonus"] = int(e.get("power_bonus", 0)) + int(effects["grow_random"])
		lines.append(tr("%s: +%d Poder permanente.") % [tr(CardDB.get_card(String(e["id"])).name), int(effects["grow_random"])])
	if effects.has("mult_random") and not GameState.deck.is_empty():
		var e: Dictionary = GameState.deck[GameState.rng.randi_range(0, GameState.deck.size() - 1)]
		e["mult_bonus"] = float(e.get("mult_bonus", 0.0)) + float(effects["mult_random"])
		lines.append(tr("%s: +%s Mult permanente.") % [tr(CardDB.get_card(String(e["id"])).name), Cascade.fmt_mult(float(effects["mult_random"]))])
	# Fonte de Mana: até N cartas passam à cor principal do baralho.
	var to_recolor := int(effects.get("recolor", 0))
	var main := GameState.main_color()
	for i in to_recolor:
		if main == "":
			break
		var card := await _pick_card(tr("FONTE DE MANA — escolhe a carta (%d/%d)") % [i + 1, to_recolor], func(c: CardInstance): return not c.data.is_colorless() and c.data.colors != [main])
		if card == null:
			break
		GameState.deck[card.entry_index]["colors"] = [main]
		lines.append(tr("%s passou a %s.") % [tr(card.data.name), tr(CardZoom.COLOR_NAMES.get(main, main))])
	# Altar de Phyrexia: sacrifica uma carta; outra herda os efeitos dela e metade do Poder.
	if int(effects.get("fuse", 0)) > 0 and GameState.deck.size() > 6:
		var victim := await _pick_card(tr("ALTAR — escolhe a carta a sacrificar"), Callable())
		if victim != null:
			var receiver := await _pick_card(tr("ALTAR — quem herda a habilidade de %s?") % tr(victim.data.name), func(c: CardInstance): return c.entry_index != victim.entry_index)
			if receiver != null:
				var target: Dictionary = GameState.deck[receiver.entry_index]
				var extra: Array = (target.get("extra_effects", []) as Array).duplicate(true)
				extra.append_array(victim.data.effects.duplicate(true))
				target["extra_effects"] = extra
				target["extra_text"] = (String(target.get("extra_text", "")) + " " + victim.data.text).strip_edges()
				target["power_bonus"] = int(target.get("power_bonus", 0)) + int(victim.power() / 2)
				lines.append(tr("%s herdou a habilidade de %s (+%d Poder).") % [tr(receiver.data.name), tr(victim.data.name), int(victim.power() / 2)])
				GameState.deck.remove_at(victim.entry_index)
	var to_remove := int(effects.get("remove_cards", 0))
	for i in to_remove:
		if GameState.deck.size() <= 6:
			break
		var picked := [null]
		var viewer := ZoneViewer.open_deck(tr("REMOVER — escolhe a carta (%d/%d)") % [i + 1, to_remove], func(card: CardInstance): picked[0] = card)
		var done := [false]
		viewer.tree_exited.connect(func(): done[0] = true)
		while not done[0]:
			await get_tree().process_frame
		if picked[0] == null:
			break
		var card: CardInstance = picked[0]
		if card.entry_index >= 0 and card.entry_index < GameState.deck.size():
			GameState.deck.remove_at(card.entry_index)
			lines.append(tr("%s removida do baralho.") % tr(card.data.name))

## Escolha de uma carta do baralho (fecha com null se o jogador cancelar).
func _pick_card(title: String, filter: Callable) -> CardInstance:
	var picked := [null]
	var viewer := ZoneViewer.open_deck(title, func(card: CardInstance): picked[0] = card, filter)
	var done := [false]
	viewer.tree_exited.connect(func(): done[0] = true)
	while not done[0]:
		await get_tree().process_frame
	return picked[0]

## Avança o ante e volta ao mapa.
func _continue_run() -> void:
	GameState.pending_event = ""
	GameState.next_ante()
	GameState.save_run({}, "map")
	SceneRouter.go("map")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		Sfx.select()
