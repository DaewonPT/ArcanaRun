extends Control
## Construtor de baralhos (Modo Livre): escolhe entre as 300 cartas, 10 a 30 cartas, no máximo
## 2 cópias de cada. Seis espaços guardados em user://custom_decks.json (CardDB.custom_decks).
## Jogar com um baralho personalizado é sempre Modo Livre (não conta para a campanha).

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const SLOTS := 6
const MIN_CARDS := 10
const MAX_CARDS := 30
const MAX_COPIES := 2
const PAGE := 48
const COLORS := [["white", "B"], ["blue", "A"], ["black", "P"], ["red", "V"], ["green", "Vd"], ["colorless", "∅"]]

var _slot := 1
var _cards: Array[String] = []     # ids, com repetições
var _name := ""
var _color_filter := ""
var _type_filter := ""
var _deck_filter := ""
var _page := 0

var _name_edit: LineEdit
var _slot_opt: OptionButton
var _grid: GridContainer
var _page_label: Label
var _deck_list: VBoxContainer
var _deck_title: Label
var _summary: Label
var _msg: Label
var _play_btn: Button
var _curve: ManaCurve         # 0.13.0: curva de mana
var _stake := 1               # 0.13.0: Selo Planar da run com este baralho
var _stake_btn: Button

func _ready() -> void:
	CardView.art_on = false   # 0.12.0: grelha grande — a ilustração vê-se na carta em grande
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	# Cabeçalho: voltar, título, espaço, nome, guardar, jogar.
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 10)
	vbox.add_child(header)
	var back := UiKit.menu_button(48, 18)
	back.custom_minimum_size.x = 120
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("CONSTRUTOR"), 26, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(title)
	_slot_opt = OptionButton.new()
	_slot_opt.custom_minimum_size = Vector2(170, 44)
	_slot_opt.add_theme_font_size_override("font_size", 16)
	for i in range(1, SLOTS + 1):
		var d: Dictionary = CardDB.custom_decks.get("custom_%d" % i, {})
		_slot_opt.add_item(("%d · %s" % [i, d.get("name", "")]) if not d.is_empty() else tr("Espaço %d (vazio)") % i)
	_slot_opt.item_selected.connect(func(idx: int): Sfx.select(); _load_slot(idx + 1))
	header.add_child(_slot_opt)
	_name_edit = LineEdit.new()
	_name_edit.placeholder_text = tr("Nome do baralho")
	_name_edit.custom_minimum_size = Vector2(240, 44)
	_name_edit.max_length = 24
	_name_edit.add_theme_font_size_override("font_size", 16)
	_name_edit.text_changed.connect(func(t: String): _name = t)
	header.add_child(_name_edit)
	var save := UiKit.button(tr("GUARDAR"), 48, 18)
	save.custom_minimum_size.x = 130
	save.pressed.connect(_on_save)
	header.add_child(save)
	# 0.13.0: Selos Planares também nos baralhos do Construtor (cada espaço tem a sua escada).
	_stake_btn = UiKit.button("", 48, 17)
	_stake_btn.name = "Stake"
	_stake_btn.custom_minimum_size.x = 132
	_stake_btn.pressed.connect(_on_stake)
	header.add_child(_stake_btn)
	_play_btn = UiKit.button(tr("JOGAR  ▶"), 48, 20, UiKit.PRIMARY, Color(0, 0, 0, 0))
	_play_btn.custom_minimum_size.x = 150
	_play_btn.pressed.connect(_on_play)
	header.add_child(_play_btn)

	var body := HBoxContainer.new()
	body.add_theme_constant_override("separation", 12)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(body)

	# Esquerda: filtros + grelha paginada.
	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_theme_constant_override("separation", 6)
	body.add_child(left)
	var filters := HBoxContainer.new()
	filters.add_theme_constant_override("separation", 6)
	left.add_child(filters)
	for c in COLORS:
		var b := UiKit.button(String(c[1]), 40, 15, CardView.COLORS[c[0]], Color(0, 0, 0, 0))
		b.custom_minimum_size.x = 46
		b.add_theme_color_override("font_color", CardView.DARK_TEXT if (CardView.COLORS[c[0]] as Color).get_luminance() > 0.45 else CardView.LIGHT_TEXT)
		b.toggle_mode = true
		b.button_pressed = (_color_filter == c[0])
		b.pressed.connect(func():
			_color_filter = "" if _color_filter == c[0] else String(c[0])
			_page = 0
			Sfx.select()
			_rebuild())
		filters.add_child(b)
	for t in [["creature", tr("Criaturas")], ["spell", tr("Feitiços")], ["land", tr("Terrenos")]]:
		var b := UiKit.button(String(t[1]), 40, 15)
		b.toggle_mode = true
		b.button_pressed = (_type_filter == t[0])
		b.pressed.connect(func():
			_type_filter = "" if _type_filter == t[0] else String(t[0])
			_page = 0
			Sfx.select()
			_rebuild())
		filters.add_child(b)
	var deck_opt := OptionButton.new()
	deck_opt.custom_minimum_size = Vector2(190, 40)
	deck_opt.add_theme_font_size_override("font_size", 14)
	deck_opt.add_item(tr("Todos os baralhos"))
	deck_opt.set_item_metadata(0, "")
	var i := 1
	for d in CardDB.decks:
		deck_opt.add_item("%02d · %s" % [int(d.get("num", 0)), tr(String(d.get("name", "")))])
		deck_opt.set_item_metadata(i, String(d.get("id", "")))
		i += 1
	deck_opt.item_selected.connect(func(idx: int):
		_deck_filter = String(deck_opt.get_item_metadata(idx))
		_page = 0
		Sfx.select()
		_rebuild())
	filters.add_child(deck_opt)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	left.add_child(scroll)
	_grid = GridContainer.new()
	_grid.columns = 6
	_grid.add_theme_constant_override("h_separation", 8)
	_grid.add_theme_constant_override("v_separation", 8)
	_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(_grid)
	# Em baixo: a ajuda e as páginas (0.12.0: saíram da fila dos filtros, que não cabia num ecrã 16:9).
	var bottom := HBoxContainer.new()
	bottom.add_theme_constant_override("separation", 6)
	left.add_child(bottom)
	var hint := UiKit.label(tr("Toca numa carta para a juntar ao baralho (máx. 2 cópias); toque longo para ver em grande."), 14, UiKit.TEXT_DIM)
	hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hint.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	hint.clip_text = true
	bottom.add_child(hint)
	var prev := UiKit.button("◀", 40, 16)
	prev.name = "PrevPage"
	prev.custom_minimum_size.x = 48
	prev.pressed.connect(func(): _page = max(0, _page - 1); Sfx.select(); _rebuild())
	bottom.add_child(prev)
	_page_label = UiKit.label("1/1", 15, UiKit.TEXT_DIM)
	_page_label.custom_minimum_size.x = 56
	_page_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_page_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	bottom.add_child(_page_label)
	var next := UiKit.button("▶", 40, 16)
	next.name = "NextPage"
	next.custom_minimum_size.x = 48
	next.pressed.connect(func(): _page += 1; Sfx.select(); _rebuild())
	bottom.add_child(next)

	# Direita: o baralho.
	var right := PanelContainer.new()
	right.custom_minimum_size = Vector2(340, 0)
	right.add_theme_stylebox_override("panel", UiKit.flat(UiKit.BG, 12, UiKit.BORDER, 2, 10))
	body.add_child(right)
	var rv := VBoxContainer.new()
	rv.add_theme_constant_override("separation", 6)
	right.add_child(rv)
	_deck_title = UiKit.label("", 19, UiKit.GOLD)
	rv.add_child(_deck_title)
	_summary = UiKit.label("", 14, UiKit.TEXT_DIM, true)
	rv.add_child(_summary)
	# 0.13.0: curva de mana do baralho que estás a montar.
	_curve = ManaCurve.new()
	_curve.name = "ManaCurve"
	_curve.custom_minimum_size = Vector2(0, 74)
	_curve.font_size = 12
	rv.add_child(_curve)
	var dscroll := ScrollContainer.new()
	dscroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	dscroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	rv.add_child(dscroll)
	_deck_list = VBoxContainer.new()
	_deck_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_deck_list.add_theme_constant_override("separation", 2)
	dscroll.add_child(_deck_list)
	_msg = UiKit.label("", 14, Color(1, 0.75, 0.5), true)
	rv.add_child(_msg)
	# 0.12.0: códigos de baralho (copiar para partilhar; colar o de alguém).
	var code_row := HBoxContainer.new()
	code_row.add_theme_constant_override("separation", 6)
	rv.add_child(code_row)
	var copy_btn := UiKit.button(tr("COPIAR CÓDIGO"), 42, 15)
	copy_btn.name = "CopyCode"
	copy_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	copy_btn.pressed.connect(_on_copy_code)
	code_row.add_child(copy_btn)
	var paste_btn := UiKit.button(tr("COLAR CÓDIGO"), 42, 15)
	paste_btn.name = "PasteCode"
	paste_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	paste_btn.pressed.connect(_on_paste_code)
	code_row.add_child(paste_btn)
	var clear := UiKit.button(tr("LIMPAR"), 42, 16, UiKit.DANGER, Color(0, 0, 0, 0))
	clear.pressed.connect(func():
		_cards.clear()
		Sfx.hit()
		_refresh_deck())
	rv.add_child(clear)

	_fit_columns()
	resized.connect(_fit_columns)
	_load_slot(1)

## 0.12.0: as colunas da grelha dependem da largura do ecrã (5 num 16:9, 7 num telemóvel comprido),
## para o painel do baralho nunca sair do ecrã. Conta a partir da largura deste ecrã, não da grelha.
func _fit_columns() -> void:
	var w := size.x if size.x > 0.0 else get_viewport_rect().size.x
	# 0.13.0: conta com a largura normal das cartas (+ uma folga de 6 px por coluna para uma ou outra carta
	# mais larga) — contar com a mais larga de todas deixava uma coluna vazia à direita.
	var card_w := (CardView.SIZE_COMPACT.x if Settings.compact else CardView.SIZE_NORMAL.x) + 8.0 + 6.0
	var available := w - 48.0 - 340.0 - 12.0 - 18.0
	_grid.columns = clampi(int((available + 8.0) / card_w), 3, 9)

# --- Espaços guardados ---

func _load_slot(slot: int) -> void:
	_slot = slot
	var d: Dictionary = CardDB.custom_decks.get("custom_%d" % slot, {})
	_cards.clear()
	for id in d.get("cards", []):
		_cards.append(String(id))
	_name = String(d.get("name", ""))
	_name_edit.text = _name
	_slot_opt.select(slot - 1)
	_msg.text = ""
	_refresh_stake()
	_rebuild()
	_refresh_deck()

func _deck_dict() -> Dictionary:
	var colors := {}
	for id in _cards:
		var c := CardDB.get_card(id)
		if c:
			for col in c.colors:
				colors[col] = true
	var name := _name.strip_edges()
	if name == "":
		name = tr("Baralho %d") % _slot
	return {
		"id": "custom_%d" % _slot, "num": 0, "name": name, "custom": true,
		"cards": _cards.duplicate(), "colors": colors.keys(), "size": _cards.size(),
		"difficulty": 0, "mechanic": tr("Baralho personalizado"), "color_code": "",
	}

func _on_save() -> void:
	if _cards.size() < MIN_CARDS:
		_msg.text = tr("Precisas de pelo menos %d cartas.") % MIN_CARDS
		Sfx.deny()
		return
	var d := _deck_dict()
	CardDB.custom_decks[d["id"]] = d
	CardDB.save_custom_decks()
	_slot_opt.set_item_text(_slot - 1, "%d · %s" % [_slot, d["name"]])
	_msg.text = tr("Guardado.")
	Sfx.boom()

func _on_play() -> void:
	if _cards.size() < MIN_CARDS:
		_msg.text = tr("Precisas de pelo menos %d cartas.") % MIN_CARDS
		Sfx.deny()
		return
	_on_save()
	Sfx.select()
	# 0.12.0: escolher o espaço de gravação (um ocupado pede confirmação).
	SlotPicker.open(tr("Modo Livre"), func(_s: int): _start_play())

## Toca para rodar o Selo Planar (1 até ao seguinte ao mais alto vencido com este espaço).
func _on_stake() -> void:
	Sfx.select()
	var max_n := GameState.max_stake("custom_%d" % _slot)
	_stake = 1 if _stake >= max_n else _stake + 1
	_refresh_stake(true)

func _refresh_stake(explain: bool = false) -> void:
	if _stake_btn == null:
		return
	var max_n := GameState.max_stake("custom_%d" % _slot)
	_stake = clampi(_stake, 1, max_n)
	_stake_btn.text = tr("SELO %d") % _stake + ("  ▸" if max_n > 1 else "")
	_stake_btn.tooltip_text = tr("Selo Planar %d — %s: %s") % [_stake, tr(GameState.stake_name(_stake)), tr(String(GameState.STAKES[_stake - 1].get("text", "")))]
	if explain:
		var txt := _stake_btn.tooltip_text
		if _stake > 1:
			txt += "  " + tr("(acumula os selos anteriores)")
		if max_n < GameState.STAKES.size():
			txt += "  " + tr("Vence o Selo %d com este baralho para abrir o seguinte.") % max_n
		_msg.text = txt

func _start_play() -> void:
	GameState.free_mode = true
	GameState.claim_slot_for_new_run()
	GameState.new_run("custom_%d" % _slot, 0, _stake)
	GameState.apply_talents()
	SceneRouter.go("battle")

# --- Códigos de baralho (0.12.0) ---

func deck_code() -> String:
	return DeckCode.encode(_name if _name.strip_edges() != "" else tr("Baralho %d") % _slot, _cards)

func _on_copy_code() -> void:
	if _cards.is_empty():
		_msg.text = tr("O baralho está vazio.")
		Sfx.deny()
		return
	DisplayServer.clipboard_set(deck_code())
	_msg.text = tr("Código copiado — cola-o numa mensagem para partilhar o baralho.")
	Sfx.select()

func _on_paste_code() -> void:
	Sfx.select()
	var clip := DisplayServer.clipboard_get().strip_edges()
	TextPrompt.open(tr("COLAR CÓDIGO DE BARALHO"), clip if clip.contains(DeckCode.PREFIX) else "", "ZS1-…", 2000, apply_code)

## Carrega um código no espaço atual (não grava: é preciso tocar em GUARDAR). Devolve se correu bem.
func apply_code(code: String) -> bool:
	var res := DeckCode.decode(code)
	if not bool(res.get("ok", false)):
		_msg.text = tr(String(res.get("error", "")))
		Sfx.deny()
		return false
	_cards.clear()
	for id in res["cards"]:
		_cards.append(String(id))
	_name = String(res.get("name", ""))
	_name_edit.text = _name
	var skipped := int(res.get("skipped", 0))
	_msg.text = tr("Baralho carregado — toca em GUARDAR para o manter.") + ((" " + tr("%d cartas ficaram de fora (bloqueadas ou inválidas).") % skipped) if skipped > 0 else "")
	Sfx.boom()
	_rebuild()
	_refresh_deck()
	return true

# --- Grelha ---

func _filtered_pool() -> Array:
	var list: Array = CardDB.collectible_cards()
	list.sort_custom(func(a: CardData, b: CardData): return a.num < b.num)
	var out: Array = []
	for d in list:
		if d.is_curse() or not CardDB.is_available(d):
			continue   # maldições só entram por eventos; Míticas só depois de desbloqueadas
		if _deck_filter != "" and not _belongs_to_deck(d.id, _deck_filter):
			continue
		if _color_filter == "colorless" and not d.is_colorless():
			continue
		if _color_filter != "" and _color_filter != "colorless" and not (_color_filter in d.colors):
			continue
		if _type_filter != "" and d.type != _type_filter:
			continue
		out.append(d)
	return out

func _belongs_to_deck(card_id: String, deck_id: String) -> bool:
	for id in CardDB.get_deck(deck_id).get("cards", []):
		if String(id) == card_id:
			return true
	return false

func _rebuild() -> void:
	UiKit.clear_children(_grid)
	var pool := _filtered_pool()
	var pages: int = max(1, int(ceil(float(pool.size()) / PAGE)))
	_page = clampi(_page, 0, pages - 1)
	_page_label.text = "%d/%d" % [_page + 1, pages]
	for i in range(_page * PAGE, min(pool.size(), (_page + 1) * PAGE)):
		var d: CardData = pool[i]
		var view: CardView = CARD_VIEW.instantiate()
		_grid.add_child(view)
		view.setup(CardDB.new_instance(d.id))
		view.pressed.connect(func(c: CardInstance): _add_card(c.data.id))
		view.long_pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
		_refresh_view_copies(view)
	_fit_columns()

func _refresh_view_copies(view: CardView) -> void:
	var n := _cards.count(view.card.data.id)
	view.delta = 0
	view.modulate = Color.WHITE if n < MAX_COPIES else Color(0.55, 0.55, 0.6)
	view.delta_label.text = ("×%d" % n) if n > 0 else ""
	view.delta_label.add_theme_color_override("font_color", UiKit.GOLD)

func _add_card(id: String) -> void:
	if _cards.size() >= MAX_CARDS:
		_msg.text = tr("Máximo de %d cartas.") % MAX_CARDS
		Sfx.deny()
		return
	if _cards.count(id) >= MAX_COPIES:
		_msg.text = tr("Máximo de %d cópias de cada carta.") % MAX_COPIES
		Sfx.deny()
		return
	_cards.append(id)
	_msg.text = ""
	Sfx.select()
	Settings.vibrate(15)
	for v in _grid.get_children():
		if v is CardView and v.card.data.id == id:
			_refresh_view_copies(v)
	_refresh_deck()

func _remove_card(id: String) -> void:
	var i := _cards.find(id)
	if i >= 0:
		_cards.remove_at(i)
	Sfx.hit()
	for v in _grid.get_children():
		if v is CardView and v.card.data.id == id:
			_refresh_view_copies(v)
	_refresh_deck()

# --- Lista do baralho ---

func _refresh_deck() -> void:
	for c in _deck_list.get_children():
		c.queue_free()
	_deck_title.text = tr("O teu baralho (%d/%d)") % [_cards.size(), MAX_CARDS]
	var counts := {}
	var creatures := 0
	var spells := 0
	var lands := 0
	var colors := {}
	for id in _cards:
		counts[id] = int(counts.get(id, 0)) + 1
		var c := CardDB.get_card(id)
		if c == null:
			continue
		if c.is_creature():
			creatures += 1
		elif c.is_spell():
			spells += 1
		else:
			lands += 1
		for col in c.colors:
			colors[col] = true
	var color_names: Array[String] = []
	for col in ["white", "blue", "black", "red", "green"]:
		if colors.has(col):
			color_names.append(tr(CardZoom.COLOR_NAMES.get(col, col)))
	_summary.text = tr("%d criaturas · %d feitiços · %d terrenos · cores: %s") % [creatures, spells, lands, "/".join(PackedStringArray(color_names)) if not color_names.is_empty() else tr("Incolor")]
	if _curve != null:
		var datas: Array = []
		for id in _cards:
			var cd := CardDB.get_card(id)
			if cd != null:
				datas.append(cd)
		_curve.set_cards(datas)
		if not datas.is_empty():
			_summary.text += "  ·  " + tr("custo médio %s") % ManaCurve.decimal(_curve.average_cost())
	var ids: Array = counts.keys()
	ids.sort_custom(func(a, b):
		var ca := CardDB.get_card(a)
		var cb := CardDB.get_card(b)
		if ca.is_land() != cb.is_land():
			return cb.is_land()
		if ca.cost != cb.cost:
			return ca.cost < cb.cost
		return ca.num < cb.num)
	for id in ids:
		var c := CardDB.get_card(id)
		var b := Button.new()
		b.text = "×%d  %s  (%d)" % [counts[id], tr(c.name), c.cost]
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.custom_minimum_size.y = 34
		b.add_theme_font_size_override("font_size", 14)
		b.clip_text = true
		b.add_theme_color_override("font_color", CardView.COLORS.get(c.primary_color(), Color.WHITE).lightened(0.3))
		b.pressed.connect(_remove_card.bind(id))
		_deck_list.add_child(b)
	_play_btn.disabled = _cards.size() < MIN_CARDS

func _exit_tree() -> void:
	CardView.art_on = true

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
