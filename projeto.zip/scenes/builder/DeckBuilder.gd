extends Control
## Construtor de baralhos (Modo Livre): escolhe entre as 300 cartas, 10 a 30 cartas, no máximo
## 2 cópias de cada. Seis espaços guardados em user://custom_decks.json (CardDB.custom_decks).
## Jogar com um baralho personalizado é sempre Modo Livre (não conta para a campanha).
## 0.16.1 (V52): a grelha já com as ilustrações; filtros de cor com o símbolo da mana e de tipo em
## etiquetas; o baralho em tiras (custo numa esfera, nome, a ilustração a desvanecer e ×2). Fundo do
## menu, sossegado (V57).
## 0.19.0 (secção 2 das 300): 12 espaços (37), pesquisa por nome (33), ordenar (34), só favoritas (44), notas (38),
## números e avisos do baralho (39, 40), mão de exemplo (35), completar (41), duplicar (36), copiar um baralho da
## campanha (42), lista em texto (43), mudar a ordem dos espaços (32) e voltar ao mesmo sítio (22).

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const SLOTS := 12
const MIN_CARDS := 10
const MAX_CARDS := 30
const MAX_COPIES := 2
const PAGE := 48
const COLORS := [["white", "B"], ["blue", "A"], ["black", "P"], ["red", "V"], ["green", "Vd"], ["colorless", "∅"]]

var _slot := 1
var _cards: Array[String] = []     # ids, com repetições
var _name := ""
var _color_filter := ""
var _type_filter := ""
var _deck_filter := ""
var _page := 0

var _name_edit: LineEdit
var _slot_opt: OptionButton
var _grid: GridContainer
var _page_label: Label
var _deck_list: VBoxContainer
var _deck_title: Label
var _summary: Label
var _msg: Label
var _play_btn: Button
var _curve: ManaCurve         # 0.13.0: curva de mana
var _color_buttons: Dictionary = {}
var _type_buttons: Dictionary = {}
var _stake := 1               # 0.13.0: Selo Planar da run com este baralho
var _stake_btn: Button
var _back_picker: BackPicker
# 0.19.0
var _search := ""                 # 33
var _sort := "num"                # 34
var _fav_only := false            # 44
var _note := ""                   # 38
var _note_edit: LineEdit
var _warn_label: Label            # 40
var _sort_btn: Button
var _fav_btn: Button
var _scroll: ScrollContainer
const TARGET_SIZE := 20           # 41: COMPLETAR enche até 20 cartas
## 22: o Construtor reabre no mesmo espaço, com os mesmos filtros e na mesma página (enquanto o jogo está aberto).
static var _mem: Dictionary = {}

static func reset_memory() -> void:
	_mem = {}

func _ready() -> void:
	var backdrop := MenuBackdrop.new()
	backdrop.name = "MenuBackdrop"
	backdrop.quiet = true
	add_child(backdrop)
	move_child(backdrop, mini(1, get_child_count() - 1))
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 10)
	margin.add_theme_constant_override("margin_bottom", 22)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	# Cabeçalho: voltar, título, espaço, nome, guardar, jogar.
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 10)
	vbox.add_child(header)
	var back := UiKit.menu_button(52, 20)
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("CONSTRUTOR"), 30, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(title)
	_slot_opt = OptionButton.new()
	_slot_opt.name = "SlotOpt"
	_slot_opt.custom_minimum_size = Vector2(170, 44)
	_slot_opt.add_theme_font_size_override("font_size", 16)
	_fill_slot_opt()
	_slot_opt.item_selected.connect(func(idx: int): Sfx.select(); _load_slot(idx + 1))
	header.add_child(_slot_opt)
	_name_edit = LineEdit.new()
	_name_edit.placeholder_text = tr("Nome do baralho")
	_name_edit.custom_minimum_size = Vector2(240, 44)
	_name_edit.max_length = 24
	_name_edit.add_theme_font_size_override("font_size", 16)
	_name_edit.text_changed.connect(func(t: String): _name = t)
	header.add_child(_name_edit)
	var save := UiKit.button(tr("GUARDAR"), 48, 18)
	save.custom_minimum_size.x = 130
	save.pressed.connect(_on_save)
	header.add_child(save)
	var more := UiKit.button("⋯", 48, 22)
	more.name = "More"
	more.tooltip_text = tr("Mais: duplicar, copiar da campanha, lista em texto, mudar de lugar, limpar")
	more.custom_minimum_size.x = 58
	more.pressed.connect(_open_more)
	header.add_child(more)
	# 0.13.0: Selos Planares também nos baralhos do Construtor (cada espaço tem a sua escada).
	_stake_btn = UiKit.button("", 48, 17)
	_stake_btn.name = "Stake"
	_stake_btn.custom_minimum_size.x = 132
	_stake_btn.pressed.connect(_on_stake)
	header.add_child(_stake_btn)
	_play_btn = UiKit.button(tr("JOGAR  ▶"), 48, 20, UiKit.PRIMARY, Color(0, 0, 0, 0))
	_play_btn.custom_minimum_size.x = 150
	_play_btn.pressed.connect(_on_play)
	UiKit.gold_plate(_play_btn, true)
	header.add_child(_play_btn)

	var body := HBoxContainer.new()
	body.add_theme_constant_override("separation", 12)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(body)

	# Esquerda: filtros + grelha paginada.
	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_theme_constant_override("separation", 6)
	body.add_child(left)
	var filters := HBoxContainer.new()
	filters.add_theme_constant_override("separation", 6)
	left.add_child(filters)
	for c in COLORS:
		var b := UiKit.mana_button(String(c[0]), 40, 48)
		b.button_pressed = (_color_filter == c[0])
		b.pressed.connect(func():
			_color_filter = "" if _color_filter == c[0] else String(c[0])
			_page = 0
			Sfx.select()
			for k in _color_buttons:
				(_color_buttons[k] as Button).button_pressed = _color_filter == k
			_rebuild())
		filters.add_child(b)
		_color_buttons[c[0]] = b
	for t in [["creature", tr("Criaturas")], ["spell", tr("Feitiços")], ["land", tr("Terrenos")]]:
		var b := UiKit.chip_button(String(t[1]), 40)
		b.name = "Type_" + String(t[0])
		b.button_pressed = (_type_filter == t[0])
		b.pressed.connect(func():
			_type_filter = "" if _type_filter == t[0] else String(t[0])
			_page = 0
			Sfx.select()
			for k in _type_buttons:
				(_type_buttons[k] as Button).set_pressed_no_signal(_type_filter == k)
			_rebuild())
		filters.add_child(b)
		_type_buttons[t[0]] = b
	var deck_opt := OptionButton.new()
	deck_opt.custom_minimum_size = Vector2(190, 40)
	deck_opt.add_theme_font_size_override("font_size", 14)
	deck_opt.add_item(tr("Todos os baralhos"))
	deck_opt.set_item_metadata(0, "")
	var i := 1
	for d in CardDB.decks:
		deck_opt.add_item("%02d · %s" % [int(d.get("num", 0)), tr(String(d.get("name", "")))])
		deck_opt.set_item_metadata(i, String(d.get("id", "")))
		i += 1
	deck_opt.item_selected.connect(func(idx: int):
		_deck_filter = String(deck_opt.get_item_metadata(idx))
		_page = 0
		Sfx.select()
		_rebuild())
	filters.add_child(deck_opt)
	deck_opt.name = "DeckFilter"
	# 0.19.0: procurar pelo nome (33), ordenar (34) e só as favoritas (44).
	var row2 := HBoxContainer.new()
	row2.add_theme_constant_override("separation", 6)
	left.add_child(row2)
	var search := LineEdit.new()
	search.name = "Search"
	search.placeholder_text = tr("Procurar nome ou texto…")
	search.custom_minimum_size = Vector2(260, 40)
	search.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	search.add_theme_font_size_override("font_size", 15)
	search.clear_button_enabled = true
	var debounce := Timer.new()
	debounce.one_shot = true
	debounce.wait_time = 0.3
	row2.add_child(debounce)
	debounce.timeout.connect(func(): _page = 0; _rebuild())
	search.text_changed.connect(func(t: String):
		_search = t
		debounce.start())
	row2.add_child(search)
	_sort_btn = UiKit.button(CardSort.label(_sort), 40, 14)
	_sort_btn.name = "Sort"
	_sort_btn.custom_minimum_size.x = 190
	_sort_btn.pressed.connect(func():
		Sfx.select()
		_sort = CardSort.next_key(_sort)
		_sort_btn.text = CardSort.label(_sort)
		_page = 0
		_rebuild())
	row2.add_child(_sort_btn)
	_fav_btn = UiKit.chip_button(tr("★ Só favoritas"), 40)
	_fav_btn.name = "FavOnly"
	_fav_btn.pressed.connect(func():
		Sfx.select()
		_fav_only = not _fav_only
		_fav_btn.set_pressed_no_signal(_fav_only)
		_page = 0
		_rebuild())
	row2.add_child(_fav_btn)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	left.add_child(scroll)
	_scroll = scroll
	_grid = GridContainer.new()
	_grid.columns = 6
	_grid.add_theme_constant_override("h_separation", 8)
	_grid.add_theme_constant_override("v_separation", 8)
	_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(_grid)
	# Em baixo: a ajuda e as páginas (0.12.0: saíram da fila dos filtros, que não cabia num ecrã 16:9).
	var bottom := HBoxContainer.new()
	bottom.add_theme_constant_override("separation", 6)
	left.add_child(bottom)
	var hint := UiKit.label(tr("Toca numa carta para a juntar ao baralho (máx. 2 cópias); toque longo para ver em grande (e marcar como favorita)."), 14, UiKit.TEXT_DIM)
	hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hint.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	hint.clip_text = true
	bottom.add_child(hint)
	var prev := UiKit.button("◀", 40, 16)
	prev.name = "PrevPage"
	prev.custom_minimum_size.x = 48
	prev.pressed.connect(func(): _page = max(0, _page - 1); Sfx.select(); _rebuild())
	bottom.add_child(prev)
	_page_label = UiKit.label("1/1", 15, UiKit.TEXT_DIM)
	_page_label.custom_minimum_size.x = 56
	_page_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_page_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	bottom.add_child(_page_label)
	var next := UiKit.button("▶", 40, 16)
	next.name = "NextPage"
	next.custom_minimum_size.x = 48
	next.pressed.connect(func(): _page += 1; Sfx.select(); _rebuild())
	bottom.add_child(next)

	# Direita: o baralho.
	var right := PanelContainer.new()
	right.custom_minimum_size = Vector2(340, 0)
	right.add_theme_stylebox_override("panel", UiKit.flat(Color(0.075, 0.06, 0.12, 0.92), 16, Color(0.42, 0.36, 0.6, 0.85), 2, 14))
	body.add_child(right)
	var rv := VBoxContainer.new()
	rv.add_theme_constant_override("separation", 6)
	right.add_child(rv)
	_deck_title = UiKit.label("", 20, Color(1.0, 0.86, 0.55))
	rv.add_child(_deck_title)
	# 38: uma linha para a ideia do baralho.
	_note_edit = LineEdit.new()
	_note_edit.name = "Note"
	_note_edit.placeholder_text = tr("Nota: a ideia do baralho («feitiços + Destreza»)")
	_note_edit.max_length = 60
	_note_edit.custom_minimum_size = Vector2(0, 36)
	_note_edit.add_theme_font_size_override("font_size", 14)
	_note_edit.text_changed.connect(func(t: String): _note = t)
	rv.add_child(_note_edit)
	_summary = UiKit.label("", 14, UiKit.TEXT_DIM, true)
	_summary.name = "Summary"
	rv.add_child(_summary)
	_warn_label = UiKit.label("", 14, Color(1.0, 0.66, 0.4), true)
	_warn_label.name = "Warnings"
	rv.add_child(_warn_label)
	# 0.13.0: curva de mana do baralho que estás a montar.
	_curve = ManaCurve.new()
	_curve.name = "ManaCurve"
	_curve.custom_minimum_size = Vector2(0, 74)
	_curve.font_size = 12
	rv.add_child(_curve)
	var dscroll := ScrollContainer.new()
	dscroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	dscroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	rv.add_child(dscroll)
	_deck_list = VBoxContainer.new()
	_deck_list.name = "DeckList"
	_deck_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_deck_list.add_theme_constant_override("separation", 6)
	dscroll.add_child(_deck_list)
	_msg = UiKit.label("", 14, Color(1, 0.75, 0.5), true)
	rv.add_child(_msg)
	# 0.16.1 (V12): as costas deste espaço.
	_back_picker = BackPicker.make("custom_1", 40)
	rv.add_child(_back_picker)
	# 0.12.0: códigos de baralho (copiar para partilhar; colar o de alguém).
	var code_row := HBoxContainer.new()
	code_row.add_theme_constant_override("separation", 6)
	rv.add_child(code_row)
	var copy_btn := UiKit.button(tr("COPIAR CÓDIGO"), 42, 15)
	copy_btn.name = "CopyCode"
	copy_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	copy_btn.pressed.connect(_on_copy_code)
	code_row.add_child(copy_btn)
	var paste_btn := UiKit.button(tr("COLAR CÓDIGO"), 42, 15)
	paste_btn.name = "PasteCode"
	paste_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	paste_btn.pressed.connect(_on_paste_code)
	code_row.add_child(paste_btn)
	# 35, 41: mão de exemplo e completar.
	var act_row := HBoxContainer.new()
	act_row.add_theme_constant_override("separation", 6)
	rv.add_child(act_row)
	var sample := UiKit.button(tr("MÃO DE EXEMPLO"), 42, 15)
	sample.name = "SampleHand"
	sample.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sample.pressed.connect(_open_sample_hand)
	act_row.add_child(sample)
	var fill := UiKit.button(tr("COMPLETAR"), 42, 15)
	fill.name = "Complete"
	fill.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	fill.tooltip_text = tr("Enche o baralho até %d cartas com cartas das cores dele.") % TARGET_SIZE
	fill.pressed.connect(func(): complete_deck())
	act_row.add_child(fill)

	_fit_columns()
	resized.connect(_fit_columns)
	_recall()

## 0.12.0: as colunas da grelha dependem da largura do ecrã (5 num 16:9, 7 num telemóvel comprido),
## para o painel do baralho nunca sair do ecrã. Conta a partir da largura deste ecrã, não da grelha.
func _fit_columns() -> void:
	var w := size.x if size.x > 0.0 else get_viewport_rect().size.x
	# 0.13.0: conta com a largura normal das cartas (+ uma folga de 6 px por coluna para uma ou outra carta
	# mais larga) — contar com a mais larga de todas deixava uma coluna vazia à direita.
	var card_w := (CardView.SIZE_COMPACT.x if Settings.compact else CardView.SIZE_NORMAL.x) + 8.0 + 6.0
	var available := w - 48.0 - 340.0 - 12.0 - 18.0
	_grid.columns = clampi(int((available + 8.0) / card_w), 3, 9)

# --- Espaços guardados ---

func _load_slot(slot: int) -> void:
	_slot = slot
	var d: Dictionary = CardDB.custom_decks.get("custom_%d" % slot, {})
	_cards.clear()
	for id in d.get("cards", []):
		_cards.append(String(id))
	_name = String(d.get("name", ""))
	_name_edit.text = _name
	_note = String(d.get("note", ""))
	if _note_edit != null:
		_note_edit.text = _note
	_slot_opt.select(slot - 1)
	if _back_picker != null:
		_back_picker.deck_id = "custom_%d" % slot
	_msg.text = ""
	_refresh_stake()
	_rebuild()
	_refresh_deck()

func _deck_dict() -> Dictionary:
	var colors := {}
	for id in _cards:
		var c := CardDB.get_card(id)
		if c:
			for col in c.colors:
				colors[col] = true
	var name := _name.strip_edges()
	if name == "":
		name = tr("Baralho %d") % _slot
	return {
		"id": "custom_%d" % _slot, "num": 0, "name": name, "custom": true,
		"cards": _cards.duplicate(), "colors": colors.keys(), "size": _cards.size(),
		"difficulty": 0, "mechanic": tr("Baralho personalizado"), "color_code": "", "note": _note.strip_edges(),
	}

func _on_save() -> void:
	if _cards.size() < MIN_CARDS:
		_msg.text = tr("Precisas de pelo menos %d cartas.") % MIN_CARDS
		Sfx.deny()
		return
	var d := _deck_dict()
	CardDB.custom_decks[d["id"]] = d
	CardDB.save_custom_decks()
	_slot_opt.set_item_text(_slot - 1, _slot_text(_slot))
	_msg.text = tr("Guardado.")
	Sfx.boom()

func _on_play() -> void:
	if _cards.size() < MIN_CARDS:
		_msg.text = tr("Precisas de pelo menos %d cartas.") % MIN_CARDS
		Sfx.deny()
		return
	_on_save()
	Sfx.select()
	# 0.12.0: escolher o espaço de gravação (um ocupado pede confirmação).
	SlotPicker.open(tr("Modo Livre"), func(_s: int): _start_play())

## Toca para rodar o Selo Planar (1 até ao seguinte ao mais alto vencido com este espaço).
func _on_stake() -> void:
	Sfx.select()
	var max_n := GameState.max_stake("custom_%d" % _slot)
	_stake = 1 if _stake >= max_n else _stake + 1
	_refresh_stake(true)

func _refresh_stake(explain: bool = false) -> void:
	if _stake_btn == null:
		return
	var max_n := GameState.max_stake("custom_%d" % _slot)
	_stake = clampi(_stake, 1, max_n)
	_stake_btn.text = tr("SELO %d") % _stake + ("  ▸" if max_n > 1 else "")
	_stake_btn.tooltip_text = tr("Selo Planar %d — %s: %s") % [_stake, tr(GameState.stake_name(_stake)), tr(String(GameState.STAKES[_stake - 1].get("text", "")))]
	if explain:
		var txt := _stake_btn.tooltip_text
		if _stake > 1:
			txt += "  " + tr("(acumula os selos anteriores)")
		if max_n < GameState.STAKES.size():
			txt += "  " + tr("Vence o Selo %d com este baralho para abrir o seguinte.") % max_n
		_msg.text = txt

func _start_play() -> void:
	GameState.free_mode = true
	GameState.claim_slot_for_new_run()
	GameState.new_run("custom_%d" % _slot, 0, _stake)
	GameState.apply_talents()
	SceneRouter.go("battle")

# --- Códigos de baralho (0.12.0) ---

func deck_code() -> String:
	return DeckCode.encode(_name if _name.strip_edges() != "" else tr("Baralho %d") % _slot, _cards)

func _on_copy_code() -> void:
	if _cards.is_empty():
		_msg.text = tr("O baralho está vazio.")
		Sfx.deny()
		return
	DisplayServer.clipboard_set(deck_code())
	_msg.text = tr("Código copiado — cola-o numa mensagem para partilhar o baralho.")
	Sfx.select()

func _on_paste_code() -> void:
	Sfx.select()
	var clip := DisplayServer.clipboard_get().strip_edges()
	TextPrompt.open(tr("COLAR CÓDIGO DE BARALHO"), clip if clip.contains(DeckCode.PREFIX) else "", "ZS1-…", 2000, apply_code)

## Carrega um código no espaço atual (não grava: é preciso tocar em GUARDAR). Devolve se correu bem.
func apply_code(code: String) -> bool:
	var res := DeckCode.decode(code)
	if not bool(res.get("ok", false)):
		_msg.text = tr(String(res.get("error", "")))
		Sfx.deny()
		return false
	_cards.clear()
	for id in res["cards"]:
		_cards.append(String(id))
	_name = String(res.get("name", ""))
	_name_edit.text = _name
	var skipped := int(res.get("skipped", 0))
	_msg.text = tr("Baralho carregado — toca em GUARDAR para o manter.") + ((" " + tr("%d cartas ficaram de fora (bloqueadas ou inválidas).") % skipped) if skipped > 0 else "")
	Sfx.boom()
	_rebuild()
	_refresh_deck()
	return true

# --- Grelha ---

func _filtered_pool() -> Array:
	var list: Array = CardDB.collectible_cards()
	var needle := _search.strip_edges().to_lower()
	var out: Array = []
	for d in list:
		if d.is_curse() or not CardDB.is_available(d):
			continue   # maldições só entram por eventos; Míticas só depois de desbloqueadas
		if _deck_filter != "" and not _belongs_to_deck(d.id, _deck_filter):
			continue
		if _color_filter == "colorless" and not d.is_colorless():
			continue
		if _color_filter != "" and _color_filter != "colorless" and not (_color_filter in d.colors):
			continue
		if _type_filter != "" and d.type != _type_filter:
			continue
		if _fav_only and not GameState.is_favorite(d.id):
			continue
		if needle != "" and not (d.display_name().to_lower().contains(needle) or tr(d.text).to_lower().contains(needle) or d.name.to_lower().contains(needle)):
			continue
		out.append(d)
	CardSort.sort(out, _sort)
	return out

func _belongs_to_deck(card_id: String, deck_id: String) -> bool:
	for id in CardDB.get_deck(deck_id).get("cards", []):
		if String(id) == card_id:
			return true
	return false

func _rebuild() -> void:
	UiKit.clear_children(_grid)
	var pool := _filtered_pool()
	var pages: int = max(1, int(ceil(float(pool.size()) / PAGE)))
	_page = clampi(_page, 0, pages - 1)
	_page_label.text = "%d/%d" % [_page + 1, pages]
	var page_list: Array = []
	for i in range(_page * PAGE, min(pool.size(), (_page + 1) * PAGE)):
		page_list.append(pool[i])
	for d in page_list:
		var view: CardView = CARD_VIEW.instantiate()
		_grid.add_child(view)
		view.setup(CardDB.new_instance((d as CardData).id))
		view.pressed.connect(func(c: CardInstance): _add_card(c.data.id))
		view.long_pressed.connect(func(c: CardInstance): CardZoom.show_card_in(c.data, page_list))   # 0.19.0 (10)
		view.set_favorite_mark(GameState.is_favorite((d as CardData).id))   # 0.19.0 (44)
		_refresh_view_copies(view)
	_fit_columns()

func _refresh_view_copies(view: CardView) -> void:
	var n := _cards.count(view.card.data.id)
	view.delta = 0
	view.modulate = Color.WHITE if n < MAX_COPIES else Color(0.55, 0.55, 0.6)
	view.delta_label.text = ("×%d" % n) if n > 0 else ""
	view.delta_label.add_theme_color_override("font_color", UiKit.GOLD)

func _add_card(id: String) -> void:
	if _cards.size() >= MAX_CARDS:
		_msg.text = tr("Máximo de %d cartas.") % MAX_CARDS
		Sfx.deny()
		return
	if _cards.count(id) >= MAX_COPIES:
		_msg.text = tr("Máximo de %d cópias de cada carta.") % MAX_COPIES
		Sfx.deny()
		return
	_cards.append(id)
	_msg.text = ""
	Sfx.select()
	Settings.vibrate(15)
	for v in _grid.get_children():
		if v is CardView and v.card.data.id == id:
			_refresh_view_copies(v)
	_refresh_deck()

func _remove_card(id: String) -> void:
	var i := _cards.find(id)
	if i >= 0:
		_cards.remove_at(i)
	Sfx.hit()
	for v in _grid.get_children():
		if v is CardView and v.card.data.id == id:
			_refresh_view_copies(v)
	_refresh_deck()

# --- Lista do baralho ---

func _refresh_deck() -> void:
	UiKit.clear_children(_deck_list)
	_deck_title.text = tr("O teu baralho (%d/%d)") % [_cards.size(), MAX_CARDS]
	var counts := {}
	var creatures := 0
	var spells := 0
	var lands := 0
	var colors := {}
	for id in _cards:
		counts[id] = int(counts.get(id, 0)) + 1
		var c := CardDB.get_card(id)
		if c == null:
			continue
		if c.is_creature():
			creatures += 1
		elif c.is_spell():
			spells += 1
		else:
			lands += 1
		for col in c.colors:
			colors[col] = true
	var color_names: Array[String] = []
	for col in ["white", "blue", "black", "red", "green"]:
		if colors.has(col):
			color_names.append(tr(CardZoom.COLOR_NAMES.get(col, col)))
	_summary.text = tr("%d criaturas · %d feitiços · %d terrenos · cores: %s") % [creatures, spells, lands, "/".join(PackedStringArray(color_names)) if not color_names.is_empty() else tr("Incolor")]
	var nums := deck_numbers(_cards)
	if int(nums["cards"]) > 0:
		_summary.text += "  ·  " + tr("Poder médio %d") % int(nums["avg_power"]) + "  ·  " + tr("ataque esperado no 3.º turno ≈ %d") % int(nums["t3"])
	_warn_label.text = "\n".join(PackedStringArray(deck_warnings(_cards)))
	if _curve != null:
		var datas: Array = []
		for id in _cards:
			var cd := CardDB.get_card(id)
			if cd != null:
				datas.append(cd)
		_curve.set_cards(datas)
		if not datas.is_empty():
			_summary.text += "  ·  " + tr("custo médio %s") % ManaCurve.decimal(_curve.average_cost())
	var ids: Array = counts.keys()
	ids.sort_custom(func(a, b):
		var ca := CardDB.get_card(a)
		var cb := CardDB.get_card(b)
		if ca.is_land() != cb.is_land():
			return cb.is_land()
		if ca.cost != cb.cost:
			return ca.cost < cb.cost
		return ca.num < cb.num)
	for id in ids:
		_deck_list.add_child(_deck_strip(CardDB.get_card(id), int(counts[id])))
	_play_btn.disabled = _cards.size() < MIN_CARDS

## 0.16.1 (V52): tira de uma carta do baralho — a esfera do custo na cor da carta, o nome, a ilustração à
## direita a desvanecer para a esquerda e o número de cópias. Tocar tira uma cópia.
func _deck_strip(c: CardData, count: int) -> Button:
	var b := Button.new()
	b.name = "Strip_" + c.id
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(0, 46)
	b.clip_contents = true
	var empty := StyleBoxEmpty.new()
	for st in ["normal", "hover", "pressed", "hover_pressed", "focus"]:
		b.add_theme_stylebox_override(st, empty)
	var col: Color = CardView.COLORS.get(c.primary_color(), CardView.COLORS["colorless"])
	var art := ArtLib.card_art(c.id)
	var name := c.display_name()
	var cost_txt := "+1" if c.is_land() else str(c.cost)
	b.draw.connect(func():
		var r := Rect2(Vector2.ZERO, b.size)
		b.draw_style_box(UiKit.flat(Color(0.12, 0.1, 0.19), 10, Color(col, 0.35), 1, 0), r)
		if art != null:
			# a ilustração na metade direita, a aparecer devagar da esquerda para a direita
			var aw := r.size.x * 0.46
			var ar := Rect2(Vector2(r.size.x - aw, 1.0), Vector2(aw - 1.0, r.size.y - 2.0))
			var src := ArtLib.cover_region(art, ar.size, 0.4)
			var slices := 12
			for k in slices:
				var f0 := float(k) / slices
				var piece := Rect2(ar.position + Vector2(ar.size.x * f0, 0), Vector2(ar.size.x / slices + 0.6, ar.size.y))
				var sp := Rect2(src.position + Vector2(src.size.x * f0, 0), Vector2(src.size.x / slices, src.size.y))
				b.draw_texture_rect_region(art, piece, sp, Color(1, 1, 1, clampf(f0 * 1.6, 0.0, 0.85)))
		b.draw_rect(Rect2(Vector2(0, 0), Vector2(4, r.size.y)), col)
		var oc := Vector2(26.0, r.size.y * 0.5)
		b.draw_circle(oc, 14.0, col.darkened(0.35))
		b.draw_circle(oc, 12.5, col)
		b.draw_arc(oc, 13.5, 0.0, TAU, 32, Color(1, 1, 1, 0.5), 1.2, true)
		var font := b.get_theme_default_font()
		var cw := font.get_string_size(cost_txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 15).x
		b.draw_string(font, oc + Vector2(-cw * 0.5, 5.5), cost_txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 15, CardView.DARK_TEXT if col.get_luminance() > 0.5 else Color.WHITE)
		var cnt := "×%d" % count
		var cnt_w := font.get_string_size(cnt, HORIZONTAL_ALIGNMENT_LEFT, -1, 16).x
		b.draw_string_outline(font, Vector2(48.0, r.size.y * 0.5 + 6.0), name, HORIZONTAL_ALIGNMENT_LEFT, r.size.x - 48.0 - cnt_w - 22.0, 16, 4, Color(0, 0, 0, 0.75))
		b.draw_string(font, Vector2(48.0, r.size.y * 0.5 + 6.0), name, HORIZONTAL_ALIGNMENT_LEFT, r.size.x - 48.0 - cnt_w - 22.0, 16, Color.WHITE)
		b.draw_string_outline(font, Vector2(r.size.x - cnt_w - 10.0, r.size.y * 0.5 + 6.0), cnt, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, 4, Color(0, 0, 0, 0.8))
		b.draw_string(font, Vector2(r.size.x - cnt_w - 10.0, r.size.y * 0.5 + 6.0), cnt, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, UiKit.GOLD))
	b.pressed.connect(_remove_card.bind(c.id))
	return b

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
	elif what == NOTIFICATION_EXIT_TREE and _grid != null:
		_remember()

# --- 0.19.0: o resto da secção 2 ---

func _slot_text(i: int) -> String:
	var d: Dictionary = CardDB.custom_decks.get("custom_%d" % i, {})
	return ("%d · %s" % [i, d.get("name", "")]) if not d.is_empty() else tr("Espaço %d (vazio)") % i

func _fill_slot_opt() -> void:
	_slot_opt.clear()
	for i in range(1, SLOTS + 1):
		_slot_opt.add_item(_slot_text(i))
	_slot_opt.select(clampi(_slot - 1, 0, SLOTS - 1))

## 22: guarda o espaço, os filtros, a ordem, a página e a posição da grelha.
func _remember() -> void:
	_mem = {"slot": _slot, "color": _color_filter, "type": _type_filter, "deck": _deck_filter, "page": _page,
		"search": _search, "sort": _sort, "fav": _fav_only, "scroll": _scroll.scroll_vertical if _scroll != null else 0}

func _recall() -> void:
	if _mem.is_empty():
		_load_slot(1)
		return
	_color_filter = String(_mem.get("color", ""))
	_type_filter = String(_mem.get("type", ""))
	_deck_filter = String(_mem.get("deck", ""))
	_search = String(_mem.get("search", ""))
	_sort = String(_mem.get("sort", "num"))
	_fav_only = bool(_mem.get("fav", false))
	for k in _color_buttons:
		(_color_buttons[k] as Button).set_pressed_no_signal(_color_filter == k)
	for k in _type_buttons:
		(_type_buttons[k] as Button).set_pressed_no_signal(_type_filter == k)
	var sf := find_child("Search", true, false) as LineEdit
	if sf != null:
		sf.text = _search
	var dopt := find_child("DeckFilter", true, false) as OptionButton
	if dopt != null:
		for i in dopt.item_count:
			if String(dopt.get_item_metadata(i)) == _deck_filter:
				dopt.select(i)
	_sort_btn.text = CardSort.label(_sort)
	_fav_btn.set_pressed_no_signal(_fav_only)
	_load_slot(clampi(int(_mem.get("slot", 1)), 1, SLOTS))
	_page = int(_mem.get("page", 0))
	_rebuild()
	var y := int(_mem.get("scroll", 0))
	if y > 0:
		await get_tree().process_frame
		await get_tree().process_frame
		if is_inside_tree() and _scroll != null:
			_scroll.scroll_vertical = y

## 39: os números de um baralho — Poder médio, quantas de cada tipo e o ataque esperado no 3.º turno (uma conta
## simples: a mana dos 3 turnos dá para tantas cartas, e as criaturas ficam a atacar).
static func deck_numbers(ids: Array) -> Dictionary:
	var n := 0
	var lands := 0
	var power_sum := 0
	var cost_sum := 0
	var nonland := 0
	var creature_power := 0
	var creatures := 0
	var spell_power := 0
	var spells := 0
	for id in ids:
		var c := CardDB.get_card(String(id))
		if c == null:
			continue
		n += 1
		if c.is_land():
			lands += 1
			continue
		nonland += 1
		cost_sum += c.cost
		power_sum += c.power
		if c.is_creature():
			creatures += 1
			creature_power += c.power
		else:
			spells += 1
			spell_power += c.power
	var avg_cost := float(cost_sum) / float(maxi(1, nonland))
	# Mana dos turnos 1 a 3 (1 + 2 + 3) e um Terreno por cada 4 cartas na mão inicial.
	var mana := 6.0 + floorf(float(lands) / float(maxi(1, n)) * 6.0)
	var plays := minf(mana / maxf(1.0, avg_cost), 6.0)
	var share_c := float(creatures) / float(maxi(1, nonland))
	var avg_c := float(creature_power) / float(maxi(1, creatures))
	var avg_s := float(spell_power) / float(maxi(1, spells))
	# As criaturas jogadas nos turnos 1–3 atacam no 3.º; os feitiços contam só os do 3.º turno (um terço).
	var t3 := plays * share_c * avg_c + plays * (1.0 - share_c) * avg_s / 3.0
	return {"cards": n, "lands": lands, "creatures": creatures, "spells": spells,
		"avg_power": roundi(float(power_sum) / float(maxi(1, nonland))), "avg_cost": avg_cost, "t3": roundi(t3)}

## 40: avisos do Construtor (poucos Terrenos para cartas caras, uma cor com poucas cartas…).
static func deck_warnings(ids: Array) -> Array[String]:
	var out: Array[String] = []
	var nums := deck_numbers(ids)
	var n := int(nums["cards"])
	if n == 0:
		return out
	if n < MIN_CARDS:
		out.append(TranslationServer.translate("Faltam %d cartas para jogar (mínimo %d).") % [MIN_CARDS - n, MIN_CARDS])
	var land_share := float(nums["lands"]) / float(n)
	if float(nums["avg_cost"]) >= 2.8 and land_share < 0.2:
		out.append(TranslationServer.translate("Poucos Terrenos para cartas tão caras (custo médio %s).") % ManaCurve.decimal(float(nums["avg_cost"])))
	if int(nums["creatures"]) < 5 and n >= MIN_CARDS:
		out.append(TranslationServer.translate("Poucas criaturas: a cascata começa nelas."))
	var per_color := {}
	for id in ids:
		var c := CardDB.get_card(String(id))
		if c == null or c.is_land():
			continue
		for col in c.colors:
			per_color[col] = int(per_color.get(col, 0)) + 1
	if per_color.size() >= 2:
		for col in per_color:
			if int(per_color[col]) <= 2:
				out.append(TranslationServer.translate("Só %d cartas de %s: a mana dessa cor pode não chegar.") % [int(per_color[col]), TranslationServer.translate(String(CardZoom.COLOR_NAMES.get(col, col))).to_lower()])
	if per_color.size() >= 3:
		out.append(TranslationServer.translate("%d cores: a mana pode faltar.") % per_color.size())
	return out

## 41: enche o baralho até TARGET_SIZE com cartas das cores dele (ou das escolhidas no filtro): primeiro Terrenos
## até ~1/4, depois as cartas com o custo onde a curva tem menos. Devolve quantas juntou.
func complete_deck(rng_seed: int = 0) -> int:
	var rng := RandomNumberGenerator.new()
	rng.seed = rng_seed if rng_seed != 0 else int(Time.get_ticks_usec())
	var colors := {}
	if _color_filter != "" and _color_filter != "colorless":
		colors[_color_filter] = true
	for id in _cards:
		var c := CardDB.get_card(id)
		if c != null:
			for col in c.colors:
				colors[col] = true
	var pool: Array = []
	for d in CardDB.collectible_cards():
		var cd := d as CardData
		if cd.is_curse() or not CardDB.is_available(cd) or _cards.count(cd.id) >= MAX_COPIES:
			continue
		if not colors.is_empty() and not cd.is_colorless() and not cd.colors.any(func(col): return colors.has(col)):
			continue
		pool.append(cd)
	var added := 0
	var guard := 0
	while _cards.size() < TARGET_SIZE and not pool.is_empty() and guard < 400:
		guard += 1
		var nums := deck_numbers(_cards)
		var want_land := float(nums["lands"]) < float(_cards.size() + 1) * 0.25
		var curve := {}
		for id in _cards:
			var c := CardDB.get_card(id)
			if c != null and not c.is_land():
				curve[clampi(c.cost, 1, 5)] = int(curve.get(clampi(c.cost, 1, 5), 0)) + 1
		var best_cost := 1
		for k in [2, 3, 1, 4, 5]:
			if int(curve.get(k, 0)) < int(curve.get(best_cost, 0)):
				best_cost = k
		var picks: Array = pool.filter(func(cd: CardData): return cd.is_land() if want_land else (not cd.is_land() and clampi(cd.cost, 1, 5) == best_cost))
		if picks.is_empty():
			picks = pool.filter(func(cd: CardData): return not cd.is_land()) if not want_land else pool
		if picks.is_empty():
			break
		var pick: CardData = picks[rng.randi_range(0, picks.size() - 1)]
		_cards.append(pick.id)
		added += 1
		if _cards.count(pick.id) >= MAX_COPIES:
			pool.erase(pick)
	if added > 0:
		Sfx.boom()
		_msg.text = tr("Juntei %d cartas — toca em GUARDAR para o manter.") % added
		_rebuild()
		_refresh_deck()
	else:
		Sfx.deny()
		_msg.text = tr("Já tem %d cartas ou mais.") % TARGET_SIZE if _cards.size() >= TARGET_SIZE else tr("Não encontrei mais cartas destas cores.")
	return added

## 43: a lista do baralho em texto («2× Lâmina de Aprendiz…»), para mandar a alguém.
func deck_text() -> String:
	var counts := {}
	for id in _cards:
		counts[id] = int(counts.get(id, 0)) + 1
	var ids: Array = counts.keys()
	ids.sort_custom(func(a, b):
		var ca := CardDB.get_card(a)
		var cb := CardDB.get_card(b)
		if ca.cost != cb.cost:
			return ca.cost < cb.cost
		return ca.num < cb.num)
	var lines: Array[String] = [(_name if _name.strip_edges() != "" else tr("Baralho %d") % _slot) + " (%d)" % _cards.size()]
	if _note.strip_edges() != "":
		lines.append(_note.strip_edges())
	for id in ids:
		lines.append("%d× %s" % [int(counts[id]), CardDB.get_card(id).display_name()])
	return "\n".join(PackedStringArray(lines))

## 36: copia o baralho para o primeiro espaço vazio (e passa para lá). Devolve o espaço (0 se estão todos cheios).
func duplicate_deck() -> int:
	if _cards.is_empty():
		Sfx.deny()
		_msg.text = tr("O baralho está vazio.")
		return 0
	var free := 0
	for i in range(1, SLOTS + 1):
		if not CardDB.custom_decks.has("custom_%d" % i) and i != _slot:
			free = i
			break
	if free == 0:
		Sfx.deny()
		_msg.text = tr("Os %d espaços estão cheios.") % SLOTS
		return 0
	var copy := _deck_dict()
	copy["id"] = "custom_%d" % free
	copy["name"] = (tr("Cópia de %s") % String(copy["name"])).substr(0, 24)
	CardDB.custom_decks[copy["id"]] = copy
	CardDB.save_custom_decks()
	_fill_slot_opt()
	_load_slot(free)
	Sfx.boom()
	_msg.text = tr("Copiado para o espaço %d.") % free
	return free

## 42: um baralho da campanha (dos que já abriste) como ponto de partida, no espaço de agora.
func copy_campaign_deck(deck_id: String) -> bool:
	var d := CardDB.get_deck(deck_id)
	if d.is_empty() or not GameState.is_deck_unlocked(deck_id):
		return false
	_cards.clear()
	for id in d.get("cards", []):
		var cd := CardDB.get_card(String(id))
		if cd != null and _cards.size() < MAX_CARDS and _cards.count(cd.id) < MAX_COPIES and not cd.is_curse():
			_cards.append(cd.id)
	_name = (tr("Cópia de %s") % tr(String(d.get("name", "")))).substr(0, 24)
	_name_edit.text = _name
	Sfx.boom()
	_msg.text = tr("Baralho copiado — toca em GUARDAR para o manter.")
	_rebuild()
	_refresh_deck()
	return true

## 32: muda o espaço de agora com o do lado (−1 para trás, +1 para a frente).
func move_slot(step: int) -> bool:
	var to := _slot + step
	if to < 1 or to > SLOTS:
		return false
	if not _cards.is_empty() and _cards.size() >= MIN_CARDS:
		var d := _deck_dict()
		CardDB.custom_decks[d["id"]] = d   # o que está no ecrã vai com ele
	CardDB.swap_custom_decks(_slot, to)
	_fill_slot_opt()
	_load_slot(to)
	Sfx.select()
	_msg.text = tr("Agora é o espaço %d.") % to
	return true

## O ⋯: duplicar, copiar da campanha, lista em texto, mudar de lugar e limpar.
func _open_more() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	var dlg := ChoiceDialog.open(tr("MAIS"), tr("Espaço %d: %s") % [_slot, _name if _name != "" else tr("sem nome")], [
		[tr("DUPLICAR"), "dup", false, not _cards.is_empty()],
		[tr("COPIAR DA CAMPANHA"), "copy"],
		[tr("LISTA EM TEXTO"), "text", false, not _cards.is_empty()],
		["◀ " + tr("PARA TRÁS"), "back", false, _slot > 1],
		[tr("PARA A FRENTE") + " ▶", "fwd", false, _slot < SLOTS],
		[tr("LIMPAR"), "clear", false, not _cards.is_empty()],
	])
	dlg.chosen.connect(_on_more_choice)

func _on_more_choice(v) -> void:
	match String(v):
		"dup":
			duplicate_deck()
		"copy":
			_open_campaign_copy()
		"text":
			DisplayServer.clipboard_set(deck_text())
			_msg.text = tr("Lista copiada — cola-a numa mensagem.")
		"back":
			move_slot(-1)
		"fwd":
			move_slot(1)
		"clear":
			_cards.clear()
			Sfx.hit()
			_rebuild()
			_refresh_deck()

func _open_campaign_copy() -> void:
	var buttons: Array = []
	for d in CardDB.decks:
		var id := String(d.get("id", ""))
		if GameState.is_deck_unlocked(id):
			buttons.append(["%02d · %s" % [int(d.get("num", 0)), tr(String(d.get("name", "")))], id])
	if buttons.is_empty():
		return
	var dlg := ChoiceDialog.open(tr("COPIAR DA CAMPANHA"), tr("Escolhe o baralho que fica no espaço %d (o que lá está é substituído quando guardares).") % _slot, buttons)
	dlg.chosen.connect(func(v):
		if v is String and String(v) != "":
			copy_campaign_deck(String(v)))

## 35: a mão inicial de exemplo — 6 cartas ao acaso do baralho, quantas vezes quiseres.
func _open_sample_hand() -> void:
	if SceneRouter.has_overlay():
		return
	if _cards.size() < 6:
		Sfx.deny()
		_msg.text = tr("Precisas de pelo menos 6 cartas.")
		return
	Sfx.select()
	var root := Control.new()
	root.name = "SampleHandWindow"
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(UiKit.dim(0.82))
	SceneRouter.show_overlay(root)
	var body := UiKit.window(root, 1100, tr("MÃO DE EXEMPLO"), UiKit.GOLD, func(): UiKit.close_animated(root), tr("6 cartas ao acaso, como no início de uma batalha."))
	var row := HBoxContainer.new()
	row.name = "Hand"
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 10)
	body.add_child(row)
	var info := UiKit.label("", 17, UiKit.TEXT_DIM)
	info.name = "Info"
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	body.add_child(info)
	var again := UiKit.button(tr("OUTRA MÃO"), 52, 18, UiKit.PRIMARY)
	again.name = "Again"
	again.custom_minimum_size.x = 220
	again.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	body.add_child(again)
	var deal := func():
		UiKit.clear_children(row)
		var ids := _cards.duplicate()
		ids.shuffle()
		var lands := 0
		var cost := 0
		for i in 6:
			var view: CardView = CARD_VIEW.instantiate()
			row.add_child(view)
			view.setup(CardDB.new_instance(String(ids[i])))
			view.long_pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
			if view.card.data.is_land():
				lands += 1
			else:
				cost += view.card.data.cost
		info.text = tr("%d Terrenos · custo total %d") % [lands, cost]
	deal.call()
	again.pressed.connect(func(): Sfx.shuffle(); deal.call())
	UiKit.pop_in(body.get_meta("panel"))
