extends Control
## ESCOLA DO MAGO (0.11.0): lições curtas e jogáveis (data/lessons.json), uma por mecânica —
## Terrenos, Formações, Fichas, Reforço, Reação e Encantamentos; 0.12.0: Palavras-chave, Cadeias,
## Recapitular, Dupla face, Selos e Planeswalker. Cada lição é uma batalha de 1 turno
## com a mão fixa e uma explicação por cima; as feitas ficam com ✓ (progress.lessons).

func _ready() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	margin.add_child(vbox)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var back := UiKit.button(tr("◀ MENU"), 48, 18)
	back.custom_minimum_size.x = 120
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("ESCOLA DO MAGO"), 26, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	var done := 0
	for l in CardDB.lessons:
		if GameState.lesson_done(String(l.get("id", ""))):
			done += 1
	var counter := UiKit.label(tr("Lições: %d/%d") % [done, CardDB.lessons.size()], 18, UiKit.TEXT_DIM)
	counter.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(counter)
	vbox.add_child(UiKit.label(tr("Lições curtas: cada uma ensina uma mecânica com uma batalha de um turno. Lê a explicação e cumpre o objetivo."), 16, UiKit.TEXT_DIM, true))
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 10)
	scroll.add_child(grid)
	var i := 1
	for l in CardDB.lessons:
		var id := String(l.get("id", ""))
		var ok := GameState.lesson_done(id)
		var b := UiKit.wrap_button("%d · %s%s\n%s" % [i, tr(String(l.get("name", ""))), "  ✓" if ok else "", tr("Objetivo: %s") % tr(String(l.get("goal", "")))], 96, 17, Color(0.16, 0.3, 0.2) if ok else UiKit.BG_LIGHT, Color(0.5, 0.85, 0.55) if ok else UiKit.BORDER)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(_start.bind(id))
		grid.add_child(b)
		i += 1

func _start(id: String) -> void:
	Sfx.boom()
	GameState.start_lesson(id)
	SceneRouter.go("battle")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
