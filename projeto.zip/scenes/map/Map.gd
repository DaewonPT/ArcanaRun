extends Control
## Mapa da run ("As Crónicas da Centelha"): mostra o ato atual (dois antes) como uma fila de nós
## com caminhos bifurcados. Em cada ante há uma batalha (Batedor ou Guarda; boss nos antes
## múltiplos de 4) e depois uma paragem (Loja ou outra). Toca no nó para seguir; os nós já
## percorridos ficam marcados e os futuros veem-se, para planear. A run está gravada aqui.

const NODE_INFO := {
	"scout": ["Batedor", "Inimigo normal · ouro normal", "creature"],
	"guard": ["Guarda", "+25 % de vida · +4 ouro", "shield"],
	"elite": ["Elite", "+60 % de vida, +2 de ataque · relíquia garantida", "skull"],
	"nemesis": ["Némesis", "O teu rival volta mais forte · recompensa especial", "burst"],
	# 0.18.0 (24, 25): batalhas com outro objetivo e a Dupla.
	"ambush": ["Emboscada", "Ataca primeiro · +50 % de ouro", "first_strike"],
	"siege": ["Cerco", "Cura-se · +1 turno · +3 ouro", "flag"],
	"escape": ["Fuga", "Sobrevive 4 turnos", "speed"],
	"pair": ["Dupla", "Dois inimigos · +5 ouro", "swords"],
	"boss": ["Boss", "Regra especial · recompensa de boss", "crown"],
	"shop": ["Loja", "Cartas, relíquias, serviços, juros", "shop"],
	"event": ["Evento", "Uma escolha com consequências", "sorcery"],
	"rest": ["Acampamento", "Curar, treinar, meditar ou forjar uma carta +", "campfire"],
	"spring": ["Fonte de Mana", "Muda a cor de até 3 cartas", "mana"],
	"altar": ["Altar Profano", "Sacrifica uma carta, funde a habilidade", "exile"],
	"merchant": ["Mercador Cego", "Relíquias lendárias e patronos", "relic"],
	"contracts": ["Quadro de Contratos", "Aceita um desafio para a próxima batalha", "contract"],
	"tribunal": ["Tribunal dos Deuses", "Aposta ouro ou vida na roda", "wheel"],
	"treasure": ["Tesouro", "Abre um de três baús", "chest"],
	"sanctuary": ["Santuário", "Uma bênção para a run — com um preço", "heart"],
	"arena": ["Arena", "Batalha extra de 3 turnos · relíquia e ouro", "first_strike"],
	"forge": ["Forja das Edições", "Dá uma edição a uma carta (Brilhante, Holográfica…)", "anvil"],
	"library": ["Biblioteca", "Estuda: uma carta rara, um pergaminho ou limpa o baralho", "book"],
	"vault": ["Cofre", "Guarda ouro agora e recebe mais daqui a uns antes", "chest"],
}
const ELITE_RARITY := {"common": "comum", "uncommon": "incomum", "rare": "rara"}   # 0.19.0 (96)
## 0.19.0 (124): o risco de cada nó (o toque longo mostra-o com o que o nó dá).
const NODE_RISK := {
	"scout": "baixo", "guard": "médio", "elite": "alto", "nemesis": "alto", "boss": "muito alto",
	"ambush": "médio — ele ataca primeiro", "siege": "médio — ele cura-se", "escape": "alto — 4 turnos sem morrer",
	"pair": "alto — dois inimigos", "event": "depende da escolha", "tribunal": "podes perder ouro ou vida",
	"sanctuary": "a bênção tem um preço", "altar": "perdes uma carta", "arena": "perder custa vida",
}
const NODE_COLORS := {
	"scout": Color(0.55, 0.35, 0.3), "guard": Color(0.65, 0.3, 0.3), "elite": Color(0.55, 0.2, 0.42), "boss": Color(0.6, 0.45, 0.15),
	"nemesis": Color(0.42, 0.12, 0.22),
	"ambush": Color(0.58, 0.3, 0.16), "siege": Color(0.3, 0.38, 0.55), "escape": Color(0.22, 0.48, 0.42), "pair": Color(0.5, 0.26, 0.5),
	"shop": Color(0.3, 0.4, 0.6), "event": Color(0.45, 0.35, 0.6), "rest": Color(0.3, 0.5, 0.35),
	"spring": Color(0.25, 0.5, 0.6), "altar": Color(0.4, 0.3, 0.45), "merchant": Color(0.55, 0.45, 0.2),
	"contracts": Color(0.5, 0.4, 0.22), "tribunal": Color(0.52, 0.28, 0.5),
	"treasure": Color(0.6, 0.48, 0.18), "sanctuary": Color(0.32, 0.45, 0.62), "arena": Color(0.62, 0.25, 0.2),
	"forge": Color(0.62, 0.36, 0.2), "library": Color(0.28, 0.42, 0.56), "vault": Color(0.5, 0.44, 0.24),
}

var _columns: Array = []     # [{"ante", "phase", "state", "nodes": {kind: Control}, "buttons": {kind: Button}}]
var _lines: Control
var _busy := false
# 0.13.0 — mapa vivo: caminhos para os nós de agora a correr, brilho a pulsar nos nós e névoa/pirilampos.
var _t := 0.0
var _acc := 0.0
# 0.13.0 — mapa ilustrado (a opção C que o AlizeOnMe escolheu): o fundo do ato, os nós em medalhões ao longo de
# um caminho que serpenteia; as escolhas de agora em grande e a brilhar, o que já passou pequeno e apagado
# (✓ na escolha feita) e o que vem a seguir em tamanho médio, para planear.
const MED_CURRENT := 100.0
const MED_FUTURE := 64.0
const MED_FUTURE_BIG := 80.0    # boss, Elite e Némesis que vêm a seguir
const MED_PAST := 54.0
const LABEL_W := 214.0
const MED_TEXT_SHRINK := 80.0   # 0.20.0 (D13): px que o medalhão da escolha perde por cada 100 % de texto a mais…
const MED_TEXT_SHRINK_MAX := 20.0   # … até 20 px (medido a 115 % e a 130 %: o 3.º medalhão inteiro, a legenda dele por baixo da barra, como a 100 %)
const COLUMN_WAVE := [0.05, -0.07, 0.06, -0.05, 0.04]
var _board: Control
var _board_scroll: ScrollContainer   # 0.19.0 (23)
var _end_node: Control
var _fog_front: Control   # 0.16.1 (68): névoa por cima do fim do ato (o ato seguinte ainda escondido)
var _reveal := 1.0        # 0.16.1 (68): o caminho desenha-se da esquerda para a direita (0 → 1) ao entrar
var _clip_x := INF
var _captions: Array = []    # legendas "Ante N · batalha" por cima de cada coluna
var _long_at := 0            # 0.19.0 (124): quando abriu a legenda de um nó (o toque que a abriu não escolhe)
var _press_id := 0

func _ready() -> void:
	# 0.19.0 (201) Só batalhas: sem lojas nem eventos — depois de cada batalha, o ante seguinte.
	if GameState.mode == "brawl" and GameState.map_phase == "stop":
		GameState.next_ante()
	GameState.save_run({}, "map")
	var backdrop := MapBackdrop.new()
	backdrop.name = "MapBackdrop"
	backdrop.act = GameState.act_of_ante(GameState.ante)
	backdrop.art = ArtLib.texture("background", "act_E" if backdrop.act >= 5 else "act_%d" % backdrop.act)
	Stats.mark_seen("places", "act_E" if backdrop.act >= 5 else "act_%d" % backdrop.act)   # 0.16.1: Galeria
	add_child(backdrop)
	move_child(backdrop, mini(1, get_child_count() - 1))   # por cima do fundo, por trás de tudo o resto
	_preload_battle_art.call_deferred(backdrop.act)
	set_process(Settings.motion_ok())
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	# Cabeçalho: menu, título do ato, estado da run.
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var menu := UiKit.button(tr("MENU"), 48, 18)
	menu.custom_minimum_size.x = 118   # 0.19.0: um pouco mais estreitos, para caber o «?» sem cortar o título
	UiKit.button_icon(menu, "menu", Color.WHITE, 20.0, false)   # 0.16.0 (V59): a casa em vez do ◀
	menu.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(menu)
	# 0.13.0: ver o baralho (com a curva de mana) a partir do mapa.
	var deck_btn := UiKit.button(tr("VER BARALHO (%d)") % GameState.deck.size(), 48, 17)
	deck_btn.name = "DeckBtn"
	deck_btn.custom_minimum_size.x = 196
	UiKit.button_icon(deck_btn, "cards", Color(0.88, 0.85, 0.96), 20.0, false)
	deck_btn.pressed.connect(func(): Sfx.select(); ZoneViewer.open_deck(tr("O TEU BARALHO")))
	header.add_child(deck_btn)
	# 0.19.0 (58–60): a run toda — relíquias (e a ordem delas), formações, Vales, poções…
	var run_btn := UiKit.button(tr("A MINHA RUN"), 48, 17)
	run_btn.name = "RunInfoBtn"
	run_btn.custom_minimum_size.x = 172
	UiKit.button_icon(run_btn, "relic", Color(0.88, 0.85, 0.96), 20.0, false)
	run_btn.pressed.connect(func():
		if not SceneRouter.has_overlay():
			Sfx.select()
			RunInfo.open("relics", func(): GameState.save_run({}, "map")))
	header.add_child(run_btn)
	header.add_child(UiKit.help_button())   # 0.19.0 (145): o Como Jogar na página do mapa
	var act := GameState.act_of_ante(GameState.ante)
	var subtitle := GameState.mode_title() if GameState.mode_title() != "" else tr("As Crónicas da Centelha")
	var title := UiKit.label(tr("ATO %s") % GameState.act_name() + "  ·  " + subtitle, 26, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	title.clip_text = true
	header.add_child(title)
	var acts := HBoxContainer.new()
	acts.add_theme_constant_override("separation", 6)
	header.add_child(acts)
	for i in GameState.ACT_NAMES.size():
		var chip := UiKit.label(GameState.ACT_NAMES[i], 16, UiKit.GOLD if i + 1 == act else (Color(0.5, 0.5, 0.6) if i + 1 > act else Color(0.75, 0.7, 0.55)))
		chip.custom_minimum_size = Vector2(34, 30)
		chip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		chip.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		acts.add_child(chip)
	header.name = "Header"
	# 0.20.0 (D13): o cabeçalho é a exceção do «Texto dos menus» no mapa. O título do ato já ocupa a largura que sobra
	# dos botões (se eles crescessem, saía cortado) e um cabeçalho mais alto tirava altura aos nós.
	for hn in header.find_children("*", "Control", true, false):
		hn.set_meta("mt_done", true)
	UiKit.hand_mirror(header)   # 0.19.0 (25): com a mão esquerda, MENU e VER BARALHO ficam à direita
	# 0.16.1 (V58): a vida, o ouro e as relíquias com os ícones do jogo (coração, moeda, relíquia).
	var status_row := HBoxContainer.new()
	status_row.name = "Status"
	status_row.add_theme_constant_override("separation", 18)
	vbox.add_child(status_row)
	status_row.add_child(UiKit.label("%s  ·  %s" % [tr(String(GameState.deck_def.get("name", ""))), tr("Ante %d") % GameState.ante], 17, UiKit.TEXT_DIM))
	var hp_box := UiKit.icon_text("heart", "%d/%d" % [GameState.player_hp, GameState.player_max_hp], 17, Color.WHITE, Color(0.94, 0.32, 0.37))
	hp_box.name = "Hp"
	status_row.add_child(hp_box)
	var gold_box := UiKit.icon_text("coin", str(GameState.gold), 17, Color(1.0, 0.86, 0.45), UiKit.COIN)
	gold_box.name = "Gold"
	status_row.add_child(gold_box)
	var relic_box := UiKit.icon_text("relic", "%d/%d" % [GameState.relic_ids.size(), GameState.max_relics()], 17, Color.WHITE, Color(0.78, 0.62, 1.0))
	relic_box.name = "Relics"
	status_row.add_child(relic_box)
	# 0.19.0 (71): o ouro previsto para a próxima loja (tocar explica as contas).
	var fc := Economy.next_shop_forecast()
	var fbtn := UiKit.button(tr("Na loja: ~%d") % int(fc["total"]), 36, 15, Color(0.16, 0.13, 0.08, 0.85), Color(UiKit.COIN, 0.5))
	fbtn.name = "Forecast"
	fbtn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	UiKit.button_icon(fbtn, "coin", UiKit.COIN, 18.0, false)
	fbtn.tooltip_text = forecast_text(fc)
	fbtn.pressed.connect(_show_forecast)
	status_row.add_child(fbtn)
	var status_parts: Array[String] = []
	if GameState.stake > 1:
		status_parts.append(tr("Selo %d") % GameState.stake)
	if GameState.endless:
		status_parts.append(tr("Modo infinito"))
		var nm := GameState.next_endless_milestone()
		if nm > 0:
			status_parts.append(tr("Próximo marco: ante %d (%s)") % [nm, milestone_prize(nm)])   # 0.19.0 (91): e o prémio
	if Economy.loan() > 0:   # 0.19.0 (84)
		status_parts.append(tr("Dívida: %d") % Economy.loan())
	if not GameState.boss_relics.is_empty():
		status_parts.append(tr("de boss: %d") % GameState.boss_relics.size())
	if not status_parts.is_empty():
		var status := UiKit.label("  ·  ".join(PackedStringArray(status_parts)), 17, UiKit.TEXT_DIM)
		status.clip_text = true
		status.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		status_row.add_child(status)
	_build_chips(vbox)

	# Mapa ilustrado: o caminho por trás (_lines) e os medalhões por cima, postos no sítio por _layout_board.
	# 0.19.0 (23): numa lista que se arrasta com o dedo — quando os nós de uma coluna não cabem na altura do ecrã
	# (muitas opções, ecrã baixo, interface grande), o mapa fica mais alto e vê-se o resto a arrastar.
	_board_scroll = ScrollContainer.new()
	_board_scroll.name = "BoardScroll"
	_board_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_board_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_board_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	vbox.add_child(_board_scroll)
	_board = Control.new()
	_board.name = "Board"
	_board.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_board.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_board.mouse_filter = Control.MOUSE_FILTER_PASS
	_board_scroll.add_child(_board)
	_board_scroll.resized.connect(_layout_board)
	_lines = Control.new()
	_lines.set_anchors_preset(Control.PRESET_FULL_RECT)
	_lines.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_lines.draw.connect(_draw_lines)
	_board.add_child(_lines)
	var antes: Array[int] = []
	if act < 5:
		var first_ante := (act - 1) * 2 + 1
		antes.append(first_ante)
		antes.append(first_ante + 1)
	else:
		antes.append(GameState.ante)
	for a in antes:
		var opts := GameState.map_options(a)
		_column(a, "battle", opts["battle"])
		_column(a, "stop", opts["stop"])
	# O fim do ato (ou o ante seguinte, no Infinito).
	var end_txt := tr("Ato %s") % GameState.ACT_NAMES[min(act, 4)] if act < 5 else tr("Ante %d") % (GameState.ante + 1)
	_end_node = _node_widget("", "future", false, 0, end_txt, "", "flag", Color(0.19, 0.16, 0.28), MED_PAST - 4.0)
	_end_node.name = "EndNode"
	_board.add_child(_end_node)
	_fog_front = Control.new()
	_fog_front.name = "FogFront"
	_fog_front.set_anchors_preset(Control.PRESET_FULL_RECT)
	_fog_front.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fog_front.draw.connect(_draw_fog_front)
	_board.add_child(_fog_front)
	_board.resized.connect(_layout_board)

	var hint_txt := tr("Escolhe a batalha do ante %d.") % GameState.ante if GameState.map_phase == "battle" else tr("Ante %d vencido! Escolhe onde parar antes do próximo.") % GameState.ante
	var hint_box := PanelContainer.new()
	hint_box.name = "Hint"
	hint_box.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	hint_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hint_box.add_theme_stylebox_override("panel", UiKit.flat(Color(0.08, 0.06, 0.12, 0.82), 12, Color(UiKit.GOLD, 0.5), 1, 10))
	var hint := UiKit.label(hint_txt, 18, UiKit.GOLD)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var hint_row := HBoxContainer.new()
	hint_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hint_row.add_theme_constant_override("separation", 12)
	hint_row.add_child(hint)
	_add_boss_path(hint_row)   # 0.19.0 (123)
	hint_box.add_child(hint_row)
	vbox.add_child(hint_box)
	await get_tree().process_frame
	_layout_board()
	_start_reveal()
	# Ato novo: interlúdio com o nome do ato, a história e o clima (uma vez por ato).
	if GameState.map_phase == "battle":
		ActInterlude.open_if_new()
	# 0.13.0: o que aconteceu entre antes (consequências de eventos, maldição nova do Infinito).
	_show_later_notes()
	# 0.17.0 (89): Pacto do Infinito por escolher.
	_show_pact()
	# 0.19.0 (75): a carta depois da batalha (opção da run).
	_show_card_reward()
	# 0.19.0 (173): bom sítio para parar — depois de um boss (ou do fim de um ato), uma vez por ante.
	_safe_stop_note()

## Clima do ato (e o do próximo, na última paragem do ato) e o contrato ativo; tocar explica.
func _build_chips(parent: Control) -> void:
	var chips := HBoxContainer.new()
	chips.add_theme_constant_override("separation", 10)
	var climate := GameState.climate_for_ante(GameState.ante)
	if climate != "":
		chips.add_child(UiKit.info_chip("climate", tr("Clima: %s") % tr(String(CardDB.get_climate(climate).get("name", ""))), Color(0.35, 0.8, 0.85),
			func(): CardZoom.show_climate(climate)))
	if GameState.map_phase == "stop" and GameState.climate_key(GameState.ante + 1) != GameState.climate_key(GameState.ante):
		var next := GameState.climate_for_ante(GameState.ante + 1)
		if next != "":
			chips.add_child(UiKit.info_chip("climate", tr("A seguir: %s") % tr(String(CardDB.get_climate(next).get("name", ""))), Color(0.55, 0.65, 0.75),
				func(): CardZoom.show_climate(next)))
	if not GameState.contract.is_empty():
		var con: Dictionary = GameState.contract
		chips.add_child(UiKit.info_chip("contract", tr("Contrato: %s") % tr(String(con.get("name", ""))), UiKit.GOLD,
			func(): CardZoom.show_contract(con)))
	# 0.13.0: poções e pergaminhos (tocar: usar no mapa ou deitar fora), maldições do Infinito, promessas.
	for i in GameState.consumables.size():
		var def := CardDB.get_consumable(GameState.consumables[i])
		var chip := UiKit.info_chip(String(def.get("kind", "potion")), tr(String(def.get("name", ""))), Color(String(def.get("color", "#ffffff"))),
			_on_item.bind(i), 46, ArtLib.texture("item", String(GameState.consumables[i])))   # V58: com a ilustração
		chip.name = "ItemChip%d" % i
		chips.add_child(chip)
	if not GameState.endless_curses.is_empty():
		chips.add_child(UiKit.info_chip("curse", tr("Maldições: %d") % GameState.endless_curses.size(), Color(0.9, 0.45, 0.6), _show_curses))
	if not GameState.pending_later.is_empty():
		chips.add_child(UiKit.info_chip("wheel", tr("Promessas: %d") % GameState.pending_later.size(), Color(0.75, 0.7, 0.98), _show_later))
	# 0.19.0 (125): quem vem a seguir (o retrato, a regra e a cor fraca, se já o conheces).
	var nx := next_enemy_chip()
	if nx != null:
		chips.add_child(nx)
	# 0.19.0 (100): risco a troco de ouro — uma regra difícil na batalha deste ante, paga ao vencer.
	if Economy.risk_allowed():
		var rk := Economy.risk_active()
		var offer := Economy.risk_offer(GameState.ante)
		var on := not rk.is_empty()
		var rchip := UiKit.info_chip("skull", (tr("Risco aceite: +%d ouro") if on else tr("Risco: +%d ouro?")) % int(offer.get("gold", 0)),
			Color(1.0, 0.55, 0.4) if on else Color(0.85, 0.7, 0.6), _on_risk)
		rchip.name = "RiskChip"
		chips.add_child(rchip)
	if chips.get_child_count() > 0:
		parent.add_child(chips)
	else:
		chips.free()

## Uma coluna de nós (as opções de uma fase de um ante): um medalhão por opção.
func _column(a: int, phase: String, kinds: Array) -> Dictionary:
	var state := _state_of(a, phase)
	var chosen := GameState.map_chosen(a, phase)
	var entry := {"ante": a, "phase": phase, "state": state, "nodes": {}, "buttons": {}}
	for kind in kinds:
		var k := String(kind)
		var picked: bool = chosen == k or (state == "past" and kinds.size() == 1)
		var node := _node_widget(k, state, picked, a, "", "", "", Color(0, 0, 0, 0), _med_size(k, state, picked, kinds.size()))
		_board.add_child(node)
		var b: Button = node.get_meta("button")
		if state == "current":
			b.pressed.connect(_on_pick.bind(a, phase, k))
		entry["nodes"][k] = node
		entry["buttons"][k] = b
	var cap := UiKit.label(tr("Ante %d") % a + "  ·  " + (tr("batalha") if phase == "battle" else tr("paragem")), 13, Color(UiKit.TEXT_DIM, 0.75))
	cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	cap.custom_minimum_size.x = LABEL_W
	cap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cap.add_theme_constant_override("outline_size", 5)
	cap.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.7))
	_board.add_child(cap)
	_captions.append(cap)
	_columns.append(entry)
	return entry

## "past" (já passou), "current" (é a escolha de agora) ou "future".
func _state_of(a: int, phase: String) -> String:
	if a < GameState.ante:
		return "past"
	if a > GameState.ante:
		return "future"
	if phase == GameState.map_phase:
		return "current"
	return "past" if phase == "battle" else "future"

## 265: a forma de cada tipo de nó (círculo, quadrado, losango, triângulo, hexágono, estrela, coração…).
## Batalhas: círculo (normais), losango (mais duras), hexágono (boss), estrela (némesis e Dupla); paragens: quadrado
## (loja e serviços), triângulo (eventos e apostas), coração (descanso e bênçãos), pentágono (tesouros).
const NODE_SHAPES := {"scout": "circle", "guard": "circle", "elite": "diamond", "nemesis": "star", "ambush": "diamond",
	"siege": "diamond", "escape": "circle", "pair": "star", "boss": "hexagon", "arena": "diamond",
	"shop": "square", "merchant": "square", "forge": "square", "library": "square", "contracts": "square", "spring": "square",
	"event": "triangle", "tribunal": "triangle", "altar": "triangle",
	"rest": "heart", "sanctuary": "heart", "treasure": "pentagon", "vault": "pentagon"}

class NodeShape extends Control:
	var shape := "circle"

	func _init() -> void:
		size = Vector2(22, 22)
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _draw() -> void:
		var c := size / 2.0
		draw_circle(c, 11.0, Color(0, 0, 0, 0.75))
		var r := 7.0
		var col := Color.WHITE
		match shape:
			"circle":
				draw_circle(c, r * 0.8, col)
			"square":
				draw_rect(Rect2(c - Vector2(r, r) * 0.7, Vector2(r, r) * 1.4), col)
			"heart":
				draw_circle(c + Vector2(-2.6, -1.5), 3.3, col)
				draw_circle(c + Vector2(2.6, -1.5), 3.3, col)
				draw_colored_polygon(PackedVector2Array([c + Vector2(-5.6, -0.3), c + Vector2(5.6, -0.3), c + Vector2(0, 6)]), col)
			_:
				var n := {"diamond": 4, "triangle": 3, "pentagon": 5, "hexagon": 6, "star": 10}.get(shape, 4) as int
				var pts := PackedVector2Array()
				for k in n:
					var a := -PI / 2.0 + TAU * k / n
					var rr := r if shape != "star" or k % 2 == 0 else r * 0.45
					pts.append(c + Vector2(cos(a), sin(a)) * rr)
				draw_colored_polygon(pts, col)

## 0.20.0 (D13): largura das legendas dos nós, que cresce com o «Texto dos menus».
func _label_w() -> float:
	return LABEL_W * minf(Settings.menu_text_scale(), 1.2)

## Diâmetro do medalhão de um nó.
## 0.20.0 (D13): com o «Texto dos menus» maior e 3 ou mais opções na coluna, o medalhão da escolha encolhe o que as
## legendas crescem (a coluna já não cabia na altura do ecrã a 100 %; assim o 3.º medalhão continua à vista).
func _med_size(kind: String, state: String, chosen: bool, in_column: int = 1) -> float:
	match state:
		"current":
			return MED_CURRENT - (minf(roundf((Settings.menu_text_scale() - 1.0) * MED_TEXT_SHRINK), MED_TEXT_SHRINK_MAX) if in_column >= 3 else 0.0)
		"past":
			return MED_PAST if chosen else MED_PAST - 8.0
	return MED_FUTURE_BIG if kind in ["boss", "elite", "nemesis"] else MED_FUTURE

## Um nó do mapa: o medalhão (botão redondo com o ícone) e, por baixo, o nome e o que tem.
## Devolve o contentor; o botão fica na meta "button".
func _node_widget(kind: String, state: String, chosen: bool, ante: int = 0, title_override: String = "", desc_override: String = "",
		icon_override: String = "", color_override: Color = Color(0, 0, 0, 0), size_override: float = 0.0) -> Control:
	var info: Array = NODE_INFO.get(kind, [kind, "", "relic"])
	var color: Color = color_override if color_override.a > 0.0 else NODE_COLORS.get(kind, UiKit.BG_LIGHT)
	var d := size_override if size_override > 0.0 else _med_size(kind, state, chosen)
	var box := VBoxContainer.new()
	box.name = "Node_" + (kind if kind != "" else "end")
	box.add_theme_constant_override("separation", 4)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var b := Button.new()
	b.custom_minimum_size = Vector2(d, d)
	b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b.focus_mode = Control.FOCUS_NONE
	var bg := color if state == "current" else (color.darkened(0.25) if state == "future" else color.darkened(0.45))
	var border := UiKit.GOLD if state == "current" else (Color(0.6, 0.85, 0.6) if chosen else Color(1, 1, 1, 0.35))
	var style := UiKit.flat(bg, int(d / 2.0), border, 3 if (state == "current" or chosen) else 2, 0)
	style.shadow_color = Color(0, 0, 0, 0.5)
	style.shadow_size = 8
	style.shadow_offset = Vector2(0, 4)
	b.add_theme_stylebox_override("normal", style)
	b.add_theme_stylebox_override("hover", style)
	var pressed_style := style.duplicate() as StyleBoxFlat
	pressed_style.bg_color = bg.lightened(0.15)
	b.add_theme_stylebox_override("pressed", pressed_style)
	b.add_theme_stylebox_override("disabled", style)
	b.disabled = state != "current"
	if state == "current":
		b.set_meta("haptic", true)   # 0.16.0 (V60): escolher o caminho vibra um instante
	# 0.13.0: ilustração do medalhão (assets/art/mapnodes/<tipo>.webp); sem ela, o ícone desenhado.
	var art_id := kind if kind != "" else "act_end"
	var art_tex: Texture2D = ArtLib.texture("mapnode", art_id)
	if art_tex != null:
		var art := Control.new()
		art.name = "NodeArt"
		art.set_anchors_preset(Control.PRESET_FULL_RECT)
		art.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var inset := 3.0 if (state == "current" or chosen) else 2.0
		art.draw.connect(func(): ArtLib.draw_round(art, art_tex, art.size / 2.0, minf(art.size.x, art.size.y) / 2.0 - inset))
		if state == "past":
			art.modulate = Color(0.75, 0.75, 0.8)
		b.add_child(art)
	else:
		var center := CenterContainer.new()
		center.set_anchors_preset(Control.PRESET_FULL_RECT)
		center.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_child(center)
		var icon := CardIcon.new(icon_override if icon_override != "" else String(info[2]), Color.WHITE if state != "past" else Color(0.82, 0.82, 0.86), d * 0.42)
		icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
		center.add_child(icon)
	box.add_child(b)
	# 0.19.0 (265): cada tipo de nó com uma forma própria (com o modo daltónico ou um filtro de cores).
	if kind != "" and (Settings.colorblind or String(Settings.opt("colorblind_filter")) != "none"):
		var sh := NodeShape.new()
		sh.name = "Shape"
		sh.shape = String(NODE_SHAPES.get(kind, "circle"))
		sh.position = Vector2(-4.0, d - 18.0)
		b.add_child(sh)
	# 0.19.0 (122): NOVO nos nós que nunca visitaste; (124) toque longo mostra tudo o que o nó dá e o risco.
	if kind != "" and state != "past" and not GameState.node_seen(kind):
		var nv := PanelContainer.new()
		nv.name = "NewMark"
		nv.mouse_filter = Control.MOUSE_FILTER_IGNORE
		nv.add_theme_stylebox_override("panel", UiKit.flat(Color(0.85, 0.2, 0.25), 7, Color(1, 0.85, 0.85), 1, 3))
		var nl := UiKit.label(tr("NOVO"), 11, Color.WHITE)
		nl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		nv.add_child(nl)
		b.add_child(nv)
		# 0.20.0 (D13): preso à direita do medalhão e a crescer para dentro. Na escolha (100 px) fica onde estava, a
		# 62 %, e com a letra maior ou o medalhão mais pequeno não sai dele; nos nós pequenos que vêm a seguir continua
		# a sair os mesmos px de sempre (38 px de etiqueta a começar nos 62 %).
		var over := 0.0 if state == "current" else maxf(0.0, 38.0 - d * 0.38)
		nv.anchor_left = 1.0
		nv.anchor_right = 1.0
		nv.offset_left = over
		nv.offset_right = over
		nv.grow_horizontal = Control.GROW_DIRECTION_BEGIN
		nv.offset_top = -4.0
	if kind != "":
		b.gui_input.connect(_on_node_input.bind(b, kind, ante))
	var title_txt := title_override if title_override != "" else tr(String(info[0]))
	var desc_txt := desc_override if title_override != "" else tr(String(info[1]))
	if kind == "elite" and ante > 0:   # 0.19.0 (96): a raridade da relíquia garantida
		desc_txt = tr("+60 % de vida, +2 de ataque") + " · " + tr("relíquia %s garantida") % tr(String(ELITE_RARITY.get(Economy.elite_rarity(ante), "comum")))
	if kind == "nemesis":
		var nd := GameState.nemesis_def()
		title_txt = tr(String(nd.get("name", "Némesis")))
		desc_txt = tr("Némesis · nível %d · recompensa especial") % maxi(1, GameState.nemesis_level(ante))
	elif kind == "event" and state != "past" and GameState.chain_due(ante):
		# 0.17.0 (93): a parte seguinte da história em cadeia espera neste Evento.
		var cev := CardDB.get_event(GameState.chain_next_event())
		title_txt = tr("História")
		desc_txt = tr("Parte %d de %d: %s") % [GameState.chain_part + 1, GameState.CHAIN_PARTS, tr(String(cev.get("title", "")))]
	var t := UiKit.label(("✓ " if chosen and state == "past" else "") + title_txt, 19 if state == "current" else 15,
		Color.WHITE if state != "past" else Color(0.82, 0.82, 0.86))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	# 0.20.0 (D13): as legendas alargam com o «Texto dos menus» (até 120 %: mais do que isso tocava na coluna do lado).
	var mt := Settings.menu_text_scale()
	var label_w := _label_w()
	t.custom_minimum_size.x = label_w
	t.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	t.add_theme_constant_override("outline_size", 6)
	t.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	box.add_child(t)
	if desc_txt != "" and state != "past":
		var dl := UiKit.label(desc_txt, 13 if state == "current" else 12, Color(0.9, 0.9, 0.95) if state == "current" else Color(0.75, 0.75, 0.82), true)
		dl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		dl.custom_minimum_size.x = label_w
		dl.max_lines_visible = 2
		dl.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		dl.custom_minimum_size.y = ceilf((34.0 if state == "current" else 31.0) * mt)   # com reticências o mínimo seria 1 px
		dl.add_theme_constant_override("line_spacing", 0)
		dl.add_theme_constant_override("outline_size", 5)
		dl.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
		box.add_child(dl)
	if state == "past" and not chosen:
		b.modulate.a = 0.45
		box.modulate.a = 0.7
	box.set_meta("button", b)
	box.set_meta("diameter", d)
	box.set_meta("chosen", chosen)
	return box

## Põe os medalhões no sítio: colunas espalhadas da esquerda para a direita, cada uma a subir ou a descer
## um pouco (o caminho serpenteia), e as opções de cada coluna umas por baixo das outras.
func _layout_board() -> void:
	if _board == null or not is_instance_valid(_board):
		return
	var w := _board.size.x
	var h := _board.size.y
	if w < 10.0 or h < 10.0:
		return
	# 0.19.0 (23): se uma coluna não cabe, o mapa cresce para baixo (e arrasta-se); se cabe, volta à altura do ecrã.
	var vis_h := _board_scroll.size.y if _board_scroll != null else h
	var need := 0.0
	for e in _columns:
		var nds: Array = (e["nodes"] as Dictionary).values()
		var nh := 0.0
		for nd in nds:
			nh = maxf(nh, (nd as Control).get_combined_minimum_size().y)
		need = maxf(need, 18.0 + 6.0 + nh * nds.size() + 6.0 * maxf(0.0, nds.size() - 1.0) + 8.0)
	var want_min := need if need > vis_h + 1.0 else 0.0
	if absf(_board.custom_minimum_size.y - want_min) > 0.5:
		_board.custom_minimum_size.y = want_min
		return   # o tamanho novo chama outra vez o _layout_board
	var n := _columns.size()
	var left := 120.0 + (_label_w() - LABEL_W) / 2.0   # 0.20.0 (D13): a legenda mais larga da 1.ª coluna não sai pela esquerda
	var end_x := w - 70.0
	var step := (end_x - left) / float(maxi(1, n))
	var cap_h := 18.0
	for i in n:
		var e: Dictionary = _columns[i]
		var x := left + step * i
		var nodes: Array = (e["nodes"] as Dictionary).values()
		var m := nodes.size()
		var node_h := 0.0
		for nd in nodes:
			node_h = maxf(node_h, (nd as Control).get_combined_minimum_size().y)
		# 0.20.0 (D13): com o «Texto dos menus» maior, uma coluna que cabe arruma-se na altura à vista (e não na do
		# mapa todo, que cresce quando outra coluna não cabe): nada dela fica debaixo da barra de baixo.
		var col_h := h
		if Settings.menu_text_scale() > 1.001 and cap_h + 6.0 + node_h * m + 6.0 * maxf(0.0, m - 1.0) + 8.0 <= vis_h:
			col_h = vis_h
		var avail := col_h - cap_h - 6.0
		var spacing := 0.0 if m <= 1 else minf(200.0, maxf(node_h + 6.0, (avail - node_h) / float(m - 1)))
		spacing = minf(spacing, (avail - node_h) / float(maxi(1, m - 1))) if m > 1 else 0.0
		var span := spacing * float(m - 1) + node_h
		var yc := col_h * (0.52 + float(COLUMN_WAVE[i % COLUMN_WAVE.size()]))
		var top := clampf(yc - span / 2.0, cap_h + 4.0, maxf(cap_h + 4.0, col_h - span - 2.0))
		for k in m:
			var nd := nodes[k] as Control
			var sz := nd.get_combined_minimum_size()
			nd.size = sz
			nd.position = Vector2(x - sz.x / 2.0, top + spacing * k)
		var cap := _captions[i] as Control
		cap.size = cap.get_combined_minimum_size()
		cap.position = Vector2(x - cap.size.x / 2.0, 0.0)
	if _end_node != null:
		var sz := _end_node.get_combined_minimum_size()
		_end_node.size = sz
		var end_h := vis_h if Settings.menu_text_scale() > 1.001 else h
		_end_node.position = Vector2(end_x - sz.x / 2.0, end_h * 0.52 - float(_end_node.get_meta("diameter", 50.0)) / 2.0)
	_lines.queue_redraw()
	if _fog_front != null:
		_fog_front.queue_redraw()

## Centro do medalhão de um nó (nas coordenadas do caminho).
func _med_center(node: Control) -> Vector2:
	var b := node.get_meta("button") as Control
	return b.global_position + b.size / 2.0 - _lines.global_position

func _process(delta: float) -> void:
	_t += delta
	_acc += delta
	if _acc >= 1.0 / 20.0 and _lines != null:   # 0.16.0 (74): 20 redesenhos por segundo chegam (eram 30)
		_acc = 0.0
		_lines.queue_redraw()
		if _fog_front != null:
			_fog_front.queue_redraw()

## 0.16.1 (68): ao entrar, o caminho desenha-se da esquerda para a direita (~1 s) e os medalhões que vêm
## a seguir acendem-se quando ele lá chega. Sem movimento (ou nos testes): tudo já desenhado.
func _start_reveal() -> void:
	if not Settings.motion_ok() or DisplayServer.get_name() == "headless" or _board == null:
		_set_reveal(1.0)
		return
	_set_reveal(0.0)
	var tw := create_tween()
	tw.tween_method(_set_reveal, 0.0, 1.0, Settings.dur(1.1)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_SINE)

func _set_reveal(v: float) -> void:
	_reveal = v
	if _board == null or not is_instance_valid(_board):
		return
	_clip_x = INF if v >= 1.0 else lerpf(0.0, _board.size.x + 40.0, v)
	for col in _columns:
		var future := String(col["state"]) == "future"
		for nd in (col["nodes"] as Dictionary).values():
			_fade_by_reveal(nd as Control, future)
	if _end_node != null:
		_fade_by_reveal(_end_node, true)
	_lines.queue_redraw()

func _fade_by_reveal(nd: Control, future: bool) -> void:
	if not future or _clip_x == INF:
		nd.modulate.a = 1.0
		return
	var cx := nd.position.x + nd.size.x * 0.5
	nd.modulate.a = clampf(0.15 + (_clip_x - cx + 40.0) / 80.0, 0.15, 1.0)

## 0.16.1 (68): o ato seguinte fica na névoa — nuvens suaves por cima do fim do ato, a deslizar devagar.
func _draw_fog_front() -> void:
	if _end_node == null or not is_instance_valid(_end_node) or _end_node.size.x <= 0.0:
		return
	var e := _med_center(_end_node)
	var tex := MenuBackdrop.glow_texture()
	var veil := Color(0.62, 0.58, 0.74)
	for i in 6:
		var ph := float(i) * 1.7
		var dx := 26.0 * sin(_t * 0.25 + ph) + (float(i % 3) - 1.0) * 44.0
		var dy := 14.0 * cos(_t * 0.2 + ph) + (floorf(i / 3.0) - 0.5) * 70.0
		var r := 70.0 + 18.0 * float(i % 2)
		_fog_front.draw_texture_rect(tex, Rect2(e + Vector2(dx, dy) - Vector2(r * 1.3, r), Vector2(r * 2.6, r * 2.0)), false, Color(veil, 0.22))

func _draw_lines() -> void:
	if _columns.is_empty():
		return
	var moving := Settings.motion_ok()
	var offset := _t * 42.0 if moving else 0.0
	# Entrada do ato (da esquerda) e saída para o fim do ato.
	for nd in (_columns[0]["nodes"] as Dictionary).values():
		var c := _med_center(nd as Control)
		_curve(Vector2(-30.0, c.y), c - Vector2(float((nd as Control).get_meta("diameter", 50.0)) / 2.0, 0.0), Color(1, 1, 1, 0.22), false, 0.0)
	for i in range(_columns.size() - 1):
		var from_state := String(_columns[i]["state"])
		var to_state := String(_columns[i + 1]["state"])
		for fn in (_columns[i]["nodes"] as Dictionary).values():
			for tn in (_columns[i + 1]["nodes"] as Dictionary).values():
				var a := _med_center(fn as Control)
				var b := _med_center(tn as Control)
				var ra := float((fn as Control).get_meta("diameter", 50.0)) / 2.0
				var rb := float((tn as Control).get_meta("diameter", 50.0)) / 2.0
				var from_chosen := bool((fn as Control).get_meta("chosen", false))
				var to_chosen := bool((tn as Control).get_meta("chosen", false))
				var p1 := a + Vector2(ra, 0)
				var p2 := b - Vector2(rb, 0)
				if to_state == "current":
					if from_state != "past" or from_chosen:
						_curve(p1, p2, Color(UiKit.GOLD, 0.9), true, offset)   # o caminho de agora corre
				elif from_state == "past":
					if from_chosen and to_chosen:
						_curve(p1, p2, Color(0.6, 0.9, 0.65, 0.55), false, 0.0)   # o caminho que fizeste
				elif from_state == "current":
					_curve(p1, p2, Color(1, 1, 1, 0.26), false, 0.0)   # para onde podes ir a seguir
				else:
					_curve(p1, p2, Color(1, 1, 1, 0.09), false, 0.0)   # mais à frente
	if _end_node != null:
		var e := _med_center(_end_node)
		var re := float(_end_node.get_meta("diameter", 50.0)) / 2.0
		for nd in (_columns[_columns.size() - 1]["nodes"] as Dictionary).values():
			var c := _med_center(nd as Control)
			_curve(c + Vector2(float((nd as Control).get_meta("diameter", 50.0)) / 2.0, 0.0), e - Vector2(re, 0), Color(1, 1, 1, 0.22), false, 0.0)
	# Brilho a pulsar à volta dos medalhões que podes escolher agora.
	var pulse := 0.5 + 0.5 * sin(_t * 3.0) if moving else 0.6
	for col in _columns:
		if String(col["state"]) != "current":
			continue
		for nd in (col["nodes"] as Dictionary).values():
			var c := _med_center(nd as Control)
			var r := float((nd as Control).get_meta("diameter", 50.0)) / 2.0
			_lines.draw_circle(c, r + 12.0 + 6.0 * pulse, Color(UiKit.GOLD, 0.08 + 0.07 * pulse))
			_lines.draw_circle(c, r + 5.0, Color(UiKit.GOLD, 0.22 + 0.12 * pulse))

## Curva suave (tangentes horizontais) de a para b: tracejada e a andar (o caminho de agora) ou em pontinhos.
func _curve(a: Vector2, b: Vector2, col: Color, dashed: bool, offset: float) -> void:
	var dx := (b.x - a.x) * 0.5
	var pts := PackedVector2Array()
	var segs := 28
	for i in segs + 1:
		var t := float(i) / float(segs)
		var u := 1.0 - t
		pts.append(a * (u * u * u) + (a + Vector2(dx, 0)) * (3.0 * u * u * t) + (b - Vector2(dx, 0)) * (3.0 * u * t * t) + b * (t * t * t))
	var dash := 10.0 if dashed else 2.5
	var gap := 9.0 if dashed else 8.0
	var period := dash + gap
	var walked := 0.0
	var width := 3.5 if dashed else 2.6
	for i in pts.size() - 1:
		var p := pts[i]
		var q := pts[i + 1]
		var seg := p.distance_to(q)
		if seg < 0.01:
			continue
		var s0 := 0.0
		while s0 < seg:
			var phase := fposmod(walked + s0 - offset, period)
			var run := (dash - phase) if phase < dash else (period - phase)
			var s1 := minf(seg, s0 + maxf(0.5, run))
			if phase < dash:
				var d0 := p.lerp(q, s0 / seg)
				var d1 := p.lerp(q, s1 / seg)
				if d0.x <= _clip_x:   # 68: o caminho ainda a desenhar-se
					if d1.x > _clip_x and absf(d1.x - d0.x) > 0.01:
						d1 = d0.lerp(d1, (_clip_x - d0.x) / (d1.x - d0.x))
					_lines.draw_line(d0, d1, col, width, true)
			s0 = s1
		walked += seg

func _on_pick(a: int, phase: String, kind: String) -> void:
	if _busy or a != GameState.ante or phase != GameState.map_phase:
		return
	if Time.get_ticks_msec() - _long_at < 1200:   # 124: o dedo largou depois de abrir a legenda
		_long_at = 0
		return
	GameState.mark_node_seen(kind)   # 122
	if phase == "battle" and kind == "boss" and Economy.final_trade_due() and not SceneRouter.has_overlay():
		_busy = true
		await _final_trade()   # 0.19.0 (86): o ouro que sobra antes do boss final
		if not is_inside_tree():
			return
	_busy = true
	Sfx.boom()
	if phase == "battle":
		GameState.remember_node_choice()   # 0.19.0 (199): para poder voltar e escolher outro nó
		GameState.choose_battle(kind)
		GameState.save_run({}, "battle")
		SceneRouter.go("battle")
	else:
		GameState.choose_stop(kind)
		var scene := GameState.stop_scene(kind)
		GameState.save_run({}, scene)
		SceneRouter.go(scene)

# --- 0.13.0: poções e pergaminhos, maldições do Infinito, promessas dos eventos ---

## Tocar numa poção/pergaminho no mapa: as do mapa usam-se aqui; todas se podem deitar fora.
func _on_item(index: int) -> void:
	if _busy or SceneRouter.has_overlay() or index >= GameState.consumables.size():
		return
	Sfx.select()
	var id := GameState.consumables[index]
	var def := CardDB.get_consumable(id)
	var use := String(def.get("use", "battle"))
	var body := tr(String(def.get("text", "")))
	var buttons: Array = []
	if use == "battle":
		body += "\n\n" + tr("Usa-se nas batalhas: toca nele na barra de cima.")
	else:
		var eff: Dictionary = def.get("effect", {})
		var ok := not (eff.has("heal") and GameState.player_hp >= GameState.player_max_hp) and not (eff.has("remove_card") and GameState.deck.size() <= 6)
		buttons.append([tr("USAR"), "use", true, ok])
	buttons.append([tr("DEITAR FORA"), "drop"])
	buttons.append([tr("FECHAR"), null])
	var d := ChoiceDialog.open(tr(String(def.get("name", id))), body, buttons, Color(String(def.get("color", "#ffd25a"))))
	var v = await d.chosen
	if not is_inside_tree() or index >= GameState.consumables.size() or GameState.consumables[index] != id:
		return
	if v == "drop":
		GameState.remove_consumable_at(index)
		_reload()
	elif v == "use":
		if (def.get("effect", {}) as Dictionary).has("remove_card"):
			_use_purge(index)
			return
		var txt := GameState.use_consumable_outside(index)
		if txt != "":
			SceneRouter.toast(txt)
		_reload()

## Pergaminho da Purificação: escolhe a carta a tirar do baralho (cancelar não gasta o pergaminho).
func _use_purge(index: int) -> void:
	ZoneViewer.open_deck(tr("PURIFICAÇÃO — escolhe a carta a remover"), func(card: CardInstance):
		if card.entry_index < 0 or GameState.deck.size() <= 6 or index >= GameState.consumables.size():
			return
		GameState.deck.remove_at(card.entry_index)
		GameState.remove_consumable_at(index)
		Stats.add("consumables_used")
		SceneRouter.toast(tr("%s removida do baralho.") % tr(card.data.name))
		_reload())

func _show_curses() -> void:
	var lines: Array[String] = []
	for id in GameState.endless_curses:
		var c := CardDB.get_endless_curse(id)
		lines.append("☠ %s — %s" % [tr(String(c.get("name", ""))), tr(String(c.get("text", "")))])
	ChoiceDialog.open(tr("MALDIÇÕES DO INFINITO"), "\n".join(PackedStringArray(lines)) + "\n\n" + tr("De %d em %d antes escolhes uma nova num Pacto (as piores pagam mais ouro). Juntam-se umas às outras.") % [GameState.ENDLESS_CURSE_EVERY, GameState.ENDLESS_CURSE_EVERY],
		[[tr("FECHAR"), null, true]], Color(0.9, 0.45, 0.6))

## 0.17.0 Pactos do Infinito (89): escolher 1 de 3 maldições (as piores pagam mais ouro). É obrigatório:
## a janela não fecha sem escolher e, se saíres para o menu, volta a abrir ao continuar.
func _show_pact() -> void:
	if GameState.pact_offer.is_empty():
		return
	while SceneRouter.has_overlay():   # depois do interlúdio e do «Entretanto…»
		await get_tree().process_frame
		if not is_inside_tree():
			return
	if GameState.pact_offer.is_empty():
		return
	PactPicker.open(func(id: String):
		var txt := GameState.accept_pact(id)
		GameState.save_run({}, "map")
		if txt != "":
			SceneRouter.toast("☠ " + txt, 2.8)
			Sfx.coin()
		_reload())

func _show_later() -> void:
	var lines: Array[String] = []
	for l in GameState.pending_later:
		var n := maxi(0, int(l.get("ante", 0)) - GameState.ante)
		var when := tr("no próximo ante") if n <= 1 else tr("daqui a %d antes") % n
		var head := tr(String(l.get("title", "")))
		lines.append("▶ %s%s — %s" % [(head + ": ") if head != "" else "", tr(String(l.get("text", ""))), when])
	ChoiceDialog.open(tr("PROMESSAS"), "\n".join(PackedStringArray(lines)), [[tr("FECHAR"), null, true]], Color(0.75, 0.7, 0.98))

## O que aconteceu entre antes: mostra uma vez e esquece.
func _show_later_notes() -> void:
	if GameState.later_notes.is_empty():
		return
	while SceneRouter.has_overlay():   # depois do interlúdio do ato
		await get_tree().process_frame
		if not is_inside_tree():
			return
	var body := "\n\n".join(PackedStringArray(GameState.later_notes))
	GameState.later_notes.clear()
	GameState.save_run({}, "map")
	ChoiceDialog.open(tr("ENTRETANTO…"), body, [[tr("CONTINUAR"), null, true]])

# --- 0.19.0 (secção 3): loot e economia no mapa ---

## 91: o prémio de um marco do Infinito, curto («+15 ouro, +3 talento, cosmético»).
static func milestone_prize(a: int) -> String:
	var m: Dictionary = GameState.ENDLESS_MILESTONES.get(a, {})
	var parts: Array[String] = []
	if int(m.get("gold", 0)) > 0:
		parts.append(TranslationServer.translate("+%d ouro") % int(m["gold"]))
	if int(m.get("talent", 0)) > 0:
		parts.append(TranslationServer.translate("+%d talento") % int(m["talent"]))
	if not (m.get("unlock", {}) as Dictionary).is_empty():
		parts.append(TranslationServer.translate("cosmético"))
	return ", ".join(PackedStringArray(parts))

## 71: as contas da previsão.
static func forecast_text(fc: Dictionary) -> String:
	var t := TranslationServer.translate("Tens %d") % int(fc["gold"])
	if int(fc["battle"]) > 0:
		t += " + " + TranslationServer.translate("batalha ~%d") % int(fc["battle"])
	if int(fc["loan"]) > 0:
		t += " − " + TranslationServer.translate("dívida %d") % int(fc["loan"])
	t += " + " + TranslationServer.translate("juros %d") % int(fc["interest"])
	return t + " = ~%d" % int(fc["total"])

func _show_forecast() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	var fc := Economy.next_shop_forecast()
	var body := forecast_text(fc) + "\n\n" + tr("A batalha conta como um Batedor que acabas com 2 turnos a sobrar (o Guarda dá +4, a Elite +6). Os juros: 1 ouro por cada 5 que levas para a loja (máx. %d).") % GameState.interest_cap()
	ChoiceDialog.open(tr("OURO NA PRÓXIMA LOJA"), body, [[tr("FECHAR"), null, true]], UiKit.COIN)

## 100: aceitar (ou largar) a regra difícil da batalha deste ante.
func _on_risk() -> void:
	if _busy or SceneRouter.has_overlay() or not Economy.risk_allowed():
		return
	Sfx.select()
	var offer := Economy.risk_offer(GameState.ante)
	var on := not Economy.risk_active().is_empty()
	var body := tr(String(offer.get("text", ""))) + "\n\n" + tr("Se venceres a batalha deste ante, ganhas +%d ouro. Vale para a batalha que escolheres a seguir (não para os bosses).") % int(offer.get("gold", 0))
	var d := ChoiceDialog.open(tr("RISCO A TROCO DE OURO"), body, [[tr("LARGAR O RISCO") if on else tr("ACEITAR"), "toggle", true], [tr("FECHAR"), null]], Color(1.0, 0.55, 0.4))
	var v = await d.chosen
	if v != "toggle" or not is_inside_tree():
		return
	Economy.set_risk(not on)
	if not on:
		Stats.add("risks_taken")
	_reload()

## 86: antes do boss final, o ouro que sobra pode virar vida ou pontos de talento.
func _final_trade() -> void:
	var g := GameState.gold
	var hp := int(g / Economy.FINAL_HP_COST)
	var tal := int(g / Economy.FINAL_TALENT_COST)
	var body := tr("Tens %d ouro e o boss final está à frente. Depois dele já não há loja (a não ser no Infinito).") % g
	var d := ChoiceDialog.open(tr("O OURO QUE SOBRA"), body, [
		[tr("+%d DE VIDA") % hp, "hp", true, hp > 0],
		[tr("+%d PONTOS DE TALENTO") % tal, "talent", false, tal > 0],
		[tr("GUARDAR O OURO"), "keep"]], UiKit.COIN)
	d.name = "FinalTrade"
	d.buttons_only = true   # A2: a troca é uma vez por run e a seguir vem o boss final
	var v = await d.chosen
	if not is_inside_tree():
		return
	var txt := Economy.final_trade(String(v) if v != null else "keep")
	if txt != "":
		Sfx.reward()
		SceneRouter.toast(txt, 2.4)
	GameState.save_run({}, "map")

## 75: escolher 1 de 3 cartas, ou saltar por ouro.
func _show_card_reward() -> void:
	if Economy.pending_card_reward().is_empty():
		return
	while SceneRouter.has_overlay():
		await get_tree().process_frame
		if not is_inside_tree():
			return
	if Economy.pending_card_reward().is_empty():
		return
	CardRewardPick.open(func(id: String):
		if id == "":
			var g := Economy.skip_card_reward()
			SceneRouter.toast(tr("Saltaste a carta: +%d ouro.") % g, 1.8)
		elif Economy.take_card_reward(id):
			SceneRouter.toast(tr("%s juntou-se ao baralho.") % tr(CardDB.get_card(id).name), 1.8)
		GameState.save_run({}, "map")
		_reload())

# --- 0.19.0 (173): bom sítio para parar ---

func _safe_stop_note() -> void:
	if GameState.map_phase != "stop" or not GameState.is_boss_ante(GameState.ante):
		return
	var key := "safe_%d" % GameState.ante
	if bool(GameState.run_log.get(key, false)):
		return
	GameState.run_log[key] = true
	SceneRouter.toast(tr("Bom sítio para parar: está tudo gravado, podes sair à vontade."), 3.2, false)

# --- 0.19.0 (122–125): o mapa diz mais ---

## 123: «Faltam 2 batalhas para o boss», com o retrato dele (na dica do fundo).
func _add_boss_path(row: HBoxContainer) -> void:
	if GameState.mode in ["tower", "rush"]:
		return
	var info := boss_path()
	if info.is_empty():
		return
	var sep := UiKit.label("·", 18, Color(UiKit.GOLD, 0.6))
	sep.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(sep)
	var art: Texture2D = info.get("art")
	if art != null:
		var med := Control.new()
		med.name = "BossFace"
		med.custom_minimum_size = Vector2(30, 30)
		med.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		med.mouse_filter = Control.MOUSE_FILTER_IGNORE
		med.draw.connect(func():
			var c := med.size * 0.5
			med.draw_circle(c, 15.0, Color(0.08, 0.06, 0.13))
			ArtLib.draw_round(med, art, c, 13.5)
			med.draw_arc(c, 14.5, 0.0, TAU, 32, Color(0.95, 0.4, 0.4), 1.6, true))
		row.add_child(med)
	var l := UiKit.label(String(info["text"]), 17, Color(1.0, 0.75, 0.7))
	l.name = "BossPath"
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(l)

## {"text", "battles", "boss_id", "art"} do próximo boss ({} sem boss à vista).
static func boss_path() -> Dictionary:
	var a := GameState.ante
	var first := a + (1 if GameState.map_phase == "stop" else 0)   # na paragem, a batalha deste ante já passou
	var ba := first
	while not GameState.is_boss_ante(ba) and ba < first + 12:
		ba += 1
	if not GameState.is_boss_ante(ba) or (GameState.max_ante > 0 and ba > GameState.max_ante and not GameState.endless):
		return {}
	var battles := ba - first
	var id := GameState.planned_enemy(ba)
	var def := CardDB.enemy_def(id)
	var nm := TranslationServer.translate(String(def.get("name", "")))
	var t := ""
	if battles <= 0:
		t = TranslationServer.translate("O boss é já a seguir: %s") % nm if nm != "" else TranslationServer.translate("O boss é já a seguir")
	elif battles == 1:
		t = TranslationServer.translate("Falta 1 batalha para o boss")
	else:
		t = TranslationServer.translate("Faltam %d batalhas para o boss") % battles
	var art_id := String(def.get("art", "")) if String(def.get("art", "")) != "" else id
	return {"text": t, "battles": maxi(0, battles), "boss_id": id, "art": ArtLib.texture("portrait", art_id) if id != "" else null}

## 125: o chip «A seguir: …» (só na escolha da batalha; o boss mostra-se sempre).
func next_enemy_chip() -> Control:
	if GameState.map_phase != "battle" or GameState.mode in ["tower", "rush"]:
		return null
	var id := GameState.planned_enemy(GameState.ante)
	if id == "":
		return null
	var def := CardDB.enemy_def(id)
	var known := Stats.is_seen("enemies", id) or bool(def.get("boss", false))
	var art_id := String(def.get("art", "")) if String(def.get("art", "")) != "" else id
	var chip: Control
	if known:
		chip = UiKit.info_chip("creature", tr("A seguir: %s") % tr(String(def.get("name", ""))), Color(0.95, 0.62, 0.55),
			_show_next_enemy.bind(id), 46, ArtLib.texture("portrait", art_id))
	else:
		chip = UiKit.info_chip("creature", tr("A seguir: ???"), Color(0.7, 0.68, 0.78), _show_next_enemy.bind(id))
	chip.name = "NextEnemy"
	return chip

static func next_enemy_text(id: String) -> String:
	var t := func(x: String) -> String: return TranslationServer.translate(x)
	var def := CardDB.enemy_def(id)
	if not Stats.is_seen("enemies", id) and not bool(def.get("boss", false)):
		return t.call("Ainda não o conheces: depois de o enfrentares, o mapa mostra quem é, a regra e a cor fraca.")
	var lines: Array[String] = []
	if String(def.get("text", "")) != "":
		lines.append(t.call(String(def.get("text", ""))))
	var wc := CardDB.weak_color_of({"id": id})
	if wc != "":
		lines.append(t.call("Ponto fraco: %s.") % t.call(String(CardZoom.COLOR_NAMES.get(wc, wc))))
	var danger := String(load("res://scenes/ui/Collection.gd").call("enemy_danger_text", def))
	if danger != "":
		lines.append(danger)
	lines.append(t.call("Na Guarda tem mais vida; na Elite, mais vida e ataque."))
	return "\n\n".join(PackedStringArray(lines))

func _show_next_enemy(id: String) -> void:
	var def := CardDB.enemy_def(id)
	var known := Stats.is_seen("enemies", id) or bool(def.get("boss", false))
	CardZoom.show_text(tr(String(def.get("name", ""))) if known else tr("Inimigo desconhecido"), next_enemy_text(id), tr("A seguir"), Color(0.95, 0.62, 0.55))

## 124: o que um nó dá e o risco (o mesmo texto do toque longo).
static func node_legend(kind: String, ante: int) -> String:
	var t := func(x: String) -> String: return TranslationServer.translate(x)
	var info: Array = NODE_INFO.get(kind, [kind, "", "relic"])
	var lines: Array[String] = [t.call(String(info[1]))]
	if kind == "elite" and ante > 0:
		lines[0] = t.call("+60 % de vida, +2 de ataque") + " · " + t.call("relíquia %s garantida") % t.call(String(ELITE_RARITY.get(Economy.elite_rarity(ante), "comum")))
	lines.append(t.call("Risco: %s.") % t.call(String(NODE_RISK.get(kind, "nenhum"))))
	if kind in ["scout", "guard", "elite", "ambush", "siege", "escape"] and ante == GameState.ante and GameState.map_phase == "battle":
		var id := GameState.planned_enemy(ante)
		if id != "" and Stats.is_seen("enemies", id):
			lines.append(t.call("Inimigo: %s.") % t.call(String(CardDB.enemy_def(id).get("name", ""))))
	if not GameState.node_seen(kind):
		lines.append(t.call("Nunca visitaste este nó."))
	return "\n\n".join(PackedStringArray(lines))

func _on_node_input(ev: InputEvent, b: Button, kind: String, ante: int) -> void:
	if ev is InputEventMouseButton and (ev as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
		if ev.pressed:
			_press_id += 1
			b.set_meta("press", _press_id)
			b.set_meta("press_pos", (ev as InputEventMouseButton).global_position)
			get_tree().create_timer(Settings.long_press_time()).timeout.connect(_node_long.bind(b, kind, ante, _press_id))
		else:
			b.set_meta("press", -1)
	elif ev is InputEventMouseMotion and b.has_meta("press") and int(b.get_meta("press")) > 0:
		if (ev as InputEventMouseMotion).global_position.distance_to(b.get_meta("press_pos", Vector2.ZERO)) > Settings.drag_px():
			b.set_meta("press", -1)

func _node_long(b: Button, kind: String, ante: int, id: int) -> void:
	if not is_instance_valid(b) or int(b.get_meta("press", -1)) != id or SceneRouter.has_overlay():
		return
	b.set_meta("press", -1)
	_long_at = Time.get_ticks_msec()
	open_legend(kind, ante)

func open_legend(kind: String, ante: int) -> void:
	var info: Array = NODE_INFO.get(kind, [kind, "", "relic"])
	Sfx.select()
	var col: Color = NODE_COLORS.get(kind, UiKit.GOLD)
	CardZoom.show_text(tr(String(info[0])), node_legend(kind, ante), tr("Ante %d") % ante if ante > 0 else "", col.lightened(0.45))

func _reload() -> void:
	GameState.save_run({}, "map")
	SceneRouter.go("map")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")

## 0.16.0 (77): enquanto escolhes o caminho, as ilustrações do baralho e o fundo do ato vão carregando noutra
## thread; a batalha apanha-as já prontas (sem soluços ao entrar nem ao comprar as primeiras cartas).
func _preload_battle_art(act: int) -> void:
	var items: Array = []
	var seen := {}
	for c in GameState.deck:
		var id := String(c.get("id", ""))
		if id != "" and not seen.has(id):
			seen[id] = true
			items.append([ArtLib.card_art_kind(id), id])   # 0.16.1: a miniatura (é a que a mão usa)
	items.append(["background", "act_E" if act >= 5 else "act_%d" % act])
	var clim := GameState.climate_for_ante(GameState.ante)
	if clim != "":
		items.append(["background", "clim_" + clim])
	ArtLib.preload_async(items)

