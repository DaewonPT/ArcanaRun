extends Control
## Mapa da run ("As Crónicas da Centelha"): mostra o ato atual (dois antes) como uma fila de nós
## com caminhos bifurcados. Em cada ante há uma batalha (Batedor ou Guarda; boss nos antes
## múltiplos de 4) e depois uma paragem (Loja ou outra). Toca no nó para seguir; os nós já
## percorridos ficam marcados e os futuros veem-se, para planear. A run está gravada aqui.

const NODE_INFO := {
	"scout": ["Batedor", "Inimigo normal · ouro normal", "creature"],
	"guard": ["Guarda", "+25 % de vida · +4 ouro", "shield"],
	"elite": ["Elite", "+60 % de vida, +2 de ataque · relíquia garantida", "skull"],
	"nemesis": ["Némesis", "O teu rival volta mais forte · recompensa especial", "burst"],
	"boss": ["Boss", "Regra especial · recompensa de boss", "crown"],
	"shop": ["Loja", "Cartas, relíquias, serviços, juros", "shop"],
	"event": ["Evento", "Uma escolha com consequências", "sorcery"],
	"rest": ["Acampamento", "Curar, treinar, meditar ou forjar uma carta +", "campfire"],
	"spring": ["Fonte de Mana", "Muda a cor de até 3 cartas", "mana"],
	"altar": ["Altar Profano", "Sacrifica uma carta, funde a habilidade", "exile"],
	"merchant": ["Mercador Cego", "Relíquias lendárias e patronos", "relic"],
	"contracts": ["Quadro de Contratos", "Aceita um desafio para a próxima batalha", "contract"],
	"tribunal": ["Tribunal dos Deuses", "Aposta ouro ou vida na roda", "wheel"],
	"treasure": ["Tesouro", "Abre um de três baús", "chest"],
	"sanctuary": ["Santuário", "Uma bênção para a run — com um preço", "heart"],
	"arena": ["Arena", "Batalha extra de 3 turnos · relíquia e ouro", "first_strike"],
	"forge": ["Forja das Edições", "Dá uma edição a uma carta (Brilhante, Holográfica…)", "anvil"],
	"library": ["Biblioteca", "Estuda: uma carta rara, um pergaminho ou limpa o baralho", "book"],
	"vault": ["Cofre", "Guarda ouro agora e recebe mais daqui a uns antes", "chest"],
}
const NODE_COLORS := {
	"scout": Color(0.55, 0.35, 0.3), "guard": Color(0.65, 0.3, 0.3), "elite": Color(0.55, 0.2, 0.42), "boss": Color(0.6, 0.45, 0.15),
	"nemesis": Color(0.42, 0.12, 0.22),
	"shop": Color(0.3, 0.4, 0.6), "event": Color(0.45, 0.35, 0.6), "rest": Color(0.3, 0.5, 0.35),
	"spring": Color(0.25, 0.5, 0.6), "altar": Color(0.4, 0.3, 0.45), "merchant": Color(0.55, 0.45, 0.2),
	"contracts": Color(0.5, 0.4, 0.22), "tribunal": Color(0.52, 0.28, 0.5),
	"treasure": Color(0.6, 0.48, 0.18), "sanctuary": Color(0.32, 0.45, 0.62), "arena": Color(0.62, 0.25, 0.2),
	"forge": Color(0.62, 0.36, 0.2), "library": Color(0.28, 0.42, 0.56), "vault": Color(0.5, 0.44, 0.24),
}

var _columns: Array = []     # [{"ante", "phase", "state", "nodes": {kind: Control}, "buttons": {kind: Button}}]
var _lines: Control
var _busy := false
# 0.13.0 — mapa vivo: caminhos para os nós de agora a correr, brilho a pulsar nos nós e névoa/pirilampos.
var _t := 0.0
var _acc := 0.0
# 0.13.0 — mapa ilustrado (a opção C que o Paulo escolheu): o fundo do ato, os nós em medalhões ao longo de
# um caminho que serpenteia; as escolhas de agora em grande e a brilhar, o que já passou pequeno e apagado
# (✓ na escolha feita) e o que vem a seguir em tamanho médio, para planear.
const MED_CURRENT := 100.0
const MED_FUTURE := 64.0
const MED_FUTURE_BIG := 80.0    # boss, Elite e Némesis que vêm a seguir
const MED_PAST := 54.0
const LABEL_W := 214.0
const COLUMN_WAVE := [0.05, -0.07, 0.06, -0.05, 0.04]
var _board: Control
var _end_node: Control
var _fog_front: Control   # 0.16.1 (68): névoa por cima do fim do ato (o ato seguinte ainda escondido)
var _reveal := 1.0        # 0.16.1 (68): o caminho desenha-se da esquerda para a direita (0 → 1) ao entrar
var _clip_x := INF
var _captions: Array = []    # legendas "Ante N · batalha" por cima de cada coluna

func _ready() -> void:
	GameState.save_run({}, "map")
	var backdrop := MapBackdrop.new()
	backdrop.name = "MapBackdrop"
	backdrop.act = GameState.act_of_ante(GameState.ante)
	backdrop.art = ArtLib.texture("background", "act_E" if backdrop.act >= 5 else "act_%d" % backdrop.act)
	Stats.mark_seen("places", "act_E" if backdrop.act >= 5 else "act_%d" % backdrop.act)   # 0.16.1: Galeria
	add_child(backdrop)
	move_child(backdrop, mini(1, get_child_count() - 1))   # por cima do fundo, por trás de tudo o resto
	_preload_battle_art.call_deferred(backdrop.act)
	set_process(Settings.motion_ok())
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	# Cabeçalho: menu, título do ato, estado da run.
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var menu := UiKit.button(tr("MENU"), 48, 18)
	menu.custom_minimum_size.x = 132
	UiKit.button_icon(menu, "menu", Color.WHITE, 20.0, false)   # 0.16.0 (V59): a casa em vez do ◀
	menu.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(menu)
	# 0.13.0: ver o baralho (com a curva de mana) a partir do mapa.
	var deck_btn := UiKit.button(tr("VER BARALHO (%d)") % GameState.deck.size(), 48, 17)
	deck_btn.name = "DeckBtn"
	deck_btn.custom_minimum_size.x = 220
	UiKit.button_icon(deck_btn, "cards", Color(0.88, 0.85, 0.96), 20.0, false)
	deck_btn.pressed.connect(func(): Sfx.select(); ZoneViewer.open_deck(tr("O TEU BARALHO")))
	header.add_child(deck_btn)
	var act := GameState.act_of_ante(GameState.ante)
	var subtitle := GameState.mode_title() if GameState.mode_title() != "" else tr("As Crónicas da Centelha")
	var title := UiKit.label(tr("ATO %s") % GameState.act_name() + "  ·  " + subtitle, 26, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	title.clip_text = true
	header.add_child(title)
	var acts := HBoxContainer.new()
	acts.add_theme_constant_override("separation", 6)
	header.add_child(acts)
	for i in GameState.ACT_NAMES.size():
		var chip := UiKit.label(GameState.ACT_NAMES[i], 16, UiKit.GOLD if i + 1 == act else (Color(0.5, 0.5, 0.6) if i + 1 > act else Color(0.75, 0.7, 0.55)))
		chip.custom_minimum_size = Vector2(34, 30)
		chip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		chip.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		acts.add_child(chip)
	# 0.16.1 (V58): a vida, o ouro e as relíquias com os ícones do jogo (coração, moeda, relíquia).
	var status_row := HBoxContainer.new()
	status_row.name = "Status"
	status_row.add_theme_constant_override("separation", 18)
	vbox.add_child(status_row)
	status_row.add_child(UiKit.label("%s  ·  %s" % [tr(String(GameState.deck_def.get("name", ""))), tr("Ante %d") % GameState.ante], 17, UiKit.TEXT_DIM))
	var hp_box := UiKit.icon_text("heart", "%d/%d" % [GameState.player_hp, GameState.player_max_hp], 17, Color.WHITE, Color(0.94, 0.32, 0.37))
	hp_box.name = "Hp"
	status_row.add_child(hp_box)
	var gold_box := UiKit.icon_text("coin", str(GameState.gold), 17, Color(1.0, 0.86, 0.45), UiKit.COIN)
	gold_box.name = "Gold"
	status_row.add_child(gold_box)
	var relic_box := UiKit.icon_text("relic", "%d/%d" % [GameState.relic_ids.size(), GameState.max_relics()], 17, Color.WHITE, Color(0.78, 0.62, 1.0))
	relic_box.name = "Relics"
	status_row.add_child(relic_box)
	var status_parts: Array[String] = []
	if GameState.stake > 1:
		status_parts.append(tr("Selo %d") % GameState.stake)
	if GameState.endless:
		status_parts.append(tr("Modo infinito"))
		var nm := GameState.next_endless_milestone()
		if nm > 0:
			status_parts.append(tr("Próximo marco: ante %d") % nm)
	if not GameState.boss_relics.is_empty():
		status_parts.append(tr("de boss: %d") % GameState.boss_relics.size())
	if not status_parts.is_empty():
		var status := UiKit.label("  ·  ".join(PackedStringArray(status_parts)), 17, UiKit.TEXT_DIM)
		status.clip_text = true
		status.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		status_row.add_child(status)
	_build_chips(vbox)

	# Mapa ilustrado: o caminho por trás (_lines) e os medalhões por cima, postos no sítio por _layout_board.
	_board = Control.new()
	_board.name = "Board"
	_board.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_board.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(_board)
	_lines = Control.new()
	_lines.set_anchors_preset(Control.PRESET_FULL_RECT)
	_lines.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_lines.draw.connect(_draw_lines)
	_board.add_child(_lines)
	var antes: Array[int] = []
	if act < 5:
		var first_ante := (act - 1) * 2 + 1
		antes.append(first_ante)
		antes.append(first_ante + 1)
	else:
		antes.append(GameState.ante)
	for a in antes:
		var opts := GameState.map_options(a)
		_column(a, "battle", opts["battle"])
		_column(a, "stop", opts["stop"])
	# O fim do ato (ou o ante seguinte, no Infinito).
	var end_txt := tr("Ato %s") % GameState.ACT_NAMES[min(act, 4)] if act < 5 else tr("Ante %d") % (GameState.ante + 1)
	_end_node = _node_widget("", "future", false, 0, end_txt, "", "flag", Color(0.19, 0.16, 0.28), MED_PAST - 4.0)
	_end_node.name = "EndNode"
	_board.add_child(_end_node)
	_fog_front = Control.new()
	_fog_front.name = "FogFront"
	_fog_front.set_anchors_preset(Control.PRESET_FULL_RECT)
	_fog_front.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fog_front.draw.connect(_draw_fog_front)
	_board.add_child(_fog_front)
	_board.resized.connect(_layout_board)

	var hint_txt := tr("Escolhe a batalha do ante %d.") % GameState.ante if GameState.map_phase == "battle" else tr("Ante %d vencido! Escolhe onde parar antes do próximo.") % GameState.ante
	var hint_box := PanelContainer.new()
	hint_box.name = "Hint"
	hint_box.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	hint_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hint_box.add_theme_stylebox_override("panel", UiKit.flat(Color(0.08, 0.06, 0.12, 0.82), 12, Color(UiKit.GOLD, 0.5), 1, 10))
	var hint := UiKit.label(hint_txt, 18, UiKit.GOLD)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint_box.add_child(hint)
	vbox.add_child(hint_box)
	await get_tree().process_frame
	_layout_board()
	_start_reveal()
	# Ato novo: interlúdio com o nome do ato, a história e o clima (uma vez por ato).
	if GameState.map_phase == "battle":
		ActInterlude.open_if_new()
	# 0.13.0: o que aconteceu entre antes (consequências de eventos, maldição nova do Infinito).
	_show_later_notes()

## Clima do ato (e o do próximo, na última paragem do ato) e o contrato ativo; tocar explica.
func _build_chips(parent: Control) -> void:
	var chips := HBoxContainer.new()
	chips.add_theme_constant_override("separation", 10)
	var climate := GameState.climate_for_ante(GameState.ante)
	if climate != "":
		chips.add_child(UiKit.info_chip("climate", tr("Clima: %s") % tr(String(CardDB.get_climate(climate).get("name", ""))), Color(0.35, 0.8, 0.85),
			func(): CardZoom.show_climate(climate)))
	if GameState.map_phase == "stop" and GameState.climate_key(GameState.ante + 1) != GameState.climate_key(GameState.ante):
		var next := GameState.climate_for_ante(GameState.ante + 1)
		if next != "":
			chips.add_child(UiKit.info_chip("climate", tr("A seguir: %s") % tr(String(CardDB.get_climate(next).get("name", ""))), Color(0.55, 0.65, 0.75),
				func(): CardZoom.show_climate(next)))
	if not GameState.contract.is_empty():
		var con: Dictionary = GameState.contract
		chips.add_child(UiKit.info_chip("contract", tr("Contrato: %s") % tr(String(con.get("name", ""))), UiKit.GOLD,
			func(): CardZoom.show_contract(con)))
	# 0.13.0: poções e pergaminhos (tocar: usar no mapa ou deitar fora), maldições do Infinito, promessas.
	for i in GameState.consumables.size():
		var def := CardDB.get_consumable(GameState.consumables[i])
		var chip := UiKit.info_chip(String(def.get("kind", "potion")), tr(String(def.get("name", ""))), Color(String(def.get("color", "#ffffff"))),
			_on_item.bind(i), 46, ArtLib.texture("item", String(GameState.consumables[i])))   # V58: com a ilustração
		chip.name = "ItemChip%d" % i
		chips.add_child(chip)
	if not GameState.endless_curses.is_empty():
		chips.add_child(UiKit.info_chip("curse", tr("Maldições: %d") % GameState.endless_curses.size(), Color(0.9, 0.45, 0.6), _show_curses))
	if not GameState.pending_later.is_empty():
		chips.add_child(UiKit.info_chip("wheel", tr("Promessas: %d") % GameState.pending_later.size(), Color(0.75, 0.7, 0.98), _show_later))
	if chips.get_child_count() > 0:
		parent.add_child(chips)
	else:
		chips.free()

## Uma coluna de nós (as opções de uma fase de um ante): um medalhão por opção.
func _column(a: int, phase: String, kinds: Array) -> Dictionary:
	var state := _state_of(a, phase)
	var chosen := GameState.map_chosen(a, phase)
	var entry := {"ante": a, "phase": phase, "state": state, "nodes": {}, "buttons": {}}
	for kind in kinds:
		var k := String(kind)
		var node := _node_widget(k, state, chosen == k or (state == "past" and kinds.size() == 1), a)
		_board.add_child(node)
		var b: Button = node.get_meta("button")
		if state == "current":
			b.pressed.connect(_on_pick.bind(a, phase, k))
		entry["nodes"][k] = node
		entry["buttons"][k] = b
	var cap := UiKit.label(tr("Ante %d") % a + "  ·  " + (tr("batalha") if phase == "battle" else tr("paragem")), 13, Color(UiKit.TEXT_DIM, 0.75))
	cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	cap.custom_minimum_size.x = LABEL_W
	cap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cap.add_theme_constant_override("outline_size", 5)
	cap.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.7))
	_board.add_child(cap)
	_captions.append(cap)
	_columns.append(entry)
	return entry

## "past" (já passou), "current" (é a escolha de agora) ou "future".
func _state_of(a: int, phase: String) -> String:
	if a < GameState.ante:
		return "past"
	if a > GameState.ante:
		return "future"
	if phase == GameState.map_phase:
		return "current"
	return "past" if phase == "battle" else "future"

## Diâmetro do medalhão de um nó.
func _med_size(kind: String, state: String, chosen: bool) -> float:
	match state:
		"current":
			return MED_CURRENT
		"past":
			return MED_PAST if chosen else MED_PAST - 8.0
	return MED_FUTURE_BIG if kind in ["boss", "elite", "nemesis"] else MED_FUTURE

## Um nó do mapa: o medalhão (botão redondo com o ícone) e, por baixo, o nome e o que tem.
## Devolve o contentor; o botão fica na meta "button".
func _node_widget(kind: String, state: String, chosen: bool, ante: int = 0, title_override: String = "", desc_override: String = "",
		icon_override: String = "", color_override: Color = Color(0, 0, 0, 0), size_override: float = 0.0) -> Control:
	var info: Array = NODE_INFO.get(kind, [kind, "", "relic"])
	var color: Color = color_override if color_override.a > 0.0 else NODE_COLORS.get(kind, UiKit.BG_LIGHT)
	var d := size_override if size_override > 0.0 else _med_size(kind, state, chosen)
	var box := VBoxContainer.new()
	box.name = "Node_" + (kind if kind != "" else "end")
	box.add_theme_constant_override("separation", 4)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var b := Button.new()
	b.custom_minimum_size = Vector2(d, d)
	b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	b.focus_mode = Control.FOCUS_NONE
	var bg := color if state == "current" else (color.darkened(0.25) if state == "future" else color.darkened(0.45))
	var border := UiKit.GOLD if state == "current" else (Color(0.6, 0.85, 0.6) if chosen else Color(1, 1, 1, 0.35))
	var style := UiKit.flat(bg, int(d / 2.0), border, 3 if (state == "current" or chosen) else 2, 0)
	style.shadow_color = Color(0, 0, 0, 0.5)
	style.shadow_size = 8
	style.shadow_offset = Vector2(0, 4)
	b.add_theme_stylebox_override("normal", style)
	b.add_theme_stylebox_override("hover", style)
	var pressed_style := style.duplicate() as StyleBoxFlat
	pressed_style.bg_color = bg.lightened(0.15)
	b.add_theme_stylebox_override("pressed", pressed_style)
	b.add_theme_stylebox_override("disabled", style)
	b.disabled = state != "current"
	if state == "current":
		b.set_meta("haptic", true)   # 0.16.0 (V60): escolher o caminho vibra um instante
	# 0.13.0: ilustração do medalhão (tools/art_sheets.json, parte dos ícones do mapa); sem ela, o ícone desenhado.
	var art_id := kind if kind != "" else "act_end"
	var art_tex: Texture2D = ArtLib.texture("mapnode", art_id)
	if art_tex != null:
		var art := Control.new()
		art.name = "NodeArt"
		art.set_anchors_preset(Control.PRESET_FULL_RECT)
		art.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var inset := 3.0 if (state == "current" or chosen) else 2.0
		art.draw.connect(func(): ArtLib.draw_round(art, art_tex, art.size / 2.0, minf(art.size.x, art.size.y) / 2.0 - inset))
		if state == "past":
			art.modulate = Color(0.75, 0.75, 0.8)
		b.add_child(art)
	else:
		var center := CenterContainer.new()
		center.set_anchors_preset(Control.PRESET_FULL_RECT)
		center.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_child(center)
		var icon := CardIcon.new(icon_override if icon_override != "" else String(info[2]), Color.WHITE if state != "past" else Color(0.82, 0.82, 0.86), d * 0.42)
		icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
		center.add_child(icon)
	box.add_child(b)
	var title_txt := title_override if title_override != "" else tr(String(info[0]))
	var desc_txt := desc_override if title_override != "" else tr(String(info[1]))
	if kind == "nemesis":
		var nd := GameState.nemesis_def()
		title_txt = tr(String(nd.get("name", "Némesis")))
		desc_txt = tr("Némesis · nível %d · recompensa especial") % maxi(1, GameState.nemesis_level(ante))
	var t := UiKit.label(("✓ " if chosen and state == "past" else "") + title_txt, 19 if state == "current" else 15,
		Color.WHITE if state != "past" else Color(0.82, 0.82, 0.86))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.custom_minimum_size.x = LABEL_W
	t.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	t.add_theme_constant_override("outline_size", 6)
	t.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	box.add_child(t)
	if desc_txt != "" and state != "past":
		var dl := UiKit.label(desc_txt, 13 if state == "current" else 12, Color(0.9, 0.9, 0.95) if state == "current" else Color(0.75, 0.75, 0.82), true)
		dl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		dl.custom_minimum_size.x = LABEL_W
		dl.max_lines_visible = 2
		dl.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		dl.custom_minimum_size.y = 34 if state == "current" else 31   # com reticências o mínimo seria 1 px
		dl.add_theme_constant_override("line_spacing", 0)
		dl.add_theme_constant_override("outline_size", 5)
		dl.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
		box.add_child(dl)
	if state == "past" and not chosen:
		b.modulate.a = 0.45
		box.modulate.a = 0.7
	box.set_meta("button", b)
	box.set_meta("diameter", d)
	box.set_meta("chosen", chosen)
	return box

## Põe os medalhões no sítio: colunas espalhadas da esquerda para a direita, cada uma a subir ou a descer
## um pouco (o caminho serpenteia), e as opções de cada coluna umas por baixo das outras.
func _layout_board() -> void:
	if _board == null or not is_instance_valid(_board):
		return
	var w := _board.size.x
	var h := _board.size.y
	if w < 10.0 or h < 10.0:
		return
	var n := _columns.size()
	var left := 120.0
	var end_x := w - 70.0
	var step := (end_x - left) / float(maxi(1, n))
	var cap_h := 18.0
	for i in n:
		var e: Dictionary = _columns[i]
		var x := left + step * i
		var nodes: Array = (e["nodes"] as Dictionary).values()
		var m := nodes.size()
		var node_h := 0.0
		for nd in nodes:
			node_h = maxf(node_h, (nd as Control).get_combined_minimum_size().y)
		var avail := h - cap_h - 6.0
		var spacing := 0.0 if m <= 1 else minf(200.0, maxf(node_h + 6.0, (avail - node_h) / float(m - 1)))
		spacing = minf(spacing, (avail - node_h) / float(maxi(1, m - 1))) if m > 1 else 0.0
		var span := spacing * float(m - 1) + node_h
		var yc := h * (0.52 + float(COLUMN_WAVE[i % COLUMN_WAVE.size()]))
		var top := clampf(yc - span / 2.0, cap_h + 4.0, maxf(cap_h + 4.0, h - span - 2.0))
		for k in m:
			var nd := nodes[k] as Control
			var sz := nd.get_combined_minimum_size()
			nd.size = sz
			nd.position = Vector2(x - sz.x / 2.0, top + spacing * k)
		var cap := _captions[i] as Control
		cap.size = cap.get_combined_minimum_size()
		cap.position = Vector2(x - cap.size.x / 2.0, 0.0)
	if _end_node != null:
		var sz := _end_node.get_combined_minimum_size()
		_end_node.size = sz
		_end_node.position = Vector2(end_x - sz.x / 2.0, h * 0.52 - float(_end_node.get_meta("diameter", 50.0)) / 2.0)
	_lines.queue_redraw()
	if _fog_front != null:
		_fog_front.queue_redraw()

## Centro do medalhão de um nó (nas coordenadas do caminho).
func _med_center(node: Control) -> Vector2:
	var b := node.get_meta("button") as Control
	return b.global_position + b.size / 2.0 - _lines.global_position

func _process(delta: float) -> void:
	_t += delta
	_acc += delta
	if _acc >= 1.0 / 20.0 and _lines != null:   # 0.16.0 (74): 20 redesenhos por segundo chegam (eram 30)
		_acc = 0.0
		_lines.queue_redraw()
		if _fog_front != null:
			_fog_front.queue_redraw()

## 0.16.1 (68): ao entrar, o caminho desenha-se da esquerda para a direita (~1 s) e os medalhões que vêm
## a seguir acendem-se quando ele lá chega. Sem movimento (ou nos testes): tudo já desenhado.
func _start_reveal() -> void:
	if not Settings.motion_ok() or DisplayServer.get_name() == "headless" or _board == null:
		_set_reveal(1.0)
		return
	_set_reveal(0.0)
	var tw := create_tween()
	tw.tween_method(_set_reveal, 0.0, 1.0, Settings.dur(1.1)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_SINE)

func _set_reveal(v: float) -> void:
	_reveal = v
	if _board == null or not is_instance_valid(_board):
		return
	_clip_x = INF if v >= 1.0 else lerpf(0.0, _board.size.x + 40.0, v)
	for col in _columns:
		var future := String(col["state"]) == "future"
		for nd in (col["nodes"] as Dictionary).values():
			_fade_by_reveal(nd as Control, future)
	if _end_node != null:
		_fade_by_reveal(_end_node, true)
	_lines.queue_redraw()

func _fade_by_reveal(nd: Control, future: bool) -> void:
	if not future or _clip_x == INF:
		nd.modulate.a = 1.0
		return
	var cx := nd.position.x + nd.size.x * 0.5
	nd.modulate.a = clampf(0.15 + (_clip_x - cx + 40.0) / 80.0, 0.15, 1.0)

## 0.16.1 (68): o ato seguinte fica na névoa — nuvens suaves por cima do fim do ato, a deslizar devagar.
func _draw_fog_front() -> void:
	if _end_node == null or not is_instance_valid(_end_node) or _end_node.size.x <= 0.0:
		return
	var e := _med_center(_end_node)
	var tex := MenuBackdrop.glow_texture()
	var veil := Color(0.62, 0.58, 0.74)
	for i in 6:
		var ph := float(i) * 1.7
		var dx := 26.0 * sin(_t * 0.25 + ph) + (float(i % 3) - 1.0) * 44.0
		var dy := 14.0 * cos(_t * 0.2 + ph) + (floorf(i / 3.0) - 0.5) * 70.0
		var r := 70.0 + 18.0 * float(i % 2)
		_fog_front.draw_texture_rect(tex, Rect2(e + Vector2(dx, dy) - Vector2(r * 1.3, r), Vector2(r * 2.6, r * 2.0)), false, Color(veil, 0.22))

func _draw_lines() -> void:
	if _columns.is_empty():
		return
	var moving := Settings.motion_ok()
	var offset := _t * 42.0 if moving else 0.0
	# Entrada do ato (da esquerda) e saída para o fim do ato.
	for nd in (_columns[0]["nodes"] as Dictionary).values():
		var c := _med_center(nd as Control)
		_curve(Vector2(-30.0, c.y), c - Vector2(float((nd as Control).get_meta("diameter", 50.0)) / 2.0, 0.0), Color(1, 1, 1, 0.22), false, 0.0)
	for i in range(_columns.size() - 1):
		var from_state := String(_columns[i]["state"])
		var to_state := String(_columns[i + 1]["state"])
		for fn in (_columns[i]["nodes"] as Dictionary).values():
			for tn in (_columns[i + 1]["nodes"] as Dictionary).values():
				var a := _med_center(fn as Control)
				var b := _med_center(tn as Control)
				var ra := float((fn as Control).get_meta("diameter", 50.0)) / 2.0
				var rb := float((tn as Control).get_meta("diameter", 50.0)) / 2.0
				var from_chosen := bool((fn as Control).get_meta("chosen", false))
				var to_chosen := bool((tn as Control).get_meta("chosen", false))
				var p1 := a + Vector2(ra, 0)
				var p2 := b - Vector2(rb, 0)
				if to_state == "current":
					if from_state != "past" or from_chosen:
						_curve(p1, p2, Color(UiKit.GOLD, 0.9), true, offset)   # o caminho de agora corre
				elif from_state == "past":
					if from_chosen and to_chosen:
						_curve(p1, p2, Color(0.6, 0.9, 0.65, 0.55), false, 0.0)   # o caminho que fizeste
				elif from_state == "current":
					_curve(p1, p2, Color(1, 1, 1, 0.26), false, 0.0)   # para onde podes ir a seguir
				else:
					_curve(p1, p2, Color(1, 1, 1, 0.09), false, 0.0)   # mais à frente
	if _end_node != null:
		var e := _med_center(_end_node)
		var re := float(_end_node.get_meta("diameter", 50.0)) / 2.0
		for nd in (_columns[_columns.size() - 1]["nodes"] as Dictionary).values():
			var c := _med_center(nd as Control)
			_curve(c + Vector2(float((nd as Control).get_meta("diameter", 50.0)) / 2.0, 0.0), e - Vector2(re, 0), Color(1, 1, 1, 0.22), false, 0.0)
	# Brilho a pulsar à volta dos medalhões que podes escolher agora.
	var pulse := 0.5 + 0.5 * sin(_t * 3.0) if moving else 0.6
	for col in _columns:
		if String(col["state"]) != "current":
			continue
		for nd in (col["nodes"] as Dictionary).values():
			var c := _med_center(nd as Control)
			var r := float((nd as Control).get_meta("diameter", 50.0)) / 2.0
			_lines.draw_circle(c, r + 12.0 + 6.0 * pulse, Color(UiKit.GOLD, 0.08 + 0.07 * pulse))
			_lines.draw_circle(c, r + 5.0, Color(UiKit.GOLD, 0.22 + 0.12 * pulse))

## Curva suave (tangentes horizontais) de a para b: tracejada e a andar (o caminho de agora) ou em pontinhos.
func _curve(a: Vector2, b: Vector2, col: Color, dashed: bool, offset: float) -> void:
	var dx := (b.x - a.x) * 0.5
	var pts := PackedVector2Array()
	var segs := 28
	for i in segs + 1:
		var t := float(i) / float(segs)
		var u := 1.0 - t
		pts.append(a * (u * u * u) + (a + Vector2(dx, 0)) * (3.0 * u * u * t) + (b - Vector2(dx, 0)) * (3.0 * u * t * t) + b * (t * t * t))
	var dash := 10.0 if dashed else 2.5
	var gap := 9.0 if dashed else 8.0
	var period := dash + gap
	var walked := 0.0
	var width := 3.5 if dashed else 2.6
	for i in pts.size() - 1:
		var p := pts[i]
		var q := pts[i + 1]
		var seg := p.distance_to(q)
		if seg < 0.01:
			continue
		var s0 := 0.0
		while s0 < seg:
			var phase := fposmod(walked + s0 - offset, period)
			var run := (dash - phase) if phase < dash else (period - phase)
			var s1 := minf(seg, s0 + maxf(0.5, run))
			if phase < dash:
				var d0 := p.lerp(q, s0 / seg)
				var d1 := p.lerp(q, s1 / seg)
				if d0.x <= _clip_x:   # 68: o caminho ainda a desenhar-se
					if d1.x > _clip_x and absf(d1.x - d0.x) > 0.01:
						d1 = d0.lerp(d1, (_clip_x - d0.x) / (d1.x - d0.x))
					_lines.draw_line(d0, d1, col, width, true)
			s0 = s1
		walked += seg

func _on_pick(a: int, phase: String, kind: String) -> void:
	if _busy or a != GameState.ante or phase != GameState.map_phase:
		return
	_busy = true
	Sfx.boom()
	if phase == "battle":
		GameState.choose_battle(kind)
		GameState.save_run({}, "battle")
		SceneRouter.go("battle")
	else:
		GameState.choose_stop(kind)
		var scene := GameState.stop_scene(kind)
		GameState.save_run({}, scene)
		SceneRouter.go(scene)

# --- 0.13.0: poções e pergaminhos, maldições do Infinito, promessas dos eventos ---

## Tocar numa poção/pergaminho no mapa: as do mapa usam-se aqui; todas se podem deitar fora.
func _on_item(index: int) -> void:
	if _busy or SceneRouter.has_overlay() or index >= GameState.consumables.size():
		return
	Sfx.select()
	var id := GameState.consumables[index]
	var def := CardDB.get_consumable(id)
	var use := String(def.get("use", "battle"))
	var body := tr(String(def.get("text", "")))
	var buttons: Array = []
	if use == "battle":
		body += "\n\n" + tr("Usa-se nas batalhas: toca nele na barra de cima.")
	else:
		var eff: Dictionary = def.get("effect", {})
		var ok := not (eff.has("heal") and GameState.player_hp >= GameState.player_max_hp) and not (eff.has("remove_card") and GameState.deck.size() <= 6)
		buttons.append([tr("USAR"), "use", true, ok])
	buttons.append([tr("DEITAR FORA"), "drop"])
	buttons.append([tr("FECHAR"), null])
	var d := ChoiceDialog.open(tr(String(def.get("name", id))), body, buttons, Color(String(def.get("color", "#ffd25a"))))
	var v = await d.chosen
	if not is_inside_tree() or index >= GameState.consumables.size() or GameState.consumables[index] != id:
		return
	if v == "drop":
		GameState.remove_consumable_at(index)
		_reload()
	elif v == "use":
		if (def.get("effect", {}) as Dictionary).has("remove_card"):
			_use_purge(index)
			return
		var txt := GameState.use_consumable_outside(index)
		if txt != "":
			SceneRouter.toast(txt)
		_reload()

## Pergaminho da Purificação: escolhe a carta a tirar do baralho (cancelar não gasta o pergaminho).
func _use_purge(index: int) -> void:
	ZoneViewer.open_deck(tr("PURIFICAÇÃO — escolhe a carta a remover"), func(card: CardInstance):
		if card.entry_index < 0 or GameState.deck.size() <= 6 or index >= GameState.consumables.size():
			return
		GameState.deck.remove_at(card.entry_index)
		GameState.remove_consumable_at(index)
		Stats.add("consumables_used")
		SceneRouter.toast(tr("%s removida do baralho.") % tr(card.data.name))
		_reload())

func _show_curses() -> void:
	var lines: Array[String] = []
	for id in GameState.endless_curses:
		var c := CardDB.get_endless_curse(id)
		lines.append("☠ %s — %s" % [tr(String(c.get("name", ""))), tr(String(c.get("text", "")))])
	ChoiceDialog.open(tr("MALDIÇÕES DO INFINITO"), "\n".join(PackedStringArray(lines)) + "\n\n" + tr("Chega uma nova a cada %d antes. Juntam-se umas às outras.") % GameState.ENDLESS_CURSE_EVERY,
		[[tr("FECHAR"), null, true]], Color(0.9, 0.45, 0.6))

func _show_later() -> void:
	var lines: Array[String] = []
	for l in GameState.pending_later:
		var n := maxi(0, int(l.get("ante", 0)) - GameState.ante)
		var when := tr("no próximo ante") if n <= 1 else tr("daqui a %d antes") % n
		var head := tr(String(l.get("title", "")))
		lines.append("▶ %s%s — %s" % [(head + ": ") if head != "" else "", tr(String(l.get("text", ""))), when])
	ChoiceDialog.open(tr("PROMESSAS"), "\n".join(PackedStringArray(lines)), [[tr("FECHAR"), null, true]], Color(0.75, 0.7, 0.98))

## O que aconteceu entre antes: mostra uma vez e esquece.
func _show_later_notes() -> void:
	if GameState.later_notes.is_empty():
		return
	while SceneRouter.has_overlay():   # depois do interlúdio do ato
		await get_tree().process_frame
		if not is_inside_tree():
			return
	var body := "\n\n".join(PackedStringArray(GameState.later_notes))
	GameState.later_notes.clear()
	GameState.save_run({}, "map")
	ChoiceDialog.open(tr("ENTRETANTO…"), body, [[tr("CONTINUAR"), null, true]])

func _reload() -> void:
	GameState.save_run({}, "map")
	SceneRouter.go("map")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")

## 0.16.0 (77): enquanto escolhes o caminho, as ilustrações do baralho e o fundo do ato vão carregando noutra
## thread; a batalha apanha-as já prontas (sem soluços ao entrar nem ao comprar as primeiras cartas).
func _preload_battle_art(act: int) -> void:
	var items: Array = []
	var seen := {}
	for c in GameState.deck:
		var id := String(c.get("id", ""))
		if id != "" and not seen.has(id):
			seen[id] = true
			items.append([ArtLib.card_art_kind(id), id])   # 0.16.1: a miniatura (é a que a mão usa)
	items.append(["background", "act_E" if act >= 5 else "act_%d" % act])
	var clim := GameState.climate_for_ante(GameState.ante)
	if clim != "":
		items.append(["background", "clim_" + clim])
	ArtLib.preload_async(items)

