extends Control
## Mapa da run ("As Crónicas da Centelha"): mostra o ato atual (dois antes) como uma fila de nós
## com caminhos bifurcados. Em cada ante há uma batalha (Batedor ou Guarda; boss nos antes
## múltiplos de 4) e depois uma paragem (Loja ou outra). Toca no nó para seguir; os nós já
## percorridos ficam marcados e os futuros veem-se, para planear. A run está gravada aqui.

const NODE_INFO := {
	"scout": ["Batedor", "Inimigo normal · ouro normal", "creature"],
	"guard": ["Guarda", "+25 % de vida · +4 ouro", "creature"],
	"boss": ["Boss", "Regra especial · recompensa de boss", "relic"],
	"shop": ["Loja", "Cartas, relíquias, serviços, juros", "seal"],
	"event": ["Evento", "Uma escolha com consequências", "sorcery"],
	"rest": ["Acampamento", "Curar, treinar ou meditar", "land"],
	"spring": ["Fonte de Mana", "Muda a cor de até 3 cartas", "instant"],
	"altar": ["Altar de Phyrexia", "Sacrifica uma carta, funde a habilidade", "pip"],
	"merchant": ["Mercador Cego", "Relíquias lendárias e planeswalkers", "relic"],
}
const NODE_COLORS := {
	"scout": Color(0.55, 0.35, 0.3), "guard": Color(0.65, 0.3, 0.3), "boss": Color(0.6, 0.45, 0.15),
	"shop": Color(0.3, 0.4, 0.6), "event": Color(0.45, 0.35, 0.6), "rest": Color(0.3, 0.5, 0.35),
	"spring": Color(0.25, 0.5, 0.6), "altar": Color(0.4, 0.3, 0.45), "merchant": Color(0.55, 0.45, 0.2),
}

var _columns: Array = []     # [{"ante", "phase", "node": Control, "buttons": {kind: Button}}]
var _lines: Control
var _busy := false

func _ready() -> void:
	GameState.save_run({}, "map")
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	# Cabeçalho: menu, título do ato, estado da run.
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var menu := UiKit.button(tr("◀ MENU"), 48, 18)
	menu.custom_minimum_size.x = 120
	menu.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(menu)
	var act := GameState.act_of_ante(GameState.ante)
	var title := UiKit.label(tr("ATO %s") % GameState.act_name() + "  ·  " + tr("As Crónicas da Centelha"), 26, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	var acts := HBoxContainer.new()
	acts.add_theme_constant_override("separation", 6)
	header.add_child(acts)
	for i in GameState.ACT_NAMES.size():
		var chip := UiKit.label(GameState.ACT_NAMES[i], 16, UiKit.GOLD if i + 1 == act else (Color(0.5, 0.5, 0.6) if i + 1 > act else Color(0.75, 0.7, 0.55)))
		chip.custom_minimum_size = Vector2(34, 30)
		chip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		chip.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		acts.add_child(chip)
	var status_parts: Array[String] = [tr(String(GameState.deck_def.get("name", ""))), tr("Ante %d") % GameState.ante,
		tr("Vida %d/%d") % [GameState.player_hp, GameState.player_max_hp], tr("Ouro: %d") % GameState.gold,
		tr("Relíquias: %d/%d") % [GameState.relic_ids.size(), GameState.MAX_RELICS]]
	if GameState.stake > 1:
		status_parts.append(tr("Selo %d") % GameState.stake)
	if GameState.endless:
		status_parts.append(tr("Modo infinito"))
	var status := UiKit.label("  ·  ".join(PackedStringArray(status_parts)), 17, UiKit.TEXT_DIM)
	vbox.add_child(status)

	# Grafo do ato: linhas por trás, colunas de nós à frente.
	var graph := Control.new()
	graph.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(graph)
	_lines = Control.new()
	_lines.set_anchors_preset(Control.PRESET_FULL_RECT)
	_lines.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_lines.draw.connect(_draw_lines)
	graph.add_child(_lines)
	var row := HBoxContainer.new()
	row.set_anchors_preset(Control.PRESET_FULL_RECT)
	row.add_theme_constant_override("separation", 26)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	graph.add_child(row)
	var antes: Array[int] = []
	if act < 5:
		var first_ante := (act - 1) * 2 + 1
		antes.append(first_ante)
		antes.append(first_ante + 1)
	else:
		antes.append(GameState.ante)
	for a in antes:
		var opts := GameState.map_options(a)
		row.add_child(_column(a, "battle", opts["battle"]))
		row.add_child(_column(a, "stop", opts["stop"]))
	# Marcador do que vem a seguir ao ato.
	var next_lbl := UiKit.label(tr("Ato %s") % GameState.ACT_NAMES[min(act, 4)] if act < 5 else tr("Ante %d") % (GameState.ante + 1), 16, Color(0.5, 0.5, 0.6))
	next_lbl.custom_minimum_size.x = 60
	next_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	next_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	next_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	row.add_child(next_lbl)

	var hint_txt := tr("Escolhe a batalha do ante %d.") % GameState.ante if GameState.map_phase == "battle" else tr("Ante %d vencido! Escolhe onde parar antes do próximo.") % GameState.ante
	var hint := UiKit.label(hint_txt, 18, UiKit.GOLD)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(hint)
	await get_tree().process_frame
	_lines.queue_redraw()

## Uma coluna de nós (as opções de uma fase de um ante).
func _column(a: int, phase: String, kinds: Array) -> Control:
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var label := UiKit.label(tr("Ante %d") % a + ("  ·  " + tr("batalha") if phase == "battle" else "  ·  " + tr("paragem")), 14, UiKit.TEXT_DIM)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(label)
	var state := _state_of(a, phase)
	var chosen := GameState.map_chosen(a, phase)
	var entry := {"ante": a, "phase": phase, "node": col, "buttons": {}}
	for kind in kinds:
		var b := _node_button(String(kind), state, chosen == String(kind) or (state == "past" and kinds.size() == 1))
		if state == "current":
			b.pressed.connect(_on_pick.bind(a, phase, String(kind)))
		col.add_child(b)
		entry["buttons"][String(kind)] = b
	_columns.append(entry)
	return col

## "past" (já passou), "current" (é a escolha de agora) ou "future".
func _state_of(a: int, phase: String) -> String:
	if a < GameState.ante:
		return "past"
	if a > GameState.ante:
		return "future"
	if phase == GameState.map_phase:
		return "current"
	return "past" if phase == "battle" else "future"

func _node_button(kind: String, state: String, chosen: bool) -> Button:
	var info: Array = NODE_INFO.get(kind, [kind, "", "relic"])
	var color: Color = NODE_COLORS.get(kind, UiKit.BG_LIGHT)
	var b := Button.new()
	b.custom_minimum_size = Vector2(222, 96)
	b.focus_mode = Control.FOCUS_NONE
	var bg := color if state == "current" else color.darkened(0.45)
	var border := UiKit.GOLD if state == "current" else (Color(0.6, 0.85, 0.6) if chosen else Color(0.3, 0.28, 0.4))
	var style := UiKit.flat(bg, 14, border, 3 if (state == "current" or chosen) else 1, 8)
	b.add_theme_stylebox_override("normal", style)
	b.add_theme_stylebox_override("hover", style)
	b.add_theme_stylebox_override("pressed", UiKit.flat(bg.lightened(0.15), 14, border, 3, 8))
	b.add_theme_stylebox_override("disabled", style)
	b.disabled = state != "current"
	var box := HBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_FULL_RECT)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_theme_constant_override("separation", 8)
	b.add_child(box)
	var icon := CardIcon.new(String(info[2]), Color.WHITE if state == "current" else Color(0.7, 0.7, 0.75), 30.0)
	icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	box.add_child(icon)
	var texts := VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	texts.mouse_filter = Control.MOUSE_FILTER_IGNORE
	texts.add_theme_constant_override("separation", 0)
	box.add_child(texts)
	var t := UiKit.label(("✓ " if chosen and state == "past" else "") + tr(String(info[0])), 17, Color.WHITE if state != "future" else Color(0.75, 0.75, 0.8))
	t.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	texts.add_child(t)
	var d := UiKit.label(tr(String(info[1])), 12, Color(0.85, 0.85, 0.9) if state == "current" else Color(0.6, 0.6, 0.65), true)
	d.size_flags_vertical = Control.SIZE_FILL
	d.custom_minimum_size.y = 40
	d.add_theme_constant_override("line_spacing", 0)
	d.max_lines_visible = 2
	d.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	texts.add_child(d)
	if state == "past" and not chosen:
		b.modulate.a = 0.45
	return b

func _draw_lines() -> void:
	for i in range(_columns.size() - 1):
		var from_btns: Array = _columns[i]["buttons"].values()
		var to_btns: Array = _columns[i + 1]["buttons"].values()
		for fb in from_btns:
			for tb in to_btns:
				if not (fb is Control) or not (tb is Control):
					continue
				var p1: Vector2 = (fb as Control).global_position + Vector2((fb as Control).size.x, (fb as Control).size.y / 2.0) - _lines.global_position
				var p2: Vector2 = (tb as Control).global_position + Vector2(0, (tb as Control).size.y / 2.0) - _lines.global_position
				var alpha := 0.25
				if (fb as Button).modulate.a > 0.5 and (tb as Button).modulate.a > 0.5:
					alpha = 0.45
				_lines.draw_line(p1, p2, Color(0.8, 0.7, 0.5, alpha), 2.0, true)

func _on_pick(a: int, phase: String, kind: String) -> void:
	if _busy or a != GameState.ante or phase != GameState.map_phase:
		return
	_busy = true
	Sfx.boom()
	if phase == "battle":
		GameState.choose_battle(kind)
		GameState.save_run({}, "battle")
		SceneRouter.go("battle")
	else:
		GameState.choose_stop(kind)
		var scene := GameState.stop_scene(kind)
		GameState.save_run({}, scene)
		SceneRouter.go(scene)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
