extends Control
## DESAFIOS: runs fixas (data/challenges.json) com um baralho e uma regra especial — sem canalizar,
## só custo ≤ 2, mão de 4, vida 8, sem relíquias, bosses de 2 em 2, sem ouro das batalhas, 4 turnos.
## Vencer dá a medalha do desafio (progress.challenges). Não é semente diária e não conta para a
## campanha.

func _ready() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	margin.add_child(vbox)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var back := UiKit.button(tr("◀ MENU"), 48, 18)
	back.custom_minimum_size.x = 120
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("DESAFIOS"), 26, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	var won := 0
	for c in CardDB.challenges:
		if GameState.challenge_done(String(c.get("id", ""))):
			won += 1
	var counter := UiKit.label(tr("Medalhas: %d/%d") % [won, CardDB.challenges.size()], 18, UiKit.TEXT_DIM)
	counter.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(counter)
	vbox.add_child(UiKit.label(tr("Runs completas (8 antes) com um baralho fixo e uma regra que muda tudo. Vence para ganhar a medalha."), 16, UiKit.TEXT_DIM, true))
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 10)
	scroll.add_child(grid)
	for c in CardDB.challenges:
		grid.add_child(_challenge_button(c))

func _challenge_button(c: Dictionary) -> Control:
	var id := String(c.get("id", ""))
	var done := GameState.challenge_done(id)
	var deck := CardDB.get_deck(String(c.get("deck_id", "")))
	var b := UiKit.button("", 108, 17, Color(0.16, 0.26, 0.2) if done else UiKit.BG_LIGHT, UiKit.GOLD if done else UiKit.BORDER)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	b.clip_text = true
	b.text = ("★ " if done else "") + tr(String(c.get("name", ""))) + "  ·  " + tr(String(deck.get("name", ""))) + "\n" + tr(String(c.get("text", ""))) + ("\n" + tr("Medalha ganha") if done else "")
	b.pressed.connect(_start.bind(id))
	return b

func _start(id: String) -> void:
	Sfx.boom()
	GameState.clear_saved_run()
	GameState.new_challenge_run(id)
	GameState.save_run({}, "map")
	SceneRouter.go("map")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
