class_name RelicView
extends Control
## Uma relíquia na prateleira do topo, em medalhão: ícone redondo com o anel da cor da raridade
## (o nome e o texto abrem ao tocar). Abana quando dispara na cascata. As que escalam mostram o
## valor atual num pequeno selo por baixo.
## Toque = `pressed`; arrastar = reordenar (drag_started/moved/ended).

signal pressed(relic_id: String)
signal drag_started(relic_id: String, global_pos: Vector2)
signal drag_moved(relic_id: String, global_pos: Vector2)
signal drag_ended(relic_id: String, global_pos: Vector2)

const DRAG_START := 16.0
const SIZE := 58.0
const RING := {
	"common": Color(0.72, 0.75, 0.86),
	"uncommon": Color(0.42, 0.86, 0.8),
	"rare": Color(0.98, 0.75, 0.25),
	"legendary": Color(0.78, 0.55, 1.0),
	"boss": Color(0.95, 0.4, 0.4),
	"blessing": Color(0.55, 0.85, 1.0),
}
const BG := Color(0.12, 0.1, 0.18)

var relic_id: String = ""
var _pressing := false
var _dragging := false
var _edge_press := false   # 0.19.0 (28): começou colado à borda: não arrasta
var _press_pos := Vector2.ZERO
var _ring := Color.WHITE
var _icon: CardIcon
var _badge := ""
var _art: Texture2D   # 0.12.0: ilustração opcional (assets/art/relics/<id>.webp) no lugar do ícone
var _preview := ""          # 0.19.0 (103): o que a relíquia vai dar no ataque previsto ("+20", "+2", "×1.5")
var _preview_col := Color.WHITE

## 0.19.0 (103): o valor previsto num selo no canto de cima ("" tira-o).
func set_preview(text: String, col: Color = Color.WHITE) -> void:
	if text == _preview and col == _preview_col:
		return
	_preview = text
	_preview_col = col
	queue_redraw()

func preview_text() -> String:
	return _preview

func _init() -> void:
	custom_minimum_size = Vector2(SIZE, SIZE)
	mouse_filter = Control.MOUSE_FILTER_STOP

func setup(id: String) -> void:
	relic_id = id
	var relic: Dictionary = CardDB.relics.get(id, {})
	_ring = ring_color(relic)
	tooltip_text = TranslationServer.translate(String(relic.get("name", id)))
	if _icon == null:
		_icon = CardIcon.new(glyph_for(relic), _ring.lightened(0.25), 30.0)
		add_child(_icon)
	else:
		_icon.kind = glyph_for(relic)
		_icon.color = _ring.lightened(0.25)
	_art = ArtLib.texture("relic", id)
	_icon.visible = _art == null
	_place_icon()
	refresh_value()
	queue_redraw()

## 0.19.0 (19): com um rato a sério, passar por cima explica a relíquia (o nome e o que faz).
func _get_tooltip(_at_position: Vector2) -> String:
	var relic: Dictionary = CardDB.relics.get(relic_id, {})
	var nm := TranslationServer.translate(String(relic.get("name", relic_id)))
	if not SceneRouter.real_mouse:
		return nm
	return nm + "\n" + TranslationServer.translate(String(relic.get("text", "")))

static func ring_color(relic: Dictionary) -> Color:
	if bool(relic.get("blessing", false)):
		return RING["blessing"]
	if bool(relic.get("boss", false)):
		return RING["boss"]
	if bool(relic.get("legendary", false)):
		return RING["legendary"]
	return RING.get(String(relic.get("rarity", "common")), RING["common"])

## Ícone pelo efeito principal da relíquia (o que ela faz mais vezes).
static func glyph_for(relic: Dictionary) -> String:
	for e in relic.get("effects", []):
		# 0.12.0: relíquias de palavras-chave e de Terrenos mostram o ícone da mecânica.
		var f: Dictionary = e.get("filter", {}) if e.get("filter") is Dictionary else {}
		if f.has("keyword"):
			return String(f["keyword"])
		if String(e.get("action", "")) == "grant_keyword":
			return String(e.get("keyword", "flying"))
		if String(e.get("trigger", "")) == "land_played" or String(e.get("per", "")) == "land":
			return "landfall"
		if String(e.get("per", "")) == "keywords":
			return "first_strike"
		match String(e.get("action", "")):
			"power_add", "power_pct_enemy":
				return "creature"
			"mult_add":
				return "burst"
			"mult_mul":
				return "instant"
			"gold", "double_interest", "shop_tax", "reward_minus", "early_bonus":
				return "coin"
			"heal", "heal_player", "max_hp", "death_save":
				return "heart"
			"draw", "discard_plus", "hand_plus", "tutor_land", "discards_minus":
				return "card"
			"create_token":
				return "shield"
			"retrigger":
				return "wheel"
			"cost_reduction", "mana_plus", "kicker_minus":
				return "land"
			"enemy_hp_pct", "damage_enemy", "enemy_vulnerable", "flashback_damage_pct":
				return "skull"
			"chain_min", "tribe_plus", "ench_plus":
				return "seal"
	return "relic"

func _place_icon() -> void:
	if _icon == null:
		return
	var side := custom_minimum_size.x if custom_minimum_size.x > 0.0 else SIZE
	var s := 30.0 * side / SIZE
	_icon.position = (Vector2(side, side) - Vector2(s, s)) / 2.0 - Vector2(0, 2.0 if _badge != "" else 0.0)
	_icon.size = Vector2(s, s)

## Relíquias que escalam: o valor atual num selo por baixo ("+3").
func refresh_value() -> void:
	var v := GameState.relic_scaling_text(relic_id)
	_badge = ""
	if v != "":
		var parts := v.split(":")
		var tail := parts[parts.size() - 1].strip_edges()
		_badge = tail.split(" ")[0]
	_place_icon()
	queue_redraw()

## Tamanho do medalhão (por omissão SIZE).
func set_width(w: float) -> void:
	# 0.18.0: a barra de cima da batalha usa medalhões de 48 px (para a mão caber a 100 % de escala).
	var side := w if w > 0.0 else SIZE
	custom_minimum_size = Vector2(side, side)
	_place_icon()

func _draw() -> void:
	var c := size / 2.0
	var r := minf(size.x, size.y) / 2.0 - 2.0
	draw_circle(c, r, BG)
	draw_circle(c, r - 5.0, BG.lightened(0.06))
	if _art != null:
		var ir := r - 3.0
		var ts := _art.get_size()
		var side := minf(ts.x, ts.y) * 0.5
		var pts := PackedVector2Array()
		var uvs := PackedVector2Array()
		for i in 40:
			var a := TAU * i / 40.0
			var d := Vector2(cos(a), sin(a))
			pts.append(c + d * ir)
			uvs.append((ts * 0.5 + d * side) / ts)
		var cols := PackedColorArray()
		cols.resize(40)
		cols.fill(ArtLib.art_tint())   # 0.19.0 (120): brilho das ilustrações
		draw_polygon(pts, cols, uvs, _art)
	draw_arc(c, r - 1.5, 0.0, TAU, 40, _ring, 3.0, true)
	draw_arc(c, r - 6.0, 0.0, TAU, 40, Color(_ring, 0.25), 1.0, true)
	if _badge != "":
		var font := get_theme_default_font()
		var fs := 12
		var tw := font.get_string_size(_badge, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		var br := Rect2(Vector2(c.x - tw / 2.0 - 5.0, size.y - 17.0), Vector2(tw + 10.0, 15.0))
		draw_style_box(UiKit.flat(Color(0.12, 0.42, 0.22), 7, Color(0.55, 0.95, 0.6), 1, 0), br)
		draw_string(font, Vector2(br.position.x + 5.0, br.position.y + 12.0), _badge, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(0.85, 1.0, 0.85))
	if _preview != "":
		var pf := get_theme_default_font()
		var pfs := 11
		var pw := pf.get_string_size(_preview, HORIZONTAL_ALIGNMENT_LEFT, -1, pfs).x
		var pr := Rect2(Vector2(size.x - pw - 8.0, -3.0), Vector2(pw + 8.0, 14.0))
		draw_style_box(UiKit.flat(Color(0.06, 0.05, 0.1, 0.92), 7, _preview_col, 1, 0), pr)
		draw_string(pf, Vector2(pr.position.x + 4.0, pr.position.y + 11.0), _preview, HORIZONTAL_ALIGNMENT_LEFT, -1, pfs, _preview_col)

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		pivot_offset = size / 2.0
		_place_icon()
	elif what == NOTIFICATION_MOUSE_EXIT and not _dragging:
		_pressing = false

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		if _dragging:
			drag_moved.emit(relic_id, get_global_mouse_position())
		elif _pressing and (event.position - _press_pos).length() > Settings.drag_px():   # 0.19.0 (4)
			_pressing = false
			if _edge_press:
				return
			_dragging = true
			drag_started.emit(relic_id, get_global_mouse_position())
		return
	if not (event is InputEventMouseButton) or event.button_index != MOUSE_BUTTON_LEFT:
		return
	accept_event()
	if event.pressed:
		_pressing = true
		_press_pos = event.position
		_edge_press = bool(Settings.opt("edge_guard")) and SceneRouter.near_edge(get_global_mouse_position())
	else:
		if _dragging:
			_dragging = false
			drag_ended.emit(relic_id, get_global_mouse_position())
			return
		if _pressing and Rect2(Vector2.ZERO, size).has_point(event.position):
			pressed.emit(relic_id)
		_pressing = false
