class_name RelicView
extends PanelContainer
## Uma relíquia na prateleira do topo (o "joker"). Abana quando dispara na cascata.
## Toque = `pressed` (a batalha abre a descrição em grande).

signal pressed(relic_id: String)
signal drag_started(relic_id: String, global_pos: Vector2)
signal drag_moved(relic_id: String, global_pos: Vector2)
signal drag_ended(relic_id: String, global_pos: Vector2)

const DRAG_START := 16.0

var relic_id: String = ""
var _pressing := false
var _dragging := false
var _press_pos := Vector2.ZERO

@onready var name_label: Label = %Name
@onready var text_label: Label = %Text

func setup(id: String) -> void:
	relic_id = id
	if not is_node_ready():
		await ready
	var relic: Dictionary = CardDB.relics.get(id, {})
	name_label.text = relic.get("name", id)
	text_label.text = relic.get("text", "")
	pivot_offset = size / 2.0

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		pivot_offset = size / 2.0
	elif what == NOTIFICATION_MOUSE_EXIT and not _dragging:
		_pressing = false

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		if _dragging:
			drag_moved.emit(relic_id, get_global_mouse_position())
		elif _pressing and (event.position - _press_pos).length() > DRAG_START:
			_pressing = false
			_dragging = true
			drag_started.emit(relic_id, get_global_mouse_position())
		return
	if not (event is InputEventMouseButton) or event.button_index != MOUSE_BUTTON_LEFT:
		return
	accept_event()
	if event.pressed:
		_pressing = true
		_press_pos = event.position
	else:
		if _dragging:
			_dragging = false
			drag_ended.emit(relic_id, get_global_mouse_position())
			return
		if _pressing and Rect2(Vector2.ZERO, size).has_point(event.position):
			pressed.emit(relic_id)
		_pressing = false
