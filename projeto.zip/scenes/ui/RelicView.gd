class_name RelicView
extends Control
## Uma relíquia na prateleira do topo, em medalhão: ícone redondo com o anel da cor da raridade
## (o nome e o texto abrem ao tocar). Abana quando dispara na cascata. As que escalam mostram o
## valor atual num pequeno selo por baixo.
## Toque = `pressed`; arrastar = reordenar (drag_started/moved/ended).

signal pressed(relic_id: String)
signal drag_started(relic_id: String, global_pos: Vector2)
signal drag_moved(relic_id: String, global_pos: Vector2)
signal drag_ended(relic_id: String, global_pos: Vector2)

const DRAG_START := 16.0
const SIZE := 58.0
const RING := {
	"common": Color(0.72, 0.75, 0.86),
	"uncommon": Color(0.42, 0.86, 0.8),
	"rare": Color(0.98, 0.75, 0.25),
	"legendary": Color(0.78, 0.55, 1.0),
	"boss": Color(0.95, 0.4, 0.4),
}
const BG := Color(0.12, 0.1, 0.18)

var relic_id: String = ""
var _pressing := false
var _dragging := false
var _press_pos := Vector2.ZERO
var _ring := Color.WHITE
var _icon: CardIcon
var _badge := ""

func _init() -> void:
	custom_minimum_size = Vector2(SIZE, SIZE)
	mouse_filter = Control.MOUSE_FILTER_STOP

func setup(id: String) -> void:
	relic_id = id
	var relic: Dictionary = CardDB.relics.get(id, {})
	_ring = ring_color(relic)
	tooltip_text = TranslationServer.translate(String(relic.get("name", id)))
	if _icon == null:
		_icon = CardIcon.new(glyph_for(relic), _ring.lightened(0.25), 30.0)
		add_child(_icon)
	else:
		_icon.kind = glyph_for(relic)
		_icon.color = _ring.lightened(0.25)
	_place_icon()
	refresh_value()
	queue_redraw()

static func ring_color(relic: Dictionary) -> Color:
	if bool(relic.get("boss", false)):
		return RING["boss"]
	if bool(relic.get("legendary", false)):
		return RING["legendary"]
	return RING.get(String(relic.get("rarity", "common")), RING["common"])

## Ícone pelo efeito principal da relíquia (o que ela faz mais vezes).
static func glyph_for(relic: Dictionary) -> String:
	for e in relic.get("effects", []):
		match String(e.get("action", "")):
			"power_add", "power_pct_enemy":
				return "creature"
			"mult_add":
				return "burst"
			"mult_mul":
				return "instant"
			"gold", "double_interest", "shop_tax", "reward_minus", "early_bonus":
				return "coin"
			"heal", "heal_player", "max_hp", "death_save":
				return "heart"
			"draw", "discard_plus", "hand_plus", "tutor_land", "discards_minus":
				return "card"
			"create_token":
				return "shield"
			"retrigger":
				return "wheel"
			"cost_reduction", "mana_plus", "kicker_minus":
				return "land"
			"enemy_hp_pct", "damage_enemy", "enemy_vulnerable", "flashback_damage_pct":
				return "skull"
			"chain_min", "tribe_plus", "ench_plus":
				return "seal"
	return "relic"

func _place_icon() -> void:
	if _icon == null:
		return
	var s := 30.0
	_icon.position = (Vector2(SIZE, SIZE) - Vector2(s, s)) / 2.0 - Vector2(0, 2.0 if _badge != "" else 0.0)
	_icon.size = Vector2(s, s)

## Relíquias que escalam: o valor atual num selo por baixo ("+3").
func refresh_value() -> void:
	var v := GameState.relic_scaling_text(relic_id)
	_badge = ""
	if v != "":
		var parts := v.split(":")
		var tail := parts[parts.size() - 1].strip_edges()
		_badge = tail.split(" ")[0]
	_place_icon()
	queue_redraw()

## Mantido por compatibilidade (as relíquias já não mudam de largura).
func set_width(_w: float) -> void:
	custom_minimum_size = Vector2(SIZE, SIZE)

func _draw() -> void:
	var c := size / 2.0
	var r := minf(size.x, size.y) / 2.0 - 2.0
	draw_circle(c, r, BG)
	draw_circle(c, r - 5.0, BG.lightened(0.06))
	draw_arc(c, r - 1.5, 0.0, TAU, 40, _ring, 3.0, true)
	draw_arc(c, r - 6.0, 0.0, TAU, 40, Color(_ring, 0.25), 1.0, true)
	if _badge != "":
		var font := get_theme_default_font()
		var fs := 12
		var tw := font.get_string_size(_badge, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		var br := Rect2(Vector2(c.x - tw / 2.0 - 5.0, size.y - 17.0), Vector2(tw + 10.0, 15.0))
		draw_style_box(UiKit.flat(Color(0.12, 0.42, 0.22), 7, Color(0.55, 0.95, 0.6), 1, 0), br)
		draw_string(font, Vector2(br.position.x + 5.0, br.position.y + 12.0), _badge, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(0.85, 1.0, 0.85))

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		pivot_offset = size / 2.0
		_place_icon()
	elif what == NOTIFICATION_MOUSE_EXIT and not _dragging:
		_pressing = false

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		if _dragging:
			drag_moved.emit(relic_id, get_global_mouse_position())
		elif _pressing and (event.position - _press_pos).length() > DRAG_START:
			_pressing = false
			_dragging = true
			drag_started.emit(relic_id, get_global_mouse_position())
		return
	if not (event is InputEventMouseButton) or event.button_index != MOUSE_BUTTON_LEFT:
		return
	accept_event()
	if event.pressed:
		_pressing = true
		_press_pos = event.position
	else:
		if _dragging:
			_dragging = false
			drag_ended.emit(relic_id, get_global_mouse_position())
			return
		if _pressing and Rect2(Vector2.ZERO, size).has_point(event.position):
			pressed.emit(relic_id)
		_pressing = false
