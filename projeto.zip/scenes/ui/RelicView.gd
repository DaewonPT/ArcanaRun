class_name RelicView
extends PanelContainer
## Uma relíquia na prateleira do topo (o "joker"). Abana quando dispara na cascata.
## Toque = `pressed` (a batalha abre a descrição em grande).

signal pressed(relic_id: String)

var relic_id: String = ""
var _pressing := false

@onready var name_label: Label = %Name
@onready var text_label: Label = %Text

func setup(id: String) -> void:
	relic_id = id
	if not is_node_ready():
		await ready
	var relic: Dictionary = CardDB.relics.get(id, {})
	name_label.text = relic.get("name", id)
	text_label.text = relic.get("text", "")
	pivot_offset = size / 2.0

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		pivot_offset = size / 2.0
	elif what == NOTIFICATION_MOUSE_EXIT:
		_pressing = false

func _gui_input(event: InputEvent) -> void:
	if not (event is InputEventMouseButton) or event.button_index != MOUSE_BUTTON_LEFT:
		return
	accept_event()
	if event.pressed:
		_pressing = true
	else:
		if _pressing and Rect2(Vector2.ZERO, size).has_point(event.position):
			pressed.emit(relic_id)
		_pressing = false
