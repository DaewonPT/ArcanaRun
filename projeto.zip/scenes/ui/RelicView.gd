class_name RelicView
extends PanelContainer
## Uma relíquia na prateleira do topo (o "joker"). Abana quando dispara na cascata.

var relic_id: String = ""

@onready var name_label: Label = %Name
@onready var text_label: Label = %Text

func setup(id: String) -> void:
	relic_id = id
	if not is_node_ready():
		await ready
	var relic: Dictionary = CardDB.relics.get(id, {})
	name_label.text = relic.get("name", id)
	text_label.text = relic.get("text", "")
	pivot_offset = size / 2.0

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		pivot_offset = size / 2.0
