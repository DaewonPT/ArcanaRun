class_name RelicView
extends PanelContainer
## Uma relíquia na prateleira do topo (o "joker"). Abana quando dispara na cascata.
## Toque = `pressed` (a batalha abre a descrição em grande).

signal pressed(relic_id: String)
signal drag_started(relic_id: String, global_pos: Vector2)
signal drag_moved(relic_id: String, global_pos: Vector2)
signal drag_ended(relic_id: String, global_pos: Vector2)

const DRAG_START := 16.0

var relic_id: String = ""
var _pressing := false
var _dragging := false
var _press_pos := Vector2.ZERO

@onready var name_label: Label = %Name
@onready var text_label: Label = %Text

func setup(id: String) -> void:
	relic_id = id
	if not is_node_ready():
		await ready
	var relic: Dictionary = CardDB.relics.get(id, {})
	name_label.text = relic.get("name", id)
	text_label.text = relic.get("text", "")
	refresh_value()
	# Relíquias de boss: moldura vermelha (ficam à parte, depois das normais).
	if bool(relic.get("boss", false)):
		var style: StyleBoxFlat = get_theme_stylebox("panel").duplicate()
		style.border_color = Color(0.9, 0.35, 0.35)
		style.bg_color = Color(0.22, 0.11, 0.14)
		add_theme_stylebox_override("panel", style)
		name_label.add_theme_color_override("font_color", Color(1.0, 0.6, 0.55))
	pivot_offset = size / 2.0

## Relíquias que escalam: em vez da descrição, mostra o valor atual ("Agora: +3 Mult").
func refresh_value() -> void:
	if not is_node_ready():
		return
	var v := GameState.relic_scaling_text(relic_id)
	if v != "":
		text_label.text = v
		text_label.add_theme_color_override("font_color", Color(0.55, 0.95, 0.6))

## Largura na prateleira: com muitas relíquias encolhem (o texto some abaixo de 140 px; toca para ler).
func set_width(w: float) -> void:
	custom_minimum_size.x = w
	if not is_node_ready():
		await ready
	text_label.visible = w >= 140.0

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		pivot_offset = size / 2.0
	elif what == NOTIFICATION_MOUSE_EXIT and not _dragging:
		_pressing = false

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		if _dragging:
			drag_moved.emit(relic_id, get_global_mouse_position())
		elif _pressing and (event.position - _press_pos).length() > DRAG_START:
			_pressing = false
			_dragging = true
			drag_started.emit(relic_id, get_global_mouse_position())
		return
	if not (event is InputEventMouseButton) or event.button_index != MOUSE_BUTTON_LEFT:
		return
	accept_event()
	if event.pressed:
		_pressing = true
		_press_pos = event.position
	else:
		if _dragging:
			_dragging = false
			drag_ended.emit(relic_id, get_global_mouse_position())
			return
		if _pressing and Rect2(Vector2.ZERO, size).has_point(event.position):
			pressed.emit(relic_id)
		_pressing = false
