class_name TextPrompt
extends Control
## 0.12.0: pedir um texto curto (o nome de uma run gravada). O painel fica no cimo do ecrã, para o
## teclado do Android não o tapar; ENTER ou GUARDAR confirmam, CANCELAR ou "retroceder" fecham.

var _edit: LineEdit
var _on_ok: Callable

static func open(title: String, initial: String, placeholder: String, max_len: int, on_ok: Callable) -> TextPrompt:
	var o := TextPrompt.new()
	o._on_ok = on_ok
	SceneRouter.show_overlay(o)
	o._build(title, initial, placeholder, max_len)
	return o

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.8))

func _build(title: String, initial: String, placeholder: String, max_len: int) -> void:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiKit.flat(UiKit.BG, 18, UiKit.GOLD, 2, 22))
	panel.set_anchors_preset(Control.PRESET_CENTER_TOP)
	panel.offset_left = -380
	panel.offset_right = 380
	panel.offset_top = 28
	panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(panel)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	panel.add_child(vbox)
	var t := UiKit.label(title, 24, UiKit.GOLD)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(t)
	_edit = LineEdit.new()
	_edit.name = "Edit"
	_edit.text = initial
	_edit.placeholder_text = placeholder
	_edit.max_length = max_len
	_edit.custom_minimum_size = Vector2(0, 56)
	_edit.add_theme_font_size_override("font_size", 22)
	_edit.select_all_on_focus = true
	_edit.text_submitted.connect(func(_t: String): _confirm())
	vbox.add_child(_edit)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	vbox.add_child(row)
	var cancel := UiKit.button(tr("CANCELAR"), 54, 20)
	cancel.name = "Cancel"
	cancel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cancel.pressed.connect(func(): Sfx.select(); UiKit.close_animated(self))
	row.add_child(cancel)
	var ok := UiKit.button(tr("GUARDAR"), 54, 20, UiKit.PRIMARY)
	ok.name = "Ok"
	ok.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ok.pressed.connect(_confirm)
	row.add_child(ok)
	_focus_later()

func _focus_later() -> void:
	await get_tree().process_frame
	if is_instance_valid(_edit) and _edit.is_inside_tree():
		_edit.grab_focus()
		_edit.caret_column = _edit.text.length()

func text() -> String:
	return _edit.text if is_instance_valid(_edit) else ""

func _confirm() -> void:
	if is_queued_for_deletion():
		return
	Sfx.select()
	var value := _edit.text
	var cb := _on_ok
	UiKit.close_animated(self)
	if cb.is_valid():
		cb.call(value)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		UiKit.close_animated(self)
