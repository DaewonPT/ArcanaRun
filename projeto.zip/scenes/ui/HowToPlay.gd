class_name HowToPlay
extends Control
## Regras do jogo. Abre como cena (do menu) ou como painel por cima da pausa.
## O texto vive em i18n/howto.json (só ficheiros-recurso entram no APK): secções separadas por uma linha
## em branco, a 1.ª linha de cada uma é o título. A seguir vêm o Glossário (data/glossary.json) e as
## palavras-chave.
## 0.12.0: índice à esquerda (toca para saltar) e pesquisa no topo — sem acentos nem maiúsculas ("magica"
## encontra "Mágica"; várias palavras têm de aparecer todas) — com as palavras encontradas realçadas.

const FOLD := {"á": "a", "à": "a", "â": "a", "ã": "a", "ä": "a", "é": "e", "è": "e", "ê": "e", "ë": "e",
	"í": "i", "ì": "i", "î": "i", "ï": "i", "ó": "o", "ò": "o", "ô": "o", "õ": "o", "ö": "o", "ú": "u",
	"ù": "u", "û": "u", "ü": "u", "ç": "c", "ñ": "n"}
const HL_OPEN := "[bgcolor=#6a5418][color=#ffe9a8]"
const HL_CLOSE := "[/color][/bgcolor]"

var overlay := false
var sections: Array = []   # [{"title", "body", "f_title", "f_body", "panel", "rtl", "btn"}]
var _search: LineEdit
var _list: VBoxContainer
var _scroll: ScrollContainer
var _index: VBoxContainer
var _count: Label
var _empty: Label
var _timer: Timer

static func open_overlay() -> HowToPlay:
	var s: HowToPlay = load("res://scenes/ui/HowToPlay.tscn").instantiate()
	s.overlay = true
	SceneRouter.show_overlay(s)
	return s

## 0.19.0 (145): abre logo na secção com este título (o título em português, também com o jogo em inglês).
static func open_at(pt_title: String) -> HowToPlay:
	var s := open_overlay()
	s.jump_to(s.index_of(pt_title))
	return s

## 0.19.0 (151): um ícone em cada regra (pelo título em português).
const SECTION_ICONS := {"OBJETIVO": "flag", "MANA": "mana", "TURNO": "hourglass", "A CASCATA": "swords", "FORMAÇÕES": "star",
	"O INIMIGO": "skull", "LOJA": "shop", "O MAPA": "flag", "CLIMA PLANAR": "climate", "BOSSES": "crown", "RELÍQUIAS QUE CRESCEM": "relic",
	"MALDIÇÕES": "curse", "MULLIGAN": "replay", "CARTAS DE DUPLA FACE": "cards", "SELOS": "seal", "RECAPITULAR E EXÍLIO": "replay",
	"PLANESWALKER": "star", "SELOS PLANARES": "seal", "MODOS": "book", "FICHAS E TRIBOS": "creature", "CADEIAS E CONJUNTOS": "relic",
	"ENCANTAMENTOS, REFORÇO E REAÇÃO": "sorcery", "EQUIPAMENTOS": "anvil", "BATALHAS ESPECIAIS": "first_strike", "LACAIOS E ESCUDOS": "shield",
	"MÍTICAS E DESBLOQUEIOS": "star", "VALES E CARTAS +": "coin", "NÉMESIS": "burst", "GLOSSÁRIO E HISTÓRICO": "book", "TIPOS DE CARTA": "cards",
	"PALAVRAS-CHAVE": "instant", "CHEGADA DE TERRENO": "land", "ESCOLA, DICAS E TALENTOS": "book", "EDIÇÕES": "star",
	"POÇÕES E PERGAMINHOS": "potion", "CONJUNTOS DE RELÍQUIAS": "relic", "MESTRIA, CORES E PERFIL": "star", "DIFICULDADE": "skull",
	"CONFORTO": "heart", "AJUDAS NA BATALHA": "heart", "NÍVEIS DE BARALHO": "cards", "CAMPANHA": "flag", "JOGOS GUARDADOS": "book",
	"ESTATÍSTICAS, CÓDIGOS E PARTILHA": "book", "MARCAS E PREVISÕES": "star", "PREÇOS DA LOJA": "coin", "GLOSSÁRIO": "book"}
## 0.19.0 (164): as secções novas de cada versão (o código da app em que entraram) ficam com NOVO até abrires o
## Como Jogar nessa versão.
const NEW_SECTIONS := {"PREÇOS DA LOJA": 29, "MARCAS E PREVISÕES": 29}

var _pt_titles: Array[String] = []

## Índice da secção com este título em português (-1 se não houver).
func index_of(pt_title: String) -> int:
	return _pt_titles.find(pt_title)

## As secções que ainda estão com NOVO.
func new_titles() -> Array[String]:
	var seen := int(GameState.progress.get("howto_seen_code", 0))
	var out: Array[String] = []
	for t in NEW_SECTIONS:
		if int(NEW_SECTIONS[t]) > seen and t in _pt_titles:
			out.append(String(t))
	return out

func _ready() -> void:
	%Back.pressed.connect(func(): Sfx.select(); _close())
	if overlay:
		%Back.text = tr("◀ VOLTAR")
	_build()
	_refresh_text()
	Settings.changed.connect(_refresh_text)

func _build() -> void:
	var top: HBoxContainer = %Back.get_parent()
	var spacer := Control.new()
	spacer.custom_minimum_size.x = 8
	top.add_child(spacer)
	_search = LineEdit.new()
	_search.name = "Search"
	_search.placeholder_text = tr("Procurar regra… (ex.: mana, boss, Voar)")
	_search.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_search.custom_minimum_size = Vector2(0, 52)
	_search.add_theme_font_size_override("font_size", 19)
	_search.clear_button_enabled = true
	_search.text_changed.connect(func(_t: String): _timer.start())
	top.add_child(_search)
	_timer = Timer.new()
	_timer.one_shot = true
	_timer.wait_time = 0.18
	_timer.timeout.connect(func(): apply_filter(_search.text))
	add_child(_timer)
	_count = UiKit.label("", 16, UiKit.TEXT_DIM)
	_count.custom_minimum_size.x = 120
	_count.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_count.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	top.add_child(_count)

	var body := HBoxContainer.new()
	body.add_theme_constant_override("separation", 14)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	get_node("Layout").add_child(body)
	var index_scroll := ScrollContainer.new()
	index_scroll.custom_minimum_size = Vector2(260, 0)
	index_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body.add_child(index_scroll)
	_index = VBoxContainer.new()
	_index.name = "Index"
	_index.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_index.add_theme_constant_override("separation", 3)
	index_scroll.add_child(_index)
	_scroll = ScrollContainer.new()
	_scroll.name = "Scroll"
	_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body.add_child(_scroll)
	var wrap := VBoxContainer.new()
	wrap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	wrap.add_theme_constant_override("separation", 10)
	_scroll.add_child(wrap)
	_empty = UiKit.label("", 18, UiKit.TEXT_DIM, true)
	_empty.visible = false
	wrap.add_child(_empty)
	_list = VBoxContainer.new()
	_list.name = "Sections"
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list.add_theme_constant_override("separation", 10)
	wrap.add_child(_list)

## Secções do texto das regras + Glossário (na língua em uso).
func _refresh_text() -> void:
	var lang := Settings.effective_language()
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(ContentUpdate.resolve("res://i18n/howto.json")))
	var text := ""
	if parsed is Dictionary:
		text = String(parsed.get(lang, parsed.get("pt", "")))
	var raw: Array = []
	var pt_text := String(parsed.get("pt", "")) if parsed is Dictionary else ""
	var pt_blocks: Array[String] = []
	for block in pt_text.split("\n\n", false):
		var first := String(block).strip_edges().split("\n", true, 1)
		if not first.is_empty() and String(first[0]) != "":
			pt_blocks.append(String(first[0]))
	_pt_titles.clear()
	for block in text.split("\n\n", false):
		var lines := String(block).strip_edges().split("\n", true, 1)
		if lines.is_empty() or String(lines[0]) == "":
			continue
		_pt_titles.append(pt_blocks[raw.size()] if raw.size() < pt_blocks.size() else String(lines[0]))
		raw.append([String(lines[0]), String(lines[1]) if lines.size() > 1 else ""])
	# Glossário: "Termo — explicação", por ordem alfabética.
	var gl: Array = []
	for g in CardDB.glossary:
		var term := String(g.get("en", g.get("term", ""))) if lang == "en" else String(g.get("term", ""))
		if term != "":
			gl.append("%s — %s" % [term, tr(String(g.get("text", "")))])
	gl.sort_custom(func(a, b): return fold(String(a)) < fold(String(b)))
	raw.append([tr("PREÇOS DA LOJA"), Economy.price_table()])   # 0.19.0 (94): todos os preços e o que os faz mudar
	_pt_titles.append("PREÇOS DA LOJA")
	if not gl.is_empty():
		raw.append([tr("GLOSSÁRIO"), "\n".join(PackedStringArray(gl))])
		_pt_titles.append("GLOSSÁRIO")
	UiKit.clear_children(_list)
	UiKit.clear_children(_index)
	sections.clear()
	for r in raw:
		_add_section(String(r[0]), String(r[1]))
	apply_filter(_search.text if _search != null else "")

func _add_section(title: String, body: String) -> void:
	var i := sections.size()
	var panel := PanelContainer.new()
	panel.name = "Section_%d" % i
	panel.add_theme_stylebox_override("panel", UiKit.flat(UiKit.PARCH if Settings.light_theme() else UiKit.BG, 12, UiKit.BORDER, 1, 14))
	if Settings.light_theme():
		panel.set_meta("light_surface", true)   # 0.19.0 (296): as regras em pergaminho, com letra escura
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	panel.add_child(v)
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 8)
	v.add_child(head)
	var pt := _pt_titles[i] if i < _pt_titles.size() else title
	var icon := CardIcon.new(String(SECTION_ICONS.get(pt, "book")), UiKit.GOLD, 24.0)   # 151
	icon.name = "Icon"
	icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	head.add_child(icon)
	var t := UiKit.label(title, 20, UiKit.GOLD)
	t.name = "Title"
	head.add_child(t)
	var is_new := int(NEW_SECTIONS.get(pt, 0)) > int(GameState.progress.get("howto_seen_code", 0))
	if is_new:   # 164
		var nv := PanelContainer.new()
		nv.name = "NewMark"
		nv.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		nv.add_theme_stylebox_override("panel", UiKit.flat(Color(0.85, 0.2, 0.25), 7, Color(1, 0.85, 0.85), 1, 3))
		nv.add_child(UiKit.label(tr("NOVO"), 12, Color.WHITE))
		head.add_child(nv)
	var rtl := RichTextLabel.new()
	rtl.name = "Body"
	rtl.bbcode_enabled = true
	rtl.fit_content = true
	rtl.scroll_active = false
	rtl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rtl.add_theme_font_size_override("normal_font_size", 18)
	rtl.add_theme_color_override("default_color", Color(0.92, 0.9, 0.97))
	rtl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rtl.selection_enabled = false
	v.add_child(rtl)
	_list.add_child(panel)
	var b := Button.new()
	b.name = "Jump_%d" % i
	b.text = ("● " if is_new else "") + title
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.clip_text = true
	b.custom_minimum_size = Vector2(0, 40)
	b.add_theme_font_size_override("font_size", 14)
	b.focus_mode = Control.FOCUS_NONE
	b.flat = true
	b.pressed.connect(func(): Sfx.select(); jump_to(i))
	_index.add_child(b)
	sections.append({"title": title, "body": body, "f_title": fold(title), "f_body": fold(body), "panel": panel, "rtl": rtl, "btn": b})

## Mostra só as secções onde aparecem todas as palavras da pesquisa, com elas realçadas.
func apply_filter(query: String) -> void:
	var words: Array = []
	for w in fold(query).split(" ", false):
		if String(w).length() >= 2:
			words.append(String(w))
	var shown := 0
	for s in sections:
		var hay := String(s.f_title) + "\n" + String(s.f_body)
		var ok := true
		for w in words:
			if not hay.contains(w):
				ok = false
				break
		(s.panel as Control).visible = ok
		(s.btn as Control).visible = ok
		(s.rtl as RichTextLabel).text = highlight(String(s.body), String(s.f_body), words)
		if ok:
			shown += 1
	_count.text = tr("%d secções") % shown
	_empty.visible = shown == 0
	_empty.text = tr("Nada encontrado para «%s». Experimenta outra palavra.") % query.strip_edges()
	if not words.is_empty():
		_scroll.scroll_vertical = 0

func jump_to(i: int) -> void:
	if i < 0 or i >= sections.size():
		return
	var panel: Control = sections[i].panel
	await get_tree().process_frame
	if is_instance_valid(panel):
		_scroll.scroll_vertical = int(panel.position.y)

## Texto em minúsculas e sem acentos, com o mesmo comprimento (as posições batem certo com o original).
static func fold(s: String) -> String:
	var t := s.to_lower()
	var out := PackedStringArray()
	out.resize(t.length())
	for i in t.length():
		var ch := t[i]
		out[i] = String(FOLD.get(ch, ch))
	return "".join(out)

## BBCode do texto com as palavras realçadas (os [ ] do texto ficam escapados).
static func highlight(text: String, folded: String, words: Array) -> String:
	var marks := PackedByteArray()
	marks.resize(text.length())
	for w in words:
		var from := 0
		while true:
			var at := folded.find(String(w), from)
			if at < 0:
				break
			for k in range(at, mini(at + String(w).length(), text.length())):
				marks[k] = 1
			from = at + 1
	var out := ""
	var i := 0
	while i < text.length():
		var j := i
		while j < text.length() and marks[j] == marks[i]:
			j += 1
		var seg := _escape(text.substr(i, j - i))
		out += (HL_OPEN + seg + HL_CLOSE) if marks[i] == 1 else seg
		i = j
	return out

static func _escape(s: String) -> String:
	return s.replace("[", "\u0001").replace("]", "[rb]").replace("\u0001", "[lb]")

func _close() -> void:
	# 164: depois de abrires o Como Jogar nesta versão, as secções novas deixam de ter NOVO.
	if int(GameState.progress.get("howto_seen_code", 0)) < ContentUpdate.APP_VERSION_CODE:
		GameState.progress["howto_seen_code"] = ContentUpdate.APP_VERSION_CODE
		GameState.save_progress()
	if overlay:
		queue_free()
	else:
		SceneRouter.go("main")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree():
		if overlay and SceneRouter.top_overlay() != self:
			return
		if not overlay and SceneRouter.has_overlay():
			return
		_close()
