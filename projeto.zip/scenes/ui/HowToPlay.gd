extends Control
## Regras em poucas linhas.

func _ready() -> void:
	%Back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	%Text.text = """OBJETIVO
Reduz a vida do inimigo a zero em 5 turnos. Vence 8 antes para ganhar a run. Cada ante o inimigo tem mais vida.

MANA
No turno N tens N+1 de mana (2 → 6). Criaturas e feitiços custam o número no canto. Feitiços custam 1 a menos (mínimo 1).
Terrenos são opcionais: na mão dão o bónus [Na Mão]; se os jogares, +1 mana permanente.

TURNO
A mão repõe-se até 6. Toca numa carta para a jogar. Criaturas ficam no tabuleiro (máx. 5) e atacam todas quando carregas em ATACAR. Feitiços contam no ataque desse turno.
CANALIZAR: liga o botão e toca numa carta para a descartar e comprar outra (3 por batalha, 4 no fácil, 2 no difícil).

A CASCATA
Dano = Poder × Mult. Primeiro cada criatura (+Poder e os seus efeitos), depois os feitiços, as formações, as cartas na mão e as relíquias — uma a uma. O mostrador mostra sempre a pré-visualização.

FORMAÇÕES
Pacto Dual (2 criaturas com o mesmo custo) · Tríade (3) · Bando Tribal (3+ criaturas) · Tempestade (3+ feitiços no turno) · Curva de Mana (custos 1-2-3-4-5) · Devoção (4+ da mesma cor) · Horda (5) · Convergência WUBRG (5 cores).

O INIMIGO
Depois do teu ataque ele contra-ataca: a criatura mais robusta que sobreviva bloqueia; senão levas tu. A tua vida repõe-se em cada batalha. Alguns inimigos têm habilidades (lê o texto por baixo do nome).

LOJA
Entre antes: compra cartas das cores do teu baralho, relíquias (os multiplicadores permanentes) e remove uma carta por visita.

CAMPANHA
Cada capítulo é um baralho com a sua dificuldade. Chega ao ante 4 para desbloquear o capítulo seguinte; ao ante 6 para abrir o ato seguinte. O Modo Livre abre tudo mas não conta."""
