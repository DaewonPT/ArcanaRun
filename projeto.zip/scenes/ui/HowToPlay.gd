class_name HowToPlay
extends Control
## Regras em poucas linhas. Abre como cena (do menu) ou como painel por cima da pausa.

var overlay := false

static func open_overlay() -> HowToPlay:
	var s: HowToPlay = load("res://scenes/ui/HowToPlay.tscn").instantiate()
	s.overlay = true
	SceneRouter.show_overlay(s)
	return s

func _ready() -> void:
	%Back.pressed.connect(func(): Sfx.select(); _close())
	if overlay:
		%Back.text = tr("◀ VOLTAR")
	_refresh_text()
	Settings.changed.connect(_refresh_text)

func _refresh_text() -> void:
	# Só ficheiros-recurso (.json) entram no APK; por isso o texto vive em i18n/howto.json.
	var parsed = JSON.parse_string(FileAccess.get_file_as_string("res://i18n/howto.json"))
	if parsed is Dictionary:
		%Text.text = String(parsed.get(Settings.effective_language(), parsed.get("pt", "")))

func _close() -> void:
	if overlay:
		queue_free()
	else:
		SceneRouter.go("main")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree():
		if overlay and SceneRouter.top_overlay() != self:
			return
		if not overlay and SceneRouter.has_overlay():
			return
		_close()
