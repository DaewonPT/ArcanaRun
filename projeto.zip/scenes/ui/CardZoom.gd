class_name CardZoom
extends Control
## Carta em grande (toque longo numa carta da mão, do tabuleiro ou de uma lista) com o texto
## completo, ou a descrição de uma relíquia. Toca em qualquer sítio para fechar.
## 0.10.0: os termos do glossário (data/glossary.json) aparecem sublinhados no texto da carta;
## tocar num deles mostra a explicação por baixo. O sigilo da carta aparece em fundo.

const COLOR_NAMES := {"white": "Branco", "blue": "Azul", "black": "Preto", "red": "Vermelho", "green": "Verde"}
const RARITY_NAMES := {"common": "Comum", "uncommon": "Incomum", "rare": "Rara", "mythic": "Mítica", "legendary": "Lendária"}

var _panel: PanelContainer
var _gloss_label: Label
var _link_hit := false
# 0.13.0: carta em grande em 3D (inclina com o telemóvel; no computador segue o rato).
const SHEEN_SHADER := preload("res://assets/shaders/card_sheen.gdshader")
var _tilt_on := false
var _tilt_rest := Vector2.ZERO
var _tilt_v := Vector2.ZERO
var _tilt_wait := 0.0
var _tilt_fixed := false      # testes e capturas: inclinação dada à mão
var _sheen: ColorRect
var _shadow: Panel
const TRIBE_NAMES := CardView.TRIBE_NAMES   # 0.13.0: a mesma lista (com Construto, Espírito, Fera e Planta)

static func show_card(card: CardInstance) -> void:
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_card(card.data, card)

# --- 0.19.0 (10): passar à carta seguinte sem fechar ---
## As cartas à volta (da mão, do grimório, da loja…) e a que está em grande. Deslizar para o lado (ou os botões
## ◀ ▶, ou as setas do teclado/comando) mostra a seguinte ou a anterior.
var _list: Array = []      # CardInstance ou CardData
var _index := -1
var _swipe_from := Vector2.ZERO
var _swiping := false
const SWIPE_PX := 70.0

## Abre `card` em grande com as vizinhas de `list` (CardInstance ou CardData); sem lista, como o show_card.
static func show_card_in(card, list: Array) -> CardZoom:
	var i := list.find(card)
	if i < 0 or list.size() < 2:
		if card is CardInstance:
			show_card(card)
		elif card is CardData:
			show_data(card)
		return null
	return show_list(list, i)

static func show_list(list: Array, index: int) -> CardZoom:
	if list.is_empty():
		return null
	var z := CardZoom.new()
	z._list = list.duplicate()
	z._index = clampi(index, 0, list.size() - 1)
	SceneRouter.show_overlay(z)
	z._build_current()
	return z

## A carta de agora (para os testes).
func current_item():
	return _list[_index] if _index >= 0 and _index < _list.size() else null

func _build_current() -> void:
	var it = _list[_index]
	if it is CardInstance:
		_build_card((it as CardInstance).data, it)
	elif it is CardData:
		_build_card(it, null)
	if _list.size() > 1:
		_add_nav()

## ◀ ▶ dos lados e «3 / 7» por baixo.
func _add_nav() -> void:
	for side in [-1, 1]:
		var b := UiKit.button("◀" if side < 0 else "▶", 72, 30)
		b.name = "Prev" if side < 0 else "Next"
		b.custom_minimum_size = Vector2(72, 96)
		b.set_meta("no_big", true)
		add_child(b)
		b.set_anchors_preset(Control.PRESET_CENTER_LEFT if side < 0 else Control.PRESET_CENTER_RIGHT)
		b.offset_top = -48.0
		b.offset_bottom = 48.0
		if side < 0:
			b.offset_left = 28.0
			b.offset_right = 100.0
		else:
			b.offset_left = -100.0
			b.offset_right = -28.0
		b.pressed.connect(go_step.bind(side))
	var count := UiKit.label("%d / %d" % [_index + 1, _list.size()], 18, UiKit.TEXT_DIM)
	count.name = "Counter"
	add_child(count)
	count.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	count.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	count.offset_left = -80.0
	count.offset_right = 80.0
	count.offset_top = -34.0
	count.offset_bottom = -8.0

## Passa à carta seguinte (+1) ou à anterior (−1) da lista, sem fechar (dá a volta nas pontas).
func go_step(step: int) -> CardZoom:
	if _list.size() < 2 or is_queued_for_deletion():
		return null
	var z := CardZoom.new()
	z._list = _list
	z._index = wrapi(_index + step, 0, _list.size())
	SceneRouter.show_overlay(z)
	z._build_current()
	Sfx.tick()
	if get_parent() != null:
		get_parent().remove_child(self)
	queue_free()
	return z

func _input(event: InputEvent) -> void:
	if _list.size() < 2 or is_queued_for_deletion() or SceneRouter.top_overlay() != self:
		return
	if event is InputEventMouseButton and (event as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
		var mb := event as InputEventMouseButton
		if mb.pressed:
			_swipe_from = mb.position
			_swiping = true
		elif _swiping:
			_swiping = false
			var d := mb.position - _swipe_from
			if absf(d.x) >= SWIPE_PX and absf(d.x) > absf(d.y) * 1.4:
				get_viewport().set_input_as_handled()   # o largar não fecha a janela
				go_step(1 if d.x < 0.0 else -1)
		return
	if event.is_action_pressed("ui_left"):
		get_viewport().set_input_as_handled()
		go_step(-1)
	elif event.is_action_pressed("ui_right"):
		get_viewport().set_input_as_handled()
		go_step(1)

func _in_battle() -> bool:
	var cur := get_tree().current_scene if is_inside_tree() else null
	return cur != null and cur.scene_file_path.contains("/battle/")

static func show_data(data: CardData) -> void:
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_card(data, null)

static func show_planeswalker(id: String) -> void:
	var p := CardDB.get_planeswalker(id)
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_patron(id, p)

## Texto simples em grande (intenção do inimigo, ajudas).
static func show_text(title: String, body: String, kind: String, accent: Color = UiKit.GOLD) -> void:
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_text(title, body, kind, UiKit.BG_LIGHT, accent)

## 0.16.0 (V43): o clima com a ilustração dele no topo da janela.
static func show_climate(id: String, extra: String = "") -> void:
	var c := CardDB.get_climate(id)
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	var body := z._window(z.tr(String(c.get("name", id))) + extra, z.tr("Clima Planar · regra deste ato"), Color(0.35, 0.82, 0.85), 560.0)
	var art := ArtLib.texture("background", "clim_" + String(c.get("art", id)) if String(c.get("art", "")) != "" else "clim_" + id)
	if art != null:
		var banner := Control.new()
		banner.name = "ClimateArt"
		banner.custom_minimum_size = Vector2(0, 176)
		banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
		banner.draw.connect(func():
			var r := Rect2(Vector2.ZERO, banner.size)
			ArtLib.draw_rounded(banner, art, r, 12.0, 0.45)
			var st := StyleBoxFlat.new()
			st.draw_center = false
			st.set_border_width_all(1)
			st.border_color = Color(1, 1, 1, 0.12)
			st.set_corner_radius_all(12)
			banner.draw_style_box(st, r))
		body.add_child(banner)
	body.add_child(UiKit.label(z.tr(String(c.get("text", ""))), 20, Color.WHITE, true))
	z._finish_window(body)

static func show_contract(c: Dictionary) -> void:
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	var reward := GameState.reward_text(c.get("reward", {}))
	var body := z.tr(String(c.get("text", ""))) + ("\n" + z.tr("Recompensa: %s.") % reward if reward != "" else "")
	z._build_text(z.tr(String(c.get("name", ""))), body, z.tr("Contrato · vale para esta batalha"), UiKit.BG_LIGHT, UiKit.GOLD)

static func show_seal(id: String) -> void:
	var sd := CardDB.get_seal(id)
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_text(z.tr(String(sd.get("name", id))), z.tr(String(sd.get("text", ""))), z.tr("Selo de carta"), UiKit.BG_LIGHT, CardView.seal_color(sd))

## 0.16.0 (V41, «B — imagem ao lado»): a relíquia com a ilustração ao lado do texto, a raridade num losango e o
## conjunto com as peças que já tens. `actions` (a loja): botões no fundo — [{text, price (−1: sem), enabled,
## tooltip, call}].
static func show_relic(id: String, actions: Array = []) -> void:
	var r: Dictionary = CardDB.relics.get(id, {})
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_relic(id, r, actions)

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.78))

const ZOOM_W := 470.0
const ZOOM_BW := 3.0
const ZOOM_R := 22
const ZOOM_ART_H := 214.0

var _zoom_id := ""

func _build_card(d: CardData, inst: CardInstance) -> void:
	_zoom_id = d.id
	# 0.14.1: visual "Arte em destaque", como a carta pequena — a ilustração a toda a largura em cima, com o
	# nome por cima (Lora, com sombra) e o custo numa esfera; o tipo e a raridade numa pílula a meio da linha
	# onde a arte acaba; o texto centrado, com o glossário e as cores; o Poder e a Vida em pílulas.
	var keys := CardFace.color_keys(d)
	var border := CardFace.border_color(d)
	var bgs := CardFace.backgrounds(d)
	var text_color := CardView.BODY_COLOR
	var dim_color := Color(0.74, 0.7, 0.86)
	var W := ZOOM_W
	var bw := ZOOM_BW
	_panel = UiKit.centered_panel(self, W, bgs[1], border)
	_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var ps := UiKit.flat(bgs[1], ZOOM_R, border, int(bw), 0)
	if d.rarity == "mythic":
		ps.border_color = CardView.MYTHIC_COLORS[0]
	if not Settings.performance_mode:
		if d.rarity == "mythic":
			ps.shadow_color = Color(1.0, 0.5, 0.25, 0.5)
			ps.shadow_size = 22
		else:
			ps.shadow_color = Color(0, 0, 0, 0.55)
			ps.shadow_size = 18
			ps.shadow_offset = Vector2(0, 8)
	_panel.add_theme_stylebox_override("panel", ps)
	if _panel.has_meta("light_surface"):
		_panel.remove_meta("light_surface")   # a carta tem o fundo dela (0.19.0, 296)
	var fogged := CardView.fog_hand and inst != null and inst.zone == CardInstance.Zone.HAND
	var art_tex: Texture2D = null if fogged else ArtLib.texture("card", d.id)
	var art := Rect2(bw, bw, W - 2.0 * bw, ZOOM_ART_H)
	# Camadas: a ilustração por trás; sem ela, o sigilo ou a paisagem; o resto desenhado por cima.
	var back := CardFace.new()
	back.name = "FaceBack"
	back.layer = 0
	_panel.add_child(back)
	var art_slot := Control.new()
	art_slot.name = "ArtSlot"
	art_slot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(art_slot)
	if art_tex == null:
		if d.is_land():
			var land := LandArt.new()
			land.card_id = d.id
			land.colors = d.colors.duplicate()
			land.ink = Color(CardView.LIGHT_TEXT, 0.3)
			land.window = Rect2(0.05, 0.24, 0.9, 0.7)
			land.position = art.position
			land.size = art.size
			art_slot.add_child(land)
		else:
			var sigil := CardSigil.new()
			sigil.card_id = d.id
			sigil.colors = d.colors.duplicate()
			sigil.ink = Color((CardFace.palette(keys[0])["border"] as Color).lerp(Color.WHITE, 0.25), 0.42)
			sigil.line_width = 2.0
			sigil.mouse_filter = Control.MOUSE_FILTER_IGNORE
			sigil.position = art.position
			sigil.size = art.size
			art_slot.add_child(sigil)
	var front := CardFace.new()
	front.name = "FaceFront"
	front.layer = 1
	_panel.add_child(front)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 0)
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(vbox)
	# Zona da arte (as peças por cima dela vão à mão: nome, esfera, pips e pílula do tipo).
	var top := Control.new()
	top.name = "ArtArea"
	top.custom_minimum_size = Vector2(0, art.end.y)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(top)
	var od := 58.0
	var orb := Rect2(W - bw - 12.0 - od, bw + 12.0, od, od)
	var cost_l := UiKit.label("+1" if d.is_land() else str(d.cost), 32, Color.WHITE)
	cost_l.name = "Cost"
	cost_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	cost_l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	CardZoom._text_shadow(cost_l, 0.85, 2, 0)
	top.add_child(cost_l)
	cost_l.position = orb.position
	cost_l.size = orb.size
	var name_l := UiKit.label(d.display_name(), 30, CardView.NAME_COLOR)
	name_l.name = "Name"
	name_l.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	CardZoom._text_shadow(name_l, 0.9, 2, 0)
	top.add_child(name_l)
	var name_x := bw + 20.0
	var name_w := orb.position.x - 12.0 - name_x
	_fit_one_line(name_l, name_w, 30, 22)
	name_l.position = Vector2(name_x, bw + 14.0)
	name_l.size = Vector2(name_w, maxf(name_l.custom_minimum_size.y, name_l.get_minimum_size().y))
	# Pips por baixo da esfera (no modo daltónico, com o símbolo da cor).
	var pip_rects: Array[Rect2] = []
	var pip_cols: Array[Color] = []
	var pip_y := orb.end.y + 8.0
	var pip_cx := orb.get_center().x
	if Settings.colorblind and not d.colors.is_empty():
		var i := 0
		for c in d.colors:
			var pip := CardIcon.new("pip", CardFace.palette(String(c)).get("pip", Color.WHITE), 22.0)
			pip.mana_color = String(c)
			top.add_child(pip)
			pip.position = Vector2(pip_cx - 11.0, pip_y + i * 25.0)
			i += 1
	elif d.colors.size() >= 2:
		for i in d.colors.size():
			pip_rects.append(Rect2(pip_cx - 8.0, pip_y + i * 21.0, 16.0, 16.0))
			pip_cols.append(CardFace.palette(String(d.colors[i])).get("pip", Color.WHITE))
	# Pílula do tipo: tipo (e tribo) e raridade, a meio da linha onde a arte acaba.
	var type_txt := ""
	if d.is_creature():
		type_txt = tr("Ficha") if d.token else tr("Criatura")
		if d.tribe != "":
			type_txt += " · " + tr(TRIBE_NAMES.get(d.tribe, d.tribe))
	elif d.is_enchantment():
		type_txt = tr("Encantamento")
	elif d.is_equipment():
		type_txt = tr("Equipamento")
	elif d.is_spell():
		type_txt = tr("Mágica") if d.subtype == "instant" else tr("Feitiço")
	elif d.is_curse():
		type_txt = tr("Maldição")
	else:
		type_txt = tr("Terreno")
	var pill_txt := "%s · %s" % [type_txt, tr(RARITY_NAMES.get(d.rarity, d.rarity.capitalize()))]
	var tl := UiKit.label(pill_txt, 15, Color.WHITE)
	tl.name = "TypeLabel"
	tl.uppercase = true
	tl.add_theme_font_override("font", CardView.type_font())
	tl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	tl.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	top.add_child(tl)
	var ph := 30.0
	var pcy := art.end.y - 3.0
	var icon_s := 16.0
	var gem_col: Color = CardFace.RARITY_GEM.get(d.rarity, Color(1, 1, 1, 0))
	var gem_half := 6.5 if gem_col.a > 0.0 else 0.0
	var gem_w := 6.0 + gem_half * 2.0 if gem_half > 0.0 else 0.0
	var tfont := tl.get_theme_font("font")
	var max_text := W - 2.0 * bw - 40.0 - 32.0 - icon_s - 8.0 - gem_w
	var tw := minf(max_text, ceilf(tfont.get_string_size(pill_txt.to_upper(), HORIZONTAL_ALIGNMENT_LEFT, -1, 15).x) + 1.0)
	var pill_w := 32.0 + icon_s + 8.0 + tw + gem_w
	var pill := Rect2(W * 0.5 - pill_w * 0.5, pcy - ph * 0.5, pill_w, ph)
	var icon_r := Rect2(pill.position.x + 16.0, pcy - icon_s * 0.5, icon_s, icon_s)
	tl.position = Vector2(icon_r.end.x + 8.0, pill.position.y)
	tl.size = Vector2(tw, ph)
	var gem_r := Rect2()
	if gem_half > 0.0:
		gem_r = Rect2(Vector2(tl.position.x + tw + 6.0, pcy - gem_half), Vector2(gem_half, gem_half) * 2.0)
	# O resto, por baixo da pílula.
	var body_m := MarginContainer.new()
	body_m.mouse_filter = Control.MOUSE_FILTER_IGNORE
	body_m.add_theme_constant_override("margin_left", 24)
	body_m.add_theme_constant_override("margin_right", 24)
	body_m.add_theme_constant_override("margin_top", int(ph * 0.5) + 12)
	body_m.add_theme_constant_override("margin_bottom", 16)
	vbox.add_child(body_m)
	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 10)
	inner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	body_m.add_child(inner)
	var kws: Array = inst.keywords() if inst != null and inst.data == d else d.keywords
	if not kws.is_empty() and not fogged:
		var kw_row := HBoxContainer.new()
		kw_row.alignment = BoxContainer.ALIGNMENT_CENTER
		kw_row.add_theme_constant_override("separation", 6)
		kw_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var kw_names: PackedStringArray = []
		for k in kws:
			var ic := CardIcon.new(String(k), text_color, 22.0)
			ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			kw_row.add_child(ic)
			kw_names.append(tr(String(CardData.KEYWORD_NAMES.get(k, k))))
		kw_row.add_child(UiKit.label(" · ".join(kw_names), 20, text_color))
		inner.add_child(kw_row)
	var body_txt := d.display_text_marked() if d.text != "" else tr("Sem efeito.")   # 0.19.0 (127)
	if fogged:
		body_txt = tr("??? — o Nevoeiro esconde o texto das cartas na mão.")
	var zoom_big := bool(Settings.opt("zoom_text"))   # 0.19.0 (148): A+ — a letra maior na carta em grande
	var body := _rich_text(body_txt, 29 if zoom_big else 23, text_color, true)
	inner.add_child(body)
	_gloss_label = UiKit.label("", 17, text_color, true)
	_gloss_label.visible = false
	inner.add_child(_gloss_label)
	# Poder (pílula azul) à esquerda e Vida (pílula vermelha) à direita.
	var power_box: Control = null
	var tough_box: Control = null
	if d.is_creature() or d.power > 0:
		var srow := HBoxContainer.new()
		srow.name = "Stats"
		srow.mouse_filter = Control.MOUSE_FILTER_IGNORE
		power_box = CardZoom._stat_pill(str(inst.power() if inst != null else d.power), 22.0)
		power_box.name = "PowerPill"
		srow.add_child(power_box)
		var gap := Control.new()
		gap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		gap.mouse_filter = Control.MOUSE_FILTER_IGNORE
		srow.add_child(gap)
		if d.is_creature():
			var life := ("%d / %d" % [inst.remaining(), inst.toughness()]) if inst != null else str(d.toughness)
			tough_box = CardZoom._stat_pill(life, 20.0)
			tough_box.name = "ToughPill"
			srow.add_child(tough_box)
		inner.add_child(srow)
	_zf = {"front": front, "back": back, "panel_bw": bw, "keys": keys, "bgs": bgs, "tex": art_tex, "art": art,
		"orb": orb, "pips": pip_rects, "pip_cols": pip_cols, "pill": pill, "pill_color": CardFace.PILL.get(CardView.type_key(d), CardFace.PILL["creature"]),
		"icon": "creature" if d.token else CardView.type_key(d), "icon_r": icon_r, "gem_r": gem_r, "gem": gem_col,
		"gem_glow": d.rarity == "rare" or d.rarity == "mythic", "ring": CardFace.RARITY_RING.get(d.rarity, Color(1, 1, 1, 0)),
		"gradient": keys.size() >= 2 and d.rarity != "mythic", "power": power_box, "tough": tough_box}
	_panel.resized.connect(_queue_zoom_face)
	inner.sort_children.connect(_queue_zoom_face)

	var extras: Array[String] = []
	if d.is_land():
		extras.append(tr("Terreno: jogá-lo é de graça e dá +1 mana para sempre; guardado na mão, dá o bónus [Na Mão]."))
	if not fogged:
		for k in kws:
			extras.append(tr(String(CardData.KEYWORD_TEXT.get(k, ""))) + ("  " + tr("(dada nesta batalha)") if inst != null and k in inst.granted_keywords else ""))
	if inst != null:
		var pb := power_breakdown(inst)   # 0.19.0 (102): de onde vem o Poder
		if pb != "":
			extras.append(pb)
		if inst.perm_power() != 0 or inst.perm_mult() != 0.0:
			var parts: Array[String] = []
			if inst.perm_power() != 0:
				parts.append(tr("+%d Poder") % inst.perm_power())
			if inst.perm_mult() != 0.0:
				parts.append(tr("+%s Mult") % Cascade.fmt_mult(inst.perm_mult()))
			extras.append(tr("Bónus permanente: %s") % " · ".join(PackedStringArray(parts)))
		if inst.power_bonus != 0 and pb == "":
			extras.append(tr("Nesta batalha: +%d Poder") % inst.power_bonus)
		if inst.damage > 0:
			extras.append(tr("Dano sofrido: %d") % inst.damage)
		if inst.kicked:
			extras.append(tr("★ Jogada com Reforço."))
		# 0.15.0: Veteranos, Persistir e a cópia do Selo do Espelho.
		if inst.vet_stars() > 0:
			extras.append("★".repeat(inst.vet_stars()) + " " + tr("Veterano: +%d Poder até ao fim da run.") % (inst.vet_stars() * BattleManager.VETERAN_POWER))
		if d.is_creature() and not inst.is_token() and inst.vet_stars() < BattleManager.VETERAN_STARS and int(inst.deck_entry.get("vet_attacks", 0)) > 0:
			var every := maxi(1, BattleManager.VETERAN_ATTACKS - int(GameState.relic_passive("veteran_fast")))
			extras.append(tr("Veterano: %d/%d ataques até à próxima estrela.") % [int(inst.deck_entry.get("vet_attacks", 0)), every * (inst.vet_stars() + 1)])
		if inst.persisted:
			extras.append(tr("Persistiu: já voltou uma vez nesta batalha."))
		if inst.temp_copy:
			extras.append(tr("Cópia do Selo do Espelho: desaparece no fim do turno."))
	if d.approx:
		extras.append(tr("≈ efeito aproximado da carta original"))
	if d.phyrexian > 0:   # 0.15.0 Mana de Sangue
		var life_each := maxi(1, BattleManager.PHYREXIAN_LIFE - int(GameState.relic_passive("phyrexian_cheap")))
		extras.append(tr("🩸 Mana de Sangue: %d do custo pode pagar-se com vida (%d de vida cada) quando falta mana.") % [d.phyrexian, life_each])
	if d.has_kicker():
		extras.append(tr("Reforço +%d mana: %s.") % [int(d.kicker.get("cost", 0)), d.display_kicker_text()])
	if d.plus:
		extras.append(tr("Versão +: os efeitos valem ×1,5."))
	if d.locked and not Stats.is_content_unlocked("card", d.id):
		extras.append(tr("Bloqueada: desbloqueia-se com uma conquista."))
	if d.flashback:
		extras.append(tr("↺ Recapitular: pode ser lançada a partir do cemitério; depois vai para o exílio até ao fim da batalha."))
	if d.fused_text != "":
		extras.append(tr("⚗ Habilidade fundida no Altar: %s") % tr(d.fused_text))
	if d.infected:
		extras.append(tr("☠ Infetada: Poder a dobrar; exila-se ao fim de %d utilizações (%d/%d).") % [BattleManager.INFECTED_USES, int(inst.deck_entry.get("uses", 0)) if inst != null else 0, BattleManager.INFECTED_USES])
	if d.is_back:
		extras.append(tr("⇄ Face transformada."))
	elif not d.transformed.is_empty():
		var back_face: Dictionary = d.transformed
		var progress_txt := ""
		if inst != null and inst.has_mission():
			progress_txt = tr("Missão %d/%d. ") % [inst.mission_count, inst.mission_target()]
		extras.append("⇄ " + progress_txt + tr("Vira em %s (%d ⚔): %s") % [tr(String(back_face.get("name", ""))), int(back_face.get("power", 0)), tr(String(back_face.get("text", "")))])
	if inst != null and inst.seal() != "":
		var seal_def := CardDB.get_seal(inst.seal())
		extras.append("◉ %s: %s" % [tr(String(seal_def.get("name", inst.seal()))), tr(String(seal_def.get("text", "")))])
	# 0.13.0: edição da carta (o brilho próprio fica por cima de tudo).
	var ed := inst.edition() if inst != null else ""
	if EffectResolver.EDITIONS.has(ed):
		extras.insert(0, String(EffectResolver.EDITIONS[ed]["symbol"]) + " " + EffectResolver.edition_text(ed))
		if not Settings.performance_mode:
			var fx := ColorRect.new()
			fx.name = "EditionFx"
			fx.mouse_filter = Control.MOUSE_FILTER_IGNORE
			fx.material = CardView.edition_material(ed)
			_panel.add_child(fx)
	# 0.12.0: estatísticas da carta nas tuas runs (fora das batalhas, para não encher o ecrã).
	if not fogged and not _in_battle():
		var cs := GameState.card_stat(d.id)
		if not cs.is_empty():
			extras.append(tr("Nas tuas runs: %s de dano · jogada %d× · em %d runs (%d vitórias)") % [Cascade.fmt_int(int(cs.get("dmg", 0))), int(cs.get("plays", 0)), int(cs.get("runs", 0)), int(cs.get("wins", 0))])
		# 0.19.0 (57): os números desta run (com uma run a decorrer e a carta do baralho dela).
		if inst != null and inst.entry_index >= 0:
			var rd := int((GameState.run_log.get("card_dmg", {}) as Dictionary).get(d.id, 0)) if GameState.run_log.get("card_dmg") is Dictionary else 0
			var rp := int((GameState.run_log.get("card_plays", {}) as Dictionary).get(d.id, 0)) if GameState.run_log.get("card_plays") is Dictionary else 0
			if rd > 0 or rp > 0:
				extras.append(tr("Nesta run: %s de dano · jogada %d×") % [Cascade.fmt_int(rd), rp])
		# 0.13.0: mestria (Bronze 15, Prata 50, Ouro 120 jogadas).
		var lv := GameState.mastery_of(cs)
		var plays := int(cs.get("plays", 0))
		if lv >= GameState.MASTERY_PLAYS.size():
			extras.append("★ " + tr("Mestria %s: a carta tem a moldura dourada.") % tr(GameState.MASTERY_NAMES[lv - 1]))
		elif not d.token and not d.is_curse():
			var next_txt := tr("Mestria: %d/%d jogadas para %s.") % [plays, int(GameState.MASTERY_PLAYS[lv]), tr(GameState.MASTERY_NAMES[lv])]
			extras.append(("★ " + tr("Mestria %s.") % tr(GameState.MASTERY_NAMES[lv - 1]) + " " if lv > 0 else "") + next_txt)
	# 0.19.0 (55): o que esta carta ganhou nesta run, num toque (do histórico do baralho).
	if inst != null and inst.entry_index >= 0 and not _in_battle():
		for line in card_history_lines(d.id):
			extras.append(line)
	if not extras.is_empty():
		inner.add_child(UiKit.label("\n".join(PackedStringArray(extras)), 21 if zoom_big else 17, dim_color, true))

	var hint := UiKit.label(tr("Toca para fechar"), 16, dim_color)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	inner.add_child(hint)
	if art_tex != null:
		_add_art_only(art_tex, d.display_name())
	_add_text_size(d, inst, art_tex != null)
	_sync_zoom_face()   # já com a ilustração; o tamanho certo chega depois do layout (resized → outra vez)
	# 0.19.0 (45): abrir em grande tira o NOVO; (44) na Coleção e no Construtor, a estrela das favoritas.
	if GameState.mark_opened("cards", d.id):
		GameState.save_progress()
	if not d.token and not d.is_curse() and _in_scene(["Collection", "DeckBuilder"]):
		_add_favorite_toggle(d.id)
	# 0.19.0 (53): uma carta à venda (loja, booster) compara-se com uma do teu baralho.
	if inst != null and inst.entry_index < 0 and not GameState.deck.is_empty() and _in_scene(["Shop"]) and not d.token:
		_add_compare_button(inst)
	# 0.19.0 (64): uma carta do baralho da run (fora da batalha) pode ficar protegida («não remover»).
	if inst != null and inst.entry_index >= 0 and inst.entry_index < GameState.deck.size() and not _in_battle() and not d.is_curse():
		_add_protect_toggle(inst.entry_index)
	UiKit.pop_in(_panel)
	_setup_tilt()

func _in_scene(names: Array) -> bool:
	var cur := get_tree().current_scene if is_inside_tree() else null
	return cur != null and String(cur.name) in names

## 44: ☆/★ por cima, à direita — marcar a carta como favorita.
func _add_favorite_toggle(card_id: String) -> void:
	var b := UiKit.button("", 48, 18)
	b.name = "Favorite"
	b.custom_minimum_size.x = 190
	var paint := func():
		var on := GameState.is_favorite(card_id)
		b.text = ("★ " + tr("FAVORITA")) if on else ("☆ " + tr("FAVORITA"))
		b.add_theme_color_override("font_color", UiKit.GOLD if on else Color.WHITE)
	paint.call()
	b.pressed.connect(func():
		Sfx.select()
		GameState.toggle_favorite(card_id)
		paint.call())
	add_child(b)
	b.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	b.offset_left = -214.0
	b.offset_right = -24.0
	b.offset_top = 18.0
	b.offset_bottom = 66.0

func _add_compare_button(inst: CardInstance) -> void:
	var b := UiKit.button(tr("COMPARAR"), 48, 17)
	b.name = "Compare"
	b.custom_minimum_size.x = 190
	b.pressed.connect(func():
		Sfx.select()
		ZoneViewer.open_deck(tr("COMPARAR COM QUAL?"), func(other: CardInstance):
			show_compare(inst, other)))
	add_child(b)
	b.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	b.offset_left = -214.0
	b.offset_right = -24.0
	b.offset_top = -72.0
	b.offset_bottom = -24.0

## 53: duas cartas lado a lado (a da loja e uma do teu baralho), com o Poder, o custo e o texto.
static func show_compare(a: CardInstance, b: CardInstance) -> Control:
	var root := Control.new()
	root.name = "CompareWindow"
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(UiKit.dim(0.85))
	SceneRouter.show_overlay(root)
	var body := UiKit.window(root, 900, TranslationServer.translate("COMPARAR"), UiKit.GOLD, func(): UiKit.close_animated(root))
	var row := HBoxContainer.new()
	row.name = "Pair"
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 30)
	body.add_child(row)
	for c: CardInstance in [a, b]:
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 6)
		col.custom_minimum_size.x = 360
		row.add_child(col)
		var head := UiKit.label(TranslationServer.translate("À venda") if c == a else TranslationServer.translate("No teu baralho"), 16, UiKit.TEXT_DIM)
		head.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(head)
		var v: CardView = load("res://scenes/ui/CardView.tscn").instantiate()
		v.size_scale = 1.25
		v.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		col.add_child(v)
		v.setup(c)
		var other: CardInstance = b if c == a else a
		var dp: int = c.power() - other.power()
		var facts: String = TranslationServer.translate("Poder %d") % c.power() + (" (%s%d)" % ["+" if dp > 0 else "", dp] if dp != 0 else "") + "  ·  " + (TranslationServer.translate("Terreno") if c.data.is_land() else TranslationServer.translate("Custo %d") % c.data.cost)
		var fl := UiKit.label(facts, 17, Color(0.6, 0.95, 0.65) if dp > 0 else (Color(1.0, 0.6, 0.55) if dp < 0 else Color.WHITE))
		fl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(fl)
		var tl := UiKit.label(c.data.display_text(), 15, Color(0.9, 0.88, 0.96), true)
		tl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(tl)
	UiKit.pop_in(body.get_meta("panel"))
	return root

## 64: 🛡 NÃO REMOVER — a loja pede confirmação a dobrar para remover (ou vender) estas cartas.
func _add_protect_toggle(entry_index: int) -> void:
	var b := UiKit.button("", 48, 17)
	b.name = "Protect"
	b.custom_minimum_size.x = 230
	var paint := func():
		var on := bool(GameState.deck[entry_index].get("protected", false)) if entry_index < GameState.deck.size() else false
		b.text = ("🛡 " + tr("PROTEGIDA")) if on else ("🛡 " + tr("NÃO REMOVER"))
		b.add_theme_color_override("font_color", Color(0.6, 0.9, 1.0) if on else Color.WHITE)
	paint.call()
	b.pressed.connect(func():
		if entry_index >= GameState.deck.size():
			return
		Sfx.select()
		var e: Dictionary = GameState.deck[entry_index]
		e["protected"] = not bool(e.get("protected", false))
		paint.call())
	add_child(b)
	b.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	b.offset_left = 24.0
	b.offset_right = 254.0
	b.offset_top = 18.0
	b.offset_bottom = 66.0

## 55: as linhas do histórico do baralho (nesta run) sobre uma carta: «Ante 3 · Loja: +10 Poder».
static func card_history_lines(card_id: String) -> Array[String]:
	var out: Array[String] = []
	for e in GameState.deck_log:
		if not (e is Dictionary) or String(e.get("id", "")) != card_id:
			continue
		var what := deck_log_text(e)
		if what != "":
			out.append("✎ " + TranslationServer.translate("Ante %d") % int(e.get("ante", 1)) + (" · " + TranslationServer.translate(String(e.get("place", ""))) if String(e.get("place", "")) != "" else "") + ": " + what)
	return out

## O que uma linha do histórico do baralho diz (sem o nome da carta).
static func deck_log_text(e: Dictionary) -> String:
	var detail := String(e.get("detail", ""))
	match String(e.get("kind", "")):
		"add":
			return TranslationServer.translate("entrou no baralho") + ((" (" + EffectResolver.edition_name(detail) + ")") if detail != "" else "")
		"curse":
			return TranslationServer.translate("entrou no baralho (maldição)")
		"remove":
			return TranslationServer.translate("exilada até ao fim da run") if detail == "exiled" else TranslationServer.translate("saiu do baralho")
		"plus":
			return TranslationServer.translate("forjada (versão +)")
		"edition":
			return TranslationServer.translate("edição %s") % EffectResolver.edition_name(detail)
		"seal":
			return TranslationServer.translate("recebeu o %s") % TranslationServer.translate(String(CardDB.get_seal(detail).get("name", detail)))
		"power":
			return TranslationServer.translate("%s permanente") % detail if detail.contains("Mult") else TranslationServer.translate("%s Poder permanente") % detail
		"fuse":
			var v := CardDB.get_card(detail)
			return TranslationServer.translate("herdou a habilidade de %s") % (v.display_name() if v != null else detail)
	return ""

## 0.19.0 (148): «A+» ao lado da carta (por baixo do SÓ A ARTE) — a letra maior, até voltares a tocar (A−).
func _add_text_size(d: CardData, inst: CardInstance, below_art: bool) -> void:
	var on := bool(Settings.opt("zoom_text"))
	var b := UiKit.button("A−" if on else "A+", 48, 20)
	b.name = "TextSize"
	b.custom_minimum_size.x = 72
	b.tooltip_text = tr("Letra mais pequena") if on else tr("Letra maior")
	add_child(b)
	b.pressed.connect(func():
		Sfx.select()
		Settings.set_opt("zoom_text", not bool(Settings.opt("zoom_text")))
		reopen(d, inst))
	var place := func():
		if not is_instance_valid(b) or not is_instance_valid(_panel):
			return
		var c := size * 0.5
		var x := c.x + _panel.size.x * 0.5 + 18.0
		if x + 168.0 > size.x - 12.0:
			x = c.x - _panel.size.x * 0.5 - 18.0 - b.size.x
		b.position = Vector2(x, c.y - _panel.size.y * 0.5 + (62.0 if below_art else 6.0))
		if is_instance_valid(_listen):
			_listen.position = b.position + Vector2(0, 58)
	_panel.resized.connect(place)
	resized.connect(place)
	place.call_deferred()
	# 0.19.0 (255): ouvir a carta (nome, custo, Poder, texto e a ilustração) com a voz do telemóvel.
	_listen = UiKit.button("", 48, 20)
	_listen.name = "Listen"
	_listen.custom_minimum_size.x = 72
	_listen.tooltip_text = tr("Ouvir a carta")
	var sp := CardIcon.new("speaker", Color(0.9, 0.88, 1.0), 22.0)
	sp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	sp.position = Vector2(25, 13)
	_listen.add_child(sp)
	_listen.pressed.connect(func():
		if not Speech.say(Speech.card_text(d)):
			SceneRouter.toast(tr("Este telemóvel não tem uma voz instalada para ler o texto."), 2.6))
	add_child(_listen)
	if bool(Settings.opt("tts_auto")):
		Speech.say.call_deferred(Speech.card_text(d))

var _listen: Button

## Volta a abrir a mesma carta (com a letra nova), na mesma lista.
func reopen(d: CardData, inst: CardInstance) -> CardZoom:
	var z := CardZoom.new()
	z._list = _list
	z._index = _index
	SceneRouter.show_overlay(z)
	if not _list.is_empty():
		z._build_current()
	else:
		z._build_card(d, inst)
	if get_parent() != null:
		get_parent().remove_child(self)
	queue_free()
	return z

## 0.16.1 (53): «SÓ A ARTE» ao lado da carta — a ilustração sozinha, no ecrã todo (ArtViewer).
func _add_art_only(tex: Texture2D, title: String) -> void:
	var b := UiKit.button(tr("SÓ A ARTE"), 48, 17)
	b.name = "ArtOnly"
	b.custom_minimum_size.x = 168
	UiKit.button_icon(b, "star", Color.WHITE, 18.0, false)
	add_child(b)
	b.pressed.connect(func():
		Sfx.select()
		ArtViewer.open(tex, title))
	# Ao lado direito da carta (o painel está centrado no ecrã).
	var place := func():
		if not is_instance_valid(b) or not is_instance_valid(_panel):
			return
		var c := size * 0.5
		var x := c.x + _panel.size.x * 0.5 + 18.0
		if x + b.size.x > size.x - 12.0:
			x = c.x - _panel.size.x * 0.5 - 18.0 - b.size.x
		b.position = Vector2(x, c.y - _panel.size.y * 0.5 + 6.0)
	_panel.resized.connect(place)
	resized.connect(place)
	place.call_deferred()

# --- 0.14.1: camadas desenhadas da carta em grande ---

var _zf := {}
var _zf_queued := false

func _queue_zoom_face() -> void:
	if _zf_queued:
		return
	_zf_queued = true
	_sync_zoom_face.call_deferred()

## Põe as peças desenhadas nos sítios certos (as pílulas do Poder e da Vida dependem do layout).
func _sync_zoom_face() -> void:
	_zf_queued = false
	if _zf.is_empty() or _panel == null or not is_instance_valid(_panel):
		return
	var size_now := _panel.size
	for k in ["back", "front"]:
		var f: CardFace = _zf[k]
		f.card_size = size_now
		f.radius = float(ZOOM_R)
		f.border_width = float(_zf["panel_bw"])
		f.keys = _zf["keys"]
		f.bg_top = (_zf["bgs"] as Array)[0]
		f.bg_bottom = (_zf["bgs"] as Array)[1]
		f.texture = _zf["tex"]
		f.art_rect = _zf["art"]
		f.art_radius = maxf(0.0, float(ZOOM_R) - float(_zf["panel_bw"]))
		f.art_tint = (CardFace.palette((_zf["keys"] as Array)[0])["border"] as Color).darkened(0.5)
		f.queue_redraw()
	var ff: CardFace = _zf["front"]
	ff.gradient_border = bool(_zf["gradient"])
	ff.ring_color = _zf["ring"]
	ff.ring_width = 1.5
	ff.orb_rect = _zf["orb"]
	ff.orb_glow = not Settings.performance_mode
	ff.pip_rects = _zf["pips"]
	ff.pip_colors = _zf["pip_cols"]
	ff.pill_rect = _zf["pill"]
	ff.pill_color = _zf["pill_color"]
	ff.pill_icon = String(_zf["icon"])
	ff.pill_icon_rect = _zf["icon_r"]
	ff.gem_rect = _zf["gem_r"]
	ff.gem_color = _zf["gem"]
	ff.gem_glow = bool(_zf["gem_glow"])
	ff.power_rect = Rect2()
	ff.tough_rect = Rect2()
	var pb = _zf["power"]
	if pb is Control and is_instance_valid(pb):
		ff.power_rect = _rect_in(pb, _panel)
		ff.power_icon_rect = CardZoom._pill_icon_rect(pb, _panel)
	var tb = _zf["tough"]
	if tb is Control and is_instance_valid(tb):
		ff.tough_rect = _rect_in(tb, _panel)
		ff.tough_icon_rect = CardZoom._pill_icon_rect(tb, _panel)

## Pílula do Poder ou da Vida: o número (Lora) e o lugar do ícone (desenhado pela frente da carta).
static func _stat_pill(text: String, icon_px: float) -> Control:
	var box := Control.new()
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var l := UiKit.label(text, 26, Color.WHITE)
	l.name = "Num"
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	box.add_child(l)
	var f := l.get_theme_font("font")
	var tw := ceilf(f.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, 26).x) + 2.0 if f != null else 40.0
	var h := 46.0
	box.custom_minimum_size = Vector2(16.0 + tw + 6.0 + icon_px + 16.0, h)
	box.set_meta("icon_px", icon_px)
	box.set_meta("text_w", tw)
	l.position = Vector2(16.0, 0.0)
	l.size = Vector2(tw, h)
	return box

static func _pill_icon_rect(box: Control, root: Control) -> Rect2:
	var r := _rect_in(box, root)
	var px := float(box.get_meta("icon_px", 20.0))
	var tw := float(box.get_meta("text_w", 30.0))
	return Rect2(r.position + Vector2(16.0 + tw + 6.0, (r.size.y - px) * 0.5), Vector2(px, px))

## Sombra das letras por cima da ilustração (nome e custo).
static func _text_shadow(l: Label, alpha: float, off: int, blur: int) -> void:
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, alpha))
	l.add_theme_constant_override("shadow_offset_x", 0)
	l.add_theme_constant_override("shadow_offset_y", off)
	l.add_theme_constant_override("shadow_outline_size", blur)

static func _rect_in(c: Control, root: Control) -> Rect2:
	var p := Vector2.ZERO
	var n: Node = c
	while n != null and n != root:
		if n is Control:
			p += (n as Control).position
		n = n.get_parent()
	return Rect2(p, c.size)

## Encolhe a letra até o texto caber numa linha (até min_fs); se não couber, deixa partir em duas.
static func _fit_one_line(l: Label, avail: float, max_fs: int, min_fs: int) -> void:
	var font := l.get_theme_font("font")
	var fs := max_fs
	while fs > min_fs and font != null and font.get_string_size(l.text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x > avail:
		fs -= 1
	l.add_theme_font_size_override("font_size", fs)
	var two := font != null and font.get_string_size(l.text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x > avail
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART if two else TextServer.AUTOWRAP_OFF
	l.max_lines_visible = 2 if two else -1
	var two_h := ceilf(font.get_height(fs) * 2.0 + l.get_theme_constant("line_spacing")) + 1.0 if font != null else fs * 2.6
	l.custom_minimum_size = Vector2(0, two_h if two else 0.0)

# --- 0.13.0: efeito 3D ---

func _setup_tilt() -> void:
	if not Settings.tilt_3d or not Settings.motion_ok() or Settings.performance_mode or _panel == null:
		return
	_tilt_on = true
	_tilt_wait = Settings.dur(0.16) + 0.06   # deixa acabar a entrada animada
	_tilt_rest = SceneRouter.tilt()          # a forma como estás a segurar o telemóvel conta como "direito"
	var center := _panel.get_parent()
	_shadow = Panel.new()
	_shadow.name = "TiltShadow"
	_shadow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_shadow.add_theme_stylebox_override("panel", UiKit.flat(Color(0, 0, 0, 0.55), 18))
	_shadow.modulate.a = 0.0
	center.add_child(_shadow)
	center.move_child(_shadow, _panel.get_index())   # por trás da carta
	_sheen = ColorRect.new()
	_sheen.name = "TiltSheen"
	_sheen.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var m := ShaderMaterial.new()
	m.shader = SHEEN_SHADER
	_sheen.material = m
	_sheen.modulate.a = 0.0
	center.add_child(_sheen)   # por cima da carta
	set_process(true)

## Inclinação fixa (−1 a 1), para os testes e as capturas.
func set_tilt(t: Vector2) -> void:
	_tilt_fixed = true
	_tilt_wait = 0.0
	_tilt_v = t
	_apply_tilt(t, 1.0)

func _process(delta: float) -> void:
	if not _tilt_on or _panel == null or not is_instance_valid(_panel):
		return
	if not _tilt_fixed:
		var target := Vector2.ZERO
		if Input.get_accelerometer() != Vector3.ZERO:
			target = ((SceneRouter.tilt() - _tilt_rest) * 2.4).clamp(Vector2(-1, -1), Vector2(1, 1))
		else:
			var r := _panel.get_global_rect()
			if r.size.x > 0.0 and r.grow(60.0).has_point(get_global_mouse_position()):
				target = ((get_global_mouse_position() - r.get_center()) / (r.size * 0.5)).clamp(Vector2(-1, -1), Vector2(1, 1))
		_tilt_v = _tilt_v.lerp(target, clampf(delta * 6.0, 0.0, 1.0))
	if _tilt_wait > 0.0:
		_tilt_wait -= delta
		return
	_apply_tilt(_tilt_v, clampf(delta * 5.0, 0.0, 1.0))

func _apply_tilt(t: Vector2, fade: float) -> void:
	_panel.pivot_offset = _panel.size / 2.0
	_panel.rotation = t.x * 0.03
	_panel.scale = Vector2(1.0 - 0.045 * absf(t.x), 1.0 - 0.03 * absf(t.y))
	for c in [_shadow, _sheen]:
		var ctl := c as Control
		if ctl == null:
			continue
		if ctl.custom_minimum_size != _panel.size:
			ctl.custom_minimum_size = _panel.size
		ctl.size = _panel.size
		ctl.pivot_offset = _panel.pivot_offset
		ctl.rotation = _panel.rotation
		ctl.scale = _panel.scale
	if _sheen != null:
		_sheen.position = _panel.position
		_sheen.modulate.a = lerpf(_sheen.modulate.a, 1.0, fade)
		var m := _sheen.material as ShaderMaterial
		m.set_shader_parameter("tilt", t)
		m.set_shader_parameter("size_px", _panel.size)
	if _shadow != null:
		# A sombra foge da luz: parece que a carta levanta do ecrã.
		_shadow.position = _panel.position + Vector2(-t.x * 18.0, 14.0 - t.y * 12.0)
		_shadow.modulate.a = lerpf(_shadow.modulate.a, 0.55 + 0.35 * minf(1.0, t.length()), fade)

## 0.16.0 (V44): as janelas de texto com a moldura comum — faixa de título na cor do tipo, cantos dourados,
## sombra e ✕. Tocar em qualquer sítio fora dos botões fecha, como antes.
func _build_text(title: String, body_text: String, kind: String, _bg: Color, accent: Color) -> void:
	var body := _window(title, kind, accent)
	body.add_child(UiKit.label(body_text, 22, Color.WHITE, true))
	_finish_window(body)

func _window(title: String, subtitle: String, accent: Color, width: float = 540.0) -> VBoxContainer:
	var body := UiKit.window(self, width, title, accent, close, subtitle)
	_panel = body.get_meta("panel")
	_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return body

func _finish_window(body: VBoxContainer) -> void:
	var hint := UiKit.label(tr("Toca para fechar"), 15, UiKit.TEXT_DIM)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	body.add_child(hint)
	UiKit.pop_in(_panel)

## Losango da raridade (na faixa do título): «◆ Comum».
static func _rarity_badge(text: String, col: Color) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.name = "Rarity"
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 7)
	row.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var d := Control.new()
	d.custom_minimum_size = Vector2(14, 14)
	d.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	d.mouse_filter = Control.MOUSE_FILTER_IGNORE
	d.draw.connect(func():
		var c := d.size * 0.5
		d.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -7), c + Vector2(7, 0), c + Vector2(0, 7), c + Vector2(-7, 0)]), col.lightened(0.15))
		d.draw_colored_polygon(PackedVector2Array([c + Vector2(0, -3), c + Vector2(3, 0), c + Vector2(0, 3), c + Vector2(-3, 0)]), Color(1, 1, 1, 0.55)))
	row.add_child(d)
	var l := UiKit.label(text, 15, col.lightened(0.3))
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(l)
	return row

func _build_relic(id: String, r: Dictionary, actions: Array) -> void:
	var ring := RelicView.ring_color(r)
	var rarity := tr("Relíquia de boss") if bool(r.get("boss", false)) else (tr("Lendária") if bool(r.get("legendary", false)) else (tr("Bênção do Santuário") if bool(r.get("blessing", false)) else tr(RARITY_NAMES.get(String(r.get("rarity", "common")), "Comum"))))
	var body := _window(tr(String(r.get("name", id))), "", ring, 620.0)
	var tl: Label = body.get_meta("title")
	var band_row := tl.get_parent().get_parent() as HBoxContainer
	if band_row != null:
		var badge := _rarity_badge(rarity, ring)
		band_row.add_child(badge)
		band_row.move_child(badge, maxi(0, band_row.get_child_count() - 2))
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 18)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	body.add_child(top)
	var medal := RelicView.new()
	medal.name = "RelicArt"
	medal.mouse_filter = Control.MOUSE_FILTER_IGNORE
	medal.custom_minimum_size = Vector2(104, 104)
	medal.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	top.add_child(medal)
	medal.setup(id)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 6)
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(col)
	col.add_child(UiKit.label(tr(String(r.get("text", ""))), 20, Color.WHITE, true))
	if id in GameState.relic_ids and GameState.relic_scaling_text(id) != "":
		col.add_child(UiKit.label(GameState.relic_scaling_text(id), 16, Color(0.55, 0.95, 0.66), true))
	if id in GameState.stolen_relics:
		col.add_child(UiKit.label(tr("Roubada: desligada até ao fim desta batalha."), 16, Color(1.0, 0.55, 0.5), true))
	# 0.19.0 (62, 97): o dano desta run e quanto dá vendida.
	if id in GameState.relic_ids or id in GameState.boss_relics:
		var rd := int((GameState.run_log.get("relic_dmg", {}) as Dictionary).get(id, 0)) if GameState.run_log.get("relic_dmg") is Dictionary else 0
		var facts: Array[String] = [tr("Deu %s de dano nesta run") % Cascade.fmt_int(rd)]
		if id in GameState.relic_ids and not (id in GameState.relic_locked):
			facts.append(tr("vende-se por %d ouro") % GameState.relic_sell_price(id))
		var fl := UiKit.label("  ·  ".join(PackedStringArray(facts)), 16, Color(0.85, 0.82, 0.95), true)
		fl.name = "RelicFacts"
		col.add_child(fl)
	var rs := CardDB.relic_set_of(id)   # 0.13.0: conjuntos de relíquias
	if not rs.is_empty():
		body.add_child(_set_box(rs))
	if not actions.is_empty():
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		body.add_child(row)
		for a in actions:
			row.add_child(_action_button(a))
	_finish_window(body)

## As peças do conjunto (as que tens com cor e um visto; as que faltam apagadas) e o bónus.
func _set_box(rs: Dictionary) -> PanelContainer:
	var members: Array = rs.get("relics", [])
	var have := 0
	for m in members:
		if String(m) in GameState.relic_ids or String(m) in GameState.boss_relics:
			have += 1
	var box := PanelContainer.new()
	box.name = "SetBox"
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_theme_stylebox_override("panel", UiKit.flat(Color(1, 1, 1, 0.04), 12, Color(1, 1, 1, 0.08), 1, 10))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(v)
	v.add_child(UiKit.label(tr("Conjunto: %s (%d/%d)") % [tr(String(rs.get("name", ""))), have, members.size()], 16, Color(1.0, 0.88, 0.62)))
	var pieces := HBoxContainer.new()
	pieces.add_theme_constant_override("separation", 8)
	pieces.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(pieces)
	for m in members:
		var mid := String(m)
		var owned := mid in GameState.relic_ids or mid in GameState.boss_relics
		var pv := RelicView.new()
		pv.mouse_filter = Control.MOUSE_FILTER_IGNORE
		pv.custom_minimum_size = Vector2(40, 40)
		pieces.add_child(pv)
		pv.setup(mid)
		pv.tooltip_text = tr(String((CardDB.relics.get(mid, {}) as Dictionary).get("name", mid)))
		if owned:
			var ck := CardIcon.new("check", Color.WHITE, 12.0)
			var dot := Control.new()
			dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
			dot.draw.connect(func(): dot.draw_circle(dot.size * 0.5, 9.0, Color(0.12, 0.62, 0.34)))
			pv.add_child(dot)
			dot.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
			dot.offset_left = -14.0
			dot.offset_top = -14.0
			dot.offset_right = 4.0
			dot.offset_bottom = 4.0
			dot.add_child(ck)
			ck.set_anchors_preset(Control.PRESET_CENTER)
			ck.offset_left = -6.0
			ck.offset_right = 6.0
			ck.offset_top = -6.0
			ck.offset_bottom = 6.0
		else:
			pv.modulate = Color(0.42, 0.42, 0.48, 0.85)
	v.add_child(UiKit.label(tr(String(rs.get("text", ""))), 14, UiKit.TEXT_DIM, true))
	return box

## Botão de ação de uma janela (VENDER na loja): o texto, a moeda com o preço e desligado quando não dá.
func _action_button(a: Dictionary) -> Button:
	var b := UiKit.button("", 54, 20, UiKit.PRIMARY)
	b.name = "Action"
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.set_meta("haptic", true)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 8)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(row)
	row.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var l := UiKit.label(String(a.get("text", "")), 20, Color.WHITE)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(l)
	var price := int(a.get("price", -1))
	if price >= 0:
		var pr := UiKit.price(price, true, 18)
		(pr.get_meta("label") as Label).add_theme_color_override("font_color", Color.WHITE)
		row.add_child(pr)
	b.disabled = not bool(a.get("enabled", true))
	b.tooltip_text = String(a.get("tooltip", ""))
	if not b.disabled:
		UiKit.gold_plate(b, true)
	var cb: Callable = a.get("call", Callable())
	b.pressed.connect(func():
		close()
		if cb.is_valid():
			cb.call())
	return b

## 0.16.0 (V42): o patrono com o retrato, a lealdade em pontos e cada habilidade numa linha com o custo numa gema.
func _build_patron(id: String, p: Dictionary) -> void:
	var col: Color = CardView.COLORS.get(String(p.get("color", "colorless")), UiKit.GOLD)
	var active := String(GameState.planeswalker.get("id", "")) == id
	var mx := int(p.get("max_loyalty", 6))
	var l := GameState.planeswalker_loyalty() if active else 0
	var body := _window(tr(String(p.get("name", id))), "", col, 620.0)
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 18)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	body.add_child(top)
	var art := ArtLib.texture("portrait", id)
	var face := Control.new()
	face.name = "PatronArt"
	face.custom_minimum_size = Vector2(104, 104)
	face.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	face.mouse_filter = Control.MOUSE_FILTER_IGNORE
	face.draw.connect(func():
		var c := face.size * 0.5
		var rad := minf(face.size.x, face.size.y) * 0.5
		face.draw_circle(c, rad, Color(0.08, 0.06, 0.12))
		if art != null:
			ArtLib.draw_round(face, art, c, rad - 3.0)
		var st := StyleBoxFlat.new()
		st.draw_center = false
		st.set_border_width_all(3)
		st.border_color = col
		st.set_corner_radius_all(int(rad))
		face.draw_style_box(st, Rect2(Vector2.ZERO, face.size)))
	top.add_child(face)
	var info := VBoxContainer.new()
	info.add_theme_constant_override("separation", 6)
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	info.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(info)
	info.add_child(UiKit.label((tr("Patrono") + "  ·  " + tr("Lealdade %d/%d") % [l, mx]) if active else tr("Patrono"), 15, col.lightened(0.3)))
	var dots := Control.new()
	dots.name = "Loyalty"
	dots.custom_minimum_size = Vector2(mx * 20.0, 16.0)
	dots.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dots.draw.connect(func():
		for k in mx:
			var c := Vector2(8.0 + 20.0 * k, 8.0)
			if k < l:
				dots.draw_circle(c, 7.0, col.lightened(0.15))
				dots.draw_circle(c + Vector2(-2, -2), 2.5, Color(1, 1, 1, 0.5))
			else:
				dots.draw_circle(c, 7.0, Color(1, 1, 1, 0.15)))
	info.add_child(dots)
	info.add_child(UiKit.label(tr(String(p.get("text", ""))), 17, Color.WHITE, true))
	for sk in p.get("skills", []):
		var cost := int(sk.get("cost", 0))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		body.add_child(row)
		var gem := SkillGem.new(cost, Vector2(46, 42))
		gem.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		gem.off = active and l + cost < 0
		row.add_child(gem)
		var txt := tr(String(sk.get("text", "")))
		var cut := txt.find(": ")
		if cut > 0 and cut <= 3:
			txt = txt.substr(cut + 2)   # o custo já está na gema («+1: …» → «…»)
		var tl2 := UiKit.label(txt, 17, Color.WHITE if not gem.off else UiKit.TEXT_DIM, true)
		tl2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		tl2.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(tl2)
	_finish_window(body)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and not event.pressed:
		accept_event()
		close()

# --- Glossário ---

## Texto da carta com os termos do glossário sublinhados (tocar mostra a explicação).
func _rich_text(text: String, font_size: int, color: Color, centered: bool = false) -> RichTextLabel:
	var r := RichTextLabel.new()
	r.bbcode_enabled = true
	r.fit_content = true
	r.scroll_active = false
	r.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	r.add_theme_font_size_override("normal_font_size", font_size)
	r.add_theme_color_override("default_color", color)
	r.meta_underlined = true
	r.mouse_filter = Control.MOUSE_FILTER_STOP
	r.text = CardView.plus_marks(CardView.colorize_bbcode(glossary_bbcode(text)))   # 0.14.0: Poder a azul, Mult a vermelho
	if centered:
		r.text = "[center]" + r.text + "[/center]"   # 0.14.1: texto centrado, como na carta pequena
	r.meta_clicked.connect(func(meta):
		_link_hit = true
		_show_term(int(str(meta))))
	# Tocar fora de um termo fecha (como no resto da carta); o sinal chega antes do clique no link,
	# por isso a decisão fica para o fim do frame.
	r.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
			if ev.pressed:
				_link_hit = false
			else:
				_close_unless_link.call_deferred())
	return r

func _close_unless_link() -> void:
	if not _link_hit:
		close()

func _show_term(index: int) -> void:
	if index < 0 or index >= CardDB.glossary.size() or _gloss_label == null:
		return
	var g: Dictionary = CardDB.glossary[index]
	var term := String(g.get("en", g.get("term", ""))) if Settings.effective_language() == "en" else String(g.get("term", ""))
	_gloss_label.text = "▸ " + term + ": " + tr(String(g.get("text", "")))
	var ex := glossary_example(index, _zoom_id)   # 0.19.0 (152): uma carta que o usa (outra que não esta)
	if ex != "":
		_gloss_label.text += "  " + tr("Exemplo: %s.") % ex
	_gloss_label.visible = true
	Sfx.select()

## 0.19.0 (102): «Poder 55 = 30 base + 10 loja e eventos + 10 Veterano + 5 nesta batalha + 20 equipamento». "" quando
## o Poder é só o da carta. O equipamento conta quando a carta está numa batalha.
static func power_breakdown(inst: CardInstance) -> String:
	if inst == null or not inst.data.is_creature():
		return ""
	var t := func(s: String) -> String: return TranslationServer.translate(s)
	var vet := inst.vet_stars() * BattleManager.VETERAN_POWER
	var shop := inst.perm_power() - vet
	var equip := 0
	var sc: Node = (Engine.get_main_loop() as SceneTree).current_scene if Engine.get_main_loop() is SceneTree else null
	if sc != null and sc.has_method("_equip_of") and inst.zone == CardInstance.Zone.BOARD:
		var eq = sc.call("_equip_of", inst)
		if eq is CardInstance:
			equip = (eq as CardInstance).power()
	var parts: Array[String] = []
	for p in [[shop, t.call("loja e eventos")], [vet, t.call("Veterano")], [inst.power_bonus, t.call("nesta batalha")], [equip, t.call("equipamento")]]:
		if int(p[0]) != 0:
			parts.append(("+ %d " if int(p[0]) > 0 else "− %d ") % absi(int(p[0])) + String(p[1]))
	if parts.is_empty():
		return ""
	return t.call("Poder %d = %d base %s") % [inst.power() + equip, inst.data.power, " ".join(PackedStringArray(parts))]

## 0.19.0 (152): o nome de uma carta que usa o termo do glossário (a primeira por ordem; "" se não houver).
static var _gloss_examples: Dictionary = {}

static func glossary_example(index: int, exclude_id: String = "") -> String:
	if index < 0 or index >= CardDB.glossary.size():
		return ""
	if not _gloss_examples.has(index):
		var g: Dictionary = CardDB.glossary[index]
		var words: Array = [fold_term(String(g.get("term", "")))]
		for a in g.get("aliases", []):
			words.append(fold_term(String(a)))
		var found: Array = []
		for id in CardDB.cards:
			var d: CardData = CardDB.cards[id]
			if d.is_curse() or d.token or d.is_back:
				continue
			var hay := fold_term(d.text + " " + " ".join(PackedStringArray(d.keywords.map(func(k): return String(CardData.KEYWORD_NAMES.get(k, k))))))
			for w in words:
				if w != "" and hay.contains(w):
					found.append(String(id))
					break
			if found.size() >= 2:
				break
		_gloss_examples[index] = found
	for cid in _gloss_examples[index]:
		if String(cid) != exclude_id:
			var cd := CardDB.get_card(String(cid))
			return cd.display_name() if cd != null else ""
	return ""

static func fold_term(s: String) -> String:
	return HowToPlay.fold(s)

## Converte o texto em BBCode com [url=i] nos termos do glossário (palavra inteira ou começo de
## palavra: "Ficha" apanha "Fichas"; "aliases" para plurais irregulares).
static func glossary_bbcode(text: String) -> String:
	var en := Settings.effective_language() == "en"
	var spans: Array = []   # [início, fim, índice]
	var taken := PackedByteArray()
	taken.resize(text.length())
	var terms: Array = []
	for i in CardDB.glossary.size():
		var g: Dictionary = CardDB.glossary[i]
		var words: Array = []
		if en:
			words.append(String(g.get("en", "")))
			words.append_array(g.get("en_aliases", []))
		else:
			words.append(String(g.get("term", "")))
			words.append_array(g.get("aliases", []))
		for w in words:
			if String(w) != "":
				terms.append([String(w), i, bool(g.get("exact", false))])
	terms.sort_custom(func(a, b): return String(a[0]).length() > String(b[0]).length())
	for t in terms:
		var word: String = t[0]
		var from := 0
		while true:
			var at := text.findn(word, from)
			if at < 0:
				break
			from = at + 1
			if at > 0 and _is_letter(text[at - 1]):
				continue
			var end := at + word.length()
			if bool(t[2]) and end < text.length() and _is_letter(text[end]):
				continue   # termo exato: "Mult" não sublinha "Multiplica"
			while end < text.length() and _is_letter(text[end]):
				end += 1
			var clash := false
			for k in range(at, end):
				if taken[k] != 0:
					clash = true
					break
			if clash:
				continue
			for k in range(at, end):
				taken[k] = 1
			spans.append([at, end, int(t[1])])
			break   # um sublinhado por termo chega
	spans.sort_custom(func(a, b): return int(a[0]) < int(b[0]))
	var out := ""
	var pos := 0
	for sp in spans:
		out += _escape(text.substr(pos, int(sp[0]) - pos))
		out += "[url=%d]%s[/url]" % [int(sp[2]), _escape(text.substr(int(sp[0]), int(sp[1]) - int(sp[0])))]
		pos = int(sp[1])
	out += _escape(text.substr(pos))
	return out

static func _is_letter(ch: String) -> bool:
	return ch.to_upper() != ch.to_lower()

static func _escape(s: String) -> String:
	return s.replace("[", "[lb]")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Sfx.select()
	UiKit.close_animated(self, _panel)
