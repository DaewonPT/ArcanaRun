class_name CardZoom
extends Control
## Carta em grande (toque longo numa carta da mão, do tabuleiro ou de uma lista) com o texto
## completo, ou a descrição de uma relíquia. Toca em qualquer sítio para fechar.

const COLOR_NAMES := {"white": "Branco", "blue": "Azul", "black": "Preto", "red": "Vermelho", "green": "Verde"}
const RARITY_NAMES := {"common": "Comum", "uncommon": "Incomum", "rare": "Rara", "mythic": "Mítica", "legendary": "Lendária"}

var _panel: PanelContainer

static func show_card(card: CardInstance) -> void:
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_card(card.data, card)

static func show_data(data: CardData) -> void:
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_card(data, null)

static func show_planeswalker(id: String) -> void:
	var p := CardDB.get_planeswalker(id)
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	var lines: Array[String] = [z.tr(String(p.get("text", "")))]
	for sk in p.get("skills", []):
		lines.append(z.tr(String(sk.get("text", ""))))
	var loyalty_txt := ""
	if String(GameState.planeswalker.get("id", "")) == id:
		loyalty_txt = "  ·  " + z.tr("Lealdade %d/%d") % [GameState.planeswalker_loyalty(), int(p.get("max_loyalty", 6))]
	z._build_text("✦ " + z.tr(String(p.get("name", id))), "\n".join(PackedStringArray(lines)), z.tr("Planeswalker") + loyalty_txt, UiKit.BG_LIGHT, CardView.COLORS.get(String(p.get("color", "colorless")), UiKit.GOLD))

## Texto simples em grande (intenção do inimigo, ajudas).
static func show_text(title: String, body: String, kind: String, accent: Color = UiKit.GOLD) -> void:
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_text(title, body, kind, UiKit.BG_LIGHT, accent)

static func show_climate(id: String, extra: String = "") -> void:
	var c := CardDB.get_climate(id)
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_text(z.tr(String(c.get("name", id))) + extra, z.tr(String(c.get("text", ""))), z.tr("Clima Planar · regra deste ato"), UiKit.BG_LIGHT, Color(0.35, 0.8, 0.85))

static func show_contract(c: Dictionary) -> void:
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	var reward := GameState.reward_text(c.get("reward", {}))
	var body := z.tr(String(c.get("text", ""))) + ("\n" + z.tr("Recompensa: %s.") % reward if reward != "" else "")
	z._build_text(z.tr(String(c.get("name", ""))), body, z.tr("Contrato · vale para esta batalha"), UiKit.BG_LIGHT, UiKit.GOLD)

static func show_seal(id: String) -> void:
	var sd := CardDB.get_seal(id)
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_text("◉ " + z.tr(String(sd.get("name", id))), z.tr(String(sd.get("text", ""))), z.tr("Selo de guilda"), UiKit.BG_LIGHT, CardView.COLORS.get(String(sd.get("color", "colorless")), UiKit.GOLD))

static func show_relic(id: String) -> void:
	var r: Dictionary = CardDB.relics.get(id, {})
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	var kind := z.tr("Relíquia de boss") if bool(r.get("boss", false)) else (z.tr("Relíquia lendária") if bool(r.get("legendary", false)) else z.tr("Relíquia"))
	var body := z.tr(String(r.get("text", "")))
	if id in GameState.relic_ids and GameState.relic_scaling_text(id) != "":
		body += "\n" + GameState.relic_scaling_text(id)
	z._build_text("★ " + z.tr(String(r.get("name", id))), body, kind, UiKit.BG_LIGHT, Color(0.9, 0.35, 0.35) if bool(r.get("boss", false)) else UiKit.GOLD)

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.78))

func _build_card(d: CardData, inst: CardInstance) -> void:
	var bg: Color = CardView.COLORS[d.primary_color()]
	if d.colors.size() >= 2:
		bg = Color(0, 0, 0)
		for col in d.colors:
			bg += CardView.COLORS.get(col, CardView.COLORS.colorless) / d.colors.size()
	var text_color := CardView.DARK_TEXT if bg.get_luminance() > 0.45 else CardView.LIGHT_TEXT
	var dim_color := text_color.lerp(bg, 0.35)
	_panel = UiKit.centered_panel(self, 470, bg, UiKit.GOLD if d.colors.size() >= 3 else bg.darkened(0.25))
	_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.custom_minimum_size = Vector2(470, 540)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(vbox)

	var top := HBoxContainer.new()
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(top)
	var name_l := UiKit.label(d.name, 32, text_color, true)
	name_l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_l.size_flags_vertical = Control.SIZE_FILL   # com autowrap+reticências o mínimo é 1 px: tem de encher a linha
	name_l.custom_minimum_size = Vector2(0, 92)
	name_l.max_lines_visible = 2
	name_l.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	top.add_child(name_l)
	var cost_l := UiKit.label(str(d.cost), 46, text_color)
	cost_l.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	top.add_child(cost_l)

	var type_txt := ""
	if d.is_creature():
		type_txt = tr("Criatura")
	elif d.is_spell():
		type_txt = tr("Mágica") if d.subtype == "instant" else tr("Feitiço")
	elif d.is_curse():
		type_txt = tr("Maldição")
	else:
		type_txt = tr("Terreno")
	var cols: Array[String] = []
	for c in d.colors:
		cols.append(tr(COLOR_NAMES.get(String(c), String(c))))
	if cols.is_empty():
		cols.append(tr("Incolor"))
	vbox.add_child(UiKit.label("%s  ·  %s  ·  %s" % [type_txt, "/".join(PackedStringArray(cols)), tr(RARITY_NAMES.get(d.rarity, d.rarity.capitalize()))], 18, dim_color))

	var line := ColorRect.new()
	line.color = Color(text_color, 0.25)
	line.custom_minimum_size = Vector2(0, 2)
	line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(line)

	var body := UiKit.label(tr(d.text) if d.text != "" else tr("Sem efeito."), 23, text_color, true)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(body)

	if d.is_creature():
		var stats := ""
		if inst != null:
			stats = "%d ⚔  %d / %d ♥" % [inst.power(), inst.remaining(), inst.toughness()]
		else:
			stats = "%d ⚔  %d ♥" % [d.power, d.toughness]
		var s := UiKit.label(stats, 34, text_color)
		s.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		vbox.add_child(s)
	elif d.power > 0:
		var s := UiKit.label("%d ⚔" % (inst.power() if inst != null else d.power), 34, text_color)
		s.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		vbox.add_child(s)

	var extras: Array[String] = []
	if inst != null:
		if inst.perm_power() != 0 or inst.perm_mult() != 0.0:
			var parts: Array[String] = []
			if inst.perm_power() != 0:
				parts.append(tr("+%d Poder") % inst.perm_power())
			if inst.perm_mult() != 0.0:
				parts.append(tr("+%s Mult") % Cascade.fmt_mult(inst.perm_mult()))
			extras.append(tr("Bónus permanente: %s") % " · ".join(PackedStringArray(parts)))
		if inst.power_bonus != 0:
			extras.append(tr("Nesta batalha: +%d Poder") % inst.power_bonus)
		if inst.damage > 0:
			extras.append(tr("Dano sofrido: %d") % inst.damage)
	if d.approx:
		extras.append(tr("≈ efeito aproximado da carta original"))
	if d.flashback:
		extras.append(tr("↺ Recapitular: pode ser lançada a partir do cemitério; depois vai para o exílio até ao fim da batalha."))
	if d.fused_text != "":
		extras.append(tr("⚗ Habilidade fundida no Altar: %s") % tr(d.fused_text))
	if d.infected:
		extras.append(tr("☠ Infetada: Poder a dobrar; exila-se ao fim de %d utilizações (%d/%d).") % [BattleManager.INFECTED_USES, int(inst.deck_entry.get("uses", 0)) if inst != null else 0, BattleManager.INFECTED_USES])
	if d.is_back:
		extras.append(tr("⇄ Face transformada."))
	elif not d.transformed.is_empty():
		var back: Dictionary = d.transformed
		var progress_txt := ""
		if inst != null and inst.has_mission():
			progress_txt = tr("Missão %d/%d. ") % [inst.mission_count, inst.mission_target()]
		extras.append("⇄ " + progress_txt + tr("Vira em %s (%d ⚔): %s") % [tr(String(back.get("name", ""))), int(back.get("power", 0)), tr(String(back.get("text", "")))])
	if inst != null and inst.seal() != "":
		var seal_def := CardDB.get_seal(inst.seal())
		extras.append("◉ %s: %s" % [tr(String(seal_def.get("name", inst.seal()))), tr(String(seal_def.get("text", "")))])
	if not extras.is_empty():
		vbox.add_child(UiKit.label("\n".join(PackedStringArray(extras)), 17, dim_color, true))

	var hint := UiKit.label(tr("Toca para fechar"), 16, dim_color)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(hint)
	UiKit.pop_in(_panel)

func _build_text(title: String, body_text: String, kind: String, bg: Color, accent: Color) -> void:
	_panel = UiKit.centered_panel(self, 520, bg, accent)
	_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(vbox)
	vbox.add_child(UiKit.label(title, 30, accent, true))
	vbox.add_child(UiKit.label(kind, 17, UiKit.TEXT_DIM))
	vbox.add_child(UiKit.label(body_text, 23, Color.WHITE, true))
	var hint := UiKit.label(tr("Toca para fechar"), 16, UiKit.TEXT_DIM)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(hint)
	UiKit.pop_in(_panel)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and not event.pressed:
		accept_event()
		close()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Sfx.select()
	queue_free()
