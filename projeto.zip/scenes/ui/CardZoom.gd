class_name CardZoom
extends Control
## Carta em grande (toque longo numa carta da mão, do tabuleiro ou de uma lista) com o texto
## completo, ou a descrição de uma relíquia. Toca em qualquer sítio para fechar.
## 0.10.0: os termos do glossário (data/glossary.json) aparecem sublinhados no texto da carta;
## tocar num deles mostra a explicação por baixo. O sigilo da carta aparece em fundo.

const COLOR_NAMES := {"white": "Branco", "blue": "Azul", "black": "Preto", "red": "Vermelho", "green": "Verde"}
const RARITY_NAMES := {"common": "Comum", "uncommon": "Incomum", "rare": "Rara", "mythic": "Mítica", "legendary": "Lendária"}

var _panel: PanelContainer
var _gloss_label: Label
var _link_hit := false
# 0.13.0: carta em grande em 3D (inclina com o telemóvel; no computador segue o rato).
const SHEEN_SHADER := preload("res://assets/shaders/card_sheen.gdshader")
var _tilt_on := false
var _tilt_rest := Vector2.ZERO
var _tilt_v := Vector2.ZERO
var _tilt_wait := 0.0
var _tilt_fixed := false      # testes e capturas: inclinação dada à mão
var _sheen: ColorRect
var _shadow: Panel
const TRIBE_NAMES := CardView.TRIBE_NAMES   # 0.13.0: a mesma lista (com Construto, Espírito, Fera e Planta)

static func show_card(card: CardInstance) -> void:
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_card(card.data, card)

func _in_battle() -> bool:
	var cur := get_tree().current_scene if is_inside_tree() else null
	return cur != null and cur.scene_file_path.contains("/battle/")

static func show_data(data: CardData) -> void:
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_card(data, null)

static func show_planeswalker(id: String) -> void:
	var p := CardDB.get_planeswalker(id)
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	var lines: Array[String] = [z.tr(String(p.get("text", "")))]
	for sk in p.get("skills", []):
		lines.append(z.tr(String(sk.get("text", ""))))
	var loyalty_txt := ""
	if String(GameState.planeswalker.get("id", "")) == id:
		loyalty_txt = "  ·  " + z.tr("Lealdade %d/%d") % [GameState.planeswalker_loyalty(), int(p.get("max_loyalty", 6))]
	z._build_text("✦ " + z.tr(String(p.get("name", id))), "\n".join(PackedStringArray(lines)), z.tr("Planeswalker") + loyalty_txt, UiKit.BG_LIGHT, CardView.COLORS.get(String(p.get("color", "colorless")), UiKit.GOLD))

## Texto simples em grande (intenção do inimigo, ajudas).
static func show_text(title: String, body: String, kind: String, accent: Color = UiKit.GOLD) -> void:
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_text(title, body, kind, UiKit.BG_LIGHT, accent)

static func show_climate(id: String, extra: String = "") -> void:
	var c := CardDB.get_climate(id)
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_text(z.tr(String(c.get("name", id))) + extra, z.tr(String(c.get("text", ""))), z.tr("Clima Planar · regra deste ato"), UiKit.BG_LIGHT, Color(0.35, 0.8, 0.85))

static func show_contract(c: Dictionary) -> void:
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	var reward := GameState.reward_text(c.get("reward", {}))
	var body := z.tr(String(c.get("text", ""))) + ("\n" + z.tr("Recompensa: %s.") % reward if reward != "" else "")
	z._build_text(z.tr(String(c.get("name", ""))), body, z.tr("Contrato · vale para esta batalha"), UiKit.BG_LIGHT, UiKit.GOLD)

static func show_seal(id: String) -> void:
	var sd := CardDB.get_seal(id)
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	z._build_text("◉ " + z.tr(String(sd.get("name", id))), z.tr(String(sd.get("text", ""))), z.tr("Selo de guilda"), UiKit.BG_LIGHT, CardView.COLORS.get(String(sd.get("color", "colorless")), UiKit.GOLD))

static func show_relic(id: String) -> void:
	var r: Dictionary = CardDB.relics.get(id, {})
	var z := CardZoom.new()
	SceneRouter.show_overlay(z)
	var kind := z.tr("Relíquia de boss") if bool(r.get("boss", false)) else (z.tr("Relíquia lendária") if bool(r.get("legendary", false)) else (z.tr("Bênção do Santuário") if bool(r.get("blessing", false)) else z.tr("Relíquia")))
	var body := z.tr(String(r.get("text", "")))
	if id in GameState.relic_ids and GameState.relic_scaling_text(id) != "":
		body += "\n" + GameState.relic_scaling_text(id)
	if id in GameState.stolen_relics:
		body += "\n" + z.tr("Roubada: desligada até ao fim desta batalha.")
	var rs := CardDB.relic_set_of(id)   # 0.13.0: conjuntos de relíquias
	if not rs.is_empty():
		var members: Array = rs.get("relics", [])
		var have := 0
		for m in members:
			if String(m) in GameState.relic_ids or String(m) in GameState.boss_relics:
				have += 1
		body += "\n\n◆ " + z.tr("Conjunto: %s (%d/%d)") % [z.tr(String(rs.get("name", ""))), have, members.size()] + "\n" + z.tr(String(rs.get("text", "")))
	z._build_text("★ " + z.tr(String(r.get("name", id))), body, kind, UiKit.BG_LIGHT, Color(0.9, 0.35, 0.35) if bool(r.get("boss", false)) else UiKit.GOLD)

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.78))

func _build_card(d: CardData, inst: CardInstance) -> void:
	var bg: Color = CardView.COLORS[d.primary_color()]
	if d.colors.size() >= 2:
		bg = Color(0, 0, 0)
		for col in d.colors:
			bg += CardView.COLORS.get(col, CardView.COLORS.colorless) / d.colors.size()
	var text_color := CardView.DARK_TEXT if bg.get_luminance() > 0.45 else CardView.LIGHT_TEXT
	var dim_color := text_color.lerp(bg, 0.35)
	var border := UiKit.GOLD if d.colors.size() >= 3 else bg.darkened(0.25)
	if d.rarity == "mythic":
		border = CardView.MYTHIC_COLORS[0]
	_panel = UiKit.centered_panel(self, 470, bg, border)
	_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.custom_minimum_size = Vector2(470, 540)
	var fogged := CardView.fog_hand and inst != null and inst.zone == CardInstance.Zone.HAND
	# 0.12.0: ilustração (se existir) por trás, forte em cima e a desvanecer para o texto.
	var art_tex: Texture2D = null if fogged else ArtLib.texture("card", d.id)
	if art_tex != null:
		var art := CardArt.new()
		art.name = "Art"
		art.texture = art_tex
		art.top_alpha = 0.95
		art.fade_from = 0.18
		art.fade_to = 0.44
		art.floor_alpha = 0.0
		art.height_frac = 0.5
		_panel.add_child(art)
	elif not d.is_land():   # os Terrenos têm a paisagem por baixo do texto (mais abaixo)
		var sigil := CardSigil.new()
		sigil.card_id = d.id
		sigil.colors = d.colors.duplicate()
		sigil.ink = Color(text_color, 0.16)
		sigil.line_width = 2.2
		sigil.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_panel.add_child(sigil)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(vbox)

	var top := HBoxContainer.new()
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(top)
	var name_l := UiKit.label(d.display_name(), 32, text_color, true)
	if art_tex != null:
		name_l.add_theme_constant_override("outline_size", 8)
		name_l.add_theme_color_override("font_outline_color", Color(bg, 0.92))
	name_l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_l.size_flags_vertical = Control.SIZE_FILL   # com autowrap+reticências o mínimo é 1 px: tem de encher a linha
	name_l.custom_minimum_size = Vector2(0, 92)
	name_l.max_lines_visible = 2
	name_l.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	top.add_child(name_l)
	var cost_l := UiKit.label("+1" if d.is_land() else str(d.cost), 46, text_color)
	if d.is_land():
		cost_l.add_theme_color_override("font_color", Color(0.1, 0.32, 0.68) if text_color == CardView.DARK_TEXT else Color(0.62, 0.86, 1.0))
	cost_l.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	top.add_child(cost_l)
	if art_tex != null:
		cost_l.add_theme_constant_override("outline_size", 8)
		cost_l.add_theme_color_override("font_outline_color", Color(bg, 0.92))
		var window := Control.new()   # janela da ilustração entre o nome e a faixa do tipo
		window.custom_minimum_size = Vector2(0, 76)
		window.mouse_filter = Control.MOUSE_FILTER_IGNORE
		vbox.add_child(window)

	var type_txt := ""
	if d.is_creature():
		type_txt = tr("Ficha") if d.token else tr("Criatura")
		if d.tribe != "":
			type_txt += " · " + tr(TRIBE_NAMES.get(d.tribe, d.tribe))
	elif d.is_enchantment():
		type_txt = tr("Encantamento")
	elif d.is_spell():
		type_txt = tr("Mágica") if d.subtype == "instant" else tr("Feitiço")
	elif d.is_curse():
		type_txt = tr("Maldição")
	else:
		type_txt = tr("Terreno")
	var cols: Array[String] = []
	for c in d.colors:
		cols.append(tr(COLOR_NAMES.get(String(c), String(c))))
	if cols.is_empty():
		cols.append(tr("Incolor"))
	# Faixa do tipo, com a mesma cor da carta pequena.
	var ribbon := PanelContainer.new()
	ribbon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var rs := UiKit.flat(CardView.TYPE_RIBBON.get(CardView.type_key(d), CardView.TYPE_RIBBON.creature), 8, Color(0, 0, 0, 0), 0, 6)
	ribbon.add_theme_stylebox_override("panel", rs)
	var rrow := HBoxContainer.new()
	rrow.add_theme_constant_override("separation", 8)
	rrow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ribbon.add_child(rrow)
	var ticon := CardIcon.new("creature" if d.token else CardIcon.kind_for(d), CardView.LIGHT_TEXT, 22.0)
	ticon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	rrow.add_child(ticon)
	rrow.add_child(UiKit.label("%s  ·  %s  ·  %s" % [type_txt, "/".join(PackedStringArray(cols)), tr(RARITY_NAMES.get(d.rarity, d.rarity.capitalize()))], 18, CardView.LIGHT_TEXT))
	vbox.add_child(ribbon)
	var kws: Array = inst.keywords() if inst != null and inst.data == d else d.keywords
	if not kws.is_empty() and not fogged:
		var kw_row := HBoxContainer.new()
		kw_row.add_theme_constant_override("separation", 6)
		kw_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var kw_names: PackedStringArray = []
		for k in kws:
			var ic := CardIcon.new(String(k), text_color, 22.0)
			ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			kw_row.add_child(ic)
			kw_names.append(tr(String(CardData.KEYWORD_NAMES.get(k, k))))
		kw_row.add_child(UiKit.label(" · ".join(kw_names), 20, text_color))
		vbox.add_child(kw_row)

	var line := ColorRect.new()
	line.color = Color(text_color, 0.25)
	line.custom_minimum_size = Vector2(0, 2)
	line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(line)

	var body_txt := d.display_text() if d.text != "" else tr("Sem efeito.")
	if fogged:
		body_txt = tr("??? — o Nevoeiro esconde o texto das cartas na mão.")
	var body := _rich_text(body_txt, 23, text_color)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(body)
	_gloss_label = UiKit.label("", 17, text_color, true)
	_gloss_label.visible = false
	vbox.add_child(_gloss_label)
	if d.is_land() and art_tex == null:
		# Paisagem do Terreno numa faixa própria, entre o texto e a explicação (nunca por cima de texto).
		var land := LandArt.new()
		land.card_id = d.id
		land.colors = d.colors.duplicate()
		land.ink = Color(text_color, 0.24)
		land.window = Rect2(0.0, 0.0, 1.0, 1.0)
		land.custom_minimum_size = Vector2(0, 120)
		vbox.add_child(land)

	if d.is_creature():
		var stats := ""
		if inst != null:
			stats = "%d ⚔  %d / %d ♥" % [inst.power(), inst.remaining(), inst.toughness()]
		else:
			stats = "%d ⚔  %d ♥" % [d.power, d.toughness]
		var s := UiKit.label(stats, 34, text_color)
		s.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		vbox.add_child(s)
	elif d.power > 0:
		var s := UiKit.label("%d ⚔" % (inst.power() if inst != null else d.power), 34, text_color)
		s.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		vbox.add_child(s)

	var extras: Array[String] = []
	if d.is_land():
		extras.append(tr("Terreno: jogá-lo é de graça e dá +1 mana para sempre; guardado na mão, dá o bónus [Na Mão]."))
	if not fogged:
		for k in kws:
			extras.append(tr(String(CardData.KEYWORD_TEXT.get(k, ""))) + ("  " + tr("(dada nesta batalha)") if inst != null and k in inst.granted_keywords else ""))
	if inst != null:
		if inst.perm_power() != 0 or inst.perm_mult() != 0.0:
			var parts: Array[String] = []
			if inst.perm_power() != 0:
				parts.append(tr("+%d Poder") % inst.perm_power())
			if inst.perm_mult() != 0.0:
				parts.append(tr("+%s Mult") % Cascade.fmt_mult(inst.perm_mult()))
			extras.append(tr("Bónus permanente: %s") % " · ".join(PackedStringArray(parts)))
		if inst.power_bonus != 0:
			extras.append(tr("Nesta batalha: +%d Poder") % inst.power_bonus)
		if inst.damage > 0:
			extras.append(tr("Dano sofrido: %d") % inst.damage)
		if inst.kicked:
			extras.append(tr("★ Jogada com Reforço."))
	if d.approx:
		extras.append(tr("≈ efeito aproximado da carta original"))
	if d.has_kicker():
		extras.append(tr("Reforço +%d mana: %s.") % [int(d.kicker.get("cost", 0)), d.display_kicker_text()])
	if d.plus:
		extras.append(tr("Versão +: os efeitos valem ×1,5."))
	if d.locked and not Stats.is_content_unlocked("card", d.id):
		extras.append(tr("Bloqueada: desbloqueia-se com uma conquista."))
	if d.flashback:
		extras.append(tr("↺ Recapitular: pode ser lançada a partir do cemitério; depois vai para o exílio até ao fim da batalha."))
	if d.fused_text != "":
		extras.append(tr("⚗ Habilidade fundida no Altar: %s") % tr(d.fused_text))
	if d.infected:
		extras.append(tr("☠ Infetada: Poder a dobrar; exila-se ao fim de %d utilizações (%d/%d).") % [BattleManager.INFECTED_USES, int(inst.deck_entry.get("uses", 0)) if inst != null else 0, BattleManager.INFECTED_USES])
	if d.is_back:
		extras.append(tr("⇄ Face transformada."))
	elif not d.transformed.is_empty():
		var back: Dictionary = d.transformed
		var progress_txt := ""
		if inst != null and inst.has_mission():
			progress_txt = tr("Missão %d/%d. ") % [inst.mission_count, inst.mission_target()]
		extras.append("⇄ " + progress_txt + tr("Vira em %s (%d ⚔): %s") % [tr(String(back.get("name", ""))), int(back.get("power", 0)), tr(String(back.get("text", "")))])
	if inst != null and inst.seal() != "":
		var seal_def := CardDB.get_seal(inst.seal())
		extras.append("◉ %s: %s" % [tr(String(seal_def.get("name", inst.seal()))), tr(String(seal_def.get("text", "")))])
	# 0.13.0: edição da carta (o brilho próprio fica por cima de tudo).
	var ed := inst.edition() if inst != null else ""
	if EffectResolver.EDITIONS.has(ed):
		extras.insert(0, String(EffectResolver.EDITIONS[ed]["symbol"]) + " " + EffectResolver.edition_text(ed))
		if not Settings.performance_mode:
			var fx := ColorRect.new()
			fx.name = "EditionFx"
			fx.mouse_filter = Control.MOUSE_FILTER_IGNORE
			fx.material = CardView.edition_material(ed)
			_panel.add_child(fx)
	# 0.12.0: estatísticas da carta nas tuas runs (fora das batalhas, para não encher o ecrã).
	if not fogged and not _in_battle():
		var cs := GameState.card_stat(d.id)
		if not cs.is_empty():
			extras.append(tr("Nas tuas runs: %s de dano · jogada %d× · em %d runs (%d vitórias)") % [Cascade.fmt_int(int(cs.get("dmg", 0))), int(cs.get("plays", 0)), int(cs.get("runs", 0)), int(cs.get("wins", 0))])
		# 0.13.0: mestria (Bronze 15, Prata 50, Ouro 120 jogadas).
		var lv := GameState.mastery_of(cs)
		var plays := int(cs.get("plays", 0))
		if lv >= GameState.MASTERY_PLAYS.size():
			extras.append("★ " + tr("Mestria %s: a carta tem a moldura dourada.") % tr(GameState.MASTERY_NAMES[lv - 1]))
		elif not d.token and not d.is_curse():
			var next_txt := tr("Mestria: %d/%d jogadas para %s.") % [plays, int(GameState.MASTERY_PLAYS[lv]), tr(GameState.MASTERY_NAMES[lv])]
			extras.append(("★ " + tr("Mestria %s.") % tr(GameState.MASTERY_NAMES[lv - 1]) + " " if lv > 0 else "") + next_txt)
	if not extras.is_empty():
		vbox.add_child(UiKit.label("\n".join(PackedStringArray(extras)), 17, dim_color, true))

	var hint := UiKit.label(tr("Toca para fechar"), 16, dim_color)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(hint)
	UiKit.pop_in(_panel)
	_setup_tilt()

# --- 0.13.0: efeito 3D ---

func _setup_tilt() -> void:
	if not Settings.tilt_3d or not Settings.motion_ok() or Settings.performance_mode or _panel == null:
		return
	_tilt_on = true
	_tilt_wait = Settings.dur(0.16) + 0.06   # deixa acabar a entrada animada
	_tilt_rest = SceneRouter.tilt()          # a forma como estás a segurar o telemóvel conta como "direito"
	var center := _panel.get_parent()
	_shadow = Panel.new()
	_shadow.name = "TiltShadow"
	_shadow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_shadow.add_theme_stylebox_override("panel", UiKit.flat(Color(0, 0, 0, 0.55), 18))
	_shadow.modulate.a = 0.0
	center.add_child(_shadow)
	center.move_child(_shadow, _panel.get_index())   # por trás da carta
	_sheen = ColorRect.new()
	_sheen.name = "TiltSheen"
	_sheen.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var m := ShaderMaterial.new()
	m.shader = SHEEN_SHADER
	_sheen.material = m
	_sheen.modulate.a = 0.0
	center.add_child(_sheen)   # por cima da carta
	set_process(true)

## Inclinação fixa (−1 a 1), para os testes e as capturas.
func set_tilt(t: Vector2) -> void:
	_tilt_fixed = true
	_tilt_wait = 0.0
	_tilt_v = t
	_apply_tilt(t, 1.0)

func _process(delta: float) -> void:
	if not _tilt_on or _panel == null or not is_instance_valid(_panel):
		return
	if not _tilt_fixed:
		var target := Vector2.ZERO
		if Input.get_accelerometer() != Vector3.ZERO:
			target = ((SceneRouter.tilt() - _tilt_rest) * 2.4).clamp(Vector2(-1, -1), Vector2(1, 1))
		else:
			var r := _panel.get_global_rect()
			if r.size.x > 0.0 and r.grow(60.0).has_point(get_global_mouse_position()):
				target = ((get_global_mouse_position() - r.get_center()) / (r.size * 0.5)).clamp(Vector2(-1, -1), Vector2(1, 1))
		_tilt_v = _tilt_v.lerp(target, clampf(delta * 6.0, 0.0, 1.0))
	if _tilt_wait > 0.0:
		_tilt_wait -= delta
		return
	_apply_tilt(_tilt_v, clampf(delta * 5.0, 0.0, 1.0))

func _apply_tilt(t: Vector2, fade: float) -> void:
	_panel.pivot_offset = _panel.size / 2.0
	_panel.rotation = t.x * 0.03
	_panel.scale = Vector2(1.0 - 0.045 * absf(t.x), 1.0 - 0.03 * absf(t.y))
	for c in [_shadow, _sheen]:
		var ctl := c as Control
		if ctl == null:
			continue
		if ctl.custom_minimum_size != _panel.size:
			ctl.custom_minimum_size = _panel.size
		ctl.size = _panel.size
		ctl.pivot_offset = _panel.pivot_offset
		ctl.rotation = _panel.rotation
		ctl.scale = _panel.scale
	if _sheen != null:
		_sheen.position = _panel.position
		_sheen.modulate.a = lerpf(_sheen.modulate.a, 1.0, fade)
		var m := _sheen.material as ShaderMaterial
		m.set_shader_parameter("tilt", t)
		m.set_shader_parameter("size_px", _panel.size)
	if _shadow != null:
		# A sombra foge da luz: parece que a carta levanta do ecrã.
		_shadow.position = _panel.position + Vector2(-t.x * 18.0, 14.0 - t.y * 12.0)
		_shadow.modulate.a = lerpf(_shadow.modulate.a, 0.55 + 0.35 * minf(1.0, t.length()), fade)

func _build_text(title: String, body_text: String, kind: String, bg: Color, accent: Color) -> void:
	_panel = UiKit.centered_panel(self, 520, bg, accent)
	_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(vbox)
	vbox.add_child(UiKit.label(title, 30, accent, true))
	vbox.add_child(UiKit.label(kind, 17, UiKit.TEXT_DIM))
	vbox.add_child(UiKit.label(body_text, 23, Color.WHITE, true))
	var hint := UiKit.label(tr("Toca para fechar"), 16, UiKit.TEXT_DIM)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(hint)
	UiKit.pop_in(_panel)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and not event.pressed:
		accept_event()
		close()

# --- Glossário ---

## Texto da carta com os termos do glossário sublinhados (tocar mostra a explicação).
func _rich_text(text: String, font_size: int, color: Color) -> RichTextLabel:
	var r := RichTextLabel.new()
	r.bbcode_enabled = true
	r.fit_content = true
	r.scroll_active = false
	r.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	r.add_theme_font_size_override("normal_font_size", font_size)
	r.add_theme_color_override("default_color", color)
	r.meta_underlined = true
	r.mouse_filter = Control.MOUSE_FILTER_STOP
	r.text = glossary_bbcode(text)
	r.meta_clicked.connect(func(meta):
		_link_hit = true
		_show_term(int(str(meta))))
	# Tocar fora de um termo fecha (como no resto da carta); o sinal chega antes do clique no link,
	# por isso a decisão fica para o fim do frame.
	r.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
			if ev.pressed:
				_link_hit = false
			else:
				_close_unless_link.call_deferred())
	return r

func _close_unless_link() -> void:
	if not _link_hit:
		close()

func _show_term(index: int) -> void:
	if index < 0 or index >= CardDB.glossary.size() or _gloss_label == null:
		return
	var g: Dictionary = CardDB.glossary[index]
	var term := String(g.get("en", g.get("term", ""))) if Settings.effective_language() == "en" else String(g.get("term", ""))
	_gloss_label.text = "▸ " + term + ": " + tr(String(g.get("text", "")))
	_gloss_label.visible = true
	Sfx.select()

## Converte o texto em BBCode com [url=i] nos termos do glossário (palavra inteira ou começo de
## palavra: "Ficha" apanha "Fichas"; "aliases" para plurais irregulares).
static func glossary_bbcode(text: String) -> String:
	var en := Settings.effective_language() == "en"
	var spans: Array = []   # [início, fim, índice]
	var taken := PackedByteArray()
	taken.resize(text.length())
	var terms: Array = []
	for i in CardDB.glossary.size():
		var g: Dictionary = CardDB.glossary[i]
		var words: Array = []
		if en:
			words.append(String(g.get("en", "")))
			words.append_array(g.get("en_aliases", []))
		else:
			words.append(String(g.get("term", "")))
			words.append_array(g.get("aliases", []))
		for w in words:
			if String(w) != "":
				terms.append([String(w), i, bool(g.get("exact", false))])
	terms.sort_custom(func(a, b): return String(a[0]).length() > String(b[0]).length())
	for t in terms:
		var word: String = t[0]
		var from := 0
		while true:
			var at := text.findn(word, from)
			if at < 0:
				break
			from = at + 1
			if at > 0 and _is_letter(text[at - 1]):
				continue
			var end := at + word.length()
			if bool(t[2]) and end < text.length() and _is_letter(text[end]):
				continue   # termo exato: "Mult" não sublinha "Multiplica"
			while end < text.length() and _is_letter(text[end]):
				end += 1
			var clash := false
			for k in range(at, end):
				if taken[k] != 0:
					clash = true
					break
			if clash:
				continue
			for k in range(at, end):
				taken[k] = 1
			spans.append([at, end, int(t[1])])
			break   # um sublinhado por termo chega
	spans.sort_custom(func(a, b): return int(a[0]) < int(b[0]))
	var out := ""
	var pos := 0
	for sp in spans:
		out += _escape(text.substr(pos, int(sp[0]) - pos))
		out += "[url=%d]%s[/url]" % [int(sp[2]), _escape(text.substr(int(sp[0]), int(sp[1]) - int(sp[0])))]
		pos = int(sp[1])
	out += _escape(text.substr(pos))
	return out

static func _is_letter(ch: String) -> bool:
	return ch.to_upper() != ch.to_lower()

static func _escape(s: String) -> String:
	return s.replace("[", "[lb]")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Sfx.select()
	queue_free()
