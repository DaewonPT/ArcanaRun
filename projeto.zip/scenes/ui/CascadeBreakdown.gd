class_name CascadeBreakdown
extends Control
## Detalhe da cascata: a lista dos passos de um ataque (quem deu cada +Poder / +Mult / ×Mult) com o
## Poder × Mult acumulado em cada linha. Abre-se ao tocar no cálculo da batalha.

const ROW_COLORS := {
	"creature": Color(0.22, 0.74, 0.97), "spell": Color(0.6, 0.7, 1.0), "formation": Color(0.98, 0.75, 0.25),
	"hand": Color(0.75, 0.75, 0.85), "relic": Color(0.98, 0.85, 0.3), "planeswalker": Color(0.98, 0.75, 0.25),
	"climate": Color(0.35, 0.8, 0.85), "weak": Color(1.0, 0.55, 0.35),   # 0.15.0 Ponto fraco
	"equipment": Color(0.95, 0.72, 0.42),   # 0.18.0 Equipamentos
}

var _panel: PanelContainer

## 0.13.0: replay (opcional) acrescenta "▶ REVER O ÚLTIMO ATAQUE" (fecha o detalhe e repete a animação).
static func open(cascade: Cascade, title: String, replay: Callable = Callable()) -> CascadeBreakdown:
	var v := CascadeBreakdown.new()
	SceneRouter.show_overlay(v)
	v._replay = replay
	v._build(cascade, title)
	return v

var _replay: Callable

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.78))

func _build(cascade: Cascade, title: String) -> void:
	_panel = UiKit.centered_panel(self, 700)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	_panel.add_child(vbox)
	vbox.add_child(UiKit.label(title, 28, UiKit.GOLD))
	if not cascade.formations.is_empty():
		var names: Array[String] = []
		for f in cascade.formations:
			names.append(tr(f))
		vbox.add_child(UiKit.label(tr("Formações: %s") % ", ".join(PackedStringArray(names)), 17, UiKit.TEXT_DIM, true))
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, mini(440, 34 * cascade.steps.size() + 8))
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)
	var list := VBoxContainer.new()
	list.add_theme_constant_override("separation", 2)
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(list)
	for s in cascade.steps:
		list.add_child(_row(s))
	var total := UiKit.label(tr("Total: %s") % Cascade.fmt_int(cascade.total()), 26, Color(1, 0.92, 0.6))
	total.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	vbox.add_child(total)
	var buttons := HBoxContainer.new()
	buttons.add_theme_constant_override("separation", 10)
	vbox.add_child(buttons)
	if _replay.is_valid():
		var replay_btn := UiKit.button("▶  " + tr("REVER O ÚLTIMO ATAQUE"), 50, 17, UiKit.BG_LIGHT, UiKit.GOLD)
		replay_btn.name = "ReplayBtn"
		replay_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		replay_btn.pressed.connect(func():
			var cb := _replay
			close()
			cb.call())
		buttons.add_child(replay_btn)
	var close_btn := UiKit.button(tr("FECHAR"), 50, 18)
	close_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	close_btn.pressed.connect(close)
	buttons.add_child(close_btn)
	UiKit.pop_in(_panel)

func _row(s: Cascade.Step) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	row.custom_minimum_size.y = 32
	var color: Color = ROW_COLORS.get(s.source_kind, Color.WHITE)
	if s.tag == "seal":
		color = Color(0.9, 0.5, 0.9)
	var prefix := "↻ " if s.retrigger else ""
	var shown := tr(s.source_name)
	if s.tag == "edition" and EffectResolver.EDITIONS.has(s.source_id):   # 0.13.0: "☼ Nome (Brilhante)"
		color = EffectResolver.edition_color(s.source_id)
		prefix += String(EffectResolver.EDITIONS[s.source_id]["symbol"]) + " "
		shown += " (%s)" % EffectResolver.edition_name(s.source_id)
	var name_l := UiKit.label(prefix + shown, 17, color)
	name_l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_l.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	row.add_child(name_l)
	var what := UiKit.label(s.label, 17, Color.WHITE)
	what.custom_minimum_size.x = 150
	row.add_child(what)
	var acc := UiKit.label("%s × %s" % [Cascade.fmt_int(s.power_after), Cascade.fmt_mult(s.mult_after)], 17, UiKit.TEXT_DIM)
	acc.custom_minimum_size.x = 190
	acc.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	row.add_child(acc)
	return row

func _gui_input(event: InputEvent) -> void:
	# Toque fora do painel fecha.
	if event is InputEventMouseButton and not event.pressed and _panel != null and not _panel.get_global_rect().has_point(event.global_position):
		accept_event()
		close()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Sfx.select()
	UiKit.close_animated(self)
