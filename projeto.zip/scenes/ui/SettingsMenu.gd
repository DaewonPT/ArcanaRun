class_name SettingsMenu
extends Control
## Painel de Configurações (abre por cima do menu principal ou da pausa).
## 0.19.0: refeito (as 300 do documento: 222, 287–291 e as opções novas de cada área):
##   - separadores à esquerda: JOGO, CONTROLOS, RITMO, VISUAL, TEXTO E HUD, SOM, ACESSIBILIDADE, DESEMPENHO e PERFIL;
##   - pesquisa em cima (288): procura em todas as opções, pelo nome e pela ajuda;
##   - uma linha de ajuda por opção (289) e, nas que pesam na bateria, quanto gastam (222);
##   - REPOR ESTE SEPARADOR e REPOR TUDO (290), com 2 toques;
##   - predefinições Visão, Motricidade e Concentração no separador ACESSIBILIDADE (287);
##   - perfis de jogador com o nome e o retrato do mago no separador PERFIL (291, 298).
## As opções descrevem-se em _options() (dados) e as linhas fazem-se todas da mesma maneira.
## Grava em user://settings.json (o do perfil) a cada mudança e ao fechar.

signal closed

const TABS := [["game", "JOGO"], ["controls", "CONTROLOS"], ["pace", "RITMO"], ["visual", "VISUAL"],
	["text", "TEXTO E HUD"], ["sound", "SOM"], ["access", "ACESSIBILIDADE"], ["perf", "DESEMPENHO"], ["profile", "PERFIL"]]
const CONTENT_HEIGHT := 486.0
const COST_NAMES := {"low": "gasta pouco", "mid": "gasta algum", "high": "gasta muito"}
const COST_COLORS := {"low": Color(0.55, 0.85, 0.6), "mid": Color(0.95, 0.8, 0.4), "high": Color(1.0, 0.5, 0.45)}

var _tab := "game"
var _tab_buttons: Dictionary = {}
var _content: VBoxContainer
var _scroll: ScrollContainer
var _panel: PanelContainer
var _search: LineEdit
var _reset_btn: Button
var _confirm_reset := false
var _confirm_id := 0
var _import_edit: LineEdit
var _import_note: Label
var _pending_import := ""
var _opts_cache: Array = []

static func open(tab: String = "game") -> SettingsMenu:
	var m := SettingsMenu.new()
	SceneRouter.show_overlay(m)
	m._tab = tab
	m._build()
	return m

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.8))

func _build() -> void:
	_panel = UiKit.centered_panel(self, 1180)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	_panel.add_child(vbox)
	# Cabeçalho: título e pesquisa (288).
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 12)
	vbox.add_child(head)
	var title := UiKit.label(tr("CONFIGURAÇÕES"), 30, UiKit.GOLD)
	title.name = "PathTitle"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	_path_title = title
	_search = LineEdit.new()
	_search.name = "Search"
	_search.placeholder_text = tr("Procurar uma opção…")
	_search.custom_minimum_size = Vector2(380, 50)
	_search.add_theme_font_size_override("font_size", 18)
	_search.clear_button_enabled = true
	_search.text_changed.connect(_on_search)
	head.add_child(_search)
	var body := HBoxContainer.new()
	body.add_theme_constant_override("separation", 14)
	vbox.add_child(body)
	# Separadores à esquerda.
	var tabs := VBoxContainer.new()
	tabs.add_theme_constant_override("separation", 6)
	tabs.custom_minimum_size = Vector2(232, 0)
	body.add_child(tabs)
	for t in TABS:
		var b := UiKit.button(tr(String(t[1])), 48, 17)
		b.name = "Tab_" + String(t[0])
		var id := String(t[0])
		b.pressed.connect(func(): Sfx.select(); _search.text = ""; _show_tab(id))
		tabs.add_child(b)
		_tab_buttons[id] = b
	_scroll = ScrollContainer.new()
	_scroll.custom_minimum_size = Vector2(0, CONTENT_HEIGHT)
	_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body.add_child(_scroll)
	_content = VBoxContainer.new()
	_content.add_theme_constant_override("separation", 8)
	_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll.add_child(_content)
	var close_btn := UiKit.button(tr("FECHAR"), 56, 22, UiKit.PRIMARY, Color(0, 0, 0, 0))
	close_btn.name = "Close"
	close_btn.pressed.connect(func(): Sfx.select(); close())
	vbox.add_child(close_btn)
	_show_tab(_tab)
	SwipeArea.attach(self, _scroll, _on_swipe)   # 0.19.0 (9): deslizar para o lado troca de separador
	UiKit.pop_in(_panel)

func _on_swipe(direction: int) -> void:
	if _search.text.strip_edges() != "":
		return
	var ids: Array = TABS.map(func(t): return String(t[0]))
	var nt := String(SwipeArea.step_id(ids, _tab, direction))
	if nt != _tab:
		Sfx.select()
		_show_tab(nt)

func _paint_tabs(active: String) -> void:
	for id in _tab_buttons:
		var on: bool = id == active
		var b: Button = _tab_buttons[id]
		var st := UiKit.flat(UiKit.GOLD.darkened(0.55) if on else UiKit.BG_LIGHT, 12, UiKit.GOLD if on else Color(0, 0, 0, 0), 2 if on else 0, 10)
		b.add_theme_stylebox_override("normal", st)
		b.add_theme_stylebox_override("hover", st)
		b.add_theme_color_override("font_color", UiKit.GOLD if on else UiKit.TEXT_DIM)

func _clear() -> void:
	for c in _content.get_children():
		_content.remove_child(c)
		c.queue_free()
	_confirm_reset = false
	_scroll.scroll_vertical = 0

var _path_title: Label

func _show_tab(id: String) -> void:
	_tab = id
	_paint_tabs(id)
	if _path_title != null:   # 0.19.0 (154): «Configurações › Visual»
		_path_title.text = tr("CONFIGURAÇÕES") + "  ›  " + UiKit.sentence(_tab_name(id))
	_clear()
	if id == "access":
		_build_presets()
	for d in _options():
		if String(d.get("tab", "")) == id and _visible(d):
			_add_option(d)
	match id:
		"game":
			_build_game_extra()
		"profile":
			_build_profiles()
	_add_reset_row(id)

# --- Pesquisa (288) ---

static func _norm(text: String) -> String:
	var t := text.to_lower()
	var pairs := {"á": "a", "à": "a", "â": "a", "ã": "a", "é": "e", "ê": "e", "í": "i", "ó": "o", "ô": "o", "õ": "o", "ú": "u", "ç": "c"}
	for k in pairs:
		t = t.replace(k, pairs[k])
	return t

## As opções que batem com o texto (no nome ou na ajuda, em português e na língua em uso).
func matches(query: String) -> Array:
	var q := _norm(query.strip_edges())
	var out: Array = []
	if q.length() < 2:
		return out
	for d in _options():
		if not _visible(d):
			continue
		var hay := _norm(String(d.get("label", "")) + " " + tr(String(d.get("label", ""))) + " " + String(d.get("help", "")) + " " + tr(String(d.get("help", ""))))
		if hay.find(q) >= 0:
			out.append(d)
	return out

func _on_search(text: String) -> void:
	if text.strip_edges().length() < 2:
		_show_tab(_tab)
		return
	_paint_tabs("")
	_clear()
	var found := matches(text)
	if found.is_empty():
		_content.add_child(UiKit.label(tr("Nenhuma opção com «%s».") % text.strip_edges(), 18, UiKit.TEXT_DIM, true))
		return
	_content.add_child(UiKit.label(tr("%d opções encontradas") % found.size(), 16, UiKit.TEXT_DIM))
	for d in found:
		_add_option(d, true)

# --- Linhas ---

func _visible(d: Dictionary) -> bool:
	var v = d.get("visible", null)
	return true if not (v is Callable) else bool((v as Callable).call())

## Uma opção: nome (e, na pesquisa, o separador), o controlo, a ajuda (289) e quanto gasta (222).
func _add_option(d: Dictionary, with_tab: bool = false) -> void:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 2)
	box.name = "Opt_" + String(d.get("key", d.get("id", "custom")))
	_content.add_child(box)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	box.add_child(row)
	var label_text := tr(String(d.get("label", "")))
	if with_tab:
		label_text = _tab_name(String(d.get("tab", ""))) + " › " + label_text
	var l := UiKit.label(label_text, 19)
	l.custom_minimum_size = Vector2(340, 0)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(l)
	match String(d.get("kind", "toggle")):
		"toggle":
			_toggle_control(row, d)
		"choice":
			_choice_control(row, d)
		"slider":
			_slider_control(row, d)
		"cycle":
			_cycle_control(row, d)
		"custom":
			(d["build"] as Callable).call(row)
	var help := String(d.get("help", ""))
	var cost := String(d.get("cost", ""))
	if help != "" or cost != "":
		var hrow := HBoxContainer.new()
		hrow.add_theme_constant_override("separation", 8)
		box.add_child(hrow)
		if cost != "":
			var c := UiKit.label("⚡ " + tr(String(COST_NAMES.get(cost, ""))), 13, COST_COLORS.get(cost, UiKit.TEXT_DIM))
			c.name = "Cost"
			hrow.add_child(c)
		if help != "":
			var h := UiKit.label(tr(help), 14, UiKit.TEXT_DIM, true)
			h.name = "Help"
			h.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			hrow.add_child(h)

func _tab_name(id: String) -> String:
	for t in TABS:
		if String(t[0]) == id:
			return tr(String(t[1]))
	return ""

func _after_change(d: Dictionary, value) -> void:
	if bool(d.get("apply", false)):
		Settings.apply()
	var cb = d.get("on_change", null)
	if cb is Callable:
		(cb as Callable).call(value)

func _toggle_control(row: HBoxContainer, d: Dictionary) -> void:
	var key := String(d["key"])
	var names: Array = d.get("names", ["Ligado", "Desligado"])
	var b := UiKit.button("", 50, 19)
	b.name = "Toggle"
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var refresh := func():
		var on := bool(Settings.opt(key))
		b.text = tr(String(names[0])) if on else tr(String(names[1]))
		_paint_toggle(b, on)
	refresh.call()
	b.pressed.connect(func():
		Sfx.select()
		var v := not bool(Settings.opt(key))
		Settings.set_opt(key, v)
		_after_change(d, v)
		refresh.call())
	row.add_child(b)

func _choice_control(row: HBoxContainer, d: Dictionary) -> void:
	var key := String(d["key"])
	var names: Dictionary = d.get("names", {})
	var b := UiKit.button("", 50, 19)
	b.name = "Choice"
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var refresh := func():
		var v = Settings.opt(key)
		b.text = tr(String(names.get(v, str(v))))
	refresh.call()
	b.pressed.connect(func():
		Sfx.select()
		Settings.cycle_opt(key)
		_after_change(d, Settings.opt(key))
		refresh.call())
	row.add_child(b)

func _cycle_control(row: HBoxContainer, d: Dictionary) -> void:
	var b := UiKit.button(String((d["label_fn"] as Callable).call()), 50, 19)
	b.name = "Cycle"
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.pressed.connect(func():
		Sfx.select()
		(d["next_fn"] as Callable).call()
		b.text = String((d["label_fn"] as Callable).call()))
	row.add_child(b)

func _slider_control(row: HBoxContainer, d: Dictionary) -> void:
	var key := String(d["key"])
	var s := HSlider.new()
	s.name = "Slider"
	s.min_value = 0
	s.max_value = 100
	s.step = 5
	s.value = round(float(Settings.opt(key)) * 100.0)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	s.custom_minimum_size = Vector2(0, 44)
	row.add_child(s)
	var v := UiKit.label("%d%%" % int(s.value), 19, UiKit.TEXT_DIM)
	v.custom_minimum_size = Vector2(70, 0)
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	v.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(v)
	s.value_changed.connect(func(x: float):
		v.text = "%d%%" % int(x)
		Settings.set_opt(key, x / 100.0, false)
		_after_change(d, x / 100.0))
	s.drag_ended.connect(func(_changed: bool): Sfx.select(); Settings.save_settings())

func _paint_toggle(b: Button, on: bool) -> void:
	var st := UiKit.flat(Color(0.18, 0.32, 0.22) if on else UiKit.BG_LIGHT, 12, Color(0.45, 0.85, 0.55) if on else Color(0, 0, 0, 0), 2 if on else 0, 10)
	b.add_theme_stylebox_override("normal", st)
	b.add_theme_stylebox_override("hover", st)

func _small_button(row: HBoxContainer, text: String, on_press: Callable, name_: String = "") -> Button:
	var b := UiKit.button(text, 50, 17)
	if name_ != "":
		b.name = name_
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.pressed.connect(on_press)
	row.add_child(b)
	return b

# --- Repor (290) ---

func _keys_of_tab(id: String) -> Array:
	var keys: Array = []
	for d in _options():
		if String(d.get("tab", "")) == id and d.has("key") and String(d.get("kind", "")) != "custom":
			keys.append(String(d["key"]))
	return keys

func _add_reset_row(id: String) -> void:
	var keys := _keys_of_tab(id)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	_content.add_child(row)
	if not keys.is_empty():
		_reset_button(row, tr("REPOR ESTE SEPARADOR"), "ResetTab", func():
			Settings.reset_options(keys)
			SceneRouter.toast(tr("Separador reposto."))
			_show_tab(id))
	if id == "game":
		_reset_button(row, tr("REPOR TUDO"), "ResetAll", func():
			Settings.reset_options([])
			SceneRouter.toast(tr("Todas as configurações repostas."))
			_show_tab(id))

## Botão de 2 toques (o 1.º arma; o 2.º, nos 3 segundos seguintes, faz).
func _reset_button(row: HBoxContainer, text: String, name_: String, action: Callable) -> void:
	var b := UiKit.button(text, 48, 16, UiKit.BTN_BG)
	b.name = name_
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.pressed.connect(func():
		if not bool(b.get_meta("armed", false)):
			Sfx.select()
			b.set_meta("armed", true)
			b.text = tr("TOCA OUTRA VEZ PARA REPOR")
			get_tree().create_timer(3.0).timeout.connect(func():
				if is_instance_valid(b):
					b.set_meta("armed", false)
					b.text = text)
			return
		Sfx.hit()
		action.call())
	row.add_child(b)

# --- Predefinições (287) ---

const PRESET_NAMES := {"vision": "VISÃO", "motor": "MOTRICIDADE", "focus": "CONCENTRAÇÃO"}
const PRESET_HELP := {"vision": "texto maior, alto contraste, lembretes e avisos mais demorados",
	"motor": "1 toque para jogar, botões grandes, toques longos com alternativa e sem gestos",
	"focus": "sem abanões nem flashes, fundo calmo, foco na cascata e avisos no fim da batalha"}

func _build_presets() -> void:
	var box := VBoxContainer.new()
	box.name = "Presets"
	box.add_theme_constant_override("separation", 4)
	_content.add_child(box)
	box.add_child(UiKit.label(tr("Predefinições"), 20, UiKit.GOLD))
	box.add_child(UiKit.label(tr("Um toque liga as opções que mais ajudam; depois podes afinar uma a uma."), 14, UiKit.TEXT_DIM, true))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	box.add_child(row)
	for id in ["vision", "motor", "focus"]:
		var pid := String(id)
		var b := UiKit.wrap_button(tr(String(PRESET_NAMES[pid])) + "\n" + tr(String(PRESET_HELP[pid])), 78, 14)
		b.name = "Preset_" + pid
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(func():
			Sfx.level_up()
			var n := Settings.apply_preset(pid).size()
			SceneRouter.toast(tr("%s: %d opções ligadas.") % [tr(String(PRESET_NAMES[pid])), n] if n > 0 else tr("Já estava tudo assim."))
			_show_tab("access"))
		row.add_child(b)

# --- As opções (dados) ---

func _options() -> Array:
	if not _opts_cache.is_empty():
		return _opts_cache
	var o: Array = []
	var on_off := ["Ligado", "Desligado"]
	var on_off_f := ["Ligada", "Desligada"]
	# JOGO
	o.append({"tab": "game", "id": "language", "label": "Idioma", "kind": "cycle",
		"help": "Interface, cartas, relíquias, inimigos, regras e história.",
		"label_fn": func(): return Settings.language_label(), "next_fn": func(): Settings.cycle_language()})
	# 0.19.0 (293, 294): as cartas noutra língua e o formato dos números.
	o.append({"tab": "game", "key": "cards_language", "label": "Língua das cartas", "kind": "choice",
		"names": {"same": "A do jogo", "pt": "Português", "en": "Inglês"},
		"help": "Cartas em inglês com os menus em português, ou o contrário (os nomes e os textos das cartas)."})
	o.append({"tab": "game", "key": "number_format", "label": "Formato dos números", "kind": "choice",
		"names": {"auto": "12 345 (com espaço)", "pt": "12.345", "en": "12,345"},
		"help": "O separador dos milhares nos golpes, na vida e no ouro."})
	o.append({"tab": "game", "id": "difficulty", "label": "Dificuldade", "kind": "cycle",
		"help": "Vale para todas as runs (a vida dos inimigos, as canalizações e os turnos).",
		"label_fn": func(): return tr(GameState.difficulty_name()), "next_fn": _next_difficulty})
	o.append({"tab": "game", "key": "confirm_buy", "label": "Confirmar compras caras", "kind": "toggle", "names": on_off,
		"help": "Pede um 2.º toque nas compras de 10 ouro ou mais (ou de metade do que tens)."})
	o.append({"tab": "game", "key": "warn_mana", "label": "Aviso: atacar sem gastar a mana", "kind": "toggle", "names": on_off,
		"help": "Avisa quando atacas com mana por gastar e cartas que aumentavam o ataque."})
	o.append({"tab": "game", "key": "warn_rare", "label": "Aviso: canalizar uma rara", "kind": "toggle", "names": on_off,
		"help": "Pede confirmação antes de descartar uma carta rara."})
	o.append({"tab": "game", "key": "tips_enabled", "label": "Dicas das mecânicas", "kind": "toggle", "names": ["Ligadas", "Desligadas"],
		"help": "Uma linha por cima da batalha na 1.ª vez que aparece cada mecânica."})
	o.append({"tab": "game", "key": "play_hints", "label": "Dica de jogada (Fácil)", "kind": "toggle", "names": on_off_f,
		"help": "O botão DICA sugere a melhor jogada no Fácil."})
	o.append({"tab": "game", "key": "show_threats", "label": "Setas do inimigo (o que vai fazer às criaturas)", "kind": "toggle", "names": ["Ligadas", "Desligadas"],
		"help": "Setas e etiquetas por cima das criaturas que o inimigo vai atacar ou afetar."})
	# CONTROLOS
	o.append({"tab": "controls", "key": "play_taps", "label": "Jogar uma carta", "kind": "cycle",
		"help": "Com 2 toques, o 1.º escolhe e o 2.º joga; com 1, joga logo.",
		"label_fn": func(): return tr("2 toques (escolher e jogar)") if Settings.play_taps == 2 else tr("1 toque"),
		"next_fn": func(): Settings.set_opt("play_taps", 1 if Settings.play_taps == 2 else 2)})
	o.append({"tab": "controls", "key": "left_handed", "label": "Mão dominante", "kind": "toggle", "apply": true,
		"names": ["Esquerda (botões à direita)", "Direita (botões à esquerda)"],
		"help": "De que lado ficam os botões de ação."})
	o.append({"tab": "controls", "key": "one_hand", "label": "Modo de uma mão", "kind": "toggle", "apply": true,
		"names": ["Ligado (botões em baixo)", "Desligado"],
		"help": "ATACAR, CANALIZAR e DESFAZER ao lado da mão, do lado da mão dominante."})
	o.append({"tab": "controls", "key": "vibration", "label": "Vibração", "kind": "toggle", "names": on_off_f,
		"help": "O telemóvel vibra ao jogar, nos golpes e quando levas dano.",
		"on_change": _test_vibration})
	o.append({"tab": "controls", "key": "vibration_strength", "label": "Força da vibração", "kind": "choice",
		"names": {1: "Fraca", 2: "Média", 3: "Forte"}, "help": "Quanto vibra quando vibra.",
		"visible": func(): return Settings.vibration, "on_change": _test_vibration})
	# 0.19.0: gestos e botões (3–8, 24, 26–29)
	o.append({"tab": "controls", "key": "battle_buttons", "label": "Botões da batalha (ATACAR, CANALIZAR, DESFAZER)", "kind": "choice", "apply": true,
		"names": {"hand": "Do lado da mão dominante", "left": "Sempre à esquerda", "right": "Sempre à direita", "bottom": "Em baixo, ao lado da mão"},
		"help": "Onde ficam os botões de agir na batalha («em baixo» é como o modo de uma mão)."})
	o.append({"tab": "controls", "key": "hand_offset", "label": "Altura da mão", "kind": "choice", "apply": true,
		"names": {-16: "Mais em baixo", 0: "Normal", 16: "Mais acima", 32: "Bem acima"},
		"help": "Sobe a mão para longe da barra do Android, ou desce-a para ganhar espaço."})
	o.append({"tab": "controls", "key": "buttons_big", "label": "Tamanho dos botões", "kind": "choice",
		"names": {0: "Normais (48 px)", 1: "Maiores (56 px)", 2: "Grandes (64 px)"},
		"help": "Botões mais altos, sem mexer no tamanho do resto.", "on_change": _refresh_buttons})
	o.append({"tab": "controls", "key": "long_press", "label": "Toque longo", "kind": "choice",
		"names": {"short": "Curto (0,3 s)", "normal": "Normal (0,4 s)", "long": "Longo (0,65 s)"},
		"help": "Quanto tempo segurar o dedo para abrir a carta em grande."})
	o.append({"tab": "controls", "key": "drag_threshold", "label": "Sensibilidade do arrasto", "kind": "choice",
		"names": {"low": "Sensível (10 px)", "normal": "Normal (16 px)", "high": "Firme (26 px, para mãos que tremem)"},
		"help": "Quanto o dedo tem de andar até um toque virar arrasto."})
	o.append({"tab": "controls", "key": "hold_attack", "label": "ATACAR a segurar", "kind": "toggle", "names": ["Ligado (meio segundo)", "Desligado"],
		"help": "Para nunca atacar sem querer: segura o ATACAR meio segundo (a barra enche)."})
	o.append({"tab": "controls", "key": "two_finger", "label": "Gestos com dois dedos", "kind": "toggle", "names": ["Ligados", "Desligados"],
		"help": "Na batalha: tocar com dois dedos abre a pausa; deslizar com dois dedos para a esquerda desfaz."})
	o.append({"tab": "controls", "key": "edge_guard", "label": "Margens a salvo dos gestos do Android", "kind": "toggle", "names": on_off,
		"help": "Nada se arrasta a partir da borda (onde o gesto de voltar o apanha) e o jogo fica fora dos entalhes do ecrã.",
		"on_change": _refresh_safe_area})
	o.append({"tab": "controls", "key": "palm_guard", "label": "Ignorar a palma nas bordas", "kind": "toggle", "names": on_off,
		"help": "Para ecrãs curvos: um toque que começa colado à borda não conta."})
	o.append({"tab": "controls", "id": "keys_help", "label": "Teclado e comando", "kind": "custom", "build": _build_keys_note,
		"help": "Teclado: Espaço ataca · C canaliza · Z desfaz · Esc pausa · 1 a 9 escolhem a carta · setas mudam de carta · Enter joga. Comando: A joga · X ataca · Y canaliza · Back desfaz · Start pausa · LB/RB e o direcional escolhem a carta · B volta. Nos menus, o direcional escolhe o botão (com a moldura dourada) e o A carrega."})
	# RITMO
	o.append({"tab": "pace", "id": "anim_speed", "label": "Velocidade das animações", "kind": "cycle",
		"help": "Normal, rápida ou instantânea (o botão ▶ da batalha muda o mesmo).",
		"label_fn": func(): return Settings.speed_label(), "next_fn": func(): Settings.cycle_speed()})
	# 0.19.0 (secção 6): o ritmo da batalha, dos menus e da sessão.
	o.append({"tab": "pace", "key": "enemy_speed", "label": "Turno do inimigo", "kind": "choice",
		"names": {"normal": "Normal", "fast": "Rápido", "instant": "Instantâneo (só o resumo)"},
		"help": "Quanto tempo o inimigo demora a jogar. No instantâneo vês só o que ele fez, no fim."})
	o.append({"tab": "pace", "key": "intro_once", "label": "Apresentação dos inimigos só da 1.ª vez", "kind": "toggle", "names": on_off_f,
		"help": "A entrada com o nome e a frase do inimigo só aparece na primeira vez que o enfrentas."})
	o.append({"tab": "pace", "key": "short_banners", "label": "Letreiros curtos", "kind": "toggle", "names": on_off,
		"help": "«TURNO 2», «FORMAÇÃO!» e os outros letreiros ficam no ecrã metade do tempo."})
	o.append({"tab": "pace", "key": "short_celebrations", "label": "Festejos curtos", "kind": "toggle", "names": on_off,
		"help": "Recordes e conquistas repetidos festejam-se num instante."})
	o.append({"tab": "pace", "key": "auto_end", "label": "Atacar sozinho sem jogadas", "kind": "toggle", "names": on_off,
		"help": "Sem mana nem jogadas possíveis, o ATACAR carrega-se sozinho ao fim de 1 segundo (tocar no ecrã cancela)."})
	o.append({"tab": "pace", "key": "booster_fast", "label": "Abrir boosters depressa", "kind": "toggle", "names": on_off,
		"help": "As cartas do booster aparecem todas de uma vez, sem virar uma a uma."})
	o.append({"tab": "pace", "key": "wheel_fast", "label": "Roda da sorte sem girar", "kind": "toggle", "names": on_off_f,
		"help": "Nos eventos com roda, o resultado aparece logo."})
	o.append({"tab": "pace", "key": "rewards_toast", "label": "Recompensas num aviso", "kind": "toggle", "names": on_off_f,
		"help": "Depois de uma batalha simples, o ouro e o resto aparecem num aviso, sem janela."})
	o.append({"tab": "pace", "key": "card_reward", "label": "Cartas depois das batalhas", "kind": "toggle", "names": ["Sim", "Não"],
		"help": "Escolher uma carta depois de cada batalha (como nos jogos do género). Também na Campanha."})
	o.append({"tab": "pace", "key": "interludes", "label": "Interlúdios entre atos", "kind": "choice",
		"names": {"always": "Sempre", "first": "Só da primeira vez"},
		"help": "As páginas da história entre um ato e o seguinte."})
	o.append({"tab": "pace", "key": "merchant_lines", "label": "Frases do mercador", "kind": "choice",
		"names": {"always": "Sempre", "sometimes": "Às vezes", "never": "Nunca"},
		"help": "O que o mercador diz quando entras, compras ou sais da loja."})
	o.append({"tab": "pace", "key": "news_auto", "label": "Novidades ao abrir", "kind": "toggle", "names": on_off_f,
		"help": "Depois de uma atualização, as novidades abrem sozinhas. Desligado: só um aviso."})
	o.append({"tab": "pace", "key": "speedrun", "label": "Cronómetro da run", "kind": "toggle", "names": on_off,
		"help": "Mostra o tempo da run num canto e guarda o teu melhor tempo por modo."})
	o.append({"tab": "pace", "key": "break_reminder", "label": "Lembrete de pausa", "kind": "choice",
		"names": {0: "Nunca", 30: "A cada 30 min", 60: "A cada hora", 90: "A cada hora e meia"},
		"help": "Uma janela a sugerir uma pausa (podes continuar ou gravar e sair)."})
	o.append({"tab": "pace", "key": "self_limit", "label": "Limite que escolhes", "kind": "choice",
		"names": {"off": "Sem limite", "runs1": "1 run por sessão", "runs3": "3 runs por sessão", "min30": "30 minutos", "min45": "45 minutos", "min60": "1 hora"},
		"help": "Quando chegas ao limite, o jogo avisa (não te tira do jogo)."})
	o.append({"tab": "pace", "key": "rules_refresher", "label": "Regras ao voltar", "kind": "toggle", "names": on_off_f,
		"help": "Depois de um mês sem jogar, um resumo das regras em 30 segundos."})
	# VISUAL
	o.append({"tab": "visual", "id": "ui_scale", "label": "Escala da interface", "kind": "custom", "build": _build_scale,
		"help": "Acima de 100 % a interface só cresce onde o ecrã tem altura de sobra (tablets); nos telemóveis compridos usa o texto maior."})
	o.append({"tab": "visual", "key": "compact", "label": "Modo compacto (cartas mais pequenas)", "kind": "toggle", "names": on_off, "apply": true,
		"help": "Cartas e tabuleiro mais baixos, para telemóveis pequenos."})
	o.append({"tab": "visual", "id": "hand_scale", "label": "Tamanho das cartas da mão", "kind": "cycle",
		"help": "As cartas da mão maiores ou mais pequenas (o resto não muda).",
		"label_fn": func(): return Settings.hand_scale_label(), "next_fn": func(): Settings.cycle_hand_scale(); Settings.apply()})
	o.append({"tab": "visual", "key": "tilt_3d", "label": "Carta em grande inclina com o telemóvel", "kind": "toggle", "names": ["Ligado (3D)", "Desligado"],
		"help": "A carta em grande mexe-se quando inclinas o telemóvel.", "cost": "low"})
	o.append({"tab": "visual", "key": "foil_zoom_only", "label": "Brilho holográfico só na carta em grande", "kind": "toggle", "names": on_off, "apply": true, "cost": "low",
		"help": "Na mão, no tabuleiro e na loja, as raras ficam sem o efeito (gasta menos); na carta em grande continua."})
	o.append({"tab": "visual", "key": "theme", "label": "Tema", "kind": "choice", "apply": true, "cost": "low",
		"names": {"classic": "Clássico", "black": "Preto (OLED)", "light": "Claro (pergaminho)"},
		"help": "Preto: fundos pretos a sério, que gastam menos nos ecrãs OLED. Claro: as janelas em pergaminho com letra escura, para quem lê melhor em fundo claro. Aplica-se por completo ao mudar de ecrã."})
	o.append({"tab": "visual", "key": "show_art", "label": "Ilustrações", "kind": "toggle", "apply": true,
		"names": ["Ligadas", "Desligadas (só desenhos)"], "help": "As ilustrações das cartas, dos inimigos e dos fundos.", "cost": "mid",
		"visible": func(): return ArtLib.total() > 0})
	# 0.19.0 (118–120): foco na cascata, fundo calmo e brilho das ilustrações.
	o.append({"tab": "visual", "key": "focus_cascade", "label": "Foco na cascata", "kind": "toggle", "names": on_off, "cost": "low",
		"help": "Durante o ataque, escurece tudo menos a carta ou relíquia que está a disparar."})
	o.append({"tab": "visual", "key": "calm_bg", "label": "Fundo da batalha mais calmo", "kind": "toggle", "names": on_off, "cost": "low",
		"help": "Escurece o fundo e o clima da batalha, para as cartas se destacarem (sem ligar o alto contraste)."})
	o.append({"tab": "visual", "key": "art_brightness", "label": "Brilho das ilustrações", "kind": "choice",
		"names": {1.0: "Normal", 1.15: "Mais claras", 1.3: "Muito claras"},
		"help": "Só as imagens: as mais escuras perdem-se ao sol.", "visible": func(): return ArtLib.total() > 0})
	o.append({"tab": "visual", "key": "accent", "label": "Cor de destaque", "kind": "choice", "apply": true,
		"names": {"gold": "Dourado", "blue": "Azul", "green": "Verde", "red": "Vermelho"},
		"help": "A cor dos botões principais. Aplica-se por completo ao mudar de ecrã."})
	o.append({"tab": "visual", "key": "menu_bg", "label": "Fundo do menu", "kind": "choice",
		"names": {"act": "O ato da última run", "faction": "A fação favorita", "plain": "Liso"},
		"help": "A ilustração por trás do menu principal."})
	o.append({"tab": "visual", "key": "tablet", "label": "Modo tablet", "kind": "choice",
		"names": {"auto": "Automático", "on": "Ligado", "off": "Desligado"},
		"help": "Nos ecrãs grandes, as cartas da mão ficam maiores (automático: 7 polegadas ou mais)."})
	o.append({"tab": "visual", "key": "random_cosmetics", "label": "Cosméticos ao acaso", "kind": "toggle", "names": on_off_f,
		"help": "Cada run sorteia costas, moldura, tapete e efeito entre os que já tens."})
	o.append({"tab": "visual", "id": "cosmetics", "label": "Costas, molduras, tapetes e efeitos", "kind": "custom", "build": _build_cosmetics,
		"help": "Ganhas mais na História, nos Desafios, no Infinito e com conquistas. Não mexem no jogo."})
	# TEXTO E HUD
	o.append({"tab": "text", "key": "large_text", "label": "Texto das cartas", "kind": "toggle", "apply": true, "names": ["Grande", "Normal"],
		"help": "Letras maiores nas cartas (a ilustração fica um pouco mais baixa)."})
	# 0.19.0 (secção 5): legibilidade e HUD.
	o.append({"tab": "text", "key": "menu_text", "label": "Texto dos menus", "kind": "choice",
		"names": {1.0: "Normal", 1.15: "Maior", 1.3: "Muito maior"},
		"help": "Janelas, avisos e listas com letra maior, sem aumentar a interface toda (vale nas janelas que abrires a seguir)."})
	o.append({"tab": "text", "key": "toast_time", "label": "Tempo dos avisos", "kind": "choice",
		"names": {"normal": "Normal (3 s)", "long": "Mais tempo (5 s)", "longer": "Muito tempo (8 s)", "tap": "Até lhe tocares"},
		"help": "Quanto tempo ficam no ecrã os avisos de cima (conquistas, compras…). O sino do menu guarda os últimos 20."})
	o.append({"tab": "text", "key": "boss_wait", "label": "Falas dos bosses até tocares", "kind": "toggle", "names": on_off,
		"help": "Os balões dos bosses não fogem a meio da leitura: fecham quando lhes tocas."})
	o.append({"tab": "text", "key": "clock", "label": "Relógio no canto", "kind": "toggle", "names": on_off,
		"help": "As horas no canto de baixo à direita (o jogo esconde a barra do Android)."})
	o.append({"tab": "text", "key": "icon_labels", "label": "Nomes por baixo dos ícones", "kind": "toggle", "names": on_off,
		"help": "Na batalha, o nome por baixo dos botões que só têm ícone (pausa, desfazer, pilhas)."})
	o.append({"tab": "text", "key": "numbers", "label": "Números grandes", "kind": "choice",
		"names": {"auto": "Abreviados só no Infinito", "full": "Sempre completos", "short": "Sempre abreviados (1,2 M)"},
		"help": "Como aparecem os números do ataque e da vida do inimigo."})
	o.append({"tab": "text", "key": "light_cards", "label": "Cartas claras", "kind": "toggle", "names": on_off, "apply": true,
		"help": "Fundo claro e texto escuro na parte do texto das cartas, mais fácil de ler ao sol."})
	o.append({"tab": "text", "key": "kw_reminders", "label": "Lembretes das palavras-chave", "kind": "toggle", "names": on_off, "apply": true,
		"help": "O que cada palavra-chave faz, entre parênteses, na própria carta («Voar: os lacaios do inimigo não a travam»)."})
	o.append({"tab": "text", "key": "cascade_big", "label": "Números da cascata maiores", "kind": "toggle", "names": on_off,
		"help": "As etiquetas que voam durante o ataque, maiores."})
	o.append({"tab": "text", "key": "cascade_bg", "label": "Fundo por trás dos números a voar", "kind": "toggle", "names": on_off,
		"help": "Uma pílula escura atrás de cada etiqueta da cascata, para se ler por cima das ilustrações."})
	o.append({"tab": "text", "key": "typewriter", "label": "Máquina de escrever", "kind": "choice",
		"names": {"slow": "Lenta", "normal": "Normal", "fast": "Rápida", "instant": "O texto todo de uma vez"},
		"help": "A velocidade das letras nos interlúdios dos atos."})
	for hud in [["hud_climate", "Barra de cima: clima"], ["hud_contract", "Barra de cima: contrato"], ["hud_patron", "Barra de cima: patrono em grande"],
			["hud_chain", "Barra de cima: Cadeia"], ["hud_objective", "Barra de cima: objetivo da batalha"]]:
		o.append({"tab": "text", "key": hud[0], "label": hud[1], "kind": "toggle", "names": ["Mostrar", "Esconder"],
			"help": "O que aparece por cima do cálculo na batalha (o patrono escondido fica pequeno, com as habilidades)."})
	o.append({"tab": "text", "id": "explain_mode", "label": "Modo explicar", "kind": "custom", "build": _build_explain_row,
		"help": "Cada toque explica o que tocaste em vez de agir, até o desligares (também na pausa da batalha). O toque longo num ícone explica-o sempre."})
	# SOM
	o.append({"tab": "sound", "key": "master_volume", "label": "Volume geral", "kind": "slider", "apply": true,
		"help": "Tudo: música, efeitos e cliques."})
	o.append({"tab": "sound", "key": "sfx_volume", "label": "Efeitos sonoros", "kind": "slider", "apply": true,
		"help": "Os sons do jogo (cartas, golpes, moedas)."})
	o.append({"tab": "sound", "key": "ui_volume", "label": "Cliques da interface", "kind": "slider", "apply": true,
		"help": "O som dos botões e dos menus (em proporção dos efeitos)."})
	o.append({"tab": "sound", "key": "music_volume", "label": "Música", "kind": "slider", "apply": true,
		"help": "A música dos menus, dos atos e dos bosses.", "visible": func(): return Settings.has_music()})
	o.append({"tab": "sound", "key": "muted", "label": "Silêncio", "kind": "toggle", "apply": true, "names": ["Tudo calado", "Desligado"],
		"help": "Cala o jogo todo sem mexer nos volumes."})
	o.append({"tab": "sound", "key": "mono", "label": "Som mono", "kind": "toggle", "apply": true, "names": on_off,
		"help": "O mesmo som nas duas colunas (para quem ouve só de um lado)."})
	o.append({"tab": "sound", "key": "soft_sounds", "label": "Sons suaves", "kind": "toggle", "apply": true, "names": on_off,
		"help": "Efeitos mais baixos e menos agudos, para quem se incomoda com barulho."})
	# 0.19.0 (secção 9): som para todos.
	o.append({"tab": "sound", "key": "attack_music", "label": "Música do ataque", "kind": "toggle", "names": on_off_f,
		"help": "A percussão que cresce durante a cascata, por cima da música."})
	o.append({"tab": "sound", "key": "captions", "label": "Legendas dos sons", "kind": "toggle", "names": on_off_f,
		"help": "«O boss ruge», «Relíquia dispara»… do lado direito do ecrã, para quem joga sem som."})
	o.append({"tab": "sound", "key": "cues", "label": "Avisos para os olhos e para a mão", "kind": "toggle", "names": on_off,
		"help": "Os sons que avisam (relíquias, bosses, cartas presas) também fazem brilhar as bordas do ecrã e vibrar."})
	o.append({"tab": "sound", "id": "jukebox", "label": "Jukebox", "kind": "custom", "build": _build_jukebox_row,
		"help": "Ouve as faixas do jogo e escolhe a música do menu."})
	# ACESSIBILIDADE
	o.append({"tab": "access", "key": "colorblind", "label": "Modo daltónico", "kind": "toggle", "apply": true,
		"names": ["Ligado (símbolos nas cores)", "Desligado"], "help": "Um símbolo em cada cor de mana: sol, gota, caveira, chama e árvore."})
	o.append({"tab": "access", "key": "reduce_motion", "label": "Reduzir movimento", "kind": "toggle", "apply": true, "cost": "low",
		"names": ["Ligado (sem abanões, flashes nem partículas)", "Desligado"], "help": "Desliga de uma vez tudo o que abana, pisca ou voa."})
	o.append({"tab": "access", "key": "high_contrast", "label": "Alto contraste", "kind": "toggle", "apply": true,
		"names": ["Ligado (textos e contornos mais fortes)", "Desligado"], "help": "Aplica-se por completo ao mudar de ecrã."})
	# 0.19.0 (secção 9): ler, ver, mexer e ajudas.
	o.append({"tab": "access", "key": "colorblind_filter", "label": "Filtro de daltonismo", "kind": "choice", "cost": "mid",
		"names": {"none": "Nenhum", "protan": "Protanopia (vermelho)", "deutan": "Deuteranopia (verde)", "tritan": "Tritanopia (azul)"},
		"help": "Corrige as cores do ecrã todo para separares melhor as barras, o Poder e o Mult e o mapa."})
	o.append({"tab": "access", "key": "dyslexic", "label": "Letra para dislexia", "kind": "toggle", "apply": true, "names": on_off_f,
		"help": "Todo o texto em OpenDyslexic (licença livre). Aplica-se por completo ao mudar de ecrã."})
	o.append({"tab": "access", "key": "spacing", "label": "Mais espaço entre letras e linhas", "kind": "toggle", "apply": true, "names": on_off,
		"help": "Para quem se perde em linhas apertadas."})
	o.append({"tab": "access", "key": "tts_auto", "label": "Ler as cartas em voz alta", "kind": "toggle", "names": on_off,
		"help": "Ao abrir uma carta em grande, a voz do telemóvel lê-a (também há o botão do altifalante na carta)."})
	o.append({"tab": "access", "key": "tts_duck", "label": "Baixar a música quando a voz lê", "kind": "toggle", "names": on_off,
		"help": "Enquanto a voz lê uma carta ou um botão, a música fica quase calada (ainda se ouve baixinho) e volta no fim."})
	o.append({"tab": "access", "key": "reader", "label": "Modo leitor", "kind": "toggle", "names": on_off,
		"help": "Ao tocar num botão, a voz diz o que ele faz; toca outra vez (em 3 s) para carregar."})
	o.append({"tab": "access", "key": "fx_shake", "label": "Abanões", "kind": "toggle", "names": on_off, "visible": func(): return not Settings.reduce_motion,
		"help": "O ecrã treme nos golpes."})
	o.append({"tab": "access", "key": "shake_strength", "label": "Força dos abanões", "kind": "slider",
		"visible": func(): return not Settings.reduce_motion and bool(Settings.opt("fx_shake")), "help": "De 0 a 100 %."})
	o.append({"tab": "access", "key": "fx_flash", "label": "Flashes", "kind": "toggle", "names": on_off, "visible": func(): return not Settings.reduce_motion,
		"help": "Clarões nos golpes e quando levas dano."})
	o.append({"tab": "access", "key": "fx_particles", "label": "Partículas", "kind": "toggle", "names": on_off_f, "visible": func(): return not Settings.reduce_motion,
		"help": "Faíscas, confetes, cinza e o clima a cair."})
	o.append({"tab": "access", "key": "fx_flips", "label": "Cartas a virar", "kind": "toggle", "names": on_off, "visible": func(): return not Settings.reduce_motion,
		"help": "As cartas viram-se ao sair do grimório e dos boosters."})
	o.append({"tab": "access", "key": "fx_living_art", "label": "Arte viva das míticas", "kind": "toggle", "names": on_off_f, "visible": func(): return not Settings.reduce_motion,
		"help": "As ilustrações das cartas míticas mexem-se devagar."})
	o.append({"tab": "access", "key": "assist_turn", "label": "Assistido: +1 turno", "kind": "toggle", "names": on_off,
		"help": "Mais um turno em cada batalha, sem mudar a dificuldade."})
	o.append({"tab": "access", "key": "assist_channel", "label": "Assistido: +1 canalização", "kind": "toggle", "names": on_off_f,
		"help": "Mais uma troca de carta em cada batalha."})
	o.append({"tab": "access", "key": "assist_hp", "label": "Assistido: inimigos com menos vida", "kind": "toggle", "names": on_off,
		"help": "Os inimigos começam com menos 25 % de vida."})
	o.append({"tab": "access", "key": "assist_rewind", "label": "Assistido: rebobinar o turno", "kind": "toggle", "names": on_off,
		"help": "Depois de atacar, voltar ao início desse turno (na pausa), uma vez por batalha."})
	o.append({"tab": "access", "key": "assist_retry", "label": "Assistido: repetir a batalha perdida", "kind": "toggle", "names": on_off,
		"help": "Ao perder, recomeçar essa batalha uma vez por run, em vez de a run acabar."})
	o.append({"tab": "access", "key": "hint_all", "label": "DICA em todas as dificuldades", "kind": "toggle", "names": on_off_f,
		"help": "O botão DICA da batalha também no Normal e no Difícil."})
	o.append({"tab": "access", "key": "simple_text", "label": "Texto simples nas cartas", "kind": "toggle", "names": on_off,
		"help": "As palavras do jogo trocadas por palavras do dia a dia (mesa, baralho, pilha das usadas…), para quem está a aprender."})
	o.append({"tab": "access", "key": "move_buttons", "label": "Tudo sem arrastar", "kind": "toggle", "names": on_off,
		"help": "Tocar numa criatura ou relíquia dá botões ◀ ▶ para mudar a ordem."})
	o.append({"tab": "access", "key": "no_longpress", "label": "Sem toques longos", "kind": "toggle", "names": on_off,
		"help": "A carta escolhida ganha um botão VER e as criaturas abrem o menu com um toque."})
	o.append({"tab": "access", "key": "touch_circle", "label": "Círculo no sítio do toque", "kind": "toggle", "names": on_off,
		"help": "Mostra onde o dedo tocou (ajuda quem treme e quem grava vídeos)."})
	o.append({"tab": "access", "id": "fonts", "label": "Tipos de letra", "kind": "custom", "build": _build_fonts_note,
		"help": "Inter, Lora, New Rocker e OpenDyslexic (SIL Open Font License)."})
	# DESEMPENHO
	o.append({"tab": "perf", "key": "performance_mode", "label": "Modo de desempenho", "kind": "toggle", "apply": true,
		"names": ["Ligado (30 FPS e menos efeitos)", "Desligado"], "help": "Para telemóveis fracos ou para poupar bateria.", "cost": "low",
		"on_change": _perf_changed})
	# 0.19.0 (secção 7): calor e bateria.
	o.append({"tab": "perf", "key": "auto_perf", "label": "Modo de desempenho automático", "kind": "toggle", "names": on_off, "cost": "low",
		"help": "Se o jogo ficar lento muito tempo (sinal de que o telemóvel está a aquecer), o modo de desempenho liga-se sozinho e avisa."})
	o.append({"tab": "perf", "key": "saver_extra", "label": "Poupança extra (20 FPS fora da batalha)", "kind": "toggle", "names": on_off_f, "cost": "low",
		"help": "Menus, mapa e loja a 20 FPS; a batalha fica igual. Para telemóveis muito fracos ou bateria baixa."})
	o.append({"tab": "perf", "id": "fps_cap", "label": "Limite de FPS (bateria)", "kind": "cycle", "cost": "mid",
		"help": "60 é mais fluido; 30 gasta menos bateria e aquece menos.",
		"label_fn": func(): return "%d FPS" % Settings.fps_cap,
		"next_fn": _next_fps_cap})
	o.append({"tab": "perf", "key": "keep_screen_on", "label": "Ecrã sempre ligado na batalha", "kind": "toggle", "names": on_off, "cost": "mid",
		"help": "O ecrã não se apaga enquanto pensas na jogada."})
	o.append({"tab": "perf", "key": "dim_idle", "label": "Escurecer o ecrã parado", "kind": "toggle", "names": on_off, "cost": "low",
		"help": "Na batalha, com o ecrã sempre ligado: escurece ao fim de 2 minutos sem toques (o primeiro toque só acende).",
		"visible": func(): return Settings.keep_screen_on})
	o.append({"tab": "perf", "key": "screen_limit", "label": "Deixar o ecrã apagar-se ao fim de 5 minutos", "kind": "toggle", "names": on_off, "cost": "low",
		"help": "Mesmo na batalha: 5 minutos sem toques e o telemóvel pode apagar o ecrã como de costume.",
		"visible": func(): return Settings.keep_screen_on})
	_opts_cache = o
	return o

## 206: desligaste o modo de desempenho à mão — deixa de estar marcado como automático.
func _perf_changed() -> void:
	if not Settings.performance_mode and bool(Settings.opt("auto_perf_on")):
		Settings.set_opt("auto_perf_on", false)

func _build_jukebox_row(row: HBoxContainer) -> void:
	var b := UiKit.button(tr("ABRIR A JUKEBOX"), 48, 17)
	b.name = "JukeboxBtn"
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.pressed.connect(func(): Sfx.select(); Jukebox.open())
	row.add_child(b)

func _build_fonts_note(row: HBoxContainer) -> void:
	var l := UiKit.label(tr("Fontes: Inter, Lora, New Rocker e OpenDyslexic"), 16, UiKit.TEXT_DIM, true)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(l)

func _build_explain_row(row: HBoxContainer) -> void:
	var b := UiKit.button(tr("LIGAR O MODO EXPLICAR"), 48, 17)
	b.name = "ExplainOn"
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.pressed.connect(func():
		Sfx.select()
		close()
		SceneRouter.set_explain_mode(true))
	row.add_child(b)

func _build_keys_note(row: HBoxContainer) -> void:
	var l := UiKit.label(tr("Ligam-se sozinhos ao usar um comando ou o teclado."), 17, UiKit.TEXT_DIM, true)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(l)

func _refresh_buttons(_v = null) -> void:
	SceneRouter.refresh_buttons()

func _refresh_safe_area(_v = null) -> void:
	SceneRouter.refresh_safe_area()

func _test_vibration(v) -> void:
	if bool(v):
		Settings.vibrate(40)

func _next_difficulty() -> void:
	GameState.cycle_difficulty()
	SceneRouter.toast(GameState.difficulty_text())

func _next_fps_cap() -> void:
	Settings.fps_cap = 30 if Settings.fps_cap == 60 else 60
	Settings.apply()

func _build_scale(row: HBoxContainer) -> void:
	var minus := UiKit.button("−", 50, 24)
	minus.name = "ScaleMinus"
	minus.custom_minimum_size.x = 70
	row.add_child(minus)
	var value := UiKit.label(Settings.scale_label(), 19)
	value.name = "ScaleValue"
	value.custom_minimum_size.x = 250
	value.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	value.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(value)
	var plus := UiKit.button("+", 50, 24)
	plus.name = "ScalePlus"
	plus.custom_minimum_size.x = 70
	row.add_child(plus)
	minus.pressed.connect(func(): Sfx.select(); Settings.cycle_scale(-1); value.text = Settings.scale_label())
	plus.pressed.connect(func(): Sfx.select(); Settings.cycle_scale(1); value.text = Settings.scale_label())

func _build_cosmetics(row: HBoxContainer) -> void:
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 6)
	row.add_child(col)
	for kind in ["back", "frame", "mat", "effect"]:
		var k := String(kind)
		var b := UiKit.button(_cosmetic_title(k) + ": " + _cosmetic_label(k), 48, 16)
		b.name = "Cosmetic_" + k
		b.pressed.connect(func():
			Sfx.select()
			Settings.cycle_cosmetic(k)
			Settings.save_settings()
			b.text = _cosmetic_title(k) + ": " + _cosmetic_label(k))
		col.add_child(b)

func _cosmetic_title(kind: String) -> String:
	match kind:
		"back":
			return tr("Costas")
		"frame":
			return tr("Moldura")
		"mat":
			return tr("Tapete da Arena")
	return tr("Efeito do golpe")

func _cosmetic_label(kind: String) -> String:
	var id := Settings.cosmetic(kind)
	var c := CardDB.get_cosmetic(kind, id)
	var owned := Settings.unlocked_cosmetics(kind).size()
	var total := (CardDB.cosmetics.get(kind + "s", []) as Array).size()
	return tr(String(c.get("name", id))) + "   (%d/%d)" % [owned, total]

# --- JOGO: tutorial, progresso, cópias e relatório ---

func _plain_row(text: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	_content.add_child(row)
	var l := UiKit.label(text, 19)
	l.custom_minimum_size = Vector2(340, 0)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(l)
	return row

func _build_game_extra() -> void:
	var tut_row := _plain_row(tr("Tutorial"))
	var tut_btn := _small_button(tut_row, tr("REPETIR NA PRÓXIMA BATALHA"), func(): pass)
	tut_btn.pressed.connect(func():
		Stats.set_tutorial_done(false)
		GameState.reset_tips()   # as dicas das mecânicas voltam a aparecer
		Sfx.select()
		tut_btn.text = tr("Tutorial marcado  ✓")
		tut_btn.disabled = true)
	# Progresso: copiar para outro telemóvel e apagar.
	var prog := _plain_row(tr("Progresso"))
	_small_button(prog, tr("EXPORTAR"), _on_export)
	_small_button(prog, tr("IMPORTAR"), _on_import_open)
	_reset_btn = UiKit.button(tr("APAGAR PROGRESSO"), 50, 17, UiKit.DANGER, Color(0, 0, 0, 0))
	_reset_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_reset_btn.pressed.connect(_on_reset)
	prog.add_child(_reset_btn)
	# 0.12.0: cópias de segurança (as 3 últimas, feitas ao abrir o jogo) e relatório de erros.
	var safe := _plain_row(tr("Cópias de segurança"))
	var backups := GameState.backups_info()
	var see := _small_button(safe, tr("VER CÓPIAS (%d)") % backups.size(), _on_backups_open, "Backups")
	see.disabled = backups.is_empty()
	# 0.19.0 (233): quanto ocupa o jogo no telemóvel, com LIMPAR onde dá.
	var space := _plain_row(tr("Espaço ocupado"))
	var total := 0
	for u in Storage.usage():
		total += int(u[2])
	_small_button(space, tr("VER (%s)") % Storage.fmt_bytes(total), _on_storage_open, "Storage")
	var help := _plain_row(tr("Problemas"))
	var report := _small_button(help, tr("COPIAR RELATÓRIO DE ERROS"), func(): pass, "ErrorReport")
	report.pressed.connect(func():
		Sfx.select()
		DisplayServer.clipboard_set(ErrorReport.build())
		report.text = tr("Copiado ✓ — cola-o numa mensagem"))
	_import_note = UiKit.label("", 16, UiKit.TEXT_DIM, true)
	_content.add_child(_import_note)

## As cópias de segurança do progresso: data e resumo de cada uma; REPOR pede um 2.º toque.
func _on_backups_open() -> void:
	Sfx.select()
	_clear()
	_content.add_child(UiKit.label(tr("Cópias de segurança"), 22, UiKit.GOLD))
	_content.add_child(UiKit.label(tr("O jogo guarda uma cópia do progresso cada vez que abre (as 3 últimas). Repor uma cópia substitui o progresso atual — que passa a ser a cópia 1, para poderes voltar atrás."), 17, Color.WHITE, true))
	for info in GameState.backups_info():
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		_content.add_child(row)
		var when := Time.get_datetime_string_from_unix_time(int(info.get("time", 0)) + int(Time.get_time_zone_from_system().get("bias", 0)) * 60, true)
		var l := UiKit.label(tr("Cópia %d  ·  %s\n%d runs, %d vitórias, %d conquistas") % [int(info["index"]), when, int(info.get("runs", 0)), int(info.get("wins", 0)), int(info.get("achievements", 0))], 17, Color.WHITE)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(l)
		var b := UiKit.button(tr("REPOR"), 54, 18)
		b.name = "Restore%d" % int(info["index"])
		b.custom_minimum_size.x = 190
		var idx := int(info["index"])
		b.pressed.connect(func():
			if not bool(b.get_meta("armed", false)):
				Sfx.select()
				b.set_meta("armed", true)
				b.text = tr("TOCA OUTRA VEZ")
				return
			if GameState.restore_backup(idx):
				Sfx.boom()
				close()
				SceneRouter.go("main"))
		row.add_child(b)
	var back := UiKit.button(tr("VOLTAR"), 50, 18)
	back.name = "Back"
	back.pressed.connect(func(): Sfx.select(); _show_tab("game"))
	_content.add_child(back)

# --- PERFIL (291, 298) ---

func _build_profiles() -> void:
	var box := VBoxContainer.new()
	box.name = "Profiles"
	box.add_theme_constant_override("separation", 8)
	_content.add_child(box)
	box.add_child(UiKit.label(tr("Perfis de jogador"), 20, UiKit.GOLD))
	box.add_child(UiKit.label(tr("Cada perfil tem o seu progresso, as suas configurações, os seus baralhos e os seus jogos guardados (até %d).") % Profiles.MAX, 14, UiKit.TEXT_DIM, true))
	for p in Profiles.all():
		var id := int(p.get("id", 1))
		var row := HBoxContainer.new()
		row.name = "Profile%d" % id
		row.add_theme_constant_override("separation", 10)
		box.add_child(row)
		var portrait := _portrait_rect(Profiles.portrait_of(id), 52)
		row.add_child(portrait)
		var active := id == Profiles.active()
		var l := UiKit.label(Profiles.name_of(id) + ("   ✓ " + tr("em uso") if active else ""), 19, UiKit.GOLD if active else Color.WHITE)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(l)
		var ren := UiKit.button(tr("NOME"), 50, 16)
		ren.name = "Rename%d" % id
		ren.custom_minimum_size.x = 96
		ren.pressed.connect(func():
			Sfx.select()
			TextPrompt.open(tr("Nome do mago"), String(Profiles.get_profile(id).get("name", "")), tr("Mago %d") % id, Profiles.NAME_MAX, func(value: String):
				Profiles.rename(id, value)
				_show_tab("profile")))
		row.add_child(ren)
		var pic := UiKit.button(tr("RETRATO"), 50, 16)
		pic.name = "Portrait%d" % id
		pic.custom_minimum_size.x = 118
		pic.pressed.connect(func():
			Sfx.select()
			Profiles.set_portrait(id, _next_portrait(Profiles.portrait_of(id)))
			_show_tab("profile"))
		row.add_child(pic)
		if not active:
			var use := UiKit.button(tr("USAR"), 50, 16, UiKit.PRIMARY.darkened(0.25))
			use.name = "Use%d" % id
			use.custom_minimum_size.x = 96
			use.pressed.connect(func():
				Sfx.level_up()
				if Profiles.switch_to(id):
					close()
					SceneRouter.toast(tr("Perfil: %s") % Profiles.name_of(id))
					SceneRouter.go("main"))
			row.add_child(use)
			if id > 1:
				var del := UiKit.button(tr("APAGAR"), 50, 16, UiKit.BTN_BG)
				del.name = "DeleteProfile%d" % id
				del.custom_minimum_size.x = 104
				del.pressed.connect(func():
					if not bool(del.get_meta("armed", false)):
						Sfx.select()
						del.set_meta("armed", true)
						del.text = tr("APAGAR?")
						del.add_theme_stylebox_override("normal", UiKit.flat(UiKit.DANGER, 12))
						return
					Sfx.hit()
					Profiles.remove(id)
					_show_tab("profile"))
				row.add_child(del)
	if Profiles.can_add():
		var add := UiKit.button(tr("+ NOVO PERFIL"), 50, 17)
		add.name = "NewProfile"
		add.pressed.connect(func():
			Sfx.select()
			TextPrompt.open(tr("Nome do mago"), "", tr("Mago %d") % (Profiles.count() + 1), Profiles.NAME_MAX, func(value: String):
				Profiles.create(value)
				_show_tab("profile")))
		box.add_child(add)

## Retratos que se podem escolher: os dos inimigos já vencidos e as ilustrações das cartas já vistas.
func portrait_choices() -> Array:
	var out: Array = [""]
	for id in GameState.progress.get("defeated", {}):
		if ArtLib.has("portrait", String(id)):
			out.append("portrait:" + String(id))
	var seen = GameState.progress.get("seen", {})
	if seen is Dictionary and seen.get("cards") is Array:
		for cid in seen["cards"]:
			if out.size() >= 80:
				break
			if ArtLib.has("card", String(cid)):
				out.append("card:" + String(cid))
	return out

func _next_portrait(current: String) -> String:
	var choices := portrait_choices()
	var i := choices.find(current)
	return String(choices[(i + 1) % choices.size()])

## A imagem de um retrato («portrait:<id>» ou «card:<id>»); sem retrato, o sigilo do jogo.
func _portrait_rect(portrait: String, px: int) -> Control:
	var tex: Texture2D = null
	if portrait.begins_with("portrait:"):
		tex = ArtLib.texture("portrait", portrait.substr(9))
	elif portrait.begins_with("card:"):
		tex = ArtLib.card_art(portrait.substr(5))
	if tex == null:
		var icon := CardIcon.new("crown", UiKit.GOLD, float(px) * 0.7)
		icon.custom_minimum_size = Vector2(px, px)
		return icon
	var r := TextureRect.new()
	r.texture = tex
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	r.custom_minimum_size = Vector2(px, px)
	r.clip_contents = true
	return r

# --- Exportar / importar / apagar ---

func _on_export() -> void:
	Sfx.select()
	var code := Settings.export_code()
	DisplayServer.clipboard_set(code)
	_show_code_panel(code)

## 233: o espaço ocupado, por pasta, com LIMPAR (as gravações e o progresso não se limpam daqui).
func _on_storage_open() -> void:
	Sfx.select()
	_clear()
	_content.add_child(UiKit.label(tr("Espaço ocupado"), 22, UiKit.GOLD))
	_content.add_child(UiKit.label(tr("O que o Zero-Sum guarda neste telemóvel. Limpar não mexe no progresso nem nos jogos guardados: o que se limpa volta a fazer-se quando for preciso."), 17, Color.WHITE, true))
	for u in Storage.usage():
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		_content.add_child(row)
		var l := UiKit.label(tr(String(u[1])) + "  ·  " + Storage.fmt_bytes(int(u[2])), 18, Color.WHITE)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(l)
		if bool(u[3]):
			var b := UiKit.button(tr("LIMPAR"), 48, 17)
			b.name = "Clear_" + String(u[0])
			b.custom_minimum_size.x = 160
			b.disabled = int(u[2]) == 0
			var id := String(u[0])
			b.pressed.connect(func():
				Sfx.select()
				Storage.clear(id)
				_on_storage_open())
			row.add_child(b)
	var back := UiKit.button(tr("VOLTAR"), 50, 18)
	back.name = "Back"
	back.pressed.connect(func(): Sfx.select(); _show_tab("game"))
	_content.add_child(back)

func _show_code_panel(code: String) -> void:
	_clear()
	_content.add_child(UiKit.label(tr("Código do teu progresso (já copiado)"), 22, UiKit.GOLD))
	_content.add_child(UiKit.label(tr("No outro telemóvel: Configurações → Jogo → Importar, e cola o código. Leva as conquistas, os baralhos, as configurações e os jogos guardados."), 17, Color.WHITE, true))
	var edit := TextEdit.new()
	edit.text = code
	edit.editable = false
	edit.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	edit.custom_minimum_size = Vector2(0, 150)
	edit.add_theme_font_size_override("font_size", 13)
	_content.add_child(edit)
	# 0.19.0 (231): também num ficheiro, para mandar por email ou guardar no Drive.
	var frow := HBoxContainer.new()
	frow.add_theme_constant_override("separation", 10)
	_content.add_child(frow)
	var note := UiKit.label("", 15, UiKit.TEXT_DIM, true)
	var file_btn := UiKit.button(tr("GUARDAR NUM FICHEIRO"), 50, 17, UiKit.PRIMARY.darkened(0.2), UiKit.PRIMARY)
	file_btn.name = "ExportFile"
	file_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	file_btn.pressed.connect(func():
		Sfx.select()
		var path := Storage.export_progress_file(code)
		if path == "":
			note.text = tr("Não deu para gravar o ficheiro. Usa o código acima (já está copiado).")
			return
		note.text = tr("Guardado em %s — partilha-o por email ou guarda-o no Drive. No outro telemóvel: IMPORTAR → ABRIR FICHEIRO.") % path
		if OS.shell_open(path) != OK:
			pass)
	frow.add_child(file_btn)
	_content.add_child(note)
	var back := UiKit.button(tr("VOLTAR"), 50, 18)
	back.name = "Back"
	back.pressed.connect(func(): Sfx.select(); _show_tab("game"))
	_content.add_child(back)

func _on_import_open() -> void:
	Sfx.select()
	_clear()
	_pending_import = ""
	_content.add_child(UiKit.label(tr("Importar progresso"), 22, UiKit.GOLD))
	_content.add_child(UiKit.label(tr("Cola o código exportado no outro telemóvel. O progresso deste telemóvel é substituído."), 17, Color.WHITE, true))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	_content.add_child(row)
	_import_edit = LineEdit.new()
	_import_edit.placeholder_text = "ZS1:…"
	_import_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_import_edit.custom_minimum_size = Vector2(0, 50)
	row.add_child(_import_edit)
	var paste := UiKit.button(tr("COLAR"), 50, 18)
	paste.custom_minimum_size.x = 120
	paste.pressed.connect(func():
		Sfx.select()
		_import_edit.text = DisplayServer.clipboard_get().strip_edges())
	row.add_child(paste)
	# 0.19.0 (232): ou a partir de um ficheiro de progresso (zero-sum-progresso-….zs1, nas Transferências).
	var open_f := UiKit.button(tr("ABRIR FICHEIRO"), 50, 18)
	open_f.name = "ImportFile"
	open_f.custom_minimum_size.x = 200
	open_f.pressed.connect(_on_import_file)
	row.add_child(open_f)
	_import_note = UiKit.label("", 17, UiKit.TEXT_DIM, true)
	_content.add_child(_import_note)
	var go := UiKit.button(tr("IMPORTAR"), 54, 20, UiKit.PRIMARY.darkened(0.2), UiKit.PRIMARY)
	go.pressed.connect(func(): _on_import(go))
	_content.add_child(go)
	var back := UiKit.button(tr("VOLTAR"), 50, 18)
	back.name = "Back"
	back.pressed.connect(func(): Sfx.select(); _show_tab("game"))
	_content.add_child(back)

## 232: os ficheiros de progresso que se encontram (Transferências, Documentos, pasta do jogo); escolher um põe
## o código na caixa (e o IMPORTAR valida, como com o código colado).
func _on_import_file() -> void:
	Sfx.select()
	var files := Storage.find_progress_files()
	if files.is_empty():
		_import_note.text = tr("Não encontrei nenhum ficheiro «zero-sum-progresso» nas Transferências. Põe lá o ficheiro (ou abre-o e copia o código) e tenta outra vez.")
		return
	if files.size() == 1:
		_use_progress_file(String(files[0][0]))
		return
	var buttons: Array = []
	for f in files.slice(0, 6):
		buttons.append([String(f[0]).get_file(), String(f[0])])
	buttons.append([tr("CANCELAR"), null])
	var d := ChoiceDialog.open(tr("ESCOLHE O FICHEIRO"), tr("Os ficheiros de progresso que encontrei (o mais recente primeiro)."), buttons)
	d.chosen.connect(func(v):
		if v is String:
			_use_progress_file(String(v)))

func _use_progress_file(path: String) -> void:
	var code := Storage.read_progress_file(path)
	if code == "":
		_import_note.text = tr("Esse ficheiro não tem um código de progresso.")
		return
	_import_edit.text = code
	_import_note.text = tr("Código lido de %s. Toca em IMPORTAR.") % path.get_file()

## 1.º toque valida e mostra o resumo; 2.º toque (com o mesmo código) importa.
func _on_import(btn: Button) -> void:
	var code := _import_edit.text.strip_edges()
	var d := Settings.parse_code(code)
	if d.is_empty():
		Sfx.hit()
		_import_note.text = tr("Código inválido. Confirma que copiaste tudo, desde «ZS1:» até ao fim.")
		_pending_import = ""
		return
	if _pending_import != code:
		_pending_import = code
		var p: Dictionary = d["progress"]
		var st: Dictionary = p.get("stats", {}) if p.get("stats") is Dictionary else {}
		var ach: Array = p.get("achievements", []) if p.get("achievements") is Array else []
		_import_note.text = tr("Código válido: %d runs, %d vitórias, %d conquistas. Toca outra vez em IMPORTAR para substituir o progresso deste telemóvel.") % [int(st.get("runs", 0)), int(st.get("wins", 0)), ach.size()]
		btn.text = tr("CONFIRMAR IMPORTAÇÃO")
		Sfx.select()
		return
	if Settings.import_code(code):
		Sfx.boom()
		_import_note.text = tr("Progresso importado!")
		btn.disabled = true
		close()
		SceneRouter.go("main")

func _on_reset() -> void:
	if _confirm_reset:
		GameState.reset_progress()
		Sfx.hit()
		_confirm_reset = false
		_reset_btn.text = tr("PROGRESSO APAGADO")
		_reset_btn.disabled = true
		return
	Sfx.select()
	_confirm_reset = true
	_confirm_id += 1
	var id := _confirm_id
	_reset_btn.text = tr("TENS A CERTEZA? TOCA OUTRA VEZ")
	await get_tree().create_timer(3.0).timeout
	if id == _confirm_id and is_instance_valid(_reset_btn) and not is_queued_for_deletion():
		_confirm_reset = false
		_reset_btn.text = tr("APAGAR PROGRESSO")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		var back := _content.get_node_or_null("Back") as Button   # 0.20.0 (A6): numa sub-página, o mesmo que o VOLTAR
		if back != null:
			back.pressed.emit()
		else:
			close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Settings.save_settings()
	closed.emit()
	UiKit.close_animated(self)
