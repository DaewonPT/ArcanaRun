class_name SettingsMenu
extends Control
## Painel de Configurações (abre por cima do menu principal ou da pausa), em quatro separadores:
##   JOGO           idioma, velocidade, mão dominante, avisos, tutorial, exportar/importar e apagar progresso
##   VISUAL         escala da interface (90–120 %), modo compacto, texto das cartas, costas e moldura
##   SOM            efeitos, música (quando existir) e vibração
##   ACESSIBILIDADE modo daltónico, reduzir movimento, limite de FPS e ecrã ligado na batalha
## Grava em user://settings.json ao fechar.

signal closed

const TABS := ["JOGO", "VISUAL", "SOM", "ACESSIBILIDADE"]
const CONTENT_HEIGHT := 424.0

var _tab := 0
var _tab_buttons: Array[Button] = []
var _content: VBoxContainer
var _panel: PanelContainer
var _reset_btn: Button
var _confirm_reset := false
var _confirm_id := 0
var _import_edit: LineEdit
var _import_note: Label
var _pending_import := ""

static func open() -> SettingsMenu:
	var m := SettingsMenu.new()
	SceneRouter.show_overlay(m)
	m._build()
	return m

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.8))

func _build() -> void:
	_panel = UiKit.centered_panel(self, 900)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	_panel.add_child(vbox)
	var title := UiKit.label(tr("CONFIGURAÇÕES"), 30, UiKit.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 8)
	vbox.add_child(tabs)
	for i in TABS.size():
		var b := UiKit.button(tr(TABS[i]), 48, 18)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(func(): Sfx.select(); _show_tab(i))
		tabs.add_child(b)
		_tab_buttons.append(b)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, CONTENT_HEIGHT)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)
	_content = VBoxContainer.new()
	_content.add_theme_constant_override("separation", 10)
	_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(_content)
	var close_btn := UiKit.button(tr("FECHAR"), 58, 24, UiKit.PRIMARY, Color(0, 0, 0, 0))
	close_btn.pressed.connect(func(): Sfx.select(); close())
	vbox.add_child(close_btn)
	_show_tab(0)
	UiKit.pop_in(_panel)

func _show_tab(i: int) -> void:
	_tab = i
	for k in _tab_buttons.size():
		var on := k == i
		var b := _tab_buttons[k]
		var st := UiKit.flat(UiKit.GOLD.darkened(0.55) if on else UiKit.BG_LIGHT, 12, UiKit.GOLD if on else Color(0, 0, 0, 0), 2 if on else 0, 10)
		b.add_theme_stylebox_override("normal", st)
		b.add_theme_stylebox_override("hover", st)
		b.add_theme_color_override("font_color", UiKit.GOLD if on else UiKit.TEXT_DIM)
	for c in _content.get_children():
		_content.remove_child(c)
		c.queue_free()
	_confirm_reset = false
	match i:
		0:
			_build_game()
		1:
			_build_visual()
		2:
			_build_sound()
		3:
			_build_access()

# --- Separadores ---

func _build_game() -> void:
	_cycle_row(tr("Idioma"), func(): return Settings.language_label(), func(): Settings.cycle_language())
	_cycle_row(tr("Velocidade das animações"), func(): return Settings.speed_label(), func(): Settings.cycle_speed())
	_toggle_row(tr("Mão dominante"), func(): return Settings.left_handed, func(v: bool): Settings.left_handed = v; Settings.apply(),
		tr("Esquerda (botões à direita)"), tr("Direita (botões à esquerda)"))
	_toggle_row(tr("Aviso: atacar sem gastar a mana"), func(): return Settings.warn_mana, func(v: bool): Settings.warn_mana = v)
	_toggle_row(tr("Aviso: canalizar uma rara"), func(): return Settings.warn_rare, func(v: bool): Settings.warn_rare = v)
	var tut_row := _row(tr("Tutorial"))
	var tut_btn := UiKit.button(tr("REPETIR NA PRÓXIMA BATALHA"), 50, 18)
	tut_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tut_btn.pressed.connect(func():
		Stats.set_tutorial_done(false)
		Sfx.select()
		tut_btn.text = tr("Tutorial marcado  ✓")
		tut_btn.disabled = true)
	tut_row.add_child(tut_btn)
	# Progresso: copiar para outro telemóvel e apagar.
	var prog := _row(tr("Progresso"))
	var exp := UiKit.button(tr("EXPORTAR"), 50, 18)
	exp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	exp.pressed.connect(_on_export)
	prog.add_child(exp)
	var imp := UiKit.button(tr("IMPORTAR"), 50, 18)
	imp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	imp.pressed.connect(_on_import_open)
	prog.add_child(imp)
	_reset_btn = UiKit.button(tr("APAGAR PROGRESSO"), 50, 18, UiKit.DANGER, Color(0, 0, 0, 0))
	_reset_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_reset_btn.pressed.connect(_on_reset)
	prog.add_child(_reset_btn)
	_import_note = UiKit.label("", 16, UiKit.TEXT_DIM, true)
	_content.add_child(_import_note)

func _build_visual() -> void:
	var scale_row := _row(tr("Escala da interface"))
	var minus := UiKit.button("−", 50, 24)
	minus.custom_minimum_size.x = 70
	scale_row.add_child(minus)
	var value := UiKit.label(Settings.scale_label(), 19)
	value.custom_minimum_size.x = 250
	value.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	value.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	scale_row.add_child(value)
	var plus := UiKit.button("+", 50, 24)
	plus.custom_minimum_size.x = 70
	scale_row.add_child(plus)
	minus.pressed.connect(func(): Sfx.select(); Settings.cycle_scale(-1); value.text = Settings.scale_label())
	plus.pressed.connect(func(): Sfx.select(); Settings.cycle_scale(1); value.text = Settings.scale_label())
	_content.add_child(UiKit.label(tr("Acima de 100 % a interface só cresce onde o ecrã tem altura de sobra (tablets); nos telemóveis compridos usa o modo compacto e o texto grande."), 14, UiKit.TEXT_DIM, true))
	_toggle_row(tr("Modo compacto (cartas mais pequenas)"), func(): return Settings.compact, func(v: bool): Settings.compact = v; Settings.apply())
	_toggle_row(tr("Texto das cartas"), func(): return Settings.large_text, func(v: bool): Settings.large_text = v; Settings.apply(), tr("Grande"), tr("Normal"))
	# Costas das cartas (com uma pequena amostra) e moldura.
	var back_row := _row(tr("Costas das cartas"))
	var sample := CardBack.new()
	sample.back_id = Settings.card_back
	sample.custom_minimum_size = Vector2(36, 50)
	sample.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	back_row.add_child(sample)
	var back_btn := UiKit.button(_cosmetic_label("back"), 50, 18)
	back_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	back_btn.pressed.connect(func():
		Sfx.select()
		Settings.cycle_cosmetic("back")
		sample.back_id = Settings.card_back
		back_btn.text = _cosmetic_label("back"))
	back_row.add_child(back_btn)
	var frame_row := _row(tr("Moldura das cartas"))
	var frame_btn := UiKit.button(_cosmetic_label("frame"), 50, 18)
	frame_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	frame_btn.pressed.connect(func():
		Sfx.select()
		Settings.cycle_cosmetic("frame")
		frame_btn.text = _cosmetic_label("frame"))
	frame_row.add_child(frame_btn)
	_content.add_child(UiKit.label(tr("Ganhas mais costas e molduras na História, nos Desafios e com conquistas. Não mexem no jogo."), 15, UiKit.TEXT_DIM, true))

func _build_sound() -> void:
	_slider_row(tr("Efeitos sonoros"), Settings.sfx_volume, func(v: float):
		Settings.sfx_volume = v
		Settings.apply())
	if Settings.has_music():
		_slider_row(tr("Música"), Settings.music_volume, func(v: float):
			Settings.music_volume = v
			Settings.apply())
	_toggle_row(tr("Vibração"), func(): return Settings.vibration, func(v: bool):
		Settings.vibration = v
		Settings.vibrate(40), tr("Ligada"), tr("Desligada"))

func _build_access() -> void:
	_toggle_row(tr("Modo daltónico"), func(): return Settings.colorblind, func(v: bool): Settings.colorblind = v; Settings.apply(),
		tr("Ligado (símbolos nas cores)"), tr("Desligado"))
	_toggle_row(tr("Reduzir movimento"), func(): return Settings.reduce_motion, func(v: bool): Settings.reduce_motion = v; Settings.apply(),
		tr("Ligado (sem abanões, flashes nem partículas)"), tr("Desligado"))
	_cycle_row(tr("Limite de FPS (bateria)"), func(): return "%d FPS" % Settings.fps_cap, func():
		Settings.fps_cap = 30 if Settings.fps_cap == 60 else 60
		Settings.apply())
	_toggle_row(tr("Ecrã sempre ligado na batalha"), func(): return Settings.keep_screen_on, func(v: bool): Settings.keep_screen_on = v)
	var note := UiKit.label(tr("A história está em português; a interface e as cartas traduzem-se.") + "  ·  " + tr("Fontes: Inter e Lora (SIL Open Font License)."), 14, UiKit.TEXT_DIM, true)
	_content.add_child(note)

# --- Linhas ---

func _row(text: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	_content.add_child(row)
	var l := UiKit.label(text, 20)
	l.custom_minimum_size = Vector2(330, 0)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(l)
	return row

## Botão que roda entre valores (idioma, velocidade, FPS).
func _cycle_row(text: String, label_fn: Callable, next_fn: Callable) -> void:
	var row := _row(text)
	var b := UiKit.button(String(label_fn.call()), 50, 20)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.pressed.connect(func():
		Sfx.select()
		next_fn.call()
		b.text = String(label_fn.call()))
	row.add_child(b)

## Interruptor ligado/desligado (os textos por omissão são "Ligado"/"Desligado").
func _toggle_row(text: String, get_fn: Callable, set_fn: Callable, on_text: String = "", off_text: String = "") -> void:
	var row := _row(text)
	var on_t := on_text if on_text != "" else tr("Ligado")
	var off_t := off_text if off_text != "" else tr("Desligado")
	var b := UiKit.button(on_t if bool(get_fn.call()) else off_t, 50, 20)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_paint_toggle(b, bool(get_fn.call()))
	b.pressed.connect(func():
		Sfx.select()
		var v := not bool(get_fn.call())
		set_fn.call(v)
		b.text = on_t if v else off_t
		_paint_toggle(b, v))
	row.add_child(b)

func _paint_toggle(b: Button, on: bool) -> void:
	var st := UiKit.flat(Color(0.18, 0.32, 0.22) if on else UiKit.BG_LIGHT, 12, Color(0.45, 0.85, 0.55) if on else Color(0, 0, 0, 0), 2 if on else 0, 10)
	b.add_theme_stylebox_override("normal", st)
	b.add_theme_stylebox_override("hover", st)

func _slider_row(text: String, value01: float, on_change: Callable) -> void:
	var row := _row(text)
	var s := HSlider.new()
	s.min_value = 0
	s.max_value = 100
	s.step = 5
	s.value = round(value01 * 100.0)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	s.custom_minimum_size = Vector2(0, 44)
	row.add_child(s)
	var v := UiKit.label("%d%%" % int(s.value), 20, UiKit.TEXT_DIM)
	v.custom_minimum_size = Vector2(70, 0)
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	v.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(v)
	s.value_changed.connect(func(x: float):
		v.text = "%d%%" % int(x)
		on_change.call(x / 100.0))
	s.drag_ended.connect(func(_changed: bool): Sfx.select())

func _cosmetic_label(kind: String) -> String:
	var id := Settings.card_back if kind == "back" else Settings.card_frame
	var c := CardDB.get_cosmetic(kind, id)
	var owned := Settings.unlocked_cosmetics(kind).size()
	var total := (CardDB.cosmetics.get(kind + "s", []) as Array).size()
	return tr(String(c.get("name", id))) + "   (%d/%d)" % [owned, total]

# --- Exportar / importar / apagar ---

func _on_export() -> void:
	Sfx.select()
	var code := Settings.export_code()
	DisplayServer.clipboard_set(code)
	_show_code_panel(code)

func _show_code_panel(code: String) -> void:
	for c in _content.get_children():
		_content.remove_child(c)
		c.queue_free()
	_content.add_child(UiKit.label(tr("Código do teu progresso (já copiado)"), 22, UiKit.GOLD))
	_content.add_child(UiKit.label(tr("No outro telemóvel: Configurações → Jogo → Importar, e cola o código. Leva as conquistas, os baralhos, as configurações e a run gravada."), 17, Color.WHITE, true))
	var edit := TextEdit.new()
	edit.text = code
	edit.editable = false
	edit.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	edit.custom_minimum_size = Vector2(0, 150)
	edit.add_theme_font_size_override("font_size", 13)
	_content.add_child(edit)
	var back := UiKit.button(tr("VOLTAR"), 50, 18)
	back.pressed.connect(func(): Sfx.select(); _show_tab(0))
	_content.add_child(back)

func _on_import_open() -> void:
	Sfx.select()
	for c in _content.get_children():
		_content.remove_child(c)
		c.queue_free()
	_pending_import = ""
	_content.add_child(UiKit.label(tr("Importar progresso"), 22, UiKit.GOLD))
	_content.add_child(UiKit.label(tr("Cola o código exportado no outro telemóvel. O progresso deste telemóvel é substituído."), 17, Color.WHITE, true))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	_content.add_child(row)
	_import_edit = LineEdit.new()
	_import_edit.placeholder_text = "ZS1:…"
	_import_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_import_edit.custom_minimum_size = Vector2(0, 50)
	row.add_child(_import_edit)
	var paste := UiKit.button(tr("COLAR"), 50, 18)
	paste.custom_minimum_size.x = 120
	paste.pressed.connect(func():
		Sfx.select()
		_import_edit.text = DisplayServer.clipboard_get().strip_edges())
	row.add_child(paste)
	_import_note = UiKit.label("", 17, UiKit.TEXT_DIM, true)
	_content.add_child(_import_note)
	var go := UiKit.button(tr("IMPORTAR"), 54, 20, UiKit.PRIMARY.darkened(0.2), UiKit.PRIMARY)
	go.pressed.connect(func(): _on_import(go))
	_content.add_child(go)
	var back := UiKit.button(tr("VOLTAR"), 50, 18)
	back.pressed.connect(func(): Sfx.select(); _show_tab(0))
	_content.add_child(back)

## 1.º toque valida e mostra o resumo; 2.º toque (com o mesmo código) importa.
func _on_import(btn: Button) -> void:
	var code := _import_edit.text.strip_edges()
	var d := Settings.parse_code(code)
	if d.is_empty():
		Sfx.hit()
		_import_note.text = tr("Código inválido. Confirma que copiaste tudo, desde «ZS1:» até ao fim.")
		_pending_import = ""
		return
	if _pending_import != code:
		_pending_import = code
		var p: Dictionary = d["progress"]
		var st: Dictionary = p.get("stats", {}) if p.get("stats") is Dictionary else {}
		var ach: Array = p.get("achievements", []) if p.get("achievements") is Array else []
		_import_note.text = tr("Código válido: %d runs, %d vitórias, %d conquistas. Toca outra vez em IMPORTAR para substituir o progresso deste telemóvel.") % [int(st.get("runs", 0)), int(st.get("wins", 0)), ach.size()]
		btn.text = tr("CONFIRMAR IMPORTAÇÃO")
		Sfx.select()
		return
	if Settings.import_code(code):
		Sfx.boom()
		_import_note.text = tr("Progresso importado!")
		btn.disabled = true
		close()
		SceneRouter.go("main")

func _on_reset() -> void:
	if _confirm_reset:
		GameState.reset_progress()
		Sfx.hit()
		_confirm_reset = false
		_reset_btn.text = tr("PROGRESSO APAGADO")
		_reset_btn.disabled = true
		return
	Sfx.select()
	_confirm_reset = true
	_confirm_id += 1
	var id := _confirm_id
	_reset_btn.text = tr("TENS A CERTEZA? TOCA OUTRA VEZ")
	await get_tree().create_timer(3.0).timeout
	if id == _confirm_id and is_instance_valid(_reset_btn) and not is_queued_for_deletion():
		_confirm_reset = false
		_reset_btn.text = tr("APAGAR PROGRESSO")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Settings.save_settings()
	closed.emit()
	queue_free()
