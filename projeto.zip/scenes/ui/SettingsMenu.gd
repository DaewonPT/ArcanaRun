class_name SettingsMenu
extends Control
## Painel de Configurações (abre por cima do menu principal ou da pausa):
## volume dos efeitos (e da música, quando existir), idioma, velocidade das animações,
## vibração e apagar o progresso. Grava em user://settings.json ao fechar.

signal closed

var _lang_btn: Button
var _speed_btn: Button
var _vib_btn: Button
var _text_btn: Button
var _hand_btn: Button
var _reset_btn: Button
var _sfx_value: Label
var _music_value: Label
var _confirm_reset := false
var _confirm_id := 0

static func open() -> SettingsMenu:
	var m := SettingsMenu.new()
	SceneRouter.show_overlay(m)
	m._build()
	return m

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.8))

func _build() -> void:
	var panel := UiKit.centered_panel(self, 860)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 6)
	panel.add_child(vbox)
	var title := UiKit.label(tr("CONFIGURAÇÕES"), 30, UiKit.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)

	# Efeitos sonoros
	var sfx_row := _row(vbox, tr("Efeitos sonoros"))
	var sfx := _slider(Settings.sfx_volume)
	sfx_row.add_child(sfx)
	_sfx_value = _value_label(Settings.sfx_volume)
	sfx_row.add_child(_sfx_value)
	sfx.value_changed.connect(func(v: float):
		Settings.sfx_volume = v / 100.0
		_sfx_value.text = "%d%%" % int(v)
		Settings.apply())
	sfx.drag_ended.connect(func(_changed: bool): Sfx.select())

	# Música (só quando houver ficheiro de música no projeto)
	if Settings.has_music():
		var music_row := _row(vbox, tr("Música"))
		var music := _slider(Settings.music_volume)
		music_row.add_child(music)
		_music_value = _value_label(Settings.music_volume)
		music_row.add_child(_music_value)
		music.value_changed.connect(func(v: float):
			Settings.music_volume = v / 100.0
			_music_value.text = "%d%%" % int(v)
			Settings.apply())

	# Idioma
	var lang_row := _row(vbox, tr("Idioma"))
	_lang_btn = UiKit.button(Settings.language_label(), 54, 22)
	_lang_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_lang_btn.pressed.connect(func():
		Sfx.select()
		Settings.cycle_language()
		_refresh_texts())
	lang_row.add_child(_lang_btn)

	# Velocidade das animações
	var speed_row := _row(vbox, tr("Velocidade das animações"))
	_speed_btn = UiKit.button(Settings.speed_label(), 54, 22)
	_speed_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_speed_btn.pressed.connect(func():
		Sfx.select()
		Settings.cycle_speed()
		_refresh_texts())
	speed_row.add_child(_speed_btn)

	# Vibração
	var vib_row := _row(vbox, tr("Vibração"))
	_vib_btn = UiKit.button(_vib_label(), 54, 22)
	_vib_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_vib_btn.pressed.connect(func():
		Settings.vibration = not Settings.vibration
		Settings.vibrate(40)
		Sfx.select()
		_refresh_texts())
	vib_row.add_child(_vib_btn)

	# Texto grande e mão dominante
	var text_row := _row(vbox, tr("Texto das cartas"))
	_text_btn = UiKit.button(_text_label(), 54, 22)
	_text_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_text_btn.pressed.connect(func():
		Settings.large_text = not Settings.large_text
		Sfx.select()
		Settings.apply()
		_refresh_texts())
	text_row.add_child(_text_btn)
	var hand_row := _row(vbox, tr("Mão dominante"))
	_hand_btn = UiKit.button(_hand_label(), 54, 22)
	_hand_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_hand_btn.pressed.connect(func():
		Settings.left_handed = not Settings.left_handed
		Sfx.select()
		Settings.apply()
		_refresh_texts())
	hand_row.add_child(_hand_btn)
	var tut_row := _row(vbox, tr("Tutorial"))
	var tut_btn := UiKit.button(tr("REPETIR NA PRÓXIMA BATALHA"), 54, 20)
	tut_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tut_btn.pressed.connect(func():
		Stats.set_tutorial_done(false)
		Sfx.select()
		tut_btn.text = tr("Tutorial marcado  ✓")
		tut_btn.disabled = true)
	tut_row.add_child(tut_btn)
	var note := UiKit.label(tr("A história está em português; a interface e as cartas traduzem-se."), 15, UiKit.TEXT_DIM, true)
	vbox.add_child(note)

	var bottom := HBoxContainer.new()
	bottom.add_theme_constant_override("separation", 16)
	vbox.add_child(bottom)
	_reset_btn = UiKit.button(tr("APAGAR PROGRESSO"), 60, 22, UiKit.DANGER, Color(0, 0, 0, 0))
	_reset_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_reset_btn.pressed.connect(_on_reset)
	bottom.add_child(_reset_btn)
	var close_btn := UiKit.button(tr("FECHAR"), 60, 24, UiKit.PRIMARY, Color(0, 0, 0, 0))
	close_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	close_btn.pressed.connect(func(): Sfx.select(); close())
	bottom.add_child(close_btn)
	UiKit.pop_in(panel)

func _row(parent: Control, text: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	parent.add_child(row)
	var l := UiKit.label(text, 22)
	l.custom_minimum_size = Vector2(330, 0)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(l)
	return row

func _slider(value01: float) -> HSlider:
	var s := HSlider.new()
	s.min_value = 0
	s.max_value = 100
	s.step = 5
	s.value = round(value01 * 100.0)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	s.custom_minimum_size = Vector2(0, 44)
	return s

func _value_label(value01: float) -> Label:
	var l := UiKit.label("%d%%" % int(round(value01 * 100.0)), 20, UiKit.TEXT_DIM)
	l.custom_minimum_size = Vector2(70, 0)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	return l

func _vib_label() -> String:
	return tr("Ligada") if Settings.vibration else tr("Desligada")

func _text_label() -> String:
	return tr("Grande") if Settings.large_text else tr("Normal")

func _hand_label() -> String:
	return tr("Esquerda (botões à direita)") if Settings.left_handed else tr("Direita (botões à esquerda)")

func _refresh_texts() -> void:
	_lang_btn.text = Settings.language_label()
	_speed_btn.text = Settings.speed_label()
	_vib_btn.text = _vib_label()
	_text_btn.text = _text_label()
	_hand_btn.text = _hand_label()
	if not _confirm_reset:
		_reset_btn.text = tr("APAGAR PROGRESSO")

func _on_reset() -> void:
	if _confirm_reset:
		GameState.reset_progress()
		Sfx.hit()
		_confirm_reset = false
		_reset_btn.text = tr("PROGRESSO APAGADO")
		_reset_btn.disabled = true
		return
	Sfx.select()
	_confirm_reset = true
	_confirm_id += 1
	var id := _confirm_id
	_reset_btn.text = tr("TENS A CERTEZA? TOCA OUTRA VEZ")
	await get_tree().create_timer(3.0).timeout
	if id == _confirm_id and is_instance_valid(_reset_btn) and not is_queued_for_deletion():
		_confirm_reset = false
		_reset_btn.text = tr("APAGAR PROGRESSO")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Settings.save_settings()
	closed.emit()
	queue_free()
