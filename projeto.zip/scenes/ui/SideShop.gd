class_name SideShop
extends Control
## 0.19.0 (87, 88): a loja pequena da Torre do Arquimago (nos andares de boss) e o Mercador da Corrida de Bosses (de
## 3 em 3 bosses): 3 cartas, uma relíquia, uma poção ou pergaminho e curar, pagos com o ouro ganho nas batalhas
## desse modo. As ofertas vêm de Economy.side_shop() (gravadas com a run); cada compra grava a run.

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")

var _body: VBoxContainer
var _content: VBoxContainer
var _gold_label: Label
var _on_change: Callable

static func open(on_change: Callable = Callable()) -> SideShop:
	var o := SideShop.new()
	o._on_change = on_change
	SceneRouter.show_overlay(o)
	o._build()
	return o

func _init() -> void:
	name = "SideShop"
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.85))

func _build() -> void:
	var tower := GameState.mode == "tower"
	_body = UiKit.window(self, 1080, tr("LOJA DA TORRE") if tower else tr("MERCADOR DA CORRIDA"), UiKit.GOLD, close,
		tr("Com o ouro das batalhas: cartas, uma relíquia, uma poção e curar."))
	var top := HBoxContainer.new()
	top.alignment = BoxContainer.ALIGNMENT_CENTER
	_body.add_child(top)
	var g := UiKit.icon_text("coin", str(GameState.gold), 24, UiKit.COIN, UiKit.COIN)
	g.name = "Gold"
	_gold_label = g.get_meta("label")
	top.add_child(g)
	_content = VBoxContainer.new()
	_content.name = "Content"
	_content.add_theme_constant_override("separation", 12)
	_body.add_child(_content)
	_refresh()
	UiKit.pop_in(_body.get_meta("panel"))

func _refresh() -> void:
	UiKit.clear_children(_content)
	_gold_label.text = str(GameState.gold)
	var shop := Economy.side_shop()
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 22)
	_content.add_child(row)
	var cards := HBoxContainer.new()
	cards.name = "Cards"
	cards.add_theme_constant_override("separation", 14)
	row.add_child(cards)
	for id in shop.get("cards", []):
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 6)
		cards.add_child(col)
		var v: CardView = CARD_VIEW.instantiate()
		v.name = "Card_" + String(id)
		col.add_child(v)
		v.setup(CardDB.new_instance(String(id)))
		v.long_pressed.connect(func(c): CardZoom.show_card(c))
		v.pressed.connect(func(c): CardZoom.show_card(c))
		col.add_child(_buy_button("card", String(id)))
	var side := VBoxContainer.new()
	side.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	side.add_theme_constant_override("separation", 10)
	row.add_child(side)
	var rid := String(shop.get("relic", ""))
	if rid != "":
		var r: Dictionary = CardDB.relics.get(rid, {})
		var rr := _line(side, tr(String(r.get("name", rid))), tr(String(r.get("text", ""))))
		var rv := RelicView.new()
		rv.custom_minimum_size = Vector2(52, 52)
		rv.mouse_filter = Control.MOUSE_FILTER_IGNORE
		rv.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		rr.add_child(rv)
		rr.move_child(rv, 0)
		rv.setup(rid)
		rr.add_child(_buy_button("relic", rid))
	var iid := String(shop.get("item", ""))
	if iid != "":
		var c := CardDB.get_consumable(iid)
		var ir := _line(side, tr(String(c.get("name", iid))), tr(String(c.get("text", ""))))
		var ic := CardIcon.new(String(c.get("kind", "potion")), Color(String(c.get("color", "#ffffff"))), 40.0)
		ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		ir.add_child(ic)
		ir.move_child(ic, 0)
		ir.add_child(_buy_button("item", iid))
	var hr := _line(side, tr("Curar %d") % Economy.side_heal_amount(), tr("Vida %d/%d") % [GameState.player_hp, GameState.player_max_hp])
	var hc := CardIcon.new("heart", Color(0.94, 0.32, 0.37), 40.0)
	hc.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hr.add_child(hc)
	hr.move_child(hc, 0)
	hr.add_child(_buy_button("heal", "heal"))

func _line(parent: Control, title: String, text: String) -> HBoxContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UiKit.flat(Color(1, 1, 1, 0.05), 12, Color(1, 1, 1, 0.08), 1, 8))
	parent.add_child(p)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	p.add_child(row)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(col)
	col.add_child(UiKit.label(title, 17, UiKit.GOLD, true))
	var t := UiKit.label(text, 14, Color.WHITE, true)
	t.max_lines_visible = 3
	col.add_child(t)
	return row

func _buy_button(kind: String, id: String) -> Button:
	var key := kind + ":" + id
	var done := kind != "heal" and Economy.side_bought(key)
	var price := Economy.side_price(kind, id)
	var b := UiKit.button(tr("VENDIDO") if done else tr("COMPRAR · %d") % price, 44, 15, UiKit.PRIMARY if not done else UiKit.BG_LIGHT)
	b.name = "Buy_" + kind + "_" + id
	b.custom_minimum_size.x = 150
	b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var full_item := kind == "item" and not GameState.can_add_consumable()
	var full_hp := kind == "heal" and GameState.player_hp >= GameState.player_max_hp
	b.disabled = done or GameState.gold < price or full_item or full_hp
	b.pressed.connect(buy.bind(kind, id))
	UiKit.explain(b, func() -> String:   # 0.19.0 (121)
		if done:
			return ""
		if full_item:
			return tr("Poções cheias: usa ou vende uma primeiro.")
		if full_hp:
			return tr("Já tens a vida toda.")
		return UiKit.why_gold(price))
	return b

## Compra (também usado pelos testes). Com as relíquias cheias, pergunta qual sai.
func buy(kind: String, id: String, replace: String = "") -> void:
	if kind == "relic" and replace == "" and GameState.relic_ids.size() >= GameState.max_relics():
		RelicSwap.open(id, func(out: String):
			if out != "":
				buy("relic", id, out))
		return
	var txt := Economy.side_buy(kind, id, replace)
	if txt == "":
		Sfx.deny()
		return
	if kind == "heal":
		Sfx.heal()
	else:
		Sfx.reward()
	SceneRouter.toast(txt, 1.8)
	GameState.save_run({}, "tower")
	_refresh()
	if _on_change.is_valid():
		_on_change.call()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Sfx.select()
	UiKit.close_animated(self)
