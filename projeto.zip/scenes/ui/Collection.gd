extends Control
## Coleção / códice: cartas (por baralho e cor), relíquias e inimigos, com o que já descobriste.
## Descoberta: cartas dos baralhos jogados, ofertas vistas e cartas ganhas; relíquias vistas na loja
## ou ganhas; inimigos enfrentados (Stats.mark_seen).

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const COLORS := [["white", "B"], ["blue", "A"], ["black", "P"], ["red", "V"], ["green", "Vd"], ["colorless", "∅"]]

var _tab := "cards"
var _deck_filter := ""      # "" = todos
var _color_filter := ""     # "" = todas
var _body: VBoxContainer
var _tab_buttons: Dictionary = {}
var _counter: Label

func _ready() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 10)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var back := UiKit.button(tr("◀ MENU"), 52, 20)
	back.custom_minimum_size.x = 140
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("COLEÇÃO"), 30, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(title)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(spacer)
	for t in [["cards", tr("CARTAS")], ["relics", tr("RELÍQUIAS")], ["enemies", tr("INIMIGOS")]]:
		var b := UiKit.button(String(t[1]), 52, 19)
		b.custom_minimum_size.x = 170
		b.toggle_mode = true
		b.pressed.connect(_select_tab.bind(String(t[0])))
		header.add_child(b)
		_tab_buttons[t[0]] = b
	_counter = UiKit.label("", 18, UiKit.TEXT_DIM)
	_counter.custom_minimum_size.x = 120
	_counter.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_counter.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(_counter)

	_body = VBoxContainer.new()
	_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_body.add_theme_constant_override("separation", 8)
	vbox.add_child(_body)
	_select_tab("cards")

func _select_tab(tab: String) -> void:
	_tab = tab
	for k in _tab_buttons:
		(_tab_buttons[k] as Button).button_pressed = (k == tab)
	for c in _body.get_children():
		c.queue_free()
	match tab:
		"cards":
			_build_cards()
		"relics":
			_build_relics()
		"enemies":
			_build_enemies()

# --- Cartas ---

func _build_cards() -> void:
	_counter.text = "%d/%d" % [Stats.seen_count("cards"), CardDB.cards.size()]
	var filters := HBoxContainer.new()
	filters.add_theme_constant_override("separation", 8)
	_body.add_child(filters)
	var deck_opt := OptionButton.new()
	deck_opt.custom_minimum_size = Vector2(320, 44)
	deck_opt.add_theme_font_size_override("font_size", 17)
	deck_opt.add_item(tr("Todos os baralhos"))
	deck_opt.set_item_metadata(0, "")
	var selected := 0
	var i := 1
	for d in CardDB.decks:
		deck_opt.add_item("%02d · %s" % [int(d.get("num", 0)), tr(String(d.get("name", "")))])
		deck_opt.set_item_metadata(i, String(d.get("id", "")))
		if String(d.get("id", "")) == _deck_filter:
			selected = i
		i += 1
	deck_opt.select(selected)
	deck_opt.item_selected.connect(func(idx: int):
		_deck_filter = String(deck_opt.get_item_metadata(idx))
		Sfx.select()
		_select_tab("cards"))
	filters.add_child(deck_opt)
	for c in COLORS:
		var b := UiKit.button(String(c[1]), 44, 17, CardView.COLORS[c[0]], Color(0, 0, 0, 0))
		b.custom_minimum_size.x = 52
		b.add_theme_color_override("font_color", CardView.DARK_TEXT if (CardView.COLORS[c[0]] as Color).get_luminance() > 0.45 else CardView.LIGHT_TEXT)
		b.toggle_mode = true
		b.button_pressed = (_color_filter == c[0])
		b.pressed.connect(func():
			_color_filter = "" if _color_filter == c[0] else String(c[0])
			Sfx.select()
			_select_tab("cards"))
		filters.add_child(b)
	var hint := UiKit.label(tr("Toca numa carta para a ver em grande."), 15, UiKit.TEXT_DIM)
	hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	hint.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	filters.add_child(hint)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_body.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 8
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(grid)
	var list: Array = CardDB.cards.values()
	list.sort_custom(func(a: CardData, b: CardData): return a.num < b.num)
	var shown := 0
	for d in list:
		if _deck_filter != "" and not _belongs_to_deck(d.id, _deck_filter):
			continue
		if _color_filter == "colorless" and not d.is_colorless():
			continue
		if _color_filter != "" and _color_filter != "colorless" and not (_color_filter in d.colors):
			continue
		var view: CardView = CARD_VIEW.instantiate()
		grid.add_child(view)
		var inst := CardDB.new_instance(d.id)
		view.setup(inst)
		if Stats.is_seen("cards", d.id):
			view.pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
			view.long_pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
		else:
			view.set_unknown()
		shown += 1
	if shown == 0:
		_body.add_child(UiKit.label(tr("Nada aqui."), 22, UiKit.TEXT_DIM))

func _belongs_to_deck(card_id: String, deck_id: String) -> bool:
	var d := CardDB.get_deck(deck_id)
	for id in d.get("cards", []):
		if String(id) == card_id:
			return true
	return false

# --- Relíquias ---

func _build_relics() -> void:
	_counter.text = "%d/%d" % [Stats.seen_count("relics"), CardDB.relics.size()]
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_body.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 8)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(grid)
	var order := {"common": 0, "uncommon": 1, "rare": 2}
	var list: Array = CardDB.relics.values()
	list.sort_custom(func(a, b): return int(order.get(a.get("rarity", "common"), 0)) < int(order.get(b.get("rarity", "common"), 0)))
	for r in list:
		var id := String(r.get("id", ""))
		var seen := Stats.is_seen("relics", id)
		var panel := PanelContainer.new()
		panel.custom_minimum_size = Vector2(0, 86)
		panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var rar := String(r.get("rarity", "common"))
		var border := UiKit.GOLD if rar == "rare" else (Color(0.75, 0.75, 0.85) if rar == "uncommon" else UiKit.BORDER)
		panel.add_theme_stylebox_override("panel", UiKit.flat(UiKit.BG_LIGHT if seen else UiKit.BG, 10, border if seen else UiKit.BORDER, 2, 8))
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 2)
		panel.add_child(col)
		if seen:
			col.add_child(UiKit.label("★ " + tr(String(r.get("name", id))) + "  ·  " + tr(CardZoom.RARITY_NAMES.get(rar, "Comum")), 17, UiKit.GOLD))
			col.add_child(UiKit.label(tr(String(r.get("text", ""))), 14, Color.WHITE, true))
		else:
			col.add_child(UiKit.label("???  ·  " + tr(CardZoom.RARITY_NAMES.get(rar, "Comum")), 17, UiKit.TEXT_DIM))
			col.add_child(UiKit.label(tr("Ainda não descoberta."), 14, UiKit.TEXT_DIM))
		grid.add_child(panel)

# --- Inimigos ---

func _build_enemies() -> void:
	_counter.text = "%d/%d" % [Stats.seen_count("enemies"), CardDB.enemies.size()]
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_body.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 8)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(grid)
	for e in CardDB.enemies:
		var id := String(e.get("id", ""))
		var seen := Stats.is_seen("enemies", id)
		var boss := bool(e.get("boss", false))
		var panel := PanelContainer.new()
		panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		panel.add_theme_stylebox_override("panel", UiKit.flat(UiKit.BG_LIGHT if seen else UiKit.BG, 10, UiKit.GOLD if (seen and boss) else UiKit.BORDER, 2, 8))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		panel.add_child(row)
		var emblem := PanelContainer.new()
		emblem.custom_minimum_size = Vector2(44, 44)
		emblem.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		var style := UiKit.flat(Color.from_hsv(fmod(float(abs(id.hash())) / 1000.0, 1.0), 0.55, 0.75) if seen else Color(0.25, 0.25, 0.3), 22, Color(0, 0, 0, 0), 0, 0)
		emblem.add_theme_stylebox_override("panel", style)
		var initial := UiKit.label(tr(String(e.get("name", "?"))).substr(0, 1).to_upper() if seen else "?", 22)
		initial.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		initial.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		emblem.add_child(initial)
		row.add_child(emblem)
		var col := VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.add_theme_constant_override("separation", 2)
		row.add_child(col)
		if seen:
			col.add_child(UiKit.label("%s  ·  %s %d" % [tr(String(e.get("name", id))), tr("ataque"), int(e.get("attack", 0))], 17, UiKit.GOLD if boss else Color.WHITE))
			col.add_child(UiKit.label(tr(String(e.get("text", ""))), 14, Color.WHITE, true))
		else:
			col.add_child(UiKit.label("???", 17, UiKit.TEXT_DIM))
			col.add_child(UiKit.label(tr("Ainda não enfrentado."), 14, UiKit.TEXT_DIM))
		grid.add_child(panel)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
