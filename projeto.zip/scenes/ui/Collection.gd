extends Control
## Coleção / códice: o que já descobriste. 0.16.1: cinco separadores —
##   CARTAS      grelha virtual (VirtualCardGrid: só cria as cartas à vista) e agora com as ilustrações
##               (miniaturas de 256 px); filtros por baralho, cor (botões com o símbolo da mana), nome/texto,
##               tipo, palavra-chave, raridade e custo.
##   RELÍQUIAS   medalhões numa grelha desenhada (TileGrid) + painel ao lado com o texto e o conjunto.
##   BESTIÁRIO   retratos + painel (regras, história e quantas vezes o venceste).
##   GALERIA     as ilustrações descobertas (cartas, inimigos, relíquias, lugares) e «SÓ A ARTE».
##   COSMÉTICOS  costas, molduras, tapetes e efeitos: os que tens, os que faltam e como se ganham; USAR.
## Escolha do Paulo para a 0.16.1: "grelha + painel" (toca numa peça e vês os pormenores à direita).
## Por trás, o fundo do menu, sossegado (V57: sem runas e parado quando não mexes no ecrã).
## Descoberta (Stats.mark_seen): cartas dos baralhos jogados, ofertas vistas e cartas ganhas; relíquias
## vistas ou ganhas; inimigos enfrentados; eventos, climas e lugares por onde passaste.

const COLOR_KEYS := ["white", "blue", "black", "red", "green", "colorless"]
const PANEL_W := 420.0
const TABS := [["cards", "CARTAS"], ["relics", "RELÍQUIAS"], ["enemies", "BESTIÁRIO"], ["gallery", "GALERIA"], ["cosmetics", "COSMÉTICOS"], ["diary", "DIÁRIO"]]
const TYPE_FILTERS := ["", "creature", "spell", "enchantment", "land"]
const TYPE_FILTER_NAMES := {"": "Todos os tipos", "creature": "Criaturas", "spell": "Feitiços", "enchantment": "Encantamentos", "land": "Terrenos"}
const RARITY_FILTERS := ["", "common", "uncommon", "rare", "mythic"]
const KW_FILTERS := ["", "flying", "trample", "first_strike", "vigilance", "lifelink", "protection", "landfall"]
const RELIC_CATS := [["all", "Todas"], ["common", "Comuns"], ["uncommon", "Incomuns"], ["rare", "Raras"], ["legendary", "Lendárias"], ["boss", "De boss"], ["blessing", "Bênçãos"]]
const RELIC_ORDER := ["common", "uncommon", "rare", "legendary", "boss", "blessing"]
const ENEMY_CATS := [["all", "Todos"], ["normal", "Inimigos"], ["boss", "Bosses"], ["saga", "História"]]
const GALLERY_CATS := [["cards", "Cartas"], ["enemies", "Inimigos"], ["relics", "Relíquias"], ["places", "Lugares"]]
const COSMETIC_CATS := [["back", "Costas"], ["frame", "Molduras"], ["mat", "Tapetes"], ["effect", "Efeitos"]]
const TAB_ON := Color(0.36, 0.28, 0.62)
const TAB_ON_BORDER := Color(0.72, 0.62, 1.0)

var _tab := "cards"
var _deck_filter := ""      # "" = todos
var _color_filter := ""     # "" = todas
var _search := ""
var _type_filter := ""      # "" | creature | spell | enchantment | land
var _kw_filter := ""        # "" | keyword (CardData.KEYWORDS) | "landfall"
var _rarity_filter := ""    # "" | common | uncommon | rare | mythic
var _cost_filter := 0       # 0 = todos; 1..5
var _grid: VirtualCardGrid
var _shown_label: Label
var _color_buttons: Dictionary = {}
var _all_cards: Array = []      # colecionáveis, pelo número (feito uma vez)
var _deck_ids: Dictionary = {}  # cartas do baralho do filtro
var _body: VBoxContainer
var _tab_buttons: Dictionary = {}
var _counter: Label
# Separadores com grelha + painel
var _relic_cat := "all"
var _enemy_cat := "all"
var _gallery_cat := "cards"
var _cos_kind := "back"
var _tiles: TileGrid              # relíquias e Galeria (desenhada)
var _tile_ids: Array = []         # o id de cada peça da grelha
var _node_grid: GridContainer     # Bestiário e Cosméticos (nós)
var _node_tiles: Dictionary = {}  # id → Button
var _panel: PanelContainer
var _panel_box: VBoxContainer
var _sel := ""
var _backdrop: MenuBackdrop

func _ready() -> void:
	Stats.check_color_sets()  # 0.13.0: cores completas antes desta versão também dão as costas
	Stats.check_deck_backs()  # 0.16.1 (V8): baralhos no nível 4 antes desta versão
	_backdrop = MenuBackdrop.new()
	_backdrop.name = "MenuBackdrop"
	_backdrop.quiet = true
	add_child(_backdrop)
	move_child(_backdrop, mini(1, get_child_count() - 1))   # por cima do fundo liso, por trás de tudo
	_all_cards = CardDB.collectible_cards()
	_all_cards.sort_custom(func(a: CardData, b: CardData): return a.num < b.num)
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 10)
	margin.add_theme_constant_override("margin_bottom", 22)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 10)
	vbox.add_child(header)
	var back := UiKit.menu_button(52, 20)
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("COLEÇÃO"), 30, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(title)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(spacer)
	for t in TABS:
		var b := UiKit.button(tr(String(t[1])), 52, 17)
		b.name = "Tab_" + String(t[0])
		b.toggle_mode = true
		var on := UiKit.flat(TAB_ON, 12, TAB_ON_BORDER, 2, 14)
		b.add_theme_stylebox_override("pressed", on)
		b.add_theme_stylebox_override("hover_pressed", on)
		for st in ["normal", "hover", "pressed", "hover_pressed"]:
			(b.get_theme_stylebox(st) as StyleBoxFlat).content_margin_left = 16
			(b.get_theme_stylebox(st) as StyleBoxFlat).content_margin_right = 16
		b.pressed.connect(func(): Sfx.select(); _select_tab(String(t[0])))
		header.add_child(b)
		_tab_buttons[t[0]] = b
	_counter = UiKit.label("", 17, UiKit.TEXT_DIM)
	_counter.name = "Counter"
	_counter.custom_minimum_size.x = 78
	_counter.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_counter.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(_counter)

	_body = VBoxContainer.new()
	_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_body.add_theme_constant_override("separation", 8)
	vbox.add_child(_body)
	_select_tab("cards")

func _select_tab(tab: String) -> void:
	_tab = tab
	for k in _tab_buttons:
		(_tab_buttons[k] as Button).set_pressed_no_signal(k == tab)
	UiKit.clear_children(_body)
	_grid = null
	_tiles = null
	_node_grid = null
	_node_tiles.clear()
	_diary_buttons.clear()
	_panel = null
	_sel = ""
	match tab:
		"cards":
			_build_cards()
		"relics":
			_build_relics()
		"enemies":
			_build_enemies()
		"gallery":
			_build_gallery()
		"cosmetics":
			_build_cosmetics()
		"diary":
			_build_diary()

## As cartas que a grelha mostra agora (depois dos filtros), pela ordem.
func shown_cards() -> Array:
	return _grid.items if _grid != null else []

# --- Cartas ---

func _build_cards() -> void:
	_counter.text = "%d/%d" % [Stats.seen_count("cards"), _all_cards.size()]
	var filters := HBoxContainer.new()
	filters.add_theme_constant_override("separation", 8)
	_body.add_child(filters)
	var deck_opt := OptionButton.new()
	deck_opt.name = "DeckFilter"
	deck_opt.custom_minimum_size = Vector2(300, 44)
	deck_opt.add_theme_font_size_override("font_size", 17)
	deck_opt.add_item(tr("Todos os baralhos"))
	deck_opt.set_item_metadata(0, "")
	var selected := 0
	var i := 1
	for d in CardDB.decks:
		deck_opt.add_item("%02d · %s" % [int(d.get("num", 0)), tr(String(d.get("name", "")))])
		deck_opt.set_item_metadata(i, String(d.get("id", "")))
		if String(d.get("id", "")) == _deck_filter:
			selected = i
		i += 1
	deck_opt.select(selected)
	deck_opt.item_selected.connect(func(idx: int):
		Sfx.select()
		_set_deck_filter(String(deck_opt.get_item_metadata(idx))))
	filters.add_child(deck_opt)
	_color_buttons.clear()
	for c in COLOR_KEYS:
		var b := UiKit.mana_button(String(c), 44, 52)
		b.button_pressed = _color_filter == c
		b.pressed.connect(func():
			Sfx.select()
			_color_filter = "" if _color_filter == c else String(c)
			_refilter())
		filters.add_child(b)
		_color_buttons[c] = b
	# 0.13.0: descobertas por cor (completar uma cor dá umas costas de carta).
	var hint := UiKit.label(Stats.color_progress_text() + "\n" + tr("Completa uma cor para ganhar umas costas de carta."), 13, UiKit.TEXT_DIM)
	hint.name = "ColorProgress"
	hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	hint.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	hint.clip_text = true
	filters.add_child(hint)
	# 2.ª fila: procurar, tipo, palavra-chave, raridade e custo.
	var row2 := HBoxContainer.new()
	row2.add_theme_constant_override("separation", 8)
	_body.add_child(row2)
	var search := LineEdit.new()
	search.name = "Search"
	search.placeholder_text = tr("Procurar nome ou texto…")
	search.text = _search
	search.custom_minimum_size = Vector2(300, 44)
	search.add_theme_font_size_override("font_size", 17)
	search.clear_button_enabled = true
	var debounce := Timer.new()
	debounce.one_shot = true
	debounce.wait_time = 0.35
	row2.add_child(debounce)
	debounce.timeout.connect(_refilter)
	search.text_changed.connect(func(t: String):
		_search = t
		debounce.start())
	row2.add_child(search)
	row2.add_child(_cycle_btn("TypeFilter", func(): return tr(TYPE_FILTER_NAMES.get(_type_filter, "")), func():
		_type_filter = TYPE_FILTERS[(TYPE_FILTERS.find(_type_filter) + 1) % TYPE_FILTERS.size()]))
	row2.add_child(_cycle_btn("KeywordFilter", func(): return _kw_name(_kw_filter), func():
		_kw_filter = KW_FILTERS[(KW_FILTERS.find(_kw_filter) + 1) % KW_FILTERS.size()]))
	row2.add_child(_cycle_btn("RarityFilter", func(): return tr("Todas as raridades") if _rarity_filter == "" else tr(CardZoom.RARITY_NAMES.get(_rarity_filter, "")), func():
		_rarity_filter = RARITY_FILTERS[(RARITY_FILTERS.find(_rarity_filter) + 1) % RARITY_FILTERS.size()]))
	row2.add_child(_cycle_btn("CostFilter", func(): return tr("Qualquer custo") if _cost_filter == 0 else tr("Custo %d") % _cost_filter, func():
		_cost_filter = (_cost_filter + 1) % 6))
	_shown_label = UiKit.label("", 15, UiKit.TEXT_DIM)
	_shown_label.name = "ShownCount"
	_shown_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row2.add_child(_shown_label)

	_grid = VirtualCardGrid.new()
	_grid.name = "CardGrid"
	_grid.seen_fn = func(d: CardData) -> bool: return Stats.is_seen("cards", d.id)
	_grid.back_id = Settings.card_back
	_grid.card_pressed.connect(func(c: CardInstance):
		Sfx.select()
		CardZoom.show_card(c))
	_body.add_child(_grid)
	_set_deck_filter(_deck_filter)

func _set_deck_filter(deck_id: String) -> void:
	_deck_filter = deck_id
	_deck_ids.clear()
	if deck_id != "":
		for id in CardDB.get_deck(deck_id).get("cards", []):
			_deck_ids[String(id)] = true
	_refilter()

## Botão que roda por valores (tipo, palavra-chave, raridade, custo) e volta a filtrar.
func _cycle_btn(node_name: String, label_fn: Callable, next_fn: Callable) -> Button:
	var b := UiKit.button(String(label_fn.call()), 44, 15)
	b.name = node_name
	b.custom_minimum_size.x = 150
	b.pressed.connect(func():
		Sfx.select()
		next_fn.call()
		b.text = String(label_fn.call())
		_refilter())
	return b

func _kw_name(k: String) -> String:
	if k == "":
		return tr("Todas as palavras-chave")
	if k == "landfall":
		return tr("Chegada de Terreno")
	return tr(String(CardData.KEYWORD_NAMES.get(k, k)))

## Volta a fazer a lista com os filtros (as não descobertas só aparecem sem procura por texto).
func _refilter() -> void:
	if _grid == null or not is_instance_valid(_grid):
		return
	var needle := _search.strip_edges().to_lower()
	var list: Array = []
	for d in _all_cards:
		if _passes(d as CardData, needle):
			list.append(d)
	_grid.back_id = Settings.card_back
	_grid.set_items(list)
	if _shown_label != null:
		_shown_label.text = tr("%d cartas") % list.size()
	for c in _color_buttons:
		(_color_buttons[c] as Button).button_pressed = _color_filter == c

func _passes(d: CardData, needle: String) -> bool:
	if _deck_filter != "" and not _deck_ids.has(d.id):
		return false
	if _color_filter == "colorless" and not d.is_colorless():
		return false
	if _color_filter != "" and _color_filter != "colorless" and not (_color_filter in d.colors):
		return false
	if _type_filter != "" and not d.is_type(_type_filter):
		return false
	if _rarity_filter != "" and d.rarity != _rarity_filter:
		return false
	if _cost_filter > 0 and (d.cost != _cost_filter or d.is_land()):
		return false
	if _kw_filter != "":
		if _kw_filter == "landfall":
			if not d.effects.any(func(e): return String(e.get("trigger", "")) == "landfall"):
				return false
		elif not d.has_keyword(_kw_filter):
			return false
	if needle != "":
		if not Stats.is_seen("cards", d.id):
			return false
		return d.display_name().to_lower().contains(needle) or tr(d.text).to_lower().contains(needle) or d.name.to_lower().contains(needle)
	return true

# --- Peças comuns dos separadores "grelha + painel" ---

## Fila das etiquetas, a grelha à esquerda e o painel à direita; a dica em baixo. Devolve o sítio da grelha.
func _split(chips: Control, footer: String) -> HBoxContainer:
	_body.add_child(chips)
	var split := HBoxContainer.new()
	split.name = "Split"
	split.size_flags_vertical = Control.SIZE_EXPAND_FILL
	split.add_theme_constant_override("separation", 14)
	_body.add_child(split)
	_panel = PanelContainer.new()
	_panel.name = "DetailPanel"
	_panel.custom_minimum_size = Vector2(PANEL_W, 0)
	_panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.075, 0.06, 0.12, 0.9), 16, Color(0.42, 0.36, 0.6, 0.85), 2, 20))
	_panel_box = VBoxContainer.new()
	_panel_box.add_theme_constant_override("separation", 12)
	_panel.add_child(_panel_box)
	var hint := UiKit.label(footer, 14, UiKit.TEXT_DIM)
	hint.name = "Footer"
	_body.add_child(hint)
	return split

func _tile_grid(split: HBoxContainer, shape: String, cell: Vector2) -> void:
	_tiles = TileGrid.new()
	_tiles.name = "Tiles"
	_tiles.shape = shape
	_tiles.cell = cell
	_tiles.tile_pressed.connect(func(i: int):
		if i < 0 or i >= _tile_ids.size():
			return
		Sfx.select()
		_select_item(String(_tile_ids[i])))
	split.add_child(_tiles)
	split.add_child(_panel)

## Grelha de nós (Bestiário e Cosméticos): as colunas acertam-se com a largura.
func _node_grid_in(split: HBoxContainer, cell_w: float) -> void:
	var scroll := ScrollContainer.new()
	scroll.name = "NodeScroll"
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	split.add_child(scroll)
	split.add_child(_panel)
	_node_grid = GridContainer.new()
	_node_grid.name = "NodeGrid"
	_node_grid.add_theme_constant_override("h_separation", 10)
	_node_grid.add_theme_constant_override("v_separation", 10)
	scroll.add_child(_node_grid)
	scroll.resized.connect(_fit_node_columns)
	_set_node_cell(cell_w)

## Largura de cada peça da grelha de nós (os tapetes são mais largos) e as colunas que cabem.
func _set_node_cell(cell_w: float) -> void:
	_node_grid.set_meta("cell_w", cell_w)
	_fit_node_columns()

func _fit_node_columns() -> void:
	if _node_grid == null or not is_instance_valid(_node_grid):
		return
	var scroll := _node_grid.get_parent() as Control
	var w := scroll.size.x if scroll != null and scroll.size.x > 0.0 else 1232.0 - PANEL_W - 14.0
	var cell_w := float(_node_grid.get_meta("cell_w", 104.0))
	_node_grid.columns = maxi(1, int((w - 14.0 + 10.0) / (cell_w + 10.0)))

## Escolhe uma peça (por id) no separador atual e mostra-a no painel.
func _select_item(id: String) -> void:
	_sel = id
	if _tiles != null:
		_tiles.set_selected(_tile_ids.find(id))
		_tiles.ensure_visible(_tile_ids.find(id))
	for k in _node_tiles:
		_style_node_tile(_node_tiles[k] as Button, String(k) == id)
	if _panel_box == null:
		return
	UiKit.clear_children(_panel_box)
	match _tab:
		"relics":
			_show_relic(id)
		"enemies":
			_show_enemy(id)
		"gallery":
			_show_gallery_item(id)
		"cosmetics":
			_show_cosmetic(id)
		"diary":
			_show_diary(id)

## A primeira já descoberta da lista (ou a primeira de todas).
func _first_seen(ids: Array, seen_fn: Callable) -> String:
	for id in ids:
		if bool(seen_fn.call(String(id))):
			return String(id)
	return String(ids[0]) if not ids.is_empty() else ""

func _panel_title(text: String, color: Color = Color.WHITE) -> Label:
	var l := UiKit.label(text, 26, color, true)
	l.name = "PanelTitle"
	return l

static func _rarity_line(text: String, col: Color) -> HBoxContainer:
	return CardZoom._rarity_badge(text, col)

# --- Relíquias ---

static func relic_category(r: Dictionary) -> String:
	if bool(r.get("blessing", false)):
		return "blessing"
	if bool(r.get("boss", false)):
		return "boss"
	if bool(r.get("legendary", false)):
		return "legendary"
	return String(r.get("rarity", "common"))

static func relic_rarity_text(r: Dictionary) -> String:
	match relic_category(r):
		"boss":
			return TranslationServer.translate("Relíquia de boss")
		"legendary":
			return TranslationServer.translate("Lendária")
		"blessing":
			return TranslationServer.translate("Bênção do Santuário")
	return TranslationServer.translate(String(CardZoom.RARITY_NAMES.get(String(r.get("rarity", "common")), "Comum")))

func _sorted_relics() -> Array:
	var list: Array = CardDB.relics.values()
	list.sort_custom(func(a, b):
		var ra := RELIC_ORDER.find(relic_category(a))
		var rb := RELIC_ORDER.find(relic_category(b))
		if ra != rb:
			return ra < rb
		return tr(String(a.get("name", ""))).naturalnocasecmp_to(tr(String(b.get("name", "")))) < 0)
	return list

func _build_relics() -> void:
	_counter.text = "%d/%d" % [Stats.seen_count("relics"), CardDB.relics.size()]
	var counts := {"all": CardDB.relics.size()}
	for r in CardDB.relics.values():
		var c := relic_category(r)
		counts[c] = int(counts.get(c, 0)) + 1
	var chips: Array = []
	for rc in RELIC_CATS:
		var id := String(rc[0])
		chips.append([id, "%s %d" % [tr(String(rc[1])), int(counts.get(id, 0))], Color(0, 0, 0, 0) if id == "all" else RelicView.RING.get(id, RelicView.RING["common"])])
	var row := UiKit.chip_row(chips, _relic_cat, func(id: String):
		_relic_cat = id
		_refresh_relics())
	var split := _split(row, tr("Toca numa relíquia para a ver aqui ao lado."))
	_tile_grid(split, "round", Vector2(88, 108))
	_refresh_relics()

func _refresh_relics() -> void:
	var items: Array = []
	_tile_ids.clear()
	for r in _sorted_relics():
		if _relic_cat != "all" and relic_category(r) != _relic_cat:
			continue
		var id := String(r.get("id", ""))
		var seen := Stats.is_seen("relics", id)
		_tile_ids.append(id)
		items.append({"art": ArtLib.path("relic", id) if seen else "", "label": tr(String(r.get("name", id))), "seen": seen, "ring": RelicView.ring_color(r)})
	_tiles.set_items(items)
	var pick := _sel if _sel in _tile_ids else _first_seen(_tile_ids, func(id: String) -> bool: return Stats.is_seen("relics", id))
	if pick != "":
		_select_item(pick)
	else:
		UiKit.clear_children(_panel_box)

func _show_relic(id: String) -> void:
	var r: Dictionary = CardDB.relics.get(id, {})
	var seen := Stats.is_seen("relics", id)
	var ring := RelicView.ring_color(r)
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 18)
	_panel_box.add_child(top)
	if seen:
		var medal := RelicView.new()
		medal.name = "RelicArt"
		medal.mouse_filter = Control.MOUSE_FILTER_IGNORE
		medal.custom_minimum_size = Vector2(116, 116)
		medal.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		top.add_child(medal)
		medal.setup(id)
	else:
		top.add_child(QMark.make(116.0, ring))
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_theme_constant_override("separation", 6)
	top.add_child(col)
	col.add_child(_panel_title(tr(String(r.get("name", id))) if seen else "???"))
	col.add_child(_rarity_line(relic_rarity_text(r), ring))
	if seen:
		_panel_box.add_child(UiKit.label(tr(String(r.get("text", ""))), 18, Color.WHITE, true))
	else:
		_panel_box.add_child(UiKit.label(tr("Ainda não descoberta."), 18, UiKit.TEXT_DIM, true))
		_panel_box.add_child(UiKit.label(_relic_source(r), 15, Color(0.8, 0.76, 0.95), true))
	var rs := CardDB.relic_set_of(id)
	if not rs.is_empty():
		_panel_box.add_child(_relic_set_box(rs))

## De onde vem uma relíquia que ainda não viste.
func _relic_source(r: Dictionary) -> String:
	var id := String(r.get("id", ""))
	if bool(r.get("locked", false)) and not Stats.is_content_unlocked("relic", id):
		for a in Stats.achievements:
			var u: Dictionary = a.get("unlock", {}) if a.get("unlock") is Dictionary else {}
			if String(u.get("type", "")) == "relic" and String(u.get("id", "")) == id:
				return tr("Desbloqueia-se com a conquista «%s»: %s") % [tr(String(a.get("name", ""))), tr(String(a.get("text", "")))]
	match relic_category(r):
		"blessing":
			return tr("Dá-ta o Santuário, uma paragem do mapa.")
		"boss":
			return tr("Vem no Baú de Espólio, depois de venceres um boss.")
		"legendary":
			return tr("Vende-a o Mercador Cego.")
	return tr("Aparece nas lojas e noutros prémios da run.")

## O conjunto: as peças (as descobertas com cor, as outras com «?») e o bónus.
func _relic_set_box(rs: Dictionary) -> PanelContainer:
	var members: Array = rs.get("relics", [])
	var seen_n := 0
	for m in members:
		if Stats.is_seen("relics", String(m)):
			seen_n += 1
	var box := PanelContainer.new()
	box.name = "SetBox"
	box.add_theme_stylebox_override("panel", UiKit.flat(Color(1, 1, 1, 0.04), 12, Color(1, 1, 1, 0.1), 1, 14))
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	box.add_child(v)
	v.add_child(UiKit.label(tr("Conjunto: %s (%d/%d)") % [tr(String(rs.get("name", ""))), seen_n, members.size()], 16, Color(1.0, 0.86, 0.55), true))
	var pieces := HBoxContainer.new()
	pieces.add_theme_constant_override("separation", 8)
	v.add_child(pieces)
	for m in members:
		var mid := String(m)
		if Stats.is_seen("relics", mid):
			var pv := RelicView.new()
			pv.mouse_filter = Control.MOUSE_FILTER_IGNORE
			pv.custom_minimum_size = Vector2(42, 42)
			pieces.add_child(pv)
			pv.setup(mid)
		else:
			pieces.add_child(QMark.make(42.0, RelicView.ring_color(CardDB.relics.get(mid, {}))))
	v.add_child(UiKit.label(tr(String(rs.get("text", ""))), 14, UiKit.TEXT_DIM, true))
	return box

# --- Bestiário ---

static func _enemy_rank(e: Dictionary) -> int:
	if bool(e.get("saga", false)):
		return 2
	return 1 if bool(e.get("boss", false)) else 0

static func enemy_category(e: Dictionary) -> String:
	return ["normal", "boss", "saga"][_enemy_rank(e)]

static func enemy_tint(id: String) -> Color:
	return Color.from_hsv(fmod(float(abs(id.hash())) / 1000.0, 1.0), 0.55, 0.75)

static func _enemy_kind(e: Dictionary) -> String:
	if bool(e.get("saga", false)):
		return "Boss da História"
	if bool(e.get("final", false)):
		return "Boss final"
	if bool(e.get("boss", false)):
		return "Boss"
	return "Inimigo"

func _sorted_enemies() -> Array:
	var list: Array = CardDB.enemies.duplicate()
	var pos := {}
	for i in list.size():
		pos[String(list[i].get("id", ""))] = i
	list.sort_custom(func(a, b):
		var ra := _enemy_rank(a)
		var rb := _enemy_rank(b)
		if ra != rb:
			return ra < rb
		return int(pos[String(a.get("id", ""))]) < int(pos[String(b.get("id", ""))]))
	return list

func _build_enemies() -> void:
	_counter.text = "%d/%d" % [Stats.seen_count("enemies"), CardDB.enemies.size()]
	var counts := {"all": CardDB.enemies.size()}
	for e in CardDB.enemies:
		var c := enemy_category(e)
		counts[c] = int(counts.get(c, 0)) + 1
	var chips: Array = []
	for ec in ENEMY_CATS:
		chips.append([String(ec[0]), "%s %d" % [tr(String(ec[1])), int(counts.get(String(ec[0]), 0))]])
	var row := UiKit.chip_row(chips, _enemy_cat, func(id: String):
		_enemy_cat = id
		_refresh_enemies())
	var split := _split(row, tr("Bestiário: todos os inimigos e bosses que já enfrentaste. Toca num para ver as regras, a história e quantas vezes o venceste."))
	_node_grid_in(split, 100.0)
	_node_grid.name = "Bestiary"
	_refresh_enemies()

func _refresh_enemies() -> void:
	UiKit.clear_children(_node_grid)
	_node_tiles.clear()
	var ids: Array = []
	for e in _sorted_enemies():
		if _enemy_cat != "all" and enemy_category(e) != _enemy_cat:
			continue
		var id := String(e.get("id", ""))
		ids.append(id)
		var t := _enemy_tile(e)
		_node_grid.add_child(t)
		_node_tiles[id] = t
	var pick := _sel if _sel in ids else _first_seen(ids, func(id: String) -> bool: return Stats.is_seen("enemies", id))
	if pick != "":
		_select_item(pick)
	else:
		UiKit.clear_children(_panel_box)

func _enemy_tile(e: Dictionary) -> Button:
	var id := String(e.get("id", ""))
	var seen := Stats.is_seen("enemies", id)
	var boss := bool(e.get("boss", false))
	var b := Button.new()
	b.name = "Enemy_" + id
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(100, 134)
	b.set_meta("boss", boss)
	_style_node_tile(b, false)
	var v := VBoxContainer.new()
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	v.offset_top = 6
	v.offset_left = 4
	v.offset_right = -4
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_theme_constant_override("separation", 4)
	b.add_child(v)
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(76, 76)
	holder.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(holder)
	if seen:
		var portrait := EnemyPortrait.new()
		portrait.set_anchors_preset(Control.PRESET_FULL_RECT)
		portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE
		portrait.archetype = String(e.get("portrait", "brute"))
		portrait.tint = enemy_tint(id)
		portrait.boss = boss
		portrait.breathing = false
		portrait.art_id = id
		holder.add_child(portrait)
		var wins := Stats.defeated_count(id)
		if wins > 0:
			holder.add_child(WinsBadge.make(wins))
	else:
		var q := QMark.make(76.0, UiKit.GOLD if boss else UiKit.BORDER)
		q.set_anchors_preset(Control.PRESET_FULL_RECT)
		holder.add_child(q)
	v.add_child(_tile_label(tr(String(e.get("name", id))) if seen else "???", (UiKit.GOLD if boss else Color.WHITE) if seen else UiKit.TEXT_DIM))
	b.pressed.connect(func(): Sfx.select(); _select_item(id))
	return b

## Nome por baixo de uma peça: até 2 linhas, centrado (com altura fixa: com autowrap e corte de texto o
## Godot 4.3 dá-lhe 1 px de altura e o nome desaparecia).
static func _tile_label(text: String, color: Color) -> Label:
	var l := UiKit.label(text, 13, color, true)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.max_lines_visible = 2
	l.clip_text = true
	l.custom_minimum_size = Vector2(0, 40)   # 2 linhas de 13 px (com 34 só cabia uma)
	return l

## Peça de nó (Bestiário, Cosméticos): sem fundo; a escolhida com um aro dourado.
func _style_node_tile(b: Button, on: bool) -> void:
	var st := UiKit.flat(Color(1, 1, 1, 0.06) if on else Color(0, 0, 0, 0), 12, UiKit.GOLD if on else Color(0, 0, 0, 0), 2 if on else 0, 4)
	for s in ["normal", "hover", "pressed", "hover_pressed", "disabled"]:
		b.add_theme_stylebox_override(s, st)

func _show_enemy(id: String) -> void:
	var e := CardDB.enemy_def(id)
	var seen := Stats.is_seen("enemies", id)
	var boss := bool(e.get("boss", false))
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 16)
	_panel_box.add_child(top)
	if seen:
		var portrait := EnemyPortrait.new()
		portrait.name = "EnemyArt"
		portrait.custom_minimum_size = Vector2(132, 132)
		portrait.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE
		portrait.archetype = String(e.get("portrait", "brute"))
		portrait.tint = enemy_tint(id)
		portrait.boss = boss
		portrait.breathing = false
		portrait.art_id = id
		top.add_child(portrait)
	else:
		top.add_child(QMark.make(132.0, UiKit.GOLD if boss else UiKit.BORDER))
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_theme_constant_override("separation", 6)
	top.add_child(col)
	col.add_child(_panel_title(tr(String(e.get("name", id))) if seen else "???", UiKit.GOLD if (seen and boss) else Color.WHITE))
	var facts: Array[String] = [tr(_enemy_kind(e))]
	if seen:
		facts.append(tr("ataque %d") % int(e.get("attack", 0)))
		var hp_mult := float(e.get("hp_mult", 1.0))
		if not is_equal_approx(hp_mult, 1.0):
			facts.append(tr("vida ×%s") % String.num(hp_mult, 2))
	if not boss:
		facts.append(tr("a partir do ante %d") % int(e.get("min_ante", 1)))
	col.add_child(UiKit.label("  ·  ".join(PackedStringArray(facts)), 15, UiKit.TEXT_DIM, true))
	if not seen:
		_panel_box.add_child(UiKit.label(tr("Ainda não enfrentado."), 18, UiKit.TEXT_DIM, true))
		return
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_panel_box.add_child(scroll)
	var body := VBoxContainer.new()
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 10)
	scroll.add_child(body)
	body.add_child(UiKit.label(tr(String(e.get("text", ""))), 17, Color.WHITE, true))
	if String(e.get("lore", "")) != "":
		body.add_child(UiKit.label("“" + tr(String(e.get("lore", ""))) + "”", 16, Color(0.82, 0.78, 0.95), true))
	var lines: Dictionary = e.get("lines", {}) if e.get("lines") is Dictionary else {}
	if String(lines.get("intro", "")) != "":
		body.add_child(UiKit.label(tr("Diz: «%s»") % tr(String(lines["intro"])), 15, UiKit.TEXT_DIM, true))
	var wins := UiKit.label(tr("Vencido %d vezes.") % Stats.defeated_count(id), 17, Color(0.6, 0.95, 0.65))
	wins.name = "Wins"
	_panel_box.add_child(wins)

# --- Galeria (53) ---

## As peças de uma categoria da Galeria: [{id, art (miniatura), full [tipo, id], label, sub, seen}].
func gallery_items(cat: String) -> Array:
	var out: Array = []
	match cat:
		"cards":
			for d in _all_cards:
				var cd := d as CardData
				if ArtLib.path("card", cd.id) == "":
					continue
				var thumb := ArtLib.path("card_thumb", cd.id)
				out.append({"id": cd.id, "art": thumb if thumb != "" else ArtLib.path("card", cd.id), "full": ["card", cd.id],
					"label": cd.display_name(), "sub": _card_sub(cd), "seen": Stats.is_seen("cards", cd.id)})
		"enemies":
			for e in _sorted_enemies():
				var id := String(e.get("id", ""))
				if ArtLib.path("portrait", id) == "":
					continue
				out.append({"id": id, "art": ArtLib.path("portrait", id), "full": ["portrait", id], "label": tr(String(e.get("name", id))),
					"sub": tr(_enemy_kind(e)), "seen": Stats.is_seen("enemies", id)})
		"relics":
			for r in _sorted_relics():
				var id := String(r.get("id", ""))
				if ArtLib.path("relic", id) == "":
					continue
				out.append({"id": id, "art": ArtLib.path("relic", id), "full": ["relic", id], "label": tr(String(r.get("name", id))),
					"sub": relic_rarity_text(r), "seen": Stats.is_seen("relics", id), "ring": RelicView.ring_color(r)})
		"places":
			for a in CardDB.acts:
				var key := String(a.get("key", ""))
				var bid := "act_E" if key == "E" else "act_" + key
				if ArtLib.path("background", bid) == "":
					continue
				out.append({"id": bid, "art": ArtLib.path("place_thumb", bid), "full": ["background", bid], "label": tr(String(a.get("title", ""))),
					"sub": tr("Eternidade") if key == "E" else tr("Ato %s") % ["I", "II", "III", "IV", "V"][clampi(int(key) - 1, 0, 4)],
					"seen": key == "E" or Stats.is_seen("places", bid)})
			for sp in [["shop_merchant", "Loja do Mercador", "Loja"], ["shop_blind", "Tenda do Mercador Cego", "Loja"]]:
				if ArtLib.path("background", String(sp[0])) != "":
					out.append({"id": String(sp[0]), "art": ArtLib.path("place_thumb", String(sp[0])), "full": ["background", String(sp[0])],
						"label": tr(String(sp[1])), "sub": tr(String(sp[2])), "seen": Stats.is_seen("places", String(sp[0]))})
			for c in CardDB.climates:
				var cid := String(c.get("id", ""))
				if ArtLib.path("background", "clim_" + cid) == "":
					continue
				out.append({"id": "clim_" + cid, "art": ArtLib.path("place_thumb", "clim_" + cid), "full": ["background", "clim_" + cid],
					"label": tr(String(c.get("name", cid))), "sub": tr("Clima planar"), "seen": Stats.is_seen("climates", cid)})
			for ev in CardDB.events:
				var eid := String(ev.get("id", ""))
				if ArtLib.path("event", eid) == "":
					continue
				out.append({"id": "ev_" + eid, "art": ArtLib.path("place_thumb", "ev_" + eid), "full": ["event", eid],
					"label": tr(String(ev.get("title", eid))), "sub": tr("Paragem do mapa"), "seen": Stats.is_seen("events", eid)})
	for it in out:
		if String(it["art"]) == "":
			it["art"] = ArtLib.path(String(it["full"][0]), String(it["full"][1]))
	return out

var _card_deck: Dictionary = {}   # carta → nome do baralho (para a legenda da Galeria)

func _card_sub(d: CardData) -> String:
	if _card_deck.is_empty():
		for dk in CardDB.decks:
			for cid in dk.get("cards", []):
				if not _card_deck.has(String(cid)):
					_card_deck[String(cid)] = String(dk.get("name", ""))
	var deck := String(_card_deck.get(d.id, ""))
	return tr(deck) if deck != "" else tr("Carta")

var _gallery: Array = []

func _build_gallery() -> void:
	var chips: Array = []
	var seen_all := 0
	var total_all := 0
	for gc in GALLERY_CATS:
		var list := gallery_items(String(gc[0]))
		var n := list.filter(func(it): return bool(it["seen"])).size()
		seen_all += n
		total_all += list.size()
		chips.append([String(gc[0]), "%s %d/%d" % [tr(String(gc[1])), n, list.size()]])
	_counter.text = "%d/%d" % [seen_all, total_all]
	var row := UiKit.chip_row(chips, _gallery_cat, func(id: String):
		_gallery_cat = id
		_refresh_gallery())
	var split := _split(row, tr("As que ainda não descobriste aparecem com «?». Toca numa e depois em «SÓ A ARTE» para a ver em grande."))
	_tile_grid(split, "wide", Vector2(148, 112))
	_refresh_gallery()

func _refresh_gallery() -> void:
	_gallery = gallery_items(_gallery_cat)
	match _gallery_cat:
		"enemies":
			_tiles.shape = "square"
			_tiles.cell = Vector2(104, 128)
		"relics":
			_tiles.shape = "round"
			_tiles.cell = Vector2(88, 108)
		_:
			_tiles.shape = "wide"
			_tiles.cell = Vector2(148, 112)
	_tile_ids.clear()
	var items: Array = []
	for it in _gallery:
		_tile_ids.append(String(it["id"]))
		items.append({"art": String(it["art"]) if bool(it["seen"]) else "", "label": String(it["label"]), "seen": bool(it["seen"]),
			"ring": it.get("ring", Color(0.55, 0.48, 0.78))})
	_tiles.set_items(items)
	var pick := _sel if _sel in _tile_ids else ""
	if pick == "":
		for it in _gallery:
			if bool(it["seen"]):
				pick = String(it["id"])
				break
	if pick == "" and not _tile_ids.is_empty():
		pick = String(_tile_ids[0])
	if pick != "":
		_select_item(pick)
	else:
		UiKit.clear_children(_panel_box)

func _gallery_item(id: String) -> Dictionary:
	for it in _gallery:
		if String(it["id"]) == id:
			return it
	return {}

func _show_gallery_item(id: String) -> void:
	var it := _gallery_item(id)
	if it.is_empty():
		return
	var seen := bool(it["seen"])
	var full: Array = it["full"]
	var preview := ArtPreview.new()
	preview.name = "GalleryArt"
	preview.circle = _gallery_cat == "relics"
	preview.custom_minimum_size = Vector2(PANEL_W - 40.0, 214.0)
	preview.tex = ArtLib.texture(String(full[0]), String(full[1])) if seen else null
	_panel_box.add_child(preview)
	_panel_box.add_child(_panel_title(String(it["label"]) if seen else "???"))
	_panel_box.add_child(UiKit.label(String(it["sub"]), 16, UiKit.TEXT_DIM, true))
	if not seen:
		_panel_box.add_child(UiKit.label(tr("Ainda por descobrir: aparece aqui quando a encontrares numa run."), 16, UiKit.TEXT_DIM, true))
		return
	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_panel_box.add_child(spacer)
	var only := UiKit.button(tr("SÓ A ARTE"), 52, 18, UiKit.PRIMARY)
	only.name = "ArtOnly"
	UiKit.button_icon(only, "star", Color.WHITE, 20.0, false)
	only.pressed.connect(func():
		Sfx.select()
		ArtViewer.open(ArtLib.texture(String(full[0]), String(full[1])), String(it["label"]), String(it["sub"])))
	_panel_box.add_child(only)

# --- 0.17.0 (94): Diário do Mago ---
# À esquerda as páginas (as fechadas com «???»; as novas com um ponto), à direita a página aberta: a ilustração,
# o título e o texto. As fechadas dizem o que falta para as abrir.

var _diary_buttons: Dictionary = {}   # id da página → Button

func _build_diary() -> void:
	Stats.check_diary(false)
	var open: Array = Stats.diary_unlocked()
	_counter.text = "%d/%d" % [open.size(), CardDB.diary.size()]
	var split := HBoxContainer.new()
	split.name = "DiarySplit"
	split.size_flags_vertical = Control.SIZE_EXPAND_FILL
	split.add_theme_constant_override("separation", 14)
	_body.add_child(split)
	var scroll := ScrollContainer.new()
	scroll.name = "DiaryScroll"
	scroll.custom_minimum_size.x = 340
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	split.add_child(scroll)
	var list := VBoxContainer.new()
	list.name = "DiaryList"
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 6)
	scroll.add_child(list)
	_panel = PanelContainer.new()
	_panel.name = "DetailPanel"
	_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.075, 0.06, 0.12, 0.9), 16, Color(0.62, 0.5, 0.3, 0.85), 2, 20))
	_panel_box = VBoxContainer.new()
	_panel_box.add_theme_constant_override("separation", 10)
	_panel.add_child(_panel_box)
	split.add_child(_panel)
	var first_unread := ""
	for i in CardDB.diary.size():
		var p: Dictionary = CardDB.diary[i]
		var id := String(p.get("id", ""))
		var b := UiKit.button("", 46, 16)
		b.name = "Page_" + id
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.clip_text = true
		b.pressed.connect(func(): Sfx.select(); _select_item(id))
		list.add_child(b)
		_diary_buttons[id] = b
		_diary_button_text(id, i)
		if first_unread == "" and Stats.diary_is_open(id) and not Stats.diary_is_read(id):
			first_unread = id
	var hint := UiKit.label(tr("Páginas da história do Plano: abrem-se ao vencer bosses, acabar capítulos, descobrir cartas raras e com outros feitos."), 14, UiKit.TEXT_DIM)
	hint.name = "Footer"
	_body.add_child(hint)
	var pick := first_unread
	if pick == "":
		pick = String(open[0]) if not open.is_empty() else (String(CardDB.diary[0].get("id", "")) if not CardDB.diary.is_empty() else "")
	if pick != "":
		_select_item(pick)

func _diary_button_text(id: String, index: int) -> void:
	var b: Button = _diary_buttons.get(id)
	if b == null:
		return
	var p := Stats.diary_page(id)
	var open := Stats.diary_is_open(id)
	b.text = ("%02d · " % (index + 1)) + (tr(String(p.get("title", ""))) if open else "???") + ("  •" if open and not Stats.diary_is_read(id) else "")
	b.add_theme_color_override("font_color", Color.WHITE if open else UiKit.TEXT_DIM)

func _show_diary(id: String) -> void:
	var p := Stats.diary_page(id)
	if p.is_empty():
		return
	var index := CardDB.diary.find(p)
	for k in _diary_buttons:
		var on := String(k) == id
		var st := UiKit.flat(Color(0.36, 0.26, 0.12, 0.9) if on else UiKit.BTN_BG, 12, UiKit.GOLD if on else Color(0, 0, 0, 0), 2 if on else 0, 12)
		for s in ["normal", "hover", "pressed", "hover_pressed"]:
			(_diary_buttons[k] as Button).add_theme_stylebox_override(s, st)
	if not Stats.diary_is_open(id):
		var center := CenterContainer.new()
		center.custom_minimum_size.y = 200
		center.add_child(QMark.make(150.0, UiKit.GOLD))
		_panel_box.add_child(center)
		_panel_box.add_child(_panel_title("???", UiKit.TEXT_DIM))
		_panel_box.add_child(UiKit.label(tr("Página %d de %d") % [index + 1, CardDB.diary.size()], 15, UiKit.TEXT_DIM))
		var how := UiKit.label(tr("Para a abrir: %s") % Stats.diary_hint(p), 18, Color.WHITE, true)
		how.name = "DiaryHint"
		_panel_box.add_child(how)
		return
	var art: Dictionary = p.get("art", {}) if p.get("art") is Dictionary else {}
	var tex: Texture2D = ArtLib.texture(String(art.get("kind", "")), String(art.get("id", "")))
	if tex == null and art.get("fallback") is Array and (art["fallback"] as Array).size() >= 2:
		tex = ArtLib.texture(String(art["fallback"][0]), String(art["fallback"][1]))
	if tex != null:
		var preview := ArtPreview.new()
		preview.name = "DiaryArt"
		preview.custom_minimum_size = Vector2(0, 230)
		preview.tex = tex
		_panel_box.add_child(preview)
	elif String(art.get("kind", "")) == "portrait":
		var eid := String(art.get("id", ""))
		var center := CenterContainer.new()
		center.name = "DiaryArt"
		center.custom_minimum_size.y = 230
		var portrait := EnemyPortrait.new()
		portrait.custom_minimum_size = Vector2(210, 210)
		portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE
		portrait.archetype = String(CardDB.enemy_def(eid).get("portrait", "brute"))
		portrait.tint = enemy_tint(eid)
		portrait.boss = true
		portrait.breathing = false
		portrait.art_id = eid
		center.add_child(portrait)
		_panel_box.add_child(center)
	var title := _panel_title(tr(String(p.get("title", ""))), UiKit.GOLD)
	title.theme_type_variation = &"TitleLabel"
	_panel_box.add_child(title)
	_panel_box.add_child(UiKit.label(tr("Página %d de %d") % [index + 1, CardDB.diary.size()], 15, UiKit.TEXT_DIM))
	var scroll := ScrollContainer.new()
	scroll.name = "DiaryTextScroll"
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	_panel_box.add_child(scroll)
	var text := UiKit.label(tr(String(p.get("text", ""))), 18, Color(0.94, 0.92, 0.98), true)
	text.name = "DiaryText"
	text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(text)
	if not Stats.diary_is_read(id):
		Stats.mark_diary_read(id)
		_diary_button_text(id, index)

# --- Cosméticos (V13) ---

func _cosmetics(kind: String) -> Array:
	return CardDB.cosmetics.get(kind + "s", []) as Array

func _build_cosmetics() -> void:
	var chips: Array = []
	var have_all := 0
	var total_all := 0
	for cc in COSMETIC_CATS:
		var kind := String(cc[0])
		var have := Settings.unlocked_cosmetics(kind).size()
		var total := _cosmetics(kind).size()
		have_all += have
		total_all += total
		chips.append([kind, "%s %d/%d" % [tr(String(cc[1])), have, total]])
	_counter.text = "%d/%d" % [have_all, total_all]
	var row := UiKit.chip_row(chips, _cos_kind, func(id: String):
		_cos_kind = id
		_sel = ""
		_refresh_cosmetics())
	var split := _split(row, tr("Os cosméticos só mudam o aspeto. Toca num para ver como se ganha; USAR escolhe-o."))
	_node_grid_in(split, 104.0 if _cos_kind != "mat" else 150.0)
	_node_grid.name = "Cosmetics"
	_refresh_cosmetics()

func _refresh_cosmetics() -> void:
	UiKit.clear_children(_node_grid)
	_node_tiles.clear()
	_set_node_cell(150.0 if _cos_kind == "mat" else 104.0)
	var unlocked := Settings.unlocked_cosmetics(_cos_kind)
	var ids: Array = []
	for c in _cosmetics(_cos_kind):
		var id := String(c.get("id", ""))
		ids.append(id)
		var t := _cosmetic_tile(_cos_kind, c, id in unlocked)
		_node_grid.add_child(t)
		_node_tiles[id] = t
	var pick := _sel if _sel in ids else Settings.cosmetic(_cos_kind)
	if not (pick in ids) and not ids.is_empty():
		pick = String(ids[0])
	if pick != "":
		_select_item(pick)

func _cosmetic_tile(kind: String, c: Dictionary, unlocked: bool) -> Button:
	var id := String(c.get("id", ""))
	var b := Button.new()
	b.name = "Cos_" + id
	b.focus_mode = Control.FOCUS_NONE
	var wide := kind == "mat"
	b.custom_minimum_size = Vector2(150 if wide else 104, 134 if wide else (182 if kind != "effect" else 146))
	_style_node_tile(b, false)
	var v := VBoxContainer.new()
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	v.offset_top = 6
	v.offset_left = 4
	v.offset_right = -4
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_theme_constant_override("separation", 4)
	b.add_child(v)
	var size_px := Vector2(140, 82) if wide else (Vector2(80, 112) if kind != "effect" else Vector2(84, 84))
	var prev := CosmeticPreview.make(kind, id, size_px)
	prev.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	if not unlocked:
		prev.modulate = Color(0.42, 0.4, 0.52, 0.95)
	v.add_child(prev)
	if not unlocked:
		var lock := CardIcon.new("lock", Color(1, 1, 1, 0.85), 26.0)
		lock.set_anchors_preset(Control.PRESET_CENTER)
		lock.offset_left = -13
		lock.offset_right = 13
		lock.offset_top = -13
		lock.offset_bottom = 13
		prev.add_child(lock)
	if Settings.cosmetic(kind) == id:
		prev.add_child(InUseBadge.new())
	v.add_child(_tile_label(tr(String(c.get("name", id))), Color.WHITE if unlocked else UiKit.TEXT_DIM))
	b.pressed.connect(func(): Sfx.select(); _select_item(id))
	return b

func _show_cosmetic(id: String) -> void:
	var kind := _cos_kind
	var c := CardDB.get_cosmetic(kind, id)
	var unlocked := id in Settings.unlocked_cosmetics(kind)
	var in_use := Settings.cosmetic(kind) == id
	var holder := CenterContainer.new()
	holder.name = "CosmeticArt"
	_panel_box.add_child(holder)
	var px := Vector2(360, 190) if kind == "mat" else (Vector2(150, 210) if kind != "effect" else Vector2(200, 170))
	var prev := CosmeticPreview.make(kind, id, px)
	if not unlocked:
		prev.modulate = Color(0.45, 0.42, 0.55)
	holder.add_child(prev)
	_panel_box.add_child(_panel_title(tr(String(c.get("name", id)))))
	if kind == "back" and String(c.get("deck", "")) != "":
		_panel_box.add_child(UiKit.label(tr("Costas do baralho"), 15, UiKit.TEXT_DIM))
	var status := UiKit.label(tr("Em uso") if in_use else (tr("Desbloqueado") if unlocked else tr("Bloqueado")), 16,
		Color(0.6, 0.95, 0.65) if in_use else (Color.WHITE if unlocked else Color(1.0, 0.62, 0.55)))
	status.name = "CosmeticStatus"
	_panel_box.add_child(status)
	var src := Stats.cosmetic_source(kind, id)
	if src != "":
		var sl := UiKit.label(src, 15, Color(0.8, 0.76, 0.95), true)
		sl.name = "CosmeticSource"
		_panel_box.add_child(sl)
	var spacer := Control.new()
	spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_panel_box.add_child(spacer)
	var use := UiKit.button(tr("EM USO") if in_use else tr("USAR"), 52, 19, UiKit.PRIMARY)
	use.name = "UseCosmetic"
	use.disabled = in_use or not unlocked
	use.pressed.connect(func():
		if Settings.set_cosmetic(kind, id):
			Sfx.select()
			_refresh_cosmetics())
	_panel_box.add_child(use)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")

# --- Peças desenhadas ---

## Peça por descobrir: círculo escuro com «?» e um aro apagado.
class QMark extends Control:
	var ring := Color(0.35, 0.3, 0.5)

	static func make(px: float, p_ring: Color) -> QMark:
		var q := QMark.new()
		q.ring = p_ring
		q.custom_minimum_size = Vector2(px, px)
		q.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		q.mouse_filter = Control.MOUSE_FILTER_IGNORE
		return q

	func _draw() -> void:
		var c := size * 0.5
		var r := minf(size.x, size.y) * 0.5 - 2.0
		if r < 4.0:
			return
		draw_circle(c, r, Color(0.08, 0.06, 0.13))
		draw_arc(c, r - 1.5, 0.0, TAU, 40, Color(ring, 0.3), 3.0, true)
		var font := get_theme_default_font()
		var fs := int(clampf(r * 0.8, 12.0, 48.0))
		var w := font.get_string_size("?", HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		draw_string(font, c + Vector2(-w * 0.5, fs * 0.36), "?", HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 1, 1, 0.32))

## Medalha das vitórias no canto do retrato («×3»).
class WinsBadge extends Control:
	var wins := 0

	static func make(n: int) -> WinsBadge:
		var w := WinsBadge.new()
		w.wins = n
		w.mouse_filter = Control.MOUSE_FILTER_IGNORE
		w.set_anchors_preset(Control.PRESET_TOP_RIGHT)
		w.offset_left = -26
		w.offset_right = 4
		w.offset_top = -4
		w.offset_bottom = 22
		return w

	func _draw() -> void:
		var c := size * 0.5
		draw_circle(c, 13.0, Color(0.42, 0.3, 0.08))
		draw_circle(c, 11.0, Color(0.95, 0.74, 0.28))
		var font := get_theme_default_font()
		var t := "%d" % wins if wins < 100 else "99+"
		var fs := 12 if wins < 10 else 10
		var tw := font.get_string_size(t, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		draw_string(font, c + Vector2(-tw * 0.5, fs * 0.36), t, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(0.2, 0.12, 0.02))

## «EM USO» por cima da pré-visualização do cosmético escolhido.
class InUseBadge extends Control:
	func _init() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		set_anchors_preset(Control.PRESET_FULL_RECT)

	func _draw() -> void:
		var font := get_theme_default_font()
		var t := TranslationServer.translate("EM USO")
		var tw := font.get_string_size(t, HORIZONTAL_ALIGNMENT_LEFT, -1, 11).x
		var r := Rect2(Vector2((size.x - tw) * 0.5 - 6.0, size.y - 20.0), Vector2(tw + 12.0, 17.0))
		draw_style_box(UiKit.flat(Color(0.1, 0.42, 0.24), 8, Color(0.55, 0.95, 0.6), 1, 0), r)
		draw_string(font, Vector2(r.position.x + 6.0, r.position.y + 13.0), t, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(0.9, 1.0, 0.9))

## A ilustração em grande no painel da Galeria (inteira, centrada; redonda nas relíquias).
class ArtPreview extends Control:
	var tex: Texture2D = null:
		set(v):
			tex = v
			queue_redraw()
	var circle := false

	func _init() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _draw() -> void:
		var s := size
		if s.x < 10.0:
			return
		if tex == null:
			var q := minf(s.x, s.y) * 0.5
			draw_circle(s * 0.5, q - 4.0, Color(0.08, 0.06, 0.13))
			var font := get_theme_default_font()
			var w := font.get_string_size("?", HORIZONTAL_ALIGNMENT_LEFT, -1, 48).x
			draw_string(font, s * 0.5 + Vector2(-w * 0.5, 17.0), "?", HORIZONTAL_ALIGNMENT_LEFT, -1, 48, Color(1, 1, 1, 0.3))
			return
		var ts := tex.get_size()
		if circle:
			var rr := minf(s.x, s.y) * 0.5 - 4.0
			ArtLib.draw_round(self, tex, s * 0.5, rr)
			draw_arc(s * 0.5, rr, 0.0, TAU, 48, Color(UiKit.GOLD, 0.8), 2.0, true)
			return
		var k := minf(s.x / ts.x, s.y / ts.y)
		var r := Rect2((s - ts * k) * 0.5, ts * k)
		ArtLib.draw_rounded(self, tex, r, 12.0, 0.5)
		var pts := ArtLib.rounded_rect_points(r, 12.0, 4)
		pts.append(pts[0])
		draw_polyline(pts, Color(UiKit.GOLD, 0.6), 2.0, true)
