extends Control
## Coleção / códice: cartas (por baralho e cor), relíquias e inimigos, com o que já descobriste.
## 0.12.0: as cartas filtram-se também por nome/texto, tipo, palavra-chave, raridade e custo (sem refazer
## a grelha); o separador dos inimigos é o Bestiário (retrato, regras, história e vezes vencido).
## Descoberta: cartas dos baralhos jogados, ofertas vistas e cartas ganhas; relíquias vistas na loja
## ou ganhas; inimigos enfrentados (Stats.mark_seen).

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const COLORS := [["white", "B"], ["blue", "A"], ["black", "P"], ["red", "V"], ["green", "Vd"], ["colorless", "∅"]]

var _tab := "cards"
var _deck_filter := ""      # "" = todos
var _color_filter := ""     # "" = todas
# 0.12.0: filtros extra (aplicam-se escondendo cartas, sem refazer a grelha)
var _search := ""
var _type_filter := ""      # "" | creature | spell | enchantment | land
var _kw_filter := ""        # "" | keyword (CardData.KEYWORDS) | "landfall"
var _rarity_filter := ""    # "" | common | uncommon | rare | mythic
var _cost_filter := 0       # 0 = todos; 1..5
var _card_grid: GridContainer
var _shown_label: Label
const TYPE_FILTERS := ["", "creature", "spell", "enchantment", "land"]
const TYPE_FILTER_NAMES := {"": "Todos os tipos", "creature": "Criaturas", "spell": "Feitiços", "enchantment": "Encantamentos", "land": "Terrenos"}
const RARITY_FILTERS := ["", "common", "uncommon", "rare", "mythic"]
const KW_FILTERS := ["", "flying", "trample", "first_strike", "vigilance", "lifelink", "protection", "landfall"]
var _body: VBoxContainer
var _tab_buttons: Dictionary = {}
var _counter: Label

func _ready() -> void:
	CardView.art_on = false   # 0.12.0: centenas de cartas — a ilustração vê-se na carta em grande
	Stats.check_color_sets()  # 0.13.0: cores completas antes desta versão também dão as costas
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 10)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var back := UiKit.menu_button(52, 20)
	back.custom_minimum_size.x = 140
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("COLEÇÃO"), 30, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(title)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(spacer)
	for t in [["cards", tr("CARTAS")], ["relics", tr("RELÍQUIAS")], ["enemies", tr("BESTIÁRIO")]]:
		var b := UiKit.button(String(t[1]), 52, 19)
		b.custom_minimum_size.x = 170
		b.toggle_mode = true
		b.pressed.connect(_select_tab.bind(String(t[0])))
		header.add_child(b)
		_tab_buttons[t[0]] = b
	_counter = UiKit.label("", 18, UiKit.TEXT_DIM)
	_counter.custom_minimum_size.x = 120
	_counter.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_counter.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(_counter)

	_body = VBoxContainer.new()
	_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_body.add_theme_constant_override("separation", 8)
	vbox.add_child(_body)
	_select_tab("cards")

func _select_tab(tab: String) -> void:
	_tab = tab
	for k in _tab_buttons:
		(_tab_buttons[k] as Button).button_pressed = (k == tab)
	for c in _body.get_children():
		c.queue_free()
	match tab:
		"cards":
			_build_cards()
		"relics":
			_build_relics()
		"enemies":
			_build_enemies()

# --- Cartas ---

func _build_cards() -> void:
	_counter.text = "%d/%d" % [Stats.seen_count("cards"), CardDB.collectible_cards().size()]
	var filters := HBoxContainer.new()
	filters.add_theme_constant_override("separation", 8)
	_body.add_child(filters)
	var deck_opt := OptionButton.new()
	deck_opt.custom_minimum_size = Vector2(320, 44)
	deck_opt.add_theme_font_size_override("font_size", 17)
	deck_opt.add_item(tr("Todos os baralhos"))
	deck_opt.set_item_metadata(0, "")
	var selected := 0
	var i := 1
	for d in CardDB.decks:
		deck_opt.add_item("%02d · %s" % [int(d.get("num", 0)), tr(String(d.get("name", "")))])
		deck_opt.set_item_metadata(i, String(d.get("id", "")))
		if String(d.get("id", "")) == _deck_filter:
			selected = i
		i += 1
	deck_opt.select(selected)
	deck_opt.item_selected.connect(func(idx: int):
		_deck_filter = String(deck_opt.get_item_metadata(idx))
		Sfx.select()
		_select_tab("cards"))
	filters.add_child(deck_opt)
	for c in COLORS:
		var b := UiKit.button(String(c[1]), 44, 17, CardView.COLORS[c[0]], Color(0, 0, 0, 0))
		b.custom_minimum_size.x = 52
		b.add_theme_color_override("font_color", CardView.DARK_TEXT if (CardView.COLORS[c[0]] as Color).get_luminance() > 0.45 else CardView.LIGHT_TEXT)
		b.toggle_mode = true
		b.button_pressed = (_color_filter == c[0])
		b.pressed.connect(func():
			_color_filter = "" if _color_filter == c[0] else String(c[0])
			Sfx.select()
			_select_tab("cards"))
		filters.add_child(b)
	# 0.13.0: descobertas por cor (completar uma cor dá umas costas de carta).
	var hint := UiKit.label(Stats.color_progress_text() + "\n" + tr("Completa uma cor para ganhar umas costas de carta."), 13, UiKit.TEXT_DIM)
	hint.name = "ColorProgress"
	hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	hint.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	hint.clip_text = true
	filters.add_child(hint)
	# 2.ª fila: procurar, tipo, palavra-chave, raridade e custo.
	var row2 := HBoxContainer.new()
	row2.add_theme_constant_override("separation", 8)
	_body.add_child(row2)
	var search := LineEdit.new()
	search.name = "Search"
	search.placeholder_text = tr("Procurar nome ou texto…")
	search.text = _search
	search.custom_minimum_size = Vector2(300, 44)
	search.add_theme_font_size_override("font_size", 17)
	search.clear_button_enabled = true
	var debounce := Timer.new()
	debounce.one_shot = true
	debounce.wait_time = 0.35
	add_child(debounce)
	debounce.timeout.connect(_refilter)
	search.text_changed.connect(func(t: String):
		_search = t
		debounce.start())
	row2.add_child(search)
	row2.add_child(_cycle_btn("TypeFilter", func(): return tr(TYPE_FILTER_NAMES.get(_type_filter, "")), func():
		_type_filter = TYPE_FILTERS[(TYPE_FILTERS.find(_type_filter) + 1) % TYPE_FILTERS.size()]))
	row2.add_child(_cycle_btn("KeywordFilter", func(): return _kw_name(_kw_filter), func():
		_kw_filter = KW_FILTERS[(KW_FILTERS.find(_kw_filter) + 1) % KW_FILTERS.size()]))
	row2.add_child(_cycle_btn("RarityFilter", func(): return tr("Todas as raridades") if _rarity_filter == "" else tr(CardZoom.RARITY_NAMES.get(_rarity_filter, "")), func():
		_rarity_filter = RARITY_FILTERS[(RARITY_FILTERS.find(_rarity_filter) + 1) % RARITY_FILTERS.size()]))
	row2.add_child(_cycle_btn("CostFilter", func(): return tr("Qualquer custo") if _cost_filter == 0 else tr("Custo %d") % _cost_filter, func():
		_cost_filter = (_cost_filter + 1) % 6))
	_shown_label = UiKit.label("", 15, UiKit.TEXT_DIM)
	_shown_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row2.add_child(_shown_label)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_body.add_child(scroll)
	var grid := GridContainer.new()
	grid.name = "CardGrid"
	grid.columns = 8
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(grid)
	_card_grid = grid
	var list: Array = CardDB.collectible_cards()
	list.sort_custom(func(a: CardData, b: CardData): return a.num < b.num)
	for d in list:
		if _deck_filter != "" and not _belongs_to_deck(d.id, _deck_filter):
			continue
		if _color_filter == "colorless" and not d.is_colorless():
			continue
		if _color_filter != "" and _color_filter != "colorless" and not (_color_filter in d.colors):
			continue
		var view: CardView = CARD_VIEW.instantiate()
		grid.add_child(view)
		var inst := CardDB.new_instance(d.id)
		view.setup(inst)
		view.set_meta("data", d)
		view.set_meta("seen", Stats.is_seen("cards", d.id))
		if Stats.is_seen("cards", d.id):
			view.pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
			view.long_pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
		else:
			view.set_unknown()
	_refilter()

## Botão que roda por valores (tipo, palavra-chave, raridade, custo) e volta a filtrar.
func _cycle_btn(node_name: String, label_fn: Callable, next_fn: Callable) -> Button:
	var b := UiKit.button(String(label_fn.call()), 44, 15)
	b.name = node_name
	b.custom_minimum_size.x = 150
	b.pressed.connect(func():
		Sfx.select()
		next_fn.call()
		b.text = String(label_fn.call())
		_refilter())
	return b

func _kw_name(k: String) -> String:
	if k == "":
		return tr("Todas as palavras-chave")
	if k == "landfall":
		return tr("Chegada de Terreno")
	return tr(String(CardData.KEYWORD_NAMES.get(k, k)))

## Esconde as cartas que não passam nos filtros (as não descobertas só aparecem sem filtros de texto).
func _refilter() -> void:
	if _card_grid == null or not is_instance_valid(_card_grid):
		return
	var needle := _search.strip_edges().to_lower()
	var shown := 0
	for v in _card_grid.get_children():
		var d: CardData = v.get_meta("data", null)
		if d == null:
			continue
		var ok := true
		if _type_filter != "" and not d.is_type(_type_filter):
			ok = false
		if ok and _rarity_filter != "" and d.rarity != _rarity_filter:
			ok = false
		if ok and _cost_filter > 0 and (d.cost != _cost_filter or d.is_land()):
			ok = false
		if ok and _kw_filter != "":
			if _kw_filter == "landfall":
				ok = d.effects.any(func(e): return String(e.get("trigger", "")) == "landfall")
			else:
				ok = d.has_keyword(_kw_filter)
		if ok and needle != "":
			var seen := bool(v.get_meta("seen", false))
			ok = seen and (d.display_name().to_lower().contains(needle) or tr(d.text).to_lower().contains(needle) or d.name.to_lower().contains(needle))
		(v as Control).visible = ok
		if ok:
			shown += 1
	if _shown_label != null:
		_shown_label.text = tr("%d cartas") % shown

func _belongs_to_deck(card_id: String, deck_id: String) -> bool:
	var d := CardDB.get_deck(deck_id)
	for id in d.get("cards", []):
		if String(id) == card_id:
			return true
	return false

# --- Relíquias ---

func _build_relics() -> void:
	_counter.text = "%d/%d" % [Stats.seen_count("relics"), CardDB.relics.size()]
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_body.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 8)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(grid)
	var order := {"common": 0, "uncommon": 1, "rare": 2}
	var list: Array = CardDB.relics.values()
	list.sort_custom(func(a, b): return int(order.get(a.get("rarity", "common"), 0)) < int(order.get(b.get("rarity", "common"), 0)))
	for r in list:
		var id := String(r.get("id", ""))
		var seen := Stats.is_seen("relics", id)
		var panel := PanelContainer.new()
		panel.custom_minimum_size = Vector2(0, 86)
		panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var rar := String(r.get("rarity", "common"))
		var border := UiKit.GOLD if rar == "rare" else (Color(0.75, 0.75, 0.85) if rar == "uncommon" else UiKit.BORDER)
		panel.add_theme_stylebox_override("panel", UiKit.flat(UiKit.BG_LIGHT if seen else UiKit.BG, 10, border if seen else UiKit.BORDER, 2, 8))
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 2)
		panel.add_child(col)
		if seen:
			col.add_child(UiKit.label("★ " + tr(String(r.get("name", id))) + "  ·  " + tr(CardZoom.RARITY_NAMES.get(rar, "Comum")), 17, UiKit.GOLD))
			col.add_child(UiKit.label(tr(String(r.get("text", ""))), 14, Color.WHITE, true))
		else:
			col.add_child(UiKit.label("???  ·  " + tr(CardZoom.RARITY_NAMES.get(rar, "Comum")), 17, UiKit.TEXT_DIM))
			col.add_child(UiKit.label(tr("Ainda não descoberta."), 14, UiKit.TEXT_DIM))
		grid.add_child(panel)

# --- Inimigos ---

func _build_enemies() -> void:
	_counter.text = "%d/%d" % [Stats.seen_count("enemies"), CardDB.enemies.size()]
	_body.add_child(UiKit.label(tr("Bestiário: todos os inimigos e bosses que já enfrentaste. Toca num para ver as regras, a história e quantas vezes o venceste."), 15, UiKit.TEXT_DIM, true))
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_body.add_child(scroll)
	var grid := GridContainer.new()
	grid.name = "Bestiary"
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 8)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(grid)
	# Ordem: inimigos normais, bosses, bosses da História.
	var list: Array = CardDB.enemies.duplicate()
	list.sort_custom(func(a, b): return _enemy_rank(a) < _enemy_rank(b))
	for e in list:
		grid.add_child(_enemy_tile(e))

static func _enemy_rank(e: Dictionary) -> int:
	if bool(e.get("saga", false)):
		return 2
	return 1 if bool(e.get("boss", false)) else 0

static func enemy_tint(id: String) -> Color:
	return Color.from_hsv(fmod(float(abs(id.hash())) / 1000.0, 1.0), 0.55, 0.75)

func _enemy_tile(e: Dictionary) -> Control:
	var id := String(e.get("id", ""))
	var seen := Stats.is_seen("enemies", id)
	var boss := bool(e.get("boss", false))
	var b := Button.new()
	b.name = "Enemy_" + id
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(0, 84)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var st := UiKit.flat(UiKit.BG_LIGHT if seen else UiKit.BG, 10, UiKit.GOLD if (seen and boss) else UiKit.BORDER, 2, 8)
	b.add_theme_stylebox_override("normal", st)
	b.add_theme_stylebox_override("hover", st)
	b.add_theme_stylebox_override("pressed", UiKit.flat(UiKit.BG_LIGHT.lightened(0.1), 10, UiKit.GOLD, 2, 8))
	b.add_theme_stylebox_override("disabled", st)
	b.disabled = not seen
	var row := HBoxContainer.new()
	row.set_anchors_preset(Control.PRESET_FULL_RECT)
	row.offset_left = 10
	row.offset_right = -10
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 10)
	b.add_child(row)
	if seen:
		var portrait := EnemyPortrait.new()
		portrait.custom_minimum_size = Vector2(64, 64)
		portrait.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		portrait.mouse_filter = Control.MOUSE_FILTER_IGNORE
		portrait.archetype = String(e.get("portrait", "brute"))
		portrait.tint = enemy_tint(id)
		portrait.boss = boss
		portrait.breathing = false
		portrait.art_id = id
		row.add_child(portrait)
	else:
		var q := UiKit.label("?", 30, UiKit.TEXT_DIM)
		q.custom_minimum_size = Vector2(64, 64)
		q.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		q.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(q)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_theme_constant_override("separation", 2)
	row.add_child(col)
	if seen:
		var wins := Stats.defeated_count(id)
		var name_l := UiKit.label(tr(String(e.get("name", id))), 17, UiKit.GOLD if boss else Color.WHITE)
		name_l.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		col.add_child(name_l)
		var kind := _enemy_kind(e)
		col.add_child(UiKit.label("%s  ·  %s %d  ·  %s" % [tr(kind), tr("ataque"), int(e.get("attack", 0)), tr("vencido %d×") % wins], 14, UiKit.TEXT_DIM))
	else:
		col.add_child(UiKit.label("???", 17, UiKit.TEXT_DIM))
		col.add_child(UiKit.label(tr("Ainda não enfrentado."), 14, UiKit.TEXT_DIM))
	b.pressed.connect(func(): Sfx.select(); _show_enemy(e))
	return b

static func _enemy_kind(e: Dictionary) -> String:
	if bool(e.get("saga", false)):
		return "Boss da História"
	if bool(e.get("final", false)):
		return "Boss final"
	if bool(e.get("boss", false)):
		return "Boss"
	return "Inimigo"

## Página do Bestiário: retrato grande, regras, história e vezes vencido.
func _show_enemy(e: Dictionary) -> void:
	if SceneRouter.has_overlay():
		return
	var id := String(e.get("id", ""))
	var o := Control.new()
	o.name = "BestiaryPage"
	o.set_anchors_preset(Control.PRESET_FULL_RECT)
	o.mouse_filter = Control.MOUSE_FILTER_STOP
	o.add_child(UiKit.dim(0.82))
	SceneRouter.show_overlay(o)
	var panel := UiKit.centered_panel(o, 860, UiKit.BG, UiKit.GOLD if bool(e.get("boss", false)) else UiKit.BORDER)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 22)
	panel.add_child(row)
	var portrait := EnemyPortrait.new()
	portrait.custom_minimum_size = Vector2(170, 170)
	portrait.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	portrait.archetype = String(e.get("portrait", "brute"))
	portrait.tint = enemy_tint(id)
	portrait.boss = bool(e.get("boss", false))
	portrait.art_id = id
	row.add_child(portrait)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 8)
	row.add_child(col)
	col.add_child(UiKit.label(tr(String(e.get("name", id))), 28, UiKit.GOLD))
	var facts: Array[String] = [tr(_enemy_kind(e)), tr("ataque %d") % int(e.get("attack", 0))]
	var hp_mult := float(e.get("hp_mult", 1.0))
	if not is_equal_approx(hp_mult, 1.0):
		facts.append(tr("vida ×%s") % String.num(hp_mult, 2))
	if not bool(e.get("boss", false)):
		facts.append(tr("a partir do ante %d") % int(e.get("min_ante", 1)))
	col.add_child(UiKit.label("  ·  ".join(PackedStringArray(facts)), 16, UiKit.TEXT_DIM, true))
	col.add_child(UiKit.label(tr(String(e.get("text", ""))), 18, Color.WHITE, true))
	if String(e.get("lore", "")) != "":
		col.add_child(UiKit.label("“" + tr(String(e.get("lore", ""))) + "”", 17, Color(0.82, 0.78, 0.95), true))
	var lines: Dictionary = e.get("lines", {}) if e.get("lines") is Dictionary else {}
	if String(lines.get("intro", "")) != "":
		col.add_child(UiKit.label(tr("Diz: «%s»") % tr(String(lines["intro"])), 15, UiKit.TEXT_DIM, true))
	col.add_child(UiKit.label(tr("Vencido %d vezes.") % Stats.defeated_count(id), 17, Color(0.6, 0.95, 0.65)))
	var close := UiKit.button(tr("FECHAR"), 54, 20, UiKit.PRIMARY)
	close.pressed.connect(func(): Sfx.select(); o.queue_free())
	col.add_child(close)
	UiKit.pop_in(panel)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree():
		var top := SceneRouter.top_overlay()
		if top != null and top.name == "BestiaryPage":
			top.queue_free()   # o "retroceder" fecha a página do Bestiário
		elif not SceneRouter.has_overlay():
			SceneRouter.go("main")

func _exit_tree() -> void:
	CardView.art_on = true
