extends Control
## Ecrã de fim de run (vitória ou derrota): regista o progresso e mostra desbloqueios.
## 0.10.0: resumo da run — carta MVP, relíquia que mais deu, maior golpe e dano por ante — e o
## final do capítulo da História / a medalha do Desafio.

@onready var title: Label = %Title
@onready var detail: Label = %Detail
@onready var unlocks: Label = %Unlocks

func _ready() -> void:
	var won := GameState.player_hp > 0 and GameState.ante >= GameState.max_ante and GameState.last_victory
	var draft := GameState.mode == "draft"
	var reached := GameState.ante
	var endless_end := GameState.endless and not won
	var saga := GameState.saga_id
	var challenge := GameState.challenge_id
	var new_unlocks := GameState.record_run_end(reached, won)
	GameState.clear_saved_run()
	_build_summary()
	if endless_end:
		title.text = tr("FIM DO INFINITO")
		title.add_theme_color_override("font_color", Color(0.98, 0.75, 0.25))
	else:
		title.text = tr("VITÓRIA") if won else tr("DERROTA")
		title.add_theme_color_override("font_color", Color(0.5, 0.95, 0.6) if won else Color(0.95, 0.45, 0.45))
	var deck_name: String = tr(GameState.deck_def.get("name", ""))
	if won:
		detail.text = tr("%s venceu os %d antes.\nRelíquias: %d  ·  Ouro: %d  ·  Seed: %d") % [deck_name, GameState.max_ante, GameState.relic_ids.size(), GameState.gold, GameState.seed_value]
		if GameState.stake > 1:
			detail.text += "  ·  " + tr("Selo %d") % GameState.stake
		%Endless.visible = not draft
		%Endless.pressed.connect(_on_endless)
	elif endless_end:
		detail.text = tr("%s chegou ao ante %d no modo infinito.\nRelíquias: %d  ·  Baralho: %d cartas  ·  Seed: %d") % [deck_name, reached, GameState.relic_ids.size(), GameState.deck.size(), GameState.seed_value]
	else:
		detail.text = tr("%s caiu no ante %d.\nRelíquias: %d  ·  Baralho: %d cartas  ·  Seed: %d") % [deck_name, reached, GameState.relic_ids.size(), GameState.deck.size(), GameState.seed_value]
	if saga != "":
		var ch := CardDB.get_saga_chapter(saga)
		unlocks.text = (tr(String(ch.get("outro", ""))) if won else tr("O capítulo fica por acabar. Tenta outra vez — a história espera por ti.")) + ("\n" + tr("Desbloqueaste: ") + ", ".join(PackedStringArray(new_unlocks)) if not new_unlocks.is_empty() else "")
		unlocks.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		unlocks.custom_minimum_size.x = 900
		(%Campaign as Button).text = tr("HISTÓRIA")
		%Endless.visible = false
	elif challenge != "":
		var cdef := CardDB.get_challenge(challenge)
		unlocks.text = (tr("Desafio vencido: %s — medalha ganha!") if won else tr("Desafio falhado: %s.")) % tr(String(cdef.get("name", "")))
		(%Campaign as Button).text = tr("DESAFIOS")
		%Endless.visible = false
	elif draft:
		unlocks.text = tr("Arena Draft — não conta para a campanha.")
	elif GameState.free_mode:
		unlocks.text = tr("Modo Livre — não conta para a campanha.")
	elif new_unlocks.is_empty():
		var best := GameState.best_ante(String(GameState.deck_def.get("id", "")))
		unlocks.text = tr("Melhor ante com este baralho: %d.  Chega ao ante 4 para desbloquear o capítulo seguinte.") % best if best < 4 else tr("Melhor ante com este baralho: %d.") % best
	else:
		var names: Array[String] = []
		for n in new_unlocks:
			names.append(tr(n))
		unlocks.text = tr("Desbloqueaste: ") + ", ".join(PackedStringArray(names))
	if GameState.last_talent_points > 0:
		detail.text += "\n" + tr("Talentos: +%d pontos (Coleção → Talentos).") % GameState.last_talent_points
	var back_scene := "saga" if saga != "" else ("challenges" if challenge != "" else "campaign")
	%Campaign.pressed.connect(func(): Sfx.select(); SceneRouter.go(back_scene))
	%Stats.pressed.connect(func(): Sfx.select(); SceneRouter.go("stats"))
	%Menu.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	_animate_in(won)

## Resumo da run: carta MVP, relíquia que mais deu, maior golpe e o dano de cada ante.
func _build_summary() -> void:
	var log_: Dictionary = GameState.run_log
	if log_.is_empty():
		return
	var box := HBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 28)
	var vbox: VBoxContainer = title.get_parent()
	vbox.add_child(box)
	vbox.move_child(box, unlocks.get_index() + 1)
	var mvp := GameState.top_of(log_.get("card_dmg", {}))
	if not mvp.is_empty() and CardDB.get_card(String(mvp["id"])) != null:
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 4)
		box.add_child(col)
		var cap := UiKit.label(tr("Carta MVP"), 16, UiKit.GOLD)
		cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(cap)
		var view: CardView = preload("res://scenes/ui/CardView.tscn").instantiate()
		col.add_child(view)
		view.setup(CardDB.new_instance(String(mvp["id"])))
		view.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		var v := UiKit.label(tr("%s de dano") % Cascade.fmt_int(int(mvp["damage"])), 15, UiKit.TEXT_DIM)
		v.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(v)
	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 8)
	box.add_child(right)
	var top_relic := GameState.top_of(log_.get("relic_dmg", {}))
	if not top_relic.is_empty() and CardDB.relics.has(String(top_relic["id"])):
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		right.add_child(row)
		var medal: RelicView = preload("res://scenes/ui/RelicView.tscn").instantiate()
		row.add_child(medal)
		medal.setup(String(top_relic["id"]))
		var rl := UiKit.label(tr("Relíquia que mais deu: %s") % tr(String(CardDB.relics[String(top_relic["id"])].get("name", ""))) + "\n" + tr("%s de dano") % Cascade.fmt_int(int(top_relic["damage"])), 16, Color.WHITE)
		rl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(rl)
	var best_row := HBoxContainer.new()
	best_row.add_theme_constant_override("separation", 12)
	right.add_child(best_row)
	var best_l := UiKit.label(tr("Maior golpe: %s") % Cascade.fmt_int(int(log_.get("best_hit", 0))), 16, UiKit.TEXT_DIM)
	best_l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	best_row.add_child(best_l)
	if log_.get("best_cascade") is Dictionary and not (log_["best_cascade"].get("steps", []) as Array).is_empty():
		var replay := UiKit.button(tr("▶ REVER O MAIOR GOLPE"), 48, 15, UiKit.BG_LIGHT, UiKit.GOLD)
		replay.name = "Replay"
		replay.pressed.connect(func():
			if not SceneRouter.has_overlay():
				Sfx.select()
				CascadeReplay.open(log_["best_cascade"]))
		best_row.add_child(replay)
	right.add_child(UiKit.label(tr("Dano por ante"), 16, UiKit.GOLD))
	var by_ante: Dictionary = log_.get("damage_by_ante", {})
	var last := 0
	for k in by_ante:
		last = maxi(last, int(k))
	var vals: Array = []
	for a in range(1, last + 1):
		vals.append(int(by_ante.get(str(a), 0)))
	var chart := DamageChart.new()
	chart.set_values(vals)
	right.add_child(chart)

## Continuar para lá do ante 8: a vitória já ficou registada; a vida subir com o ante.
func _on_endless() -> void:
	Sfx.boom()
	GameState.endless = true
	GameState.last_victory = false
	GameState.next_ante()
	# Entrar no infinito abre o Baú de Espólio do boss final.
	GameState.prepare_loot()
	GameState.save_run({}, "loot")
	SceneRouter.go("loot")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")

func _animate_in(won: bool) -> void:
	title.pivot_offset = title.size / 2.0
	title.scale = Vector2(0.3, 0.3)
	title.modulate.a = 0.0
	var tw := create_tween().set_parallel(true)
	tw.tween_property(title, "scale", Vector2.ONE, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(title, "modulate:a", 1.0, 0.3)
	if won:
		Sfx.boom()
	else:
		Sfx.hit()
