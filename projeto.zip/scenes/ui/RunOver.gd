extends Control
## Ecrã de fim de run (vitória ou derrota): regista o progresso e mostra desbloqueios.
## 0.10.0: resumo da run — carta MVP, relíquia que mais deu, maior golpe e dano por ante — e o
## final do capítulo da História / a medalha do Desafio.
## 0.12.0: REVANCHE (a mesma run outra vez) e os botões em duas filas.
## 0.15.0: PORQUE PERDI? — depois de uma derrota, 2 a 3 dicas a partir do que aconteceu na batalha perdida.
## 0.17.0: o fim da Torre do Arquimago (o andar e o recorde) e da Corrida de Bosses (a medalha).

@onready var title: Label = %Title
@onready var detail: Label = %Detail
@onready var unlocks: Label = %Unlocks

var _rematch: Dictionary = {}
var share_summary: Dictionary = {}   # 0.12.0: para a imagem de PARTILHAR
var _loss: Dictionary = {}           # 0.15.0: BattleManager.loss_report() da batalha perdida ({} = vitória)
var _train: Dictionary = {}          # 0.19.0 (200): o inimigo e o ante da batalha perdida, para a treinar já

func _ready() -> void:
	# 0.13.0: uma batalha fora da run (enigma, lição, treino) nunca acaba aqui — este ecrã apaga a run
	# do espaço atual. Volta ao sítio dela sem tocar nos jogos guardados nem nas estatísticas.
	if GameState.puzzle_id != "":
		var home := GameState.side_battle_home()
		GameState.puzzle_id = ""
		SceneRouter.go.call_deferred(home)
		return
	_rematch = GameState.rematch_info()
	var won := GameState.player_hp > 0 and GameState.ante >= GameState.max_ante and GameState.last_victory
	_loss = {} if won else GameState.last_loss.duplicate()
	if not won and GameState.current_enemy_id != "" and not GameState.deck.is_empty():
		_train = {"enemy": GameState.current_enemy_id, "ante": GameState.ante}
	var draft := GameState.mode == "draft"
	var reached := GameState.ante
	var endless_end := GameState.endless and not won
	var saga := GameState.saga_id
	var challenge := GameState.challenge_id
	share_summary = RunShare.summary_from_state(won, endless_end)
	add_to_group(SceneRouter.HOLD_GROUP)   # 0.20.0 (C11): as conquistas do fim da run também vão para «Também ganhaste:»
	var new_unlocks := GameState.record_run_end(reached, won)
	remove_from_group(SceneRouter.HOLD_GROUP)
	GameState.clear_saved_run()
	GameState.slot_confirmed = true   # o espaço ficou livre: uma run nova a seguir fica nele
	_build_summary()
	if GameState.mode in ["tower", "rush"]:
		_side_mode_texts(won)
		_also_won()
		_lead_with_cause()
		_fit_layout()
		_arrange_buttons()
		_shrink_to_fit.call_deferred()
		_animate_in(won)
		return
	if endless_end:
		title.text = tr("FIM DO INFINITO")
		title.add_theme_color_override("font_color", Color(0.98, 0.75, 0.25))
	else:
		title.text = tr("VITÓRIA") if won else tr("DERROTA")
		title.add_theme_color_override("font_color", Color(0.5, 0.95, 0.6) if won else Color(0.95, 0.45, 0.45))
	var deck_name: String = tr(GameState.deck_def.get("name", ""))
	if won:
		detail.text = tr("%s venceu os %d antes.\nRelíquias: %d  ·  Ouro: %d  ·  Seed: %d") % [deck_name, GameState.max_ante, GameState.relic_ids.size(), GameState.gold, GameState.seed_value]
		if GameState.stake > 1:
			detail.text += "  ·  " + tr("Selo %d") % GameState.stake
		%Endless.visible = not draft
		%Endless.pressed.connect(_on_endless)
	elif endless_end:
		detail.text = tr("%s chegou ao ante %d no modo infinito.\nRelíquias: %d  ·  Baralho: %d cartas  ·  Seed: %d") % [deck_name, reached, GameState.relic_ids.size(), GameState.deck.size(), GameState.seed_value]
	else:
		detail.text = tr("%s caiu no ante %d.\nRelíquias: %d  ·  Baralho: %d cartas  ·  Seed: %d") % [deck_name, reached, GameState.relic_ids.size(), GameState.deck.size(), GameState.seed_value]
	_lead_with_cause()
	if saga != "":
		var ch := CardDB.get_saga_chapter(saga)
		unlocks.text = (tr(String(ch.get("outro", ""))) if won else tr("O capítulo fica por acabar. Tenta outra vez — a história espera por ti.")) + ("\n" + tr("Desbloqueaste: ") + ", ".join(PackedStringArray(new_unlocks)) if not new_unlocks.is_empty() else "")
		if won and String(ch.get("epilogue", "")) != "":   # 0.13.0: o fim do Livro III
			_show_epilogue.call_deferred(tr(String(ch["epilogue"])))
		unlocks.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		unlocks.custom_minimum_size.x = 900
		(%Campaign as Button).text = tr("HISTÓRIA")
		%Endless.visible = false
	elif challenge != "":
		var cdef := CardDB.get_challenge(challenge)
		unlocks.text = (tr("Desafio vencido: %s — medalha ganha!") if won else tr("Desafio falhado: %s.")) % tr(String(cdef.get("name", "")))
		if won:   # 0.13.0: estrelas
			var st := GameState.last_stars
			unlocks.text += "\n" + "★".repeat(st) + "☆".repeat(3 - st) + "  " + tr("%d de 3 estrelas: vencer · metade da vida ou mais · boss final sem despertar.") % st
		(%Campaign as Button).text = tr("DESAFIOS")
		%Endless.visible = false
	elif draft:
		unlocks.text = tr("Arena Draft — não conta para a campanha.")
	elif GameState.mode == "quick":
		unlocks.text = tr("Run Rápida — não conta para a campanha.")
		%Endless.visible = false
		(%Campaign as Button).text = tr("RUN RÁPIDA")   # 0.14.0: volta ao ecrã da Run Rápida
	elif GameState.free_mode:
		unlocks.text = tr("Modo Livre — não conta para a campanha.")
	elif new_unlocks.is_empty():
		var best := GameState.best_ante(String(GameState.deck_def.get("id", "")))
		unlocks.text = tr("Melhor ante com este baralho: %d.  Chega ao ante 4 para desbloquear o capítulo seguinte.") % best if best < 4 else tr("Melhor ante com este baralho: %d.") % best
	else:
		var names: Array[String] = []
		for n in new_unlocks:
			names.append(tr(n))
		unlocks.text = tr("Desbloqueaste: ") + ", ".join(PackedStringArray(names))
	if GameState.last_talent_points > 0:
		detail.text += "\n" + tr("Talentos: +%d pontos (Coleção → Talentos).") % GameState.last_talent_points
		if GameState.last_first_bonus > 0:   # 0.19.0 (89)
			detail.text += "  " + tr("(%d do prémio da 1.ª vez)") % GameState.last_first_bonus
	if GameState.last_fragments > 0:   # 0.19.0 (90)
		detail.text += ("\n" if GameState.last_talent_points <= 0 else "  ·  ") + (tr("+%d fragmento para cosméticos.") if GameState.last_fragments == 1 else tr("+%d fragmentos para cosméticos.")) % GameState.last_fragments
	var back_scene := "saga" if saga != "" else ("challenges" if challenge != "" else ("draft" if draft else "campaign"))
	if draft:
		(%Campaign as Button).text = tr("ARENA DRAFT")
	# 0.14.0: depois de uma Run Rápida, o botão volta à Run Rápida (antes abria a Campanha normal).
	var back_quick := back_scene == "campaign" and GameState.mode == "quick"
	%Campaign.pressed.connect(func():
		Sfx.select()
		MainMenu.return_page = "new"
		if back_quick:
			GameState.launch_mode = "quick"
		SceneRouter.go(back_scene))
	%Stats.pressed.connect(func(): Sfx.select(); SceneRouter.go("stats"))
	%Menu.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	_also_won()
	_fit_layout()
	_arrange_buttons()
	_shrink_to_fit.call_deferred()
	_animate_in(won)

## 0.20.0 (C11): os avisos de progresso retidos na última batalha, numa linha por baixo dos desbloqueios.
## O prémio do capítulo da História dado agora no record_run_end também ficou retido, mas já está em «Desbloqueaste:».
func _also_won() -> void:
	var skip: Array[String] = []
	var rw: Dictionary = CardDB.get_saga_chapter(GameState.saga_id).get("reward", {})
	if not rw.is_empty() and Stats.unlock_label(rw, "%s: %s") in GameState.last_unlocks:
		skip.append("✦ " + Stats.unlock_label(rw, "Desbloqueaste %s: %s"))
	var also := SceneRouter.take_held_notices(3, skip)
	if not also.is_empty():
		unlocks.text += ("\n" if unlocks.text != "" else "") + tr("Também ganhaste:") + " " + "  ·  ".join(PackedStringArray(also))

## 0.17.0: títulos, textos e o botão de voltar da Torre do Arquimago e da Corrida de Bosses.
func _side_mode_texts(won: bool) -> void:
	var deck_name: String = tr(GameState.deck_def.get("name", ""))
	var tower := GameState.mode == "tower"
	%Endless.visible = false
	if tower:
		title.text = tr("FIM DA TORRE")
		title.add_theme_color_override("font_color", Color(0.78, 0.66, 1.0))
		detail.text = tr("%s chegou ao andar %d da Torre do Arquimago.\nRelíquias: %d  ·  Baralho: %d cartas  ·  Seed: %d") % [deck_name, GameState.ante, GameState.relic_ids.size() + GameState.boss_relics.size(), GameState.deck.size(), GameState.seed_value]
		unlocks.text = (tr("NOVO RECORDE: andar %d!") % GameState.ante) if GameState.last_side_record else tr("Recorde: andar %d.") % GameState.tower_best()
		if GameState.last_side_record:
			unlocks.add_theme_color_override("font_color", UiKit.GOLD)
	else:
		var n := GameState.rush_turns.size()
		if won:
			var medal := GameState.rush_medal_for(GameState.rush_avg_turns())
			title.text = tr("CORRIDA COMPLETA")
			title.add_theme_color_override("font_color", Color(0.5, 0.95, 0.6))
			detail.text = tr("%s venceu os %d bosses em %d turnos (média de %s por boss).") % [deck_name, n, GameState.rush_total_turns(), GameState.fmt_dec(GameState.rush_avg_turns())]
			unlocks.text = tr(String({"gold": "Medalha de ouro!", "silver": "Medalha de prata!", "bronze": "Medalha de bronze!"}.get(medal, ""))) \
				+ "  " + tr("Ouro: média até 2,5 turnos · prata: até 3,5.") + ("\n" + tr("É o teu melhor resultado na Corrida.") if GameState.last_side_record else "")
			unlocks.add_theme_color_override("font_color", UiKit.GOLD)
		else:
			title.text = tr("DERROTA")
			title.add_theme_color_override("font_color", Color(0.95, 0.45, 0.45))
			detail.text = tr("%s caiu no boss %d de %d: %s.") % [deck_name, GameState.ante, GameState.max_ante, tr(String(GameState.rush_def(GameState.ante).get("name", "")))]
			unlocks.text = tr("Bosses vencidos nesta Corrida: %d.") % n
	(%Campaign as Button).text = tr("TORRE") if tower else tr("CORRIDA")
	var back_mode := GameState.mode
	%Campaign.pressed.connect(func():
		Sfx.select()
		MainMenu.return_page = "new"
		GameState.launch_mode = back_mode
		SceneRouter.go("campaign"))
	%Stats.pressed.connect(func(): Sfx.select(); SceneRouter.go("stats"))
	%Menu.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))

## 0.12.0: o ecrã ocupa a altura toda (com margens) e encolhe um pouco os textos, para o resumo, as
## duas filas de botões e o título caberem em 720 px de altura.
func _fit_layout() -> void:
	var vb: VBoxContainer = title.get_parent()
	vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	vb.offset_left = 40
	vb.offset_right = -40
	vb.offset_top = 8
	vb.offset_bottom = -24
	vb.add_theme_constant_override("separation", 4)
	title.add_theme_font_size_override("font_size", 64)
	detail.add_theme_font_size_override("font_size", 20)
	unlocks.add_theme_font_size_override("font_size", 19)

## 0.20.0 (B9): com o detalhe comprido (Talentos + prémio da 1.ª vez + fragmentos) mais o resumo, 720 px não chegam
## e a 2.ª fila de botões ficava colada à margem de baixo: letras mais pequenas até caber.
## 0.20.0 (C11): mais um passo, para a linha «Também ganhaste:» por baixo dos desbloqueios.
func _shrink_to_fit() -> void:
	var vb: VBoxContainer = title.get_parent()
	for sizes in [[52, 18, 18, 3], [44, 17, 17, 2], [40, 16, 16, 2]]:
		if vb.get_combined_minimum_size().y <= 720.0 - 32.0:
			return
		title.add_theme_font_size_override("font_size", sizes[0])
		detail.add_theme_font_size_override("font_size", sizes[1])
		unlocks.add_theme_font_size_override("font_size", sizes[2])
		vb.add_theme_constant_override("separation", sizes[3])

## 0.20.0 (B9): depois de uma derrota, o detalhe começa pela causa (a mesma frase do letreiro da batalha).
func _lead_with_cause() -> void:
	var cause := GameState.loss_cause(_loss)
	if cause != "":
		detail.text = cause + ". " + detail.text

## 0.12.0: duas filas — as ações principais (Infinito, Revanche, voltar ao modo) e por baixo as outras.
func _arrange_buttons() -> void:
	var row: HBoxContainer = %Endless.get_parent()
	var row2 := HBoxContainer.new()
	row2.name = "Buttons2"
	row2.alignment = BoxContainer.ALIGNMENT_CENTER
	row2.add_theme_constant_override("separation", 16)
	row.get_parent().add_child(row2)
	row.get_parent().move_child(row2, row.get_index() + 1)
	# PARTILHAR (0.12.0): imagem do resumo + texto copiado.
	var share := UiKit.button(tr("PARTILHAR"), 52, 19, Color(0.16, 0.42, 0.3))
	share.name = "Share"
	share.custom_minimum_size.x = 220
	share.pressed.connect(_on_share)
	row2.add_child(share)
	share.owner = self
	share.unique_name_in_owner = true
	for n in [%Stats, %Menu]:
		var b: Button = n
		row.remove_child(b)
		row2.add_child(b)
		b.custom_minimum_size = Vector2(220, 52)
		b.add_theme_font_size_override("font_size", 19)
	if not loss_tips(_loss).is_empty():   # 0.15.0
		var why := UiKit.button(tr("PORQUE PERDI?"), 64, 24, Color(0.42, 0.2, 0.24))   # 0.20.0 (B9): 1.ª fila, do tamanho do REVANCHE
		why.name = "WhyLost"
		why.custom_minimum_size.x = 250
		why.pressed.connect(_on_why_lost)
		row.add_child(why)
		row.move_child(why, %Endless.get_index() + 1)
		why.owner = self
		why.unique_name_in_owner = true
	if not _rematch.is_empty():
		var again := UiKit.button(tr("REVANCHE"), 64, 24, UiKit.PRIMARY)
		again.name = "Rematch"
		again.custom_minimum_size.x = 250
		again.pressed.connect(_on_rematch)
		row.add_child(again)
		row.move_child(again, %Endless.get_index() + 1)
		again.owner = self
		again.unique_name_in_owner = true
	for b in [%Endless, %Campaign]:
		(b as Button).custom_minimum_size.y = 64
		(b as Button).add_theme_font_size_override("font_size", 24)

## 0.15.0 PORQUE PERDI?: as dicas numa janela.
func _on_why_lost() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	var tips := loss_tips(_loss)
	var body := ""
	for t in tips:
		body += ("\n\n" if body != "" else "") + "• " + t
	var buttons: Array = [[tr("PERCEBI"), null, true]]
	if not _train.is_empty():   # 0.19.0 (200): treinar já contra o mesmo inimigo, com o baralho que tinhas
		buttons.append([tr("TREINAR ESTA BATALHA"), "train"])
	var d := ChoiceDialog.open(tr("PORQUE PERDI?"), body, buttons, Color(1.0, 0.62, 0.55))
	d.chosen.connect(func(v):
		if v == "train":
			train_lost_battle())

## 200: a batalha perdida outra vez, como treino (não conta para a run nem para as estatísticas).
func train_lost_battle() -> void:
	if _train.is_empty():
		return
	GameState.start_enemy_training(String(_train["enemy"]), int(_train["ante"]))
	SceneRouter.go("battle")

## 0.15.0: 2 a 3 dicas a partir do BattleManager.loss_report() da batalha perdida: primeiro o que te derrotou
## (vida ou turnos), depois o que mais pesou — escudo sem Atropelar, rituais do boss, mana por gastar,
## canalizações por usar, criaturas perdidas. Sem nada disso, uma dica geral. [] se não houver relatório.
static func loss_tips(r: Dictionary) -> Array[String]:
	var out: Array[String] = []
	if r.is_empty():
		return out
	var foe := TranslationServer.translate(String(r.get("enemy", "")))
	var pct := int(r.get("hp_left_pct", 0))
	if String(r.get("cause", "")) == "life":
		out.append(TranslationServer.translate("Ficaste sem vida ao fim de %d turno(s), com %s ainda a %d %% da vida. Bloqueia os golpes grandes com criaturas que aguentam e cura-te no Mercador antes dos bosses.") % [int(r.get("turns", 0)), foe, pct])
	else:
		out.append(TranslationServer.translate("Os turnos acabaram com %s ainda a %d %% da vida: faltou dano por ataque. Junta mais criaturas antes de atacar e procura formações e relíquias que dão Mult.") % [foe, pct])
	var extra: Array[String] = []
	if bool(r.get("shield", false)) and int(r.get("shield_absorbed", 0)) > 0 and int(r.get("trample_attacks", 0)) == 0:
		extra.append(TranslationServer.translate("%s tinha escudo e travou %s de dano. Cada criatura com Atropelar no ataque corta o escudo a meio.") % [foe, Cascade.fmt_int(int(r.get("shield_absorbed", 0)))])
	if int(r.get("rituals_resolved", 0)) > 0:
		extra.append(TranslationServer.translate("O ritual de %s chegou ao fim %d vez(es). Um só golpe de 15 %% da vida máxima do boss interrompe-o.") % [foe, int(r.get("rituals_resolved", 0))])
	if int(r.get("unspent_turns", 0)) > 0:
		extra.append(TranslationServer.translate("Em %d turno(s) acabaste com mana por gastar (%d no total) e cartas na mão que podias jogar. Joga tudo o que puderes antes de ATACAR.") % [int(r.get("unspent_turns", 0)), int(r.get("unspent_mana", 0))])
	if int(r.get("discards_left", 0)) >= 2:
		extra.append(TranslationServer.translate("Ficaram %d canalizações por usar. Canalizar troca uma carta fraca da mão por outra do grimório.") % int(r.get("discards_left", 0)))
	if int(r.get("creatures_died", 0)) >= 3:
		extra.append(TranslationServer.translate("Perdeste %d criaturas. Bloquear só com as que aguentam o golpe guarda Poder para o ataque.") % int(r.get("creatures_died", 0)))
	if extra.is_empty():
		extra.append(TranslationServer.translate("No Mercador, MELHORAR as cartas que mais atacam e comprar relíquias da tua cor ajudam nas batalhas seguintes."))
	for t in extra.slice(0, 2):
		out.append(t)
	return out

var _sharing := false

func _on_share() -> void:
	if _sharing or SceneRouter.has_overlay():
		return
	_sharing = true
	Sfx.select()
	var msg: String = await RunShare.share(self, share_summary)
	SceneRouter.toast(msg, 4.0)
	_sharing = false

## Revanche: a mesma run (modo, baralho, Selo) com outra semente, no mesmo espaço de gravação.
func _on_rematch() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.boom()
	SceneRouter.go(GameState.start_rematch(_rematch))

## Resumo da run: carta MVP, relíquia que mais deu, maior golpe e o dano de cada ante.
func _build_summary() -> void:
	var log_: Dictionary = GameState.run_log
	if log_.is_empty():
		return
	var box := HBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 28)
	var vbox: VBoxContainer = title.get_parent()
	vbox.add_child(box)
	vbox.move_child(box, unlocks.get_index() + 1)
	var mvp := GameState.top_of(log_.get("card_dmg", {}))
	if not mvp.is_empty() and CardDB.get_card(String(mvp["id"])) != null:
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 4)
		box.add_child(col)
		var cap := UiKit.label(tr("Carta MVP"), 16, UiKit.GOLD)
		cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(cap)
		var view: CardView = preload("res://scenes/ui/CardView.tscn").instantiate()
		col.add_child(view)
		view.setup(CardDB.new_instance(String(mvp["id"])))
		view.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		var v := UiKit.label(tr("%s de dano") % Cascade.fmt_int(int(mvp["damage"])), 15, UiKit.TEXT_DIM)
		v.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(v)
	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 8)
	box.add_child(right)
	var top_relic := GameState.top_of(log_.get("relic_dmg", {}))
	if not top_relic.is_empty() and CardDB.relics.has(String(top_relic["id"])):
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		right.add_child(row)
		var medal: RelicView = preload("res://scenes/ui/RelicView.tscn").instantiate()
		row.add_child(medal)
		medal.setup(String(top_relic["id"]))
		var rl := UiKit.label(tr("Relíquia que mais deu: %s") % tr(String(CardDB.relics[String(top_relic["id"])].get("name", ""))) + "\n" + tr("%s de dano") % Cascade.fmt_int(int(top_relic["damage"])), 16, Color.WHITE)
		rl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(rl)
	var best_row := HBoxContainer.new()
	best_row.add_theme_constant_override("separation", 12)
	right.add_child(best_row)
	var best_l := UiKit.label(tr("Maior golpe: %s") % Cascade.fmt_int(int(log_.get("best_hit", 0))), 16, UiKit.TEXT_DIM)
	best_l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	best_row.add_child(best_l)
	if log_.get("best_cascade") is Dictionary and not (log_["best_cascade"].get("steps", []) as Array).is_empty():
		var replay := UiKit.button(tr("▶ REVER O MAIOR GOLPE"), 48, 15, UiKit.BG_LIGHT, UiKit.GOLD)
		replay.name = "Replay"
		replay.pressed.connect(func():
			if not SceneRouter.has_overlay():
				Sfx.select()
				CascadeReplay.open(log_["best_cascade"]))
		best_row.add_child(replay)
	var chart_title := tr("Dano por andar") if GameState.mode == "tower" else (tr("Dano por boss") if GameState.mode == "rush" else tr("Dano por ante"))
	# 0.19.0 (72, 73): ao lado do dano, o ouro de cada ante e ONDE GASTEI.
	var charts := HBoxContainer.new()
	charts.name = "Charts"
	charts.add_theme_constant_override("separation", 22)
	right.add_child(charts)
	var dmg_col := VBoxContainer.new()
	dmg_col.add_theme_constant_override("separation", 8)
	charts.add_child(dmg_col)
	dmg_col.add_child(UiKit.label(chart_title, 16, UiKit.GOLD))
	var by_ante: Dictionary = log_.get("damage_by_ante", {})
	var last := 0
	for k in by_ante:
		last = maxi(last, int(k))
	var vals: Array = []
	for a in range(1, last + 1):
		vals.append(int(by_ante.get(str(a), 0)))
	var chart := DamageChart.new()
	chart.set_values(vals)
	dmg_col.add_child(chart)
	var rows := Economy.gold_rows(log_)
	if not rows.is_empty():
		var gold_col := VBoxContainer.new()
		gold_col.name = "GoldCol"
		gold_col.add_theme_constant_override("separation", 4)
		charts.add_child(gold_col)
		var head := HBoxContainer.new()
		head.add_theme_constant_override("separation", 10)
		gold_col.add_child(head)
		var gl := UiKit.label(tr("Ouro por ante"), 16, UiKit.COIN)
		gl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		gl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		head.add_child(gl)
		var where := UiKit.button(tr("ONDE GASTEI"), 40, 14, UiKit.BG_LIGHT, UiKit.COIN)
		where.name = "WhereSpent"
		where.pressed.connect(_on_where_spent)
		head.add_child(where)
		var gc := GoldChart.new()
		gc.name = "GoldChart"
		gc.custom_minimum_size = Vector2(320, 134)
		gc.set_rows(rows)
		gold_col.add_child(gc)

## 0.19.0 (73): onde foi o ouro (por categoria, do maior para o menor) e a compra que mais rendeu.
func _on_where_spent() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.select()
	ChoiceDialog.open(tr("ONDE GASTEI"), where_spent_text(GameState.run_log), [[tr("FECHAR"), null, true]], UiKit.COIN)

static func where_spent_text(log_: Dictionary) -> String:
	var lines: Array[String] = []
	var tin := 0
	var tout := 0
	var tint := 0
	var tsold := 0
	for r in Economy.gold_rows(log_):
		tin += int(r["in"])
		tout += int(r["out"])
		tint += int(r["interest"])
		tsold += int(r["sold"])
	lines.append(TranslationServer.translate("Ganhaste %d ouro (juros %d, vendas %d) e gastaste %d.") % [tin, tint, tsold, tout])
	var sp := Economy.spent_lines(log_)
	if not sp.is_empty():
		lines.append("• " + "\n• ".join(PackedStringArray(sp)))
	var best := Economy.best_purchase(log_)
	if not best.is_empty():
		var nm := ""
		if String(best["k"]) == "card":
			var cd := CardDB.get_card(String(best["id"]))
			nm = cd.display_name() if cd != null else String(best["id"])
		else:
			nm = TranslationServer.translate(String(CardDB.relics.get(String(best["id"]), {}).get("name", best["id"])))
		lines.append(TranslationServer.translate("A compra que mais rendeu: %s — %d ouro, %s de dano.") % [nm, int(best["p"]), Cascade.fmt_int(int(best["dmg"]))])
	return "\n\n".join(PackedStringArray(lines))

## Continuar para lá do ante 8: a vitória já ficou registada; a vida subir com o ante.
func _on_endless() -> void:
	Sfx.boom()
	GameState.endless = true
	GameState.last_victory = false
	GameState.next_ante()
	# Entrar no infinito abre o Baú de Espólio do boss final.
	GameState.prepare_loot()
	GameState.save_run({}, "loot")
	SceneRouter.go("loot")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")

func _animate_in(won: bool) -> void:
	title.pivot_offset = title.size / 2.0
	title.scale = Vector2(0.3, 0.3)
	title.modulate.a = 0.0
	var tw := create_tween().set_parallel(true)
	tw.tween_property(title, "scale", Vector2.ONE, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(title, "modulate:a", 1.0, 0.3)
	if won:
		Sfx.victory()
	else:
		Sfx.defeat()

## 0.13.0: epílogo do Livro III da História (por cima do ecrã do fim, com confetes).
func _show_epilogue(text: String) -> void:
	if not is_inside_tree():
		return
	CelebrationFx.play(self, get_viewport_rect(), "confetti")
	Sfx.level_up()
	ChoiceDialog.open(tr("EPÍLOGO"), text, [[tr("FIM"), null, true]])
