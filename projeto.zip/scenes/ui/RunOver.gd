extends Control
## Ecrã de fim de run (vitória ou derrota): regista o progresso e mostra desbloqueios.
## 0.10.0: resumo da run — carta MVP, relíquia que mais deu, maior golpe e dano por ante — e o
## final do capítulo da História / a medalha do Desafio.
## 0.12.0: REVANCHE (a mesma run outra vez) e os botões em duas filas.

@onready var title: Label = %Title
@onready var detail: Label = %Detail
@onready var unlocks: Label = %Unlocks

var _rematch: Dictionary = {}
var share_summary: Dictionary = {}   # 0.12.0: para a imagem de PARTILHAR

func _ready() -> void:
	# 0.13.0: uma batalha fora da run (enigma, lição, treino) nunca acaba aqui — este ecrã apaga a run
	# do espaço atual. Volta ao sítio dela sem tocar nos jogos guardados nem nas estatísticas.
	if GameState.puzzle_id != "":
		var home := GameState.side_battle_home()
		GameState.puzzle_id = ""
		SceneRouter.go.call_deferred(home)
		return
	_rematch = GameState.rematch_info()
	var won := GameState.player_hp > 0 and GameState.ante >= GameState.max_ante and GameState.last_victory
	var draft := GameState.mode == "draft"
	var reached := GameState.ante
	var endless_end := GameState.endless and not won
	var saga := GameState.saga_id
	var challenge := GameState.challenge_id
	share_summary = RunShare.summary_from_state(won, endless_end)
	var new_unlocks := GameState.record_run_end(reached, won)
	GameState.clear_saved_run()
	GameState.slot_confirmed = true   # o espaço ficou livre: uma run nova a seguir fica nele
	_build_summary()
	if endless_end:
		title.text = tr("FIM DO INFINITO")
		title.add_theme_color_override("font_color", Color(0.98, 0.75, 0.25))
	else:
		title.text = tr("VITÓRIA") if won else tr("DERROTA")
		title.add_theme_color_override("font_color", Color(0.5, 0.95, 0.6) if won else Color(0.95, 0.45, 0.45))
	var deck_name: String = tr(GameState.deck_def.get("name", ""))
	if won:
		detail.text = tr("%s venceu os %d antes.\nRelíquias: %d  ·  Ouro: %d  ·  Seed: %d") % [deck_name, GameState.max_ante, GameState.relic_ids.size(), GameState.gold, GameState.seed_value]
		if GameState.stake > 1:
			detail.text += "  ·  " + tr("Selo %d") % GameState.stake
		%Endless.visible = not draft
		%Endless.pressed.connect(_on_endless)
	elif endless_end:
		detail.text = tr("%s chegou ao ante %d no modo infinito.\nRelíquias: %d  ·  Baralho: %d cartas  ·  Seed: %d") % [deck_name, reached, GameState.relic_ids.size(), GameState.deck.size(), GameState.seed_value]
	else:
		detail.text = tr("%s caiu no ante %d.\nRelíquias: %d  ·  Baralho: %d cartas  ·  Seed: %d") % [deck_name, reached, GameState.relic_ids.size(), GameState.deck.size(), GameState.seed_value]
	if saga != "":
		var ch := CardDB.get_saga_chapter(saga)
		unlocks.text = (tr(String(ch.get("outro", ""))) if won else tr("O capítulo fica por acabar. Tenta outra vez — a história espera por ti.")) + ("\n" + tr("Desbloqueaste: ") + ", ".join(PackedStringArray(new_unlocks)) if not new_unlocks.is_empty() else "")
		if won and String(ch.get("epilogue", "")) != "":   # 0.13.0: o fim do Livro III
			_show_epilogue.call_deferred(tr(String(ch["epilogue"])))
		unlocks.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		unlocks.custom_minimum_size.x = 900
		(%Campaign as Button).text = tr("HISTÓRIA")
		%Endless.visible = false
	elif challenge != "":
		var cdef := CardDB.get_challenge(challenge)
		unlocks.text = (tr("Desafio vencido: %s — medalha ganha!") if won else tr("Desafio falhado: %s.")) % tr(String(cdef.get("name", "")))
		if won:   # 0.13.0: estrelas
			var st := GameState.last_stars
			unlocks.text += "\n" + "★".repeat(st) + "☆".repeat(3 - st) + "  " + tr("%d de 3 estrelas: vencer · metade da vida ou mais · boss final sem despertar.") % st
		(%Campaign as Button).text = tr("DESAFIOS")
		%Endless.visible = false
	elif draft:
		unlocks.text = tr("Arena Draft — não conta para a campanha.")
	elif GameState.mode == "quick":
		unlocks.text = tr("Run Rápida — não conta para a campanha.")
		%Endless.visible = false
	elif GameState.free_mode:
		unlocks.text = tr("Modo Livre — não conta para a campanha.")
	elif new_unlocks.is_empty():
		var best := GameState.best_ante(String(GameState.deck_def.get("id", "")))
		unlocks.text = tr("Melhor ante com este baralho: %d.  Chega ao ante 4 para desbloquear o capítulo seguinte.") % best if best < 4 else tr("Melhor ante com este baralho: %d.") % best
	else:
		var names: Array[String] = []
		for n in new_unlocks:
			names.append(tr(n))
		unlocks.text = tr("Desbloqueaste: ") + ", ".join(PackedStringArray(names))
	if GameState.last_talent_points > 0:
		detail.text += "\n" + tr("Talentos: +%d pontos (Coleção → Talentos).") % GameState.last_talent_points
	var back_scene := "saga" if saga != "" else ("challenges" if challenge != "" else ("draft" if draft else "campaign"))
	if draft:
		(%Campaign as Button).text = tr("ARENA DRAFT")
	%Campaign.pressed.connect(func(): Sfx.select(); MainMenu.return_page = "new"; SceneRouter.go(back_scene))
	%Stats.pressed.connect(func(): Sfx.select(); SceneRouter.go("stats"))
	%Menu.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	_fit_layout()
	_arrange_buttons()
	_animate_in(won)

## 0.12.0: o ecrã ocupa a altura toda (com margens) e encolhe um pouco os textos, para o resumo, as
## duas filas de botões e o título caberem em 720 px de altura.
func _fit_layout() -> void:
	var vb: VBoxContainer = title.get_parent()
	vb.set_anchors_preset(Control.PRESET_FULL_RECT)
	vb.offset_left = 40
	vb.offset_right = -40
	vb.offset_top = 8
	vb.offset_bottom = -24
	vb.add_theme_constant_override("separation", 10)
	title.add_theme_font_size_override("font_size", 64)
	detail.add_theme_font_size_override("font_size", 20)
	unlocks.add_theme_font_size_override("font_size", 19)

## 0.12.0: duas filas — as ações principais (Infinito, Revanche, voltar ao modo) e por baixo as outras.
func _arrange_buttons() -> void:
	var row: HBoxContainer = %Endless.get_parent()
	var row2 := HBoxContainer.new()
	row2.name = "Buttons2"
	row2.alignment = BoxContainer.ALIGNMENT_CENTER
	row2.add_theme_constant_override("separation", 16)
	row.get_parent().add_child(row2)
	row.get_parent().move_child(row2, row.get_index() + 1)
	# PARTILHAR (0.12.0): imagem do resumo + texto copiado.
	var share := UiKit.button(tr("PARTILHAR"), 52, 19, Color(0.16, 0.42, 0.3))
	share.name = "Share"
	share.custom_minimum_size.x = 220
	share.pressed.connect(_on_share)
	row2.add_child(share)
	share.owner = self
	share.unique_name_in_owner = true
	for n in [%Stats, %Menu]:
		var b: Button = n
		row.remove_child(b)
		row2.add_child(b)
		b.custom_minimum_size = Vector2(220, 52)
		b.add_theme_font_size_override("font_size", 19)
	if not _rematch.is_empty():
		var again := UiKit.button(tr("REVANCHE"), 64, 24, UiKit.PRIMARY)
		again.name = "Rematch"
		again.custom_minimum_size.x = 250
		again.pressed.connect(_on_rematch)
		row.add_child(again)
		row.move_child(again, %Endless.get_index() + 1)
		again.owner = self
		again.unique_name_in_owner = true
	for b in [%Endless, %Campaign]:
		(b as Button).custom_minimum_size.y = 64
		(b as Button).add_theme_font_size_override("font_size", 24)

var _sharing := false

func _on_share() -> void:
	if _sharing or SceneRouter.has_overlay():
		return
	_sharing = true
	Sfx.select()
	var msg: String = await RunShare.share(self, share_summary)
	SceneRouter.toast(msg, 4.0)
	_sharing = false

## Revanche: a mesma run (modo, baralho, Selo) com outra semente, no mesmo espaço de gravação.
func _on_rematch() -> void:
	if SceneRouter.has_overlay():
		return
	Sfx.boom()
	SceneRouter.go(GameState.start_rematch(_rematch))

## Resumo da run: carta MVP, relíquia que mais deu, maior golpe e o dano de cada ante.
func _build_summary() -> void:
	var log_: Dictionary = GameState.run_log
	if log_.is_empty():
		return
	var box := HBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 28)
	var vbox: VBoxContainer = title.get_parent()
	vbox.add_child(box)
	vbox.move_child(box, unlocks.get_index() + 1)
	var mvp := GameState.top_of(log_.get("card_dmg", {}))
	if not mvp.is_empty() and CardDB.get_card(String(mvp["id"])) != null:
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 4)
		box.add_child(col)
		var cap := UiKit.label(tr("Carta MVP"), 16, UiKit.GOLD)
		cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(cap)
		var view: CardView = preload("res://scenes/ui/CardView.tscn").instantiate()
		col.add_child(view)
		view.setup(CardDB.new_instance(String(mvp["id"])))
		view.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		var v := UiKit.label(tr("%s de dano") % Cascade.fmt_int(int(mvp["damage"])), 15, UiKit.TEXT_DIM)
		v.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(v)
	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 8)
	box.add_child(right)
	var top_relic := GameState.top_of(log_.get("relic_dmg", {}))
	if not top_relic.is_empty() and CardDB.relics.has(String(top_relic["id"])):
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		right.add_child(row)
		var medal: RelicView = preload("res://scenes/ui/RelicView.tscn").instantiate()
		row.add_child(medal)
		medal.setup(String(top_relic["id"]))
		var rl := UiKit.label(tr("Relíquia que mais deu: %s") % tr(String(CardDB.relics[String(top_relic["id"])].get("name", ""))) + "\n" + tr("%s de dano") % Cascade.fmt_int(int(top_relic["damage"])), 16, Color.WHITE)
		rl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(rl)
	var best_row := HBoxContainer.new()
	best_row.add_theme_constant_override("separation", 12)
	right.add_child(best_row)
	var best_l := UiKit.label(tr("Maior golpe: %s") % Cascade.fmt_int(int(log_.get("best_hit", 0))), 16, UiKit.TEXT_DIM)
	best_l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	best_row.add_child(best_l)
	if log_.get("best_cascade") is Dictionary and not (log_["best_cascade"].get("steps", []) as Array).is_empty():
		var replay := UiKit.button(tr("▶ REVER O MAIOR GOLPE"), 48, 15, UiKit.BG_LIGHT, UiKit.GOLD)
		replay.name = "Replay"
		replay.pressed.connect(func():
			if not SceneRouter.has_overlay():
				Sfx.select()
				CascadeReplay.open(log_["best_cascade"]))
		best_row.add_child(replay)
	right.add_child(UiKit.label(tr("Dano por ante"), 16, UiKit.GOLD))
	var by_ante: Dictionary = log_.get("damage_by_ante", {})
	var last := 0
	for k in by_ante:
		last = maxi(last, int(k))
	var vals: Array = []
	for a in range(1, last + 1):
		vals.append(int(by_ante.get(str(a), 0)))
	var chart := DamageChart.new()
	chart.set_values(vals)
	right.add_child(chart)

## Continuar para lá do ante 8: a vitória já ficou registada; a vida subir com o ante.
func _on_endless() -> void:
	Sfx.boom()
	GameState.endless = true
	GameState.last_victory = false
	GameState.next_ante()
	# Entrar no infinito abre o Baú de Espólio do boss final.
	GameState.prepare_loot()
	GameState.save_run({}, "loot")
	SceneRouter.go("loot")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")

func _animate_in(won: bool) -> void:
	title.pivot_offset = title.size / 2.0
	title.scale = Vector2(0.3, 0.3)
	title.modulate.a = 0.0
	var tw := create_tween().set_parallel(true)
	tw.tween_property(title, "scale", Vector2.ONE, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(title, "modulate:a", 1.0, 0.3)
	if won:
		Sfx.victory()
	else:
		Sfx.defeat()

## 0.13.0: epílogo do Livro III da História (por cima do ecrã do fim, com confetes).
func _show_epilogue(text: String) -> void:
	if not is_inside_tree():
		return
	CelebrationFx.play(self, get_viewport_rect(), "confetti")
	Sfx.level_up()
	ChoiceDialog.open(tr("EPÍLOGO"), text, [[tr("FIM"), null, true]])
