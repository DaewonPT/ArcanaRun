extends Control
## Ecrã de fim de run (vitória ou derrota): regista o progresso e mostra desbloqueios.

@onready var title: Label = %Title
@onready var detail: Label = %Detail
@onready var unlocks: Label = %Unlocks

func _ready() -> void:
	var won := GameState.player_hp > 0 and GameState.ante >= GameState.max_ante and GameState.last_victory
	var reached := GameState.ante
	var new_unlocks := GameState.record_run_end(reached, won)
	GameState.clear_saved_run()
	title.text = "VITÓRIA" if won else "DERROTA"
	title.add_theme_color_override("font_color", Color(0.5, 0.95, 0.6) if won else Color(0.95, 0.45, 0.45))
	var deck_name: String = GameState.deck_def.get("name", "")
	if won:
		detail.text = "%s venceu os 8 antes.\nRelíquias: %d  ·  Ouro: %d  ·  Seed: %d" % [deck_name, GameState.relic_ids.size(), GameState.gold, GameState.seed_value]
	else:
		detail.text = "%s caiu no ante %d.\nRelíquias: %d  ·  Baralho: %d cartas  ·  Seed: %d" % [deck_name, reached, GameState.relic_ids.size(), GameState.deck.size(), GameState.seed_value]
	if GameState.free_mode:
		unlocks.text = "Modo Livre — não conta para a campanha."
	elif new_unlocks.is_empty():
		var best := GameState.best_ante(String(GameState.deck_def.get("id", "")))
		unlocks.text = "Melhor ante com este baralho: %d.  Chega ao ante 4 para desbloquear o capítulo seguinte." % best if best < 4 else "Melhor ante com este baralho: %d." % best
	else:
		unlocks.text = "Desbloqueaste: " + ", ".join(PackedStringArray(new_unlocks))
	%Campaign.pressed.connect(func(): Sfx.select(); SceneRouter.go("campaign"))
	%Menu.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	_animate_in(won)

func _animate_in(won: bool) -> void:
	title.pivot_offset = title.size / 2.0
	title.scale = Vector2(0.3, 0.3)
	title.modulate.a = 0.0
	var tw := create_tween().set_parallel(true)
	tw.tween_property(title, "scale", Vector2.ONE, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(title, "modulate:a", 1.0, 0.3)
	if won:
		Sfx.boom()
	else:
		Sfx.hit()
