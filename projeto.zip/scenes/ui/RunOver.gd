extends Control
## Ecrã de fim de run (vitória ou derrota).

@onready var title: Label = %Title
@onready var detail: Label = %Detail

func _ready() -> void:
	var won := GameState.player_hp > 0 and GameState.ante >= GameState.max_ante
	title.text = "VITÓRIA" if won else "DERROTA"
	detail.text = "Chegaste ao ante %d\nSeed: %d" % [GameState.ante, GameState.seed_value]
	%Back.pressed.connect(func(): SceneRouter.go("main"))
