class_name SealPicker
extends Control
## Escolha de um selo de guilda (loja): os selos com nome, cor e texto (8 desde a 0.15.0). Depois escolhe-se a carta.

var _on_pick: Callable

static func open(on_pick: Callable) -> SealPicker:
	var p := SealPicker.new()
	p._on_pick = on_pick
	SceneRouter.show_overlay(p)
	p._build()
	return p

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.8))

func _build() -> void:
	# 0.15.0: 8 selos — em duas colunas, para caberem no ecrã baixo.
	var panel := UiKit.centered_panel(self, 1000)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	panel.add_child(vbox)
	var title := UiKit.label(tr("ESCOLHE O SELO"), 30, UiKit.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	vbox.add_child(grid)
	for sd in CardDB.seals:
		var color := CardView.seal_color(sd)
		var b := UiKit.wrap_button("◉ %s — %s" % [tr(String(sd.get("name", ""))), tr(String(sd.get("text", "")))], 72, 15, color.darkened(0.55), color)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var id := String(sd.get("id", ""))
		b.name = "Seal_" + id
		b.pressed.connect(func():
			Sfx.select()
			queue_free()
			if _on_pick.is_valid():
				_on_pick.call(id))
		grid.add_child(b)
	var cancel := UiKit.button(tr("CANCELAR"), 50, 20)
	cancel.pressed.connect(close)
	vbox.add_child(cancel)
	UiKit.pop_in(panel)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Sfx.select()
	queue_free()
