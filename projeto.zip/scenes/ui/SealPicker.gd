class_name SealPicker
extends Control
## Escolha de um selo de guilda (loja): os 5 selos com nome, cor e texto. Depois escolhe-se a carta.

var _on_pick: Callable

static func open(on_pick: Callable) -> SealPicker:
	var p := SealPicker.new()
	p._on_pick = on_pick
	SceneRouter.show_overlay(p)
	p._build()
	return p

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.8))

func _build() -> void:
	var panel := UiKit.centered_panel(self, 640)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	panel.add_child(vbox)
	var title := UiKit.label(tr("ESCOLHE O SELO"), 30, UiKit.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	for sd in CardDB.seals:
		var color: Color = CardView.COLORS.get(String(sd.get("color", "colorless")), UiKit.BG_LIGHT)
		var b := UiKit.button("◉ %s — %s" % [tr(String(sd.get("name", ""))), tr(String(sd.get("text", "")))], 62, 16, color.darkened(0.55), color)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		b.clip_text = true
		var id := String(sd.get("id", ""))
		b.pressed.connect(func():
			Sfx.select()
			queue_free()
			if _on_pick.is_valid():
				_on_pick.call(id))
		vbox.add_child(b)
	var cancel := UiKit.button(tr("CANCELAR"), 50, 20)
	cancel.pressed.connect(close)
	vbox.add_child(cancel)
	UiKit.pop_in(panel)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Sfx.select()
	queue_free()
