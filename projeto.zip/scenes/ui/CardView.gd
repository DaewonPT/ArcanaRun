class_name CardView
extends PanelContainer
## Representação visual de uma CardInstance (mão, tabuleiro ou faixa de feitiços).
## Toque (carregar e largar em cima da carta) = `pressed`. Um arrasto para fazer scroll não conta.
## Toques no Android chegam como eventos de rato (emulate_mouse_from_touch, ligado por defeito).

signal pressed(card: CardInstance)

const COLORS := {
	"white": Color(0.93, 0.89, 0.74),
	"blue": Color(0.38, 0.56, 0.88),
	"black": Color(0.42, 0.36, 0.48),
	"red": Color(0.86, 0.36, 0.30),
	"green": Color(0.40, 0.66, 0.40),
	"colorless": Color(0.66, 0.66, 0.70),
}
const DARK_TEXT := Color(0.08, 0.08, 0.1)
const LIGHT_TEXT := Color(0.97, 0.97, 0.99)

var card: CardInstance
var playable: bool = true:
	set(v):
		playable = v
		modulate.a = 1.0 if v else 0.45
var compact: bool = false

var _pressing: bool = false

@onready var name_label: Label = %Name
@onready var cost_label: Label = %Cost
@onready var stats_label: Label = %Stats
@onready var text_label: Label = %Text
@onready var type_label: Label = %Type

func setup(p_card: CardInstance) -> void:
	card = p_card
	if not is_node_ready():
		await ready
	refresh()

func refresh() -> void:
	var d := card.data
	name_label.text = d.name
	cost_label.text = str(d.cost)
	if d.is_creature():
		stats_label.text = "%d ⚔  %d ♥" % [card.power(), card.remaining()]
		type_label.text = "Criatura"
	elif d.is_spell():
		stats_label.text = "%d ⚔" % card.power() if d.power > 0 else ""
		type_label.text = "Mágica" if d.subtype == "instant" else "Feitiço"
	else:
		stats_label.text = ""
		type_label.text = "Terreno · na mão"
	text_label.text = d.text + ("  ≈" if d.approx else "")
	# Fundo: cor principal; multicolor = mistura das cores; incolor = cinzento.
	var bg: Color = COLORS[d.primary_color()]
	if d.colors.size() >= 2:
		bg = Color(0, 0, 0)
		for col in d.colors:
			bg += COLORS.get(col, COLORS.colorless) / d.colors.size()
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.set_corner_radius_all(12)
	style.set_content_margin_all(7)
	if d.colors.size() >= 3:
		style.set_border_width_all(3)
		style.border_color = Color(0.98, 0.78, 0.3)
	add_theme_stylebox_override("panel", style)
	var text_color := DARK_TEXT if bg.get_luminance() > 0.45 else LIGHT_TEXT
	for l in [name_label, cost_label, stats_label, text_label, type_label]:
		l.add_theme_color_override("font_color", text_color)
	pivot_offset = size / 2.0

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		pivot_offset = size / 2.0
	elif what == NOTIFICATION_MOUSE_EXIT and _pressing:
		# O dedo saiu da carta (scroll da mão): cancela o toque.
		_pressing = false
		_press_feedback(false)

func _gui_input(event: InputEvent) -> void:
	if not (event is InputEventMouseButton) or event.button_index != MOUSE_BUTTON_LEFT:
		return
	accept_event()
	if event.pressed:
		_pressing = true
		_press_feedback(true)
	else:
		var inside := Rect2(Vector2.ZERO, size).has_point(event.position)
		_press_feedback(false)
		if _pressing and inside:
			pressed.emit(card)
		_pressing = false

func _press_feedback(down: bool) -> void:
	if not is_inside_tree() or is_queued_for_deletion():
		return
	pivot_offset = size / 2.0
	if has_meta("press_tw"):
		var old = get_meta("press_tw")
		if old is Tween and (old as Tween).is_valid():
			(old as Tween).kill()
	if not down:
		scale = Vector2.ONE   # imediato: a carta pode ser destruída já a seguir (jogada/canalizada)
		return
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector2(0.95, 0.95), 0.06)
	set_meta("press_tw", tw)
