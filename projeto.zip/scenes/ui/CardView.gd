class_name CardView
extends PanelContainer
## Representação visual de uma CardInstance (mão, tabuleiro, listas).
## Toque (carregar e largar em cima da carta) = `pressed`; manter o dedo = `long_pressed` (ver em grande).
## Um arrasto para fazer scroll cancela os dois. Toques no Android chegam como eventos de rato
## (emulate_mouse_from_touch) e o ScrollContainer avisa com NOTIFICATION_SCROLL_BEGIN quando arrasta.

signal pressed(card: CardInstance)
signal long_pressed(card: CardInstance)
signal drag_started(card: CardInstance, global_pos: Vector2)
signal drag_moved(card: CardInstance, global_pos: Vector2)
signal drag_ended(card: CardInstance, global_pos: Vector2)

const LONG_PRESS := 0.42     # segundos com o dedo em cima para abrir em grande
const DRAG_CANCEL := 16.0    # px de movimento a partir dos quais o toque passa a ser scroll

const COLORS := {
	"white": Color(0.93, 0.89, 0.74),
	"blue": Color(0.38, 0.56, 0.88),
	"black": Color(0.42, 0.36, 0.48),
	"red": Color(0.86, 0.36, 0.30),
	"green": Color(0.40, 0.66, 0.40),
	"colorless": Color(0.66, 0.66, 0.70),
}
const DARK_TEXT := Color(0.08, 0.08, 0.1)
const LIGHT_TEXT := Color(0.97, 0.97, 0.99)
const FOIL_SHADER := preload("res://assets/shaders/foil.gdshader")

## Material partilhado por todos os brilhos holográficos (a inclinação muda-se uma vez para todos).
static var _foil_material: ShaderMaterial

static func foil_material() -> ShaderMaterial:
	if _foil_material == null:
		_foil_material = ShaderMaterial.new()
		_foil_material.shader = FOIL_SHADER
	return _foil_material

## Inclinação do telemóvel (acelerómetro), chamada pelo SceneRouter a cada frame.
static func set_foil_tilt(t: Vector2) -> void:
	if _foil_material != null:
		_foil_material.set_shader_parameter("tilt", t)

var card: CardInstance
var playable: bool = true:
	set(v):
		playable = v
		modulate.a = 1.0 if v else 0.45
var compact: bool = false
var draggable: bool = false        # tabuleiro: arrastar reordena em vez de cancelar o toque
## Variação do total do ataque se esta carta for jogada (mão). 0 = não mostrar.
var delta: int = 0:
	set(v):
		delta = v
		if is_node_ready():
			_refresh_delta()

var _pressing: bool = false
var _press_pos := Vector2.ZERO
var _press_id: int = 0
var _long_fired: bool = false
var _dragging: bool = false

@onready var name_label: Label = %Name
@onready var cost_label: Label = %Cost
@onready var stats_label: Label = %Stats
@onready var text_label: Label = %Text
@onready var type_label: Label = %Type
@onready var delta_label: Label = %Delta
@onready var icon_slot: Control = %Icon
@onready var pips_box: HBoxContainer = %Pips
@onready var seal_slot: Control = %Seal
var _icon: CardIcon
var _seal_icon: CardIcon
var _foil: ColorRect

func setup(p_card: CardInstance) -> void:
	card = p_card
	if not is_node_ready():
		await ready
	refresh()

func refresh() -> void:
	var d := card.data
	name_label.text = d.name
	cost_label.text = str(d.cost)
	if d.is_creature():
		stats_label.text = "%d ⚔  %d ♥" % [card.power(), card.remaining()]
		type_label.text = tr("Criatura")
	elif d.is_spell():
		stats_label.text = "%d ⚔" % card.power() if d.power > 0 else ""
		type_label.text = tr("Mágica") if d.subtype == "instant" else tr("Feitiço")
	elif d.is_curse():
		stats_label.text = ""
		type_label.text = tr("Maldição")
	else:
		stats_label.text = ""
		type_label.text = tr("Terreno · na mão")
	# Marcadores: recapitular ↺, dupla face ⇄ (com progresso da missão), fusão ⚗, infeção ☠.
	if d.flashback:
		type_label.text += " · ↺"
	if card.has_mission():
		type_label.text += " · ⇄ %d/%d" % [card.mission_count, card.mission_target()]
	elif card.transformed:
		type_label.text += " · ⇄"
	if d.fused_text != "":
		type_label.text += " · ⚗"
	if d.infected:
		type_label.text += " · ☠ %d/%d" % [int(card.deck_entry.get("uses", 0)), BattleManager.INFECTED_USES]
	var body := tr(d.text) + ("  ≈" if d.approx else "")
	if d.fused_text != "":
		body += "\n⚗ " + tr(d.fused_text)
	text_label.text = body
	# Fundo: cor principal; multicolor = mistura das cores; incolor = cinzento.
	var bg: Color = COLORS[d.primary_color()]
	if d.colors.size() >= 2:
		bg = Color(0, 0, 0)
		for col in d.colors:
			bg += COLORS.get(col, COLORS.colorless) / d.colors.size()
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.set_corner_radius_all(12)
	style.set_content_margin_all(7)
	# Moldura por raridade: rara = ouro, incomum = prata; tricolor sem raridade = ouro fino.
	if d.rarity == "rare":
		style.set_border_width_all(3)
		style.border_color = Color(0.98, 0.78, 0.3)
	elif d.rarity == "uncommon":
		style.set_border_width_all(2)
		style.border_color = Color(0.82, 0.84, 0.92)
	elif d.colors.size() >= 3:
		style.set_border_width_all(2)
		style.border_color = Color(0.98, 0.78, 0.3)
	add_theme_stylebox_override("panel", style)
	var text_color := DARK_TEXT if bg.get_luminance() > 0.45 else LIGHT_TEXT
	for l in [name_label, cost_label, stats_label, text_label, type_label]:
		l.add_theme_color_override("font_color", text_color)
	# Ícone do tipo e pips de cor (só nas multicolor, onde o fundo é uma mistura).
	if _icon == null:
		_icon = CardIcon.new(CardIcon.kind_for(d), text_color, 14.0)
		_icon.set_anchors_preset(Control.PRESET_FULL_RECT)
		icon_slot.add_child(_icon)
	else:
		_icon.kind = CardIcon.kind_for(d)
		_icon.color = text_color
	for c in pips_box.get_children():
		c.queue_free()
	# Pips de cor nas multicolores; no modo daltónico também nas de uma cor (com símbolo).
	if d.colors.size() >= 2 or (Settings.colorblind and d.colors.size() == 1):
		for col in d.colors:
			pips_box.add_child(CardIcon.pip(col))
	# Selo de guilda (emblema no canto inferior esquerdo).
	var seal_id := card.seal()
	if seal_id != "":
		var seal_def := CardDB.get_seal(seal_id)
		var seal_color: Color = COLORS.get(String(seal_def.get("color", "colorless")), COLORS.colorless)
		if _seal_icon == null:
			_seal_icon = CardIcon.new("seal", seal_color, 18.0)
			_seal_icon.set_anchors_preset(Control.PRESET_FULL_RECT)
			seal_slot.add_child(_seal_icon)
		else:
			_seal_icon.color = seal_color
		seal_slot.custom_minimum_size.x = 18
		seal_slot.visible = true
	else:
		seal_slot.visible = false
		seal_slot.custom_minimum_size.x = 0
	_apply_text_size()
	_refresh_delta()
	_refresh_foil(d.rarity == "rare" or d.is_back)
	pivot_offset = size / 2.0

## Brilho holográfico (raras e faces viradas): um ColorRect com o shader por cima do conteúdo.
func _refresh_foil(on: bool) -> void:
	if on and _foil == null:
		_foil = ColorRect.new()
		_foil.material = CardView.foil_material()
		_foil.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(_foil)
	elif not on and _foil != null:
		_foil.queue_free()
		_foil = null

## Texto grande (Configurações): fontes maiores nas cartas.
func _apply_text_size() -> void:
	var big := Settings.large_text
	name_label.custom_minimum_size.y = 44 if big else 40
	name_label.add_theme_font_size_override("font_size", 16 if big else 14)
	text_label.add_theme_font_size_override("font_size", 14 if big else 12)
	type_label.add_theme_font_size_override("font_size", 12 if big else 11)
	stats_label.add_theme_font_size_override("font_size", 22 if big else 20)
	text_label.max_lines_visible = 4 if big else 5

## Carta ainda não descoberta (coleção): sem nome, texto nem toque.
func set_unknown() -> void:
	if not is_node_ready():
		await ready
	name_label.text = "???"
	cost_label.text = "?"
	stats_label.text = ""
	text_label.text = tr("Ainda não descoberta.")
	_refresh_foil(false)
	modulate = Color(0.45, 0.45, 0.5)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _refresh_delta() -> void:
	if delta == 0:
		delta_label.text = ""
		return
	delta_label.text = ("+" if delta > 0 else "−") + Cascade.fmt_int(absi(delta))
	delta_label.add_theme_color_override("font_color", Color(0.15, 0.7, 0.3) if delta > 0 else Color(0.8, 0.3, 0.3))

func _notification(what: int) -> void:
	match what:
		NOTIFICATION_RESIZED:
			pivot_offset = size / 2.0
		NOTIFICATION_MOUSE_EXIT, NOTIFICATION_SCROLL_BEGIN:
			# O dedo saiu da carta ou a lista começou a fazer scroll: cancela o toque (não o arrasto).
			if _pressing and not _dragging:
				_cancel_press()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		if _dragging:
			drag_moved.emit(card, get_global_mouse_position())
		elif _pressing and (event.position - _press_pos).length() > DRAG_CANCEL:
			if draggable:
				_pressing = false
				_press_id += 1   # cancela o toque longo
				_press_feedback(false)
				_dragging = true
				drag_started.emit(card, get_global_mouse_position())
			else:
				_cancel_press()
		return
	if not (event is InputEventMouseButton) or event.button_index != MOUSE_BUTTON_LEFT:
		return
	accept_event()
	if event.pressed:
		_pressing = true
		_long_fired = false
		_press_pos = event.position
		_press_feedback(true)
		_press_id += 1
		_start_long_press(_press_id)
	else:
		if _dragging:
			_dragging = false
			drag_ended.emit(card, get_global_mouse_position())
			return
		var inside := Rect2(Vector2.ZERO, size).has_point(event.position)
		var was_pressing := _pressing
		_pressing = false
		_press_feedback(false)
		if was_pressing and inside and not _long_fired:
			pressed.emit(card)

func _start_long_press(id: int) -> void:
	await get_tree().create_timer(LONG_PRESS).timeout
	if id != _press_id or not _pressing or not is_inside_tree() or is_queued_for_deletion():
		return
	_long_fired = true
	_pressing = false
	_press_feedback(false)
	Settings.vibrate(25)
	long_pressed.emit(card)

func _cancel_press() -> void:
	_pressing = false
	_press_id += 1   # invalida o temporizador do toque longo
	_press_feedback(false)

func _press_feedback(down: bool) -> void:
	if not is_inside_tree() or is_queued_for_deletion():
		return
	pivot_offset = size / 2.0
	if has_meta("press_tw"):
		var old = get_meta("press_tw")
		if old is Tween and (old as Tween).is_valid():
			(old as Tween).kill()
	if not down:
		scale = Vector2.ONE   # imediato: a carta pode ser destruída já a seguir (jogada/canalizada)
		return
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector2(0.95, 0.95), 0.06)
	set_meta("press_tw", tw)
