class_name CardView
extends PanelContainer
## Representação visual de uma CardInstance (mão, tabuleiro, listas).
## Toque (carregar e largar em cima da carta) = `pressed`; manter o dedo = `long_pressed` (ver em grande).
## Um arrasto para fazer scroll cancela os dois. Toques no Android chegam como eventos de rato
## (emulate_mouse_from_touch) e o ScrollContainer avisa com NOTIFICATION_SCROLL_BEGIN quando arrasta.
## 0.10.0: sigilo da carta (CardSigil), tribo/encantamento/Ficha/Reforço/Reação na linha do tipo, versão
## "+" no nome, moldura animada nas Míticas, molduras cosméticas e modo compacto.
## 0.11.0: tipo com cor e ícone (Criatura, Feitiço, Mágica, Encantamento, Terreno, Maldição, Ficha); os
## Terrenos têm "+1" em vez do custo, uma paisagem quando não há ilustração e "jogar: +1 mana" em baixo;
## ícones das palavras-chave; o Nevoeiro esconde o texto na mão.
## 0.14.1: visual "Arte em destaque" (escolhido pelo Paulo; substitui o "Vidro arcano" da 0.14.0) — a
## ilustração a toda a largura em cima, com o nome por cima (em Lora, com sombra) e o custo numa esfera com
## brilho; o tipo numa pílula colorida a meio, com o losango da raridade; o texto centrado (Poder a azul,
## Mult a vermelho, [Na Mão] a dourado); em baixo, o Poder numa pílula azul e a Vida numa vermelha. Fundo
## em degradê na cor da carta, contorno na cor (em degradê nas de várias cores) e um fio da raridade por
## dentro. As peças desenhadas estão em dois nós CardFace (um comando de desenho cada, mais a ilustração);
## as letras são Labels postos à mão em _layout(), à medida do tamanho da carta.

signal pressed(card: CardInstance)
signal long_pressed(card: CardInstance)
signal drag_started(card: CardInstance, global_pos: Vector2)
signal drag_moved(card: CardInstance, global_pos: Vector2)
signal drag_ended(card: CardInstance, global_pos: Vector2)
signal keyword_tapped(card: CardInstance, keyword: String, at: Rect2)   # 0.13.0: tocou num ícone de palavra-chave

const LONG_PRESS := 0.42     # segundos com o dedo em cima para abrir em grande
const DRAG_CANCEL := 16.0    # px de movimento a partir dos quais o toque passa a ser scroll
const DRAG_AFTER_LONG := 28.0   # 0.12.1: depois de abrir em grande, mexer o dedo pega na carta (arrastar)

const COLORS := {
	"white": Color(0.93, 0.89, 0.74),
	"blue": Color(0.38, 0.56, 0.88),
	"black": Color(0.42, 0.36, 0.48),
	"red": Color(0.86, 0.36, 0.30),
	"green": Color(0.40, 0.66, 0.40),
	"colorless": Color(0.66, 0.66, 0.70),
}
const DARK_TEXT := Color(0.08, 0.08, 0.1)
const LIGHT_TEXT := Color(0.97, 0.97, 0.99)
const NAME_COLOR := Color(1.0, 1.0, 1.0)
const BODY_COLOR := Color(0.945, 0.925, 0.973)      # #f1ecf8
const POWER_COLOR := Color(0.44, 0.82, 1.0)        # Poder (texto e carta em grande)
const TOUGH_COLOR := Color(1.0, 0.48, 0.565)
const DELTA_UP := Color(0.494, 0.941, 0.627)
const DELTA_DOWN := Color(1.0, 0.45, 0.45)
## Cores das palavras no texto: Poder a azul, Mult a vermelho (como no placar) e [Na Mão] a dourado.
const BB_POWER := "6fd0ff"
const BB_MULT := "ff7a90"
const BB_HAND := "f2c14e"
## Losango da raridade (as comuns não têm).
const RARITY_GEM := CardFace.RARITY_GEM
const SIZE_NORMAL := Vector2(130, 186)
const SIZE_COMPACT := Vector2(112, 160)
## As medidas do desenho são para a carta normal (186 de altura); as outras escalam a partir dela.
const BASE_H := 186.0
const MYTHIC_COLORS := [Color(1.0, 0.45, 0.2), Color(1.0, 0.82, 0.3), Color(0.95, 0.3, 0.55)]
const TRIBE_NAMES := {"goblin": "Goblin", "elf": "Elfo", "zombie": "Zombie", "angel": "Anjo", "dragon": "Dragão", "soldier": "Soldado",
	"construct": "Construto", "spirit": "Espírito", "beast": "Fera", "plant": "Planta"}
const FOIL_SHADER := preload("res://assets/shaders/foil.gdshader")

## Nevoeiro (Bruxa do Nevoeiro): o texto das cartas na mão fica escondido. Liga-o a batalha.
static var fog_hand := false

## Tipo para a pílula e para o ícone.
static func type_key(d: CardData) -> String:
	if d.token:
		return "token"
	return CardIcon.kind_for(d)

## Material partilhado por todos os brilhos holográficos (a inclinação muda-se uma vez para todos).
static var _foil_material: ShaderMaterial

static func foil_material() -> ShaderMaterial:
	if _foil_material == null:
		_foil_material = ShaderMaterial.new()
		_foil_material.shader = FOIL_SHADER
	return _foil_material

## 0.13.0: um material por edição (Brilhante, Holográfica, Policromática), partilhado pelas cartas.
static var _edition_materials := {}

static func edition_material(ed: String) -> ShaderMaterial:
	if not _edition_materials.has(ed):
		var m := ShaderMaterial.new()
		m.shader = FOIL_SHADER
		m.set_shader_parameter("mode", int(EffectResolver.EDITIONS[ed].get("mode", 0)))
		m.set_shader_parameter("strength", 0.3 if ed == "poly" else 0.26)
		_edition_materials[ed] = m
	return _edition_materials[ed]

## Inclinação do telemóvel (acelerómetro), chamada pelo SceneRouter a cada frame.
static func set_foil_tilt(t: Vector2) -> void:
	if _foil_material != null:
		_foil_material.set_shader_parameter("tilt", t)
	for m in _edition_materials.values():
		(m as ShaderMaterial).set_shader_parameter("tilt", t)

var card: CardInstance
var playable: bool = true:
	set(v):
		playable = v
		modulate.a = 1.0 if v else 0.45
var compact: bool = false
## 0.13.0: tamanho das cartas da mão (Configurações → Visual): multiplica o tamanho e as letras.
var size_scale: float = 1.0
var draggable: bool = false        # tabuleiro: arrastar reordena em vez de cancelar o toque
var keyword_taps: bool = false     # 0.13.0: tocar num ícone de palavra-chave explica-a (em vez do toque normal)
## Variação do total do ataque se esta carta for jogada (mão). 0 = não mostrar.
var delta: int = 0:
	set(v):
		delta = v
		if is_node_ready():
			_refresh_delta()

var _pressing: bool = false
var _press_pos := Vector2.ZERO
var _press_global := Vector2.ZERO   # 0.12.1: o movimento mede-se no ecrã (a carta da mão sobe debaixo do dedo)
var _last_global := Vector2.ZERO    # última posição do dedo no ecrã (dos eventos)
var _held: bool = false             # o dedo continua em baixo (do toque até largar)
var _press_id: int = 0
var _long_fired: bool = false
var _dragging: bool = false
var _selected: bool = false         # 0.12.1: carta da mão escolhida (contorno dourado e "JOGAR")
var _lethal: bool = false           # 0.16.0 (60): jogada, mata o inimigo neste turno (contorno dourado a pulsar)
var _lethal_t := 0.0
var _lethal_acc := 0.0
var _sel_playable: bool = true
## 0.16.0: a etiqueta por cima da carta escolhida ("" = só o contorno; a loja tem o COMPRAR por baixo).
var select_chip := "▲ JOGAR"

@onready var name_label: Label = %Name
@onready var cost_label: Label = %Cost            # dentro da esfera
@onready var stats_label: Label = %Stats          # Poder, na pílula azul (ou "jogar: +1 mana" nos Terrenos)
@onready var tough_label: Label = %Tough          # Vida, na pílula vermelha
@onready var text_label: RichTextLabel = %Text    # centrado, com cores (BBCode)
@onready var type_label: Label = %Type            # na pílula do tipo
@onready var delta_label: Label = %Delta
@onready var art_slot: Control = %ArtSlot         # zona da arte: sigilo ou paisagem quando não há ilustração
@onready var pips_box: Control = %Pips            # pips com símbolo (modo daltónico)
@onready var seal_slot: Control = %Seal
@onready var _kw_box: Control = %Keywords         # ícones das palavras-chave, em coluna à esquerda
@onready var _layout_root: Control = $Layout
var _face_back: CardFace
var _face_front: CardFace
var _layout_queued := false
var _tex: Texture2D           # ilustração (null = sem ilustração)
var _keys: Array[String] = ["colorless"]
var _bgs: Array[Color] = [Color("26262f"), Color("121218")]
var _text_fs := 10            # tamanho do texto antes de encolher para caber
var _u := 1.0                 # escala da carta face à normal (posições e letras)
var _name_h := 14.0
var _type_full := ""          # "Criatura · Dragão · ↺"
var _type_short := ""         # "Dragão · ↺" (se não couber tudo na pílula)
static var _type_font: FontVariation
static var _title_font: Font
var _seal_icon: CardIcon
var _foil: ColorRect
var _sigil: CardSigil
var _style: StyleBoxFlat
var _mythic_t := 0.0
## 0.12.0: molduras animadas (cosmético) — só se animam na batalha (a Coleção tem centenas de cartas).
static var frame_anim_on := false
## 0.12.0: ilustrações (assets/art/cards). A Coleção e o Construtor desligam-nas (centenas de cartas de uma
## vez gastariam memória a mais); lá vêem-se na carta em grande.
static var art_on := true
var _frame_anim := ""
var _frame_color := Color.WHITE
var _synergy: CardIcon
var _land_art: LandArt
var _edition_fx: ColorRect     # 0.13.0: brilho da edição por cima da carta
var _edition_gem: Control      # 0.13.0: pedra da edição no meio da borda de cima
var _mastery_badge: Control    # 0.13.0: medalha da mestria (meio da borda de baixo)
## 0.13.0: a mestria (jogadas em todas as runs) só aparece onde faz sentido (batalha, baralho, coleção).
static var mastery_on := true

## Marca de sinergia (elos dourados ao lado do Poder): a carta combina com o baralho (loja, draft).
func set_synergy(reason: String) -> void:
	if reason == "":
		if _synergy != null:
			_synergy.queue_free()
			_synergy = null
		return
	if _synergy == null:
		_synergy = CardIcon.new("chain", UiKit.GOLD, 15.0)
		_layout_root.add_child(_synergy)
		_queue_layout()
	_synergy.tooltip_text = reason
	tooltip_text = TranslationServer.translate("Combina: %s") % reason

func setup(p_card: CardInstance) -> void:
	card = p_card
	if not is_node_ready():
		await ready
	refresh()

func _ready() -> void:
	# 0.14.1: as peças desenhadas ficam em dois nós — a ilustração por trás de tudo e o resto por cima dela
	# (e do sigilo ou da paisagem), por baixo das letras.
	_face_back = CardFace.new()
	_face_back.name = "FaceBack"
	_face_back.layer = 0
	_layout_root.add_child(_face_back)
	_layout_root.move_child(_face_back, 0)
	_face_front = CardFace.new()
	_face_front.name = "FaceFront"
	_face_front.layer = 1
	_layout_root.add_child(_face_front)
	_layout_root.move_child(_face_front, art_slot.get_index() + 1)
	resized.connect(_queue_layout)
	text_label.resized.connect(_fit_text)

func refresh() -> void:
	var d := card.data
	if custom_minimum_size == SIZE_NORMAL or custom_minimum_size == SIZE_COMPACT or custom_minimum_size == Vector2.ZERO or has_meta("scaled_size"):
		var base := SIZE_COMPACT if Settings.compact else SIZE_NORMAL   # tamanhos à medida (draft, zoom) ficam
		custom_minimum_size = base if is_equal_approx(size_scale, 1.0) else (base * size_scale).round()
		if is_equal_approx(size_scale, 1.0):
			remove_meta("scaled_size")
		else:
			set_meta("scaled_size", true)
	var u0 := custom_minimum_size.y / BASE_H if custom_minimum_size.y > 0.0 else 1.0
	name_label.text = d.display_name()
	cost_label.text = "+1" if d.is_land() else str(d.cost)   # jogar um Terreno é de graça e dá +1 mana para sempre
	stats_label.text = ""
	tough_label.text = ""
	var base_type := ""
	var tribe := ""
	if d.is_creature():
		stats_label.text = str(card.power())
		tough_label.text = str(card.remaining())
		base_type = tr("Ficha") if d.token else tr("Criatura")
		if d.tribe != "":
			tribe = tr(TRIBE_NAMES.get(d.tribe, d.tribe))
	elif d.is_enchantment():
		base_type = tr("Encantamento")
	elif d.is_spell():
		stats_label.text = str(card.power()) if d.power > 0 else ""
		base_type = tr("Mágica") if d.subtype == "instant" else tr("Feitiço")
	elif d.is_curse():
		base_type = tr("Maldição")
	else:
		stats_label.text = tr("jogar: +1 mana")
		base_type = tr("Terreno")
	if card.temp_copy:
		base_type = tr("Cópia")   # 0.15.0 Selo do Espelho: desaparece no fim do turno
	# Marcadores: recapitular ↺, dupla face ⇄ (com progresso da missão), fusão ⚗, infeção ☠, Reforço, Reação,
	# edição.
	var marks := ""
	if d.flashback:
		marks += " · ↺"
	if card.has_mission():
		marks += " · ⇄ %d/%d" % [card.mission_count, card.mission_target()]
	elif card.transformed:
		marks += " · ⇄"
	if d.fused_text != "":
		marks += " · ⚗"
	if d.infected:
		marks += " · ☠ %d/%d" % [int(card.deck_entry.get("uses", 0)), BattleManager.INFECTED_USES]
	if d.has_kicker():
		marks += " · ★" if card.kicked else " · +%d" % int(d.kicker.get("cost", 0))
	if BattleManager.has_reaction(card):
		marks += " · ↯"
	var ed := card.edition()
	if EffectResolver.EDITIONS.has(ed):
		marks += " · " + String(EffectResolver.EDITIONS[ed]["symbol"])
	if card.persisted:
		marks += " · " + tr("persistiu")   # 0.15.0: já voltou uma vez nesta batalha
	_type_full = base_type + (" · " + tribe if tribe != "" else "") + marks
	_type_short = ((tr("Ficha") if d.token else tribe) + marks) if tribe != "" else ""
	type_label.text = _type_full
	var body := d.display_text() + ("  ≈" if d.approx else "")
	if d.fused_text != "":
		body += "\n⚗ " + tr(d.fused_text)
	text_label.text = "[center]%s[/center]" % ("???" if is_fogged() else CardView.card_bbcode(body))
	# Painel: fundo da cor da carta (o degradê e a arte vêm por cima), contorno na cor e sombra por baixo.
	_keys = CardFace.color_keys(d)
	_bgs = CardFace.backgrounds(d)
	var style := StyleBoxFlat.new()
	style.bg_color = _bgs[1]
	style.set_corner_radius_all(maxi(4, roundi(11.0 * u0)))
	style.set_content_margin_all(0)
	style.set_border_width_all(2)
	style.border_color = CardFace.border_color(d)
	if not Settings.performance_mode:
		style.shadow_color = Color(0, 0, 0, 0.45)
		style.shadow_size = 7
		style.shadow_offset = Vector2(0, 3)
	# Míticas: o contorno vai mudando de cor (lume → ouro → magenta) e brilham a laranja. A moldura
	# cosmética (Configurações → Visual) vale só para as comuns.
	_frame_anim = ""
	if d.rarity == "mythic":
		style.border_color = MYTHIC_COLORS[0]
		if not Settings.performance_mode:
			style.shadow_color = Color(1.0, 0.51, 0.27, 0.6)
			style.shadow_size = 9
			style.shadow_offset = Vector2.ZERO
	elif d.rarity == "common":
		_apply_frame(style)
	if d.plus:
		style.shadow_color = Color(0.55, 0.95, 0.6, 0.55)
		style.shadow_size = 7
		style.shadow_offset = Vector2.ZERO
	if card.temp_copy:
		style.bg_color.a = 0.72
		style.border_color = Color(0.62, 0.9, 1.0)
	add_theme_stylebox_override("panel", style)
	_style = style
	set_process((d.rarity == "mythic" or (_frame_anim != "" and frame_anim_on)) and Settings.motion_ok() and not Settings.performance_mode)
	var has_art := _refresh_art(d)
	_refresh_sigil(d, has_art)
	_refresh_land_art(d, has_art)
	# Letras: nome em Lora com sombra (lê-se sobre a ilustração), números em Lora, tipo e texto em Inter.
	name_label.add_theme_font_override("font", CardView.title_font())
	name_label.add_theme_color_override("font_color", NAME_COLOR)
	name_label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.95))
	name_label.add_theme_constant_override("shadow_offset_x", 0)
	name_label.add_theme_constant_override("shadow_offset_y", 1)
	# Sombra simples (deslocada), sem contorno: a sombra com contorno parte o lote das letras e custava
	# ~15 comandos de desenho por carta. O escuro por cima da ilustração faz o resto.
	name_label.add_theme_constant_override("shadow_outline_size", 0)
	name_label.add_theme_constant_override("outline_size", 0)
	cost_label.add_theme_font_override("font", CardView.title_font())
	cost_label.add_theme_color_override("font_color", Color.WHITE)
	cost_label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.85))
	cost_label.add_theme_constant_override("shadow_offset_x", 0)
	cost_label.add_theme_constant_override("shadow_offset_y", 1)
	cost_label.add_theme_constant_override("shadow_outline_size", 0)
	cost_label.add_theme_constant_override("outline_size", 0)
	for l in [stats_label, tough_label]:
		(l as Label).add_theme_font_override("font", CardView.title_font() if not d.is_land() else get_theme_default_font())
		(l as Label).add_theme_color_override("font_color", Color.WHITE)
		(l as Label).add_theme_constant_override("outline_size", 0)
	type_label.add_theme_font_override("font", CardView.type_font())
	type_label.add_theme_color_override("font_color", Color.WHITE)
	type_label.add_theme_constant_override("outline_size", 0)
	text_label.add_theme_color_override("default_color", BODY_COLOR)
	text_label.add_theme_constant_override("outline_size", 0)
	# 0.12.0 (alto contraste): texto a branco puro com contorno preto.
	if Settings.high_contrast:
		for l in [name_label, cost_label, stats_label, tough_label, type_label]:
			l.add_theme_color_override("font_color", Color.WHITE)
			UiKit.outline_for(l, Color.WHITE, 3)
		text_label.add_theme_color_override("default_color", Color.WHITE)
		text_label.add_theme_color_override("font_outline_color", Color.BLACK)
		text_label.add_theme_constant_override("outline_size", 3)
	_refresh_keywords(d)
	for c in pips_box.get_children():
		pips_box.remove_child(c)
		c.queue_free()
	# Modo daltónico: pips com o símbolo da cor (também nas de uma cor); fora dele, os pips das cartas de
	# várias cores são desenhados pela frente da carta.
	if (Settings.colorblind or (d.phyrexian > 0 and d.colors.size() >= 2)) and not d.colors.is_empty():
		for col in d.colors:
			var pip := CardIcon.new("pip", CardFace.palette(String(col)).get("pip", Color.WHITE), 14.0)
			pip.mana_color = String(col)
			pips_box.add_child(pip)
	# 0.15.0 Mana de Sangue: uma gota por baixo da esfera do custo por cada uma.
	for i in d.phyrexian:
		var drop := CardIcon.new("blood", Color(0.88, 0.16, 0.22), 14.0)
		drop.tooltip_text = tr("Mana de Sangue: paga-se com 1 de mana ou com 2 de vida.")
		pips_box.add_child(drop)
	# Selo de guilda (emblema ao lado do Poder).
	var seal_id := card.seal()
	if seal_id != "":
		var seal_def := CardDB.get_seal(seal_id)
		var seal_color := CardView.seal_color(seal_def)
		if _seal_icon == null:
			_seal_icon = CardIcon.new("seal", seal_color, 15.0)
			_seal_icon.set_anchors_preset(Control.PRESET_FULL_RECT)
			seal_slot.add_child(_seal_icon)
		else:
			_seal_icon.color = seal_color
		seal_slot.visible = true
	else:
		seal_slot.visible = false
	_refresh_delta()
	_refresh_foil((d.rarity == "rare" or d.rarity == "mythic" or d.is_back) and not Settings.performance_mode and not EffectResolver.EDITIONS.has(ed))
	_refresh_edition(ed)
	_refresh_mastery(d)
	pivot_offset = size / 2.0
	if size.y >= 20.0:
		_layout()   # já tem tamanho (refresh numa carta que já está no ecrã): sem esperar pelo fim do frame
	else:
		_queue_layout()

## 0.15.0: cor de um selo de guilda (os selos novos têm "tint" próprio; os outros usam a cor de mana).
static func seal_color(sd: Dictionary) -> Color:
	var tint := String(sd.get("tint", ""))
	if tint != "" and Color.html_is_valid(tint):
		return Color.html(tint)
	return COLORS.get(String(sd.get("color", "colorless")), COLORS.colorless)

## Cores néon da carta (contorno), para quem precisa de uma cor por cor da carta (até 3).
static func neon_colors(d: CardData) -> Array[Color]:
	var out: Array[Color] = []
	for k in CardFace.color_keys(d):
		out.append(CardFace.palette(k)["border"])
	return out

## Letra do tipo: a Inter com um pouco mais de espaço entre letras (maiúsculas pequenas leem-se melhor).
static func type_font() -> FontVariation:
	if _type_font == null:
		_type_font = FontVariation.new()
		_type_font.base_font = ThemeDB.get_project_theme().default_font if ThemeDB.get_project_theme() != null else ThemeDB.fallback_font
		_type_font.spacing_glyph = 1
	return _type_font

## 0.14.1: a Lora (a letra dos títulos), para o nome e os números das cartas.
static func title_font() -> Font:
	if _title_font == null:
		var th := ThemeDB.get_project_theme()
		if th != null and th.has_font("font", "TitleLabel"):
			_title_font = th.get_font("font", "TitleLabel")
		else:
			_title_font = ThemeDB.fallback_font
	return _title_font

## Texto da carta em BBCode, com Poder a azul, Mult a vermelho e [Na Mão] a dourado. O número junta-se à
## palavra com um espaço que não parte ("+5 Mult" nunca fica separado).
static func card_bbcode(text: String) -> String:
	return colorize_bbcode(text.replace("[", "[lb]"))

## Pinta as palavras do texto já em BBCode (aceita os [url] do glossário à volta das palavras).
static func colorize_bbcode(bb: String) -> String:
	var rx := _color_regex()
	var out := ""
	var pos := 0
	for m in rx.search_all(bb):
		out += bb.substr(pos, m.get_start() - pos)
		var whole := m.get_string()
		var hex := BB_HAND
		var word := m.get_string("word").to_lower()
		if word.begins_with("mult"):
			hex = BB_MULT
		elif word.begins_with("poder") or word.begins_with("power") or word.begins_with("base"):
			hex = BB_POWER
		var num := m.get_string("num")
		if num != "":
			whole = whole.replace(num + " ", num + String.chr(0xA0))
		out += "[color=#%s]%s[/color]" % [hex, whole]
		pos = m.get_end()
	return out + bb.substr(pos)

static var _rx: RegEx
static func _color_regex() -> RegEx:
	if _rx == null:
		_rx = RegEx.new()
		# número (com +, −, ×) opcional, depois a palavra (com ou sem [url=n]…[/url] à volta).
		_rx.compile("(?:(?<num>[+×x−-]?\\d+(?:[.,]\\d+)?) )?(?:\\[url=\\d+\\])?(?<word>Poder Base|Poder|base Power|Power|Mult)(?:\\[/url\\])?(?![A-Za-zÀ-ÿ])|\\[lb\\](?:\\[url=\\d+\\])?(?<word2>Na Mão|In Hand)(?:\\[/url\\])?\\]")
	return _rx

func _queue_layout() -> void:
	if _layout_queued:
		return
	_layout_queued = true
	_layout.call_deferred()

## 0.14.1: põe cada peça no sítio, a partir do tamanho real da carta (as medidas são as do desenho, para
## 130×186, e escalam com a altura): ilustração a toda a largura em cima (53 %; 46 % com o texto grande),
## nome e esfera do custo por cima dela, pips por baixo da esfera, palavras-chave em coluna à esquerda,
## pílula do tipo a meio da linha onde a arte acaba, texto por baixo e as pílulas do Poder e da Vida.
func _layout() -> void:
	_layout_queued = false
	if card == null or not is_node_ready() or _face_front == null:
		return
	var W := size.x
	var H := size.y
	if W < 20.0 or H < 20.0:
		return
	var d := card.data
	var u := H / BASE_H
	_u = u
	var big := Settings.large_text
	var bw := float(_style.border_width_left) if _style != null else 2.0
	var R := float(_style.corner_radius_top_left) if _style != null else 11.0
	_apply_fonts()
	# Zona da arte.
	var art := Rect2(bw, bw, W - 2.0 * bw, roundf((86.0 if big else 98.0) * u))
	art_slot.position = art.position
	art_slot.size = art.size
	var pad := 7.0 * u
	# Esfera do custo, em cima à direita.
	var od := roundf(22.0 * u)
	var orb := Rect2(W - bw - 4.0 * u - od, bw + 4.0 * u, od, od)
	CardView._center_in(cost_label, orb)
	# Nome por cima da arte, à esquerda da esfera.
	var name_x := bw + pad
	var name_w := maxf(10.0, orb.position.x - 3.0 * u - name_x)
	_fit_name(name_w)
	name_label.position = Vector2(name_x, bw + 4.0 * u)
	name_label.size = Vector2(name_w, _name_h)
	# Pips por baixo da esfera (fora do modo daltónico, desenhados pela frente da carta).
	var pip_rects: Array[Rect2] = []
	var pip_cols: Array[Color] = []
	var pip_cx := W - bw - 11.5 * u
	var pip_y := orb.end.y + 3.0 * u
	if pips_box.get_child_count() > 0:
		var s := roundf(14.0 * u)
		var i := 0
		for p in pips_box.get_children():
			var pc := p as Control
			if pc == null or pc.is_queued_for_deletion():
				continue
			pc.custom_minimum_size = Vector2(s, s)
			pc.position = Vector2(pip_cx - s * 0.5, pip_y + i * (s + 1.0 * u))
			pc.size = Vector2(s, s)
			i += 1
	elif d.colors.size() >= 2:
		var pd := 7.0 * u
		for i in d.colors.size():
			pip_rects.append(Rect2(pip_cx - pd * 0.5, pip_y + i * (pd + 2.0 * u), pd, pd))
			pip_cols.append(CardFace.palette(String(d.colors[i])).get("pip", Color.WHITE))
	# Palavras-chave em coluna à esquerda, por baixo do nome (com um disco escuro por trás).
	var kw_rects: Array[Rect2] = []
	var ks := roundf(13.0 * u)
	var ky := name_label.position.y + _name_h + 4.0 * u
	var ki := 0
	for ic in _kw_box.get_children():
		var c := ic as Control
		if c == null or c.is_queued_for_deletion():
			continue
		c.custom_minimum_size = Vector2(ks, ks)
		c.position = Vector2(bw + 6.0 * u, ky + ki * (ks + 6.0 * u))
		c.size = Vector2(ks, ks)
		kw_rects.append(Rect2(c.position, c.size))
		ki += 1
	# Pílula do tipo: centrada, a meio da linha onde a arte acaba.
	var ph := roundf(14.0 * u)
	var pcy := art.end.y - 2.0 * u
	var icon_s := roundf(8.0 * u)
	var gem_col: Color = CardFace.RARITY_GEM.get(d.rarity, Color(1, 1, 1, 0))
	var gem_half := 3.5 * u if gem_col.a > 0.0 else 0.0
	var gem_w := (2.0 * u + gem_half * 2.0) if gem_half > 0.0 else 0.0
	var max_pill := W - 2.0 * bw - 8.0 * u
	var text_w := _fit_type(max_pill - 14.0 * u - icon_s - 3.0 * u - gem_w)
	var pill_w := 14.0 * u + icon_s + 3.0 * u + text_w + gem_w
	var pill := Rect2(W * 0.5 - pill_w * 0.5, pcy - ph * 0.5, pill_w, ph)
	var icon_r := Rect2(pill.position.x + 7.0 * u, pcy - icon_s * 0.5, icon_s, icon_s)
	CardView._center_in(type_label, Rect2(icon_r.end.x + 3.0 * u, pill.position.y, text_w, ph))
	var gem_r := Rect2()
	if gem_half > 0.0:
		gem_r = Rect2(Vector2(type_label.position.x + text_w + 2.0 * u, pcy - gem_half), Vector2(gem_half, gem_half) * 2.0)
	# Pílulas de baixo.
	var bh := roundf((22.0 if big else 20.0) * u)
	var by := H - bw - 4.0 * u - bh
	var left_x := bw + 4.0 * u
	var right_x := W - bw - 4.0 * u
	var power_r := Rect2()
	var power_icon := Rect2()
	var land_r := Rect2()
	var tough_r := Rect2()
	var tough_icon := Rect2()
	_fit_bottom_row(W - 2.0 * bw - 8.0 * u, u)
	if d.is_land():
		var lw := _text_width(stats_label)
		land_r = Rect2(left_x, by, lw + 14.0 * u, bh)
		CardView._center_in(stats_label, Rect2(left_x + 7.0 * u, by, lw, bh))
	elif stats_label.text != "":
		var sw := _text_width(stats_label)
		var isz := roundf(9.0 * u)
		power_r = Rect2(left_x, by, 6.0 * u + sw + 2.0 * u + isz + 6.0 * u, bh)
		CardView._center_in(stats_label, Rect2(left_x + 6.0 * u, by, sw, bh))
		power_icon = Rect2(left_x + 6.0 * u + sw + 2.0 * u, by + (bh - isz) * 0.5, isz, isz)
	if tough_label.text != "":
		var tw := _text_width(tough_label)
		var hsz := roundf(8.0 * u)
		var tpw := 6.0 * u + tw + 2.0 * u + hsz + 6.0 * u
		tough_r = Rect2(right_x - tpw, by, tpw, bh)
		CardView._center_in(tough_label, Rect2(tough_r.position.x + 6.0 * u, by, tw, bh))
		tough_icon = Rect2(tough_r.position.x + 6.0 * u + tw + 2.0 * u, by + (bh - hsz) * 0.5, hsz, hsz)
	# Selo e sinergia ao lado do Poder; o ganho (delta) ao meio do espaço que sobra.
	var mid_x := maxf(power_r.end.x, land_r.end.x) if (power_r.size.x > 0.0 or land_r.size.x > 0.0) else left_x - 3.0 * u
	var isz2 := roundf(15.0 * u)
	if seal_slot.visible:
		seal_slot.position = Vector2(mid_x + 3.0 * u, by + (bh - isz2) * 0.5)
		seal_slot.size = Vector2(isz2, isz2)
		if _seal_icon != null:
			_seal_icon.custom_minimum_size = Vector2(isz2, isz2)
		mid_x = seal_slot.position.x + isz2
	if _synergy != null and is_instance_valid(_synergy):
		_synergy.custom_minimum_size = Vector2(isz2, isz2)
		_synergy.position = Vector2(mid_x + 3.0 * u, by + (bh - isz2) * 0.5)
		_synergy.size = Vector2(isz2, isz2)
		mid_x = _synergy.position.x + isz2
	var end_x := tough_r.position.x if tough_r.size.x > 0.0 else right_x
	CardView._center_in(delta_label, Rect2(mid_x + 2.0 * u, by, maxf(4.0, end_x - mid_x - 4.0 * u), bh))
	# Texto entre a pílula do tipo e as de baixo.
	var ty := pill.end.y + 4.0 * u
	text_label.position = Vector2(bw + pad, ty)
	text_label.size = Vector2(maxf(10.0, W - 2.0 * (bw + pad)), maxf(8.0, by - ty))
	_fit_text()
	# As duas camadas desenhadas.
	var unknown := has_meta("unknown")
	for f in [_face_back, _face_front]:
		var face := f as CardFace
		face.visible = not unknown
		face.position = Vector2.ZERO
		face.size = size
		face.card_size = size
		face.radius = R
		face.border_width = bw
		face.keys = _keys
		face.bg_top = _bgs[0]
		face.bg_bottom = _bgs[1]
		face.texture = _tex
		face.art_rect = art
		face.art_radius = maxf(0.0, R - bw)
		face.art_tint = (CardFace.palette(_keys[0])["border"] as Color).darkened(0.5)
		face.queue_redraw()
	var ff := _face_front
	ff.gradient_border = _keys.size() >= 2 and d.rarity != "mythic" and _frame_anim == ""
	ff.ring_color = CardFace.RARITY_RING.get(d.rarity, Color(1, 1, 1, 0))
	ff.ring_width = maxf(1.0, roundf(u))
	ff.orb_rect = orb
	ff.orb_glow = not Settings.performance_mode
	ff.pip_rects = pip_rects
	ff.pip_colors = pip_cols
	ff.pill_rect = pill
	ff.pill_color = CardFace.PILL.get(CardView.type_key(d), CardFace.PILL["creature"])
	ff.pill_icon = "creature" if d.token else CardView.type_key(d)
	ff.pill_icon_rect = icon_r
	ff.gem_rect = gem_r
	ff.gem_color = gem_col
	ff.gem_glow = d.rarity == "rare" or d.rarity == "mythic"
	ff.power_rect = power_r
	ff.vet_stars = card.vet_stars() if not d.is_land() else 0   # 0.15.0 Veteranos
	ff.power_icon_rect = power_icon
	ff.tough_rect = tough_r
	ff.tough_icon_rect = tough_icon
	ff.land_rect = land_r
	ff.kw_rects = kw_rects
	if _sigil != null:
		_sigil.size = art_slot.size
	if _land_art != null:
		_land_art.size = art_slot.size

## Põe um Label centrado num retângulo (se o tamanho mínimo da letra for maior do que o retângulo, o Label
## fica maior mas com o mesmo centro: o número não desce na esfera nem nas pílulas).
static func _center_in(l: Control, r: Rect2) -> void:
	l.size = r.size
	l.position = (r.get_center() - l.size * 0.5).round()

## Largura do texto de um Label com a letra e o tamanho que tem agora.
static func _text_width(l: Label) -> float:
	var f := l.get_theme_font("font")
	if f == null:
		return 10.0
	return ceilf(f.get_string_size(l.text, HORIZONTAL_ALIGNMENT_LEFT, -1, l.get_theme_font_size("font_size")).x) + 1.0

## Tamanhos das letras (as medidas do desenho para a carta normal, a escalar com ela; texto grande nas
## Configurações aumenta-as).
func _apply_fonts() -> void:
	var u := _u
	var big := Settings.large_text
	_text_fs = maxi(6, roundi((12.0 if big else 10.0) * u))
	text_label.add_theme_font_size_override("normal_font_size", _text_fs)
	cost_label.add_theme_font_size_override("font_size", maxi(6, roundi(13.0 * u)))
	var land := card != null and card.data.is_land()
	var num_fs := maxi(6, roundi(((10.0 if big else 9.0) if land else (14.0 if big else 12.0)) * u))
	stats_label.add_theme_font_size_override("font_size", num_fs)
	tough_label.add_theme_font_size_override("font_size", num_fs)
	delta_label.add_theme_font_size_override("font_size", maxi(6, roundi((11.0 if big else 10.0) * u)))

## Moldura cosmética escolhida nas Configurações (só nas cartas comuns).
func _apply_frame(style: StyleBoxFlat) -> void:
	var f := CardDB.get_cosmetic("frame", Settings.card_frame)
	var hex := String(f.get("color", ""))
	_frame_anim = ""
	if Settings.card_frame == "classic" or hex == "":
		return
	_frame_anim = String(f.get("anim", ""))
	_frame_color = Color(hex)
	style.set_border_width_all(3 if Settings.card_frame == "stone" else 2)
	style.border_color = Color(hex)
	if Settings.card_frame == "neon":
		style.shadow_color = Color(Color(hex), 0.5)
		style.shadow_size = 4
		style.shadow_offset = Vector2.ZERO
	elif Settings.card_frame == "royal":
		style.border_width_top = 4
		style.border_width_bottom = 4

var _mirror_tag: Control

## Espelho Vivo: a criatura copiada fica prateada, com a etiqueta ESPELHO (no próximo ataque não dá
## Poder base).
func set_mirrored(on: bool) -> void:
	if _tag_kind == "jail" and not on:
		return   # a etiqueta de presa manda (o Carcereiro e o Espelho não aparecem juntos)
	_set_tag("mirror" if on else "", tr("ESPELHO"), Color(0.55, 0.65, 0.85, 0.94), Color(0.78, 0.86, 1.0))   # fundo prateado

## 0.12.0 Carcereiro: criatura presa no ataque seguinte (moldura cinzenta e etiqueta PRESA).
func set_jailed(on: bool) -> void:
	if _tag_kind == "mirror" and not on:
		return
	_set_tag("jail" if on else "", tr("PRESA"), Color(0.45, 0.42, 0.5, 0.95), Color(0.62, 0.6, 0.66))

var _tag_kind := ""

## Etiqueta a meio da carta (ESPELHO, PRESA) e a cor da moldura; kind "" tira-a.
func _set_tag(kind: String, text: String, bg: Color, frame_tint: Color) -> void:
	self_modulate = frame_tint if kind != "" else Color.WHITE   # só a moldura, não o texto
	if kind == "":
		if _mirror_tag != null:
			_mirror_tag.queue_free()
			_mirror_tag = null
		_tag_kind = ""
		return
	if _mirror_tag != null and _tag_kind == kind:
		return
	if _mirror_tag != null:
		_mirror_tag.queue_free()
	_tag_kind = kind
	# O PanelContainer estica os filhos: a etiqueta vai dentro de um Control simples do tamanho da carta.
	var holder := Control.new()
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(holder)
	var tag := PanelContainer.new()
	tag.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tag.add_theme_stylebox_override("panel", UiKit.flat(bg, 6, Color(1, 1, 1, 0.8), 1, 3))
	var l := UiKit.label(text, 13, Color(0.08, 0.1, 0.18) if kind == "mirror" else Color(1, 1, 1))
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tag.add_child(l)
	holder.add_child(tag)
	tag.anchor_left = 0.5
	tag.anchor_right = 0.5
	tag.anchor_top = 0.44
	tag.anchor_bottom = 0.44
	tag.offset_left = -46
	tag.offset_right = 46
	_mirror_tag = holder

## Nevoeiro: carta na mão durante a batalha contra a Bruxa do Nevoeiro.
func is_fogged() -> bool:
	return fog_hand and card != null and card.zone == CardInstance.Zone.HAND

## Terrenos sem ilustração: paisagem da cor na zona da arte (em vez do sigilo).
func _refresh_land_art(d: CardData, has_art: bool = false) -> void:
	if not d.is_land() or has_art:
		if _land_art != null:
			_land_art.visible = false
		return
	if _land_art == null:
		_land_art = LandArt.new()
		_land_art.window = Rect2(0.05, 0.24, 0.9, 0.7)
		art_slot.add_child(_land_art)
	_land_art.visible = true
	_land_art.card_id = d.id
	_land_art.colors = d.colors.duplicate()
	_land_art.ink = Color(LIGHT_TEXT, 0.3)
	_land_art.size = art_slot.size

## Ilustração (0.12.0; 0.14.1: a toda a largura em cima, com a cor toda). Sem ilustração (Coleção,
## Construtor, ilustrações desligadas) a zona fica na cor da carta, com o sigilo ou a paisagem.
## Devolve se há ilustração.
func _refresh_art(d: CardData) -> bool:
	_tex = ArtLib.texture("card", d.id) if art_on and not has_meta("unknown") else null
	return _tex != null

## Há ilustração na carta?
func has_art() -> bool:
	return _tex != null

## Ícones das palavras-chave, em coluna à esquerda, por baixo do nome (o texto completo está no zoom).
func _refresh_keywords(d: CardData) -> void:
	for c in _kw_box.get_children():
		_kw_box.remove_child(c)
		c.queue_free()
	if is_fogged():
		return
	var kws: Array = card.keywords() if card != null and card.data == d else d.keywords
	for k in kws:
		var spent: bool = k == "persist" and card != null and card.persisted   # 0.15.0: Persistir já usado
		var ic := CardIcon.new(String(k), Color(1, 1, 1, 0.35 if spent else 0.95), 13.0)
		ic.tooltip_text = tr(String(CardData.KEYWORD_NAMES.get(k, k)))
		ic.set_meta("kw", String(k))
		_kw_box.add_child(ic)

## 0.13.0: palavra-chave cujo ícone está debaixo deste ponto do ecrã (com folga para o dedo); {} se nenhuma.
func keyword_at(global_pos: Vector2) -> Dictionary:
	if _kw_box == null or not is_instance_valid(_kw_box):
		return {}
	for ic in _kw_box.get_children():
		var c := ic as Control
		if c == null or c.is_queued_for_deletion() or not c.has_meta("kw"):
			continue
		var r := c.get_global_rect()
		if r.grow(10.0).has_point(global_pos):
			return {"kw": String(c.get_meta("kw")), "rect": r}
	return {}

## Sigilo da carta na zona da arte, quando não há ilustração (Coleção, Construtor).
func _refresh_sigil(d: CardData, has_art: bool) -> void:
	if has_art or d.is_land():
		if _sigil != null:
			_sigil.visible = false
		return
	if _sigil == null:
		_sigil = CardSigil.new()
		_sigil.mouse_filter = Control.MOUSE_FILTER_IGNORE
		art_slot.add_child(_sigil)
	_sigil.visible = true
	_sigil.card_id = d.id
	_sigil.colors = d.colors.duplicate()
	var main: Color = CardFace.palette(CardFace.color_keys(d)[0])["border"]
	_sigil.ink = Color(main.lerp(Color.WHITE, 0.25), 0.42)
	_sigil.line_width = 1.4
	_sigil.size = art_slot.size

## Míticas: a moldura vai mudando de cor (lume → ouro → magenta).
func _process(delta: float) -> void:
	if _lethal:
		_lethal_t += delta
		_lethal_acc += delta
		if _lethal_acc >= 1.0 / 24.0:
			_lethal_acc = 0.0
			queue_redraw()
	if _style == null or card == null:
		if not _lethal:
			set_process(false)
		return
	if card.data.rarity != "mythic":
		if _frame_anim == "" or not frame_anim_on:
			if not _lethal:
				set_process(false)
			return
		_animate_frame(delta)
		return
	_mythic_t += delta * 0.8
	var n := MYTHIC_COLORS.size()
	var i := int(_mythic_t) % n
	var t: float = _mythic_t - floorf(_mythic_t)
	_style.border_color = (MYTHIC_COLORS[i] as Color).lerp(MYTHIC_COLORS[(i + 1) % n], t)

## Molduras animadas: twinkle (cintila), shimmer (brilho dourado a correr), flicker (relâmpagos),
## pulse (respira) e rainbow (arco-íris).
func _animate_frame(delta: float) -> void:
	_mythic_t += delta
	var c := _frame_color
	match _frame_anim:
		"twinkle":
			c = c.lerp(Color.WHITE, 0.5 + 0.5 * sin(_mythic_t * 5.0 + float(get_instance_id() % 7)))
		"shimmer":
			c = c.lightened(0.35 * (0.5 + 0.5 * sin(_mythic_t * 3.0)))
		"flicker":
			c = c.lerp(Color(0.95, 0.95, 1.0), 1.0 if fmod(_mythic_t * 3.3 + float(get_instance_id() % 5), 2.6) < 0.12 else 0.0)
		"pulse":
			c = Color(c, 0.45 + 0.55 * (0.5 + 0.5 * sin(_mythic_t * 2.2)))
		"rainbow":
			c = Color.from_hsv(fmod(_mythic_t * 0.25, 1.0), 0.55, 1.0)
	_style.border_color = c

## Brilho holográfico (raras e faces viradas): um ColorRect com o shader por cima do conteúdo.
func _refresh_foil(on: bool) -> void:
	if on and _foil == null:
		_foil = ColorRect.new()
		_foil.material = CardView.foil_material()
		_foil.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(_foil)
	elif not on and _foil != null:
		_foil.queue_free()
		_foil = null

## 0.13.0: mestria — medalha na borda de baixo (bronze, prata, ouro); com Ouro, as comuns e incomuns ganham
## a moldura dourada que brilha.
func _refresh_mastery(d: CardData) -> void:
	var lv := GameState.card_mastery(d.id) if mastery_on and not d.token and not d.is_curse() else 0
	if lv <= 0:
		if _mastery_badge != null:
			_mastery_badge.queue_free()
			_mastery_badge = null
		return
	if lv >= GameState.MASTERY_PLAYS.size() and d.rarity != "rare" and d.rarity != "mythic" and _style != null:
		_style.set_border_width_all(3)
		_style.border_color = GameState.MASTERY_COLORS[2]
		_frame_anim = "shimmer"
		_frame_color = GameState.MASTERY_COLORS[2]
		set_process(frame_anim_on and Settings.motion_ok() and not Settings.performance_mode)
	if _mastery_badge == null:
		_mastery_badge = Control.new()
		_mastery_badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(_mastery_badge)
		var badge := _mastery_badge
		badge.draw.connect(func(): CardView._draw_mastery(badge, int(badge.get_meta("lv", 1)), float(_style.content_margin_bottom) if _style != null else 0.0))
	else:
		move_child(_mastery_badge, get_child_count() - 1)
	_mastery_badge.set_meta("lv", lv)
	_mastery_badge.tooltip_text = tr("Mestria %s") % tr(GameState.MASTERY_NAMES[lv - 1])
	_mastery_badge.queue_redraw()

## No meio da borda de baixo (o canto de cima à esquerda é dos números de ordem na Arena).
static func _draw_mastery(c: Control, lv: int, bottom: float) -> void:
	var col: Color = GameState.MASTERY_COLORS[clampi(lv - 1, 0, 2)]
	var ctr := Vector2(c.size.x * 0.5, c.size.y + bottom)
	c.draw_circle(ctr + Vector2(1, 2), 9.0, Color(0, 0, 0, 0.45))
	c.draw_circle(ctr, 9.0, Color(0.12, 0.09, 0.2, 0.96))
	c.draw_arc(ctr, 9.0, 0.0, TAU, 24, col, 2.0, true)
	var pts := PackedVector2Array()
	for k in 10:
		var a := -PI / 2.0 + TAU * k / 10.0
		pts.append(ctr + Vector2(cos(a), sin(a)) * (5.6 if k % 2 == 0 else 2.4))
	c.draw_colored_polygon(pts, col)

## 0.13.0: edição da carta — brilho próprio por cima (sem o das raras) e uma pedra na borda de cima.
func _refresh_edition(ed: String) -> void:
	var on := EffectResolver.EDITIONS.has(ed)
	if on and not Settings.performance_mode:
		if _edition_fx == null:
			_edition_fx = ColorRect.new()
			_edition_fx.mouse_filter = Control.MOUSE_FILTER_IGNORE
			add_child(_edition_fx)
		_edition_fx.material = CardView.edition_material(ed)
	elif _edition_fx != null:
		_edition_fx.queue_free()
		_edition_fx = null
	if not on:
		if _edition_gem != null:
			_edition_gem.queue_free()
			_edition_gem = null
		return
	if _edition_gem == null:
		_edition_gem = Control.new()
		_edition_gem.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(_edition_gem)
		var gem := _edition_gem
		gem.draw.connect(func(): CardView._draw_edition_gem(gem, String(gem.get_meta("ed", "")), -float(_style.content_margin_top) if _style != null else 0.0))
	else:
		move_child(_edition_gem, get_child_count() - 1)
	_edition_gem.set_meta("ed", ed)
	_edition_gem.tooltip_text = EffectResolver.edition_text(ed)
	_edition_gem.queue_redraw()

## Pedra da edição: losango no meio da borda de cima (Policromática = quatro cores).
static func _draw_edition_gem(c: Control, ed: String, top: float) -> void:
	if not EffectResolver.EDITIONS.has(ed):
		return
	var ctr := Vector2(c.size.x * 0.5, top)
	var r := 8.0
	var pts := PackedVector2Array([ctr + Vector2(0, -r), ctr + Vector2(r, 0), ctr + Vector2(0, r), ctr + Vector2(-r, 0)])
	c.draw_colored_polygon(PackedVector2Array([pts[0] + Vector2(1, 2), pts[1] + Vector2(1, 2), pts[2] + Vector2(1, 2), pts[3] + Vector2(1, 2)]), Color(0, 0, 0, 0.45))
	if ed == "poly":
		var cols := [Color(1.0, 0.4, 0.4), Color(1.0, 0.9, 0.35), Color(0.4, 0.95, 0.6), Color(0.45, 0.6, 1.0)]
		for i in 4:
			c.draw_colored_polygon(PackedVector2Array([ctr, pts[i], pts[(i + 1) % 4]]), cols[i])
	else:
		c.draw_colored_polygon(pts, EffectResolver.edition_color(ed))
	c.draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[3], pts[0]]), Color(0.1, 0.08, 0.16), 1.6, true)
	c.draw_line(ctr + Vector2(-3.5, -2.5), ctr + Vector2(0, -5.5), Color(1, 1, 1, 0.85), 1.6, true)

## O nome fica numa linha e encolhe até caber (até 80 % do tamanho); se ainda não couber (nomes muito
## compridos), passa a duas linhas.
func _fit_name(avail: float) -> void:
	var base_fs := maxi(6, roundi((13.0 if Settings.large_text else 11.0) * _u))
	set_meta("name_fs", base_fs)
	var font := name_label.get_theme_font("font")
	var fs := base_fs
	var floor_fs := maxi(6, roundi(base_fs * 0.8))
	while fs > floor_fs and font != null and font.get_string_size(name_label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x > avail:
		fs -= 1
	var two_lines := font != null and font.get_string_size(name_label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x > avail
	name_label.add_theme_font_size_override("font_size", fs)
	name_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART if two_lines else TextServer.AUTOWRAP_OFF
	name_label.max_lines_visible = 2 if two_lines else -1
	var line_h := font.get_height(fs) if font != null else fs * 1.3
	_name_h = ceilf(line_h * (2.0 if two_lines else 1.0) + (name_label.get_theme_constant("line_spacing") if two_lines else 0.0)) + 1.0

## Texto da pílula do tipo: tudo ("Criatura · Dragão · ↺"); se não couber, sem o espaço extra entre letras;
## depois só a tribo ("Dragão · ↺"); depois letra mais pequena (até 6). Devolve a largura do texto.
func _fit_type(avail: float) -> float:
	var fs := maxi(6, roundi((9.0 if Settings.large_text else 8.0) * _u))
	var spaced := CardView.type_font()
	var plain: Font = spaced.base_font if spaced.base_font != null else spaced
	var texts: Array[String] = [_type_full]
	if _type_short != "" and _type_short != _type_full:
		texts.append(_type_short)
	var pick_text := texts[texts.size() - 1]
	var pick_font: Font = plain
	var found := false
	for f in [spaced, plain]:
		for t in texts:
			if (f as Font).get_string_size(t.to_upper(), HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x <= avail:
				pick_text = t
				pick_font = f
				found = true
				break
		if found:
			break
	if not found:
		var floor_fs := mini(fs, 6)
		while fs > floor_fs and plain.get_string_size(pick_text.to_upper(), HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x > avail:
			fs -= 1
	type_label.text = pick_text
	type_label.add_theme_font_override("font", pick_font)
	type_label.add_theme_font_size_override("font_size", fs)
	var w := ceilf(pick_font.get_string_size(pick_text.to_upper(), HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x) + 1.0
	return clampf(w, 4.0, maxf(4.0, avail))

## O texto encolhe (até 2 pontos) para caber na caixa; se mesmo assim não couber, mostra só as linhas
## inteiras (o texto todo está na carta em grande).
func _fit_text() -> void:
	if text_label == null or text_label.size.y < 4.0 or text_label.size.x < 4.0:
		return
	text_label.visible_characters = -1
	var fs := _text_fs
	text_label.add_theme_font_size_override("normal_font_size", fs)
	var floor_fs := maxi(6, _text_fs - 2)
	while fs > floor_fs and text_label.get_content_height() > text_label.size.y + 0.5:
		fs -= 1
		text_label.add_theme_font_size_override("normal_font_size", fs)
	if text_label.get_content_height() <= text_label.size.y + 0.5:
		return
	# Ainda não cabe: esconde a partir da primeira linha que ficaria cortada.
	var lines := text_label.get_line_count()
	var fit := 0
	for i in lines:
		var bottom_y := text_label.get_line_offset(i + 1) if i + 1 < lines else float(text_label.get_content_height())
		if bottom_y > text_label.size.y + 0.5:
			break
		fit = i + 1
	var total := text_label.get_total_character_count()
	var cut := total
	for ch in total:
		if text_label.get_character_line(ch) >= fit:
			cut = ch
			break
	text_label.visible_characters = maxi(0, cut)

## Números muito grandes (Poder de milhares) não podem fazer as duas pílulas passar da largura da carta:
## encolhem até caber.
func _fit_bottom_row(avail: float, u: float) -> void:
	if card == null or card.data.is_land():
		return
	var fs := stats_label.get_theme_font_size("font_size")
	var floor_fs := maxi(6, roundi(8.0 * u))
	while fs > floor_fs:
		var need := 0.0
		if stats_label.text != "":
			need += 14.0 * u + _text_width(stats_label) + 9.0 * u
		if tough_label.text != "":
			need += 14.0 * u + _text_width(tough_label) + 8.0 * u
		if need + 6.0 * u <= avail:
			break
		fs -= 1
		stats_label.add_theme_font_size_override("font_size", fs)
		tough_label.add_theme_font_size_override("font_size", fs)

## Carta ainda não descoberta (coleção): sem nome, texto nem toque.
func set_unknown() -> void:
	if not is_node_ready():
		await ready
	set_meta("unknown", true)
	name_label.text = "???"
	cost_label.text = "?"
	stats_label.text = ""
	tough_label.text = ""
	text_label.text = "[center]%s[/center]" % tr("Ainda não descoberta.")
	_tex = null
	if _face_back != null:
		_face_back.visible = false
		_face_front.visible = false
	_refresh_foil(false)
	set_process(false)
	if _sigil != null:
		_sigil.visible = false
	if _land_art != null:
		_land_art.visible = false
	# Costas da carta (cosmético escolhido) por cima de tudo; o painel fica neutro (não revela a cor).
	add_theme_stylebox_override("panel", UiKit.flat(Color(0.1, 0.09, 0.14), 11, Color(0, 0, 0, 0), 0, 0))
	var back := CardBack.new()
	back.back_id = Settings.card_back
	back.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(back)
	modulate = Color(0.8, 0.8, 0.85)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _refresh_delta() -> void:
	if delta == 0:
		delta_label.text = ""
		return
	delta_label.text = ("+" if delta > 0 else "−") + Cascade.fmt_short(absi(delta))   # 0.15.0: 1,2 M no Infinito
	delta_label.add_theme_color_override("font_color", DELTA_UP if delta > 0 else DELTA_DOWN)

func _notification(what: int) -> void:
	match what:
		NOTIFICATION_RESIZED:
			pivot_offset = size / 2.0
		NOTIFICATION_MOUSE_EXIT, NOTIFICATION_SCROLL_BEGIN:
			# O dedo saiu da carta ou a lista começou a fazer scroll: cancela o toque (não o arrasto).
			# 0.12.1: se foi a carta que se mexeu (na mão sobe quando é tocada) e o dedo está quieto,
			# o toque continua — senão segurar nunca chegava a abrir a carta em grande.
			if _pressing and not _dragging:
				if what == NOTIFICATION_MOUSE_EXIT and _moved() <= DRAG_CANCEL:
					return
				_cancel_press()

## Quanto o dedo andou no ecrã desde que tocou.
func _moved() -> float:
	return (_last_global - _press_global).length()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouse:
		_last_global = (event as InputEventMouse).global_position
	if event is InputEventMouseMotion:
		if _dragging:
			drag_moved.emit(card, _last_global)
		elif _pressing and _moved() > DRAG_CANCEL:
			if draggable:
				_begin_drag()
			else:
				_cancel_press()
		elif _held and _long_fired and draggable and _moved() > DRAG_AFTER_LONG:
			_begin_drag()   # segurou (abriu em grande) e depois mexeu: pega na carta
		return
	if not (event is InputEventMouseButton) or event.button_index != MOUSE_BUTTON_LEFT:
		return
	accept_event()
	if event.pressed:
		_pressing = true
		_held = true
		_long_fired = false
		_press_pos = event.position
		_press_global = _last_global
		_press_feedback(true)
		_press_id += 1
		_start_long_press(_press_id)
	else:
		_held = false
		if _dragging:
			_dragging = false
			drag_ended.emit(card, _last_global)
			return
		# Conta como toque se o dedo largou em cima da carta ou quase não se mexeu (a carta pode ter subido).
		var inside := _has_point(event.position) or _moved() <= DRAG_CANCEL
		var was_pressing := _pressing
		_pressing = false
		_press_feedback(false)
		if was_pressing and inside and not _long_fired:
			var hit := keyword_at(_last_global) if keyword_taps else {}
			if not hit.is_empty():
				keyword_tapped.emit(card, String(hit["kw"]), hit["rect"])
			else:
				pressed.emit(card)

func _begin_drag() -> void:
	_pressing = false
	_press_id += 1   # cancela o toque longo
	_press_feedback(false)
	_dragging = true
	drag_started.emit(card, _last_global)

## 0.12.1: carta da mão escolhida — contorno dourado e "JOGAR" por cima (vermelho se agora não dá).
func set_selected(on: bool, can_play: bool = true) -> void:
	if _selected == on and _sel_playable == can_play:
		return
	_selected = on
	_sel_playable = can_play
	queue_redraw()

func is_selected() -> bool:
	return _selected

## 0.16.0 (60): brilho de letal — contorno dourado a pulsar (parado com movimento reduzido).
func set_lethal(on: bool) -> void:
	if _lethal == on:
		return
	_lethal = on
	_lethal_t = 0.0
	if on and Settings.motion_ok():
		set_process(true)
	queue_redraw()

func is_lethal() -> bool:
	return _lethal

## A etiqueta "JOGAR" (por cima da carta escolhida) também conta como a carta.
func _has_point(point: Vector2) -> bool:
	var r := Rect2(Vector2.ZERO, size)
	if _selected and _sel_playable and select_chip != "":
		r = r.grow_individual(0, 32, 0, 0)
	return r.has_point(point)

func _draw() -> void:
	if not _selected:
		if _lethal:
			var k := (0.5 + 0.5 * sin(_lethal_t * 5.5)) if Settings.motion_ok() else 0.7
			var gl := StyleBoxFlat.new()
			gl.draw_center = false
			gl.set_border_width_all(3)
			gl.border_color = Color(1.0, 0.85, 0.35, 0.55 + 0.45 * k)
			gl.set_corner_radius_all((_style.corner_radius_top_left if _style != null else 11) + 3)
			gl.shadow_color = Color(1.0, 0.78, 0.25, 0.25 + 0.4 * k)
			gl.shadow_size = int(8.0 + 8.0 * k)
			draw_style_box(gl, Rect2(Vector2(-4, -4), size + Vector2(8, 8)))
		return
	var col := UiKit.GOLD if _sel_playable else Color(0.92, 0.42, 0.38)
	var st := StyleBoxFlat.new()
	st.draw_center = false
	st.set_border_width_all(3)
	st.border_color = col
	st.set_corner_radius_all((_style.corner_radius_top_left if _style != null else 11) + 3)
	st.shadow_color = Color(col, 0.5)
	st.shadow_size = 10
	draw_style_box(st, Rect2(Vector2(-4, -4), size + Vector2(8, 8)))
	if not _sel_playable or select_chip == "":
		return
	var font := get_theme_font("font", "Label")
	var fs := 15
	var text := tr(select_chip)
	var tw := font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
	var chip := Rect2(Vector2((size.x - tw) / 2.0 - 10.0, -30.0), Vector2(tw + 20.0, 24.0))
	var cs := StyleBoxFlat.new()
	cs.bg_color = col
	cs.set_corner_radius_all(12)
	draw_style_box(cs, chip)
	draw_string(font, Vector2(chip.position.x + 10.0, chip.position.y + 18.0), text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(0.1, 0.07, 0.03))

func _start_long_press(id: int) -> void:
	await get_tree().create_timer(LONG_PRESS).timeout
	if id != _press_id or not _pressing or not is_inside_tree() or is_queued_for_deletion():
		return
	if _moved() > DRAG_CANCEL:
		return
	_long_fired = true
	_pressing = false
	_press_feedback(false)
	Settings.vibrate(25)
	long_pressed.emit(card)

func _cancel_press() -> void:
	_pressing = false
	_press_id += 1   # invalida o temporizador do toque longo
	_press_feedback(false)

func _press_feedback(down: bool) -> void:
	if not is_inside_tree() or is_queued_for_deletion():
		return
	pivot_offset = size / 2.0
	if has_meta("press_tw"):
		var old = get_meta("press_tw")
		if old is Tween and (old as Tween).is_valid():
			(old as Tween).kill()
	if not down:
		scale = Vector2.ONE   # imediato: a carta pode ser destruída já a seguir (jogada/canalizada)
		return
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector2(0.95, 0.95), 0.06)
	set_meta("press_tw", tw)
