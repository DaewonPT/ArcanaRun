class_name CardView
extends PanelContainer
## Representação visual de uma CardInstance (mão, tabuleiro, listas).
## Toque (carregar e largar em cima da carta) = `pressed`; manter o dedo = `long_pressed` (ver em grande).
## Um arrasto para fazer scroll cancela os dois. Toques no Android chegam como eventos de rato
## (emulate_mouse_from_touch) e o ScrollContainer avisa com NOTIFICATION_SCROLL_BEGIN quando arrasta.
## 0.10.0: sigilo da carta em marca de água (CardSigil), tribo/encantamento/Ficha/Reforço/Reação na
## linha do tipo, versão "+" no nome, moldura animada nas Míticas, molduras cosméticas e modo compacto.
## 0.11.0: faixa colorida com o tipo (Criatura, Feitiço, Mágica, Encantamento, Terreno, Maldição, Ficha);
## os Terrenos têm "+1" em vez do custo, uma paisagem em vez do sigilo e "jogar: +1 mana" em baixo;
## ícones das palavras-chave (Vigilância, Vínculo Vital, Proteção); Nevoeiro esconde o texto na mão.
## 0.14.0: visual "Vidro arcano" — vidro escuro com contorno e brilho néon na cor da carta (degradê nas de
## várias cores), custo num hexágono, ilustração numa janela com a cor toda, tipo em maiúsculas com o
## losango da raridade, Poder a azul e Mult a vermelho no texto, nomes que encolhem para caber e, em baixo,
## o Poder à esquerda e a Vida à direita. Os enfeites de vidro estão todos num nó (CardGlass).

signal pressed(card: CardInstance)
signal long_pressed(card: CardInstance)
signal drag_started(card: CardInstance, global_pos: Vector2)
signal drag_moved(card: CardInstance, global_pos: Vector2)
signal drag_ended(card: CardInstance, global_pos: Vector2)
signal keyword_tapped(card: CardInstance, keyword: String, at: Rect2)   # 0.13.0: tocou num ícone de palavra-chave

const LONG_PRESS := 0.42     # segundos com o dedo em cima para abrir em grande
const DRAG_CANCEL := 16.0    # px de movimento a partir dos quais o toque passa a ser scroll
const DRAG_AFTER_LONG := 28.0   # 0.12.1: depois de abrir em grande, mexer o dedo pega na carta (arrastar)

const COLORS := {
	"white": Color(0.93, 0.89, 0.74),
	"blue": Color(0.38, 0.56, 0.88),
	"black": Color(0.42, 0.36, 0.48),
	"red": Color(0.86, 0.36, 0.30),
	"green": Color(0.40, 0.66, 0.40),
	"colorless": Color(0.66, 0.66, 0.70),
}
const DARK_TEXT := Color(0.08, 0.08, 0.1)
const LIGHT_TEXT := Color(0.97, 0.97, 0.99)
## 0.14.0 ("Vidro arcano"): cores néon do contorno, do brilho e do custo (as de COLORS continuam nos pips,
## selos e no resto do jogo).
const NEON := {
	"white": Color(0.95, 0.89, 0.69),
	"blue": Color(0.36, 0.61, 0.94),
	"black": Color(0.65, 0.48, 0.88),
	"red": Color(1.0, 0.42, 0.29),
	"green": Color(0.35, 0.77, 0.42),
	"colorless": Color(0.72, 0.71, 0.78),
}
const CURSE_NEON := Color(0.82, 0.3, 0.56)
const GLASS_BG := Color(0.086, 0.063, 0.16)
const NAME_COLOR := Color(0.965, 0.95, 1.0)
const BODY_COLOR := Color(0.914, 0.894, 0.969)
const POWER_COLOR := Color(0.5, 0.85, 1.0)
const TOUGH_COLOR := Color(1.0, 0.48, 0.565)
const DELTA_UP := Color(0.494, 0.941, 0.627)
const DELTA_DOWN := Color(1.0, 0.45, 0.45)
## Cores das palavras no texto: Poder a azul, Mult a vermelho (como no placar) e [Na Mão] a dourado.
const BB_POWER := "5fd4ff"
const BB_MULT := "ff6b86"
const BB_HAND := "ffd27a"
## Losango da raridade (as comuns não têm).
const RARITY_GEM := {"uncommon": Color(0.84, 0.86, 0.92), "rare": Color(0.95, 0.76, 0.31), "mythic": Color(1.0, 0.54, 0.24)}
const SIZE_NORMAL := Vector2(130, 186)
const SIZE_COMPACT := Vector2(112, 160)
const MYTHIC_COLORS := [Color(1.0, 0.45, 0.2), Color(1.0, 0.82, 0.3), Color(0.95, 0.3, 0.55)]
const TRIBE_NAMES := {"goblin": "Goblin", "elf": "Elfo", "zombie": "Zombie", "angel": "Anjo", "dragon": "Dragão", "soldier": "Soldado",
	"construct": "Construto", "spirit": "Espírito", "beast": "Fera", "plant": "Planta"}
const FOIL_SHADER := preload("res://assets/shaders/foil.gdshader")
## Cor da faixa do tipo (o fundo da carta continua a ser a cor de mana).
const TYPE_RIBBON := {
	"creature": Color(0.5, 0.19, 0.14),
	"token": Color(0.34, 0.34, 0.4),
	"sorcery": Color(0.15, 0.29, 0.58),
	"instant": Color(0.39, 0.19, 0.58),
	"enchantment": Color(0.07, 0.43, 0.43),
	"land": Color(0.38, 0.28, 0.1),
	"curse": Color(0.17, 0.08, 0.17),
}

## Nevoeiro (Bruxa do Nevoeiro): o texto das cartas na mão fica escondido. Liga-o a batalha.
static var fog_hand := false

## Tipo para a faixa e para o ícone.
static func type_key(d: CardData) -> String:
	if d.token:
		return "token"
	return CardIcon.kind_for(d)

## Material partilhado por todos os brilhos holográficos (a inclinação muda-se uma vez para todos).
static var _foil_material: ShaderMaterial

static func foil_material() -> ShaderMaterial:
	if _foil_material == null:
		_foil_material = ShaderMaterial.new()
		_foil_material.shader = FOIL_SHADER
	return _foil_material

## 0.13.0: um material por edição (Brilhante, Holográfica, Policromática), partilhado pelas cartas.
static var _edition_materials := {}

static func edition_material(ed: String) -> ShaderMaterial:
	if not _edition_materials.has(ed):
		var m := ShaderMaterial.new()
		m.shader = FOIL_SHADER
		m.set_shader_parameter("mode", int(EffectResolver.EDITIONS[ed].get("mode", 0)))
		m.set_shader_parameter("strength", 0.3 if ed == "poly" else 0.26)
		_edition_materials[ed] = m
	return _edition_materials[ed]

## Inclinação do telemóvel (acelerómetro), chamada pelo SceneRouter a cada frame.
static func set_foil_tilt(t: Vector2) -> void:
	if _foil_material != null:
		_foil_material.set_shader_parameter("tilt", t)
	for m in _edition_materials.values():
		(m as ShaderMaterial).set_shader_parameter("tilt", t)

var card: CardInstance
var playable: bool = true:
	set(v):
		playable = v
		modulate.a = 1.0 if v else 0.45
var compact: bool = false
## 0.13.0: tamanho das cartas da mão (Configurações → Visual): multiplica o tamanho e as letras.
var size_scale: float = 1.0
var draggable: bool = false        # tabuleiro: arrastar reordena em vez de cancelar o toque
var keyword_taps: bool = false     # 0.13.0: tocar num ícone de palavra-chave explica-a (em vez do toque normal)
## Variação do total do ataque se esta carta for jogada (mão). 0 = não mostrar.
var delta: int = 0:
	set(v):
		delta = v
		if is_node_ready():
			_refresh_delta()

var _pressing: bool = false
var _press_pos := Vector2.ZERO
var _press_global := Vector2.ZERO   # 0.12.1: o movimento mede-se no ecrã (a carta da mão sobe debaixo do dedo)
var _last_global := Vector2.ZERO    # última posição do dedo no ecrã (dos eventos)
var _held: bool = false             # o dedo continua em baixo (do toque até largar)
var _press_id: int = 0
var _long_fired: bool = false
var _dragging: bool = false
var _selected: bool = false         # 0.12.1: carta da mão escolhida (contorno dourado e "JOGAR")
var _sel_playable: bool = true

@onready var name_label: Label = %Name
@onready var cost_label: Label = %Cost
@onready var stats_label: Label = %Stats          # Poder (ou "jogar: +1 mana" nos Terrenos)
@onready var tough_label: Label = %Tough          # 0.14.0: Vida, à direita
@onready var text_label: RichTextLabel = %Text    # 0.14.0: com cores (BBCode)
@onready var type_label: Label = %Type
@onready var delta_label: Label = %Delta
@onready var icon_slot: Control = %Icon
@onready var pips_box: HBoxContainer = %Pips
@onready var seal_slot: Control = %Seal
@onready var type_row: PanelContainer = %TypeRow
@onready var art_slot: Control = %ArtSlot
@onready var gem_slot: Control = %Gem
var _glass: CardGlass
var _glass_queued := false
var _neon: Array[Color] = []
var _text_fs := 11          # tamanho do texto antes de encolher para caber
var _kf := 1.0              # 0.14.0: escala das letras (tamanho da carta face ao normal)
static var _type_font: FontVariation
var _icon: CardIcon
var _seal_icon: CardIcon
var _foil: ColorRect
var _sigil: CardSigil
var _style: StyleBoxFlat
var _mythic_t := 0.0
## 0.12.0: molduras animadas (cosmético) — só se animam na batalha (a Coleção tem centenas de cartas).
static var frame_anim_on := false
## 0.12.0: ilustrações (assets/art/cards). A Coleção e o Construtor desligam-nas (centenas de cartas de uma
## vez gastariam memória a mais); lá vêem-se na carta em grande.
static var art_on := true
var _art: CardArt
var _frame_anim := ""
var _frame_color := Color.WHITE
var _synergy: CardIcon
var _land_art: LandArt
var _kw_box: HBoxContainer
var _edition_fx: ColorRect     # 0.13.0: brilho da edição por cima da carta
var _edition_gem: Control      # 0.13.0: pedra da edição no meio da borda de cima
var _mastery_badge: Control    # 0.13.0: medalha da mestria (meio da borda de baixo)
## 0.13.0: a mestria (jogadas em todas as runs) só aparece onde faz sentido (batalha, baralho, coleção).
static var mastery_on := true

## Marca de sinergia (elos dourados no canto): a carta combina com o baralho (loja, draft).
func set_synergy(reason: String) -> void:
	if reason == "":
		if _synergy != null:
			_synergy.queue_free()
			_synergy = null
		return
	if _synergy == null:
		_synergy = CardIcon.new("chain", UiKit.GOLD, 22.0)
		_synergy.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		var bottom := seal_slot.get_parent()
		bottom.add_child(_synergy)
		bottom.move_child(_synergy, 0)
	_synergy.tooltip_text = reason
	tooltip_text = TranslationServer.translate("Combina: %s") % reason

func setup(p_card: CardInstance) -> void:
	card = p_card
	if not is_node_ready():
		await ready
	refresh()

func refresh() -> void:
	var d := card.data
	if custom_minimum_size == SIZE_NORMAL or custom_minimum_size == SIZE_COMPACT or custom_minimum_size == Vector2.ZERO or has_meta("scaled_size"):
		var base := SIZE_COMPACT if Settings.compact else SIZE_NORMAL   # tamanhos à medida (draft, zoom) ficam
		custom_minimum_size = base if is_equal_approx(size_scale, 1.0) else (base * size_scale).round()
		if is_equal_approx(size_scale, 1.0):
			remove_meta("scaled_size")
		else:
			set_meta("scaled_size", true)
	name_label.text = d.display_name()
	cost_label.text = str(d.cost)
	tough_label.text = ""
	if d.is_creature():
		stats_label.text = "⚔ %d" % card.power()
		tough_label.text = "%d ♥" % card.remaining()
		type_label.text = tr("Ficha") if d.token else tr("Criatura")
		if d.tribe != "":
			# 0.14.0: na carta pequena, só a tribo (a espada já diz que é uma criatura; o zoom diz tudo).
			type_label.text = (tr("Ficha") + " · " if d.token else "") + tr(TRIBE_NAMES.get(d.tribe, d.tribe))
	elif d.is_enchantment():
		stats_label.text = ""
		type_label.text = tr("Encantamento")
	elif d.is_spell():
		stats_label.text = "⚔ %d" % card.power() if d.power > 0 else ""
		type_label.text = tr("Mágica") if d.subtype == "instant" else tr("Feitiço")
	elif d.is_curse():
		stats_label.text = ""
		type_label.text = tr("Maldição")
	else:
		stats_label.text = tr("jogar: +1 mana")
		type_label.text = tr("Terreno")
	# Marcadores: recapitular ↺, dupla face ⇄ (com progresso da missão), fusão ⚗, infeção ☠.
	if d.flashback:
		type_label.text += " · ↺"
	if card.has_mission():
		type_label.text += " · ⇄ %d/%d" % [card.mission_count, card.mission_target()]
	elif card.transformed:
		type_label.text += " · ⇄"
	if d.fused_text != "":
		type_label.text += " · ⚗"
	if d.infected:
		type_label.text += " · ☠ %d/%d" % [int(card.deck_entry.get("uses", 0)), BattleManager.INFECTED_USES]
	if d.has_kicker():
		type_label.text += " · ★" if card.kicked else " · +%d" % int(d.kicker.get("cost", 0))
	if BattleManager.has_reaction(card):
		type_label.text += " · ↯"
	var ed := card.edition()
	if EffectResolver.EDITIONS.has(ed):
		type_label.text += " · " + String(EffectResolver.EDITIONS[ed]["symbol"])
	var body := d.display_text() + ("  ≈" if d.approx else "")
	if d.fused_text != "":
		body += "\n⚗ " + tr(d.fused_text)
	text_label.text = "???" if is_fogged() else CardView.card_bbcode(body)
	if d.is_land():
		cost_label.text = "+1"   # jogar um Terreno é de graça e dá +1 mana para sempre
	# 0.14.0: vidro escuro com contorno e brilho néon nas cores da carta (degradê nas de várias cores).
	_neon = CardView.neon_colors(d)
	var main: Color = _neon[0] if _neon.size() == 1 else _neon[0].lerp(_neon[1], 0.5)
	var style := StyleBoxFlat.new()
	style.bg_color = GLASS_BG.lerp(Color(0.3, 0.3, 0.36), 0.25) if d.token else GLASS_BG
	style.set_corner_radius_all(12)
	var m := 5 if Settings.compact else 6
	style.content_margin_left = m
	style.content_margin_right = m
	style.content_margin_top = m - 1
	style.content_margin_bottom = m - 1
	style.set_border_width_all(2)
	style.border_color = main
	if not Settings.performance_mode:
		style.shadow_color = Color(main, 0.42)
		style.shadow_size = 7
	# Míticas: o contorno vai mudando de cor (lume → ouro → magenta) e brilham a laranja. A moldura
	# cosmética (Configurações → Visual) vale só para as comuns.
	_frame_anim = ""
	if d.rarity == "mythic":
		style.border_color = MYTHIC_COLORS[0]
		if not Settings.performance_mode:
			style.shadow_color = Color(1.0, 0.5, 0.25, 0.5)
			style.shadow_size = 9
	elif d.rarity == "common":
		_apply_frame(style)
	if d.plus:
		style.shadow_color = Color(0.55, 0.95, 0.6, 0.55)
		style.shadow_size = 7
	add_theme_stylebox_override("panel", style)
	_style = style
	set_process((d.rarity == "mythic" or (_frame_anim != "" and frame_anim_on)) and Settings.motion_ok() and not Settings.performance_mode)
	var text_color := LIGHT_TEXT
	var has_art := _refresh_art(d)
	_refresh_sigil(d, has_art)
	_refresh_land_art(d, text_color, has_art)
	name_label.add_theme_color_override("font_color", NAME_COLOR)
	name_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0))
	name_label.add_theme_constant_override("outline_size", 0)
	cost_label.add_theme_color_override("font_color", Color.WHITE)
	cost_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.5))
	cost_label.add_theme_constant_override("outline_size", 3)
	text_label.add_theme_color_override("default_color", BODY_COLOR)
	text_label.add_theme_constant_override("outline_size", 0)
	stats_label.add_theme_color_override("font_color", Color(0.72, 0.88, 1.0) if d.is_land() else POWER_COLOR)
	tough_label.add_theme_color_override("font_color", TOUGH_COLOR)
	# Linha do tipo: ícone e nome em maiúsculas na cor da carta (mais clara), sem faixa por trás.
	var tkey := type_key(d)
	var type_col: Color = (CURSE_NEON if d.is_curse() else main).lerp(Color.WHITE, 0.45)
	type_row.add_theme_stylebox_override("panel", StyleBoxEmpty.new())
	type_label.add_theme_font_override("font", CardView.type_font())
	type_label.add_theme_color_override("font_color", type_col)
	var icon_kind := "creature" if tkey == "token" else tkey
	if _icon == null:
		_icon = CardIcon.new(icon_kind, type_col, 10.0)
		_icon.set_anchors_preset(Control.PRESET_FULL_RECT)
		icon_slot.add_child(_icon)
	else:
		_icon.kind = icon_kind
		_icon.color = type_col
	# 0.12.0 (alto contraste): texto a branco puro com contorno preto.
	if Settings.high_contrast:
		for l in [name_label, cost_label, stats_label, tough_label, type_label]:
			l.add_theme_color_override("font_color", Color.WHITE)
			UiKit.outline_for(l, Color.WHITE, 3)
		text_label.add_theme_color_override("default_color", Color.WHITE)
		text_label.add_theme_color_override("font_outline_color", Color.BLACK)
		text_label.add_theme_constant_override("outline_size", 3)
	_refresh_keywords(d, text_color)
	for c in pips_box.get_children():
		pips_box.remove_child(c)
		c.queue_free()
	# Pips de cor nas multicolores; no modo daltónico também nas de uma cor (com símbolo).
	if d.colors.size() >= 2 or (Settings.colorblind and d.colors.size() == 1):
		for col in d.colors:
			if Settings.colorblind:
				var pip := CardIcon.new("pip", NEON.get(String(col), NEON.colorless), 13.0)
				pip.mana_color = String(col)   # com o símbolo da cor
				pips_box.add_child(pip)
			else:
				# Só o lugar: o círculo é desenhado pelo vidro (no mesmo comando que os outros enfeites).
				var slot := Control.new()
				slot.custom_minimum_size = Vector2(8, 8) * size_scale
				slot.mouse_filter = Control.MOUSE_FILTER_IGNORE
				slot.size_flags_vertical = Control.SIZE_SHRINK_CENTER
				slot.set_meta("pip", String(col))
				pips_box.add_child(slot)
	# Selo de guilda (emblema no canto inferior esquerdo).
	var seal_id := card.seal()
	if seal_id != "":
		var seal_def := CardDB.get_seal(seal_id)
		var seal_color: Color = COLORS.get(String(seal_def.get("color", "colorless")), COLORS.colorless)
		if _seal_icon == null:
			_seal_icon = CardIcon.new("seal", seal_color, 18.0)
			_seal_icon.set_anchors_preset(Control.PRESET_FULL_RECT)
			seal_slot.add_child(_seal_icon)
		else:
			_seal_icon.color = seal_color
		seal_slot.custom_minimum_size.x = 18
		seal_slot.visible = true
	else:
		seal_slot.visible = false
		seal_slot.custom_minimum_size.x = 0
	_apply_text_size()
	_refresh_delta()
	_refresh_foil((d.rarity == "rare" or d.rarity == "mythic" or d.is_back) and not Settings.performance_mode and not EffectResolver.EDITIONS.has(ed))
	_refresh_edition(ed)
	_refresh_mastery(d)
	pivot_offset = size / 2.0
	_queue_glass()

func _ready() -> void:
	# 0.14.0: os enfeites de vidro ficam por trás de tudo e só se redesenham quando a carta ou o layout mudam.
	_glass = CardGlass.new()
	_glass.name = "Glass"
	add_child(_glass)
	move_child(_glass, 0)
	for box in [$VBox, $VBox/Top, $VBox/TypeRow/TypeBox, $VBox/Bottom]:
		(box as Container).sort_children.connect(_queue_glass)
	text_label.resized.connect(_fit_text)

## Cores néon da carta: as das suas cores (até 3); Maldições a magenta; incolores a prateado.
static func neon_colors(d: CardData) -> Array[Color]:
	var out: Array[Color] = []
	if d.is_curse():
		out.append(CURSE_NEON)
		return out
	for col in d.colors:
		if out.size() < 3:
			out.append(NEON.get(String(col), NEON.colorless))
	if out.is_empty():
		out.append(NEON.colorless)
	if d.token:
		for i in out.size():
			out[i] = out[i].lerp(Color(0.8, 0.8, 0.86), 0.4)
	return out

## Letra do tipo: a Inter com um pouco mais de espaço entre letras (maiúsculas pequenas leem-se melhor).
static func type_font() -> FontVariation:
	if _type_font == null:
		_type_font = FontVariation.new()
		_type_font.base_font = ThemeDB.get_project_theme().default_font if ThemeDB.get_project_theme() != null else ThemeDB.fallback_font
		_type_font.spacing_glyph = 1
	return _type_font

## Texto da carta em BBCode, com Poder a azul, Mult a vermelho e [Na Mão] a dourado. O número junta-se à
## palavra com um espaço que não parte ("+5 Mult" nunca fica separado).
static func card_bbcode(text: String) -> String:
	return colorize_bbcode(text.replace("[", "[lb]"))

## Pinta as palavras do texto já em BBCode (aceita os [url] do glossário à volta das palavras).
static func colorize_bbcode(bb: String) -> String:
	var rx := _color_regex()
	var out := ""
	var pos := 0
	for m in rx.search_all(bb):
		out += bb.substr(pos, m.get_start() - pos)
		var whole := m.get_string()
		var hex := BB_HAND
		var word := m.get_string("word").to_lower()
		if word.begins_with("mult"):
			hex = BB_MULT
		elif word.begins_with("poder") or word.begins_with("power") or word.begins_with("base"):
			hex = BB_POWER
		var num := m.get_string("num")
		if num != "":
			whole = whole.replace(num + " ", num + String.chr(0xA0))
		out += "[color=#%s]%s[/color]" % [hex, whole]
		pos = m.get_end()
	return out + bb.substr(pos)

static var _rx: RegEx
static func _color_regex() -> RegEx:
	if _rx == null:
		_rx = RegEx.new()
		# número (com +, −, ×) opcional, depois a palavra (com ou sem [url=n]…[/url] à volta).
		_rx.compile("(?:(?<num>[+×x−-]?\\d+(?:[.,]\\d+)?) )?(?:\\[url=\\d+\\])?(?<word>Poder Base|Poder|base Power|Power|Mult)(?:\\[/url\\])?(?![A-Za-zÀ-ÿ])|\\[lb\\](?:\\[url=\\d+\\])?(?<word2>Na Mão|In Hand)(?:\\[/url\\])?\\]")
	return _rx

func _queue_glass() -> void:
	if _glass_queued or _glass == null:
		return
	_glass_queued = true
	_sync_glass.call_deferred()

## Retângulo de um nó da carta, nas coordenadas do painel (soma as posições até à carta).
func _rect_in_card(c: Control) -> Rect2:
	var p := Vector2.ZERO
	var n: Node = c
	while n != null and n != self:
		if n is Control:
			p += (n as Control).position
		n = n.get_parent()
	return Rect2(p, c.size)

## Põe os enfeites de vidro nos sítios certos (depois de o layout assentar).
func _sync_glass() -> void:
	_glass_queued = false
	if _glass == null or not is_instance_valid(_glass) or card == null:
		return
	var d := card.data
	_glass.visible = not has_meta("unknown")
	_glass.card_size = size
	_glass.neon = _neon if not _neon.is_empty() else CardView.neon_colors(d)
	_glass.gradient_border = _neon.size() >= 2 and d.rarity != "mythic" and _frame_anim == ""
	_glass.border_width = float(_style.border_width_left) if _style != null else 2.0
	_glass.sheen = true
	_glass.hex_rect = _rect_in_card(cost_label).grow(1.0)
	var type_r := _rect_in_card(type_label)
	var font := type_label.get_theme_font("font")
	var fs := type_label.get_theme_font_size("font_size")
	var tw := font.get_string_size(type_label.text.to_upper(), HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x if font != null else type_r.size.x
	var line_y := type_r.position.y + type_r.size.y * 0.5 + 0.5
	var end_x := _rect_in_card(pips_box).position.x if pips_box.get_child_count() > 0 else _rect_in_card(gem_slot).position.x
	_glass.fade_from = Vector2(type_r.position.x + minf(tw, type_r.size.x) + 4.0, line_y)
	_glass.fade_to = Vector2(end_x - 4.0, line_y)
	_glass.fade_color = Color(type_label.get_theme_color("font_color"), 0.55)
	_glass.pip_rects.clear()
	_glass.pip_colors.clear()
	for p in pips_box.get_children():
		if p is Control and p.has_meta("pip") and not p.is_queued_for_deletion():
			_glass.pip_rects.append(_rect_in_card(p))
			_glass.pip_colors.append(NEON.get(String(p.get_meta("pip")), NEON.colorless))
	var gem: Color = RARITY_GEM.get(d.rarity, Color(1, 1, 1, 0))
	_glass.gem_rect = _rect_in_card(gem_slot)
	_glass.gem_color = gem
	_glass.gem_glow = d.rarity == "rare" or d.rarity == "mythic"
	# Selo de runas por trás do texto (com ilustração; sem ela fica o sigilo próprio da carta).
	var has_art := art_slot.visible
	if has_art and not d.is_land():
		var tr_rect := _rect_in_card(text_label)
		var side := minf(size.x * 0.66, tr_rect.size.y + 34.0)
		_glass.rune_rect = Rect2(tr_rect.get_center() + Vector2(0, 8) - Vector2(side, side) * 0.5, Vector2(side, side))
		_glass.rune_color = Color(_glass.main_color(), 0.2)
	else:
		_glass.rune_rect = Rect2()
	_glass.queue_redraw()

## Moldura cosmética escolhida nas Configurações (só nas cartas comuns).
func _apply_frame(style: StyleBoxFlat) -> void:
	var f := CardDB.get_cosmetic("frame", Settings.card_frame)
	var hex := String(f.get("color", ""))
	_frame_anim = ""
	if Settings.card_frame == "classic" or hex == "":
		return
	_frame_anim = String(f.get("anim", ""))
	_frame_color = Color(hex)
	style.set_border_width_all(3 if Settings.card_frame == "stone" else 2)
	style.border_color = Color(hex)
	if Settings.card_frame == "neon":
		style.shadow_color = Color(Color(hex), 0.5)
		style.shadow_size = 4
	elif Settings.card_frame == "royal":
		style.border_width_top = 4
		style.border_width_bottom = 4

var _mirror_tag: Control

## Espelho Vivo: a criatura copiada fica prateada, com a etiqueta ESPELHO (no próximo ataque não dá
## Poder base).
func set_mirrored(on: bool) -> void:
	if _tag_kind == "jail" and not on:
		return   # a etiqueta de presa manda (o Carcereiro e o Espelho não aparecem juntos)
	_set_tag("mirror" if on else "", tr("ESPELHO"), Color(0.55, 0.65, 0.85, 0.94), Color(0.78, 0.86, 1.0))   # fundo prateado

## 0.12.0 Carcereiro: criatura presa no ataque seguinte (moldura cinzenta e etiqueta PRESA).
func set_jailed(on: bool) -> void:
	if _tag_kind == "mirror" and not on:
		return
	_set_tag("jail" if on else "", tr("PRESA"), Color(0.45, 0.42, 0.5, 0.95), Color(0.62, 0.6, 0.66))

var _tag_kind := ""

## Etiqueta a meio da carta (ESPELHO, PRESA) e a cor da moldura; kind "" tira-a.
func _set_tag(kind: String, text: String, bg: Color, frame_tint: Color) -> void:
	self_modulate = frame_tint if kind != "" else Color.WHITE   # só a moldura, não o texto
	if kind == "":
		if _mirror_tag != null:
			_mirror_tag.queue_free()
			_mirror_tag = null
		_tag_kind = ""
		return
	if _mirror_tag != null and _tag_kind == kind:
		return
	if _mirror_tag != null:
		_mirror_tag.queue_free()
	_tag_kind = kind
	# O PanelContainer estica os filhos: a etiqueta vai dentro de um Control simples do tamanho da carta.
	var holder := Control.new()
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(holder)
	var tag := PanelContainer.new()
	tag.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tag.add_theme_stylebox_override("panel", UiKit.flat(bg, 6, Color(1, 1, 1, 0.8), 1, 3))
	var l := UiKit.label(text, 13, Color(0.08, 0.1, 0.18) if kind == "mirror" else Color(1, 1, 1))
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tag.add_child(l)
	holder.add_child(tag)
	tag.anchor_left = 0.5
	tag.anchor_right = 0.5
	tag.anchor_top = 0.44
	tag.anchor_bottom = 0.44
	tag.offset_left = -46
	tag.offset_right = 46
	_mirror_tag = holder

## Nevoeiro: carta na mão durante a batalha contra a Bruxa do Nevoeiro.
func is_fogged() -> bool:
	return fog_hand and card != null and card.zone == CardInstance.Zone.HAND

## Terrenos sem ilustração: paisagem da cor na parte de baixo (em vez do sigilo).
func _refresh_land_art(d: CardData, text_color: Color, has_art: bool = false) -> void:
	if not d.is_land() or has_art:
		if _land_art != null:
			_land_art.visible = false
		return
	if _land_art == null:
		_land_art = LandArt.new()
		_land_art.set_anchors_preset(Control.PRESET_FULL_RECT)
		add_child(_land_art)
		move_child(_land_art, 0)
	_land_art.visible = true
	_land_art.card_id = d.id
	_land_art.colors = d.colors.duplicate()
	_land_art.ink = Color(text_color, 0.26)

## Ilustração (0.12.0; 0.14.0: numa janela entre o nome e o tipo, com a cor toda, contorno e brilho na cor
## da carta). Sem ilustração (Coleção, Construtor) a janela fecha e o texto fica com mais espaço.
## Devolve se há ilustração.
func _refresh_art(d: CardData) -> bool:
	var tex: Texture2D = ArtLib.texture("card", d.id) if art_on and not has_meta("unknown") else null
	if tex == null:
		if _art != null:
			_art.visible = false
		art_slot.visible = false
		return false
	if _art == null:
		_art = CardArt.new()
		_art.set_anchors_preset(Control.PRESET_FULL_RECT)
		art_slot.add_child(_art)
	art_slot.visible = true
	_art.visible = true
	_art.texture = tex
	_art.radius = 7.0
	var main: Color = _neon[0] if _neon.size() == 1 else _neon[0].lerp(_neon[1], 0.5)
	_art.outline = Color(main, 0.85)
	_art.glow = Color(main, 0.0 if Settings.performance_mode else 0.4)
	return true

## Ícones das palavras-chave, em baixo à esquerda (o texto completo está no zoom).
func _refresh_keywords(d: CardData, text_color: Color) -> void:
	if _kw_box == null:
		_kw_box = HBoxContainer.new()
		_kw_box.add_theme_constant_override("separation", 1)
		_kw_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_kw_box.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		var bottom := seal_slot.get_parent()
		bottom.add_child(_kw_box)
		bottom.move_child(_kw_box, stats_label.get_index() + 1)   # 0.14.0: depois do Poder
	for c in _kw_box.get_children():
		_kw_box.remove_child(c)
		c.queue_free()
	if is_fogged():
		return
	var px := 12.0 if Settings.compact else 14.0
	var kws: Array = card.keywords() if card != null and card.data == d else d.keywords
	for k in kws:
		var ic := CardIcon.new(String(k), Color(text_color, 0.85), px)
		ic.tooltip_text = tr(String(CardData.KEYWORD_NAMES.get(k, k)))
		ic.set_meta("kw", String(k))
		_kw_box.add_child(ic)

## 0.13.0: palavra-chave cujo ícone está debaixo deste ponto do ecrã (com folga para o dedo); {} se nenhuma.
func keyword_at(global_pos: Vector2) -> Dictionary:
	if _kw_box == null or not is_instance_valid(_kw_box):
		return {}
	for ic in _kw_box.get_children():
		var c := ic as Control
		if c == null or c.is_queued_for_deletion() or not c.has_meta("kw"):
			continue
		var r := c.get_global_rect()
		if r.grow(10.0).has_point(global_pos):
			return {"kw": String(c.get_meta("kw")), "rect": r}
	return {}

## Sigilo da carta em marca de água, atrás do texto (cada carta tem o seu). 0.14.0: só nas cartas sem
## ilustração (Coleção, Construtor), na cor néon; com ilustração fica o selo de runas do vidro (mais leve).
func _refresh_sigil(d: CardData, has_art: bool) -> void:
	if has_art or d.is_land():
		if _sigil != null:
			_sigil.visible = false
		return
	if _sigil == null:
		_sigil = CardSigil.new()
		_sigil.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(_sigil)
		move_child(_sigil, 0)
	_sigil.visible = true
	_sigil.card_id = d.id
	_sigil.colors = d.colors.duplicate()
	var main: Color = _neon[0] if not _neon.is_empty() else LIGHT_TEXT
	_sigil.ink = Color(main, 0.17)
	_sigil.line_width = 1.4

## Míticas: a moldura vai mudando de cor (lume → ouro → magenta).
func _process(delta: float) -> void:
	if _style == null or card == null:
		set_process(false)
		return
	if card.data.rarity != "mythic":
		if _frame_anim == "" or not frame_anim_on:
			set_process(false)
			return
		_animate_frame(delta)
		return
	_mythic_t += delta * 0.8
	var n := MYTHIC_COLORS.size()
	var i := int(_mythic_t) % n
	var t: float = _mythic_t - floorf(_mythic_t)
	_style.border_color = (MYTHIC_COLORS[i] as Color).lerp(MYTHIC_COLORS[(i + 1) % n], t)

## Molduras animadas: twinkle (cintila), shimmer (brilho dourado a correr), flicker (relâmpagos),
## pulse (respira) e rainbow (arco-íris).
func _animate_frame(delta: float) -> void:
	_mythic_t += delta
	var c := _frame_color
	match _frame_anim:
		"twinkle":
			c = c.lerp(Color.WHITE, 0.5 + 0.5 * sin(_mythic_t * 5.0 + float(get_instance_id() % 7)))
		"shimmer":
			c = c.lightened(0.35 * (0.5 + 0.5 * sin(_mythic_t * 3.0)))
		"flicker":
			c = c.lerp(Color(0.95, 0.95, 1.0), 1.0 if fmod(_mythic_t * 3.3 + float(get_instance_id() % 5), 2.6) < 0.12 else 0.0)
		"pulse":
			c = Color(c, 0.45 + 0.55 * (0.5 + 0.5 * sin(_mythic_t * 2.2)))
		"rainbow":
			c = Color.from_hsv(fmod(_mythic_t * 0.25, 1.0), 0.55, 1.0)
	_style.border_color = c

## Brilho holográfico (raras e faces viradas): um ColorRect com o shader por cima do conteúdo.
func _refresh_foil(on: bool) -> void:
	if on and _foil == null:
		_foil = ColorRect.new()
		_foil.material = CardView.foil_material()
		_foil.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(_foil)
	elif not on and _foil != null:
		_foil.queue_free()
		_foil = null

## 0.13.0: mestria — medalha na borda de baixo (bronze, prata, ouro); com Ouro, as comuns e incomuns ganham
## a moldura dourada que brilha.
func _refresh_mastery(d: CardData) -> void:
	var lv := GameState.card_mastery(d.id) if mastery_on and not d.token and not d.is_curse() else 0
	if lv <= 0:
		if _mastery_badge != null:
			_mastery_badge.queue_free()
			_mastery_badge = null
		return
	if lv >= GameState.MASTERY_PLAYS.size() and d.rarity != "rare" and d.rarity != "mythic" and _style != null:
		_style.set_border_width_all(3)
		_style.border_color = GameState.MASTERY_COLORS[2]
		_frame_anim = "shimmer"
		_frame_color = GameState.MASTERY_COLORS[2]
		set_process(frame_anim_on and Settings.motion_ok() and not Settings.performance_mode)
	if _mastery_badge == null:
		_mastery_badge = Control.new()
		_mastery_badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(_mastery_badge)
		var badge := _mastery_badge
		badge.draw.connect(func(): CardView._draw_mastery(badge, int(badge.get_meta("lv", 1)), float(_style.content_margin_bottom) if _style != null else 6.0))
	else:
		move_child(_mastery_badge, get_child_count() - 1)
	_mastery_badge.set_meta("lv", lv)
	_mastery_badge.tooltip_text = tr("Mestria %s") % tr(GameState.MASTERY_NAMES[lv - 1])
	_mastery_badge.queue_redraw()

## No meio da borda de baixo (o canto de cima à esquerda é dos números de ordem na Arena).
static func _draw_mastery(c: Control, lv: int, bottom: float) -> void:
	var col: Color = GameState.MASTERY_COLORS[clampi(lv - 1, 0, 2)]
	var ctr := Vector2(c.size.x * 0.5, c.size.y + bottom)
	c.draw_circle(ctr + Vector2(1, 2), 9.0, Color(0, 0, 0, 0.45))
	c.draw_circle(ctr, 9.0, Color(0.12, 0.09, 0.2, 0.96))
	c.draw_arc(ctr, 9.0, 0.0, TAU, 24, col, 2.0, true)
	var pts := PackedVector2Array()
	for k in 10:
		var a := -PI / 2.0 + TAU * k / 10.0
		pts.append(ctr + Vector2(cos(a), sin(a)) * (5.6 if k % 2 == 0 else 2.4))
	c.draw_colored_polygon(pts, col)

## 0.13.0: edição da carta — brilho próprio por cima (sem o das raras) e uma pedra na borda de cima.
func _refresh_edition(ed: String) -> void:
	var on := EffectResolver.EDITIONS.has(ed)
	if on and not Settings.performance_mode:
		if _edition_fx == null:
			_edition_fx = ColorRect.new()
			_edition_fx.mouse_filter = Control.MOUSE_FILTER_IGNORE
			add_child(_edition_fx)
		_edition_fx.material = CardView.edition_material(ed)
	elif _edition_fx != null:
		_edition_fx.queue_free()
		_edition_fx = null
	if not on:
		if _edition_gem != null:
			_edition_gem.queue_free()
			_edition_gem = null
		return
	if _edition_gem == null:
		_edition_gem = Control.new()
		_edition_gem.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(_edition_gem)
		var gem := _edition_gem
		gem.draw.connect(func(): CardView._draw_edition_gem(gem, String(gem.get_meta("ed", "")), -float(_style.content_margin_top) if _style != null else -6.0))
	else:
		move_child(_edition_gem, get_child_count() - 1)
	_edition_gem.set_meta("ed", ed)
	_edition_gem.tooltip_text = EffectResolver.edition_text(ed)
	_edition_gem.queue_redraw()

## Pedra da edição: losango no meio da borda de cima (Policromática = quatro cores).
static func _draw_edition_gem(c: Control, ed: String, top: float) -> void:
	if not EffectResolver.EDITIONS.has(ed):
		return
	var ctr := Vector2(c.size.x * 0.5, top)
	var r := 8.0
	var pts := PackedVector2Array([ctr + Vector2(0, -r), ctr + Vector2(r, 0), ctr + Vector2(0, r), ctr + Vector2(-r, 0)])
	c.draw_colored_polygon(PackedVector2Array([pts[0] + Vector2(1, 2), pts[1] + Vector2(1, 2), pts[2] + Vector2(1, 2), pts[3] + Vector2(1, 2)]), Color(0, 0, 0, 0.45))
	if ed == "poly":
		var cols := [Color(1.0, 0.4, 0.4), Color(1.0, 0.9, 0.35), Color(0.4, 0.95, 0.6), Color(0.45, 0.6, 1.0)]
		for i in 4:
			c.draw_colored_polygon(PackedVector2Array([ctr, pts[i], pts[(i + 1) % 4]]), cols[i])
	else:
		c.draw_colored_polygon(pts, EffectResolver.edition_color(ed))
	c.draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[3], pts[0]]), Color(0.1, 0.08, 0.16), 1.6, true)
	c.draw_line(ctr + Vector2(-3.5, -2.5), ctr + Vector2(0, -5.5), Color(1, 1, 1, 0.85), 1.6, true)

## Texto grande (Configurações): fontes maiores nas cartas.
func _apply_text_size() -> void:
	var big := Settings.large_text
	var small := Settings.compact
	var base_h := (SIZE_COMPACT if small else SIZE_NORMAL).y
	var card_h := maxf(custom_minimum_size.y, base_h * size_scale)
	# 0.13.0: cartas da mão maiores ou mais pequenas (size_scale); 0.14.0: as cartas maiores do que o normal
	# (draft, partilhar a run) também aumentam as letras, como a carta.
	var k := maxf(size_scale, card_h / base_h)
	_kf = k
	# 0.14.0: a janela da ilustração cresce com a carta (31 % da altura).
	art_slot.custom_minimum_size.y = roundi(card_h * 0.31)
	_text_fs = roundi((13 if big else (10 if small else 11)) * k)
	text_label.add_theme_font_size_override("normal_font_size", _text_fs)
	type_label.add_theme_font_size_override("font_size", roundi((10 if big else (8 if small else 9)) * k))
	var stat_fs := roundi(((12 if big else (10 if small else 11)) if card != null and card.data.is_land() else (16 if big else (12 if small else 14))) * k)
	stats_label.add_theme_font_size_override("font_size", stat_fs)
	tough_label.add_theme_font_size_override("font_size", stat_fs)
	delta_label.add_theme_font_size_override("font_size", roundi((12 if big else (10 if small else 11)) * k))
	cost_label.add_theme_font_size_override("font_size", roundi((12 if small else 13) * k))
	cost_label.custom_minimum_size = (Vector2(20, 22) if small else Vector2(22, 24)) * k
	icon_slot.custom_minimum_size = Vector2(10, 10) * k
	gem_slot.custom_minimum_size = Vector2(7, 7) * k
	_fit_name()
	_fit_bottom_row()
	_fit_text()

## 0.14.0: o nome fica numa linha e encolhe até caber (até 80 % do tamanho); se ainda não couber (nomes
## muito compridos), passa a duas linhas.
func _fit_name() -> void:
	var k := _kf
	var base_fs := roundi((14 if Settings.large_text else (10 if Settings.compact else 12)) * k)
	set_meta("name_fs", base_fs)
	var card_w := maxf(custom_minimum_size.x, (SIZE_COMPACT if Settings.compact else SIZE_NORMAL).x * size_scale)
	var margins := 2.0 * float(_style.content_margin_left) if _style != null else 12.0
	var avail := card_w - margins - cost_label.custom_minimum_size.x - 2.0
	var font := name_label.get_theme_font("font")
	var fs := base_fs
	var floor_fs := maxi(8, roundi(base_fs * 0.8))
	while fs > floor_fs and font != null and font.get_string_size(name_label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x > avail:
		fs -= 1
	var two_lines := font != null and font.get_string_size(name_label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x > avail
	name_label.add_theme_font_size_override("font_size", fs)
	name_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART if two_lines else TextServer.AUTOWRAP_OFF
	name_label.max_lines_visible = 2 if two_lines else -1
	var two_h := ceilf(font.get_height(fs) * 2.0 + name_label.get_theme_constant("line_spacing")) + 1.0 if font != null else fs * 2.6
	name_label.custom_minimum_size = Vector2(0, two_h if two_lines else 0.0)
	_fit_type()

## 0.14.0: o tipo ocupa só a largura do texto (o resto da linha é a linha que esbate); se não couber,
## fica com reticências.
func _fit_type() -> void:
	var font := type_label.get_theme_font("font")
	if font == null:
		return
	var card_w := maxf(custom_minimum_size.x, (SIZE_COMPACT if Settings.compact else SIZE_NORMAL).x * size_scale)
	var margins := 2.0 * float(_style.content_margin_left) if _style != null else 12.0
	var sep := float((type_label.get_parent() as Container).get_theme_constant("separation"))
	var pips_w := 0.0
	for p in pips_box.get_children():
		pips_w += (p as Control).custom_minimum_size.x + 2.0
	var avail := card_w - margins - icon_slot.custom_minimum_size.x - gem_slot.custom_minimum_size.x - pips_w - sep * 4.0 - 6.0
	# Se não couber: primeiro sem o espaço extra entre letras, depois letra mais pequena (até 7).
	var txt := type_label.text.to_upper()
	var fs := type_label.get_theme_font_size("font_size")
	var tw := ceilf(font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x) + 1.0
	if tw > avail and font is FontVariation:
		font = (font as FontVariation).base_font
		type_label.add_theme_font_override("font", font)
		tw = ceilf(font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x) + 1.0
	var floor_fs := mini(fs, 7)
	while tw > avail and fs > floor_fs:
		fs -= 1
		tw = ceilf(font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x) + 1.0
	type_label.add_theme_font_size_override("font_size", fs)
	type_label.custom_minimum_size.x = clampf(tw, 0.0, maxf(8.0, avail))

## 0.14.0: o texto encolhe (até 2 pontos) para caber na caixa; se mesmo assim não couber, mostra só as
## linhas inteiras (o texto todo está na carta em grande).
func _fit_text() -> void:
	if text_label == null or text_label.size.y < 4.0 or text_label.size.x < 4.0:
		return
	text_label.visible_characters = -1
	var fs := _text_fs
	text_label.add_theme_font_size_override("normal_font_size", fs)
	var floor_fs := maxi(8, _text_fs - 2)
	while fs > floor_fs and text_label.get_content_height() > text_label.size.y + 0.5:
		fs -= 1
		text_label.add_theme_font_size_override("normal_font_size", fs)
	if text_label.get_content_height() <= text_label.size.y + 0.5:
		return
	# Ainda não cabe: esconde a partir da primeira linha que ficaria cortada.
	var lines := text_label.get_line_count()
	var fit := 0
	for i in lines:
		var bottom_y := text_label.get_line_offset(i + 1) if i + 1 < lines else float(text_label.get_content_height())
		if bottom_y > text_label.size.y + 0.5:
			break
		fit = i + 1
	var total := text_label.get_total_character_count()
	var cut := total
	for ch in total:
		if text_label.get_character_line(ch) >= fit:
			cut = ch
			break
	text_label.visible_characters = maxi(0, cut)

## 0.13.0: Poder/Vida grandes com palavras-chave na mesma linha alargavam a carta para lá do tamanho
## normal e empurravam as grelhas (Coleção, Construtor). Encolhe esses números até caber.
func _fit_bottom_row() -> void:
	var bottom := stats_label.get_parent() as Control
	if bottom == null:
		return
	var base := (SIZE_COMPACT if Settings.compact else SIZE_NORMAL) * size_scale
	var allowed := maxf(base.x, custom_minimum_size.x) - 12.0 * size_scale
	var fs := stats_label.get_theme_font_size("font_size")
	var floor_fs := roundi(10 * size_scale)
	while fs > floor_fs and bottom.get_combined_minimum_size().x > allowed:
		fs -= 1
		stats_label.add_theme_font_size_override("font_size", fs)
		tough_label.add_theme_font_size_override("font_size", fs)

## Carta ainda não descoberta (coleção): sem nome, texto nem toque.
func set_unknown() -> void:
	if not is_node_ready():
		await ready
	set_meta("unknown", true)
	name_label.text = "???"
	cost_label.text = "?"
	stats_label.text = ""
	tough_label.text = ""
	text_label.text = tr("Ainda não descoberta.")
	art_slot.visible = false
	if _glass != null:
		_glass.visible = false
	_refresh_foil(false)
	set_process(false)
	if _sigil != null:
		_sigil.visible = false
	if _land_art != null:
		_land_art.visible = false
	# Costas da carta (cosmético escolhido) por cima de tudo; o painel fica neutro (não revela a cor).
	add_theme_stylebox_override("panel", UiKit.flat(Color(0.1, 0.09, 0.14), 12, Color(0, 0, 0, 0), 0, 1))
	var back := CardBack.new()
	back.back_id = Settings.card_back
	back.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(back)
	modulate = Color(0.8, 0.8, 0.85)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _refresh_delta() -> void:
	if delta == 0:
		delta_label.text = ""
		return
	delta_label.text = ("+" if delta > 0 else "−") + Cascade.fmt_int(absi(delta))
	delta_label.add_theme_color_override("font_color", DELTA_UP if delta > 0 else DELTA_DOWN)

func _notification(what: int) -> void:
	match what:
		NOTIFICATION_RESIZED:
			pivot_offset = size / 2.0
		NOTIFICATION_MOUSE_EXIT, NOTIFICATION_SCROLL_BEGIN:
			# O dedo saiu da carta ou a lista começou a fazer scroll: cancela o toque (não o arrasto).
			# 0.12.1: se foi a carta que se mexeu (na mão sobe quando é tocada) e o dedo está quieto,
			# o toque continua — senão segurar nunca chegava a abrir a carta em grande.
			if _pressing and not _dragging:
				if what == NOTIFICATION_MOUSE_EXIT and _moved() <= DRAG_CANCEL:
					return
				_cancel_press()

## Quanto o dedo andou no ecrã desde que tocou.
func _moved() -> float:
	return (_last_global - _press_global).length()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouse:
		_last_global = (event as InputEventMouse).global_position
	if event is InputEventMouseMotion:
		if _dragging:
			drag_moved.emit(card, _last_global)
		elif _pressing and _moved() > DRAG_CANCEL:
			if draggable:
				_begin_drag()
			else:
				_cancel_press()
		elif _held and _long_fired and draggable and _moved() > DRAG_AFTER_LONG:
			_begin_drag()   # segurou (abriu em grande) e depois mexeu: pega na carta
		return
	if not (event is InputEventMouseButton) or event.button_index != MOUSE_BUTTON_LEFT:
		return
	accept_event()
	if event.pressed:
		_pressing = true
		_held = true
		_long_fired = false
		_press_pos = event.position
		_press_global = _last_global
		_press_feedback(true)
		_press_id += 1
		_start_long_press(_press_id)
	else:
		_held = false
		if _dragging:
			_dragging = false
			drag_ended.emit(card, _last_global)
			return
		# Conta como toque se o dedo largou em cima da carta ou quase não se mexeu (a carta pode ter subido).
		var inside := _has_point(event.position) or _moved() <= DRAG_CANCEL
		var was_pressing := _pressing
		_pressing = false
		_press_feedback(false)
		if was_pressing and inside and not _long_fired:
			var hit := keyword_at(_last_global) if keyword_taps else {}
			if not hit.is_empty():
				keyword_tapped.emit(card, String(hit["kw"]), hit["rect"])
			else:
				pressed.emit(card)

func _begin_drag() -> void:
	_pressing = false
	_press_id += 1   # cancela o toque longo
	_press_feedback(false)
	_dragging = true
	drag_started.emit(card, _last_global)

## 0.12.1: carta da mão escolhida — contorno dourado e "JOGAR" por cima (vermelho se agora não dá).
func set_selected(on: bool, can_play: bool = true) -> void:
	if _selected == on and _sel_playable == can_play:
		return
	_selected = on
	_sel_playable = can_play
	queue_redraw()

func is_selected() -> bool:
	return _selected

## A etiqueta "JOGAR" (por cima da carta escolhida) também conta como a carta.
func _has_point(point: Vector2) -> bool:
	var r := Rect2(Vector2.ZERO, size)
	if _selected and _sel_playable:
		r = r.grow_individual(0, 32, 0, 0)
	return r.has_point(point)

func _draw() -> void:
	if not _selected:
		return
	var col := UiKit.GOLD if _sel_playable else Color(0.92, 0.42, 0.38)
	var st := StyleBoxFlat.new()
	st.draw_center = false
	st.set_border_width_all(3)
	st.border_color = col
	st.set_corner_radius_all(12)
	st.shadow_color = Color(col, 0.5)
	st.shadow_size = 10
	draw_style_box(st, Rect2(Vector2(-4, -4), size + Vector2(8, 8)))
	if not _sel_playable:
		return
	var font := get_theme_font("font", "Label")
	var fs := 15
	var text := tr("▲ JOGAR")
	var tw := font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
	var chip := Rect2(Vector2((size.x - tw) / 2.0 - 10.0, -30.0), Vector2(tw + 20.0, 24.0))
	var cs := StyleBoxFlat.new()
	cs.bg_color = col
	cs.set_corner_radius_all(12)
	draw_style_box(cs, chip)
	draw_string(font, Vector2(chip.position.x + 10.0, chip.position.y + 18.0), text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(0.1, 0.07, 0.03))

func _start_long_press(id: int) -> void:
	await get_tree().create_timer(LONG_PRESS).timeout
	if id != _press_id or not _pressing or not is_inside_tree() or is_queued_for_deletion():
		return
	if _moved() > DRAG_CANCEL:
		return
	_long_fired = true
	_pressing = false
	_press_feedback(false)
	Settings.vibrate(25)
	long_pressed.emit(card)

func _cancel_press() -> void:
	_pressing = false
	_press_id += 1   # invalida o temporizador do toque longo
	_press_feedback(false)

func _press_feedback(down: bool) -> void:
	if not is_inside_tree() or is_queued_for_deletion():
		return
	pivot_offset = size / 2.0
	if has_meta("press_tw"):
		var old = get_meta("press_tw")
		if old is Tween and (old as Tween).is_valid():
			(old as Tween).kill()
	if not down:
		scale = Vector2.ONE   # imediato: a carta pode ser destruída já a seguir (jogada/canalizada)
		return
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector2(0.95, 0.95), 0.06)
	set_meta("press_tw", tw)
