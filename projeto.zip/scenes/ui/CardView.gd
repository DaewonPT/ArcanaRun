class_name CardView
extends PanelContainer
## Representação visual de uma CardInstance (mão ou tabuleiro). Emite `pressed` com a instância.
## Toques no Android chegam como eventos de rato (emulate_mouse_from_touch, ligado por defeito).

signal pressed(card: CardInstance)

const COLORS := {
	"white": Color(0.93, 0.90, 0.78),
	"red": Color(0.85, 0.35, 0.30),
	"green": Color(0.40, 0.65, 0.40),
	"blue": Color(0.40, 0.55, 0.85),
	"black": Color(0.35, 0.33, 0.38),
	"colorless": Color(0.70, 0.70, 0.70),
}

var card: CardInstance
var playable: bool = true:
	set(v):
		playable = v
		modulate.a = 1.0 if v else 0.45

@onready var name_label: Label = %Name
@onready var cost_label: Label = %Cost
@onready var stats_label: Label = %Stats
@onready var text_label: Label = %Text

func setup(p_card: CardInstance) -> void:
	card = p_card
	if not is_node_ready():
		await ready
	refresh()

func refresh() -> void:
	name_label.text = card.data.name
	cost_label.text = "" if card.data.is_land() else str(card.data.cost)
	if card.data.is_creature():
		stats_label.text = "%d/%d" % [card.power(), card.toughness() - card.damage]
	else:
		stats_label.text = ""
	text_label.text = card.data.text
	var style := StyleBoxFlat.new()
	style.bg_color = COLORS.get(card.data.color, COLORS.colorless)
	style.set_corner_radius_all(12)
	style.set_content_margin_all(8)
	add_theme_stylebox_override("panel", style)
	pivot_offset = size / 2.0

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		pivot_offset = size / 2.0

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		accept_event()
		pressed.emit(card)
