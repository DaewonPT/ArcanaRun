class_name CardView
extends PanelContainer
## Representação visual de uma CardInstance (mão, tabuleiro, listas).
## Toque (carregar e largar em cima da carta) = `pressed`; manter o dedo = `long_pressed` (ver em grande).
## Um arrasto para fazer scroll cancela os dois. Toques no Android chegam como eventos de rato
## (emulate_mouse_from_touch) e o ScrollContainer avisa com NOTIFICATION_SCROLL_BEGIN quando arrasta.

signal pressed(card: CardInstance)
signal long_pressed(card: CardInstance)
signal drag_started(card: CardInstance, global_pos: Vector2)
signal drag_moved(card: CardInstance, global_pos: Vector2)
signal drag_ended(card: CardInstance, global_pos: Vector2)

const LONG_PRESS := 0.42     # segundos com o dedo em cima para abrir em grande
const DRAG_CANCEL := 16.0    # px de movimento a partir dos quais o toque passa a ser scroll

const COLORS := {
	"white": Color(0.93, 0.89, 0.74),
	"blue": Color(0.38, 0.56, 0.88),
	"black": Color(0.42, 0.36, 0.48),
	"red": Color(0.86, 0.36, 0.30),
	"green": Color(0.40, 0.66, 0.40),
	"colorless": Color(0.66, 0.66, 0.70),
}
const DARK_TEXT := Color(0.08, 0.08, 0.1)
const LIGHT_TEXT := Color(0.97, 0.97, 0.99)

var card: CardInstance
var playable: bool = true:
	set(v):
		playable = v
		modulate.a = 1.0 if v else 0.45
var compact: bool = false
var draggable: bool = false        # tabuleiro: arrastar reordena em vez de cancelar o toque
## Variação do total do ataque se esta carta for jogada (mão). 0 = não mostrar.
var delta: int = 0:
	set(v):
		delta = v
		if is_node_ready():
			_refresh_delta()

var _pressing: bool = false
var _press_pos := Vector2.ZERO
var _press_id: int = 0
var _long_fired: bool = false
var _dragging: bool = false

@onready var name_label: Label = %Name
@onready var cost_label: Label = %Cost
@onready var stats_label: Label = %Stats
@onready var text_label: Label = %Text
@onready var type_label: Label = %Type
@onready var delta_label: Label = %Delta

func setup(p_card: CardInstance) -> void:
	card = p_card
	if not is_node_ready():
		await ready
	refresh()

func refresh() -> void:
	var d := card.data
	name_label.text = d.name
	cost_label.text = str(d.cost)
	if d.is_creature():
		stats_label.text = "%d ⚔  %d ♥" % [card.power(), card.remaining()]
		type_label.text = tr("Criatura")
	elif d.is_spell():
		stats_label.text = "%d ⚔" % card.power() if d.power > 0 else ""
		type_label.text = tr("Mágica") if d.subtype == "instant" else tr("Feitiço")
	else:
		stats_label.text = ""
		type_label.text = tr("Terreno · na mão")
	text_label.text = d.text + ("  ≈" if d.approx else "")
	# Fundo: cor principal; multicolor = mistura das cores; incolor = cinzento.
	var bg: Color = COLORS[d.primary_color()]
	if d.colors.size() >= 2:
		bg = Color(0, 0, 0)
		for col in d.colors:
			bg += COLORS.get(col, COLORS.colorless) / d.colors.size()
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.set_corner_radius_all(12)
	style.set_content_margin_all(7)
	if d.colors.size() >= 3:
		style.set_border_width_all(3)
		style.border_color = Color(0.98, 0.78, 0.3)
	add_theme_stylebox_override("panel", style)
	var text_color := DARK_TEXT if bg.get_luminance() > 0.45 else LIGHT_TEXT
	for l in [name_label, cost_label, stats_label, text_label, type_label]:
		l.add_theme_color_override("font_color", text_color)
	_refresh_delta()
	pivot_offset = size / 2.0

func _refresh_delta() -> void:
	if delta == 0:
		delta_label.text = ""
		return
	delta_label.text = ("+" if delta > 0 else "−") + Cascade.fmt_int(absi(delta))
	delta_label.add_theme_color_override("font_color", Color(0.15, 0.7, 0.3) if delta > 0 else Color(0.8, 0.3, 0.3))

func _notification(what: int) -> void:
	match what:
		NOTIFICATION_RESIZED:
			pivot_offset = size / 2.0
		NOTIFICATION_MOUSE_EXIT, NOTIFICATION_SCROLL_BEGIN:
			# O dedo saiu da carta ou a lista começou a fazer scroll: cancela o toque (não o arrasto).
			if _pressing and not _dragging:
				_cancel_press()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		if _dragging:
			drag_moved.emit(card, get_global_mouse_position())
		elif _pressing and (event.position - _press_pos).length() > DRAG_CANCEL:
			if draggable:
				_pressing = false
				_press_id += 1   # cancela o toque longo
				_press_feedback(false)
				_dragging = true
				drag_started.emit(card, get_global_mouse_position())
			else:
				_cancel_press()
		return
	if not (event is InputEventMouseButton) or event.button_index != MOUSE_BUTTON_LEFT:
		return
	accept_event()
	if event.pressed:
		_pressing = true
		_long_fired = false
		_press_pos = event.position
		_press_feedback(true)
		_press_id += 1
		_start_long_press(_press_id)
	else:
		if _dragging:
			_dragging = false
			drag_ended.emit(card, get_global_mouse_position())
			return
		var inside := Rect2(Vector2.ZERO, size).has_point(event.position)
		var was_pressing := _pressing
		_pressing = false
		_press_feedback(false)
		if was_pressing and inside and not _long_fired:
			pressed.emit(card)

func _start_long_press(id: int) -> void:
	await get_tree().create_timer(LONG_PRESS).timeout
	if id != _press_id or not _pressing or not is_inside_tree() or is_queued_for_deletion():
		return
	_long_fired = true
	_pressing = false
	_press_feedback(false)
	Settings.vibrate(25)
	long_pressed.emit(card)

func _cancel_press() -> void:
	_pressing = false
	_press_id += 1   # invalida o temporizador do toque longo
	_press_feedback(false)

func _press_feedback(down: bool) -> void:
	if not is_inside_tree() or is_queued_for_deletion():
		return
	pivot_offset = size / 2.0
	if has_meta("press_tw"):
		var old = get_meta("press_tw")
		if old is Tween and (old as Tween).is_valid():
			(old as Tween).kill()
	if not down:
		scale = Vector2.ONE   # imediato: a carta pode ser destruída já a seguir (jogada/canalizada)
		return
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector2(0.95, 0.95), 0.06)
	set_meta("press_tw", tw)
