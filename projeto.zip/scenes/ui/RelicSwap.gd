class_name RelicSwap
extends Control
## 0.17.0 (Torre do Arquimago): as relíquias estão cheias — escolhe a que sai para entrar a nova. Cada uma
## das tuas aparece com o que faz e um botão TROCAR; o ✕, tocar fora ou «retroceder» desistem (on_pick("")).

var _on_pick: Callable
var _done := false

static func open(new_id: String, on_pick: Callable) -> RelicSwap:
	var d := RelicSwap.new()
	d._on_pick = on_pick
	SceneRouter.show_overlay(d)
	d._build(new_id)
	return d

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.75))

func _build(new_id: String) -> void:
	var nr: Dictionary = CardDB.relics.get(new_id, {})
	var body := UiKit.window(self, 720, tr("RELÍQUIAS CHEIAS"), UiKit.GOLD, _pick.bind(""),
		tr("Para levares %s, escolhe a relíquia que sai.") % tr(String(nr.get("name", new_id))))
	var list := VBoxContainer.new()
	list.add_theme_constant_override("separation", 8)
	body.add_child(list)
	for id in GameState.relic_ids:
		var r: Dictionary = CardDB.relics.get(id, {})
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		list.add_child(row)
		var medal: RelicView = preload("res://scenes/ui/RelicView.tscn").instantiate()
		medal.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(medal)
		medal.setup(String(id))
		var txt := UiKit.label(tr(String(r.get("name", id))) + "\n" + tr(String(r.get("text", ""))), 15, Color.WHITE, true)
		txt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		txt.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		txt.max_lines_visible = 3
		row.add_child(txt)
		var b := UiKit.button(tr("TROCAR"), 48, 16, UiKit.BTN_BG, UiKit.GOLD)
		b.name = "Swap_" + String(id)
		b.custom_minimum_size.x = 120
		b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		b.pressed.connect(_pick.bind(String(id)))
		row.add_child(b)
	UiKit.pop_in(body.get_meta("panel"))

func _pick(id: String) -> void:
	if _done or is_queued_for_deletion():
		return
	_done = true
	Sfx.select()
	UiKit.close_animated(self)
	if _on_pick.is_valid():
		_on_pick.call(id)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and not event.pressed:
		accept_event()
		_pick("")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		_pick("")
