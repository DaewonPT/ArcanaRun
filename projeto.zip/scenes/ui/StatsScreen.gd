extends Control
## Estatísticas. 0.12.0: quatro separadores —
##   RESUMO      contadores globais e, por baralho, o melhor ante, as vitórias e o nível;
##   HISTÓRICO   as últimas 30 runs (resultado, modo, baralho, maior golpe, carta MVP);
##   CARTAS      dano, vezes jogada, runs e vitórias de cada carta (toque = carta em grande);
##   CONQUISTAS  a lista de sempre.
## No HISTÓRICO e nas CARTAS, "COPIAR CSV" põe os dados na área de transferência, para colar numa
## folha de cálculo (Google Sheets, Excel).

const TABS := [["profile", "PERFIL"], ["summary", "RESUMO"], ["history", "HISTÓRICO"], ["cards", "CARTAS"], ["achievements", "CONQUISTAS"]]
## 0.13.0: títulos do Perfil pelas conquistas desbloqueadas.
const PROFILE_TITLES := [[0, "Aprendiz"], [10, "Conjurador"], [25, "Arcanista"], [45, "Arquimago"], [70, "Mestre dos Planos"], [95, "Lenda do Zero"]]
const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const CARD_SORTS := [["dmg", "Dano"], ["plays", "Jogadas"], ["runs", "Runs"], ["rate", "% vitórias"]]
const CARD_ROWS := 60

var tab := "profile"
var card_sort := "dmg"
var _tab_buttons: Dictionary = {}
var _body: VBoxContainer
var _csv_btn: Button
var _msg: Label

func _ready() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 10)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	margin.add_child(vbox)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	vbox.add_child(header)
	var back := UiKit.button(tr("◀ MENU"), 52, 20)
	back.custom_minimum_size.x = 140
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("ESTATÍSTICAS"), 30, UiKit.GOLD)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(title)
	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(spacer)
	for t in TABS:
		var b := UiKit.button(tr(String(t[1])), 52, 18)
		b.name = "Tab_" + String(t[0])
		b.custom_minimum_size.x = 140
		b.toggle_mode = true
		b.pressed.connect(func(): Sfx.select(); select_tab(String(t[0])))
		header.add_child(b)
		_tab_buttons[t[0]] = b

	var bar := HBoxContainer.new()
	bar.add_theme_constant_override("separation", 12)
	vbox.add_child(bar)
	_msg = UiKit.label("", 16, UiKit.TEXT_DIM)
	_msg.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_msg.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_msg.clip_text = true
	bar.add_child(_msg)
	_csv_btn = UiKit.button(tr("COPIAR CSV"), 44, 16)
	_csv_btn.name = "CopyCsv"
	_csv_btn.custom_minimum_size.x = 170
	_csv_btn.pressed.connect(_on_copy_csv)
	bar.add_child(_csv_btn)

	_body = VBoxContainer.new()
	_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_body.add_theme_constant_override("separation", 8)
	vbox.add_child(_body)
	select_tab("profile")

func select_tab(t: String) -> void:
	tab = t
	for k in _tab_buttons:
		(_tab_buttons[k] as Button).button_pressed = (k == t)
	UiKit.clear_children(_body)
	_csv_btn.visible = t in ["history", "cards"]
	match t:
		"history":
			Stats.add("history_viewed")
			GameState.save_progress()
			_build_history()
		"cards":
			_build_cards()
		"achievements":
			_build_achievements()
		"summary":
			_build_summary()
		_:
			_build_profile()

func _scroll_list(separation: int = 6) -> VBoxContainer:
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_body.add_child(scroll)
	var list := VBoxContainer.new()
	list.name = "List"
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", separation)
	scroll.add_child(list)
	return list

# --- PERFIL (0.13.0) ---

## Título pelo número de conquistas: [nome, conquistas do seguinte (0 = é o último), nome do seguinte].
static func profile_title(unlocked: int) -> Array:
	var name := String(PROFILE_TITLES[0][1])
	var next_at := 0
	var next_name := ""
	for i in PROFILE_TITLES.size():
		if unlocked >= int(PROFILE_TITLES[i][0]):
			name = String(PROFILE_TITLES[i][1])
			if i + 1 < PROFILE_TITLES.size():
				next_at = int(PROFILE_TITLES[i + 1][0])
				next_name = String(PROFILE_TITLES[i + 1][1])
			else:
				next_at = 0
				next_name = ""
	return [name, next_at, next_name]

## O baralho da campanha com mais experiência ("" se ainda não jogaste).
static func favourite_deck() -> String:
	var best := ""
	var best_xp := 0
	for d in CardDB.decks:
		var id := String(d.get("id", ""))
		var xp := GameState.deck_xp(id)
		if xp > best_xp:
			best = id
			best_xp = xp
	return best

## A carta com mais de `key` ("plays" ou "dmg") nas estatísticas por carta ("" se não houver).
static func top_card(key: String) -> String:
	var all := GameState.card_stats()
	var best := ""
	var best_v := 0
	for id in all:
		var cd := CardDB.get_card(String(id))
		if cd == null or cd.token or cd.is_curse() or not (all[id] is Dictionary):
			continue
		var v := int((all[id] as Dictionary).get(key, 0))
		if v > best_v:
			best = String(id)
			best_v = v
	return best

## Quantas cartas em cada nível de mestria: [Bronze, Prata, Ouro] (só o nível mais alto de cada carta).
static func mastery_counts() -> Array:
	var out := [0, 0, 0]
	var all := GameState.card_stats()
	for id in all:
		if not (all[id] is Dictionary):
			continue
		var lv := GameState.mastery_of(all[id])
		if lv > 0:
			out[lv - 1] += 1
	return out

func _build_profile() -> void:
	Stats.check_color_sets()
	var unlocked := Stats.unlocked_count()
	var total_ach := CardDB.achievements.size()
	_msg.text = tr("O teu perfil: o que já fizeste e o que falta descobrir.")
	var s := Stats.stats()
	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 18)
	columns.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_body.add_child(columns)

	# Esquerda: o cartão do jogador (título, destaques e a carta mais jogada).
	var card_panel := PanelContainer.new()
	card_panel.name = "ProfileCard"
	card_panel.custom_minimum_size = Vector2(610, 0)
	card_panel.add_theme_stylebox_override("panel", UiKit.flat(UiKit.BG_LIGHT, 14, UiKit.GOLD, 2, 14))
	columns.add_child(card_panel)
	var cv := VBoxContainer.new()
	cv.add_theme_constant_override("separation", 6)
	card_panel.add_child(cv)
	var t := profile_title(unlocked)
	var title := UiKit.label(tr(String(t[0])), 30, UiKit.GOLD)
	title.name = "ProfileTitle"
	title.theme_type_variation = "TitleLabel"
	cv.add_child(title)
	var sub := tr("Conquistas: %d/%d") % [unlocked, total_ach]
	if int(t[1]) > 0:
		sub += "  ·  " + tr("próximo título: %s (%d conquistas)") % [tr(String(t[2])), int(t[1])]
	cv.add_child(UiKit.label(sub, 15, UiKit.TEXT_DIM, true))
	var hr := ColorRect.new()
	hr.color = Color(UiKit.GOLD, 0.35)
	hr.custom_minimum_size = Vector2(0, 2)
	cv.add_child(hr)
	var inner := HBoxContainer.new()
	inner.add_theme_constant_override("separation", 14)
	inner.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cv.add_child(inner)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 3)
	inner.add_child(grid)
	var fav := favourite_deck()
	var fav_txt := "—"
	if fav != "":
		var dd := CardDB.get_deck(fav)
		fav_txt = tr("%s — Nv. %d · %d vitórias") % [tr(String(dd.get("name", fav))), GameState.deck_level(fav), GameState.wins(fav)]
	var most := top_card("plays")
	var most_txt := "—"
	if most != "":
		var mcd := CardDB.get_card(most)
		var plays := int(GameState.card_stat(most).get("plays", 0))
		most_txt = tr("%s — %d jogadas") % [mcd.display_name(), plays]
		var lv := GameState.card_mastery(most)
		if lv > 0:
			most_txt += " (" + tr("Mestria %s") % tr(GameState.MASTERY_NAMES[lv - 1]) + ")"
	var dmg := top_card("dmg")
	var dmg_txt := "—"
	if dmg != "":
		dmg_txt = "%s — %s" % [CardDB.get_card(dmg).display_name(), Cascade.fmt_int(int(GameState.card_stat(dmg).get("dmg", 0)))]
	var mc := mastery_counts()
	var wins_txt := tr("%d (Difícil %d · Pesadelo %d)") % [int(s.get("wins", 0)), maxi(0, int(s.get("wins_hard", 0)) - int(s.get("wins_nightmare", 0))), int(s.get("wins_nightmare", 0))]
	var endless := int(GameState.progress.get("endless_best", 0))
	var rows := [
		[tr("Baralho favorito"), fav_txt],
		[tr("Carta mais jogada"), most_txt],
		[tr("Carta com mais dano"), dmg_txt],
		[tr("Maior ataque"), Cascade.fmt_int(int(s.get("best_attack", 0)))],
		[tr("Vitórias"), wins_txt],
		[tr("Selo Planar mais alto"), (tr("Selo %d") % int(s.get("best_stake", 0))) if int(s.get("best_stake", 0)) > 0 else "—"],
		[tr("Infinito"), (tr("ante %d") % endless) if endless > 0 else "—"],
		[tr("Mestrias"), tr("Bronze %d · Prata %d · Ouro %d") % [int(mc[0]), int(mc[1]), int(mc[2])]],
		[tr("Pesadelo"), tr("aberto") if GameState.nightmare_unlocked() else tr("vence uma run no Difícil para o abrir")],
	]
	for r in rows:
		var k := UiKit.label(String(r[0]), 16, UiKit.TEXT_DIM)
		k.custom_minimum_size.x = 190
		grid.add_child(k)
		var v := UiKit.label(String(r[1]), 16, Color.WHITE, true)
		v.custom_minimum_size.x = 210
		v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.add_child(v)
	if most != "":
		var view: CardView = CARD_VIEW.instantiate()
		view.name = "MostPlayed"
		view.custom_minimum_size = Vector2(130, 186)
		view.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		inner.add_child(view)
		view.setup(CardDB.new_instance(most))
		view.pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
		view.long_pressed.connect(func(c: CardInstance): CardZoom.show_card(c))

	# Direita: o progresso (coleção por cor, modos, cosméticos).
	var right_scroll := ScrollContainer.new()
	right_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	columns.add_child(right_scroll)
	var right := VBoxContainer.new()
	right.name = "ProfileProgress"
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 5)
	right_scroll.add_child(right)
	right.add_child(UiKit.label(tr("Progresso"), 19, UiKit.GOLD))
	_progress_row(right, tr("Cartas descobertas"), Stats.seen_count("cards"), CardDB.collectible_cards().size(), UiKit.GOLD)
	for col in Stats.COLOR_SET_NAMES:
		var pr := Stats.color_set_progress(String(col))
		_progress_row(right, "   " + tr(String(Stats.COLOR_SET_NAMES[col])), pr.x, pr.y, CardView.COLORS.get(col, Color.WHITE), true)
	_progress_row(right, tr("Relíquias"), Stats.seen_count("relics"), CardDB.relics.size(), Color(0.95, 0.7, 0.35))
	_progress_row(right, tr("Inimigos"), Stats.seen_count("enemies"), CardDB.enemies.size(), Color(0.9, 0.45, 0.45))
	_progress_row(right, tr("História"), _count(CardDB.saga, GameState.saga_done), CardDB.saga.size(), Color(0.7, 0.6, 1.0))
	_progress_row(right, tr("Estrelas dos Desafios"), GameState.total_challenge_stars(), CardDB.challenges.size() * 3, Color(1.0, 0.85, 0.35))
	_progress_row(right, tr("Enigmas"), _count(CardDB.puzzles, Stats.is_puzzle_solved), CardDB.puzzles.size(), Color(0.55, 0.85, 1.0))
	_progress_row(right, tr("Lições"), _count(CardDB.lessons, GameState.lesson_done), CardDB.lessons.size(), Color(0.6, 0.95, 0.7))
	var cos_have := 0
	var cos_total := 0
	for kind in ["back", "frame", "mat", "effect"]:
		cos_have += Settings.unlocked_cosmetics(kind).size()
		cos_total += (CardDB.cosmetics.get(kind + "s", []) as Array).size()
	_progress_row(right, tr("Cosméticos"), cos_have, cos_total, Color(0.95, 0.55, 0.85))
	right.add_child(UiKit.label(tr("Completa uma cor da Coleção para ganhar umas costas de carta; as mestrias sobem ao jogar a mesma carta em várias runs."), 13, UiKit.TEXT_DIM, true))

static func _count(list: Array, done: Callable) -> int:
	var n := 0
	for e in list:
		if bool(done.call(String((e as Dictionary).get("id", "")))):
			n += 1
	return n

## Uma linha "Nome ▓▓▓░░ 12/40" (✓ quando está completa).
func _progress_row(parent: Control, text: String, have: int, total: int, color: Color, small: bool = false) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	parent.add_child(row)
	var l := UiKit.label(text, 14 if small else 16, Color.WHITE if not small else UiKit.TEXT_DIM)
	l.custom_minimum_size.x = 210
	l.clip_text = true
	l.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(l)
	var bar := Control.new()
	bar.custom_minimum_size = Vector2(0, 12 if small else 16)
	bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var frac := clampf(float(have) / float(total), 0.0, 1.0) if total > 0 else 0.0
	bar.draw.connect(func():
		var r := Rect2(Vector2.ZERO, bar.size)
		bar.draw_rect(r, Color(0, 0, 0, 0.35))
		if frac > 0.0:
			bar.draw_rect(Rect2(Vector2.ZERO, Vector2(bar.size.x * frac, bar.size.y)), color)
		bar.draw_rect(r, Color(1, 1, 1, 0.18), false, 1.0))
	row.add_child(bar)
	var done := total > 0 and have >= total
	var v := UiKit.label(("%d/%d" % [have, total]) + (" ✓" if done else ""), 14 if small else 16, Color(0.55, 0.95, 0.75) if done else Color.WHITE)
	v.custom_minimum_size.x = 92
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	v.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(v)

# --- RESUMO ---

func _build_summary() -> void:
	_msg.text = tr("Conquistas: %d/%d") % [Stats.unlocked_count(), CardDB.achievements.size()]
	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 20)
	columns.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_body.add_child(columns)
	var s := Stats.stats()
	var rows := [
		[tr("Runs jogadas"), str(int(s.get("runs", 0)))],
		[tr("Runs vencidas"), str(int(s.get("wins", 0)))],
		[tr("Melhor ante"), str(int(s.get("best_ante", 0)))],
		[tr("Maior ataque"), Cascade.fmt_int(int(s.get("best_attack", 0)))],
		[tr("Dano total"), Cascade.fmt_int(int(s.get("total_damage", 0)))],
		[tr("Inimigos derrotados"), tr("%d (%d bosses)") % [int(s.get("enemies", 0)), int(s.get("bosses", 0))]],
		[tr("Cartas jogadas"), str(int(s.get("cards_played", 0)))],
		[tr("Canalizações"), str(int(s.get("channels", 0)))],
		[tr("Turnos"), str(int(s.get("turns", 0)))],
		[tr("Eventos"), str(int(s.get("events", 0)))],
		[tr("Runs Rápidas vencidas"), str(int(s.get("quick_wins", 0)))],
		[tr("Quebra-cabeças resolvidos"), "%d/%d" % [int(s.get("puzzles_solved", 0)), CardDB.puzzles.size()]],
		[tr("Baralhos jogados"), "%d/%d" % [Stats.decks_played(), CardDB.decks.size()]],
	]
	var left_scroll := ScrollContainer.new()
	left_scroll.custom_minimum_size = Vector2(520, 0)
	left_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	columns.add_child(left_scroll)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 20)
	grid.add_theme_constant_override("v_separation", 2)
	left_scroll.add_child(grid)
	for r in rows:
		var k := UiKit.label(r[0], 18, UiKit.TEXT_DIM)
		k.custom_minimum_size.x = 300
		grid.add_child(k)
		grid.add_child(UiKit.label(r[1], 18))
	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 4)
	columns.add_child(right)
	right.add_child(UiKit.label(tr("Por baralho (melhor ante · vitórias · nível)"), 17, UiKit.GOLD))
	var deck_scroll := ScrollContainer.new()
	deck_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	deck_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	right.add_child(deck_scroll)
	var deck_list := VBoxContainer.new()
	deck_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	deck_list.add_theme_constant_override("separation", 1)
	deck_scroll.add_child(deck_list)
	for d in CardDB.decks:
		var id := String(d.get("id", ""))
		var best := GameState.best_ante(id)
		var lvl := GameState.deck_level(id)
		var line := "%02d  %s  —  %s  ·  %d  ·  %s" % [int(d.get("num", 0)), tr(String(d.get("name", ""))), (tr("ante %d") % best) if best > 0 else "—", GameState.wins(id), tr("Nv. %d") % lvl]
		var l := UiKit.label(line, 15, Color.WHITE if best > 0 else UiKit.TEXT_DIM)
		l.clip_text = true
		deck_list.add_child(l)

# --- HISTÓRICO ---

func _build_history() -> void:
	var h := GameState.run_history()
	_msg.text = tr("As tuas últimas %d runs (no máximo %d).") % [h.size(), GameState.HISTORY_MAX] if not h.is_empty() else ""
	var list := _scroll_list(6)
	if h.is_empty():
		var empty := UiKit.label(tr("Ainda não acabaste nenhuma run. As runs acabadas (vitórias, derrotas e abandonos) aparecem aqui."), 18, UiKit.TEXT_DIM, true)
		list.add_child(empty)
		return
	var i := 0
	for e in h:
		if e is Dictionary:
			list.add_child(_history_row(e, i))
			i += 1

func _history_row(e: Dictionary, index: int) -> Control:
	var won := bool(e.get("won", false))
	var abandoned := bool(e.get("abandoned", false))
	var accent := Color(0.5, 0.95, 0.6) if won else (UiKit.TEXT_DIM if abandoned else Color(0.95, 0.5, 0.5))
	var panel := PanelContainer.new()
	panel.name = "Run_%d" % index
	panel.add_theme_stylebox_override("panel", UiKit.flat(UiKit.BG_LIGHT if won else UiKit.BG, 10, accent.darkened(0.3), 2, 8))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	panel.add_child(row)
	var badge := UiKit.label("✓" if won else ("—" if abandoned else "✗"), 30, accent)
	badge.custom_minimum_size.x = 34
	badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	badge.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(badge)
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.add_theme_constant_override("separation", 0)
	row.add_child(info)
	info.add_child(UiKit.label("%s  ·  %s" % [_run_title(e), tr(_mode_label(e))], 19, UiKit.GOLD if won else Color.WHITE))
	var result := tr("Venceu") if won else (tr("Abandonada no ante %d") % int(e.get("ante", 1)) if abandoned else tr("Caiu no ante %d") % int(e.get("ante", 1)))
	if bool(e.get("endless", false)):
		result = tr("Infinito: ante %d") % int(e.get("ante", 1))
	var mvp := String(e.get("mvp", ""))
	var mvp_card: CardData = CardDB.get_card(mvp) if mvp != "" else null
	var line2 := "%s  ·  %s %s  ·  %s %s" % [result, tr("maior golpe"), Cascade.fmt_int(int(e.get("best_hit", 0))), tr("dano total"), Cascade.fmt_int(int(e.get("damage", 0)))]
	if mvp_card != null:
		line2 += "  ·  " + tr("MVP: %s") % mvp_card.display_name()
	var l2 := UiKit.label(line2, 15, Color(0.85, 0.85, 0.92))
	l2.clip_text = true
	info.add_child(l2)
	var bits: PackedStringArray = [SlotPicker.ago(float(e.get("t", 0))), tr(String(GameState.DIFFICULTY_NAMES.get(String(e.get("difficulty", "normal")), "Normal")))]
	if int(e.get("stake", 1)) > 1:
		bits.append(tr("Selo %d") % int(e.get("stake", 1)))
	bits.append(tr("%d cartas · %d relíquias") % [int(e.get("cards", 0)), int(e.get("relics", 0))])
	bits.append(tr("Seed: %d") % int(e.get("seed", 0)))
	var l3 := UiKit.label("  ·  ".join(bits), 14, UiKit.TEXT_DIM)
	l3.clip_text = true
	info.add_child(l3)
	return panel

func _run_title(e: Dictionary) -> String:
	var ch := String(e.get("challenge", ""))
	var saga := String(e.get("saga", ""))
	var t := ""
	if ch != "":
		t = tr(String(CardDB.get_challenge(ch).get("name", ch)))
	elif saga != "":
		t = tr(String(CardDB.get_saga_chapter(saga).get("name", saga)))
	else:
		t = tr(String(e.get("deck", "")))
	var n := String(e.get("name", ""))
	return ("«%s» %s" % [n, t]) if n != "" else t

func _mode_label(e: Dictionary) -> String:
	var m := String(e.get("mode", "campaign"))
	if m == "campaign" and bool(e.get("free", false)):
		return "Modo Livre"
	return GameState.mode_name(m)

# --- CARTAS ---

func _build_cards() -> void:
	var all := GameState.card_stats()
	var sorts := HBoxContainer.new()
	sorts.add_theme_constant_override("separation", 8)
	_body.add_child(sorts)
	sorts.add_child(UiKit.label(tr("Ordenar:"), 17, UiKit.TEXT_DIM))
	for so in CARD_SORTS:
		var b := UiKit.button(tr(String(so[1])), 42, 16)
		b.name = "Sort_" + String(so[0])
		b.custom_minimum_size.x = 120
		b.toggle_mode = true
		b.button_pressed = card_sort == so[0]
		b.pressed.connect(func():
			Sfx.select()
			card_sort = String(so[0])
			select_tab("cards"))
		sorts.add_child(b)
	_msg.text = tr("%d cartas usadas nas tuas runs. Toca numa para a ver em grande.") % all.size() if not all.is_empty() else ""
	var list := _scroll_list(3)
	if all.is_empty():
		list.add_child(UiKit.label(tr("Ainda não há dados. Joga e acaba uma run: cada carta guarda o dano que fez, as vezes que a jogaste e as runs em que esteve."), 18, UiKit.TEXT_DIM, true))
		return
	list.add_child(_card_row(null, -1, {}))
	var ids := sorted_card_ids(all, card_sort)
	for i in mini(ids.size(), CARD_ROWS):
		var cd := CardDB.get_card(String(ids[i]))
		if cd != null:
			list.add_child(_card_row(cd, i, all[ids[i]]))

## Ids ordenados pelo critério (dano, jogadas, runs ou % de vitórias; desempata pelo dano).
static func sorted_card_ids(all: Dictionary, by: String) -> Array:
	var ids: Array = all.keys()
	var key := func(id) -> float:
		var e: Dictionary = all[id] if all[id] is Dictionary else {}
		match by:
			"plays":
				return float(e.get("plays", 0))
			"runs":
				return float(e.get("runs", 0))
			"rate":
				var r := int(e.get("runs", 0))
				return (float(e.get("wins", 0)) / r) if r >= 3 else -1.0   # com menos de 3 runs ainda não diz nada
		return float(e.get("dmg", 0))
	ids.sort_custom(func(a, b):
		var ka: float = key.call(a)
		var kb: float = key.call(b)
		if ka != kb:
			return ka > kb
		return int(all[a].get("dmg", 0)) > int(all[b].get("dmg", 0)))
	return ids

func _card_row(cd: CardData, index: int, e: Dictionary) -> Control:
	var header := cd == null
	var b := Button.new()
	b.custom_minimum_size = Vector2(0, 30 if header else 40)
	b.focus_mode = Control.FOCUS_NONE
	var style := UiKit.flat(Color(0, 0, 0, 0) if header else (UiKit.BG_LIGHT if index % 2 == 0 else UiKit.BG), 8, Color(0, 0, 0, 0), 0, 4)
	for st in ["normal", "hover", "pressed", "disabled"]:
		b.add_theme_stylebox_override(st, style if st != "pressed" else UiKit.flat(UiKit.BG_LIGHT.lightened(0.1), 8, Color(0, 0, 0, 0), 0, 4))
	if header:
		b.disabled = true
		b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	else:
		b.name = "Card_" + cd.id
		b.pressed.connect(func(): Sfx.select(); CardZoom.show_data(cd))
	var row := HBoxContainer.new()
	row.set_anchors_preset(Control.PRESET_FULL_RECT)
	row.offset_left = 10
	row.offset_right = -10
	row.add_theme_constant_override("separation", 10)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(row)
	var runs := int(e.get("runs", 0))
	var cells: Array = []
	if header:
		cells = [["#", 44], [tr("Carta"), -1], [tr("Dano"), 150], [tr("Jogadas"), 110], [tr("Runs"), 90], [tr("% vitórias"), 120]]
	else:
		cells = [[str(index + 1), 44], [cd.display_name(), -1], [Cascade.fmt_int(int(e.get("dmg", 0))), 150], [str(int(e.get("plays", 0))), 110],
			[str(runs), 90], [("%d%%" % roundi(100.0 * int(e.get("wins", 0)) / runs)) if runs > 0 else "—", 120]]
	var ci := 0
	for c in cells:
		var col: Color = UiKit.TEXT_DIM
		if not header:
			col = (CardView.COLORS.get(cd.primary_color(), Color.WHITE) as Color).lightened(0.35) if ci == 1 else Color.WHITE
		var l := UiKit.label(String(c[0]), 15 if header else 17, col)
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		l.size_flags_vertical = Control.SIZE_EXPAND_FILL
		if int(c[1]) < 0:
			l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			l.clip_text = true
		else:
			l.custom_minimum_size.x = int(c[1])
			l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT if ci >= 2 else HORIZONTAL_ALIGNMENT_LEFT
		row.add_child(l)
		ci += 1
	return b

# --- CONQUISTAS ---

func _build_achievements() -> void:
	_msg.text = tr("Conquistas: %d/%d") % [Stats.unlocked_count(), CardDB.achievements.size()]
	var list := _scroll_list(4)
	for a in CardDB.achievements:
		var id := String(a.get("id", ""))
		var unlocked := Stats.is_unlocked(id)
		var panel := PanelContainer.new()
		panel.add_theme_stylebox_override("panel", UiKit.flat(UiKit.BG_LIGHT if unlocked else UiKit.BG, 8, UiKit.GOLD if unlocked else UiKit.BORDER, 2, 8))
		var row := VBoxContainer.new()
		row.add_theme_constant_override("separation", 0)
		panel.add_child(row)
		row.add_child(UiKit.label(("★ " if unlocked else "☆ ") + tr(String(a.get("name", id))), 18, UiKit.GOLD if unlocked else UiKit.TEXT_DIM))
		row.add_child(UiKit.label(tr(String(a.get("text", ""))), 14, Color.WHITE if unlocked else UiKit.TEXT_DIM, true))
		var u: Dictionary = a.get("unlock", {}) if a.get("unlock") is Dictionary else {}
		if not u.is_empty():
			row.add_child(UiKit.label(("✓ " if unlocked else "") + Stats.unlock_label(u), 13, Color(0.55, 0.95, 0.75) if unlocked else Color(0.6, 0.75, 0.7), true))
		list.add_child(panel)

# --- Exportar ---

func csv_text() -> String:
	return GameState.history_csv() if tab == "history" else GameState.card_stats_csv()

func _on_copy_csv() -> void:
	DisplayServer.clipboard_set(csv_text())
	Sfx.select()
	_msg.text = tr("Copiado em CSV — cola numa folha de cálculo (Google Sheets, Excel).")

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
