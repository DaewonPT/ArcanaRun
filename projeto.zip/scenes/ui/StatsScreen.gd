extends Control
## Estatísticas (contadores globais e por baralho) e conquistas.

func _ready() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 10)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	margin.add_child(vbox)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 16)
	vbox.add_child(header)
	var back := UiKit.button(tr("◀ MENU"), 52, 20)
	back.custom_minimum_size.x = 140
	back.pressed.connect(func(): Sfx.select(); SceneRouter.go("main"))
	header.add_child(back)
	var title := UiKit.label(tr("ESTATÍSTICAS"), 30, UiKit.GOLD)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(title)
	var ach_count := UiKit.label(tr("Conquistas: %d/%d") % [Stats.unlocked_count(), CardDB.achievements.size()], 20, UiKit.TEXT_DIM)
	ach_count.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(ach_count)

	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 16)
	columns.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(columns)

	# Esquerda: números globais + baralhos.
	var left := VBoxContainer.new()
	left.custom_minimum_size = Vector2(560, 0)
	left.add_theme_constant_override("separation", 6)
	columns.add_child(left)
	var s := Stats.stats()
	var rows := [
		[tr("Runs jogadas"), str(int(s.get("runs", 0)))],
		[tr("Runs vencidas"), str(int(s.get("wins", 0)))],
		[tr("Melhor ante"), str(int(s.get("best_ante", 0)))],
		[tr("Maior ataque"), Cascade.fmt_int(int(s.get("best_attack", 0)))],
		[tr("Dano total"), Cascade.fmt_int(int(s.get("total_damage", 0)))],
		[tr("Inimigos derrotados"), "%d (%d bosses)" % [int(s.get("enemies", 0)), int(s.get("bosses", 0))]],
		[tr("Cartas jogadas"), str(int(s.get("cards_played", 0)))],
		[tr("Canalizações"), str(int(s.get("channels", 0)))],
		[tr("Turnos"), str(int(s.get("turns", 0)))],
		[tr("Eventos"), str(int(s.get("events", 0)))],
		[tr("Baralhos jogados"), "%d/18" % Stats.decks_played()],
	]
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 20)
	grid.add_theme_constant_override("v_separation", 2)
	left.add_child(grid)
	for r in rows:
		var k := UiKit.label(r[0], 18, UiKit.TEXT_DIM)
		k.custom_minimum_size.x = 300
		grid.add_child(k)
		grid.add_child(UiKit.label(r[1], 18))
	left.add_child(UiKit.label(tr("Por baralho (melhor ante · vitórias)"), 17, UiKit.GOLD))
	var deck_scroll := ScrollContainer.new()
	deck_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	deck_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	left.add_child(deck_scroll)
	var deck_list := VBoxContainer.new()
	deck_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	deck_list.add_theme_constant_override("separation", 1)
	deck_scroll.add_child(deck_list)
	for d in CardDB.decks:
		var id := String(d.get("id", ""))
		var best := GameState.best_ante(id)
		var line := "%02d  %s  —  %s  ·  %d" % [int(d.get("num", 0)), tr(String(d.get("name", ""))), (tr("ante %d") % best) if best > 0 else "—", GameState.wins(id)]
		deck_list.add_child(UiKit.label(line, 15, Color.WHITE if best > 0 else UiKit.TEXT_DIM))

	# Direita: conquistas.
	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 6)
	columns.add_child(right)
	right.add_child(UiKit.label(tr("CONQUISTAS"), 20, UiKit.GOLD))
	var ach_scroll := ScrollContainer.new()
	ach_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	ach_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	right.add_child(ach_scroll)
	var ach_list := VBoxContainer.new()
	ach_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ach_list.add_theme_constant_override("separation", 4)
	ach_scroll.add_child(ach_list)
	for a in CardDB.achievements:
		var id := String(a.get("id", ""))
		var unlocked := Stats.is_unlocked(id)
		var panel := PanelContainer.new()
		panel.add_theme_stylebox_override("panel", UiKit.flat(UiKit.BG_LIGHT if unlocked else UiKit.BG, 8, UiKit.GOLD if unlocked else UiKit.BORDER, 2, 8))
		var row := VBoxContainer.new()
		row.add_theme_constant_override("separation", 0)
		panel.add_child(row)
		row.add_child(UiKit.label(("★ " if unlocked else "☆ ") + tr(String(a.get("name", id))), 18, UiKit.GOLD if unlocked else UiKit.TEXT_DIM))
		row.add_child(UiKit.label(tr(String(a.get("text", ""))), 14, Color.WHITE if unlocked else UiKit.TEXT_DIM, true))
		ach_list.add_child(panel)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and not SceneRouter.has_overlay():
		SceneRouter.go("main")
