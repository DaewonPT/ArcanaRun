class_name NewsOverlay
extends Control
## Ecrã "Novidades": a nota da versão (data/news.json) dentro do jogo. Abre sozinho na primeira
## vez que o jogo arranca depois de uma atualização (menos para quem nunca jogou) e volta a abrir
## ao tocar na versão no menu principal.

static func current() -> Dictionary:
	return CardDB.news[0] if not CardDB.news.is_empty() and CardDB.news[0] is Dictionary else {}

## Mostra as novidades se esta versão ainda não foi vista; quem nunca jogou só fica marcado.
static func maybe_show() -> void:
	var n := current()
	var v := String(n.get("version", ""))
	if v == "" or String(GameState.progress.get("news_seen", "")) == v:
		return
	var played := Stats.get_stat("runs") > 0 or Stats.tutorial_done()
	GameState.progress["news_seen"] = v
	GameState.save_progress()
	if played and not bool(Settings.opt("news_auto")):   # 0.19.0 (192): só quando quiseres (o botão NOVIDADES)
		SceneRouter.toast(TranslationServer.translate("Há novidades da versão %s: toca em NOVIDADES.") % v, 3.0, false)
		return
	if played:
		open()

static func open() -> NewsOverlay:
	var n := current()
	if n.is_empty():
		return null
	var o := NewsOverlay.new()
	SceneRouter.show_overlay(o)
	o._build(n)
	return o

## 202: "training" (o Treino), "school" (a Escola do Mago) ou "howto:<título>" (o Como Jogar nessa página).
static func try_now(target: String) -> void:
	if target.begins_with("howto:"):
		HowToPlay.open_at(target.substr(6))
	elif target == "training":
		SceneRouter.go("training")
	elif target == "school":
		SceneRouter.go("school")

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.8))

func _build(n: Dictionary) -> void:
	var panel := UiKit.centered_panel(self, 820, UiKit.BG, UiKit.GOLD)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	panel.add_child(vbox)
	var title := UiKit.label(tr(String(n.get("title", "Novidades"))), 30, UiKit.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 430)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(scroll)
	var list := VBoxContainer.new()
	list.add_theme_constant_override("separation", 8)
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(list)
	for item in n.get("items", []):
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		list.add_child(row)
		var dot := UiKit.label("✦", 18, UiKit.GOLD)
		dot.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
		row.add_child(dot)
		var l := UiKit.label(tr(String(item)), 19, Color.WHITE, true)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(l)
	var buttons := HBoxContainer.new()
	buttons.alignment = BoxContainer.ALIGNMENT_CENTER
	buttons.add_theme_constant_override("separation", 12)
	vbox.add_child(buttons)
	# 0.19.0 (202): «Experimentar já» — abre o que é novo (o Treino, a Escola ou a página do Como Jogar).
	var tr_target := String(n.get("try", ""))
	if tr_target != "":
		var tb := UiKit.button(tr("EXPERIMENTAR JÁ"), 56, 20)
		tb.name = "TryNow"
		tb.custom_minimum_size.x = 260
		tb.pressed.connect(func():
			Sfx.select()
			UiKit.close_animated(self)
			try_now(tr_target))
		buttons.add_child(tb)
	var ok := UiKit.button(tr("VAMOS A ISSO"), 56, 22, UiKit.PRIMARY, Color(0, 0, 0, 0))
	ok.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ok.pressed.connect(func(): Sfx.select(); UiKit.close_animated(self))
	buttons.add_child(ok)
	UiKit.pop_in(panel)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		UiKit.close_animated(self)
