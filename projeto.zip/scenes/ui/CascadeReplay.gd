class_name CascadeReplay
extends Control
## "Rever o maior golpe" (0.11.0): repete, passo a passo, a cascata do maior golpe da run
## (GameState.run_log.best_cascade): cada carta, relíquia ou formação aparece com o que deu, o Poder ×
## Mult vai subindo e no fim o total conta como na batalha. Tocar acelera; no fim, FECHAR.

const KIND_COLORS := {
	"creature": Color(0.22, 0.74, 0.97), "spell": Color(0.6, 0.7, 1.0), "formation": Color(0.98, 0.75, 0.25),
	"hand": Color(0.75, 0.75, 0.85), "relic": Color(0.98, 0.85, 0.3), "planeswalker": Color(0.98, 0.75, 0.25),
	"climate": Color(0.35, 0.8, 0.85), "chain": Color(0.95, 0.6, 0.85), "tribe": Color(0.6, 0.95, 0.6),
	"enchantment": Color(0.35, 0.9, 0.85), "equipment": Color(0.95, 0.72, 0.42), "seal_set": Color(0.9, 0.5, 0.9), "rule": Color(1.0, 0.55, 0.35),
}

var _panel: PanelContainer
var _list: VBoxContainer
var _scroll: ScrollContainer
var _power: Label
var _mult: Label
var _total: Label
var _fast := false
var _done := false

static func open(snapshot: Dictionary) -> CascadeReplay:
	var v := CascadeReplay.new()
	SceneRouter.show_overlay(v)
	v._build(snapshot)
	return v

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.82))

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed:
		_fast = true

func _build(snap: Dictionary) -> void:
	_panel = UiKit.centered_panel(self, 760)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	_panel.add_child(vbox)
	var head := String(snap.get("title", ""))   # 0.13.0: "O ÚLTIMO ATAQUE · Turno N" (rever na batalha)
	if head == "":
		head = tr("O MAIOR GOLPE") + "  ·  " + tr("Ante %d") % int(snap.get("ante", 1))
	vbox.add_child(UiKit.label(head, 28, UiKit.GOLD))
	var forms: Array = snap.get("formations", [])
	if not forms.is_empty():
		vbox.add_child(UiKit.label(tr("Formações: %s") % ", ".join(PackedStringArray(forms)), 16, UiKit.TEXT_DIM, true))
	var pills := HBoxContainer.new()
	pills.alignment = BoxContainer.ALIGNMENT_CENTER
	pills.add_theme_constant_override("separation", 14)
	vbox.add_child(pills)
	_power = _pill(pills, Color(0.22, 0.74, 0.97))
	pills.add_child(UiKit.label("×", 30, UiKit.TEXT_DIM))
	_mult = _pill(pills, Color(0.95, 0.3, 0.4))
	pills.add_child(UiKit.label("=", 30, UiKit.TEXT_DIM))
	_total = UiKit.label("0", 34, Color(1, 0.92, 0.6))
	_total.custom_minimum_size.x = 180
	pills.add_child(_total)
	_scroll = ScrollContainer.new()
	_scroll.custom_minimum_size = Vector2(0, 330)
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vbox.add_child(_scroll)
	_list = VBoxContainer.new()
	_list.add_theme_constant_override("separation", 2)
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll.add_child(_list)
	var close_btn := UiKit.button(tr("FECHAR"), 50, 18)
	close_btn.pressed.connect(close)
	vbox.add_child(close_btn)
	UiKit.pop_in(_panel)
	_play(snap)

func _pill(parent: Control, color: Color) -> Label:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UiKit.flat(color, 10, Color(0, 0, 0, 0), 0, 8))
	p.custom_minimum_size = Vector2(130, 0)
	var l := UiKit.label("0", 28, Color(0.05, 0.05, 0.08))
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	p.add_child(l)
	parent.add_child(p)
	return l

func _play(snap: Dictionary) -> void:
	var steps: Array = snap.get("steps", [])
	var i := 0
	for st in steps:
		if not is_inside_tree():
			return
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		var col: Color = KIND_COLORS.get(String(st.get("kind", "")), Color.WHITE)
		var card_col := String(st.get("color", ""))
		if card_col != "":
			row.add_child(CardIcon.pip(card_col, 12.0))
		var name_l := UiKit.label(("↻ " if bool(st.get("retrigger", false)) else "") + String(st.get("name", "")), 17, Color.WHITE)
		name_l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name_l.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		row.add_child(name_l)
		row.add_child(UiKit.label(String(st.get("label", "")), 17, col))
		var pad := Control.new()
		pad.custom_minimum_size.x = 14   # espaço para a barra de deslocamento
		row.add_child(pad)
		_list.add_child(row)
		_power.text = Cascade.fmt_int(int(st.get("power", 0)))
		_mult.text = Cascade.fmt_mult(float(st.get("mult", 1.0)))
		Sfx.blip(mini(i, 30))
		await get_tree().process_frame
		if is_instance_valid(_scroll):
			_scroll.scroll_vertical = int(_scroll.get_v_scroll_bar().max_value)
		if not _fast:
			await get_tree().create_timer(Settings.dur(maxf(0.08, 0.26 - i * 0.01))).timeout
		i += 1
	var total := int(snap.get("total", 0))
	if not _fast:
		for k in range(1, 15):
			if not is_inside_tree():
				return
			var t := float(k) / 14.0
			_total.text = Cascade.fmt_int(int(round(total * t * t)))
			Sfx.blip(mini(30, i + k))
			await get_tree().create_timer(Settings.dur(0.035)).timeout
	if not is_inside_tree():
		return
	_total.text = Cascade.fmt_int(total)
	_total.pivot_offset = _total.size / 2.0
	var tw := create_tween()
	tw.tween_property(_total, "scale", Vector2(1.3, 1.3), 0.12)
	tw.tween_property(_total, "scale", Vector2.ONE, 0.2)
	Sfx.boom()
	_done = true

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Sfx.select()
	UiKit.close_animated(self)
