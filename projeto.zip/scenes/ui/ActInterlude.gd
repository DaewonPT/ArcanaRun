class_name ActInterlude
extends Control
## Interlúdio de ato: ao entrar num ato novo (e no infinito, a cada clima novo) aparece um ecrã curto
## com o nome do ato, uma frase de história (data/acts.json) e o Clima Planar que vem aí.
## Mostra-se uma vez por ato (GameState.interlude_key, gravado com a run). Toca para continuar.
## 0.16.1 (67): por trás, a ilustração do ato (ou do clima) a aproximar-se devagar; a história escreve-se
## letra a letra (o primeiro toque mostra-a toda; o segundo continua). Sem movimento: tudo de uma vez.

signal finished

var _panel: Control
var _closing := false
var _story: Label
var _typing: Tween
var _bg: Control
var _bg_tex: Texture2D
var _zoom := 1.0
var _t := 0.0

## Abre o interlúdio do ato do ante atual, se ainda não foi visto. Devolve null se não houver.
static func open_if_new() -> ActInterlude:
	var key := GameState.climate_key(GameState.ante)
	if key == GameState.interlude_key or GameState.puzzle_id != "":
		return null
	# 0.19.0 (198): com «Interlúdios: só a 1.ª vez», os que já viste não voltam a abrir.
	if not (GameState.progress.get("interludes_seen") is Array):
		GameState.progress["interludes_seen"] = []
	var seen: Array = GameState.progress["interludes_seen"]
	var act_key := "act_%d" % GameState.act_of_ante(GameState.ante)
	if String(Settings.opt("interludes")) == "first" and act_key in seen:
		GameState.interlude_key = key
		return null
	if not (act_key in seen):
		seen.append(act_key)
	var v := ActInterlude.new()
	SceneRouter.show_overlay(v)
	v._build(key)
	return v

## 92: «No ato I ganhaste: +45 ouro · 4 cartas · 2 relíquias» ("" se não há registo).
static func act_summary_text(act: int) -> String:
	var d := Economy.act_summary(act)
	if d.is_empty():
		return ""
	var parts: Array[String] = []
	parts.append(TranslationServer.translate("+%d ouro") % int(d.get("gold", 0)))
	parts.append(TranslationServer.translate("%d carta(s)") % int(d.get("cards", 0)))
	parts.append(TranslationServer.translate("%d relíquia(s)") % int(d.get("relics", 0)))
	return TranslationServer.translate("No ato %s ganhaste: %s") % [GameState.ACT_NAMES[clampi(act - 1, 0, 4)], "  ·  ".join(PackedStringArray(parts))]

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	set_process(false)

func _build(key: String) -> void:
	GameState.interlude_key = key
	GameState.save_run({}, "map")
	var endless := key.begins_with("E")
	var act_def := CardDB.get_act("E" if endless else key)
	# A ilustração do clima que aí vem (ou a do ato), a aproximar-se devagar por trás do texto.
	var climate_id := GameState.climate_for_ante(GameState.ante)
	_bg_tex = ArtLib.texture("background", "clim_" + climate_id) if climate_id != "" else null
	if _bg_tex == null:
		var act_n := GameState.act_of_ante(GameState.ante)
		_bg_tex = ArtLib.texture("background", "act_E" if endless or act_n >= 5 else "act_%d" % act_n)
	_bg = Control.new()
	_bg.name = "InterludeArt"
	_bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_bg.draw.connect(_draw_bg)
	add_child(_bg)
	add_child(UiKit.dim(0.74 if _bg_tex != null else 0.92))
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(center)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 14)
	vbox.custom_minimum_size.x = 820
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(vbox)
	_panel = vbox
	var act_label := UiKit.label(tr("ANTE %d") % GameState.ante if endless else tr("ATO %s") % GameState.act_name(), 22, UiKit.TEXT_DIM)
	act_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(act_label)
	var title := UiKit.label(tr(String(act_def.get("title", ""))), 52, UiKit.GOLD, true)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	var story := UiKit.label(tr(String(act_def.get("story", ""))), 22, Color(0.9, 0.88, 0.95), true)
	story.name = "Story"
	story.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(story)
	_story = story
	# 0.19.0 (92): o resumo do ato que acabou — ouro, cartas e relíquias ganhos.
	var act_n := GameState.act_of_ante(GameState.ante)
	if not endless and act_n > 1:
		var sum_txt := act_summary_text(act_n - 1)
		if sum_txt != "":
			var sl := UiKit.label(sum_txt, 19, UiKit.COIN, true)
			sl.name = "ActSummary"
			sl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			vbox.add_child(sl)
	var climate := GameState.climate_for_ante(GameState.ante)
	if climate != "":
		var c := CardDB.get_climate(climate)
		var box := PanelContainer.new()
		box.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_theme_stylebox_override("panel", UiKit.flat(Color(0.1, 0.16, 0.2), 14, Color(0.35, 0.8, 0.85), 2, 16))
		vbox.add_child(box)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 14)
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_child(row)
		var icon := CardIcon.new("climate", Color(0.35, 0.8, 0.85), 44.0)
		icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		row.add_child(icon)
		var texts := VBoxContainer.new()
		texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		texts.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(texts)
		texts.add_child(UiKit.label(tr("Clima deste ato: %s") % tr(String(c.get("name", ""))), 22, Color(0.55, 0.9, 0.95)))
		texts.add_child(UiKit.label(tr(String(c.get("text", ""))), 18, Color.WHITE, true))
	var hint := UiKit.label(tr("Toca para continuar"), 16, UiKit.TEXT_DIM)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(hint)
	Sfx.boom()
	modulate.a = 0.0
	var tw := create_tween()
	tw.tween_property(self, "modulate:a", 1.0, Settings.dur(0.35))
	var cps := Settings.typewriter_cps()   # 0.19.0 (163): a velocidade à escolha (ou o texto todo de uma vez)
	if Settings.motion_ok() and DisplayServer.get_name() != "headless" and cps > 0.0:
		# A história letra a letra (depois de o ecrã aparecer) e o fundo a aproximar-se.
		_story.visible_ratio = 0.0
		_typing = create_tween()
		_typing.tween_interval(Settings.dur(0.4))
		_typing.tween_property(_story, "visible_ratio", 1.0, maxf(0.6, _story.text.length() / cps))
		set_process(_bg_tex != null)

## Ken Burns: aproxima ~8 % em 10 s e desliza um pouco (redesenha a ~30 fps).
func _process(delta: float) -> void:
	_t += delta
	_zoom = 1.0 + 0.08 * clampf(_t / 10.0, 0.0, 1.0)
	_bg.queue_redraw()

func _draw_bg() -> void:
	if _bg_tex == null:
		return
	var s := _bg.size
	var src := ArtLib.cover_region(_bg_tex, s, 0.5)
	var shrink := src.size / _zoom
	var drift := Vector2(0.015, -0.01) * clampf(_t / 10.0, 0.0, 1.0) * src.size
	var r := Rect2(src.get_center() - shrink * 0.5 + drift, shrink)
	r.position = r.position.clamp(Vector2.ZERO, _bg_tex.get_size() - r.size)
	_bg.draw_texture_rect_region(_bg_tex, Rect2(Vector2.ZERO, s), r)

## O texto ainda a escrever-se? (o primeiro toque mostra-o todo)
func typing() -> bool:
	return _typing != null and _typing.is_valid() and _typing.is_running() and _story != null and _story.visible_ratio < 1.0

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and not event.pressed:
		accept_event()
		if typing():
			_typing.kill()
			_story.visible_ratio = 1.0
			return
		close()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if _closing or is_queued_for_deletion():
		return
	_closing = true
	Sfx.select()
	var d := Settings.dur(0.25)
	if d > 0.0:
		var tw := create_tween()
		tw.tween_property(self, "modulate:a", 0.0, d)
		await tw.finished
	finished.emit()
	queue_free()
