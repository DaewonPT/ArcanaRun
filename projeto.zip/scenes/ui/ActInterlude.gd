class_name ActInterlude
extends Control
## Interlúdio de ato: ao entrar num ato novo (e no infinito, a cada clima novo) aparece um ecrã curto
## com o nome do ato, uma frase de história (data/acts.json) e o Clima Planar que vem aí.
## Mostra-se uma vez por ato (GameState.interlude_key, gravado com a run). Toca para continuar.

signal finished

var _panel: Control
var _closing := false

## Abre o interlúdio do ato do ante atual, se ainda não foi visto. Devolve null se não houver.
static func open_if_new() -> ActInterlude:
	var key := GameState.climate_key(GameState.ante)
	if key == GameState.interlude_key or GameState.puzzle_id != "":
		return null
	var v := ActInterlude.new()
	SceneRouter.show_overlay(v)
	v._build(key)
	return v

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.92))

func _build(key: String) -> void:
	GameState.interlude_key = key
	GameState.save_run({}, "map")
	var endless := key.begins_with("E")
	var act_def := CardDB.get_act("E" if endless else key)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(center)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 14)
	vbox.custom_minimum_size.x = 820
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(vbox)
	_panel = vbox
	var act_label := UiKit.label(tr("ANTE %d") % GameState.ante if endless else tr("ATO %s") % GameState.act_name(), 22, UiKit.TEXT_DIM)
	act_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(act_label)
	var title := UiKit.label(tr(String(act_def.get("title", ""))), 52, UiKit.GOLD, true)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	var story := UiKit.label(tr(String(act_def.get("story", ""))), 22, Color(0.9, 0.88, 0.95), true)
	story.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(story)
	var climate := GameState.climate_for_ante(GameState.ante)
	if climate != "":
		var c := CardDB.get_climate(climate)
		var box := PanelContainer.new()
		box.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_theme_stylebox_override("panel", UiKit.flat(Color(0.1, 0.16, 0.2), 14, Color(0.35, 0.8, 0.85), 2, 16))
		vbox.add_child(box)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 14)
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_child(row)
		var icon := CardIcon.new("climate", Color(0.35, 0.8, 0.85), 44.0)
		icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		row.add_child(icon)
		var texts := VBoxContainer.new()
		texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		texts.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(texts)
		texts.add_child(UiKit.label(tr("Clima deste ato: %s") % tr(String(c.get("name", ""))), 22, Color(0.55, 0.9, 0.95)))
		texts.add_child(UiKit.label(tr(String(c.get("text", ""))), 18, Color.WHITE, true))
	var hint := UiKit.label(tr("Toca para continuar"), 16, UiKit.TEXT_DIM)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(hint)
	Sfx.boom()
	modulate.a = 0.0
	var tw := create_tween()
	tw.tween_property(self, "modulate:a", 1.0, Settings.dur(0.35))

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and not event.pressed:
		accept_event()
		close()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if _closing or is_queued_for_deletion():
		return
	_closing = true
	Sfx.select()
	var d := Settings.dur(0.25)
	if d > 0.0:
		var tw := create_tween()
		tw.tween_property(self, "modulate:a", 0.0, d)
		await tw.finished
	finished.emit()
	queue_free()
