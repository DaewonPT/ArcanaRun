class_name CardRewardPick
extends Control
## 0.19.0 (75): a carta depois de uma batalha ganha (opção da run «Cartas depois das batalhas»): 1 de 3 cartas das
## cores do baralho, ou SALTAR por um pouco de ouro. Abre-se no mapa (Economy.pending_card_reward) e só fecha com
## uma escolha — sair para o menu deixa-a à espera.

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")

var _on_done: Callable
var _views: Array[CardView] = []
var _picked := ""
var _keep: Button
var _closed := false

static func open(on_done: Callable) -> CardRewardPick:
	var o := CardRewardPick.new()
	o._on_done = on_done
	SceneRouter.show_overlay(o)
	o._build()
	return o

func _init() -> void:
	name = "CardRewardPick"
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.8))

func _build() -> void:
	var body := UiKit.window(self, 900, tr("UMA CARTA PARA O BARALHO"), UiKit.GOLD, Callable(),
		tr("Escolhe uma das 3 ou salta e recebe %d ouro.") % Economy.CARD_SKIP_GOLD)
	var row := HBoxContainer.new()
	row.name = "Cards"
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 26)
	body.add_child(row)
	for id in Economy.pending_card_reward():
		var v: CardView = CARD_VIEW.instantiate()
		v.name = "Card_" + String(id)
		v.size_scale = 1.2
		row.add_child(v)
		v.setup(CardDB.new_instance(String(id)))
		v.pressed.connect(_on_tap.bind(String(id)))
		v.long_pressed.connect(func(c): CardZoom.show_card(c))
		_views.append(v)
	var btns := HBoxContainer.new()
	btns.alignment = BoxContainer.ALIGNMENT_CENTER
	btns.add_theme_constant_override("separation", 16)
	body.add_child(btns)
	var skip := UiKit.button(tr("SALTAR · +%d OURO") % Economy.CARD_SKIP_GOLD, 56, 19)
	skip.name = "Skip"
	skip.custom_minimum_size.x = 260
	skip.pressed.connect(choose.bind(""))
	btns.add_child(skip)
	_keep = UiKit.button(tr("FICAR COM ESTA"), 56, 20, UiKit.PRIMARY)
	_keep.name = "Keep"
	_keep.custom_minimum_size.x = 260
	_keep.disabled = true
	_keep.set_meta("haptic", true)
	UiKit.gold_plate(_keep, true)
	_keep.pressed.connect(func(): choose(_picked))
	btns.add_child(_keep)
	UiKit.pop_in(body.get_meta("panel"))

func _on_tap(_c: CardInstance, id: String) -> void:
	if _closed:
		return
	Sfx.select()
	_picked = id
	for v in _views:
		v.set_selected(v.card.data.id == id, true)
	_keep.disabled = false

## Fica com a carta `id` ("" = saltar). Também usado pelos testes.
func choose(id: String) -> void:
	if _closed:
		return
	_closed = true
	if id != "":
		Sfx.reward()
	else:
		Sfx.coin()
	UiKit.close_animated(self)
	if _on_done.is_valid():
		_on_done.call(id)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		Sfx.select()   # só fecha com uma escolha
