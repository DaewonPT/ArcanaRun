class_name ChoiceDialog
extends Control
## 0.13.0: janela simples por cima do ecrã — título, texto e botões, cada um com um valor. Tocar fora do
## painel ou "retroceder" fecha com null; com `buttons_only = true` (0.20.0) não fecha e só os botões decidem. Usada no mapa (poções e pergaminhos, maldições do Infinito,
## promessas dos eventos e o que aconteceu entre antes).
##   var d := ChoiceDialog.open(titulo, texto, [[rotulo_usar, "use", true], [rotulo_fechar, null]])
##   var v = await d.chosen
## Cada botão: [texto, valor, primário (opcional), ativo (opcional, por omissão true)].

signal chosen(value)

var _panel: PanelContainer
var _done := false
## 0.20.0 (A2): true = o toque fora e o «retroceder» não fecham; só os botões decidem. Pôr logo a seguir ao open()
## nas janelas em que fechar com null faria perder alguma coisa (a run, uma troca que só há uma vez).
var buttons_only := false
var _shake: Tween

static func open(title: String, body: String, buttons: Array, accent: Color = UiKit.GOLD) -> ChoiceDialog:
	var d := ChoiceDialog.new()
	SceneRouter.show_overlay(d)
	d._build(title, body, buttons, accent)
	return d

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.72))

func _build(title: String, body: String, buttons: Array, accent: Color) -> void:
	# 0.19.0: com muitos botões, ficam numa grelha (2 ou 3 colunas) e a janela fica mais larga; com muitos mesmo,
	# a grelha desliza.
	var n := buttons.size()
	var cols := 1 if n <= 3 else (2 if n <= 8 else 3)
	var width := 640.0 if cols == 1 else (760.0 if cols == 2 else 1040.0)
	_panel = UiKit.centered_panel(self, width, UiKit.BG, accent)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	_panel.add_child(vbox)
	var t := UiKit.label(title, 28, accent)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(t)
	if body != "":
		var scroll := ScrollContainer.new()
		scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER   # 0 empurraria a largura
		scroll.custom_minimum_size = Vector2(0, mini(360, 30 + body.count("\n") * 26 + int(body.length() / 50) * 26))
		vbox.add_child(scroll)
		var b := UiKit.label(body, 19, Color.WHITE, true)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		scroll.add_child(b)
	var row: Container
	if cols == 1:
		var hb := HBoxContainer.new()
		hb.alignment = BoxContainer.ALIGNMENT_CENTER
		hb.add_theme_constant_override("separation", 12)
		row = hb
		vbox.add_child(row)
	else:
		var grid := GridContainer.new()
		grid.name = "Choices"
		grid.columns = cols
		grid.add_theme_constant_override("h_separation", 10)
		grid.add_theme_constant_override("v_separation", 8)
		grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row = grid
		var rows := ceili(float(n) / float(cols))
		if rows > 6:
			var sc := ScrollContainer.new()
			sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
			sc.custom_minimum_size = Vector2(0, 6 * 56)
			vbox.add_child(sc)
			sc.add_child(grid)
		else:
			vbox.add_child(grid)
	var i := 0
	for spec in buttons:
		var label := String(spec[0])
		var value = spec[1] if spec.size() > 1 else null
		var primary: bool = spec.size() > 2 and bool(spec[2])
		var active: bool = spec.size() <= 3 or bool(spec[3])
		var btn := UiKit.button(label, 54 if cols == 1 else 48, 19 if cols == 1 else 16, UiKit.PRIMARY if primary else UiKit.BTN_BG)
		btn.name = "Choice%d" % i
		btn.custom_minimum_size.x = 180 if cols == 1 else (width - 60.0) / cols - 10.0
		if cols > 1:
			btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			btn.clip_text = true
			btn.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		btn.disabled = not active
		btn.pressed.connect(func(): _pick(value))
		row.add_child(btn)
		i += 1
	UiKit.hand_mirror(row)   # 0.19.0 (25): os botões do lado da mão dominante
	UiKit.pop_in(_panel)

func _pick(value) -> void:
	if _done:
		return
	_done = true
	Sfx.select()
	UiKit.close_animated(self)
	chosen.emit(value)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and not event.pressed and _panel != null and not _panel.get_global_rect().has_point(event.global_position):
		accept_event()
		_outside()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		_outside()

## Toque fora ou «retroceder»: fecha com null; com buttons_only, recusa com um som e o painel abana (para não parecer encravado).
func _outside() -> void:
	if not buttons_only:
		_pick(null)
		return
	Sfx.deny()
	if (_shake != null and _shake.is_running()) or not Settings.fx_ok("shake"):
		return
	var x := _panel.position.x
	_shake = _panel.create_tween()
	for k in 4:
		_shake.tween_property(_panel, "position:x", x + (10.0 if k % 2 == 0 else -10.0), 0.04)
	_shake.tween_property(_panel, "position:x", x, 0.04)
