class_name ChoiceDialog
extends Control
## 0.13.0: janela simples por cima do ecrã — título, texto e botões, cada um com um valor. Tocar fora do
## painel ou "retroceder" fecha com null. Usada no mapa (poções e pergaminhos, maldições do Infinito,
## promessas dos eventos e o que aconteceu entre antes).
##   var d := ChoiceDialog.open(titulo, texto, [[rotulo_usar, "use", true], [rotulo_fechar, null]])
##   var v = await d.chosen
## Cada botão: [texto, valor, primário (opcional), ativo (opcional, por omissão true)].

signal chosen(value)

var _panel: PanelContainer
var _done := false

static func open(title: String, body: String, buttons: Array, accent: Color = UiKit.GOLD) -> ChoiceDialog:
	var d := ChoiceDialog.new()
	SceneRouter.show_overlay(d)
	d._build(title, body, buttons, accent)
	return d

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.72))

func _build(title: String, body: String, buttons: Array, accent: Color) -> void:
	_panel = UiKit.centered_panel(self, 640, UiKit.BG, accent)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	_panel.add_child(vbox)
	var t := UiKit.label(title, 28, accent)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(t)
	if body != "":
		var scroll := ScrollContainer.new()
		scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER   # 0 empurraria a largura
		scroll.custom_minimum_size = Vector2(0, mini(360, 30 + body.count("\n") * 26 + int(body.length() / 50) * 26))
		vbox.add_child(scroll)
		var b := UiKit.label(body, 19, Color.WHITE, true)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		scroll.add_child(b)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 12)
	vbox.add_child(row)
	var i := 0
	for spec in buttons:
		var label := String(spec[0])
		var value = spec[1] if spec.size() > 1 else null
		var primary: bool = spec.size() > 2 and bool(spec[2])
		var active: bool = spec.size() <= 3 or bool(spec[3])
		var btn := UiKit.button(label, 54, 19, UiKit.PRIMARY if primary else UiKit.BTN_BG)
		btn.name = "Choice%d" % i
		btn.custom_minimum_size.x = 180
		btn.disabled = not active
		btn.pressed.connect(func(): _pick(value))
		row.add_child(btn)
		i += 1
	UiKit.pop_in(_panel)

func _pick(value) -> void:
	if _done:
		return
	_done = true
	Sfx.select()
	queue_free()
	chosen.emit(value)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and not event.pressed and _panel != null and not _panel.get_global_rect().has_point(event.global_position):
		accept_event()
		_pick(null)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		_pick(null)
