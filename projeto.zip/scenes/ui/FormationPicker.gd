class_name FormationPicker
extends Control
## 0.15.0 Constelação (loja): escolhe a formação que sobe 1 nível até ao fim da run. Cada botão mostra o
## nível e o Mult de agora e o de depois. Cancelar não custa nada: o ouro só sai quando se escolhe.

var _on_pick: Callable

static func open(on_pick: Callable) -> FormationPicker:
	var p := FormationPicker.new()
	p._on_pick = on_pick
	SceneRouter.show_overlay(p)
	p._build()
	return p

## Mult que a formação dá num nível (o mesmo cálculo do EffectResolver, com o talento das formações).
static func mult_at(f: Dictionary, level: int) -> float:
	return float(f.get("mult_add", 0)) + level * float(f.get("level_mult", 1)) + GameState.talent_value("formation_mult")

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.8))

func _build() -> void:
	var panel := UiKit.centered_panel(self, 1140)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	panel.add_child(vbox)
	var title := UiKit.label(tr("⁂ CONSTELAÇÃO — ESCOLHE A FORMAÇÃO"), 28, UiKit.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	var sub := UiKit.label(tr("A formação que escolheres sobe 1 nível até ao fim da run: dá mais Mult sempre que a fizeres."), 16, UiKit.TEXT_DIM, true)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(sub)
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	vbox.add_child(grid)
	var star := Color(1.0, 0.88, 0.54)
	for f in CardDB.formations:
		var id := String(f.get("id", ""))
		var lvl := GameState.formation_level(id)
		var head := tr("⁂ %s · nível %d → %d") % [tr(String(f.get("name", ""))), lvl, lvl + 1]
		var gain := tr("+%s Mult → +%s Mult") % [Cascade.fmt_mult(mult_at(f, lvl)), Cascade.fmt_mult(mult_at(f, lvl + 1))]
		var b := UiKit.wrap_button(head + "\n" + gain + "\n" + tr(String(f.get("text", ""))), 98, 14, Color(0.15, 0.13, 0.24), star.darkened(0.35) if lvl == 0 else star)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.name = "Formation_" + id
		b.pressed.connect(func():
			if is_queued_for_deletion():
				return
			Sfx.select()
			queue_free()
			if _on_pick.is_valid():
				_on_pick.call(id))
		grid.add_child(b)
	var cancel := UiKit.button(tr("CANCELAR"), 50, 20)
	cancel.name = "Cancel"
	cancel.pressed.connect(close)
	vbox.add_child(cancel)
	UiKit.pop_in(panel)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Sfx.select()
	queue_free()
