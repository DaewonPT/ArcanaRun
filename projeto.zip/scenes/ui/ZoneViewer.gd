class_name ZoneViewer
extends Control
## Lista de cartas de uma zona (grimório, cemitério ou o baralho inteiro) em grelha.
## 0.12.0: o grimório da batalha pode mostrar as probabilidades (open_library).
## Toque numa carta abre-a em grande. O grimório mostra-se ordenado por custo, para não
## revelar a ordem de compra. Pode ter uma segunda secção (p.ex. o exílio por baixo do cemitério)
## e, em modo de escolha, um filtro que deixa só algumas cartas escolhíveis (Recapitular).

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")

signal picked(card: CardInstance)
signal cancelled

var _on_pick: Callable = Callable()
var _pick_filter: Callable = Callable()
var _picked_once := false

static func open(title: String, cards: Array[CardInstance], hide_order: bool, on_pick: Callable = Callable(), pick_filter: Callable = Callable(), extra_title: String = "", extra_cards: Array[CardInstance] = []) -> ZoneViewer:
	var v := ZoneViewer.new()
	v._on_pick = on_pick
	v._pick_filter = pick_filter
	SceneRouter.show_overlay(v)
	v._build(title, cards, hide_order, extra_title, extra_cards)
	return v

## Baralho inteiro (entradas de GameState.deck, com entry_index para saber qual foi escolhida).
static func open_deck(title: String, on_pick: Callable = Callable(), pick_filter: Callable = Callable()) -> ZoneViewer:
	var v := ZoneViewer.new()
	v._on_pick = on_pick
	v._pick_filter = pick_filter
	v._show_curve = not on_pick.is_valid()   # 0.13.0: só a ver o baralho — com a curva de mana
	SceneRouter.show_overlay(v)
	v._build(title, deck_instances(), true, "", [])
	return v

static func deck_instances() -> Array[CardInstance]:
	var cards: Array[CardInstance] = []
	for i in GameState.deck.size():
		var e: Dictionary = GameState.deck[i]
		var c := CardDB.new_instance(String(e["id"]), e)
		if c:
			c.entry_index = i
			cards.append(c)
	return cards

## 0.12.0: o grimório na batalha com probabilidades — cada carta diferente uma vez, com quantas há e a
## chance de ser a próxima a sair; em cima, a próxima carta por tipo e a chance de um Terreno nas
## próximas compras. A ordem continua escondida (por custo).
static func open_library(title: String, cards: Array[CardInstance], draws_next: int) -> ZoneViewer:
	var v := ZoneViewer.new()
	v._probabilities = true
	v._draws_next = draws_next
	SceneRouter.show_overlay(v)
	v._build(title, cards, true, "", [])
	return v

var _probabilities := false
var _draws_next := 0
var _show_curve := false

## Probabilidade de sair pelo menos 1 de `k` cartas em `n` compras de um monte de `total` cartas.
static func chance_at_least_one(total: int, k: int, n: int) -> float:
	if k <= 0 or n <= 0 or total <= 0:
		return 0.0
	if n >= total or total - k < n:
		return 1.0
	var p_none := 1.0
	for i in n:
		p_none *= float(total - k - i) / float(total - i)
	return 1.0 - p_none

static func pct(x: float) -> String:
	var v := x * 100.0
	if v > 0.0 and v < 1.0:
		return "<1 %"
	return "%d %%" % int(round(v))

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.9))

func _build(title: String, cards: Array[CardInstance], hide_order: bool, extra_title: String, extra_cards: Array[CardInstance]) -> void:
	var list := cards.duplicate()
	if hide_order:
		list.sort_custom(func(a: CardInstance, b: CardInstance):
			if a.data.is_land() != b.data.is_land():
				return b.data.is_land()
			if a.data.cost != b.data.cost:
				return a.data.cost < b.data.cost
			return a.data.name < b.data.name)
	_all = list
	_extra_title = extra_title
	_extra = extra_cards
	# 0.16.0 (V44 + V48): numa janela com a moldura comum (✕ fecha; numa escolha, cancela), com separadores por
	# tipo e quantas cartas há de cada um.
	var vp := get_viewport_rect().size if is_inside_tree() else Vector2(1280, 720)
	var body := UiKit.window(self, minf(1220.0, vp.x - 40.0), "%s  ·  %d" % [title, list.size()], Color(0.56, 0.48, 0.88), _on_close_x)
	var panel: Control = body.get_meta("panel")
	panel.custom_minimum_size.y = vp.y - 50.0
	var margin := body.get_parent() as Control
	if margin != null:
		margin.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	if list.size() + extra_cards.size() > 0:
		body.add_child(_tabs(list))
	if _probabilities and not list.is_empty():
		body.add_child(_odds_header(list))
	if _show_curve and not list.is_empty():
		body.add_child(_curve_header(list))
	if list.is_empty() and extra_cards.is_empty():
		var empty := UiKit.label(tr("Nada aqui."), 24, UiKit.TEXT_DIM)
		empty.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		empty.size_flags_vertical = Control.SIZE_EXPAND_FILL
		empty.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		body.add_child(empty)
	else:
		var scroll := ScrollContainer.new()
		scroll.name = "Scroll"
		scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
		scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		body.add_child(scroll)
		_inner = VBoxContainer.new()
		_inner.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_inner.add_theme_constant_override("separation", 10)
		scroll.add_child(_inner)
		_fill(list)
	var hint_txt := tr("Toca numa carta para a ver em grande.")
	if _on_pick.is_valid():
		hint_txt = tr("Toca numa carta para a escolher; toque longo para ver em grande.")
	var hint := UiKit.label(hint_txt, 15, UiKit.TEXT_DIM)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	body.add_child(hint)
	UiKit.pop_in(panel)

var _all: Array = []
var _extra: Array[CardInstance] = []
var _extra_title := ""
var _inner: VBoxContainer
var _tab_btns: Array[Button] = []

func _on_close_x() -> void:
	if _on_pick.is_valid() and not _picked_once:
		cancelled.emit()
	close()

## Tipo de uma carta para os separadores.
static func type_key(c: CardInstance) -> String:
	if c.data.is_land():
		return "land"
	if c.data.is_creature():
		return "creature"
	if c.data.is_spell():
		return "spell"
	if c.data.is_enchantment():
		return "enchantment"
	return "other"

const TAB_NAMES := {"all": "Todas", "creature": "Criaturas", "spell": "Feitiços", "enchantment": "Encantamentos", "land": "Terrenos", "other": "Outras"}

## Os separadores: Todas e cada tipo que existe, com quantas há.
func _tabs(list: Array) -> HBoxContainer:
	var counts := {}
	for c in list:
		var k := type_key(c)
		counts[k] = int(counts.get(k, 0)) + 1
	var row := HBoxContainer.new()
	row.name = "Tabs"
	row.add_theme_constant_override("separation", 8)
	_tab_btns.clear()
	var keys: Array[String] = ["all"]
	for k in ["creature", "spell", "enchantment", "land", "other"]:
		if int(counts.get(k, 0)) > 0:
			keys.append(k)
	if keys.size() <= 2:
		return row   # só um tipo: os separadores não ajudam
	for k in keys:
		var n := list.size() if k == "all" else int(counts.get(k, 0))
		var b := Button.new()
		b.name = "Tab_" + k
		b.toggle_mode = true
		b.focus_mode = Control.FOCUS_NONE
		b.custom_minimum_size = Vector2(0, 40)
		b.text = "%s  %d" % [tr(String(TAB_NAMES[k])), n]
		b.add_theme_font_size_override("font_size", 16)
		b.add_theme_stylebox_override("normal", UiKit.flat(Color(1, 1, 1, 0.06), 10, Color(0, 0, 0, 0), 0, 12))
		b.add_theme_stylebox_override("hover", UiKit.flat(Color(1, 1, 1, 0.1), 10, Color(0, 0, 0, 0), 0, 12))
		b.add_theme_stylebox_override("pressed", UiKit.flat(Color(0.29, 0.23, 0.47), 10, Color(0.56, 0.48, 0.88), 2, 12))
		b.button_pressed = k == "all"
		b.set_meta("tab", k)
		b.pressed.connect(_on_tab.bind(k))
		row.add_child(b)
		_tab_btns.append(b)
	return row

func _on_tab(k: String) -> void:
	Sfx.select()
	for b in _tab_btns:
		b.set_pressed_no_signal(String(b.get_meta("tab", "")) == k)
	var shown: Array = []
	for c in _all:
		if k == "all" or type_key(c) == k:
			shown.append(c)
	_fill(shown, k == "all")

## Põe as cartas (e, com o separador Todas, a 2.ª secção — o exílio por baixo do cemitério).
func _fill(list: Array, with_extra: bool = true) -> void:
	if _inner == null:
		return
	UiKit.clear_children(_inner)
	var typed: Array[CardInstance] = []
	typed.assign(list)
	if typed.is_empty():
		_inner.add_child(UiKit.label(tr("Nada aqui."), 20, UiKit.TEXT_DIM))
	else:
		_inner.add_child(_grid(typed, true))
	if with_extra and _extra_title != "":
		_inner.add_child(UiKit.label("%s  ·  %d" % [_extra_title, _extra.size()], 22, UiKit.TEXT_DIM))
		if not _extra.is_empty():
			_inner.add_child(_grid(_extra, false))

## Linha de cima do grimório: próxima carta por tipo e Terrenos nas próximas compras.
func _odds_header(list: Array[CardInstance]) -> Control:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 2)
	var n := list.size()
	var by_type := {"Criatura": 0, "Feitiço": 0, "Encantamento": 0, "Terreno": 0, "Outra": 0}
	for c in list:
		if c.data.is_land():
			by_type["Terreno"] += 1
		elif c.data.is_creature():
			by_type["Criatura"] += 1
		elif c.data.is_spell():
			by_type["Feitiço"] += 1
		elif c.data.is_enchantment():
			by_type["Encantamento"] += 1
		else:
			by_type["Outra"] += 1
	var parts: Array[String] = []
	for k in ["Criatura", "Feitiço", "Encantamento", "Terreno", "Outra"]:
		if int(by_type[k]) > 0:
			parts.append("%s %s" % [tr(k), pct(float(by_type[k]) / float(n))])
	var l1 := UiKit.label(tr("Próxima carta:") + "  " + "  ·  ".join(PackedStringArray(parts)), 18, Color.WHITE)
	l1.name = "OddsNext"
	box.add_child(l1)
	var lands := int(by_type["Terreno"])
	if _draws_next > 1:
		var l2 := UiKit.label(tr("Nas próximas %d compras: %s de vir pelo menos 1 Terreno.") % [_draws_next, pct(chance_at_least_one(n, lands, _draws_next))], 16, UiKit.TEXT_DIM)
		l2.name = "OddsLand"
		box.add_child(l2)
	return box

## 0.13.0: curva de mana do baralho (barras por custo) com a legenda e o resumo ao lado.
func _curve_header(list: Array[CardInstance]) -> Control:
	var row := HBoxContainer.new()
	row.name = "CurveRow"
	row.add_theme_constant_override("separation", 18)
	var curve := ManaCurve.new()
	curve.name = "ManaCurve"
	curve.custom_minimum_size = Vector2(420, 104)
	curve.set_cards(list)
	row.add_child(curve)
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info.alignment = BoxContainer.ALIGNMENT_CENTER
	info.add_theme_constant_override("separation", 4)
	row.add_child(info)
	info.add_child(UiKit.label(tr("Curva de mana"), 20, UiKit.GOLD))
	var sum := UiKit.label(curve.summary(), 16, Color.WHITE, true)
	sum.name = "CurveSummary"
	info.add_child(sum)
	var legend := HBoxContainer.new()
	legend.add_theme_constant_override("separation", 14)
	info.add_child(legend)
	for e in [[ManaCurve.CREATURE_COLOR, tr("Criaturas")], [ManaCurve.SPELL_COLOR, tr("Feitiços")], [ManaCurve.ENCHANT_COLOR, tr("Encantamentos")]]:
		var sw := ColorRect.new()
		sw.color = e[0]
		sw.custom_minimum_size = Vector2(14, 14)
		sw.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		legend.add_child(sw)
		legend.add_child(UiKit.label(String(e[1]), 15, UiKit.TEXT_DIM))
	return row

func _grid(list: Array[CardInstance], pickable_section: bool) -> GridContainer:
	var grid := GridContainer.new()
	grid.columns = 8
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if _probabilities:
		_odds_grid(grid, list)
		return grid
	for card in list:
		var view: CardView = CARD_VIEW.instantiate()
		grid.add_child(view)
		view.setup(card)
		var pickable := pickable_section and (not _pick_filter.is_valid() or bool(_pick_filter.call(card)))
		if _on_pick.is_valid() and not pickable:
			view.playable = false
			view.pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
		else:
			view.pressed.connect(_on_card_pressed)
		view.long_pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
	return grid

## Uma carta de cada (as repetidas juntas), com "×N · X %" por baixo.
func _odds_grid(grid: GridContainer, list: Array[CardInstance]) -> void:
	var seen := {}
	var order: Array[CardInstance] = []
	for c in list:
		var key := c.data.id
		if not seen.has(key):
			seen[key] = 0
			order.append(c)
		seen[key] = int(seen[key]) + 1
	for card in order:
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 2)
		col.mouse_filter = Control.MOUSE_FILTER_PASS
		grid.add_child(col)
		var view: CardView = CARD_VIEW.instantiate()
		col.add_child(view)
		view.setup(card)
		view.pressed.connect(_on_card_pressed)
		view.long_pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
		var count := int(seen[card.data.id])
		var total := _all.size() if not _all.is_empty() else list.size()   # com um separador, a chance continua a ser do grimório todo
		var odds := UiKit.label(("×%d  ·  " % count if count > 1 else "") + pct(float(count) / float(total)), 16, UiKit.GOLD)
		odds.name = "Odds"
		odds.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(odds)

func _on_card_pressed(c: CardInstance) -> void:
	if _on_pick.is_valid():
		if _picked_once or (_pick_filter.is_valid() and not bool(_pick_filter.call(c))):
			return
		_picked_once = true
		Sfx.select()
		picked.emit(c)
		_on_pick.call(c)
		UiKit.close_animated(self)
	else:
		CardZoom.show_card(c)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Sfx.select()
	UiKit.close_animated(self)
