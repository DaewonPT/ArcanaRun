class_name ZoneViewer
extends Control
## Lista de cartas de uma zona (grimório, cemitério ou o baralho inteiro) em grelha.
## Toque numa carta abre-a em grande. O grimório mostra-se ordenado por custo, para não
## revelar a ordem de compra.

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")

static func open(title: String, cards: Array[CardInstance], hide_order: bool) -> ZoneViewer:
	var v := ZoneViewer.new()
	SceneRouter.show_overlay(v)
	v._build(title, cards, hide_order)
	return v

static func open_deck(title: String) -> ZoneViewer:
	var cards: Array[CardInstance] = []
	for e in GameState.deck:
		var c := CardDB.new_instance(String(e["id"]), e)
		if c:
			cards.append(c)
	return open(title, cards, true)

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.9))

func _build(title: String, cards: Array[CardInstance], hide_order: bool) -> void:
	var list := cards.duplicate()
	if hide_order:
		list.sort_custom(func(a: CardInstance, b: CardInstance):
			if a.data.is_land() != b.data.is_land():
				return b.data.is_land()
			if a.data.cost != b.data.cost:
				return a.data.cost < b.data.cost
			return a.data.name < b.data.name)
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 12)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(vbox)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 16)
	vbox.add_child(header)
	var t := UiKit.label("%s  ·  %d" % [title, list.size()], 30, UiKit.GOLD)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	t.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(t)
	var close_btn := UiKit.button(tr("FECHAR"), 56, 22, UiKit.PRIMARY, Color(0, 0, 0, 0))
	close_btn.custom_minimum_size.x = 180
	close_btn.pressed.connect(close)
	header.add_child(close_btn)

	if list.is_empty():
		var empty := UiKit.label(tr("Nada aqui."), 24, UiKit.TEXT_DIM)
		empty.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		empty.size_flags_vertical = Control.SIZE_EXPAND_FILL
		empty.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		vbox.add_child(empty)
	else:
		var scroll := ScrollContainer.new()
		scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
		scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		vbox.add_child(scroll)
		var grid := GridContainer.new()
		grid.columns = 8
		grid.add_theme_constant_override("h_separation", 10)
		grid.add_theme_constant_override("v_separation", 10)
		grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		scroll.add_child(grid)
		for card in list:
			var view: CardView = CARD_VIEW.instantiate()
			grid.add_child(view)
			view.setup(card)
			view.pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
			view.long_pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
	var hint := UiKit.label(tr("Toca numa carta para a ver em grande."), 16, UiKit.TEXT_DIM)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(hint)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Sfx.select()
	queue_free()
