class_name ZoneViewer
extends Control
## Lista de cartas de uma zona (grimório, cemitério ou o baralho inteiro) em grelha.
## 0.12.0: o grimório da batalha pode mostrar as probabilidades (open_library).
## Toque numa carta abre-a em grande. O grimório mostra-se ordenado por custo, para não
## revelar a ordem de compra. Pode ter uma segunda secção (p.ex. o exílio por baixo do cemitério)
## e, em modo de escolha, um filtro que deixa só algumas cartas escolhíveis (Recapitular).

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")

signal picked(card: CardInstance)
signal cancelled

var _on_pick: Callable = Callable()
var _pick_filter: Callable = Callable()
var _picked_once := false

static func open(title: String, cards: Array[CardInstance], hide_order: bool, on_pick: Callable = Callable(), pick_filter: Callable = Callable(), extra_title: String = "", extra_cards: Array[CardInstance] = []) -> ZoneViewer:
	var v := ZoneViewer.new()
	v._on_pick = on_pick
	v._pick_filter = pick_filter
	SceneRouter.show_overlay(v)
	v._build(title, cards, hide_order, extra_title, extra_cards)
	return v

## Baralho inteiro (entradas de GameState.deck, com entry_index para saber qual foi escolhida).
static func open_deck(title: String, on_pick: Callable = Callable(), pick_filter: Callable = Callable()) -> ZoneViewer:
	return open(title, deck_instances(), true, on_pick, pick_filter)

static func deck_instances() -> Array[CardInstance]:
	var cards: Array[CardInstance] = []
	for i in GameState.deck.size():
		var e: Dictionary = GameState.deck[i]
		var c := CardDB.new_instance(String(e["id"]), e)
		if c:
			c.entry_index = i
			cards.append(c)
	return cards

## 0.12.0: o grimório na batalha com probabilidades — cada carta diferente uma vez, com quantas há e a
## chance de ser a próxima a sair; em cima, a próxima carta por tipo e a chance de um Terreno nas
## próximas compras. A ordem continua escondida (por custo).
static func open_library(title: String, cards: Array[CardInstance], draws_next: int) -> ZoneViewer:
	var v := ZoneViewer.new()
	v._probabilities = true
	v._draws_next = draws_next
	SceneRouter.show_overlay(v)
	v._build(title, cards, true, "", [])
	return v

var _probabilities := false
var _draws_next := 0

## Probabilidade de sair pelo menos 1 de `k` cartas em `n` compras de um monte de `total` cartas.
static func chance_at_least_one(total: int, k: int, n: int) -> float:
	if k <= 0 or n <= 0 or total <= 0:
		return 0.0
	if n >= total or total - k < n:
		return 1.0
	var p_none := 1.0
	for i in n:
		p_none *= float(total - k - i) / float(total - i)
	return 1.0 - p_none

static func pct(x: float) -> String:
	var v := x * 100.0
	if v > 0.0 and v < 1.0:
		return "<1 %"
	return "%d %%" % int(round(v))

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.9))

func _build(title: String, cards: Array[CardInstance], hide_order: bool, extra_title: String, extra_cards: Array[CardInstance]) -> void:
	var list := cards.duplicate()
	if hide_order:
		list.sort_custom(func(a: CardInstance, b: CardInstance):
			if a.data.is_land() != b.data.is_land():
				return b.data.is_land()
			if a.data.cost != b.data.cost:
				return a.data.cost < b.data.cost
			return a.data.name < b.data.name)
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 12)
	margin.add_theme_constant_override("margin_bottom", 34)
	add_child(margin)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(vbox)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 16)
	vbox.add_child(header)
	var t := UiKit.label("%s  ·  %d" % [title, list.size()], 30, UiKit.GOLD)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	t.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(t)
	var close_btn := UiKit.button(tr("CANCELAR") if _on_pick.is_valid() else tr("FECHAR"), 56, 22, UiKit.PRIMARY, Color(0, 0, 0, 0))
	close_btn.custom_minimum_size.x = 180
	close_btn.pressed.connect(func():
		if _on_pick.is_valid() and not _picked_once:
			cancelled.emit()
		close())
	header.add_child(close_btn)

	if _probabilities and not list.is_empty():
		vbox.add_child(_odds_header(list))
	if list.is_empty() and extra_cards.is_empty():
		var empty := UiKit.label(tr("Nada aqui."), 24, UiKit.TEXT_DIM)
		empty.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		empty.size_flags_vertical = Control.SIZE_EXPAND_FILL
		empty.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		vbox.add_child(empty)
	else:
		var scroll := ScrollContainer.new()
		scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
		scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		vbox.add_child(scroll)
		var inner := VBoxContainer.new()
		inner.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		inner.add_theme_constant_override("separation", 10)
		scroll.add_child(inner)
		if list.is_empty():
			inner.add_child(UiKit.label(tr("Nada aqui."), 20, UiKit.TEXT_DIM))
		else:
			inner.add_child(_grid(list, true))
		if extra_title != "":
			inner.add_child(UiKit.label("%s  ·  %d" % [extra_title, extra_cards.size()], 22, UiKit.TEXT_DIM))
			if not extra_cards.is_empty():
				inner.add_child(_grid(extra_cards, false))
	var hint_txt := tr("Toca numa carta para a ver em grande.")
	if _on_pick.is_valid():
		hint_txt = tr("Toca numa carta para a escolher; toque longo para ver em grande.")
	var hint := UiKit.label(hint_txt, 16, UiKit.TEXT_DIM)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(hint)

## Linha de cima do grimório: próxima carta por tipo e Terrenos nas próximas compras.
func _odds_header(list: Array[CardInstance]) -> Control:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 2)
	var n := list.size()
	var by_type := {"Criatura": 0, "Feitiço": 0, "Encantamento": 0, "Terreno": 0, "Outra": 0}
	for c in list:
		if c.data.is_land():
			by_type["Terreno"] += 1
		elif c.data.is_creature():
			by_type["Criatura"] += 1
		elif c.data.is_spell():
			by_type["Feitiço"] += 1
		elif c.data.is_enchantment():
			by_type["Encantamento"] += 1
		else:
			by_type["Outra"] += 1
	var parts: Array[String] = []
	for k in ["Criatura", "Feitiço", "Encantamento", "Terreno", "Outra"]:
		if int(by_type[k]) > 0:
			parts.append("%s %s" % [tr(k), pct(float(by_type[k]) / float(n))])
	var l1 := UiKit.label(tr("Próxima carta:") + "  " + "  ·  ".join(PackedStringArray(parts)), 18, Color.WHITE)
	l1.name = "OddsNext"
	box.add_child(l1)
	var lands := int(by_type["Terreno"])
	if _draws_next > 1:
		var l2 := UiKit.label(tr("Nas próximas %d compras: %s de vir pelo menos 1 Terreno.") % [_draws_next, pct(chance_at_least_one(n, lands, _draws_next))], 16, UiKit.TEXT_DIM)
		l2.name = "OddsLand"
		box.add_child(l2)
	return box

func _grid(list: Array[CardInstance], pickable_section: bool) -> GridContainer:
	var grid := GridContainer.new()
	grid.columns = 8
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if _probabilities:
		_odds_grid(grid, list)
		return grid
	for card in list:
		var view: CardView = CARD_VIEW.instantiate()
		grid.add_child(view)
		view.setup(card)
		var pickable := pickable_section and (not _pick_filter.is_valid() or bool(_pick_filter.call(card)))
		if _on_pick.is_valid() and not pickable:
			view.playable = false
			view.pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
		else:
			view.pressed.connect(_on_card_pressed)
		view.long_pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
	return grid

## Uma carta de cada (as repetidas juntas), com "×N · X %" por baixo.
func _odds_grid(grid: GridContainer, list: Array[CardInstance]) -> void:
	var seen := {}
	var order: Array[CardInstance] = []
	for c in list:
		var key := c.data.id
		if not seen.has(key):
			seen[key] = 0
			order.append(c)
		seen[key] = int(seen[key]) + 1
	for card in order:
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 2)
		col.mouse_filter = Control.MOUSE_FILTER_PASS
		grid.add_child(col)
		var view: CardView = CARD_VIEW.instantiate()
		col.add_child(view)
		view.setup(card)
		view.pressed.connect(_on_card_pressed)
		view.long_pressed.connect(func(c: CardInstance): CardZoom.show_card(c))
		var count := int(seen[card.data.id])
		var odds := UiKit.label(("×%d  ·  " % count if count > 1 else "") + pct(float(count) / float(list.size())), 16, UiKit.GOLD)
		odds.name = "Odds"
		odds.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(odds)

func _on_card_pressed(c: CardInstance) -> void:
	if _on_pick.is_valid():
		if _picked_once or (_pick_filter.is_valid() and not bool(_pick_filter.call(c))):
			return
		_picked_once = true
		Sfx.select()
		picked.emit(c)
		_on_pick.call(c)
		queue_free()
	else:
		CardZoom.show_card(c)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Sfx.select()
	queue_free()
