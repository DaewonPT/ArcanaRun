class_name RunInfo
extends Control
## 0.19.0 (58–62): «A minha run», completa — separadores com as relíquias (com o dano desta run, o valor de venda
## e ◀ ▶ para mudar a ordem fora da batalha), as relíquias de boss, as Bênçãos, os Vales, as poções, o patrono, o
## contrato, as formações (o nível e o próximo bónus) e as maldições, cada um com o texto. Abre-se no mapa, na
## pausa da batalha, na loja e na Torre.

const TABS := [["relics", "RELÍQUIAS"], ["boss", "DE BOSS"], ["blessings", "BÊNÇÃOS"], ["vouchers", "VALES"], ["potions", "POÇÕES"],
	["patron", "PATRONO"], ["contract", "CONTRATO"], ["formations", "FORMAÇÕES"], ["curses", "MALDIÇÕES"]]

var _tab := "relics"
var _list: VBoxContainer
var _tab_btns: Dictionary = {}
var _on_change: Callable = Callable()
var _panel: Control

## `on_change` é chamado quando a ordem das relíquias muda (quem abriu grava a run).
static func open(tab: String = "relics", on_change: Callable = Callable()) -> RunInfo:
	var r := RunInfo.new()
	r._tab = tab
	r._on_change = on_change
	SceneRouter.show_overlay(r)
	r._build()
	return r

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.85))

func _build() -> void:
	var vp := get_viewport_rect().size if is_inside_tree() else Vector2(1280, 720)
	var body := UiKit.window(self, minf(1180.0, vp.x - 40.0), tr("A MINHA RUN"), UiKit.GOLD, close,
		"%s  ·  %s" % [tr(String(GameState.deck_def.get("name", ""))), GameState.stage_label()])
	_panel = body.get_meta("panel")
	_panel.custom_minimum_size.y = minf(640.0, vp.y - 50.0)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var tabs := HFlowContainer.new()
	tabs.name = "Tabs"
	tabs.add_theme_constant_override("h_separation", 6)
	tabs.add_theme_constant_override("v_separation", 6)
	body.add_child(tabs)
	for t in TABS:
		var id := String(t[0])
		var n := count_of(id)
		var b := UiKit.chip_button("%s %d" % [tr(String(t[1])), n], 40)
		b.name = "Tab_" + id
		b.pressed.connect(show_tab.bind(id))
		tabs.add_child(b)
		_tab_btns[id] = b
	var scroll := ScrollContainer.new()
	scroll.name = "Scroll"
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body.add_child(scroll)
	_list = VBoxContainer.new()
	_list.name = "List"
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list.add_theme_constant_override("separation", 8)
	scroll.add_child(_list)
	SwipeArea.attach(self, scroll, _on_swipe)
	show_tab(_tab)
	UiKit.pop_in(_panel)

## Quantos há em cada separador (para as etiquetas).
static func count_of(tab: String) -> int:
	match tab:
		"relics":
			return GameState.relic_ids.size()
		"boss":
			return GameState.boss_relics.size()
		"blessings":
			return GameState.blessings.size()
		"vouchers":
			return GameState.vouchers.size()
		"potions":
			return GameState.consumables.size()
		"patron":
			return 0 if GameState.planeswalker.is_empty() else 1
		"contract":
			return 0 if GameState.contract.is_empty() else 1
		"formations":
			var n := 0
			for f in CardDB.formations:
				if GameState.formation_level(String((f as Dictionary).get("id", ""))) > 0:
					n += 1
			return n
		"curses":
			var c := GameState.endless_curses.size()
			for e in GameState.deck:
				var cd := CardDB.get_card(String(e.get("id", "")))
				if cd != null and cd.is_curse():
					c += 1
			return c
	return 0

func _on_swipe(direction: int) -> void:
	var ids: Array = TABS.map(func(t): return String(t[0]))
	var nt := String(SwipeArea.step_id(ids, _tab, direction))
	if nt != _tab:
		show_tab(nt)

func show_tab(id: String) -> void:
	_tab = id
	Sfx.select()
	for k in _tab_btns:
		(_tab_btns[k] as Button).set_pressed_no_signal(k == id)
	UiKit.clear_children(_list)
	match id:
		"relics":
			for i in GameState.relic_ids.size():
				_list.add_child(_relic_row(GameState.relic_ids[i], i, true))
			if not GameState.relic_ids.is_empty():   # 95
				var tl := UiKit.label(tr("TROCAR: uma vez por run, troca uma relíquia por outra da mesma raridade, ao acaso (fora das batalhas).") if Economy.can_trade_relic() else tr("Já trocaste uma relíquia nesta run."), 14, UiKit.TEXT_DIM, true)
				tl.name = "TradeNote"
				_list.add_child(tl)
		"boss":
			for rid in GameState.boss_relics:
				_list.add_child(_relic_row(rid, -1, false))
		"blessings":
			for rid in GameState.blessings:
				_list.add_child(_relic_row(rid, -1, false))
		"vouchers":
			for vid in GameState.vouchers:
				var v := CardDB.get_voucher(vid)
				var vr := _text_row("ticket", tr(String(v.get("name", vid))), tr(String(v.get("text", ""))) + "\n" + Economy.voucher_result(vid))   # 98
				vr.name = "Voucher_" + vid
				_list.add_child(vr)
		"potions":
			for cid in GameState.consumables:
				var c := CardDB.get_consumable(cid)
				_list.add_child(_text_row(String(c.get("kind", "potion")), tr(String(c.get("name", cid))), tr(String(c.get("text", "")))))
			_list.add_child(UiKit.label(tr("Lugares: %d de %d.") % [GameState.consumables.size(), GameState.consumable_slots()], 15, UiKit.TEXT_DIM))
		"patron":
			if not GameState.planeswalker.is_empty():
				var p := GameState.planeswalker_def()
				var lines: Array[String] = [tr(String(p.get("text", ""))), tr("Lealdade %d de %d.") % [GameState.planeswalker_loyalty(), int(p.get("max_loyalty", 6))]]
				for sk in p.get("skills", []):
					lines.append("✦ " + tr(String((sk as Dictionary).get("text", ""))))
				_list.add_child(_text_row("crown", tr(String(p.get("name", ""))), "\n".join(PackedStringArray(lines))))
		"contract":
			if not GameState.contract.is_empty():
				var reward := GameState.reward_text(GameState.contract.get("reward", {}))
				_list.add_child(_text_row("contract", tr(String(GameState.contract.get("name", ""))), tr(String(GameState.contract.get("text", ""))) + ("\n" + tr("Recompensa: %s.") % reward if reward != "" else "")))
		"formations":
			for f in CardDB.formations:
				_list.add_child(_formation_row(f))
		"curses":
			for ec in GameState.endless_curses:
				var d := {}
				for x in CardDB.endless_curses:
					if String((x as Dictionary).get("id", "")) == ec:
						d = x
				_list.add_child(_text_row("skull", tr(String(d.get("name", ec))), tr(String(d.get("text", "")))))
			for e in GameState.deck:
				var cd := CardDB.get_card(String(e.get("id", "")))
				if cd != null and cd.is_curse():
					_list.add_child(_text_row("skull", cd.display_name(), cd.display_text()))
	if _list.get_child_count() == 0:
		var l := UiKit.label(tr("Nada aqui nesta run."), 18, UiKit.TEXT_DIM)
		l.name = "Empty"
		_list.add_child(l)

## Uma relíquia: o medalhão, o nome e o texto, o dano desta run (62), o valor de venda (97) e ◀ ▶ (60).
func _relic_row(rid: String, index: int, movable: bool) -> PanelContainer:
	var r: Dictionary = CardDB.relics.get(rid, {})
	var p := PanelContainer.new()
	p.name = "Relic_" + rid
	p.add_theme_stylebox_override("panel", UiKit.flat(Color(1, 1, 1, 0.04), 12, Color(1, 1, 1, 0.08), 1, 10))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	p.add_child(row)
	var rv := RelicView.new()
	rv.custom_minimum_size = Vector2(56, 56)
	rv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rv.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(rv)
	rv.setup(rid)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 2)
	row.add_child(col)
	col.add_child(UiKit.label(("%d · " % (index + 1) if index >= 0 else "") + tr(String(r.get("name", rid))), 18, UiKit.GOLD))
	col.add_child(UiKit.label(tr(String(r.get("text", ""))), 15, Color.WHITE, true))
	var facts: Array[String] = []
	var dmg := int((GameState.run_log.get("relic_dmg", {}) as Dictionary).get(rid, 0)) if GameState.run_log.get("relic_dmg") is Dictionary else 0
	facts.append(tr("Deu %s de dano nesta run") % Cascade.fmt_int(dmg))
	if movable and not (rid in GameState.relic_locked):
		facts.append(tr("vende-se por %d ouro") % GameState.relic_sell_price(rid))
	var sc := GameState.relic_scaling_text(rid)
	if sc != "":
		facts.append(tr("vai em %s") % sc)
	var f := UiKit.label("  ·  ".join(PackedStringArray(facts)), 14, UiKit.TEXT_DIM, true)
	f.name = "Facts"
	col.add_child(f)
	if movable and Economy.can_trade_relic() and _trade_ok():   # 0.19.0 (95)
		var tb := UiKit.button(tr("TROCAR"), 48, 15, UiKit.BG_LIGHT, UiKit.GOLD)
		tb.name = "Trade"
		tb.custom_minimum_size.x = 104
		tb.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		tb.tooltip_text = tr("Troca por outra relíquia da mesma raridade, ao acaso (uma vez por run).")
		tb.pressed.connect(_ask_trade.bind(rid))
		row.add_child(tb)
	if movable:
		for d in [-1, 1]:
			var b := UiKit.button("◀" if d < 0 else "▶", 48, 18)
			b.name = "Left" if d < 0 else "Right"
			b.custom_minimum_size.x = 52
			b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			b.disabled = (d < 0 and index == 0) or (d > 0 and index == GameState.relic_ids.size() - 1)
			b.tooltip_text = tr("Disparar antes") if d < 0 else tr("Disparar depois")
			b.pressed.connect(move_relic.bind(rid, d))
			row.add_child(b)
	return p

## 95: só fora das batalhas (na pausa da batalha não se troca).
func _trade_ok() -> bool:
	var cs := get_tree().current_scene if is_inside_tree() else null
	return cs == null or cs.name != "Battle"

func _ask_trade(rid: String) -> void:
	var r: Dictionary = CardDB.relics.get(rid, {})
	var rar := tr(String(CardZoom.RARITY_NAMES.get(String(r.get("rarity", "common")), "Comum"))).to_lower()
	var d := ChoiceDialog.open(tr("TROCAR RELÍQUIA"), tr("Trocar %s por outra relíquia %s ao acaso? Só podes fazer isto uma vez por run.") % [tr(String(r.get("name", rid))), rar],
		[[tr("TROCAR"), "yes", true], [tr("CANCELAR"), null]], UiKit.GOLD)
	var v = await d.chosen
	if v != "yes" or not is_inside_tree():
		return
	trade(rid)

## Troca a relíquia (também usado pelos testes). Devolve o id da nova ("" se não deu).
func trade(rid: String) -> String:
	var nid := Economy.trade_relic(rid)
	if nid == "":
		Sfx.deny()
		return ""
	Sfx.reward()
	SceneRouter.toast(tr("%s saiu; %s entrou.") % [tr(String(CardDB.relics.get(rid, {}).get("name", rid))), tr(String(CardDB.relics.get(nid, {}).get("name", nid)))], 2.4)
	if _on_change.is_valid():
		_on_change.call()
	show_tab("relics")
	return nid

## 60: muda a ordem de uma relíquia fora da batalha (a ordem conta na cascata).
func move_relic(rid: String, step: int) -> void:
	var i := GameState.relic_ids.find(rid)
	var to := i + step
	if i < 0 or to < 0 or to >= GameState.relic_ids.size():
		return
	GameState.move_relic(rid, to)
	if _on_change.is_valid():
		_on_change.call()
	show_tab("relics")

## 59: uma formação — o nível, o Mult de agora e quanto dá o próximo nível.
func _formation_row(f: Dictionary) -> PanelContainer:
	var id := String(f.get("id", ""))
	var level := GameState.formation_level(id)
	var now := float(f.get("mult_add", 0)) + level * float(f.get("level_mult", 1)) + GameState.talent_value("formation_mult")
	var step := float(f.get("level_mult", 1))
	var txt := tr(String(f.get("text", ""))) + "\n" + (tr("Nível %d: +%s Mult agora · o próximo nível dá +%s.") % [level, Cascade.fmt_mult(now), Cascade.fmt_mult(step)] if level > 0 else tr("Nível 0: +%s Mult · cada nível dá +%s (Constelação na loja, Selo da Sabedoria).") % [Cascade.fmt_mult(now), Cascade.fmt_mult(step)])
	var p := _text_row("seal", tr(String(f.get("name", id))) + (("  ·  " + tr("nível %d") % level) if level > 0 else ""), txt)
	p.name = "Formation_" + id
	if level > 0:
		p.add_theme_stylebox_override("panel", UiKit.flat(Color(0.2, 0.15, 0.05, 0.6), 12, Color(UiKit.GOLD, 0.6), 1, 10))
	return p

func _text_row(icon: String, title: String, text: String) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UiKit.flat(Color(1, 1, 1, 0.04), 12, Color(1, 1, 1, 0.08), 1, 10))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	p.add_child(row)
	var ic := CardIcon.new(icon, UiKit.GOLD, 34.0)
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(ic)
	var col := VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 2)
	row.add_child(col)
	col.add_child(UiKit.label(title, 18, UiKit.GOLD))
	col.add_child(UiKit.label(text, 15, Color.WHITE, true))
	return p

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Sfx.select()
	UiKit.close_animated(self)
