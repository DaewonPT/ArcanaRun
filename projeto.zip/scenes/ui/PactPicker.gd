class_name PactPicker
extends Control
## 0.17.0 Pactos do Infinito (89): de 4 em 4 antes depois do fim escolhes 1 de 3 maldições globais em vez de
## vir uma ao acaso. Cada uma mostra o que faz e o ouro que paga (as piores pagam mais). Não se pode fugir:
## tocar fora ou «retroceder» só lembra que é preciso escolher.

var _on_pick: Callable
var _done := false

static func open(on_pick: Callable) -> PactPicker:
	var p := PactPicker.new()
	p._on_pick = on_pick
	SceneRouter.show_overlay(p)
	p._build()
	return p

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.82))

func _build() -> void:
	var accent := Color(0.9, 0.45, 0.6)
	var panel := UiKit.centered_panel(self, 1060, UiKit.BG, accent)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	panel.add_child(vbox)
	var title := UiKit.label("☠ " + tr("PACTO DO INFINITO"), 30, accent)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	var sub := UiKit.label(tr("Ante %d: escolhe a maldição que se junta às outras até ao fim da run. As piores pagam mais ouro.") % GameState.ante, 17, UiKit.TEXT_DIM, true)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(sub)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	vbox.add_child(row)
	for id in GameState.pact_offer:
		var c := CardDB.get_endless_curse(id)
		var gold := GameState.pact_gold(id)
		var b := UiKit.wrap_button("☠ %s\n%s\n%s" % [tr(String(c.get("name", id))), tr(String(c.get("text", ""))), tr("+%d ouro") % gold], 132, 17,
			Color(0.17, 0.08, 0.13), accent.darkened(0.25))
		b.name = "Pact_" + id
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		UiKit.wrap_label(b).horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		b.pressed.connect(_pick.bind(id))
		row.add_child(b)
	var note := UiKit.label(tr("As maldições somam-se: vês as que tens no mapa, em «Maldições»."), 14, UiKit.TEXT_DIM, true)
	note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(note)
	UiKit.pop_in(panel)

func _pick(id: String) -> void:
	if _done or is_queued_for_deletion():
		return
	_done = true
	Sfx.select()
	UiKit.close_animated(self)
	if _on_pick.is_valid():
		_on_pick.call(id)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and not event.pressed:
		accept_event()
		SceneRouter.toast(tr("Escolhe uma das maldições para continuar."), 1.6)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		SceneRouter.toast(tr("Escolhe uma das maldições para continuar."), 1.6)
