class_name NoticeLog
extends Control
## 0.19.0 (137): o sino — os últimos 20 avisos (conquistas, desbloqueios, compras…), que no ecrã somem em
## poucos segundos. Abre-se no menu principal e na pausa da batalha.

static func open() -> NoticeLog:
	var o := NoticeLog.new()
	SceneRouter.show_overlay(o)
	o._build()
	return o

func _init() -> void:
	name = "NoticeLog"
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.85))

func _build() -> void:
	var body := UiKit.window(self, 760, tr("AVISOS"), UiKit.GOLD, close, tr("Os últimos %d avisos (o mais recente em cima)") % SceneRouter.toast_log.size())
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.custom_minimum_size = Vector2(0, 380)
	body.add_child(scroll)
	var list := VBoxContainer.new()
	list.name = "List"
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 6)
	scroll.add_child(list)
	if SceneRouter.toast_log.is_empty():
		list.add_child(UiKit.label(tr("Ainda não houve avisos nesta sessão."), 17, UiKit.TEXT_DIM, true))
	for i in range(SceneRouter.toast_log.size() - 1, -1, -1):
		var e: Dictionary = SceneRouter.toast_log[i]
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		list.add_child(row)
		var tl := UiKit.label(String(e.get("time", "")), 15, UiKit.TEXT_DIM)
		tl.custom_minimum_size.x = 52
		row.add_child(tl)
		var l := UiKit.label(String(e.get("text", "")), 17, Color.WHITE, true)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(l)
	UiKit.pop_in(body.get_meta("panel"))

func lines() -> int:
	var list := find_child("List", true, false)
	return list.get_child_count() if list != null else 0

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion():
		return
	Sfx.select()
	UiKit.close_animated(self)
