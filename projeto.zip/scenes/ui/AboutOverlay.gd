class_name AboutOverlay
extends Control
## 0.18.0: o ecrã SOBRE (menu principal, ao lado de NOVIDADES): créditos (com os testers), contactos e
## REPORTAR UM ERRO (copia o relatório técnico do ErrorReport e abre a app de email com ele), a política de
## privacidade e proteção de dados e as licenças (Godot Engine, os componentes que ele traz e os tipos de
## letra). Os textos estão em data/about.json (mudam com uma atualização de conteúdo, sem APK novo).

const TABS := [["credits", "CRÉDITOS"], ["contact", "CONTACTOS"], ["privacy", "PRIVACIDADE"], ["licenses", "LICENÇAS"]]
const FONT_LICENSES := {
	"Inter": "res://assets/fonts/Inter-OFL.txt",
	"Lora": "res://assets/fonts/Lora-OFL.txt",
	"New Rocker": "res://assets/fonts/NewRocker-OFL.txt",
}
const REPORT_MAX := 2400   # o corpo do email leva até isto do relatório (o resto fica na área de transferência)

var _tab := "credits"
var _content: VBoxContainer
var _scroll: ScrollContainer
var _license_text: Label   # o texto completo da licença escolhida (LICENÇAS)

static func open(tab: String = "credits") -> AboutOverlay:
	var o := AboutOverlay.new()
	o._tab = tab
	SceneRouter.show_overlay(o)
	o._build()
	return o

## A versão instalada (a das Novidades, que o SmokeTest confirma igual à do APK).
static func version() -> String:
	var n := NewsOverlay.current()
	return String(n.get("version", "?"))

static func email() -> String:
	return String(CardDB.about.get("email", ""))

## O site do estúdio (Pixel Lusitano); "" se não houver.
static func website() -> String:
	return String(CardDB.about.get("website", ""))

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.8))

func _build() -> void:
	var body := UiKit.window(self, 900, tr("SOBRE O ZERO-SUM"), UiKit.GOLD, _close, tr("Versão %s") % version())
	var items: Array = []
	for t in TABS:
		items.append([t[0], tr(String(t[1]))])
	var chips := UiKit.chip_row(items, _tab, _show_tab, 44)
	chips.name = "AboutTabs"
	body.add_child(chips)
	_scroll = ScrollContainer.new()
	_scroll.name = "AboutScroll"
	_scroll.custom_minimum_size = Vector2(0, 400)
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body.add_child(_scroll)
	_content = VBoxContainer.new()
	_content.name = "AboutContent"
	_content.add_theme_constant_override("separation", 10)
	_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll.add_child(_content)
	_show_tab(_tab)
	UiKit.pop_in(body.get_meta("panel"))

func _show_tab(id: String) -> void:
	_tab = id
	_license_text = null
	for c in _content.get_children():
		_content.remove_child(c)
		c.queue_free()
	_scroll.scroll_vertical = 0
	match id:
		"contact":
			_fill_contact()
		"privacy":
			_fill_privacy()
		"licenses":
			_fill_licenses()
		_:
			_fill_credits()

# --- Créditos ---

func _fill_credits() -> void:
	var head := UiKit.label("Zero-Sum", 34, UiKit.GOLD)
	head.theme_type_variation = &"TitleLabel"
	head.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_content.add_child(head)
	var motto := UiKit.label(tr("Fazemos Ameaças, não promessas."), 18, UiKit.TEXT_DIM)
	motto.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_content.add_child(motto)
	for cr in CardDB.about.get("credits", []):
		if not (cr is Dictionary):
			continue
		var row := HBoxContainer.new()
		row.name = "Credit_" + String(cr.get("id", ""))
		row.add_theme_constant_override("separation", 16)
		_content.add_child(row)
		var role := UiKit.label(tr(String(cr.get("role", ""))), 17, UiKit.TEXT_DIM, true)
		role.custom_minimum_size.x = 280
		role.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		row.add_child(role)
		var names := UiKit.label(_join_names(cr.get("names", [])), 19, Color.WHITE, true)
		names.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(names)
	var thanks := UiKit.label(tr(String(CardDB.about.get("thanks", ""))), 20, UiKit.GOLD)
	thanks.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_content.add_child(thanks)
	var owner := String(CardDB.about.get("studio", CardDB.about.get("author", "")))
	var copy := UiKit.label("© 2026 %s" % owner, 14, UiKit.TEXT_DIM)
	copy.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_content.add_child(copy)

## «A», «A e B», «A, B e C» (os nomes não se traduzem; o «e» sim).
func _join_names(list: Array) -> String:
	var out: Array[String] = []
	for n in list:
		out.append(tr(String(n)))
	if out.size() <= 1:
		return "".join(out)
	return ", ".join(PackedStringArray(out.slice(0, out.size() - 1))) + tr(" e ") + out[out.size() - 1]

# --- Contactos e reportar um erro ---

func _fill_contact() -> void:
	_content.add_child(_section_title(tr("Contacto")))
	var row := HBoxContainer.new()
	row.name = "EmailRow"
	row.add_theme_constant_override("separation", 10)
	_content.add_child(row)
	var mail := UiKit.label(email(), 20, Color.WHITE)
	mail.name = "Email"
	mail.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mail.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(mail)
	var write := UiKit.button(tr("ESCREVER"), 48, 17)
	write.name = "WriteEmail"
	write.custom_minimum_size.x = 150
	write.pressed.connect(_write_email)
	row.add_child(write)
	var copy := UiKit.button(tr("COPIAR"), 48, 17)
	copy.name = "CopyEmail"
	copy.custom_minimum_size.x = 120
	copy.pressed.connect(func():
		Sfx.select()
		DisplayServer.clipboard_set(email())
		SceneRouter.toast(tr("Email copiado.")))
	row.add_child(copy)
	if website() != "":   # o site do estúdio
		var srow := HBoxContainer.new()
		srow.name = "SiteRow"
		srow.add_theme_constant_override("separation", 10)
		_content.add_child(srow)
		var site := UiKit.label(website().trim_prefix("https://").trim_prefix("http://").trim_suffix("/"), 20, Color.WHITE)
		site.name = "Site"
		site.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		site.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		srow.add_child(site)
		var open_site := UiKit.button(tr("ABRIR O SITE"), 48, 17)
		open_site.name = "OpenSite"
		open_site.custom_minimum_size.x = 278
		open_site.pressed.connect(_open_site)
		srow.add_child(open_site)
	_content.add_child(_paragraph(tr("Sugestões, dúvidas e elogios são bem-vindos. Respondemos em português ou em inglês.")))
	_content.add_child(_section_title(tr("Reportar um erro")))
	_content.add_child(_paragraph(tr("Encontraste um erro? Toca em REPORTAR UM ERRO: abre-se a tua app de email com o relatório técnico (versão, telemóvel e as últimas mensagens de erro do jogo). Escreve por cima o que aconteceu e envia. O relatório fica também copiado, se preferires colá-lo noutro sítio.")))
	var brow := HBoxContainer.new()
	brow.add_theme_constant_override("separation", 10)
	_content.add_child(brow)
	var report := UiKit.button(tr("REPORTAR UM ERRO"), 54, 19, UiKit.PRIMARY, Color(0, 0, 0, 0))
	report.name = "ReportBug"
	report.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	report.pressed.connect(report_bug)
	brow.add_child(report)
	var copy_report := UiKit.button(tr("SÓ COPIAR O RELATÓRIO"), 54, 17)
	copy_report.name = "CopyReport"
	copy_report.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	copy_report.pressed.connect(func():
		Sfx.select()
		DisplayServer.clipboard_set(ErrorReport.build())
		SceneRouter.toast(tr("Relatório copiado: cola-o numa mensagem para %s.") % email()))
	brow.add_child(copy_report)
	var see := UiKit.button(tr("VER A POLÍTICA DE PRIVACIDADE"), 46, 16)
	see.name = "SeePrivacy"
	see.pressed.connect(func(): Sfx.select(); _select_tab("privacy"))
	_content.add_child(see)

func _open_site() -> void:
	Sfx.select()
	if OS.shell_open(website()) != OK:
		DisplayServer.clipboard_set(website())
		SceneRouter.toast(tr("Não deu para abrir o navegador: o endereço ficou copiado."))

func _write_email() -> void:
	Sfx.select()
	var err := OS.shell_open(mailto_url(tr("Zero-Sum %s") % version(), ""))
	if err != OK:
		DisplayServer.clipboard_set(email())
		SceneRouter.toast(tr("Não encontrámos uma app de email: o endereço ficou copiado."))

## REPORTAR UM ERRO: copia o relatório inteiro e abre o email com ele (cortado em REPORT_MAX caracteres).
func report_bug() -> void:
	AboutOverlay.send_report()

## 0.19.0 (230): também a partir do aviso de fecho inesperado (sem a janela do SOBRE aberta).
static func send_report() -> void:
	var t := func(x: String) -> String: return TranslationServer.translate(x)
	Sfx.select()
	var report := ErrorReport.build()
	DisplayServer.clipboard_set(report)
	var cut := report if report.length() <= REPORT_MAX else report.substr(0, REPORT_MAX) + "\n…"
	var body: String = t.call("O que aconteceu (e o que estavas a fazer):") + "\n\n\n\n— — —\n" + cut
	var err := OS.shell_open(mailto_url(t.call("Zero-Sum %s — erro") % version(), body))
	if err == OK:
		SceneRouter.toast(t.call("Relatório pronto no email (e copiado). Obrigado!"))
	else:
		SceneRouter.toast(t.call("Não encontrámos uma app de email. O relatório ficou copiado: envia-o para %s.") % email())

## mailto: com o assunto e o corpo (codificados para URL).
static func mailto_url(subject: String, body: String) -> String:
	var url := "mailto:%s?subject=%s" % [email(), subject.uri_encode()]
	if body != "":
		url += "&body=" + body.uri_encode()
	return url

# --- Política de privacidade ---

func _fill_privacy() -> void:
	var head := UiKit.label(tr("Política de privacidade e proteção de dados"), 24, UiKit.GOLD, true)
	head.theme_type_variation = &"TitleLabel"
	_content.add_child(head)
	var upd := String(CardDB.about.get("privacy_updated", ""))
	if upd.length() == 10:
		_content.add_child(UiKit.label(tr("Última atualização: %s") % ("%s/%s/%s" % [upd.substr(8, 2), upd.substr(5, 2), upd.substr(0, 4)]), 15, UiKit.TEXT_DIM))
	for sec in CardDB.about.get("privacy", []):
		if not (sec is Dictionary):
			continue
		var t := _section_title(tr(String(sec.get("title", ""))))
		t.name = "Privacy_" + String(sec.get("id", ""))
		_content.add_child(t)
		_content.add_child(_paragraph(tr(String(sec.get("text", "")))))

# --- Licenças ---

func _fill_licenses() -> void:
	_content.add_child(_section_title("Godot Engine"))
	_content.add_child(_paragraph(tr("O Zero-Sum é feito com o Godot Engine, distribuído com esta licença:"), 15))
	_content.add_child(_mono(Engine.get_license_text()))
	_content.add_child(_section_title(tr("Tipos de letra")))
	for font_name in FONT_LICENSES:
		var first := _first_line(String(FONT_LICENSES[font_name]))
		_content.add_child(_paragraph("%s — SIL Open Font License 1.1%s" % [font_name, ("  ·  " + first) if first != "" else ""], 15))
	_content.add_child(_section_title(tr("Componentes do Godot Engine")))
	var lines: PackedStringArray = []
	for comp in Engine.get_copyright_info():
		var parts: Array = comp.get("parts", [])
		var lic: Array[String] = []
		var who: Array[String] = []
		for p in parts:
			if not (String(p.get("license", "")) in lic):
				lic.append(String(p.get("license", "")))
			for cpr in p.get("copyright", []):
				if who.size() < 2 and not (String(cpr) in who):
					who.append(String(cpr))
		lines.append("%s — %s  (© %s)" % [String(comp.get("name", "")), " / ".join(PackedStringArray(lic)), "; ".join(PackedStringArray(who))])
	_content.add_child(_mono("\n".join(lines)))
	_content.add_child(_section_title(tr("Textos das licenças")))
	_content.add_child(_paragraph(tr("Toca numa licença para ler o texto completo."), 15))
	var flow := HFlowContainer.new()
	flow.name = "LicenseNames"
	flow.add_theme_constant_override("h_separation", 8)
	flow.add_theme_constant_override("v_separation", 8)
	_content.add_child(flow)
	var info := Engine.get_license_info()
	var names: Array = info.keys()
	names.sort()
	for lname in names:
		var b := UiKit.button(String(lname), 44, 15)
		b.name = "License_" + String(lname)
		b.pressed.connect(_show_license.bind(String(lname)))
		flow.add_child(b)
	_license_text = _mono("")
	_license_text.name = "LicenseText"
	_license_text.visible = false
	_content.add_child(_license_text)

func _show_license(lname: String) -> void:
	Sfx.select()
	if _license_text == null or not is_instance_valid(_license_text):
		return
	var info := Engine.get_license_info()
	_license_text.text = lname + "\n\n" + String(info.get(lname, ""))
	_license_text.visible = true
	await get_tree().process_frame
	if is_instance_valid(_license_text):
		_scroll.ensure_control_visible(_license_text)

func _first_line(path: String) -> String:
	if not FileAccess.file_exists(path):
		return ""
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return ""
	while not f.eof_reached():
		var l := f.get_line().strip_edges()
		if l != "":
			return l
	return ""

# --- Peças ---

func _section_title(text: String) -> Label:
	var l := UiKit.label(text, 20, UiKit.GOLD, true)
	return l

func _paragraph(text: String, size: int = 17) -> Label:
	var l := UiKit.label(text, size, Color(0.9, 0.88, 0.95), true)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l

func _mono(text: String) -> Label:
	var l := UiKit.label(text, 13, Color(0.78, 0.76, 0.86), true)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l

## Muda de separador também pelo código (o chip fica marcado).
func _select_tab(id: String) -> void:
	var chips := find_child("AboutTabs", true, false)
	if chips != null:
		for c in chips.get_children():
			if c is Button:
				(c as Button).set_pressed_no_signal(c.name == "Chip_" + id)
	_show_tab(id)

func _close() -> void:
	Sfx.select()
	UiKit.close_animated(self)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and not event.pressed:
		accept_event()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		_close()
