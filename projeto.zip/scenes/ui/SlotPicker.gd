class_name SlotPicker
extends Control
## 0.12.0: escolher o espaço de gravação de um jogo novo — 6 espaços em 2 colunas. Um espaço vazio
## começa logo; um ocupado pede um 2.º toque (a run que lá está perde-se, sem contar como derrota).
## O progresso (talentos, conquistas, desbloqueios) é o mesmo em todos os espaços.

var _on_pick: Callable
var _armed := 0           # espaço ocupado à espera do 2.º toque
var _note: Label
var _buttons: Dictionary = {}

static func open(mode_title: String, on_pick: Callable) -> SlotPicker:
	var o := SlotPicker.new()
	o._on_pick = on_pick
	SceneRouter.show_overlay(o)
	o._build(mode_title)
	return o

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.8))

func _build(mode_title: String) -> void:
	var panel := UiKit.centered_panel(self, 860, UiKit.BG, UiKit.GOLD)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	panel.add_child(vbox)
	var title := UiKit.label(tr("ONDE GUARDAR ESTE JOGO?"), 28, UiKit.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	var sub_text := tr("%s — escolhe um dos 6 espaços. Os talentos, as conquistas e os desbloqueios são os mesmos em todos.") % mode_title
	if GameState.first_free_slot() > 0 and GameState.saved_slot_count() > 0:
		sub_text += "\n" + tr("Escolhe um espaço livre para não substituíres nenhum jogo a meio.")
	var sub := UiKit.label(sub_text, 16, UiKit.TEXT_DIM, true)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(sub)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 10)
	vbox.add_child(grid)
	for i in range(1, GameState.SLOT_COUNT + 1):
		var b := slot_button(i)
		b.name = "Slot%d" % i
		b.custom_minimum_size = Vector2(400, 88)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(_on_slot.bind(i))
		grid.add_child(b)
		_buttons[i] = b
	_note = UiKit.label("", 16, UiKit.GOLD, true)
	_note.name = "Note"
	_note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(_note)
	var cancel := UiKit.button(tr("CANCELAR"), 54, 20)
	cancel.name = "Cancel"
	cancel.pressed.connect(func(): Sfx.select(); queue_free())
	vbox.add_child(cancel)
	UiKit.pop_in(panel)

func _on_slot(slot: int) -> void:
	if GameState.has_saved_run(slot) and _armed != slot:
		Sfx.select()
		if _armed != 0 and _buttons.has(_armed):
			_set_border(_buttons[_armed], Color(0, 0, 0, 0))
		_armed = slot
		_set_border(_buttons[slot], UiKit.DANGER.lightened(0.25))
		var info := GameState.slot_info(slot)
		_note.text = tr("\"%s\" tem uma run a meio (%s · %s). Toca outra vez para a substituir — podes recuperá-la depois em JOGOS GUARDADOS.") % [GameState.slot_name(slot), String(info.get("what", "")), tr("Ante %d") % int(info.get("ante", 1))]
		return
	Sfx.select()
	GameState.current_slot = slot
	GameState.slot_confirmed = true
	var cb := _on_pick
	queue_free()
	if cb.is_valid():
		cb.call(slot)

static func _set_border(b: Button, border: Color) -> void:
	var bg: Color = b.get_meta("bg", UiKit.BTN_BG)
	var w := 3 if border.a > 0 else 0
	b.add_theme_stylebox_override("normal", UiKit.flat(bg, 14, border, w))
	b.add_theme_stylebox_override("hover", UiKit.flat(bg.lightened(0.07), 14, border, w))

## Botão de um espaço (também usado em JOGOS GUARDADOS): nome, o que se joga e o ante, e o modo,
## a dificuldade e há quanto tempo se gravou. Vazio: "Espaço livre".
static func slot_button(slot: int) -> Button:
	var info := GameState.slot_info(slot)
	var empty := info.is_empty()
	var b := Button.new()
	b.focus_mode = Control.FOCUS_NONE
	# 0.14.0: quem corta os textos compridos é a coluna dos textos; o botão não (cortava a sombra e o
	# brilho das placas do menu).
	var bg: Color = UiKit.BTN_BG if not empty else Color(0.15, 0.13, 0.22)
	b.set_meta("bg", bg)
	b.set_meta("slot", slot)
	b.add_theme_stylebox_override("normal", UiKit.flat(bg, 14))
	b.add_theme_stylebox_override("hover", UiKit.flat(bg.lightened(0.07), 14))
	b.add_theme_stylebox_override("pressed", UiKit.flat(bg.lightened(0.16), 14))
	b.add_theme_stylebox_override("disabled", UiKit.flat(bg.darkened(0.35), 14))
	var row := HBoxContainer.new()
	row.set_anchors_preset(Control.PRESET_FULL_RECT)
	row.offset_left = 12
	row.offset_right = -12
	row.offset_top = 4
	row.offset_bottom = -4
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 12)
	b.add_child(row)
	var num := UiKit.label(str(slot), 26, UiKit.GOLD if not empty else UiKit.TEXT_DIM)
	num.custom_minimum_size.x = 22
	num.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	num.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(num)
	var texts := VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.alignment = BoxContainer.ALIGNMENT_CENTER
	texts.mouse_filter = Control.MOUSE_FILTER_IGNORE
	texts.add_theme_constant_override("separation", 0)
	texts.clip_contents = true
	row.add_child(texts)
	if empty:
		var n := UiKit.label(TranslationServer.translate("Espaço livre"), 19, UiKit.TEXT_DIM)
		n.name = "SlotName"
		texts.add_child(n)
		var d := UiKit.label(TranslationServer.translate("Começa aqui um jogo novo."), 14, Color(0.6, 0.6, 0.7))
		texts.add_child(d)
		return b
	var name_l := UiKit.label(GameState.slot_name(slot), 19, Color.WHITE)
	name_l.name = "SlotName"
	name_l.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	texts.add_child(name_l)
	var ante := int(info.get("ante", 1))
	var max_a := int(info.get("max_ante", 8))
	var ante_txt := TranslationServer.translate("Ante %d/%d") % [ante, max_a] if ante <= max_a else TranslationServer.translate("Ante %d (infinito)") % ante
	var l1 := UiKit.label("%s  ·  %s" % [String(info.get("what", "")), ante_txt], 15, UiKit.GOLD)
	l1.name = "SlotWhat"
	l1.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	texts.add_child(l1)
	var diff := String(GameState.DIFFICULTY_NAMES.get(String(info.get("difficulty", "normal")), "Normal"))
	var l2 := UiKit.label("%s  ·  %s  ·  %s" % [TranslationServer.translate(GameState.mode_name(String(info.get("mode", "campaign")))), TranslationServer.translate(diff), ago(float(info.get("saved_at", 0.0)))], 14, UiKit.TEXT_DIM)
	l2.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	texts.add_child(l2)
	return b

## "agora mesmo", "há 5 min", "há 2 h", "há 3 dias".
static func ago(t: float) -> String:
	var d := Time.get_unix_time_from_system() - t
	if t <= 0.0 or d < 90.0:
		return TranslationServer.translate("agora mesmo")
	if d < 3600.0:
		return TranslationServer.translate("há %d min") % int(d / 60.0)
	if d < 86400.0:
		return TranslationServer.translate("há %d h") % int(d / 3600.0)
	var days := int(d / 86400.0)
	return TranslationServer.translate("há 1 dia") if days == 1 else TranslationServer.translate("há %d dias") % days

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		queue_free()
