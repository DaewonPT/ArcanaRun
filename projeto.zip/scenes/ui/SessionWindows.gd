class_name SessionWindows
extends RefCounted
## 0.19.0 (175, 196): duas janelas de começo de sessão — «Onde ficaste» (ao continuar uma run parada há mais de
## 6 horas: baralho, relíquias, ante e o que vem a seguir) e o lembrete das regras (depois de um mês sem jogar).

const RESUME_AFTER := 6 * 3600
const REFRESH_AFTER := 30 * 86400

static func _t(s: String) -> String:
	return TranslationServer.translate(s)

## 175: o resumo da run carregada (GameState já com a run); `go_on` continua.
static func resume_lines() -> Array[String]:
	var lines: Array[String] = []
	lines.append(_t("Baralho: %s") % _t(String(GameState.deck_def.get("name", ""))) + "  ·  " + GameState.stage_label())
	lines.append(_t("Vida %d/%d  ·  %d de ouro  ·  %d cartas") % [GameState.player_hp, GameState.player_max_hp, GameState.gold, GameState.deck.size()])
	var rel: Array[String] = []
	for id in GameState.relic_ids:
		rel.append(_t(String(CardDB.relics.get(id, {}).get("name", id))))
	if not rel.is_empty():
		lines.append(_t("Relíquias: %s") % ", ".join(PackedStringArray(rel)))
	var nxt := ""
	match GameState.saved_scene:
		"battle":
			nxt = _t("A seguir: a batalha a meio (turno gravado).")
		"shop":
			nxt = _t("A seguir: a loja.")
		"event":
			nxt = _t("A seguir: um evento.")
		"loot":
			nxt = _t("A seguir: o Baú de Espólio.")
		_:
			nxt = _t("A seguir: escolher a batalha do ante %d.") % GameState.ante if GameState.map_phase == "battle" else _t("A seguir: escolher a paragem do ante %d.") % GameState.ante
	lines.append(nxt)
	return lines

static func open_resume(go_on: Callable) -> Control:
	var o := Control.new()
	o.name = "ResumeSummary"
	o.set_anchors_preset(Control.PRESET_FULL_RECT)
	o.mouse_filter = Control.MOUSE_FILTER_STOP
	o.add_child(UiKit.dim(0.82))
	SceneRouter.show_overlay(o)
	var body := UiKit.window(o, 700, _t("ONDE FICASTE"), UiKit.GOLD, func(): UiKit.close_animated(o), _t("A tua run, para retomares o fio"))
	for line in resume_lines():
		body.add_child(UiKit.label(line, 18, Color.WHITE, true))
	var b := UiKit.button(_t("CONTINUAR"), 56, 22, UiKit.PRIMARY)
	b.name = "GoOn"
	b.pressed.connect(func():
		Sfx.select()
		UiKit.close_animated(o)
		go_on.call())
	body.add_child(b)
	UiKit.pop_in(body.get_meta("panel"))
	return o

## 0.19.0 (277, 286): no 1.º arranque, antes do tutorial — texto maior, menos movimento, modo daltónico e o aviso
## das luzes a piscar (com o atalho para as tirar). Uma vez só (progress.first_questions).
const FIRST_QUESTIONS := [
	["large_text", "Texto maior", "Letras maiores em todo o jogo."],
	["reduce_motion", "Menos movimento", "Sem abanões, flashes nem partículas."],
	["colorblind", "Modo daltónico", "Um símbolo em cada cor, além da cor."],
	["no_flash", "Sem luzes a piscar", "O jogo tem clarões nos golpes grandes; isto tira-os."],
]

static func needs_first_questions() -> bool:
	return not bool(GameState.progress.get("first_questions", false)) and int(Stats.stats().get("runs", 0)) == 0

static func open_first_run() -> Control:
	GameState.progress["first_questions"] = true
	GameState.save_progress()
	var o := Control.new()
	o.name = "FirstRun"
	o.set_anchors_preset(Control.PRESET_FULL_RECT)
	o.mouse_filter = Control.MOUSE_FILTER_STOP
	o.add_child(UiKit.dim(0.84))
	SceneRouter.show_overlay(o)
	var body := UiKit.window(o, 760, _t("ANTES DE COMEÇAR"), UiKit.GOLD, func(): UiKit.close_animated(o), _t("Escolhe como preferes jogar (muda quando quiseres nas Configurações)"))
	var warn := UiKit.label("⚠ " + _t("Aviso: o jogo tem luzes a piscar e clarões nos ataques grandes."), 16, Color(1.0, 0.8, 0.5), true)
	warn.name = "FlashWarning"
	body.add_child(warn)
	for q in FIRST_QUESTIONS:
		var key := String(q[0])
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		body.add_child(row)
		var col := VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.add_theme_constant_override("separation", 0)
		row.add_child(col)
		col.add_child(UiKit.label(_t(String(q[1])), 19, Color.WHITE))
		col.add_child(UiKit.label(_t(String(q[2])), 14, UiKit.TEXT_DIM, true))
		var b := UiKit.button("", 50, 18)
		b.name = "Q_" + key
		b.custom_minimum_size.x = 180
		var on := first_answer(key)
		b.text = _t("SIM") if on else _t("NÃO")
		b.pressed.connect(func():
			Sfx.select()
			set_first_answer(key, not first_answer(key))
			b.text = _t("SIM") if first_answer(key) else _t("NÃO"))
		row.add_child(b)
	var go := UiKit.button(_t("COMEÇAR"), 56, 22, UiKit.PRIMARY)
	go.name = "Start"
	go.pressed.connect(func(): Sfx.select(); UiKit.close_animated(o))
	body.add_child(go)
	UiKit.pop_in(body.get_meta("panel"))
	return o

static func first_answer(key: String) -> bool:
	if key == "no_flash":
		return not bool(Settings.opt("fx_flash"))
	return bool(Settings.opt(key))

static func set_first_answer(key: String, on: bool) -> void:
	if key == "no_flash":
		Settings.set_opt("fx_flash", not on)
	else:
		Settings.set_opt(key, on)
	Settings.apply()

## 196: o resumo das regras (30 segundos de leitura).
const RULES := [
	"Joga criaturas e feitiços com a mana do turno; os Terrenos dão +1 mana para sempre.",
	"No fim do turno, ATACAR: o Poder das criaturas, da esquerda para a direita, vezes o Mult — relíquias uma a uma.",
	"Formações (pares de custo, Bando, Curva…) dão Mult; a ordem da Arena conta.",
	"O inimigo contra-ataca: escolhe quem bloqueia ou leva tu o dano. Tens 5 turnos para o vencer.",
	"Entre batalhas: loja (cartas, relíquias, serviços), eventos, descanso. O ouro que guardas rende juros.",
	"Toque longo explica qualquer carta ou ícone; o «?» abre o Como Jogar na página certa.",
]

static func maybe_rules_refresher() -> Control:
	var now := int(Time.get_unix_time_from_system())
	var last := int(GameState.progress.get("last_played", 0))
	GameState.progress["last_played"] = now
	GameState.save_progress()
	if last <= 0 or now - last < REFRESH_AFTER or not bool(Settings.opt("rules_refresher")) or SceneRouter.has_overlay():
		return null
	return open_rules()

static func open_rules() -> Control:
	var o := Control.new()
	o.name = "RulesRefresher"
	o.set_anchors_preset(Control.PRESET_FULL_RECT)
	o.mouse_filter = Control.MOUSE_FILTER_STOP
	o.add_child(UiKit.dim(0.82))
	SceneRouter.show_overlay(o)
	var body := UiKit.window(o, 820, _t("BEM-VINDO DE VOLTA"), UiKit.GOLD, func(): UiKit.close_animated(o), _t("As regras em 30 segundos"))
	for r in RULES:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		body.add_child(row)
		var dot := UiKit.label("✦", 18, UiKit.GOLD)
		dot.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
		row.add_child(dot)
		var l := UiKit.label(_t(String(r)), 18, Color.WHITE, true)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(l)
	var b := UiKit.button(_t("VAMOS A ISSO"), 56, 22, UiKit.PRIMARY)
	b.pressed.connect(func(): Sfx.select(); UiKit.close_animated(o))
	body.add_child(b)
	UiKit.pop_in(body.get_meta("panel"))
	return o
