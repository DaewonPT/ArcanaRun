class_name DamageChart
extends Control
## Gráfico de barras do dano por ante (resumo do fim da run). A altura é logarítmica — o dano cresce
## muito de ante para ante — e cada barra tem o valor por cima.

var values: Array = []        # dano por ante, pela ordem (índice 0 = ante 1)
var color := Color(0.98, 0.75, 0.25)

func _init() -> void:
	custom_minimum_size = Vector2(360, 150)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func set_values(v: Array) -> void:
	values = v
	queue_redraw()

static func short(n: int) -> String:
	if n >= 1000000:
		return "%.1fM" % (n / 1000000.0)
	if n >= 1000:
		return "%dk" % int(round(n / 1000.0))
	return str(n)

func _draw() -> void:
	var font := get_theme_default_font()
	var n := values.size()
	if n == 0:
		draw_string(font, Vector2(0, size.y / 2.0), TranslationServer.translate("Sem ataques registados."), HORIZONTAL_ALIGNMENT_LEFT, size.x, 16, Color(0.7, 0.7, 0.8))
		return
	var top := 22.0
	var bottom := size.y - 20.0
	var h := bottom - top
	var max_log := 1.0
	for v in values:
		max_log = maxf(max_log, log(maxf(1.0, float(v))) / log(10.0))
	var slot := size.x / float(n)
	var bw := minf(42.0, slot * 0.62)
	draw_line(Vector2(0, bottom), Vector2(size.x, bottom), Color(1, 1, 1, 0.2), 1.0)
	for i in n:
		var v := float(values[i])
		var lv := log(maxf(1.0, v)) / log(10.0)
		var bh := h * clampf(lv / max_log, 0.04, 1.0) if v > 0.0 else 2.0
		var x := slot * i + (slot - bw) / 2.0
		var r := Rect2(Vector2(x, bottom - bh), Vector2(bw, bh))
		draw_rect(r, color.darkened(0.15 * float(n - 1 - i) / maxf(1.0, n - 1)))
		var label := short(int(v))
		var tw := font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, 13).x
		draw_string(font, Vector2(x + bw / 2.0 - tw / 2.0, bottom - bh - 5.0), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color.WHITE)
		var a := str(i + 1)
		var aw := font.get_string_size(a, HORIZONTAL_ALIGNMENT_LEFT, -1, 13).x
		draw_string(font, Vector2(x + bw / 2.0 - aw / 2.0, size.y - 4.0), a, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(0.7, 0.7, 0.8))
