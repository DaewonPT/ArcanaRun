class_name CardMarks
extends Control
## 0.19.0 (secção 4): marcas pequenas por cima de uma carta — a versão + (134), o custo em vida da Mana de Sangue
## (113), a formação de que faz parte (105), a formação que fecha se for jogada (106) e a cor fraca do inimigo
## (107). Desenhadas todas num só nó (sem Labels nem painéis, para não somar comandos de desenho no telemóvel).
## Cada marca é {"text", "color"}; ficam empilhadas no canto de cima à direita, por baixo do nome.

var marks: Array = []
var u := 1.0
var _sig := ""

func _init() -> void:
	name = "Marks"
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	z_index = 2

func set_marks(m: Array, scale_u: float) -> void:
	var sig := str(m) + "|" + str(snappedf(scale_u, 0.01))
	if sig == _sig:
		return
	_sig = sig
	marks = m
	u = scale_u
	visible = not m.is_empty()
	queue_redraw()

func _draw() -> void:
	if marks.is_empty():
		return
	var font := get_theme_default_font()
	var fs := maxi(9, roundi(11.0 * u))
	var h := roundf(15.0 * u) + 2.0
	var y := roundf(31.0 * u)   # por baixo do nome e da esfera do custo
	for m in marks:
		var t := String(m.get("text", ""))
		if t == "":
			continue
		var col: Color = m.get("color", Color.WHITE)
		var tw := font.get_string_size(t, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		var w := minf(size.x - 6.0 * u, tw + 9.0 * u)
		var r := Rect2(size.x - w - 3.0 * u, y, w, h)
		var st := StyleBoxFlat.new()
		st.bg_color = Color(col, 0.95)
		st.set_corner_radius_all(int(h / 2.0))
		st.border_color = Color(0, 0, 0, 0.55)
		st.set_border_width_all(1)
		draw_style_box(st, r)
		var ink := Color(0.08, 0.07, 0.1) if col.get_luminance() > 0.5 else Color.WHITE
		var base := r.position.y + (h + font.get_ascent(fs) - font.get_descent(fs)) / 2.0
		draw_string(font, Vector2(r.position.x + 4.5 * u, base), t, HORIZONTAL_ALIGNMENT_LEFT, w - 8.0 * u, fs, ink)
		y += h + 2.0 * u
