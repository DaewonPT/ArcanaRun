class_name ArenaSlots
extends Control
## 0.16.0: o chão da Arena — tudo o que fica por cima do tapete e por baixo das criaturas:
##   V30 — lugares: com a Arena vazia, contornos tracejados onde as criaturas vão ficar, com o número da ordem;
##         enquanto arrastas uma criatura da mão, o lugar para onde ela vai acende a dourado;
##   61  — a sombra suave de cada criatura pousada no tapete;
##   62  — o anel da cor da criatura que se espalha quando ela assenta.
## É o primeiro filho do ScrollContainer da Arena (que o estica como ao conteúdo), antes das cartas: desenha-se
## entre o tapete e elas. Não pode ser top_level: esses desenham-se por cima de toda a cena.
## Só redesenha quando muda (e a cada frame só enquanto há um anel a espalhar-se).

var card_size := Vector2(130, 186)
var gap := 10.0
var slots := 5            # máximo de criaturas
var lit := -1             # lugar a acender (-1: nenhum)
var cards: Array[Rect2] = []   # criaturas na Arena (coordenadas globais)
var _rings: Array = []    # [centro (global), cor, idade]
const RING_TIME := 0.5
## 56: o tapete racha quando o boss desperta (rachas escuras com um brilho vermelho, sempre nos mesmos sítios).
var cracked := false:
	set(v):
		if v != cracked:
			cracked = v
			queue_redraw()

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	set_process(false)

func set_state(p_slots: int, p_lit: int, p_cards: Array[Rect2], p_card: Vector2) -> void:
	if p_slots == slots and p_lit == lit and p_cards == cards and p_card == card_size:
		return
	slots = p_slots
	lit = p_lit
	cards = p_cards
	card_size = p_card
	queue_redraw()

## Anel que se espalha por baixo de uma criatura que acabou de assentar (rect global da carta).
func ring(card_rect: Rect2, color: Color) -> void:
	if not Settings.motion_ok():
		return
	_rings.append([Vector2(card_rect.get_center().x, card_rect.end.y - card_rect.size.y * 0.08), color, 0.0, card_rect.size.x])
	set_process(true)

func _process(delta: float) -> void:
	for r in _rings:
		r[2] = float(r[2]) + delta
	_rings = _rings.filter(func(r): return float(r[2]) < RING_TIME)
	if _rings.is_empty():
		set_process(false)
	queue_redraw()

func _draw() -> void:
	var off := -global_position
	# 61: sombras (por baixo de tudo o resto).
	if not Settings.performance_mode:
		var sh := StyleBoxFlat.new()
		sh.bg_color = Color(0, 0, 0, 0.28)
		sh.set_corner_radius_all(12)
		sh.shadow_color = Color(0, 0, 0, 0.42)
		sh.shadow_size = 12
		for r in cards:
			draw_style_box(sh, Rect2(r.position + off + Vector2(5, 9), r.size - Vector2(4, 6)))
	if cracked:
		_draw_cracks()
	# V30: lugares.
	if cards.is_empty():
		var n := slots
		var total := n * card_size.x + (n - 1) * gap
		var x0 := (size.x - total) * 0.5
		var y0 := (size.y - card_size.y) * 0.5
		for i in n:
			_slot(Rect2(Vector2(x0 + i * (card_size.x + gap), y0), card_size), i + 1, i == lit)
	elif lit >= 0 and cards.size() < slots:
		var last: Rect2 = cards[cards.size() - 1]
		_slot(Rect2(Vector2(last.end.x + gap, last.position.y) + off, card_size), cards.size() + 1, true)
	# 62: anéis.
	for rg in _rings:
		var k := float(rg[2]) / RING_TIME
		var c: Vector2 = rg[0] + off
		var w: float = rg[3]
		var col: Color = rg[1]
		var rx := w * (0.3 + 0.55 * k)
		var pts := PackedVector2Array()
		for i in 33:
			var a := TAU * i / 32.0
			pts.append(c + Vector2(cos(a) * rx, sin(a) * rx * 0.28))
		draw_polyline(pts, Color(col.lightened(0.2), 0.85 * (1.0 - k)), 3.0 * (1.0 - k) + 1.0, true)

func _draw_cracks() -> void:
	var w := size.x
	var h := size.y
	var rng := RandomNumberGenerator.new()
	rng.seed = 1609
	for k in 5:
		var p := Vector2(w * (0.12 + 0.19 * k + rng.randf_range(-0.04, 0.04)), h * rng.randf_range(0.7, 0.95))
		var pts := PackedVector2Array([p])
		var dir := Vector2(rng.randf_range(-0.6, 0.6), -1.0).normalized()
		for i in 7:
			p += (dir.rotated(rng.randf_range(-0.7, 0.7))) * h * 0.11
			pts.append(p)
		draw_polyline(pts, Color(0.95, 0.25, 0.15, 0.22), 5.0, true)
		draw_polyline(pts, Color(0.04, 0.0, 0.02, 0.75), 2.0, true)
		if pts.size() > 3:
			draw_polyline(PackedVector2Array([pts[3], pts[3] + Vector2(h * 0.12, -h * 0.05)]), Color(0.04, 0.0, 0.02, 0.6), 1.4, true)

func _slot(r: Rect2, n: int, on: bool) -> void:
	var c := Color(1.0, 0.82, 0.35, 0.95) if on else Color(1, 1, 1, 0.22)
	if on:
		var glow := StyleBoxFlat.new()
		glow.bg_color = Color(1.0, 0.8, 0.3, 0.12)
		glow.set_corner_radius_all(12)
		glow.shadow_color = Color(1.0, 0.75, 0.25, 0.35)
		glow.shadow_size = 12
		draw_style_box(glow, r)
	var w := 2.5 if on else 1.6
	var pts := [r.position, Vector2(r.end.x, r.position.y), r.end, Vector2(r.position.x, r.end.y)]
	for i in 4:
		draw_dashed_line(pts[i], pts[(i + 1) % 4], c, w, 9.0)
	var font := get_theme_default_font()
	var fs := int(clampf(card_size.y * 0.24, 22.0, 46.0))
	var txt := str(n)
	var ts := font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
	draw_string(font, r.get_center() + Vector2(-ts.x * 0.5, ts.y * 0.3), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(c, 0.6 if not on else 0.9))
