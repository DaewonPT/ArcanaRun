class_name MapBackdrop
extends Control
## 0.13.0 — mapa vivo: por trás dos nós do mapa, névoa colorida (na cor do ato) a deslizar devagar e
## pirilampos/brasas a subir e a cintilar. Desenhado em código, a ~30 fps; com o movimento reduzido fica
## parado (desenhado uma vez); no modo de desempenho tem menos pirilampos e 20 fps.

const ACT_TINTS := [Color(0.98, 0.8, 0.42), Color(0.42, 0.66, 1.0), Color(0.72, 0.48, 0.98), Color(1.0, 0.48, 0.36), Color(0.42, 0.92, 0.86)]

var act := 1
var art: Texture2D = null   # ilustração do ato (se houver): fica por baixo, escurecida, e a névoa sai
var _t := 0.0
var _acc := 0.0
var _motes: Array = []   # [x (0–1), y (0–1), velocidade, fase, raio]
var _fog: Array = []     # [x, y, raio (fração da altura), velocidade, fase]
var _rng := RandomNumberGenerator.new()

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)

func _ready() -> void:
	Settings.changed.connect(queue_redraw)   # 0.19.0 (216): o tema preto (e as outras opções) redesenham já
	_rng.seed = 7331 + act
	var n := 18 if Settings.performance_mode else 42
	for i in n:
		_motes.append([_rng.randf(), _rng.randf(), _rng.randf_range(0.012, 0.035), _rng.randf() * TAU, _rng.randf_range(1.2, 2.8)])
	for i in 5:
		_fog.append([_rng.randf(), _rng.randf_range(0.25, 0.9), _rng.randf_range(0.35, 0.6), _rng.randf_range(0.004, 0.011) * (1.0 if i % 2 == 0 else -1.0), _rng.randf() * TAU])
	set_process(Settings.motion_ok())

func tint() -> Color:
	return ACT_TINTS[clampi(act - 1, 0, ACT_TINTS.size() - 1)]

func _process(delta: float) -> void:
	if SceneRouter.decor_still() or Settings.black_theme():
		return   # 0.19.0 (207, 208, 216, 224)
	_t += delta
	_acc += delta
	var step := 1.0 / (20.0 if Settings.performance_mode else 30.0)
	if _acc < step:
		return
	_acc = 0.0
	queue_redraw()

func _draw() -> void:
	var w := size.x
	var h := size.y
	if w <= 0.0 or h <= 0.0:
		return
	if Settings.black_theme():   # 0.19.0 (216)
		draw_rect(Rect2(0, 0, w, h), Color.BLACK)
		return
	var tex := MenuBackdrop.glow_texture()
	var col := tint()
	if art != null:
		# 0.13.0 (mapa ilustrado): a paisagem do ato, mais escura em cima (cabeçalho) e em baixo (dica).
		draw_texture_rect_region(art, Rect2(0, 0, w, h), ArtLib.cover_region(art, Vector2(w, h), 0.5))
		var top := Color(0.055, 0.043, 0.094, 0.78)
		var mid := Color(0.055, 0.043, 0.094, 0.32)
		var bot := Color(0.055, 0.043, 0.094, 0.62)
		draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(w, 0), Vector2(w, h * 0.42), Vector2(0, h * 0.42)]), PackedColorArray([top, top, mid, mid]))
		draw_polygon(PackedVector2Array([Vector2(0, h * 0.42), Vector2(w, h * 0.42), Vector2(w, h), Vector2(0, h)]), PackedColorArray([mid, mid, bot, bot]))
	# Névoa: manchas grandes e suaves que atravessam o ecrã e voltam pelo outro lado (sem ilustração).
	for f in (_fog if art == null else []):
		var x := fposmod(float(f[0]) + float(f[3]) * _t, 1.3) - 0.15
		var y := float(f[1]) + 0.03 * sin(_t * 0.2 + float(f[4]))
		var r := float(f[2]) * h
		var a := 0.07 + 0.03 * sin(_t * 0.35 + float(f[4]))
		draw_texture_rect(tex, Rect2(Vector2(x * w, y * h) - Vector2(r * 1.6, r), Vector2(r * 3.2, r * 2.0)), false, Color(col, a))
	# Pirilampos: sobem devagar, ondulam para os lados e cintilam.
	for m in _motes:
		var y := fposmod(float(m[1]) - float(m[2]) * _t, 1.0)
		var x := float(m[0]) + 0.012 * sin(_t * 0.9 + float(m[3]))
		var tw := 0.5 + 0.5 * sin(_t * 2.2 + float(m[3]) * 3.0)
		var fade := smoothstep(0.0, 0.15, y) * smoothstep(1.0, 0.75, y)   # aparecem em baixo e somem em cima
		var r := float(m[4])
		var p := Vector2(x * w, y * h)
		draw_texture_rect(tex, Rect2(p - Vector2(r * 4.0, r * 4.0), Vector2(r * 8.0, r * 8.0)), false, Color(col.lightened(0.3), 0.18 * tw * fade))
		draw_circle(p, r * 0.55, Color(1.0, 0.97, 0.85, 0.55 * tw * fade))
