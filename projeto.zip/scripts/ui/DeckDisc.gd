class_name DeckDisc
extends Control
## 0.16.1 (V55/V56): o "sigilo" pequeno de um baralho nas listas das Estatísticas e do Construtor — um
## círculo repartido pelas cores de mana do baralho (cinzento nos incolores) com um aro dourado.

const GOLD := Color(0.95, 0.76, 0.31)

var deck_id := "":
	set(v):
		deck_id = v
		_colors = []
		for c in CardDB.get_deck(v).get("colors", []):
			if CardView.COLORS.has(String(c)) and String(c) != "colorless":
				_colors.append(CardView.COLORS[String(c)])
		queue_redraw()
var dim := false:
	set(v):
		dim = v
		queue_redraw()
var _colors: Array = []

static func make(p_deck_id: String, px: float = 28.0) -> DeckDisc:
	var d := DeckDisc.new()
	d.custom_minimum_size = Vector2(px, px)
	d.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	d.deck_id = p_deck_id
	return d

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	var c := size * 0.5
	var r := minf(size.x, size.y) * 0.5 - 1.5
	if r < 3.0:
		return
	var inner := r - maxf(2.0, r * 0.16)
	var cols: Array = _colors if not _colors.is_empty() else [CardView.COLORS["colorless"]]
	var n := cols.size()
	# Fatias verticais (como nos esboços): da esquerda para a direita, pela ordem das cores.
	for i in n:
		var a0 := PI * 0.5 + TAU * i / n
		var a1 := PI * 0.5 + TAU * (i + 1) / n
		if n == 1:
			draw_circle(c, inner, cols[0])
			break
		var pts := PackedVector2Array([c])
		for k in 25:
			var a := lerpf(a0, a1, k / 24.0)
			pts.append(c + Vector2(cos(a), sin(a)) * inner)
		draw_colored_polygon(pts, cols[i])
	draw_arc(c, r - 0.5, 0.0, TAU, 40, Color(GOLD, 0.55 if dim else 1.0), maxf(1.5, r * 0.13), true)
	if dim:
		draw_circle(c, inner, Color(0.05, 0.04, 0.09, 0.55))
