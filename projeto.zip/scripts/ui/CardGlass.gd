class_name CardGlass
extends Control
## 0.14.0 (visual "Vidro arcano"): os enfeites de vidro de uma carta, desenhados por trás do texto, num só
## nó, num só comando de desenho (TriBatch) e só quando a carta muda (não a cada frame):
##   reflexo do vidro no canto de cima · contorno em degradê nas cartas de várias cores · custo num
##   hexágono com brilho · pips das cores · linha que esbate depois do tipo · losango da raridade ·
##   selo de runas por trás do texto (só quando a carta não tem o sigilo próprio).
## O dono (CardView, CardZoom) diz onde fica cada peça, em coordenadas do painel da carta (`card_size`);
## este nó pode estar deslocado dentro do painel (`position`), por isso desenha já com esse desvio.

var card_size := Vector2.ZERO
var radius := 12.0
## Cores néon da carta (1 a 3). A primeira é a principal.
var neon: Array[Color] = [Color(0.36, 0.61, 0.94)]
var gradient_border := false
var border_width := 2.0
var sheen := true
var sheen_alpha := 0.13
## Hexágono do custo (vazio = sem hexágono).
var hex_rect := Rect2()
## Pips das cores (fora do modo daltónico, em que são ícones com símbolo).
var pip_rects: Array[Rect2] = []
var pip_colors: Array[Color] = []
## Linha que esbate depois do nome do tipo.
var fade_from := Vector2.ZERO
var fade_to := Vector2.ZERO
var fade_color := Color(1, 1, 1, 0)
## Losango da raridade (vazio ou alfa 0 = sem losango).
var gem_rect := Rect2()
var gem_color := Color(1, 1, 1, 0)
var gem_glow := false
## Selo de runas por trás do texto (vazio = sem selo).
var rune_rect := Rect2()
var rune_color := Color(1, 1, 1, 0)

const SHEEN_DIR := Vector2(0.883, 0.469)   # o reflexo vem do canto de cima à esquerda (118°)

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func main_color() -> Color:
	return neon[0] if not neon.is_empty() else Color.WHITE

func _draw() -> void:
	if card_size.x < 8.0 or card_size.y < 8.0:
		return
	var b := TriBatch.new()
	b.offset = -position
	if rune_rect.size.x > 4.0 and rune_color.a > 0.0:
		_rune(b, rune_rect, rune_color)
	if sheen and sheen_alpha > 0.0:
		_sheen(b)
	if gradient_border and neon.size() >= 2:
		_gradient_border(b)
	if hex_rect.size.x > 2.0:
		_hex(b, hex_rect)
	for i in mini(pip_rects.size(), pip_colors.size()):
		var c := pip_rects[i].get_center()
		var r := minf(pip_rects[i].size.x, pip_rects[i].size.y) * 0.5
		b.disc(c, r, Color(0.05, 0.03, 0.1, 0.7), 14)
		b.disc(c, maxf(1.0, r - 0.9), pip_colors[i], 14)
	if fade_color.a > 0.0 and fade_to.x > fade_from.x + 3.0:
		b.seg(fade_from, fade_to, 1.0, fade_color, Color(fade_color, 0.0))
	if gem_rect.size.x > 1.0 and gem_color.a > 0.0:
		_gem(b, gem_rect, gem_color, gem_glow)
	b.flush(self)

## Reflexo: uma faixa clara junto ao canto de cima à esquerda, que se apaga a 30 % da diagonal. É um
## polígono recortado do próprio contorno da carta, com o alfa nos vértices (o degradê sai exato).
func _sheen(b: TriBatch) -> void:
	var length := absf(card_size.x * SHEEN_DIR.x) + absf(card_size.y * SHEEN_DIR.y)
	var lim := length * 0.3
	var poly := clip_half(ArtLib.rounded_rect_points(Rect2(Vector2.ZERO, card_size), radius, 4), SHEEN_DIR, lim)
	if poly.size() < 3:
		return
	var cols := PackedColorArray()
	for p in poly:
		cols.append(Color(1, 1, 1, sheen_alpha * (1.0 - clampf(p.dot(SHEEN_DIR) / lim, 0.0, 1.0))))
	b.convex(poly, cols)

## Contorno das cartas de várias cores: as cores seguem a diagonal (de cima à esquerda para baixo à direita),
## por cima do contorno do painel, com uma orla suave dos dois lados.
func _gradient_border(b: TriBatch) -> void:
	var outer_r := Rect2(Vector2.ZERO, card_size)
	var inner_r := outer_r.grow(-border_width)
	var outer := ArtLib.rounded_rect_points(outer_r, radius, 6)
	var inner := ArtLib.rounded_rect_points(inner_r, maxf(0.0, radius - border_width), 6)
	var c_out := PackedColorArray()
	var c_in := PackedColorArray()
	var diag := card_size.x + card_size.y
	for p in outer:
		c_out.append(color_at((p.x + p.y) / diag))
	for p in inner:
		c_in.append(color_at((p.x + p.y) / diag))
	b.strip(outer, inner, c_out, c_in)
	var fade_out := PackedColorArray()
	for c in c_out:
		fade_out.append(Color(c, 0.0))
	b.strip(ArtLib.rounded_rect_points(outer_r.grow(0.8), radius + 0.8, 6), outer, fade_out, c_out)

## Cor do degradê das cores da carta em t (0 a 1).
func color_at(t: float) -> Color:
	if neon.size() <= 1:
		return main_color()
	var f := clampf(t, 0.0, 1.0) * (neon.size() - 1)
	var i := mini(int(f), neon.size() - 2)
	return neon[i].lerp(neon[i + 1], f - i)

## Custo: hexágono com aro claro, interior em degradê (claro em cima, escuro em baixo) e brilho à volta.
## Nas cartas de duas ou mais cores, o interior parte-se na diagonal com as duas primeiras.
func _hex(b: TriBatch, r: Rect2) -> void:
	var c := r.get_center()
	var hw := r.size.x * 0.5
	var hh := r.size.y * 0.5
	var outer := hexagon(c, hw, hh)
	var glow := main_color() if neon.size() < 2 else neon[0].lerp(neon[1], 0.5)
	b.strip(hexagon(c, hw + 5.0, hh + 5.0), outer, PackedColorArray([Color(glow, 0.0)]), PackedColorArray([Color(glow, 0.42)]))
	var rim := main_color().lerp(Color.WHITE, 0.72) if neon.size() < 2 else Color(0.96, 0.95, 1.0)
	b.convex(outer, PackedColorArray([rim]))
	b.feather(outer, hexagon(c, hw + 0.8, hh + 0.8), rim)
	var inner := hexagon(c, hw - maxf(1.4, hw * 0.13), hh - maxf(1.6, hh * 0.13))
	if neon.size() < 2:
		_hex_fill(b, inner, main_color(), c.y - hh, hh * 2.0)
		return
	var split := Vector2(0.7071, 0.7071)
	var lim := c.dot(split)
	_hex_fill(b, clip_half(inner, split, lim), neon[0], c.y - hh, hh * 2.0)
	_hex_fill(b, clip_half(inner, -split, -lim), neon[1], c.y - hh, hh * 2.0)

func _hex_fill(b: TriBatch, poly: PackedVector2Array, col: Color, top: float, height: float) -> void:
	if poly.size() < 3:
		return
	var light := col.lerp(Color.WHITE, 0.3)
	var dark := col.darkened(0.42)
	var cols := PackedColorArray()
	for p in poly:
		cols.append(light.lerp(dark, clampf((p.y - top) / height, 0.0, 1.0)))
	b.convex(poly, cols)

func _gem(b: TriBatch, r: Rect2, col: Color, glow: bool) -> void:
	var c := r.get_center()
	var s := minf(r.size.x, r.size.y) * 0.5
	if glow:
		var g := s + 2.2
		b.convex(PackedVector2Array([c + Vector2(0, -g), c + Vector2(g, 0), c + Vector2(0, g), c + Vector2(-g, 0)]), PackedColorArray([Color(col, 0.3)]))
	var d := PackedVector2Array([c + Vector2(0, -s), c + Vector2(s, 0), c + Vector2(0, s), c + Vector2(-s, 0)])
	b.convex(d, PackedColorArray([col]))
	b.feather(d, PackedVector2Array([c + Vector2(0, -s - 0.8), c + Vector2(s + 0.8, 0), c + Vector2(0, s + 0.8), c + Vector2(-s - 0.8, 0)]), col)

## Selo de runas: anel, anel tracejado e estrela de seis pontas.
func _rune(b: TriBatch, r: Rect2, col: Color) -> void:
	var c := r.get_center()
	var big := minf(r.size.x, r.size.y) * 0.5
	b.circle_ring(c, big * 0.95 - 0.5, big * 0.95 + 0.5, col, 40)
	var rr := big * 0.78
	var n := 24
	for i in n:
		var a0 := TAU * i / n
		var a1 := a0 + TAU / n * 0.5
		b.seg(c + Vector2(cos(a0), sin(a0)) * rr, c + Vector2(cos(a1), sin(a1)) * rr, 1.0, col)
	var rs := big * 0.72
	for k in 2:
		for j in 3:
			var a := -PI / 2.0 + TAU * j / 3.0 + PI * k
			var e := -PI / 2.0 + TAU * (j + 1) / 3.0 + PI * k
			b.seg(c + Vector2(cos(a), sin(a)) * rs, c + Vector2(cos(e), sin(e)) * rs, 1.0, col)

static func hexagon(c: Vector2, hw: float, hh: float) -> PackedVector2Array:
	return PackedVector2Array([c + Vector2(0, -hh), c + Vector2(hw, -hh * 0.5), c + Vector2(hw, hh * 0.5),
		c + Vector2(0, hh), c + Vector2(-hw, hh * 0.5), c + Vector2(-hw, -hh * 0.5)])

## Corta um polígono convexo pelo semiplano p·dir <= lim (Sutherland–Hodgman com um só plano).
static func clip_half(pts: PackedVector2Array, dir: Vector2, lim: float) -> PackedVector2Array:
	var out := PackedVector2Array()
	var n := pts.size()
	for i in n:
		var a := pts[i]
		var b := pts[(i + 1) % n]
		var da := a.dot(dir) - lim
		var db := b.dot(dir) - lim
		if da <= 0.0:
			out.append(a)
		if (da <= 0.0) != (db <= 0.0):
			out.append(a.lerp(b, da / (da - db)))
	return out
