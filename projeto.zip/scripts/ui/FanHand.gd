class_name FanHand
extends Container
## Mão em leque: as cartas ficam num arco suave e, quando não cabem lado a lado, sobrepõem-se.
## A carta debaixo do dedo (ou do rato) sobe e passa para a frente; ao largar, volta ao sítio.
## Só mexe na posição, na rotação e no z_index das cartas — a escala fica livre para as animações
## da batalha (compra, toque, viragem).
## 0.12.1: a carta escolhida (`selected`) fica levantada até ser jogada ou largada, e as cartas deslizam
## para o lugar novo em vez de saltarem (ao arrastar uma carta para mudar a ordem da mão).

@export var max_angle: float = 0.045     # rotação de cada carta por cada lugar a partir do centro (rad)
@export var arc_drop: float = 7.0        # px que descem as cartas das pontas
@export var lift: float = 30.0           # px que sobe a carta tocada
@export var gap: float = 10.0            # espaço entre cartas quando cabem sem sobrepor
@export var min_visible: float = 0.42    # fração mínima de cada carta que fica à vista
@export var group_gap: float = 24.0      # espaço extra antes de uma carta com a meta "fan_gap_before" (terrenos)

var _hovered: Control = null
var selected: Control = null   # 0.12.1: carta escolhida (sobe e passa para a frente)
var smooth: bool = true        # as cartas deslizam para o lugar (false: saltam, como antes)
var _targets: Dictionary = {}  # carta → posição para onde está a deslizar

## Escolhe a carta que fica levantada (null larga-a).
func set_selected(c: Control) -> void:
	if selected == c:
		return
	selected = c
	queue_sort()

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_PASS

func _notification(what: int) -> void:
	match what:
		NOTIFICATION_SORT_CHILDREN:
			_arrange()
		NOTIFICATION_MOUSE_EXIT:
			_check_hover_left()

func _cards() -> Array[Control]:
	var out: Array[Control] = []
	for c in get_children():
		var ctl := c as Control
		if ctl == null or not ctl.visible or ctl.top_level or ctl.is_queued_for_deletion():
			continue
		out.append(ctl)
	return out

func _card_size(cards: Array[Control]) -> Vector2:
	for c in cards:
		var s := c.get_combined_minimum_size()
		if s != Vector2.ZERO:
			return s
	return Vector2(130, 186)

func _get_minimum_size() -> Vector2:
	var cs := _card_size(_cards())
	return Vector2(0, cs.y)

func _arrange() -> void:
	var cards := _cards()
	var n := cards.size()
	if n == 0:
		_hovered = null
		return
	if _hovered != null and not (_hovered in cards):
		_hovered = null
	if selected != null and not (selected in cards):
		selected = null
	var cs := _card_size(cards)
	var extra := 0.0
	for c in cards:
		if bool(c.get_meta("fan_gap_before", false)) and c != cards[0]:
			extra += group_gap
	var step := cs.x + gap
	var overlap := false
	if n > 1 and step * (n - 1) + cs.x + extra > size.x:
		step = maxf(cs.x * min_visible, (size.x - cs.x - extra) / float(n - 1))
		overlap = true
	var total := step * (n - 1) + cs.x + extra
	var x0 := (size.x - total) / 2.0
	var mid := (n - 1) / 2.0
	var norm := maxf(1.0, mid * mid)
	var angle := max_angle if overlap else max_angle * 0.55
	var shift := 0.0
	for i in n:
		var c: Control = cards[i]
		if i > 0 and bool(c.get_meta("fan_gap_before", false)):
			shift += group_gap
		if not c.mouse_entered.is_connected(_on_card_entered):
			c.mouse_entered.connect(_on_card_entered.bind(c))
			c.mouse_exited.connect(_on_card_exited.bind(c))
		var d := float(i) - mid
		var y := arc_drop * (d * d) / norm
		var rot := d * angle
		var front := c == _hovered or c == selected
		if front:
			y -= lift
			rot = 0.0
		var target := Vector2(x0 + step * i + shift, y)
		c.size = cs
		if smooth and bool(c.get_meta("fan_placed", false)) and c.position.distance_to(target) > 0.5:
			_targets[c] = target
		else:
			_targets.erase(c)
			c.position = target
			c.set_meta("fan_placed", true)
		c.pivot_offset = cs / 2.0
		c.rotation = rot
		c.z_index = 25 if c == selected else (20 if front else 0)
	set_process(not _targets.is_empty())

func _process(delta: float) -> void:
	var k := 1.0 - exp(-delta * 18.0)
	for c in _targets.keys():
		if not is_instance_valid(c):
			_targets.erase(c)
			continue
		var ctl := c as Control
		if ctl == null or ctl.get_parent() != self:
			_targets.erase(c)
			continue
		var t: Vector2 = _targets[c]
		var p := ctl.position.lerp(t, k)
		if p.distance_to(t) < 0.6:
			p = t
			_targets.erase(c)
		ctl.position = p
	if _targets.is_empty():
		set_process(false)

func _on_card_entered(card: Control) -> void:
	if _hovered == card or not is_instance_valid(card):
		return
	_hovered = card
	queue_sort()

func _on_card_exited(card: Control) -> void:
	if card != _hovered:
		return
	# A carta subiu: se o dedo ainda está onde ela estava antes de subir, não desce (sem tremer).
	await get_tree().process_frame
	if not is_instance_valid(card) or card != _hovered:
		return
	var r := card.get_global_rect().grow_individual(0, 0, 0, lift + 4.0)
	if r.has_point(get_global_mouse_position()):
		return
	_hovered = null
	queue_sort()

func _check_hover_left() -> void:
	if _hovered == null:
		return
	await get_tree().process_frame
	if _hovered != null and is_instance_valid(_hovered):
		var r := _hovered.get_global_rect().grow_individual(0, 0, 0, lift + 4.0)
		if r.has_point(get_global_mouse_position()):
			return
	_hovered = null
	queue_sort()

## Larga a carta levantada (por exemplo, depois de a jogar).
func clear_hover() -> void:
	if _hovered != null:
		_hovered = null
		queue_sort()
