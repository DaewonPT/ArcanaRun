class_name SpinWheel
extends Control
## Roda do Tribunal dos Deuses: N setores com texto, gira e pára no resultado já sorteado (o
## resultado decide-se antes, com o RNG da run; a roda só o mostra). Fecha-se sozinha no fim.

signal finished(index: int)

const SECTOR_COLORS := [
	Color(0.52, 0.34, 0.82), Color(0.86, 0.56, 0.16), Color(0.24, 0.52, 0.74), Color(0.28, 0.27, 0.36),
	Color(0.74, 0.6, 0.2), Color(0.3, 0.6, 0.36), Color(0.62, 0.2, 0.26), Color(0.8, 0.8, 0.86),
]
const SPIN_TURNS := 5

var labels: Array[String] = []
var result: int = 0
var _disc: Disc
var _last_sector := -1
var _result_label: Label

## Roda desenhada em código: setores, divisórias e o texto de cada setor ao longo do raio.
class Disc extends Control:
	var labels: Array[String] = []

	func _draw() -> void:
		var n := maxi(1, labels.size())
		var c := size / 2.0
		var r := minf(size.x, size.y) / 2.0 - 4.0
		var step := TAU / n
		var font := get_theme_default_font()
		for i in n:
			var a0 := -PI / 2.0 + i * step
			var pts := PackedVector2Array([c])
			for k in 25:
				var a := a0 + step * k / 24.0
				pts.append(c + Vector2(cos(a), sin(a)) * r)
			var col: Color = SpinWheel.SECTOR_COLORS[i % SpinWheel.SECTOR_COLORS.size()]
			draw_colored_polygon(pts, col)
			draw_line(c, c + Vector2(cos(a0), sin(a0)) * r, Color(0.08, 0.06, 0.12), 3.0, true)
		draw_arc(c, r, 0.0, TAU, 96, Color(0.98, 0.75, 0.25), 6.0, true)
		draw_circle(c, r * 0.16, Color(0.13, 0.11, 0.19))
		draw_arc(c, r * 0.16, 0.0, TAU, 48, Color(0.98, 0.75, 0.25), 3.0, true)
		for i in n:
			var mid := -PI / 2.0 + (i + 0.5) * step
			var col: Color = SpinWheel.SECTOR_COLORS[i % SpinWheel.SECTOR_COLORS.size()]
			var text_col := Color(0.08, 0.08, 0.1) if col.get_luminance() > 0.5 else Color.WHITE
			# Na metade esquerda o texto roda mais meia volta para não ficar de pernas para o ar
			# (a rotação da própria roda conta: usa-se o ângulo no ecrã).
			var screen_angle := wrapf(mid + rotation, -PI, PI)
			if absf(screen_angle) > PI / 2.0:
				var w := font.get_string_size(labels[i], HORIZONTAL_ALIGNMENT_LEFT, -1, 19).x
				draw_set_transform(c, mid + PI, Vector2.ONE)
				draw_string(font, Vector2(-r * 0.22 - minf(w, r * 0.74), 7.0), labels[i], HORIZONTAL_ALIGNMENT_LEFT, r * 0.74, 19, text_col)
			else:
				draw_set_transform(c, mid, Vector2.ONE)
				draw_string(font, Vector2(r * 0.22, 7.0), labels[i], HORIZONTAL_ALIGNMENT_LEFT, r * 0.74, 19, text_col)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

## Ponteiro fixo no topo.
class Pointer extends Control:
	func _draw() -> void:
		var w := size.x
		draw_colored_polygon(PackedVector2Array([Vector2(w / 2.0 - 18, 0), Vector2(w / 2.0 + 18, 0), Vector2(w / 2.0, 34)]), Color(0.98, 0.75, 0.25))
		draw_polyline(PackedVector2Array([Vector2(w / 2.0 - 18, 0), Vector2(w / 2.0, 34), Vector2(w / 2.0 + 18, 0)]), Color(0.1, 0.08, 0.14), 3.0, true)

static func open(p_labels: Array[String], p_result: int) -> SpinWheel:
	var w := SpinWheel.new()
	w.labels = p_labels
	w.result = clampi(p_result, 0, maxi(0, p_labels.size() - 1))
	SceneRouter.show_overlay(w)
	w._build()
	return w

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(UiKit.dim(0.9))

func _build() -> void:
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(center)
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(vbox)
	var title := UiKit.label(tr("Os deuses giram a roda…"), 26, UiKit.GOLD)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(title)
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(500, 500)
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(holder)
	_disc = Disc.new()
	_disc.labels = labels
	_disc.set_anchors_preset(Control.PRESET_FULL_RECT)
	_disc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.add_child(_disc)
	var pointer := Pointer.new()
	pointer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pointer.set_anchors_preset(Control.PRESET_TOP_WIDE)
	pointer.offset_top = -8
	pointer.offset_bottom = 30
	holder.add_child(pointer)
	_result_label = UiKit.label(" ", 24, Color.WHITE)
	_result_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(_result_label)
	_spin()

func _spin() -> void:
	await get_tree().process_frame
	if not is_inside_tree():
		return
	_disc.pivot_offset = _disc.size / 2.0
	var step := TAU / maxi(1, labels.size())
	var target := TAU * SPIN_TURNS - (result + 0.5) * step
	var d := Settings.dur(3.2)
	if d > 0.0:
		var tw := create_tween()
		tw.tween_property(_disc, "rotation", target, d).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_QUART)
		await tw.finished
	else:
		_disc.rotation = target
	if not is_inside_tree():
		return
	Sfx.boom()
	Settings.vibrate(40)
	_result_label.text = tr("Os deuses decidiram: %s") % labels[result]
	await get_tree().create_timer(maxf(0.05, Settings.dur(1.1))).timeout
	finished.emit(result)
	queue_free()

func _process(_delta: float) -> void:
	# Um "tique" por setor que passa no ponteiro.
	if _disc == null or labels.is_empty():
		return
	_disc.queue_redraw()
	var step := TAU / labels.size()
	var sector := int(floor(_disc.rotation / step))
	if sector != _last_sector:
		_last_sector = sector
		Sfx.blip(sector % 8)
