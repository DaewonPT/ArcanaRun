class_name DustFx
extends Node2D
## 0.13.0: uma criatura que morre desfaz-se em pó — grãos da cor da carta soltam-se do retângulo dela,
## de cima para baixo, e voam para cima e para o lado a desvanecer (~0.9 s). Desenhado em código; nada
## com o movimento reduzido; metade dos grãos no modo de desempenho.

var _grains: Array = []
var _t := 0.0
var _dur := 1.0
var _rng := RandomNumberGenerator.new()

static func spawn(parent: Node, rect: Rect2, color: Color) -> void:
	if parent == null or not is_instance_valid(parent) or not parent.is_inside_tree() or not Settings.motion_ok():
		return
	var d := DustFx.new()
	parent.add_child(d)
	d.global_position = rect.position
	d.z_index = 40
	d._start(rect.size, color)

func _start(sz: Vector2, color: Color) -> void:
	_rng.randomize()
	var n := 40 if Settings.performance_mode else 90
	var speed := 1.0 / sqrt(clampf(Settings.anim_scale(), 0.3, 1.0))
	_dur = 1.0 / speed
	for i in n:
		var p := Vector2(_rng.randf() * sz.x, _rng.randf() * sz.y)
		var delay := (p.y / maxf(1.0, sz.y)) * 0.35 / speed + _rng.randf() * 0.08
		var col := color.lightened(_rng.randf_range(-0.15, 0.35))
		_grains.append({
			"p": p, "delay": delay, "life": _rng.randf_range(0.4, 0.62) / speed,
			"v": Vector2(_rng.randf_range(30.0, 130.0), _rng.randf_range(-110.0, -20.0)),
			"s": _rng.randf_range(2.0, 4.2), "c": col,
		})

func _process(delta: float) -> void:
	_t += delta
	queue_redraw()
	if _t >= _dur + 0.4:
		queue_free()

func _draw() -> void:
	for g in _grains:
		var t: float = _t - float(g["delay"])
		if t < 0.0:
			continue
		var life: float = g["life"]
		if t > life:
			continue
		var k := t / life
		var pos: Vector2 = (g["p"] as Vector2) + (g["v"] as Vector2) * t + Vector2(0, -30.0) * t * t
		var s: float = float(g["s"]) * (1.0 - 0.5 * k)
		var c: Color = g["c"]
		draw_rect(Rect2(pos - Vector2(s, s) * 0.5, Vector2(s, s)), Color(c, 0.9 * (1.0 - k)))
