class_name PlaqueDeco
extends Control
## 0.13.1 (visual "Grimório dourado"): o pormenor por cima do fundo de um botão do menu, por baixo do
## texto — luz de cima para baixo (degradê dentro dos cantos redondos), cantoneiras douradas no canto de
## cima à esquerda e no de baixo à direita e, no botão principal, um brilho que passa de vez em quando.
## Desenhado em código (nítido em qualquer ecrã). Sem movimento reduzido o brilho anda; com ele, não.

const GOLD := Color(0.97, 0.84, 0.5)

var radius := 14.0
var corners := true
var highlight := 0.07     # alfa da luz no topo (vai a 0 no fundo)
var sheen := false        # brilho a passar (botão principal)
var sheen_period := 4.2   # segundos por passagem (anda nos primeiros 55 %)
var _t := 0.0
var _acc := 0.0
var _was_on := false      # 0.14.0: o brilho estava a passar no último desenho

## Acrescenta o pormenor a um botão (fica atrás do conteúdo que já lá está).
static func attach(button: Control, p_radius: float = 14.0, p_corners: bool = true, p_sheen: bool = false, p_highlight: float = 0.07) -> PlaqueDeco:
	var d := PlaqueDeco.new()
	d.name = "PlaqueDeco"
	d.radius = p_radius
	d.corners = p_corners
	d.sheen = p_sheen
	d.highlight = p_highlight
	button.add_child(d)
	button.move_child(d, 0)
	return d

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)

func _ready() -> void:
	set_process(sheen and Settings.motion_ok())
	resized.connect(queue_redraw)

## 0.14.0: redesenha a ~30 fps e só enquanto o brilho está a passar (na pausa entre passagens não há nada
## a mudar; antes redesenhava a cada frame).
func _process(delta: float) -> void:
	_t += delta
	_acc += delta
	var on := sheen_on()
	if not on and not _was_on:
		return
	if _acc >= 1.0 / 30.0 or on != _was_on:
		_acc = 0.0
		_was_on = on
		queue_redraw()

## O brilho está a passar agora (nos primeiros 55 % de cada período).
func sheen_on() -> bool:
	return sheen and fmod(_t / sheen_period, 1.0) <= 0.55

func _draw() -> void:
	var w := size.x
	var h := size.y
	if w < 4.0 or h < 4.0:
		return
	# Luz de cima: alfa linear com a altura (exato em qualquer triangulação do polígono).
	if highlight > 0.0:
		var pts := _rounded_rect(Rect2(1, 1, w - 2, h - 2), maxf(radius - 1.0, 0.0))
		var cols := PackedColorArray()
		for p in pts:
			cols.append(Color(1, 1, 1, highlight * (1.0 - clampf(p.y / h, 0.0, 1.0))))
		draw_polygon(pts, cols)
	if corners:
		var c := Color(GOLD, 0.9)
		var k := 10.0
		var m := 5.0
		draw_polyline(PackedVector2Array([Vector2(m, m + k), Vector2(m, m), Vector2(m + k, m)]), c, 2.0, true)
		draw_polyline(PackedVector2Array([Vector2(w - m - k, h - m), Vector2(w - m, h - m), Vector2(w - m, h - m - k)]), c, 2.0, true)
	if sheen:
		var p := fmod(_t / sheen_period, 1.0) / 0.55
		if p <= 1.0:
			var bw := w * 0.28
			var cx := lerpf(-bw, w + bw, p)
			var sk := h * 0.35
			var mid := Vector2(cx, h * 0.5)
			var top := Vector2(cx + sk, 0.0)
			var bot := Vector2(cx - sk, h)
			var lft := Vector2(cx - bw * 0.5, h * 0.5)
			var rgt := Vector2(cx + bw * 0.5, h * 0.5)
			var on := Color(1.0, 0.98, 0.9, 0.38)
			var off := Color(1.0, 0.98, 0.9, 0.0)
			for tri in [[lft, top], [top, rgt], [rgt, bot], [bot, lft]]:
				draw_polygon(PackedVector2Array([mid, tri[0], tri[1]]), PackedColorArray([on, off, off]))

## Contorno de um retângulo de cantos redondos (sentido dos ponteiros, 6 pontos por canto).
static func _rounded_rect(r: Rect2, rad: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	rad = minf(rad, minf(r.size.x, r.size.y) * 0.5)
	var centers := [r.position + Vector2(r.size.x - rad, rad), r.position + Vector2(r.size.x - rad, r.size.y - rad),
		r.position + Vector2(rad, r.size.y - rad), r.position + Vector2(rad, rad)]
	var starts := [-PI / 2.0, 0.0, PI / 2.0, PI]
	for i in 4:
		for k in 7:
			var a: float = starts[i] + (PI / 2.0) * k / 6.0
			pts.append(centers[i] + Vector2(cos(a), sin(a)) * rad)
	return pts
