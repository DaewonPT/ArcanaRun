class_name BattleBackdrop
extends Control
## Fundo da batalha desenhado em código (sem imagens), por trás de toda a interface: degradê vertical
## escuro por ato (1 índigo→violeta, 2 verde-azulado→âmbar, 3 carmesim→púrpura, 4 quase preto→ouro,
## 5 vazio→ciano), duas ou três formas grandes e ténues para dar profundidade, vinheta e o clima planar
## por cima: meteor_rain (riscos a cair na diagonal), scorching_sands (areia a correr de lado),
## blood_moon (lua vermelha e faúlhas a subir), aether_tide (bolhas azuis a subir), mana_eclipse
## (eclipse com coroa e pontinhos), oil_rust (pingos de óleo a escorrer), guild_market (brilhos
## dourados), temporal_echo (anéis lentos a alargar); "" = sem clima. Tudo discreto, com alfa baixo.
## Partículas só CPUParticles2D (poucas). Sem movimento (Settings.motion_ok() falso) fica parado: só o
## que é estático (degradê, formas, vinheta, lua/eclipse). Ocupa o ecrã todo e não apanha toques.

const ACT_COLORS := {
	1: [Color(0.065, 0.06, 0.17), Color(0.15, 0.075, 0.2)],
	2: [Color(0.03, 0.105, 0.115), Color(0.15, 0.095, 0.045)],
	3: [Color(0.17, 0.045, 0.07), Color(0.11, 0.05, 0.16)],
	4: [Color(0.035, 0.035, 0.045), Color(0.16, 0.12, 0.045)],
	5: [Color(0.015, 0.015, 0.03), Color(0.03, 0.12, 0.15)],
}
const CLIMATES := ["meteor_rain", "scorching_sands", "blood_moon", "aether_tide", "mana_eclipse", "oil_rust", "guild_market", "temporal_echo"]

var _act: int = 1
var _climate: String = ""
var _motion := false        # partículas e animações ligadas (Settings.motion_ok())
var _fx_nodes: Array = []   # partículas e camada animada do clima
var _vignette: Vignette

## Vinheta por cima das partículas (cantos mais escuros).
class Vignette extends Control:
	func _draw() -> void:
		var c := size / 2.0
		var rings := [[0.5, 0.0], [0.85, 0.2], [1.12, 0.38], [1.6, 0.62]]
		var segs := 48
		var pts := PackedVector2Array()
		var cols := PackedColorArray()
		for r in rings:
			for i in segs:
				var a := TAU * i / segs
				pts.append(c + Vector2(cos(a) * size.x, sin(a) * size.y) * 0.5 * float(r[0]))
				cols.append(Color(0.0, 0.0, 0.02, float(r[1])))
		var idx := PackedInt32Array()
		for k in rings.size() - 1:
			for i in segs:
				var a := k * segs + i
				var b := k * segs + (i + 1) % segs
				idx.append_array(PackedInt32Array([a, b, a + segs, b, b + segs, a + segs]))
		RenderingServer.canvas_item_add_triangle_array(get_canvas_item(), idx, pts, cols)

## Camada animada desenhada em código: anéis do Eco Temporal, bolhas da Maré de Éter e brilhos do
## Mercado das Guildas.
class Fx extends Control:
	var kind := ""
	var t := 0.0
	var items: Array = []
	var rng := RandomNumberGenerator.new()

	func setup(p_kind: String) -> void:
		kind = p_kind
		rng.seed = 4242
		items.clear()
		var count := {"aether_tide": 16, "guild_market": 12}.get(kind, 0) as int
		for i in count:
			items.append(_new_item(true))

	func _new_item(anywhere: bool) -> Dictionary:
		var w := maxf(size.x, 1.0)
		var h := maxf(size.y, 1.0)
		if kind == "aether_tide":
			return {"x": rng.randf() * w, "y": rng.randf() * h if anywhere else h + 20.0, "r": rng.randf_range(3.0, 9.0), "v": rng.randf_range(14.0, 30.0), "ph": rng.randf() * TAU}
		return {"x": rng.randf() * w, "y": rng.randf() * h, "s": rng.randf_range(5.0, 10.0), "life": rng.randf_range(1.6, 2.8), "age": rng.randf() * 2.0 if anywhere else 0.0}

	func _process(delta: float) -> void:
		t += delta
		for i in items.size():
			var it: Dictionary = items[i]
			if kind == "aether_tide":
				it.y -= it.v * delta
				if it.y < -20.0:
					items[i] = _new_item(false)
			elif kind == "guild_market":
				it.age += delta
				if it.age >= it.life:
					items[i] = _new_item(false)
		queue_redraw()

	func _draw() -> void:
		match kind:
			"temporal_echo":
				var c := Vector2(size.x * 0.5, size.y * 0.42)
				var reach := size.length() * 0.62
				for k in 3:
					var f := fmod(t / 9.0 + k / 3.0, 1.0)
					var a := 0.18 * (1.0 - f) * clampf(f * 8.0, 0.0, 1.0)
					var r := 20.0 + reach * f
					var col := Color(0.75, 0.82, 1.0, a)
					draw_arc(c, r, 0.0, TAU, 96, col, 1.6, true)
					for i in 12:
						var ang := TAU * i / 12.0 + t * 0.05 * (1.0 if k % 2 == 0 else -1.0)
						var d := Vector2(cos(ang), sin(ang))
						draw_line(c + d * (r - 5.0), c + d * (r + 5.0), col, 1.4, true)
			"aether_tide":
				for it in items:
					var p := Vector2(it.x + sin(t * 1.3 + it.ph) * 6.0, it.y)
					var r: float = it.r
					draw_arc(p, r, 0.0, TAU, 20, Color(0.55, 0.85, 1.0, 0.28), 1.3, true)
					draw_circle(p + Vector2(-0.35, -0.35) * r, r * 0.22, Color(0.8, 0.95, 1.0, 0.3))
			"guild_market":
				for it in items:
					var k: float = clampf(it.age / it.life, 0.0, 1.0)
					var a := sin(PI * k)
					var s: float = it.s * (0.6 + 0.4 * a)
					var p := Vector2(it.x, it.y)
					var col := Color(1.0, 0.86, 0.45, 0.5 * a)
					var pts := PackedVector2Array()
					for j in 8:
						var ang := -PI / 2.0 + TAU * j / 8.0
						pts.append(p + Vector2(cos(ang), sin(ang)) * (s if j % 2 == 0 else s * 0.22))
					draw_colored_polygon(pts, col)

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_vignette = Vignette.new()
	_vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_vignette.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(_vignette)

func _ready() -> void:
	_motion = Settings.motion_ok()
	_rebuild_fx()

## Ato (1–5) e clima planar (id de climates.json, ou "" sem clima).
func setup(act: int, climate_id: String) -> void:
	_act = clampi(act, 1, 5)
	_climate = climate_id if climate_id in CLIMATES else ""
	_motion = Settings.motion_ok()
	_rebuild_fx()
	queue_redraw()

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED and is_node_ready():
		_rebuild_fx()

func _process(_delta: float) -> void:
	var ok := Settings.motion_ok()
	if ok != _motion:
		_motion = ok
		_rebuild_fx()

# --- Desenho estático ---

func _draw() -> void:
	var w := size.x
	var h := size.y
	if w < 2.0 or h < 2.0:
		return
	# 0.12.0: ilustração do clima ou do ato (se existir), escurecida para a mesa continuar a ler-se.
	var bg_tex := _art_texture()
	if bg_tex != null:
		var src := ArtLib.cover_region(bg_tex, Vector2(w, h), 0.5)
		draw_texture_rect_region(bg_tex, Rect2(0, 0, w, h), src)
		draw_rect(Rect2(0, 0, w, h), Color(0.03, 0.02, 0.06, 0.7 if Settings.high_contrast else 0.52))
		return
	var cols: Array = ACT_COLORS.get(_act, ACT_COLORS[1])
	var top: Color = cols[0]
	var bottom: Color = cols[1]
	draw_polygon(PackedVector2Array([Vector2.ZERO, Vector2(w, 0), Vector2(w, h), Vector2(0, h)]), PackedColorArray([top, top, bottom, bottom]))
	if not Settings.high_contrast:   # 0.12.0: no alto contraste o fundo fica liso e escuro
		_act_shapes(w, h, bottom)
	match _climate:
		"blood_moon":
			var c := Vector2(w * 0.8, h * 0.2)
			var r := h * 0.1
			_glow(c, Vector2(r, r) * 3.0, Color(0.85, 0.12, 0.1, 0.16), r)
			_disc_gradient(c, r, Color(0.5, 0.1, 0.1, 0.78), Color(0.26, 0.04, 0.06, 0.78))
			for spot in [[Vector2(-0.3, -0.2), 0.22], [Vector2(0.25, 0.15), 0.16], [Vector2(-0.05, 0.42), 0.12]]:
				draw_circle(c + spot[0] * r, r * spot[1], Color(0.18, 0.02, 0.04, 0.35))
			draw_arc(c, r, -PI * 0.85, -PI * 0.15, 40, Color(1.0, 0.45, 0.4, 0.3), 1.5, true)
		"mana_eclipse":
			var c := Vector2(w * 0.24, h * 0.22)
			var r := h * 0.095
			_glow(c, Vector2(r, r) * 2.6, Color(0.62, 0.45, 1.0, 0.16), r)
			draw_circle(c, r, Color(0.01, 0.005, 0.02, 0.8))
			draw_arc(c, r, 0.0, TAU, 64, Color(0.75, 0.6, 1.0, 0.3), 1.6, true)
			draw_arc(c, r + 3.0, -PI * 0.7, PI * 0.05, 40, Color(0.85, 0.75, 1.0, 0.2), 2.0, true)
		"oil_rust":
			# mancha de óleo a escorrer do topo (é dela que caem os pingos)
			var pts := PackedVector2Array([Vector2(0, 0), Vector2(w, 0)])
			var n := 24
			for i in range(n, -1, -1):
				var x := w * i / n
				var y := 10.0 + 7.0 * sin(x * 0.021) + 5.0 * sin(x * 0.057 + 1.3)
				pts.append(Vector2(x, y))
			draw_colored_polygon(pts, Color(0.03, 0.022, 0.015, 0.55))
			var edge := PackedVector2Array()
			for i in range(2, pts.size()):
				edge.append(pts[i])
			draw_polyline(edge, Color(0.45, 0.25, 0.1, 0.22), 1.5, true)
			for x in [0.12, 0.31, 0.47, 0.66, 0.83]:
				var px: float = w * x
				var y0 := 10.0 + 7.0 * sin(px * 0.021) + 5.0 * sin(px * 0.057 + 1.3)
				draw_colored_polygon(PackedVector2Array([Vector2(px - 4.0, y0 - 2.0), Vector2(px + 4.0, y0 - 2.0), Vector2(px, y0 + 14.0)]), Color(0.03, 0.022, 0.015, 0.55))
				draw_circle(Vector2(px, y0 + 13.0), 3.0, Color(0.03, 0.022, 0.015, 0.55))

## Imagem de fundo opcional: a do clima ("clim_<id>") tem prioridade sobre a do ato ("act_1"…"act_4", "act_E").
func _art_texture() -> Texture2D:
	if _climate != "":
		var t := ArtLib.texture("background", "clim_" + _climate)
		if t != null:
			return t
	return ArtLib.texture("background", "act_E" if _act >= 5 else "act_%d" % _act)

## Formas grandes e ténues, diferentes em cada ato.
func _act_shapes(w: float, h: float, bottom: Color) -> void:
	match _act:
		1:
			_glow(Vector2(w * 0.2, h * 0.18), Vector2(w * 0.42, h * 0.55), Color(0.45, 0.3, 0.85, 0.1))
			_glow(Vector2(w * 0.85, h * 0.9), Vector2(w * 0.4, h * 0.5), Color(0.25, 0.25, 0.75, 0.09))
			_arcane_ring(Vector2(w * 0.82, h * 0.36), h * 0.5, Color(0.7, 0.6, 1.0, 0.05))
		2:
			_glow(Vector2(w * 0.5, h * 1.02), Vector2(w * 0.55, h * 0.45), Color(0.95, 0.6, 0.22, 0.13))
			_glow(Vector2(w * 0.12, h * 0.08), Vector2(w * 0.35, h * 0.45), Color(0.2, 0.6, 0.6, 0.08))
			_ridge(w, h, h * 0.8, h * 0.05, Color(bottom.lightened(0.12), 0.35), 3, false)
			_ridge(w, h, h * 0.88, h * 0.04, Color(bottom.darkened(0.35), 0.55), 7, false)
		3:
			_glow(Vector2(w * 0.5, -h * 0.05), Vector2(w * 0.6, h * 0.5), Color(0.9, 0.15, 0.2, 0.1))
			_glow(Vector2(w * 0.1, h * 0.95), Vector2(w * 0.35, h * 0.45), Color(0.5, 0.2, 0.75, 0.08))
			_ridge(w, h, h * 0.76, h * 0.1, Color(bottom.lightened(0.1), 0.3), 11, true)
			_ridge(w, h, h * 0.86, h * 0.08, Color(bottom.darkened(0.4), 0.55), 5, true)
		4:
			_glow(Vector2(w * 0.5, h * 1.05), Vector2(w * 0.6, h * 0.6), Color(1.0, 0.75, 0.3, 0.12))
			for i in 6:
				var x := w * (0.08 + 0.168 * i)
				_pillar(Vector2(x, h * 0.12), Vector2(w * 0.045, h * 0.8), Color(1.0, 0.82, 0.45, 0.035), Color(0.0, 0.0, 0.0, 0.18))
		5:
			_glow(Vector2(w * 0.5, h * 1.0), Vector2(w * 0.6, h * 0.55), Color(0.2, 0.85, 1.0, 0.1))
			_arcane_ring(Vector2(w * 0.5, h * 0.42), h * 0.62, Color(0.4, 0.9, 1.0, 0.045))
			var rng := RandomNumberGenerator.new()
			rng.seed = 555
			for i in 60:
				var p := Vector2(rng.randf() * w, rng.randf() * h * 0.75)
				draw_circle(p, rng.randf_range(0.6, 1.4), Color(0.75, 0.95, 1.0, rng.randf_range(0.08, 0.3)))

## Anel arcano gigante e quase invisível (dois anéis com marcas entre eles).
func _arcane_ring(c: Vector2, r: float, col: Color) -> void:
	draw_arc(c, r, 0.0, TAU, 128, col, 2.0, true)
	draw_arc(c, r * 0.9, 0.0, TAU, 128, col, 1.2, true)
	draw_arc(c, r * 0.55, 0.0, TAU, 96, col, 1.2, true)
	for i in 36:
		var a := TAU * i / 36.0
		var d := Vector2(cos(a), sin(a))
		draw_line(c + d * r * 0.91, c + d * r * (0.99 if i % 3 == 0 else 0.95), col, 1.2, true)
	var pts := PackedVector2Array()
	for i in 7:
		var a := -PI / 2.0 + TAU * (i * 3 % 7) / 7.0
		pts.append(c + Vector2(cos(a), sin(a)) * r * 0.9)
	pts.append(pts[0])
	draw_polyline(pts, Color(col, col.a * 0.7), 1.2, true)

## Cordilheira (montanhas agudas ou dunas suaves) com a base no fundo do ecrã.
func _ridge(w: float, h: float, base_y: float, amp: float, col: Color, seed_value: int, jagged: bool) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value
	var pts := PackedVector2Array([Vector2(w + 2.0, h + 2.0), Vector2(-2.0, h + 2.0)])
	var n := 14 if jagged else 40
	var ph := rng.randf() * TAU
	for i in n + 1:
		var x := -2.0 + (w + 4.0) * i / n
		var y := base_y
		if jagged:
			y -= amp * (0.35 + 0.65 * rng.randf()) * (1.0 if i % 2 == 0 else 0.45)
		else:
			y -= amp * (0.6 * sin(x / w * TAU * 1.3 + ph) + 0.4 * sin(x / w * TAU * 3.1 + ph * 2.0))
		pts.append(Vector2(x, y))
	draw_colored_polygon(pts, col)

## Coluna (fuste, capitel e base) ténue.
func _pillar(pos: Vector2, sz: Vector2, col: Color, shade: Color) -> void:
	var r := Rect2(pos + Vector2(-sz.x * 0.5, 0), sz)
	draw_rect(r, col)
	draw_rect(Rect2(r.position + Vector2(r.size.x * 0.62, 0), Vector2(r.size.x * 0.38, r.size.y)), shade)
	draw_rect(Rect2(r.position + Vector2(-sz.x * 0.2, -sz.x * 0.35), Vector2(sz.x * 1.4, sz.x * 0.35)), col)
	draw_rect(Rect2(r.position + Vector2(-sz.x * 0.2, r.size.y), Vector2(sz.x * 1.4, sz.x * 0.35)), col)

## Brilho elíptico (cor no centro, ou num disco de raio core, a desvanecer até ao bordo).
func _glow(c: Vector2, radii: Vector2, col: Color, core: float = 0.0) -> void:
	var segs := 48
	var pts := PackedVector2Array([c])
	var cols := PackedColorArray([col])
	var idx := PackedInt32Array()
	var inner := core / maxf(1.0, radii.x)
	for i in segs:
		var d := Vector2(cos(TAU * i / segs), sin(TAU * i / segs))
		pts.append(c + d * radii * inner)
		cols.append(col)
		pts.append(c + d * radii)
		cols.append(Color(col, 0.0))
	for i in segs:
		var a := 1 + i * 2
		var b := 1 + ((i + 1) % segs) * 2
		idx.append_array(PackedInt32Array([0, a, b, a, a + 1, b + 1, a, b + 1, b]))
	RenderingServer.canvas_item_add_triangle_array(get_canvas_item(), idx, pts, cols)

## Disco com degradê vertical (claro em cima).
func _disc_gradient(c: Vector2, r: float, top: Color, bottom: Color) -> void:
	var pts := PackedVector2Array()
	var cols := PackedColorArray()
	for i in 48:
		var p := c + Vector2(cos(TAU * i / 48.0), sin(TAU * i / 48.0)) * r
		pts.append(p)
		cols.append(top.lerp(bottom, (p.y - (c.y - r)) / (2.0 * r)))
	draw_polygon(pts, cols)
	draw_arc(c, r, 0.0, TAU, 48, top.lerp(bottom, 0.5), 1.0, true)

# --- Clima animado (partículas e camada Fx) ---

func _rebuild_fx() -> void:
	for n in _fx_nodes:
		if is_instance_valid(n):
			remove_child(n)
			n.queue_free()
	_fx_nodes.clear()
	var w := size.x
	var h := size.y
	if not _motion or _climate == "" or w < 2.0 or h < 2.0:
		return
	match _climate:
		"meteor_rain":
			var p := _emitter(14, 1.7)
			p.position = Vector2(w * 0.62, -30.0)
			p.emission_rect_extents = Vector2(w * 0.62, 4.0)
			p.direction = Vector2(-0.42, 1.0).normalized()
			p.spread = 3.0
			p.initial_velocity_min = 380.0
			p.initial_velocity_max = 560.0
			_streaks(p, 0.055)
			p.scale_amount_min = 28.0
			p.scale_amount_max = 52.0
			p.color_ramp = _ramp([[0.0, Color(1.0, 0.85, 0.6, 0.0)], [0.12, Color(1.0, 0.82, 0.58, 0.42)], [0.7, Color(1.0, 0.58, 0.32, 0.3)], [1.0, Color(1.0, 0.45, 0.25, 0.0)]])
			var e := _emitter(16, 2.4)
			e.position = Vector2(w * 0.5, h * 0.5)
			e.emission_rect_extents = Vector2(w * 0.5, h * 0.5)
			e.direction = Vector2(-0.42, 1.0).normalized()
			e.spread = 10.0
			e.initial_velocity_min = 20.0
			e.initial_velocity_max = 45.0
			e.scale_amount_min = 1.2
			e.scale_amount_max = 2.2
			e.color_ramp = _ramp([[0.0, Color(1.0, 0.6, 0.3, 0.0)], [0.3, Color(1.0, 0.62, 0.32, 0.42)], [1.0, Color(1.0, 0.4, 0.2, 0.0)]])
		"scorching_sands":
			var p := _emitter(36, 5.0)
			p.position = Vector2(w * 0.5, h * 0.5)
			p.emission_rect_extents = Vector2(w * 0.55, h * 0.5)
			p.direction = Vector2(1.0, 0.06)
			p.spread = 8.0
			p.initial_velocity_min = 45.0
			p.initial_velocity_max = 95.0
			p.gravity = Vector2(0.0, 5.0)
			p.angle_max = 90.0
			p.angular_velocity_min = -120.0
			p.angular_velocity_max = 120.0
			p.scale_amount_min = 1.6
			p.scale_amount_max = 3.2
			p.color_ramp = _ramp([[0.0, Color(0.95, 0.78, 0.5, 0.0)], [0.25, Color(0.97, 0.8, 0.52, 0.42)], [0.75, Color(0.95, 0.72, 0.45, 0.32)], [1.0, Color(0.95, 0.72, 0.45, 0.0)]])
			var s := _emitter(10, 3.0)
			s.position = Vector2(w * 0.5, h * 0.5)
			s.emission_rect_extents = Vector2(w * 0.6, h * 0.48)
			s.direction = Vector2(1.0, 0.0)
			s.spread = 2.0
			s.initial_velocity_min = 110.0
			s.initial_velocity_max = 170.0
			_streaks(s, 0.025)
			s.scale_amount_min = 40.0
			s.scale_amount_max = 90.0
			s.color_ramp = _ramp([[0.0, Color(1.0, 0.85, 0.6, 0.0)], [0.5, Color(1.0, 0.85, 0.6, 0.11)], [1.0, Color(1.0, 0.85, 0.6, 0.0)]])
		"blood_moon":
			var p := _emitter(28, 6.0)
			p.position = Vector2(w * 0.5, h * 0.8)
			p.emission_rect_extents = Vector2(w * 0.55, h * 0.3)
			p.direction = Vector2(0.0, -1.0)
			p.spread = 18.0
			p.initial_velocity_min = 12.0
			p.initial_velocity_max = 32.0
			p.gravity = Vector2(0.0, -4.0)
			p.angle_max = 90.0
			p.scale_amount_min = 1.8
			p.scale_amount_max = 3.6
			p.color_ramp = _ramp([[0.0, Color(1.0, 0.3, 0.22, 0.0)], [0.3, Color(1.0, 0.32, 0.24, 0.5)], [1.0, Color(0.8, 0.1, 0.12, 0.0)]])
		"aether_tide":
			_add_fx("aether_tide")
			var p := _emitter(20, 6.0)
			p.position = Vector2(w * 0.5, h * 0.75)
			p.emission_rect_extents = Vector2(w * 0.55, h * 0.35)
			p.direction = Vector2(0.0, -1.0)
			p.spread = 10.0
			p.initial_velocity_min = 18.0
			p.initial_velocity_max = 40.0
			p.scale_amount_min = 1.2
			p.scale_amount_max = 2.2
			p.color_ramp = _ramp([[0.0, Color(0.5, 0.85, 1.0, 0.0)], [0.3, Color(0.55, 0.88, 1.0, 0.4)], [1.0, Color(0.5, 0.85, 1.0, 0.0)]])
		"mana_eclipse":
			var p := _emitter(30, 4.0)
			p.position = Vector2(w * 0.5, h * 0.5)
			p.emission_rect_extents = Vector2(w * 0.5, h * 0.5)
			p.direction = Vector2(0.3, -1.0)
			p.spread = 40.0
			p.initial_velocity_min = 4.0
			p.initial_velocity_max = 12.0
			p.angle_max = 90.0
			p.scale_amount_min = 1.2
			p.scale_amount_max = 2.6
			p.color_initial_ramp = _ramp([[0.0, Color(0.7, 0.55, 1.0)], [1.0, Color(0.5, 0.85, 1.0)]])
			p.color_ramp = _ramp([[0.0, Color(1, 1, 1, 0.0)], [0.25, Color(1, 1, 1, 0.5)], [0.45, Color(1, 1, 1, 0.1)], [0.7, Color(1, 1, 1, 0.42)], [1.0, Color(1, 1, 1, 0.0)]])
		"oil_rust":
			var p := _emitter(12, 6.5)
			p.position = Vector2(w * 0.5, 16.0)
			p.emission_rect_extents = Vector2(w * 0.5, 4.0)
			p.direction = Vector2(0.0, 1.0)
			p.spread = 0.0
			p.initial_velocity_min = 4.0
			p.initial_velocity_max = 12.0
			p.gravity = Vector2(0.0, 22.0)
			p.particle_flag_align_y = true
			p.split_scale = true
			p.scale_curve_x = _curve([[0.0, 0.32], [1.0, 0.18]])
			p.scale_curve_y = _curve([[0.0, 0.3], [0.6, 0.85], [1.0, 1.0]])
			p.scale_amount_min = 12.0
			p.scale_amount_max = 22.0
			p.color_initial_ramp = _ramp([[0.0, Color(0.42, 0.22, 0.09)], [1.0, Color(0.22, 0.27, 0.3)]])
			p.color_ramp = _ramp([[0.0, Color(1, 1, 1, 0.0)], [0.1, Color(1, 1, 1, 0.75)], [0.8, Color(1, 1, 1, 0.55)], [1.0, Color(1, 1, 1, 0.0)]])
		"guild_market":
			_add_fx("guild_market")
			var p := _emitter(24, 3.5)
			p.position = Vector2(w * 0.5, h * 0.5)
			p.emission_rect_extents = Vector2(w * 0.5, h * 0.5)
			p.direction = Vector2(0.0, -1.0)
			p.spread = 30.0
			p.initial_velocity_min = 5.0
			p.initial_velocity_max = 16.0
			p.angle_min = 45.0
			p.angle_max = 45.0
			p.scale_amount_min = 1.5
			p.scale_amount_max = 3.0
			p.color_ramp = _ramp([[0.0, Color(1.0, 0.82, 0.35, 0.0)], [0.2, Color(1.0, 0.86, 0.45, 0.6)], [0.4, Color(1.0, 0.82, 0.35, 0.15)], [0.65, Color(1.0, 0.86, 0.45, 0.5)], [1.0, Color(1.0, 0.82, 0.35, 0.0)]])
		"temporal_echo":
			_add_fx("temporal_echo")
	move_child(_vignette, get_child_count() - 1)

func _emitter(amount: int, lifetime: float) -> CPUParticles2D:
	var p := CPUParticles2D.new()
	p.amount = maxi(1, amount / 2) if Settings.performance_mode else amount   # 0.12.0: modo de desempenho
	p.lifetime = lifetime
	p.preprocess = lifetime
	p.local_coords = true
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.gravity = Vector2.ZERO
	add_child(p)
	_fx_nodes.append(p)
	return p

## Partículas esticadas na direção do movimento (riscos): largura = escala × wx.
func _streaks(p: CPUParticles2D, wx: float) -> void:
	p.particle_flag_align_y = true
	p.split_scale = true
	p.scale_curve_x = _curve([[0.0, wx], [1.0, wx]])
	p.scale_curve_y = _curve([[0.0, 1.0], [1.0, 1.0]])

func _add_fx(kind: String) -> void:
	var fx := Fx.new()
	fx.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fx.position = Vector2.ZERO
	fx.size = size
	add_child(fx)
	fx.setup(kind)
	_fx_nodes.append(fx)

func _ramp(stops: Array) -> Gradient:
	var g := Gradient.new()
	var offs := PackedFloat32Array()
	var cols := PackedColorArray()
	for s in stops:
		offs.append(float(s[0]))
		cols.append(s[1])
	g.offsets = offs
	g.colors = cols
	return g

func _curve(points: Array) -> Curve:
	var c := Curve.new()
	for pt in points:
		c.add_point(Vector2(float(pt[0]), float(pt[1])))
	return c
