class_name ShaderWarmup
extends Control
## 0.16.0 (78): o Godot só prepara um shader da primeira vez que o desenha, e no telemóvel isso é um soluço a
## meio do jogo (as chamas do ataque, o brilho holográfico, a carta em grande, o fundo desfocado das janelas).
## No menu, uma vez por sessão (1 s depois de abrir, quando a entrada do menu já acabou), desenha cada um num
## quadrado de 2 px por trás do fundo durante 3 frames e sai.

const SHADERS := [
	"res://assets/shaders/fire.gdshader",
	"res://assets/shaders/foil.gdshader",
	"res://assets/shaders/card_sheen.gdshader",
	"res://assets/shaders/blur_dim.gdshader",
	"res://assets/shaders/title_gold.gdshader",
	"res://assets/shaders/back_shimmer.gdshader",   # 0.16.1 (V9)
]
const FRAMES := 3
const DELAY := 1.0

static var done := false

## Põe o aquecimento no menu (só a primeira vez na sessão; nos testes sem ecrã não faz nada).
static func run(host: Node) -> ShaderWarmup:
	if done or DisplayServer.get_name() == "headless":
		return null
	done = true
	var w := ShaderWarmup.new()
	w.name = "ShaderWarmup"
	host.add_child(w)
	host.move_child(w, 0)
	return w

var _frames := -1

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	z_index = -100   # por trás de tudo: desenha-se (e o shader fica pronto), mas o fundo tapa-o
	position = Vector2(4, 4)
	size = Vector2(2, 2)
	set_process(false)
	# Ligado ao sinal (e não com await): se o menu fechar antes, a ligação cai com o nó.
	get_tree().create_timer(DELAY).timeout.connect(_start)

func _start() -> void:
	for p in SHADERS:
		var sh := load(p) as Shader
		if sh == null:
			continue
		var mat := ShaderMaterial.new()
		mat.shader = sh
		var r := ColorRect.new()
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		r.size = Vector2(2, 2)
		r.color = Color(0, 0, 0, 0.01)
		r.material = mat
		add_child(r)
	_frames = 0
	set_process(true)

func _process(_delta: float) -> void:
	_frames += 1
	if _frames >= FRAMES:
		set_process(false)
		queue_free()
