class_name SparkFx
extends Node2D
## 0.13.0: faíscas quando uma criatura bloqueia o contra-ataque (golpe de metal): um clarão branco curto e
## uma dúzia de faúlhas amarelas a saltar em leque, com gravidade. Desenhadas em código, mistura aditiva,
## ~0.45 s; nada com o movimento reduzido.

static var _additive: CanvasItemMaterial

var _parts: Array = []
var _t := 0.0
var _dur := 0.45
var _rng := RandomNumberGenerator.new()

static func spawn(parent: Node, global_pos: Vector2) -> void:
	if parent == null or not is_instance_valid(parent) or not parent.is_inside_tree() or not Settings.motion_ok():
		return
	var s := SparkFx.new()
	parent.add_child(s)
	s.global_position = global_pos
	s.z_index = 40
	s._start()

func _start() -> void:
	_rng.randomize()
	if _additive == null:
		_additive = CanvasItemMaterial.new()
		_additive.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	material = _additive
	var n := 8 if Settings.performance_mode else 16
	for i in n:
		var a := -PI / 2.0 + _rng.randf_range(-1.3, 1.3)
		var v := Vector2(cos(a), sin(a)) * _rng.randf_range(160.0, 380.0)
		_parts.append({"p": Vector2.ZERO, "v": v, "life": _rng.randf_range(0.25, 0.45), "w": _rng.randf_range(1.6, 2.8)})

func _process(delta: float) -> void:
	_t += delta
	for p in _parts:
		p["v"] = (p["v"] as Vector2) + Vector2(0, 900.0) * delta
		p["p"] = (p["p"] as Vector2) + (p["v"] as Vector2) * delta
	queue_redraw()
	if _t >= _dur:
		queue_free()

func _draw() -> void:
	var k := clampf(_t / 0.12, 0.0, 1.0)
	if k < 1.0:
		draw_circle(Vector2.ZERO, 26.0 * (0.5 + k), Color(1, 1, 0.9, 0.55 * (1.0 - k)))
	for p in _parts:
		var life: float = p["life"]
		if _t > life:
			continue
		var a := 1.0 - _t / life
		var pos: Vector2 = p["p"]
		var tail: Vector2 = pos - (p["v"] as Vector2).normalized() * 9.0
		draw_line(tail, pos, Color(1.0, 0.85, 0.35, a), float(p["w"]), true)
