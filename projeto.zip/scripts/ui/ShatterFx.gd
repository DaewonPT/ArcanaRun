class_name ShatterFx
extends Control
## 0.16.0: uma imagem parte-se em cacos que caem em câmara lenta.
##   57 — o retrato do boss vencido (com a luz da cor do baralho por trás);
##   58 — a criatura que morre (visual «Arte em destaque»: estala e desfaz-se em cacos, em vez do pó).
## A imagem é uma textura (a ilustração) ou a própria carta, desenhada uma vez numa SubViewport. Os cacos são
## triângulos de uma grelha com os vértices mexidos e desenham-se todos num só comando por frame
## (canvas_item_add_triangle_array). Sem animações ou com movimento reduzido não aparece.

var duration := 0.6
var gravity := 900.0
var light := Color(0, 0, 0, 0)        # luz por trás (57); transparente = sem luz
var _tex: Texture2D
var _vp: SubViewport                   # quando a imagem é uma carta (fica viva até ao fim)
var _rect := Rect2()                   # onde a imagem estava (coordenadas deste nó)
var _shards: Array = []                # [pontos (3), uvs (3), centro, velocidade, rotação, velocidade angular]
var _t := 0.0
var _round := false                    # 57: só os cacos dentro do círculo do retrato

## Parte uma textura que está desenhada em `rect` (coordenadas globais).
static func from_texture(host: Node, tex: Texture2D, rect: Rect2, p_light: Color = Color(0, 0, 0, 0), round_mask: bool = false, grid: int = 4) -> ShatterFx:
	if tex == null or not Settings.motion_ok() or Settings.anim_scale() <= 0.0:
		return null
	var fx := ShatterFx.new()
	fx._tex = tex
	fx.light = p_light
	fx._round = round_mask
	host.add_child(fx)
	fx._setup(rect, grid)
	return fx

## Parte um controlo (uma carta): desenha-o uma vez numa SubViewport e usa essa imagem.
static func from_control(host: Node, make: Callable, rect: Rect2, grid: int = 3) -> ShatterFx:
	if not Settings.motion_ok() or Settings.anim_scale() <= 0.0 or rect.size.x < 4.0:
		return null
	var fx := ShatterFx.new()
	host.add_child(fx)
	var vp := SubViewport.new()
	vp.transparent_bg = true
	vp.size = Vector2i(rect.size.ceil())
	vp.render_target_update_mode = SubViewport.UPDATE_ONCE
	vp.disable_3d = true
	fx.add_child(vp)
	var ctl: Control = make.call()
	vp.add_child(ctl)
	ctl.position = Vector2.ZERO
	ctl.size = rect.size
	fx._vp = vp
	fx._tex = vp.get_texture()
	fx._setup(rect, grid)
	fx.visible = false
	fx.set_process(false)
	await RenderingServer.frame_post_draw
	if is_instance_valid(fx):
		fx.visible = true
		fx.set_process(true)
	return fx

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	top_level = true
	z_index = 40

func _setup(rect: Rect2, grid: int) -> void:
	global_position = Vector2.ZERO
	size = get_viewport_rect().size
	_rect = rect
	duration = maxf(0.4, Settings.dur(duration))   # câmara lenta: nunca muito rápido, mesmo na velocidade 2×
	var cols := grid
	var rows := maxi(2, int(round(grid * rect.size.y / maxf(1.0, rect.size.x))))
	var pts := []
	for j in rows + 1:
		var row := []
		for i in cols + 1:
			var p := Vector2(float(i) / cols, float(j) / rows)
			if i > 0 and i < cols:
				p.x += randf_range(-0.32, 0.32) / cols
			if j > 0 and j < rows:
				p.y += randf_range(-0.32, 0.32) / rows
			row.append(p)
		pts.append(row)
	var center := rect.get_center()
	for j in rows:
		for i in cols:
			var a: Vector2 = pts[j][i]
			var b: Vector2 = pts[j][i + 1]
			var c: Vector2 = pts[j + 1][i + 1]
			var d: Vector2 = pts[j + 1][i]
			var tris := [[a, b, c], [a, c, d]] if (i + j) % 2 == 0 else [[a, b, d], [b, c, d]]
			for tri in tris:
				var uv := PackedVector2Array(tri)
				var p3 := PackedVector2Array()
				var cen := Vector2.ZERO
				for q in tri:
					var g := rect.position + (q as Vector2) * rect.size
					p3.append(g)
					cen += g
				cen /= 3.0
				if _round and cen.distance_to(center) > minf(rect.size.x, rect.size.y) * 0.52:
					continue
				var out := (cen - center)
				var dirv := out.normalized() if out.length() > 1.0 else Vector2.UP
				var vel := dirv * randf_range(60.0, 190.0) + Vector2(randf_range(-30, 30), randf_range(-160, -40))
				_shards.append([p3, uv, cen, vel, 0.0, randf_range(-3.0, 3.0)])

func _process(delta: float) -> void:
	_t += delta
	if _t >= duration:
		queue_free()
		return
	queue_redraw()

func _draw() -> void:
	if _tex == null:
		return
	var k := clampf(_t / maxf(0.01, duration), 0.0, 1.0)
	var slow := k * k * 0.6 + k * 0.4     # câmara lenta no início
	var tsec := slow * duration
	if light.a > 0.0:
		var lr := minf(_rect.size.x, _rect.size.y) * (0.55 + 0.6 * k)
		draw_circle(_rect.get_center(), lr, Color(light, light.a * (1.0 - k) * 0.55))
		draw_circle(_rect.get_center(), lr * 0.6, Color(light.lightened(0.4), light.a * (1.0 - k) * 0.5))
	var alpha := 1.0 - smoothstep(0.55, 1.0, k)
	var all_pts := PackedVector2Array()
	var all_uv := PackedVector2Array()
	var all_col := PackedColorArray()
	var idx := PackedInt32Array()
	var col := Color(1, 1, 1, alpha)
	for s in _shards:
		var cen: Vector2 = s[2]
		var vel: Vector2 = s[3]
		var off := vel * tsec + Vector2(0, 0.5 * gravity * tsec * tsec)
		var rot: float = float(s[5]) * tsec
		var p3: PackedVector2Array = s[0]
		var uv: PackedVector2Array = s[1]
		var base := all_pts.size()
		for q in 3:
			var p := (p3[q] - cen).rotated(rot) + cen + off
			all_pts.append(p)
			all_uv.append(uv[q])
			all_col.append(col)
		idx.append_array(PackedInt32Array([base, base + 1, base + 2]))
	if not idx.is_empty():
		RenderingServer.canvas_item_add_triangle_array(get_canvas_item(), idx, all_pts, all_col, all_uv, PackedInt32Array(), PackedFloat32Array(), _tex.get_rid())
