class_name GoldChart
extends Control
## 0.19.0 (72): o ouro de cada ante no fim da run — para cima o que entrou (batalhas e eventos a dourado, juros a
## verde, vendas a azul), para baixo o que saiu (vermelho). Cada barra com o total por cima / por baixo.

const C_IN := Color(0.98, 0.78, 0.3)
const C_INTEREST := Color(0.45, 0.9, 0.55)
const C_SOLD := Color(0.45, 0.72, 1.0)
const C_OUT := Color(1.0, 0.45, 0.42)

var rows: Array = []   # Economy.gold_rows(): [{"ante", "in", "out", "interest", "sold"}]

func _init() -> void:
	custom_minimum_size = Vector2(320, 150)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func set_rows(r: Array) -> void:
	rows = r
	queue_redraw()

func _draw() -> void:
	var font := get_theme_default_font()
	var n := rows.size()
	if n == 0:
		draw_string(font, Vector2(0, size.y / 2.0), TranslationServer.translate("Sem ouro registado."), HORIZONTAL_ALIGNMENT_LEFT, size.x, 16, Color(0.7, 0.7, 0.8))
		return
	var top := 16.0
	var bottom := size.y - 30.0
	var mid := top + (bottom - top) * 0.6
	var up_h := mid - top
	var down_h := bottom - mid
	var max_v := 1.0
	for r in rows:
		max_v = maxf(max_v, maxf(float(r["in"]), float(r["out"])))
	var slot := size.x / float(n)
	var bw := minf(30.0, slot * 0.6)
	draw_line(Vector2(0, mid), Vector2(size.x, mid), Color(1, 1, 1, 0.25), 1.0)
	for i in n:
		var r: Dictionary = rows[i]
		var x := slot * i + (slot - bw) / 2.0
		var vin := float(r["in"])
		var interest := float(r["interest"])
		var sold := float(r["sold"])
		var rest := maxf(0.0, vin - interest - sold)
		var y := mid
		for part in [[rest, C_IN], [interest, C_INTEREST], [sold, C_SOLD]]:
			var h := up_h * float(part[0]) / max_v
			if h > 0.0:
				draw_rect(Rect2(Vector2(x, y - h), Vector2(bw, h)), part[1])
				y -= h
		if vin > 0.0:
			_label(font, "+%d" % int(vin), x + bw / 2.0, y - 4.0, Color.WHITE)
		var vout := float(r["out"])
		if vout > 0.0:
			var hd := down_h * vout / max_v
			draw_rect(Rect2(Vector2(x, mid), Vector2(bw, hd)), C_OUT)
			_label(font, "−%d" % int(vout), x + bw / 2.0, mid + hd + 13.0, Color(1.0, 0.75, 0.72))
		_label(font, str(int(r["ante"])), x + bw / 2.0, size.y - 2.0, Color(0.7, 0.7, 0.8))

func _label(font: Font, t: String, cx: float, y: float, col: Color) -> void:
	var w := font.get_string_size(t, HORIZONTAL_ALIGNMENT_LEFT, -1, 12).x
	draw_string(font, Vector2(cx - w / 2.0, y), t, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, col)
