class_name TileGrid
extends ScrollContainer
## 0.16.1: grelha desenhada (sem um nó por peça) para as relíquias e a Galeria da Coleção. Só desenha as
## filas à vista, carrega as imagens noutra thread (enquanto não chegam fica a moldura vazia) e guarda as
## últimas KEEP — a Galeria tem centenas de ilustrações e assim não fica tudo na memória.
## Tocar numa peça (sem a arrastar) emite tile_pressed com o índice em `items`.
##
## Cada peça é um Dictionary:
##   "art"    caminho da imagem ("" = sem imagem: fica o «?»)
##   "label"  o nome por baixo (até 2 linhas)
##   "seen"   já descoberta (as outras ficam escuras, com «?»)
##   "ring"   cor do aro (relíquias: a da raridade)
##   "badge"  texto pequeno no canto (opcional)
## `shape`: "round" (medalhão, relíquias), "wide" (16:9, cartas e lugares) ou "square" (retratos).

signal tile_pressed(index: int)

const SEP := Vector2(10, 10)
const KEEP := 96
const LABEL_FS := 13
const DRAG_SLOP := 14.0

var items: Array = []
var shape := "round"
var cell := Vector2(96, 112)
var selected := -1
var columns := 1
var _canvas: Control
var _tex: Dictionary = {}          # caminho → Texture2D (null = falhou)
var _order: Array[String] = []     # pela ordem em que chegaram (para largar as mais antigas)
var _pending: Dictionary = {}      # caminho → true (a carregar noutra thread)
var _press := Vector2.ZERO
var _press_scroll := 0
var _pressing := false
var _queued := false

func _init() -> void:
	horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_canvas = Control.new()
	_canvas.name = "Tiles"
	_canvas.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(_canvas)
	_canvas.draw.connect(_draw_tiles)
	_canvas.gui_input.connect(_on_canvas_input)
	set_process(false)

func _ready() -> void:
	get_v_scroll_bar().value_changed.connect(func(_v: float): _canvas.queue_redraw())
	resized.connect(_queue_relayout)
	_queue_relayout()

## A lista a mostrar (volta ao topo). `keep_scroll` mantém a posição (ao mudar só a seleção, por exemplo).
func set_items(list: Array, keep_scroll: bool = false) -> void:
	items = list
	if selected >= items.size():
		selected = -1
	if not keep_scroll:
		scroll_vertical = 0
	_queue_relayout()

func set_selected(i: int) -> void:
	selected = i
	_canvas.queue_redraw()

## Desliza o mínimo para a peça i ficar toda à vista (depois de arrumar a grelha).
func ensure_visible(i: int) -> void:
	if i < 0:
		return
	_scroll_to.call_deferred(i)

func _scroll_to(i: int) -> void:
	if not is_inside_tree() or columns <= 0:
		return
	var r := tile_rect(i)
	if r.position.y < scroll_vertical:
		scroll_vertical = int(r.position.y)
	elif r.end.y > scroll_vertical + size.y:
		scroll_vertical = int(r.end.y - size.y + 4.0)

## Retângulo da peça i (no espaço da grelha) — para os testes e para deslizar até ela.
func tile_rect(i: int) -> Rect2:
	var col := i % maxi(1, columns)
	var row := i / maxi(1, columns)
	return Rect2(Vector2(col * (cell.x + SEP.x), row * (cell.y + SEP.y)), cell)

## Índice da peça num ponto da grelha (-1 = nenhuma).
func index_at(p: Vector2) -> int:
	var col := int(p.x / (cell.x + SEP.x))
	var row := int(p.y / (cell.y + SEP.y))
	if col < 0 or col >= columns or row < 0:
		return -1
	var i := row * columns + col
	if i >= items.size() or not tile_rect(i).has_point(p):
		return -1
	return i

func _queue_relayout() -> void:
	if _queued:
		return
	_queued = true
	_relayout.call_deferred()

func _relayout() -> void:
	_queued = false
	if not is_inside_tree():
		return
	var w := size.x - 14.0   # a barra de deslizar
	columns = maxi(1, int((w + SEP.x) / (cell.x + SEP.x)))
	var rows := ceili(items.size() / float(columns))
	_canvas.custom_minimum_size = Vector2(maxf(w, 1.0), maxf(rows * (cell.y + SEP.y) - SEP.y, 1.0))
	_canvas.queue_redraw()

func _on_canvas_input(ev: InputEvent) -> void:
	if not (ev is InputEventMouseButton) or ev.button_index != MOUSE_BUTTON_LEFT:
		return
	if ev.pressed:
		_pressing = true
		_press = ev.position
		_press_scroll = scroll_vertical
		return
	if not _pressing:
		return
	_pressing = false
	# Só conta como toque se o dedo não arrastou (a deslizar, o ScrollContainer move a grelha).
	if ev.position.distance_to(_press) > DRAG_SLOP or absi(scroll_vertical - _press_scroll) > 8:
		return
	var i := index_at(ev.position)
	if i >= 0:
		tile_pressed.emit(i)

# --- Imagens (noutra thread) ---

func _texture(p: String) -> Texture2D:
	if p == "":
		return null
	if _tex.has(p):
		return _tex[p]
	if not _pending.has(p):
		if ResourceLoader.has_cached(p):
			_store(p, ResourceLoader.load(p) as Texture2D)
			return _tex[p]
		if ResourceLoader.load_threaded_request(p, "Texture2D") == OK:
			_pending[p] = true
			set_process(true)
		else:
			_store(p, ResourceLoader.load(p) as Texture2D)
			return _tex[p]
	return null

func _store(p: String, t: Texture2D) -> void:
	_tex[p] = t
	_order.append(p)
	while _order.size() > KEEP:
		_tex.erase(_order.pop_front())

func _process(_delta: float) -> void:
	var done: Array = []
	for p in _pending:
		var st := ResourceLoader.load_threaded_get_status(p)
		if st == ResourceLoader.THREAD_LOAD_IN_PROGRESS:
			continue
		done.append(p)
		_store(p, ResourceLoader.load_threaded_get(p) as Texture2D if st == ResourceLoader.THREAD_LOAD_LOADED else null)
	for p in done:
		_pending.erase(p)
	if not done.is_empty():
		_canvas.queue_redraw()
	if _pending.is_empty():
		set_process(false)

## Espera que as imagens à vista cheguem (para os testes e as capturas).
func wait_loaded() -> void:
	var tries := 0
	while not _pending.is_empty() and tries < 240:
		await get_tree().process_frame
		tries += 1

# --- Desenho ---

func _draw_tiles() -> void:
	if items.is_empty() or columns <= 0:
		return
	var row_h := cell.y + SEP.y
	var top := float(scroll_vertical)
	var first := maxi(0, int(top / row_h)) * columns
	var last := mini(items.size(), (int((top + maxf(size.y, row_h)) / row_h) + 1) * columns)
	var font := get_theme_default_font()
	for i in range(first, last):
		_draw_tile(i, tile_rect(i), items[i] as Dictionary, font)

func _draw_tile(i: int, r: Rect2, it: Dictionary, font: Font) -> void:
	var seen := bool(it.get("seen", true))
	var ring: Color = it.get("ring", UiKit.BORDER) if it.get("ring") is Color else UiKit.BORDER
	var sel := i == selected
	var label_h := 34.0 if String(it.get("label", "")) != "" else 0.0
	var art_area := Rect2(r.position, Vector2(r.size.x, r.size.y - label_h))
	var tex: Texture2D = _texture(String(it.get("art", ""))) if seen else null
	match shape:
		"round":
			var rad := minf(art_area.size.x, art_area.size.y) * 0.5 - 4.0
			var c := art_area.get_center()
			if sel:
				_canvas.draw_texture_rect(MenuBackdrop.glow_texture(), Rect2(c - Vector2(rad, rad) * 1.5, Vector2(rad, rad) * 3.0), false, Color(UiKit.GOLD, 0.35))
			_canvas.draw_circle(c, rad, Color(0.08, 0.06, 0.13))
			if tex != null:
				ArtLib.draw_round(_canvas, tex, c, rad - 3.0)
			elif not seen:
				_q_mark(font, c, rad)
			_canvas.draw_arc(c, rad - 1.5, 0.0, TAU, 40, (UiKit.GOLD if sel else ring) if seen else Color(ring, 0.25), 4.0 if sel else 3.0, true)
		_:
			var ar := art_area.grow(-3.0)
			if shape == "wide":
				var h := minf(ar.size.y, ar.size.x * 9.0 / 16.0)
				ar = Rect2(Vector2(ar.position.x, ar.position.y + (ar.size.y - h) * 0.5), Vector2(ar.size.x, h))
			else:
				var s := minf(ar.size.x, ar.size.y)
				ar = Rect2(ar.get_center() - Vector2(s, s) * 0.5, Vector2(s, s))
			var pts := ArtLib.rounded_rect_points(ar, 10.0, 4)
			if sel:
				_canvas.draw_texture_rect(MenuBackdrop.glow_texture(), ar.grow(24.0), false, Color(UiKit.GOLD, 0.3))
			_canvas.draw_colored_polygon(pts, Color(0.08, 0.06, 0.13))
			if tex != null:
				ArtLib.draw_rounded(_canvas, tex, ar, 10.0, 0.4)
			elif not seen:
				_q_mark(font, ar.get_center(), minf(ar.size.x, ar.size.y) * 0.5)
			pts.append(pts[0])
			_canvas.draw_polyline(pts, (UiKit.GOLD if sel else ring) if seen else Color(ring, 0.25), 3.0 if sel else 2.0, true)
	var badge := String(it.get("badge", ""))
	if badge != "" and seen:
		var bw := font.get_string_size(badge, HORIZONTAL_ALIGNMENT_LEFT, -1, 12).x + 12.0
		var br := Rect2(Vector2(art_area.end.x - bw - 2.0, art_area.position.y + 2.0), Vector2(bw, 18.0))
		_canvas.draw_style_box(UiKit.flat(Color(0.1, 0.36, 0.2), 9, Color(0.55, 0.95, 0.6), 1, 0), br)
		_canvas.draw_string(font, Vector2(br.position.x + 6.0, br.position.y + 14.0), badge, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(0.88, 1.0, 0.88))
	if label_h > 0.0:
		var txt := String(it.get("label", "")) if seen else "???"
		var col := Color(0.95, 0.93, 0.98) if seen else UiKit.TEXT_DIM
		if sel:
			col = UiKit.GOLD
		_canvas.draw_multiline_string(font, Vector2(r.position.x, r.end.y - label_h + 13.0), txt, HORIZONTAL_ALIGNMENT_CENTER, r.size.x, LABEL_FS, 2, col)

func _q_mark(font: Font, c: Vector2, rad: float) -> void:
	var fs := int(clampf(rad * 0.8, 14.0, 40.0))
	var w := font.get_string_size("?", HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
	_canvas.draw_string(font, c + Vector2(-w * 0.5, fs * 0.36), "?", HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 1, 1, 0.32))
