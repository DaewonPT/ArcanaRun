class_name DeckCosmetics
extends RefCounted
## 0.19.0 (299): a moldura, o tapete e o efeito do golpe de um baralho (como já havia para as costas). Cada linha
## roda entre «padrão» (o das Configurações) e os que já tens.

const KINDS := [["frame", "Moldura"], ["mat", "Tapete da Arena"], ["effect", "Efeito do golpe"]]

static func open(deck_id: String) -> Control:
	var t := func(x: String) -> String: return TranslationServer.translate(x)
	var o := Control.new()
	o.name = "DeckCosmetics"
	o.set_anchors_preset(Control.PRESET_FULL_RECT)
	o.mouse_filter = Control.MOUSE_FILTER_STOP
	o.add_child(UiKit.dim(0.8))
	SceneRouter.show_overlay(o)
	var body := UiKit.window(o, 680, t.call("COSMÉTICOS DO BARALHO"), UiKit.GOLD, func(): UiKit.close_animated(o),
		t.call(String(CardDB.get_deck(deck_id).get("name", ""))))
	for k in KINDS:
		var kind := String(k[0])
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		body.add_child(row)
		var l := UiKit.label(t.call(String(k[1])), 18, Color.WHITE)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(l)
		var b := UiKit.button("", 50, 17)
		b.name = "Pick_" + kind
		b.custom_minimum_size.x = 300
		var opts: Array = [""]
		opts.append_array(Settings.unlocked_cosmetics(kind))
		var label := func() -> String:
			var cur := GameState.deck_cosmetic(kind, deck_id)
			return (t.call("padrão") if cur == "" else t.call(String(CardDB.get_cosmetic(kind, cur).get("name", cur)))) + ("  ▸" if opts.size() > 1 else "")
		b.text = label.call()
		b.disabled = opts.size() <= 1
		b.pressed.connect(func():
			var cur := GameState.deck_cosmetic(kind, deck_id)
			GameState.set_deck_cosmetic(kind, deck_id, String(opts[(opts.find(cur) + 1) % opts.size()]))
			Sfx.select()
			b.text = label.call())
		row.add_child(b)
	body.add_child(UiKit.label(t.call("Valem nas runs com este baralho. Com «Cosméticos ao acaso» ligado, cada run sorteia os seus."), 14, UiKit.TEXT_DIM, true))
	var done := UiKit.button(t.call("FECHAR"), 52, 20, UiKit.PRIMARY)
	done.pressed.connect(func(): Sfx.select(); UiKit.close_animated(o))
	body.add_child(done)
	UiKit.pop_in(body.get_meta("panel"))
	return o
