class_name PileView
extends Control
## 0.16.0 (V11 + V31): o grimório e o cemitério da batalha em pilha, nas pontas da mão.
## O grimório mostra as tuas costas (as das Configurações); o cemitério, a última carta que lá caiu (com a
## ilustração, ou a cor da carta). Debaixo da carta de cima há mais duas quando a pilha tem cartas que cheguem,
## e o número fica num círculo. Vazia: só um contorno. Desenhado em código; redesenha só quando muda.

const CARD_R := 7.0

var kind := "library"            # "library" (grimório) | "graveyard" (cemitério)
var count := 0
var top_card: CardData = null    # cemitério: a carta de cima
var flashback := false           # cemitério: há cartas que se podem lançar de lá (↺)
var _back: CardBack
var _tex: Texture2D              # a ilustração da carta de cima (guardada: o desenho só leva o RID da textura)
var _badge: Label
var _fb: Label

func _init(p_kind: String = "library") -> void:
	kind = p_kind
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(62, 88)

func _ready() -> void:
	if kind == "library":
		_back = CardBack.new()
		_back.name = "Back"
		_back.back_id = Settings.card_back
		_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(_back)
	_badge = Label.new()
	_badge.name = "Count"
	_badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_badge.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_badge.add_theme_font_size_override("font_size", 15)
	_badge.add_theme_color_override("font_color", Color.WHITE)
	var st := UiKit.flat(Color(0.1, 0.08, 0.16, 0.96), 13, UiKit.GOLD, 2, 0)
	_badge.add_theme_stylebox_override("normal", st)
	add_child(_badge)
	_fb = Label.new()
	_fb.name = "Flashback"
	_fb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fb.text = "↺"
	_fb.add_theme_font_size_override("font_size", 18)
	_fb.add_theme_color_override("font_color", Color(0.8, 0.65, 1.0))
	_fb.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	_fb.add_theme_constant_override("outline_size", 5)
	add_child(_fb)
	resized.connect(_layout)
	_layout()
	_sync()

## Retângulo da carta de cima (as de baixo ficam deslocadas para a direita e para baixo).
func top_rect() -> Rect2:
	return Rect2(Vector2.ZERO, size - Vector2(6, 6))

func set_state(p_count: int, p_top: CardData = null, p_flashback: bool = false) -> void:
	if p_count == count and p_top == top_card and p_flashback == flashback and _badge != null and _badge.text == str(count):
		return
	count = p_count
	top_card = p_top
	flashback = p_flashback
	_tex = ArtLib.texture("card", top_card.id) if top_card != null and kind == "graveyard" else null
	_sync()

## As costas mudaram nas Configurações (o grimório usa sempre as escolhidas).
func refresh_back() -> void:
	if _back != null:
		_back.back_id = Settings.card_back

func _sync() -> void:
	if _badge == null:
		return
	_badge.text = str(count)
	_badge.modulate.a = 1.0 if count > 0 else 0.6
	if _back != null:
		_back.visible = count > 0
	_fb.visible = kind == "graveyard" and flashback
	_layout()
	queue_redraw()

func _layout() -> void:
	if _badge == null:
		return
	var r := top_rect()
	if _back != null:
		_back.position = r.position
		_back.size = r.size
	var bw := maxf(26.0, 10.0 + 8.0 * str(count).length())
	_badge.size = Vector2(bw, 26)
	_badge.position = Vector2(size.x - bw + 2.0, size.y - 24.0)
	_fb.reset_size()
	_fb.position = Vector2(2, size.y - _fb.size.y - 2)

func _draw() -> void:
	var r := top_rect()
	if count <= 0:
		# Vazia: contorno tracejado.
		var c := Color(1, 1, 1, 0.22)
		for side in [[r.position, Vector2(r.end.x, r.position.y)], [Vector2(r.end.x, r.position.y), r.end],
				[r.end, Vector2(r.position.x, r.end.y)], [Vector2(r.position.x, r.end.y), r.position]]:
			draw_dashed_line(side[0], side[1], c, 1.5, 5.0)
		return
	# Espessura da pilha: até duas cartas por baixo.
	var under := mini(2, count - 1)
	for k in range(under, 0, -1):
		var ur := Rect2(r.position + Vector2(3, 3) * k, r.size)
		draw_style_box(_card_box(Color(0.12, 0.1, 0.18), Color(0.32, 0.28, 0.42)), ur)
	if kind == "library":
		return   # a carta de cima é a CardBack (filha)
	# Cemitério: a última carta, com a ilustração por cima da cor dela.
	var col: Color = CardView.COLORS.get(top_card.primary_color(), CardView.COLORS.colorless) if top_card != null else Color(0.4, 0.4, 0.45)
	draw_style_box(_card_box(col.darkened(0.55), col), r)
	var inner := r.grow(-3.0)
	if _tex != null:
		# Recorte ao centro da ilustração com a forma da carta (a ilustração é larga), de cantos redondos.
		ArtLib.draw_rounded(self, _tex, inner, CARD_R - 2.0, 0.4, Color(0.85, 0.85, 0.9))
	elif top_card != null:
		var icon_r := minf(inner.size.x, inner.size.y) * 0.32
		draw_circle(inner.get_center(), icon_r, Color(col, 0.55))
	# Escurece a carta: está no cemitério.
	var dim := StyleBoxFlat.new()
	dim.bg_color = Color(0.05, 0.02, 0.08, 0.32)
	dim.set_corner_radius_all(int(CARD_R) - 2)
	draw_style_box(dim, inner)

func _card_box(bg: Color, border: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.set_corner_radius_all(int(CARD_R))
	s.set_border_width_all(2)
	s.border_color = border
	return s
