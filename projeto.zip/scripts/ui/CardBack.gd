class_name CardBack
extends Control
## Costas de uma carta desenhadas em código (sem imagens), a partir de data/cosmetics.json ("backs":
## id, cores [fundo, destaque] e padrão): fundo em degradê com um brilho ao centro, um padrão em toda a
## área (losangos, sol, ondas, eclipse, chamas, folhas, prisma, coroa), um medalhão com o emblema do
## padrão, orla escura e moldura dupla com cantos arredondados. Um id desconhecido usa a "classic".
## Ocupa o retângulo todo e escala com ele (referência 130×186; também 260×372 na transição de cena).
## Não reage a toques (mouse_filter IGNORE); só se redesenha quando muda.

var back_id: String = "classic":
	set(v):
		back_id = v
		queue_redraw()

## Se o cosmético não existir (ou o CardDB não tiver os dados), usa-se este.
const FALLBACK := {"id": "classic", "colors": ["#2b2350", "#f2c14e"], "pattern": "diamond"}
const PATTERNS := ["diamond", "sun", "waves", "eclipse", "flame", "leaf", "prism", "crown"]
## Cores de mana (as de CardView.COLORS; o preto mais claro para se ver no fundo escuro do prisma).
const MANA := [Color(0.93, 0.89, 0.74), Color(0.38, 0.56, 0.88), Color(0.62, 0.5, 0.78), Color(0.86, 0.36, 0.30), Color(0.40, 0.66, 0.40)]

var _bg := Color("#2b2350")
var _accent := Color("#f2c14e")
var _pattern := "diamond"
var _k := 1.0          # escala em relação a 130×186
var _feather := 1.0    # orla suave (px) das formas cheias

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

## Lê as cores e o padrão do cosmético (com a "classic" e depois FALLBACK como reserva).
func _resolve() -> void:
	var d: Dictionary = CardDB.get_cosmetic("back", back_id)
	if d.is_empty():
		d = CardDB.get_cosmetic("back", "classic")
	if d.is_empty():
		d = FALLBACK
	var cols: Array = d.get("colors", [])
	_bg = _hex(cols[0] if cols.size() > 0 else null, Color("#2b2350"))
	_accent = _hex(cols[1] if cols.size() > 1 else null, Color("#f2c14e"))
	_pattern = String(d.get("pattern", "diamond"))
	if not (_pattern in PATTERNS):
		_pattern = "diamond"

func _hex(v: Variant, fallback: Color) -> Color:
	if v is String and Color.html_is_valid(v):
		return Color.html(v)
	return fallback

func _draw() -> void:
	_resolve()
	var sz := size
	if sz.x < 12.0 or sz.y < 12.0:
		return
	_k = minf(sz.x / 130.0, sz.y / 186.0)
	_feather = clampf(_k * 0.9, 0.7, 1.6)
	var k := _k
	var radius := minf(12.0 * k, minf(sz.x, sz.y) * 0.2)
	var c := sz / 2.0

	# Fundo em degradê (mais claro em cima) e brilho suave ao centro.
	var outer := _rrect(Rect2(Vector2.ZERO, sz), radius)
	var top := _bg.lightened(0.1)
	var bottom := _bg.darkened(0.32)
	var grad := PackedColorArray()
	for p in outer:
		grad.append(top.lerp(bottom, p.y / sz.y))
	draw_polygon(outer, grad)
	_glow(c, Vector2(sz.x * 0.46, sz.y * 0.4), Color(_accent, 0.13))

	# Padrão por toda a área de dentro da moldura.
	var inset := 9.0 * k
	var inner_rect := Rect2(Vector2(inset, inset), sz - Vector2(inset, inset) * 2.0)
	var clip := _rrect(inner_rect, maxf(2.0, radius - inset * 0.55))
	_field(inner_rect, clip)

	# Medalhão com o emblema.
	var rm := minf(sz.x, sz.y) * 0.3
	_fill(_circle(c, rm + 2.5 * k, 48), Color(_bg.darkened(0.45), 0.55))
	_fill(_circle(c, rm, 48), _bg.darkened(0.12))
	_emblem(c, rm - 5.0 * k)
	draw_arc(c, rm, 0.0, TAU, 64, _accent, 1.5 * k, true)
	draw_arc(c, rm - 3.2 * k, 0.0, TAU, 64, Color(_accent, 0.45), 0.8 * k, true)

	# Moldura: orla escura no bordo, linha de destaque e linha de dentro, com pontas nos meios.
	_outline(_rrect(Rect2(Vector2.ONE * 1.4 * k, sz - Vector2.ONE * 2.8 * k), radius - 1.4 * k), _bg.darkened(0.6), 2.8 * k)
	_outline(_rrect(Rect2(Vector2.ONE * 4.6 * k, sz - Vector2.ONE * 9.2 * k), maxf(1.0, radius - 4.6 * k)), Color(_accent, 0.9), 1.3 * k)
	_outline(clip, Color(_accent, 0.42), 0.8 * k)
	for p in [Vector2(c.x, 4.6 * k), Vector2(c.x, sz.y - 4.6 * k), Vector2(4.6 * k, c.y), Vector2(sz.x - 4.6 * k, c.y)]:
		_fill(_diamond(p, 3.2 * k, 3.2 * k), _accent)
		_fill(_diamond(p, 1.4 * k, 1.4 * k), _bg.darkened(0.2))

# --- Padrões (em toda a área, recortados pela moldura de dentro) ---

func _field(r: Rect2, clip: PackedVector2Array) -> void:
	var k := _k
	var c := r.get_center()
	var faint := Color(_accent, 0.15)
	match _pattern:
		"diamond":
			# losangos: duas famílias de diagonais e um ponto em cada cruzamento
			var sx := 11.0 * k
			var sy := sx * 1.45
			var span := r.size.x + r.size.y
			for i in range(-14, 15):
				var o := Vector2(c.x + i * 2.0 * sx, c.y)
				_clip_line(o - Vector2(sx, sy) * (span / sy), o + Vector2(sx, sy) * (span / sy), clip, faint, 0.8 * k)
				_clip_line(o - Vector2(sx, -sy) * (span / sy), o + Vector2(sx, -sy) * (span / sy), clip, faint, 0.8 * k)
			for i in range(-8, 9):
				for j in range(-8, 9):
					if (i + j) % 2 != 0:
						continue
					var p := c + Vector2(i * sx, j * sy)
					if Geometry2D.is_point_in_polygon(p, clip):
						_fill(_circle(p, 1.1 * k, 8), Color(_accent, 0.3))
		"sun":
			# raios em leque a partir do centro (cunhas alternadas)
			var rays := 28
			var L := r.size.length()
			for i in rays:
				if i % 2 == 1:
					continue
				var a0 := -PI / 2.0 + TAU * i / rays
				var a1 := -PI / 2.0 + TAU * (i + 1) / rays
				var wedge := PackedVector2Array([c, c + Vector2(cos(a0), sin(a0)) * L, c + Vector2(cos(a1), sin(a1)) * L])
				for piece in Geometry2D.intersect_polygons(wedge, clip):
					draw_colored_polygon(piece, Color(_accent, 0.07))
			for i in rays:
				var a := -PI / 2.0 + TAU * i / rays
				_clip_line(c, c + Vector2(cos(a), sin(a)) * L, clip, Color(_accent, 0.1), 0.6 * k)
		"waves":
			# seigaiha: escamas de ondas (círculos concêntricos, cada fila tapa a de cima)
			var rr := 12.0 * k
			var row := 0
			var y := r.position.y - rr * 0.2
			while y < r.end.y + rr:
				var x := r.position.x - rr + (rr if row % 2 == 1 else 0.0)
				var shade := (_bg.lightened(0.1)).lerp(_bg.darkened(0.32), clampf(y / size.y, 0.0, 1.0))
				while x < r.end.x + rr:
					var disc := _circle(Vector2(x, y), rr, 28)
					for piece in Geometry2D.intersect_polygons(disc, clip):
						draw_colored_polygon(piece, shade)
					for f in [1.0, 0.72, 0.44]:
						_clip_poly(_circle(Vector2(x, y), rr * f - 0.6 * k, 28), clip, Color(_accent, 0.2 if f == 1.0 else 0.13), 0.75 * k, true)
					x += rr * 2.0
				y += rr * 0.5
				row += 1
		"eclipse":
			# céu de estrelas e duas órbitas à volta do medalhão
			var rng := RandomNumberGenerator.new()
			rng.seed = 7331
			for i in 46:
				var p := Vector2(rng.randf_range(r.position.x, r.end.x), rng.randf_range(r.position.y, r.end.y))
				var big := rng.randf() < 0.35
				var s := rng.randf_range(1.6, 3.2) * k
				if not Geometry2D.is_point_in_polygon(p, clip):
					continue
				if big:
					_fill(_sparkle(p, s), Color(_accent, rng.randf_range(0.35, 0.7)))
				else:
					_fill(_circle(p, 0.75 * k, 8), Color(_accent.lightened(0.4), rng.randf_range(0.25, 0.6)))
			var rm := minf(size.x, size.y) * 0.3
			for f in [1.28, 1.6]:
				_clip_poly(_circle(c, rm * f, 64), clip, Color(_accent, 0.13), 0.7 * k, true)
		"flame":
			# línguas de fogo em fiadas desencontradas
			var gx := 15.0 * k
			var gy := 19.0 * k
			var j := 0
			var y := r.position.y + gy * 0.85
			while y < r.end.y + gy:
				var x := r.position.x + gx * (0.5 if j % 2 == 0 else 1.0)
				var i := 0
				while x < r.end.x:
					var pts := _flat(Vector2(x, y), _tongue(3.4 * k, 12.0 * k, 1.0 if (i + j) % 2 == 0 else -1.0, true))
					if _inside(pts, clip):
						_outline(pts, faint, 0.8 * k)
					x += gx
					i += 1
				y += gy
				j += 1
		"leaf":
			# folhinhas alternadas (para um lado e para o outro) com nervura
			var gx := 15.0 * k
			var gy := 16.0 * k
			var j := 0
			var y := r.position.y + gy * 0.6
			while y < r.end.y:
				var x := r.position.x + gx * (0.55 if j % 2 == 0 else 1.05)
				var i := 0
				while x < r.end.x:
					var dir := Vector2(0.62, -0.78) if (i + j) % 2 == 0 else Vector2(-0.62, -0.78)
					var base := Vector2(x, y) - dir * 4.5 * k
					var pts := _petal(base, dir, 9.5 * k, 3.0 * k)
					if _inside(pts, clip):
						_outline(pts, faint, 0.8 * k)
						draw_line(base + dir * 1.5 * k, base + dir * 7.0 * k, faint, 0.6 * k, true)
					x += gx
					i += 1
				y += gy
				j += 1
		"prism":
			# rede triangular (três famílias de linhas)
			var sp := 12.0 * k
			var L := r.size.length()
			for ang in [0.0, PI / 3.0, 2.0 * PI / 3.0]:
				var d := Vector2(cos(ang), sin(ang))
				var nrm := Vector2(-d.y, d.x)
				for i in range(-16, 17):
					var o: Vector2 = c + nrm * i * sp
					_clip_line(o - d * L, o + d * L, clip, Color(_accent, 0.08), 0.7 * k)
		"crown":
			# riscas finas e pequenos losangos em riscas alternadas
			var sp := 8.0 * k
			var i := 0
			var x := c.x - floorf((c.x - r.position.x) / sp) * sp
			while x < r.end.x:
				_clip_line(Vector2(x, r.position.y - 4.0), Vector2(x, r.end.y + 4.0), clip, Color(_accent, 0.09 if i % 2 == 0 else 0.05), 0.7 * k)
				if i % 2 == 0:
					var y := r.position.y + (8.0 if i % 4 == 0 else 16.0) * k
					while y < r.end.y:
						var p := Vector2(x, y)
						if Geometry2D.is_point_in_polygon(p, clip):
							_fill(_diamond(p, 1.8 * k, 2.6 * k), Color(_accent, 0.22))
						y += 16.0 * k
				x += sp
				i += 1

# --- Emblemas (dentro do medalhão de raio re) ---

func _emblem(c: Vector2, re: float) -> void:
	var k := _k
	var a := _accent
	match _pattern:
		"diamond":
			# losango comprido a atravessar o anel e uma gema facetada no meio
			_outline(_diamond(c, re * 0.66, re * 1.32), a, 1.4 * k)
			var gw := re * 0.42
			var gh := re * 0.72
			var top := c + Vector2(0, -gh)
			var bot := c + Vector2(0, gh)
			var left := c + Vector2(-gw, 0)
			var right := c + Vector2(gw, 0)
			_fill(PackedVector2Array([top, c, left]), a.lightened(0.35))
			_fill(PackedVector2Array([top, right, c]), a)
			_fill(PackedVector2Array([left, c, bot]), a.darkened(0.12))
			_fill(PackedVector2Array([c, right, bot]), a.darkened(0.32))
			_fill(_sparkle(c + Vector2(gw * 0.55, -gh * 0.62), 3.2 * k), Color(1, 1, 1, 0.9))
			for sx in [-1.0, 1.0]:
				_fill(_diamond(c + Vector2(sx * re * 0.76, 0), 2.6 * k, 4.0 * k), a)
		"sun":
			# disco com raios alternados
			for i in 16:
				var ang := -PI / 2.0 + TAU * i / 16.0
				var tip := re * (0.98 if i % 2 == 0 else 0.78)
				var hw := 0.13 if i % 2 == 0 else 0.1
				_fill(PackedVector2Array([c + _dir(ang - hw) * re * 0.5, c + _dir(ang) * tip, c + _dir(ang + hw) * re * 0.5]), a)
			_fill(_circle(c, re * 0.5, 40), a)
			_outline(_circle(c, re * 0.36, 40), _bg.darkened(0.1), 1.0 * k)
			_fill(_circle(c, re * 0.2, 24), a.lightened(0.5))
		"waves":
			# gota sobre três ondas
			for j in 3:
				var y := c.y + re * (0.12 + 0.24 * j)
				var half := sqrt(maxf(0.0, re * re * 0.9 - pow(y - c.y, 2.0))) * 0.92
				var pts := PackedVector2Array()
				for t in 33:
					var x := -half + 2.0 * half * t / 32.0
					pts.append(Vector2(c.x + x, y + sin(x / re * 9.0) * re * 0.07))
				draw_polyline(pts, Color(a, 1.0 - 0.22 * j), 1.6 * k, true)
			var drop := PackedVector2Array()
			for j in 32:
				var t := TAU * j / 32.0
				drop.append(c + Vector2(0, -re * 0.38) + Vector2(re * 0.36 * sin(t) * sin(t * 0.5), -re * 0.5 * cos(t)))
			_fill(drop, a)
			_fill(_circle(c + Vector2(-re * 0.1, -re * 0.28), re * 0.07, 12), Color(1, 1, 1, 0.75))
		"eclipse":
			# disco escuro com coroa de luz e um brilho no rebordo
			_glow(c, Vector2(re, re) * 1.02, Color(a, 0.75), re * 0.6)
			_fill(_circle(c, re * 0.6, 48), _bg.darkened(0.75))
			draw_arc(c, re * 0.6, 0.0, TAU, 64, a, 1.2 * k, true)
			# crescente de luz no rebordo (mais grosso a meio, fino nas pontas)
			var cres := PackedVector2Array()
			for j in 25:
				var t := j / 24.0
				cres.append(c + _dir(lerpf(-PI * 0.62, PI * 0.12, t)) * (re * 0.6 + 2.8 * k * sin(PI * t)))
			for j in range(23, 0, -1):
				cres.append(c + _dir(lerpf(-PI * 0.62, PI * 0.12, j / 24.0)) * re * 0.6)
			_fill(cres, a.lightened(0.55))
			_fill(_sparkle(c + _dir(-PI * 0.25) * (re * 0.6 + 2.0 * k), 5.5 * k), Color(1, 1, 1, 0.95))
		"flame":
			# chama em três camadas
			var base := c + Vector2(0, re * 0.6)
			_fill(_flat(base, _tongue(re * 0.56, re * 1.45, 0.55, true)), a)
			_fill(_flat(base + Vector2(0, re * 0.06), _tongue(re * 0.36, re * 0.92, 0.5, true)), a.lightened(0.35))
			_fill(_flat(base + Vector2(0, re * 0.1), _tongue(re * 0.19, re * 0.48, 0.4, true)), Color(1.0, 0.96, 0.8))
		"leaf":
			# folha grande com nervuras e pé
			var dir := Vector2(0.55, -0.83).normalized()
			var base := c - dir * re * 0.78
			var pts := _petal(base, dir, re * 1.56, re * 0.48)
			_fill(pts, a)
			var vein := _bg.darkened(0.1)
			draw_line(base + dir * re * 0.1, base + dir * re * 1.36, vein, 1.2 * k, true)
			var side := Vector2(-dir.y, dir.x)
			for j in 4:
				var p := base + dir * re * (0.42 + 0.24 * j)
				var reach := re * (0.3 - 0.04 * j)
				draw_line(p, p + (dir * 0.7 + side * 0.7).normalized() * reach, vein, 0.9 * k, true)
				draw_line(p, p + (dir * 0.7 - side * 0.7).normalized() * reach, vein, 0.9 * k, true)
			draw_line(base + dir * re * 0.12, base - dir * re * 0.22 + side * re * 0.1, a, 1.6 * k, true)
		"prism":
			# prisma: um raio branco entra e sai partido nas cinco cores de mana
			var h := re * 1.1
			var tri := PackedVector2Array([c + Vector2(0, -h * 0.62), c + Vector2(h * 0.58, h * 0.4), c + Vector2(-h * 0.58, h * 0.4)])
			var hit_in := tri[0].lerp(tri[2], 0.55)
			var hit_out := tri[0].lerp(tri[1], 0.6)
			draw_line(c + Vector2(-re * 0.98, re * 0.22), hit_in, Color(1, 1, 1, 0.95), 1.6 * k, true)
			draw_line(hit_in, hit_out, Color(1, 1, 1, 0.5), 1.2 * k, true)
			for i in MANA.size():
				var ang := deg_to_rad(-12.0 + 8.5 * i)
				var dir := _dir(ang)
				var reach := _ray_to_circle(hit_out - c, dir, re * 0.98)
				draw_line(hit_out, hit_out + dir * reach, MANA[i], 2.0 * k, true)
			_fill(tri, Color(1, 1, 1, 0.1))
			_outline(tri, a, 1.4 * k)
		"crown":
			# coroa de cinco pontas com pérolas e pedras na faixa
			var u := re
			var pts := PackedVector2Array()
			for v in [Vector2(-0.6, 0.42), Vector2(-0.63, 0.12), Vector2(-0.7, -0.3), Vector2(-0.51, -0.02), Vector2(-0.34, -0.5), Vector2(-0.17, -0.02), Vector2(0, -0.64), Vector2(0.17, -0.02), Vector2(0.34, -0.5), Vector2(0.51, -0.02), Vector2(0.7, -0.3), Vector2(0.63, 0.12), Vector2(0.6, 0.42)]:
				pts.append(c + v * u)
			_fill(pts, a)
			_fill(PackedVector2Array([c + Vector2(-0.63, 0.12) * u, c + Vector2(0.63, 0.12) * u, c + Vector2(0.6, 0.42) * u, c + Vector2(-0.6, 0.42) * u]), a.darkened(0.25))
			for v in [Vector2(-0.7, -0.3), Vector2(-0.34, -0.5), Vector2(0, -0.64), Vector2(0.34, -0.5), Vector2(0.7, -0.3)]:
				_fill(_circle(c + v * u + Vector2(0, -0.05 * u), 0.075 * u, 14), a.lightened(0.45))
			_fill(_diamond(c + Vector2(0, 0.27) * u, 0.09 * u, 0.11 * u), Color(0.86, 0.22, 0.3))
			for sx in [-1.0, 1.0]:
				_fill(_circle(c + Vector2(sx * 0.33, 0.27) * u, 0.06 * u, 12), Color(0.3, 0.55, 0.95))

# --- Ajudantes de desenho ---

func _dir(a: float) -> Vector2:
	return Vector2(cos(a), sin(a))

func _circle(c: Vector2, r: float, segs: int) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in segs:
		pts.append(c + _dir(TAU * i / segs) * r)
	return pts

func _diamond(c: Vector2, hw: float, hh: float) -> PackedVector2Array:
	return PackedVector2Array([c + Vector2(0, -hh), c + Vector2(hw, 0), c + Vector2(0, hh), c + Vector2(-hw, 0)])

## Estrela de quatro pontas (brilho).
func _sparkle(c: Vector2, s: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in 8:
		var a := -PI / 2.0 + TAU * i / 8.0
		pts.append(c + _dir(a) * (s if i % 2 == 0 else s * 0.28))
	return pts

## Retângulo de cantos redondos como polígono (sentido dos ponteiros do relógio).
func _rrect(r: Rect2, radius: float) -> PackedVector2Array:
	var rad := clampf(radius, 0.0, minf(r.size.x, r.size.y) * 0.5)
	var segs := clampi(int(rad * 0.6), 3, 10)
	var pts := PackedVector2Array()
	var centers := [r.position + Vector2(rad, rad), Vector2(r.end.x - rad, r.position.y + rad), r.end - Vector2(rad, rad), Vector2(r.position.x + rad, r.end.y - rad)]
	for corner in 4:
		var start := PI + corner * PI / 2.0
		for j in segs + 1:
			pts.append(centers[corner] + _dir(start + PI / 2.0 * j / segs) * rad)
	return pts

## Contorno fechado (começa a meio do primeiro lado para a junção não se notar).
func _outline(pts: PackedVector2Array, col: Color, w: float) -> void:
	if pts.size() < 3:
		return
	var m := (pts[0] + pts[1]) * 0.5
	var out := PackedVector2Array([m])
	for i in range(1, pts.size()):
		out.append(pts[i])
	out.append(pts[0])
	out.append(m)
	draw_polyline(out, col, w, true)

## Linha recortada pelo polígono (só os troços de dentro).
func _clip_line(a: Vector2, b: Vector2, clip: PackedVector2Array, col: Color, w: float) -> void:
	for piece in Geometry2D.intersect_polyline_with_polygon(PackedVector2Array([a, b]), clip):
		draw_polyline(piece, col, w, true)

## Contorno (fechado ou não) recortado pelo polígono.
func _clip_poly(pts: PackedVector2Array, clip: PackedVector2Array, col: Color, w: float, closed: bool) -> void:
	var line := pts.duplicate()
	if closed and pts.size() > 0:
		line.append(pts[0])
	for piece in Geometry2D.intersect_polyline_with_polygon(line, clip):
		draw_polyline(piece, col, w, true)

func _inside(pts: PackedVector2Array, clip: PackedVector2Array) -> bool:
	for p in pts:
		if not Geometry2D.is_point_in_polygon(p, clip):
			return false
	return true

## Distância, a partir de p (relativo ao centro), na direção dir, até ao círculo de raio r.
func _ray_to_circle(p: Vector2, dir: Vector2, r: float) -> float:
	var b := p.dot(dir)
	var disc := b * b - (p.length_squared() - r * r)
	return maxf(0.0, -b + sqrt(maxf(0.0, disc)))

## Forma local de pé (y para cima), com a base no ponto dado.
func _flat(base: Vector2, local: PackedVector2Array) -> PackedVector2Array:
	var out := PackedVector2Array()
	out.resize(local.size())
	for i in local.size():
		out[i] = base + Vector2(local[i].x, -local[i].y)
	return out

## Língua de fogo em coordenadas locais: base de -half a +half, ponta à altura h inclinada por lean;
## round_base arredonda o fundo (chama solta, em gota).
func _tongue(half: float, h: float, lean: float, round_base: bool = false) -> PackedVector2Array:
	var tip := Vector2(0.5 * lean * half, h)
	var pts := PackedVector2Array()
	for j in 9:
		pts.append(Vector2(-half, 0.0).bezier_interpolate(Vector2(-1.15 * half, 0.4 * h), Vector2((-0.3 + 0.4 * lean) * half, 0.72 * h), tip, j / 8.0))
	for j in range(1, 9):
		pts.append(tip.bezier_interpolate(Vector2((0.25 + 0.5 * lean) * half, 0.66 * h), Vector2(1.12 * half, 0.38 * h), Vector2(half, 0.0), j / 8.0))
	if round_base:
		for j in range(1, 10):
			var a := PI * j / 10.0
			pts.append(Vector2(half * cos(a), -half * 0.62 * sin(a)))
	return pts

## Folha/pétala (amêndoa) da base na direção dir.
func _petal(base: Vector2, dir: Vector2, length: float, half: float) -> PackedVector2Array:
	var perp := Vector2(-dir.y, dir.x)
	var pts := PackedVector2Array()
	for j in 13:
		var t := j / 12.0
		pts.append(base + dir * length * t + perp * half * pow(sin(PI * t), 0.8))
	for j in range(11, 0, -1):
		var t := j / 12.0
		pts.append(base + dir * length * t - perp * half * pow(sin(PI * t), 0.8))
	return pts

## Brilho elíptico: cor no centro (ou num disco de raio core) a desvanecer até ao bordo.
func _glow(c: Vector2, radii: Vector2, col: Color, core: float = 0.0) -> void:
	var segs := 40
	var points := PackedVector2Array([c])
	var cols := PackedColorArray([col])
	var indices := PackedInt32Array()
	var inner := core / maxf(1.0, radii.x)
	for i in segs:
		var d := _dir(TAU * i / segs)
		points.append(c + d * radii * inner)
		cols.append(col)
		points.append(c + d * radii)
		cols.append(Color(col, 0.0))
	for i in segs:
		var a := 1 + i * 2
		var b := 1 + ((i + 1) % segs) * 2
		indices.append_array(PackedInt32Array([0, a, b, a, a + 1, b + 1, a, b + 1, b]))
	RenderingServer.canvas_item_add_triangle_array(get_canvas_item(), indices, points, cols)

## Forma cheia com orla suave (antialias): o polígono e uma tira à volta que vai até transparente.
func _fill(pts: PackedVector2Array, col: Color) -> void:
	var count := pts.size()
	if count < 3:
		return
	draw_colored_polygon(pts, col)
	var area := 0.0
	for i in count:
		area += pts[i].x * pts[(i + 1) % count].y - pts[(i + 1) % count].x * pts[i].y
	var out_sign := 1.0 if area > 0.0 else -1.0
	var points := PackedVector2Array()
	points.resize(count * 2)
	var cols := PackedColorArray()
	cols.resize(count * 2)
	var clear := Color(col, 0.0)
	var indices := PackedInt32Array()
	for i in count:
		var cur := pts[i]
		var nrm := ((cur - pts[(i - 1 + count) % count]).normalized().orthogonal() + (pts[(i + 1) % count] - cur).normalized().orthogonal()).normalized()
		points[i] = cur
		points[count + i] = cur + nrm * out_sign * _feather
		cols[i] = col
		cols[count + i] = clear
		var j := (i + 1) % count
		indices.append_array(PackedInt32Array([i, j, count + j, i, count + j, count + i]))
	RenderingServer.canvas_item_add_triangle_array(get_canvas_item(), indices, points, cols)
