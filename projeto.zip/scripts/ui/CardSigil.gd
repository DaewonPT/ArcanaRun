class_name CardSigil
extends Control
## Sigilo arcano de uma carta, desenhado em código a partir do id (a mesma carta dá sempre o mesmo
## desenho): anéis, um polígono ou estrela de 3 a 8 pontas, uma forma interior rodada, raios, pontos
## em órbita e um emblema no centro. O motivo segue a cor principal — branco: raios de sol e halo ·
## azul: ondas · preto: espinhos e crescente · vermelho: chamas · verde: pétalas · incolor: dentes de
## engrenagem. Cartas de várias cores juntam os motivos das duas primeiras (fora a 1.ª, dentro a 2.ª).
## Serve de marca de água atrás do texto (~120 px) e em grande no zoom (~300 px): desenha-se centrado
## no quadrado de lado min(size.x, size.y) e não reage a toques. Só se redesenha quando muda.

var card_id: String = "":
	set(v):
		card_id = v
		queue_redraw()
## Nomes das cores da carta ("white", "blue", "black", "red", "green"); vazio = incolor.
var colors: Array = []:
	set(v):
		colors = v
		queue_redraw()
## Cor do traço, já com o alfa (tinta escura nas cartas claras, clara nas escuras).
var ink: Color = Color(0, 0, 0, 0.18):
	set(v):
		ink = v
		queue_redraw()
## Espessura do traço num sigilo de 120 px; nos maiores engrossa com a raiz quadrada da escala.
var line_width: float = 2.0:
	set(v):
		line_width = v
		queue_redraw()

const MOTIFS := ["white", "blue", "black", "red", "green"]

var _density: float = 1.0   # 1 = banda de fora; 0.5 = banda de dentro (menos elementos)
var _feather: float = 1.0   # largura (px) da orla suave das formas cheias

static func make(p_card_id: String, p_colors: Array, p_ink: Color) -> CardSigil:
	var s := CardSigil.new()
	s.card_id = p_card_id
	s.colors = p_colors
	s.ink = p_ink
	s.set_anchors_preset(Control.PRESET_FULL_RECT)
	return s

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

## Motivo da cor na posição i (repete a última; "colorless" se não for uma cor conhecida).
func _motif_at(i: int) -> String:
	if colors.is_empty():
		return "colorless"
	var cname := String(colors[mini(i, colors.size() - 1)])
	return cname if cname in MOTIFS else "colorless"

func _draw() -> void:
	var s := minf(size.x, size.y)
	if s < 8.0 or ink.a <= 0.0:
		return
	var c := size / 2.0
	var w := maxf(0.6, line_width * sqrt(s / 120.0))
	var wt := w * 0.7   # traço fino (detalhes)
	_feather = clampf(w * 0.45, 0.6, 1.2)
	var R := s * 0.5 - w
	var rng := RandomNumberGenerator.new()
	rng.seed = card_id.hash()
	# Parâmetros: sorteados sempre pela mesma ordem, para a mesma carta dar o mesmo sigilo.
	var n := rng.randi_range(3, 8)
	var star_style := rng.randi_range(0, 2)
	var point_up := rng.randf() < 0.65
	var ring_style := rng.randi_range(0, 3)
	var orbit_style := rng.randi_range(0, 2)
	var inner_style := rng.randi_range(0, 2)
	var inner_m := rng.randi_range(3, 6)
	var inner_flat := rng.randf() < 0.5
	var compound := rng.randf() < 0.5
	var spike_ratio := rng.randf_range(0.42, 0.6)
	var variant := rng.randi_range(0, 1)
	var k8 := rng.randi_range(2, 3)
	var m1 := _motif_at(0)
	var m2 := _motif_at(1)
	var multi := m1 != m2
	var phase := -PI / 2.0 + (0.0 if point_up else PI / n)
	var inner_phase := -PI / 2.0 + (PI / inner_m if inner_flat else 0.0)

	# --- Anéis exteriores (o de dentro pode ter traços ou pontos entre os dois) ---
	var r_ring := R * 0.79
	var r_star := r_ring
	_ring(c, r_ring, w, phase)
	if ring_style >= 1:
		var r2 := R * 0.71
		_ring(c, r2, wt, phase)
		r_star = r2
		if ring_style == 2:
			var ticks := n * maxi(2, roundi(24.0 / n))
			for i in ticks:
				var a := phase + TAU * (i + 0.5) / ticks
				draw_line(_p(c, r2 + w, a), _p(c, r_ring - w, a), ink, wt * 0.8, true)
		elif ring_style == 3:
			for i in n * 2:
				_dot(_p(c, (r_ring + r2) * 0.5, phase + TAU * (i + 0.5) / (n * 2)), (r_ring - r2) * 0.2)

	# --- Motivo da cor principal, à volta do anel ---
	_motif(m1, c, r_ring + w * 0.5, R, n, phase, w, variant)

	# --- Polígono ou estrela principal (com as pontas no anel de dentro) ---
	var r_free := r_star * cos(PI / n)   # raio livre no meio da estrela
	if star_style == 2 and n < 5:
		star_style = 1
	match star_style:
		0:
			_closed(_ngon(c, r_star, n, phase), w)
			if compound:
				_closed(_ngon(c, r_star, n, phase + PI / n), wt)
			elif n <= 5:
				# traços curtos do meio de cada lado até ao anel
				for i in n:
					var a := phase + TAU * (i + 0.5) / n
					draw_line(_p(c, r_free + w * 1.5, a), _p(c, r_star - w * 1.5, a), ink, wt, true)
		1:
			var pts := PackedVector2Array()
			for i in n * 2:
				pts.append(_p(c, r_star if i % 2 == 0 else r_star * spike_ratio, phase + PI * i / n))
			_closed(pts, w)
			r_free = r_star * spike_ratio * 0.92
		2:
			var k := 2 if n < 8 else k8
			_star_polygon(c, r_star, n, k, phase, w)
			r_free = r_star * cos(k * PI / n) / cos((k - 1) * PI / n)

	# --- Pontos em órbita ---
	match orbit_style:
		0:
			for i in n:
				_dot(_p(c, r_star, phase + TAU * i / n), w * 1.5)
		1:
			for i in n:
				draw_arc(_p(c, r_star, phase + TAU * i / n), w * 2.6, 0.0, TAU, 16, ink, wt, true)
		2:
			for i in n:
				_dot(_p(c, r_ring, phase + TAU * (i + 0.5) / n), w * 1.15)

	# --- Interior: anel, forma rodada ou raios, e o emblema da (segunda) cor ---
	var r_in := r_free * 0.8
	var r_c := minf(R * 0.2, r_in * 0.56)
	if r_in > R * 0.2:
		if multi:
			_ring(c, r_in, wt, phase)
			_motif(m2, c, r_c * 1.3, r_in - w * 0.5, n, phase + PI / n, wt, 1 - variant, true)
		else:
			match inner_style:
				0:
					_closed(_ngon(c, r_in, inner_m, inner_phase), wt)
					r_c = minf(r_c, r_in * cos(PI / inner_m) * 0.7)
				1:
					_ring(c, r_in, wt, phase)
					for i in n:
						var a := phase + TAU * i / n
						draw_line(_p(c, r_c * 1.35, a), _p(c, r_in - w, a), ink, wt, true)
				2:
					_ring(c, r_in, wt, phase)
					_closed(_ngon(c, r_in, inner_m, inner_phase), wt)
					r_c = minf(r_c, r_in * cos(PI / inner_m) * 0.7)
	else:
		r_c = r_free * 0.7
	_emblem(m2 if multi else m1, c, r_c, w)

# --- Motivos: bandas à volta de um anel, entre os raios r0 e r1 ---

## small: banda de dentro (metade dos elementos).
func _motif(kind: String, c: Vector2, r0: float, r1: float, n: int, phase: float, w: float, variant: int, small: bool = false) -> void:
	_density = 0.5 if small else 1.0
	match kind:
		"white":
			_motif_sun(c, r0, r1, n, phase, w, variant)
		"blue":
			_motif_waves(c, r0, r1, n, phase, w, variant)
		"black":
			_motif_thorns(c, r0, r1, n, phase, w, variant)
		"red":
			_motif_flames(c, r0, r1, n, phase, w, variant)
		"green":
			_motif_petals(c, r0, r1, n, phase, w, variant)
		_:
			_motif_gear(c, r0, r1, n, phase, w, variant)

## Quantos elementos à volta: um múltiplo de n perto do alvo (para alinharem com a estrela).
func _count(n: int, target: float) -> int:
	return n * maxi(1, roundi(target * _density / n))

## Branco: raios de sol alternados (longos e curtos), em cunha ou em traço com um ponto na ponta.
func _motif_sun(c: Vector2, r0: float, r1: float, n: int, phase: float, w: float, variant: int) -> void:
	var count := n * maxi(2, 2 * roundi(16.0 * _density / (2.0 * n)))   # par, para alternar
	var step := TAU / count
	for i in count:
		var a := phase + i * step
		var long := i % 2 == 0
		var tip := r1 if long else r0 + (r1 - r0) * 0.55
		if variant == 0:
			var hw := step * (0.2 if long else 0.15)
			_fill(PackedVector2Array([_p(c, r0, a - hw), _p(c, tip, a), _p(c, r0, a + hw)]))
		else:
			draw_line(_p(c, r0, a), _p(c, tip - w, a), ink, w * 0.8, true)
			if long:
				_dot(_p(c, tip - w, a), w * 1.1)

## Azul: duas linhas ondeadas paralelas (como o símbolo de Aquário) ou cristas de onda enroladas.
func _motif_waves(c: Vector2, r0: float, r1: float, n: int, phase: float, w: float, variant: int) -> void:
	var h := r1 - r0
	if variant == 0:
		var periods := _count(n, clampf(TAU * r0 / (h * 1.15), 8.0, 28.0) / _density)
		var segs := periods * 10
		for k in 2:
			var rm := r0 + h * (0.3 + 0.42 * k)
			var pts := PackedVector2Array()
			for i in segs:
				var a := phase + TAU * i / segs
				pts.append(_p(c, rm + h * 0.2 * sin(periods * (a - phase)), a))
			_closed(pts, w * 0.75)
	else:
		var count := _count(n, 8.0)
		var step := TAU / count
		var half := r0 * step * 0.5
		var rho := h * 0.36
		for i in count:
			var a := phase + i * step
			var local := PackedVector2Array()
			var crest := Vector2(0.2 * half, h * 0.92)
			for j in 9:
				local.append(Vector2(-half, 0.0).bezier_interpolate(Vector2(-0.8 * half, h * 0.5), Vector2(-0.4 * half, h * 0.92), crest, j / 8.0))
			var centre := crest - Vector2(0.0, rho)
			for j in range(1, 15):
				var t := j / 14.0
				var th := PI / 2.0 - TAU * 1.1 * t
				local.append(centre + Vector2(cos(th), sin(th)) * rho * (1.0 - 0.6 * t))
			draw_polyline(_bend_all(c, r0, a, local), ink, w * 0.8, true)

## Preto: coroa de espinhos em gancho ou um ramo farpado (espinhos alternados para fora e para dentro).
func _motif_thorns(c: Vector2, r0: float, r1: float, n: int, phase: float, w: float, variant: int) -> void:
	var h := r1 - r0
	if variant == 0:
		var count := _count(n, 16.0)
		var step := TAU / count
		var half := r0 * step * 0.3
		for i in count:
			_fill(_bend_all(c, r0, phase + i * step, _thorn(half, h * (1.0 if i % 2 == 0 else 0.62))))
	else:
		var rm := r0 + h * 0.45
		_ring(c, rm, w * 0.7, phase)
		var count := _count(n, 18.0)
		var step := TAU / count
		var half := rm * step * 0.22
		for i in count:
			var a := phase + (i + 0.5) * step
			if i % 2 == 0:
				_fill(_bend_all(c, rm, a, _thorn(half, h * 0.55)))
			else:
				var local := _thorn(half, h * 0.42)
				for j in local.size():
					local[j] = Vector2(local[j].x, -local[j].y)
				_fill(_bend_all(c, rm, a, local))

## Espinho em coordenadas locais (x ao longo do anel, y para fora), com a ponta curvada para o lado.
func _thorn(half: float, h: float) -> PackedVector2Array:
	var tip := Vector2(0.8 * half, h)
	var pts := PackedVector2Array()
	for j in 7:
		pts.append(Vector2(-half, 0.0).bezier_interpolate(Vector2(-0.9 * half, 0.5 * h), Vector2(-0.1 * half, 0.85 * h), tip, j / 6.0))
	for j in range(1, 7):
		pts.append(tip.bezier_interpolate(Vector2(0.35 * half, 0.72 * h), Vector2(0.55 * half, 0.3 * h), Vector2(half, 0.0), j / 6.0))
	return pts

## Vermelho: línguas de fogo (altas e baixas alternadas), cheias a rodopiar ou em contorno com núcleo.
func _motif_flames(c: Vector2, r0: float, r1: float, n: int, phase: float, w: float, variant: int) -> void:
	var h := r1 - r0
	var count := _count(n, clampf(TAU * r0 / (h * 1.1), 8.0, 28.0) / _density)
	if count % 2 == 1:
		count += n
	var step := TAU / count
	var half := r0 * step * 0.42
	for i in count:
		var a := phase + i * step
		var tall := i % 2 == 0
		var hh := h * (1.0 if tall else 0.72)
		if variant == 0:
			_fill(_bend_all(c, r0, a, _tongue(half, hh, 0.8)))
		else:
			var lean := 0.6 if tall else -0.6
			draw_polyline(_bend_all(c, r0, a, _tongue(half, hh, lean)), ink, w * 0.75, true)
			_fill(_bend_all(c, r0, a, _tongue(half * 0.42, hh * 0.5, lean)))

## Língua de fogo em coordenadas locais: base de -half a +half, ponta à altura h inclinada por lean.
func _tongue(half: float, h: float, lean: float) -> PackedVector2Array:
	var tip := Vector2(0.5 * lean * half, h)
	var pts := PackedVector2Array()
	for j in 9:
		pts.append(Vector2(-half, 0.0).bezier_interpolate(Vector2(-1.15 * half, 0.4 * h), Vector2((-0.3 + 0.4 * lean) * half, 0.72 * h), tip, j / 8.0))
	for j in range(1, 9):
		pts.append(tip.bezier_interpolate(Vector2((0.25 + 0.5 * lean) * half, 0.66 * h), Vector2(1.12 * half, 0.38 * h), Vector2(half, 0.0), j / 8.0))
	return pts

## Verde: pétalas (amêndoas) com nervura, ou pétalas cheias com outras pequenas entre elas.
func _motif_petals(c: Vector2, r0: float, r1: float, n: int, phase: float, w: float, variant: int) -> void:
	var count := _count(n, 10.0)
	var step := TAU / count
	for i in count:
		var a := phase + i * step
		var length := r1 - r0
		var half := minf(r0 * sin(step * 0.5) * 0.85, length * 0.36)
		var pts := _petal(_p(c, r0, a), Vector2(cos(a), sin(a)), length, half)
		if variant == 0:
			_closed(pts, w * 0.8)
			draw_line(_p(c, r0 + w, a), _p(c, r0 + length * 0.72, a), ink, w * 0.55, true)
		else:
			_fill(pts)
			var a2 := a + step * 0.5
			_fill(_petal(_p(c, r0, a2), Vector2(cos(a2), sin(a2)), length * 0.5, half * 0.45))

func _petal(base: Vector2, dir: Vector2, length: float, half: float) -> PackedVector2Array:
	var perp := Vector2(-dir.y, dir.x)
	var pts := PackedVector2Array()
	for j in 11:
		var t := j / 10.0
		pts.append(base + dir * length * t + perp * half * pow(sin(PI * t), 0.85))
	for j in range(9, 0, -1):
		var t := j / 10.0
		pts.append(base + dir * length * t - perp * half * pow(sin(PI * t), 0.85))
	return pts

## Incolor: dentes de engrenagem, em contorno ou cheios com cavilhas entre eles.
func _motif_gear(c: Vector2, r0: float, r1: float, n: int, phase: float, w: float, variant: int) -> void:
	var count := _count(n, 16.0)
	var step := TAU / count
	var top := r0 + (r1 - r0) * 0.72
	for i in count:
		var a := phase + i * step
		var tooth := PackedVector2Array([_p(c, r0, a - step * 0.3), _p(c, top, a - step * 0.17), _p(c, top, a + step * 0.17), _p(c, r0, a + step * 0.3)])
		if variant == 0:
			draw_polyline(tooth, ink, w * 0.8, true)
		else:
			_fill(tooth)
			_dot(_p(c, r0 + (r1 - r0) * 0.5, a + step * 0.5), w * 0.65)

# --- Emblemas do centro ---

func _emblem(kind: String, c: Vector2, r: float, w: float) -> void:
	if r < 2.0:
		return
	match kind:
		"white":
			# sol: disco, halo e oito raios curtos
			_dot(c, r * 0.36)
			draw_arc(c, r * 0.58, 0.0, TAU, 24, ink, w * 0.7, true)
			for i in 8:
				var a := -PI / 2.0 + TAU * i / 8.0
				draw_line(_p(c, r * 0.75, a), _p(c, r * (1.0 if i % 2 == 0 else 0.9), a), ink, w * 0.7, true)
		"blue":
			# gota
			var pts := PackedVector2Array()
			for j in 28:
				var t := TAU * j / 28.0
				pts.append(c + Vector2(r * 0.66 * sin(t) * sin(t * 0.5), -r * cos(t) + r * 0.08))
			_fill(pts)
		"black":
			# crescente
			var outer := _ngon(c, r * 0.85, 36, 0.0)
			var inner := _ngon(c + Vector2(r * 0.42, -r * 0.24), r * 0.7, 36, 0.0)
			for poly in Geometry2D.clip_polygons(outer, inner):
				if not Geometry2D.is_polygon_clockwise(poly):
					_fill(poly)
		"red":
			# chama com um núcleo (a sobreposição fica mais carregada)
			_fill(_bend_flat(c + Vector2(0, r * 0.75), _tongue(r * 0.55, r * 1.6, 0.7)))
			_fill(_bend_flat(c + Vector2(0, r * 0.75), _tongue(r * 0.28, r * 0.85, 0.7)))
		"green":
			# rebento: caule e duas folhas
			draw_line(c + Vector2(0, r * 0.85), c + Vector2(0, -r * 0.2), ink, w * 0.7, true)
			_fill(_petal(c + Vector2(0, r * 0.1), Vector2(-0.8, -0.6), r * 0.85, r * 0.3))
			_fill(_petal(c + Vector2(0, -r * 0.15), Vector2(0.8, -0.6), r * 0.85, r * 0.3))
		_:
			# losango com outro, cheio, no meio
			var d := PackedVector2Array([c + Vector2(0, -r), c + Vector2(r * 0.7, 0), c + Vector2(0, r), c + Vector2(-r * 0.7, 0)])
			_closed(d, w * 0.8)
			_fill(PackedVector2Array([c + Vector2(0, -r * 0.45), c + Vector2(r * 0.32, 0), c + Vector2(0, r * 0.45), c + Vector2(-r * 0.32, 0)]))

# --- Ajudantes de desenho ---

func _p(c: Vector2, r: float, a: float) -> Vector2:
	return c + Vector2(cos(a), sin(a)) * r

func _ngon(c: Vector2, r: float, sides: int, phase: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in sides:
		pts.append(_p(c, r, phase + TAU * i / sides))
	return pts

## Forma local (x ao longo do arco, y para fora) dobrada à volta do anel de raio r0, no ângulo a.
func _bend_all(c: Vector2, r0: float, a: float, local: PackedVector2Array) -> PackedVector2Array:
	var out := PackedVector2Array()
	out.resize(local.size())
	for i in local.size():
		out[i] = _p(c, r0 + local[i].y, a + local[i].x / r0)
	return out

## Forma local de pé (y para cima), com a base no ponto dado.
func _bend_flat(base: Vector2, local: PackedVector2Array) -> PackedVector2Array:
	var out := PackedVector2Array()
	out.resize(local.size())
	for i in local.size():
		out[i] = base + Vector2(local[i].x, -local[i].y)
	return out

func _ring(c: Vector2, r: float, w: float, phase: float) -> void:
	draw_arc(c, r, phase, phase + TAU, clampi(int(r * 0.8), 24, 128), ink, w, true)

## Contorno fechado: começa e acaba a meio do primeiro lado, para a junção não se notar.
func _closed(pts: PackedVector2Array, w: float) -> void:
	if pts.size() < 3:
		return
	var m := (pts[0] + pts[1]) * 0.5
	var out := PackedVector2Array([m])
	for i in range(1, pts.size()):
		out.append(pts[i])
	out.append(pts[0])
	out.append(m)
	draw_polyline(out, ink, w, true)

## Forma cheia com orla suave (antialias): o polígono e, à volta, uma tira que vai até transparente.
func _fill(pts: PackedVector2Array) -> void:
	var count := pts.size()
	if count < 3:
		return
	draw_colored_polygon(pts, ink)
	var area := 0.0
	for i in count:
		var p := pts[i]
		var q := pts[(i + 1) % count]
		area += p.x * q.y - q.x * p.y
	var out_sign := 1.0 if area > 0.0 else -1.0
	var points := PackedVector2Array()
	points.resize(count * 2)
	var cols := PackedColorArray()
	cols.resize(count * 2)
	var clear := Color(ink, 0.0)
	var indices := PackedInt32Array()
	for i in count:
		var prev := pts[(i - 1 + count) % count]
		var cur := pts[i]
		var nxt := pts[(i + 1) % count]
		var nrm := ((cur - prev).normalized().orthogonal() + (nxt - cur).normalized().orthogonal()).normalized()
		points[i] = cur
		points[count + i] = cur + nrm * out_sign * _feather
		cols[i] = ink
		cols[count + i] = clear
		var j := (i + 1) % count
		indices.append_array(PackedInt32Array([i, j, count + j, i, count + j, count + i]))
	RenderingServer.canvas_item_add_triangle_array(get_canvas_item(), indices, points, cols)

## Ponto cheio, com orla suave.
func _dot(p: Vector2, r: float) -> void:
	_fill(_ngon(p, r, clampi(int(r * 3.0), 10, 32), 0.0))

## Estrela {n/k}: liga cada vértice ao k-ésimo seguinte (em vários contornos se n e k não forem primos).
func _star_polygon(c: Vector2, r: float, n: int, k: int, phase: float, w: float) -> void:
	var loops := _gcd(n, k)
	var per := int(float(n) / loops)
	for l in loops:
		var pts := PackedVector2Array()
		for i in per:
			pts.append(_p(c, r, phase + TAU * ((l + i * k) % n) / n))
		_closed(pts, w)

func _gcd(a: int, b: int) -> int:
	while b != 0:
		var t := b
		b = a % b
		a = t
	return a
