class_name AttackFx
extends Node2D
## Efeito do golpe final (cosmético, 0.12.0), por cima do total do ataque. Desenhado em código:
## supernova (anel a crescer e clarão), fx_sparks (faíscas douradas com gravidade), fx_bubbles (bolhas
## a subir e a rebentar), fx_lightning (raios a cair do alto), fx_petals (pétalas às voltas),
## fx_shards (estilhaços de gelo a voar). Dura ~1 s e liberta-se sozinho; não faz nada com o
## movimento reduzido. "classic" = as partículas de sempre (não cria nada).

var kind := ""
var color := Color.WHITE
var _t := 0.0
var _dur := 1.0
var _parts: Array = []
var _rng := RandomNumberGenerator.new()

static func spawn(parent: Node, global_pos: Vector2, id: String) -> void:
	if id == "" or id == "classic" or parent == null or not parent.is_inside_tree() or not Settings.motion_ok():
		return
	var d := CardDB.get_cosmetic("effect", id)
	if d.is_empty():
		return
	var fx := AttackFx.new()
	fx.kind = id
	fx.color = Color(String(d.get("color", "#ffffff")))
	fx.z_index = 20
	parent.add_child(fx)
	fx.global_position = global_pos
	fx._setup()

func _setup() -> void:
	_rng.randomize()
	_dur = Settings.dur(1.0) if Settings.anim_scale() > 0.0 else 0.4
	match kind:
		"fx_sparks":
			for i in 40:
				var a := _rng.randf() * TAU
				_parts.append({"p": Vector2.ZERO, "v": Vector2(cos(a), sin(a)) * _rng.randf_range(160, 420), "r": _rng.randf_range(1.5, 3.5)})
		"fx_bubbles":
			for i in 22:
				_parts.append({"p": Vector2(_rng.randf_range(-120, 120), _rng.randf_range(-10, 30)), "v": Vector2(_rng.randf_range(-20, 20), -_rng.randf_range(80, 200)), "r": _rng.randf_range(4, 11), "pop": _rng.randf_range(0.5, 0.95)})
		"fx_lightning":
			for i in 3:
				var bolt := PackedVector2Array()
				var x := _rng.randf_range(-140, 140)
				var y := -360.0
				bolt.append(Vector2(x, y))
				while y < 0:
					y += _rng.randf_range(30, 60)
					x = lerpf(x, 0.0, 0.35) + _rng.randf_range(-24, 24)
					bolt.append(Vector2(x, minf(y, 0.0)))
				_parts.append({"pts": bolt, "delay": i * 0.08})
		"fx_petals":
			for i in 26:
				var a2 := _rng.randf() * TAU
				_parts.append({"p": Vector2.ZERO, "v": Vector2(cos(a2), sin(a2)) * _rng.randf_range(80, 260), "rot": _rng.randf() * TAU, "spin": _rng.randf_range(-6, 6)})
		"fx_shards":
			for i in 18:
				var a3 := _rng.randf() * TAU
				_parts.append({"p": Vector2.ZERO, "v": Vector2(cos(a3), sin(a3)) * _rng.randf_range(220, 480), "rot": a3, "len": _rng.randf_range(10, 24)})

func _process(delta: float) -> void:
	_t += delta
	if _t >= _dur:
		queue_free()
		return
	for p in _parts:
		if p.has("v"):
			p["p"] += p["v"] * delta
			if kind == "fx_sparks" or kind == "fx_petals":
				p["v"] += Vector2(0, 520 if kind == "fx_sparks" else 120) * delta
				p["v"] *= 0.985
		if p.has("spin"):
			p["rot"] += p["spin"] * delta
	queue_redraw()

func _draw() -> void:
	var k := clampf(_t / maxf(_dur, 0.01), 0.0, 1.0)
	var fade := 1.0 - k
	match kind:
		"supernova":
			draw_circle(Vector2.ZERO, 30 + 40 * k, Color(color, 0.35 * fade))
			draw_arc(Vector2.ZERO, 20 + 260 * k, 0, TAU, 64, Color(color, 0.9 * fade), 6.0 * fade + 1.0, true)
			draw_arc(Vector2.ZERO, 10 + 160 * k, 0, TAU, 48, Color(1, 1, 1, 0.6 * fade), 3.0, true)
		"fx_sparks":
			for p in _parts:
				draw_circle(p["p"], float(p["r"]) * fade + 0.5, Color(color, fade))
		"fx_bubbles":
			for p in _parts:
				if k < float(p["pop"]):
					draw_arc(p["p"], float(p["r"]), 0, TAU, 20, Color(color, 0.8), 1.6, true)
					draw_circle(Vector2(p["p"]) + Vector2(-0.3, -0.3) * float(p["r"]), float(p["r"]) * 0.22, Color(1, 1, 1, 0.7))
				elif k < float(p["pop"]) + 0.08:
					draw_arc(p["p"], float(p["r"]) * 1.6, 0, TAU, 20, Color(color, 0.5), 1.0, true)
		"fx_lightning":
			for p in _parts:
				var local := k - float(p["delay"])
				if local < 0.0 or local > 0.45:
					continue
				var a := 1.0 - local / 0.45
				draw_polyline(p["pts"], Color(color, a), 4.0, true)
				draw_polyline(p["pts"], Color(1, 1, 1, a), 1.6, true)
			draw_circle(Vector2.ZERO, 26 * fade, Color(color, 0.3 * fade))
		"fx_petals":
			for p in _parts:
				var dir := Vector2(cos(p["rot"]), sin(p["rot"]))
				var c: Vector2 = p["p"]
				var pts := PackedVector2Array([c + dir * 7, c + dir.orthogonal() * 3.5, c - dir * 7, c - dir.orthogonal() * 3.5])
				draw_colored_polygon(pts, Color(color, fade))
		"fx_shards":
			for p in _parts:
				var d := Vector2(cos(p["rot"]), sin(p["rot"]))
				var c2: Vector2 = p["p"]
				var l := float(p["len"])
				var pts2 := PackedVector2Array([c2 + d * l, c2 + d.orthogonal() * 2.5, c2 - d * l * 0.4, c2 - d.orthogonal() * 2.5])
				draw_colored_polygon(pts2, Color(color, fade))
