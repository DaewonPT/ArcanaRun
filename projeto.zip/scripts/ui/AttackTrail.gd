class_name AttackTrail
extends Node2D
## 0.12.0: no golpe final, cada criatura atacante lança um cometa da sua cor até ao inimigo (arco a
## acelerar, com rasto que se apaga), que rebenta numa pequena explosão (ColorBurst) ao chegar.
## Desenhado em código; não faz nada com o movimento reduzido nem na velocidade instantânea.

const MAX_TRAIL := 14

var color := Color.WHITE
var color_key := "colorless"
var _from := Vector2.ZERO
var _to := Vector2.ZERO
var _ctrl := Vector2.ZERO
var _delay := 0.0
var _dur := 0.3
var _t := 0.0
var _trail: Array[Vector2] = []
var _arrived := false

## Lança um cometa de from para to (posições globais), depois de `delay` segundos.
static func fly(parent: Node, from: Vector2, to: Vector2, color_key: String, delay: float = 0.0) -> AttackTrail:
	if parent == null or not is_instance_valid(parent) or not parent.is_inside_tree():
		return null
	if not Settings.motion_ok() or Settings.anim_scale() <= 0.0:
		return null
	var a := AttackTrail.new()
	a.color_key = color_key
	a.color = (CardView.COLORS.get(color_key, CardView.COLORS.colorless) as Color).lightened(0.25)
	a._from = from
	a._to = to
	var mid := from.lerp(to, 0.5)
	var side := -1.0 if from.x < to.x else 1.0
	a._ctrl = mid + Vector2(side * 60.0, -minf(160.0, absf(to.y - from.y) * 0.6 + 60.0))
	a._delay = delay
	a._dur = maxf(0.16, Settings.dur(0.32))
	a.z_index = 18
	a.top_level = true
	parent.add_child(a)
	a.global_position = Vector2.ZERO
	a.visible = false
	return a

func _process(delta: float) -> void:
	if _delay > 0.0:
		_delay -= delta
		return
	visible = true
	_t += delta
	var k := clampf(_t / _dur, 0.0, 1.0)
	var e := k * k   # acelera
	var p := _from.lerp(_ctrl, e).lerp(_ctrl.lerp(_to, e), e)
	if not _arrived:
		_trail.push_front(p)
		while _trail.size() > MAX_TRAIL:
			_trail.pop_back()
	else:
		if not _trail.is_empty():
			_trail.pop_back()
	if k >= 1.0 and not _arrived:
		_arrived = true
		ColorBurst.spawn(get_parent(), _to, color_key)
	queue_redraw()
	if _arrived and _trail.is_empty():
		queue_free()

func _draw() -> void:
	var n := _trail.size()
	if n == 0:
		return
	for i in range(n - 1):
		var a := 1.0 - float(i) / n
		draw_line(_trail[i], _trail[i + 1], Color(color, 0.75 * a), 2.0 + 7.0 * a, true)
	if not _arrived:
		var head := _trail[0]
		draw_circle(head, 15.0, Color(color, 0.18))
		draw_circle(head, 9.0, Color(color, 0.45))
		draw_circle(head, 5.0, Color(1, 1, 1, 0.95))
