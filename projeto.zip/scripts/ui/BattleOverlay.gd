class_name BattleOverlay
extends Control
## 0.13.0: camada por cima da Arena (não corta nas margens da faixa das criaturas):
##  - números de ordem de disparo (1, 2, 3…) no canto de cada criatura (Primeiro Golpe primeiro);
##  - etiquetas do que o inimigo vai fazer a cada criatura no fim do turno (BLOQUEIA, MORRE, PRESA…);
##  - setas tracejadas do retrato do inimigo para as criaturas que vai prender, copiar, destruir, exilar ou
##    matar (BattleManager.threat_preview). O tracejado anda devagar (parado com "reduzir movimento").

const DASH := 11.0
const GAP := 7.0
const WIDTH := 2.6
const BADGE_R := 12.0

## Painel do inimigo (origem das setas) e a altura de onde saem (a do retrato).
var from_node: Control
var from_y := 40.0
## [[Control, n.º]] — números de ordem.
var badges: Array = []
## [{"node": Control, "text": String, "icon": String, "color": Color, "arrow": bool}]
var threats: Array = []
var _t := 0.0
var _acc := 0.0
var _font: Font
## 0.16.0 (74): no máximo 24 redesenhos por segundo (o tracejado anda devagar e as cartas só se mexem às vezes).
const REDRAW_FPS := 24.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	z_index = 30
	_font = get_theme_font("font", "Label")

func set_data(p_from: Control, p_badges: Array, p_threats: Array) -> void:
	from_node = p_from
	badges = p_badges
	threats = p_threats
	set_process(not (badges.is_empty() and threats.is_empty()))
	queue_redraw()

func clear() -> void:
	set_data(from_node, [], [])

## As cartas mexem-se (arrastar, animações): redesenha a cada frame enquanto houver o que mostrar.
func _process(delta: float) -> void:
	if Settings.motion_ok():
		_t += delta
	_acc += delta
	if _acc >= 1.0 / REDRAW_FPS:
		_acc = 0.0
		queue_redraw()

func _draw() -> void:
	if not is_visible_in_tree():
		return
	var inv := get_global_transform().affine_inverse()
	# 1. Setas (por baixo das etiquetas).
	if from_node != null and is_instance_valid(from_node) and from_node.is_visible_in_tree():
		# Sai da borda direita do painel do inimigo, à altura do retrato (não risca o nome).
		var fr := from_node.get_global_rect()
		var start := inv * Vector2(fr.end.x - 2.0, fr.position.y + from_y)
		var i := 0
		for t in threats:
			if not bool(t.get("arrow", false)):
				continue
			var node: Control = t.get("node")
			if not _ok(node):
				continue
			var r := node.get_global_rect()
			var end := inv * Vector2(r.position.x + r.size.x * 0.5, r.position.y + 2.0)
			var ctrl := Vector2((start.x + end.x) * 0.5, minf(start.y, end.y) - 40.0 - 8.0 * i)
			_dashed_curve(start, ctrl, end, t.get("color", Color(1, 0.3, 0.3)))
			i += 1
	# 2. Etiquetas das ameaças, a 70 % da altura da carta.
	for t in threats:
		var node: Control = t.get("node")
		if not _ok(node):
			continue
		var r := node.get_global_rect()
		var center := inv * Vector2(r.position.x + r.size.x * 0.5, r.position.y + r.size.y * 0.7 + float(t.get("dy", 0.0)))
		_chip(center, String(t.get("text", "")), t.get("color", Color(1, 0.3, 0.3)))
	# 3. Números de ordem, no canto de cima à esquerda.
	for b in badges:
		var node: Control = b[0]
		if not _ok(node):
			continue
		var r := node.get_global_rect()
		var c := inv * (r.position + Vector2(0.0, 2.0))
		draw_circle(c + Vector2(1, 2), BADGE_R, Color(0, 0, 0, 0.45))
		draw_circle(c, BADGE_R, Color(0.12, 0.09, 0.2, 0.96))
		draw_arc(c, BADGE_R, 0.0, TAU, 28, UiKit.GOLD, 2.0, true)
		var txt := str(int(b[1]))
		var fs := 15
		var sz := _font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
		draw_string(_font, c + Vector2(-sz.x * 0.5, fs * 0.36), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, UiKit.GOLD)

func _ok(node: Control) -> bool:
	return node != null and is_instance_valid(node) and not node.is_queued_for_deletion() and node.is_visible_in_tree() and node.modulate.a > 0.05

## Etiqueta com fundo da cor da ameaça e texto claro.
func _chip(center: Vector2, text: String, col: Color) -> void:
	var fs := 13
	var sz := _font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
	var rect := Rect2(center - Vector2(sz.x * 0.5 + 9.0, 11.0), Vector2(sz.x + 18.0, 22.0))
	var st := StyleBoxFlat.new()
	st.bg_color = Color(col.darkened(0.35), 0.95)
	st.set_corner_radius_all(11)
	st.border_color = Color(col.lightened(0.35), 0.95)
	st.set_border_width_all(1)
	st.shadow_color = Color(0, 0, 0, 0.4)
	st.shadow_size = 3
	draw_style_box(st, rect)
	draw_string(_font, Vector2(rect.position.x + 9.0, rect.position.y + 16.0), text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color.WHITE)

func _dashed_curve(a: Vector2, c: Vector2, b: Vector2, col: Color) -> void:
	var pts := PackedVector2Array()
	var n := 40
	for k in n + 1:
		var u := float(k) / n
		pts.append(a.lerp(c, u).lerp(c.lerp(b, u), u))
	var period := DASH + GAP
	var offset := period - fmod(_t * 26.0, period)   # o tracejado anda na direção da ponta
	var shadow := Color(0, 0, 0, 0.45)
	var dist := 0.0
	for k in n - 2:   # o fim fica para a ponta
		var p0 := pts[k]
		var p1 := pts[k + 1]
		var seg := p0.distance_to(p1)
		if seg <= 0.001:
			continue
		var s := 0.0
		while s < seg:
			var ph := fposmod(dist + s + offset, period)
			var on := ph < DASH
			var e := minf(seg, s + maxf(0.01, (DASH - ph) if on else (period - ph)))
			if on:
				var q0 := p0.lerp(p1, s / seg)
				var q1 := p0.lerp(p1, e / seg)
				draw_line(q0 + Vector2(1, 1.5), q1 + Vector2(1, 1.5), shadow, WIDTH + 1.0, true)
				draw_line(q0, q1, col, WIDTH, true)
			s = e
		dist += seg
	var dir := (pts[n] - pts[n - 3]).normalized()
	var side := Vector2(-dir.y, dir.x)
	var tip := pts[n]
	var head := PackedVector2Array([tip, tip - dir * 14.0 + side * 7.5, tip - dir * 14.0 - side * 7.5])
	var off := Vector2(1, 1.5)
	draw_colored_polygon(PackedVector2Array([head[0] + off, head[1] + off, head[2] + off]), shadow)
	draw_colored_polygon(head, col)
	draw_circle(pts[0], 4.0, col)
