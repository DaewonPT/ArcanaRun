class_name ManaCurve
extends Control
## 0.13.0: curva de mana de um baralho — uma barra por custo (0 a 7+), com as Criaturas por baixo e
## os Feitiços e Encantamentos por cima, o número de cartas em cima de cada barra e o custo por baixo.
## Os Terrenos não entram na curva (contam-se na linha de resumo, `summary()`).

const MAX_COST := 7   # a última barra junta 7 e mais
const CREATURE_COLOR := Color(0.95, 0.66, 0.3)
const SPELL_COLOR := Color(0.45, 0.68, 1.0)
const ENCHANT_COLOR := Color(0.74, 0.5, 0.95)

var creatures: Array[int] = []
var spells: Array[int] = []
var enchants: Array[int] = []
var lands := 0
var font_size := 14

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(300, 96)
	_reset()

func _reset() -> void:
	creatures.clear()
	spells.clear()
	enchants.clear()
	for i in MAX_COST + 1:
		creatures.append(0)
		spells.append(0)
		enchants.append(0)
	lands = 0

## Conta as cartas (CardData ou CardInstance).
func set_cards(list: Array) -> void:
	_reset()
	for x in list:
		var d: CardData = x.data if x is CardInstance else x as CardData
		if d == null or d.is_curse():
			continue
		if d.is_land():
			lands += 1
			continue
		var c := clampi(d.cost, 0, MAX_COST)
		if d.is_creature():
			creatures[c] += 1
		elif d.is_enchantment():
			enchants[c] += 1
		else:
			spells[c] += 1
	queue_redraw()

func count_at(cost: int) -> int:
	var c := clampi(cost, 0, MAX_COST)
	return creatures[c] + spells[c] + enchants[c]

## Custo médio das cartas que não são Terrenos (0 se não houver).
func average_cost() -> float:
	var n := 0
	var total := 0
	for i in MAX_COST + 1:
		var k := creatures[i] + spells[i] + enchants[i]
		n += k
		total += k * i
	return float(total) / float(n) if n > 0 else 0.0

## "12 criaturas · 6 feitiços · 2 encantamentos · 5 terrenos · custo médio 2,4"
func summary() -> String:
	var cr := 0
	var sp := 0
	var en := 0
	for i in MAX_COST + 1:
		cr += creatures[i]
		sp += spells[i]
		en += enchants[i]
	return tr("Criaturas %d · Feitiços %d · Encantamentos %d · Terrenos %d · custo médio %s") % [cr, sp, en, lands, decimal(average_cost())]

## Uma casa decimal, com vírgula em português ("2,4") e ponto em inglês ("2.4").
static func decimal(x: float) -> String:
	var t := "%.1f" % x
	return t.replace(".", ",") if TranslationServer.get_locale().begins_with("pt") else t

func _draw() -> void:
	var font := get_theme_default_font()
	var fs := font_size
	var top_pad := float(fs) + 4.0
	var bottom_pad := float(fs) + 6.0
	var h := size.y - top_pad - bottom_pad
	if h <= 4.0:
		return
	var n := MAX_COST + 1
	var slot := size.x / float(n)
	var bar_w := slot * 0.62
	var peak := 1
	for i in n:
		peak = maxi(peak, count_at(i))
	draw_line(Vector2(0, top_pad + h), Vector2(size.x, top_pad + h), Color(1, 1, 1, 0.25), 1.0)
	for i in n:
		var x := slot * i + (slot - bar_w) / 2.0
		var y := top_pad + h
		for part in [[creatures[i], CREATURE_COLOR], [spells[i], SPELL_COLOR], [enchants[i], ENCHANT_COLOR]]:
			var k := int(part[0])
			if k <= 0:
				continue
			var bh := h * float(k) / float(peak)
			draw_rect(Rect2(x, y - bh, bar_w, bh), part[1])
			y -= bh
		var total := count_at(i)
		var label := str(i) if i < MAX_COST else "%d+" % MAX_COST
		draw_string(font, Vector2(slot * i, size.y - 4.0), label, HORIZONTAL_ALIGNMENT_CENTER, slot, fs, Color(1, 1, 1, 0.75))
		if total > 0:
			draw_string(font, Vector2(slot * i, y - 3.0), str(total), HORIZONTAL_ALIGNMENT_CENTER, slot, fs, Color.WHITE)
