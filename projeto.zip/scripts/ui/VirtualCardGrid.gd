class_name VirtualCardGrid
extends ScrollContainer
## 0.16.1 (71): grelha de cartas que só cria as que se veem (mais uma fila por cima e outra por baixo) e as
## reaproveita ao deslizar: a Coleção tem quase 500 cartas e antes criava-as todas ao abrir. Mostra uma lista
## de CardData (set_items); as que ainda não descobriste aparecem com as costas e não se tocam.
## Tocar (ou manter o dedo) numa carta descoberta emite card_pressed.

signal card_pressed(card: CardInstance)

const CARD_VIEW := preload("res://scenes/ui/CardView.tscn")
const H_SEP := 10.0
const V_SEP := 10.0

## Diz se a carta já foi descoberta (sem isto, contam todas como descobertas).
var seen_fn: Callable = Callable()
## Costas das cartas por descobrir.
var back_id := "classic"
var items: Array = []
var columns := 1
var _content: Control
var _cell := CardView.SIZE_NORMAL
var _shown: Dictionary = {}          # índice → nó (CardView ou CardBack)
var _free_views: Array[CardView] = []
var _free_backs: Array[CardBack] = []
var _queued := false
var _x0 := 0.0   # margem à esquerda, para as colunas ficarem centradas

func _init() -> void:
	horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_content = Control.new()
	_content.name = "Content"
	_content.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(_content)

func _ready() -> void:
	get_v_scroll_bar().value_changed.connect(_on_scroll)
	resized.connect(_queue_relayout)

## A lista a mostrar (pela ordem); volta ao topo.
func set_items(list: Array) -> void:
	items = list
	for idx in _shown.keys():
		_release(int(idx))
	scroll_vertical = 0
	_queue_relayout()

## Os nós que estão agora no ecrã (para os testes e as capturas).
func visible_nodes() -> Array:
	return _shown.values()

func _queue_relayout() -> void:
	if _queued:
		return
	_queued = true
	_relayout.call_deferred()

func _relayout() -> void:
	_queued = false
	if not is_inside_tree():
		return
	_cell = CardView.SIZE_COMPACT if Settings.compact else CardView.SIZE_NORMAL
	var w := size.x - 14.0   # a barra de deslizar
	columns = maxi(1, int((w + H_SEP) / (_cell.x + H_SEP)))
	_x0 = maxf(0.0, (w - (columns * _cell.x + (columns - 1) * H_SEP)) * 0.5)
	var rows := ceili(items.size() / float(columns))
	_content.custom_minimum_size = Vector2(maxf(w, 1.0), maxf(rows * (_cell.y + V_SEP) - V_SEP, 1.0))
	for idx in _shown.keys():
		_place(_shown[idx], int(idx))
	_update()

func _on_scroll(_v: float) -> void:
	_update()

## Cria (ou reaproveita) as cartas das filas à vista e larga as que saíram.
func _update() -> void:
	if items.is_empty():
		for idx in _shown.keys():
			_release(int(idx))
		return
	var row_h := _cell.y + V_SEP
	var top := float(scroll_vertical)
	var first_row := maxi(0, int(top / row_h) - 1)
	var last_row := int((top + maxf(size.y, row_h)) / row_h) + 1
	var lo := first_row * columns
	var hi := mini(items.size(), (last_row + 1) * columns)
	for idx in _shown.keys():
		if int(idx) < lo or int(idx) >= hi:
			_release(int(idx))
	for idx in range(lo, hi):
		if not _shown.has(idx):
			_shown[idx] = _make(idx)

func _make(idx: int) -> Control:
	var d: CardData = items[idx]
	var seen := not seen_fn.is_valid() or bool(seen_fn.call(d))
	var n: Control
	if seen:
		var v: CardView = _free_views.pop_back() if not _free_views.is_empty() else null
		if v == null:
			v = CARD_VIEW.instantiate()
			v.pressed.connect(_on_pressed)
			v.long_pressed.connect(_on_pressed)
			_content.add_child(v)
		v.visible = true
		v.size = _cell
		v.set_meta("data", d)
		v.setup(CardDB.new_instance(d.id))
		n = v
	else:
		var b: CardBack = _free_backs.pop_back() if not _free_backs.is_empty() else null
		if b == null:
			b = CardBack.new()
			_content.add_child(b)
		b.back_id = back_id
		b.visible = true
		b.modulate = Color(0.8, 0.8, 0.85)
		b.set_meta("data", d)
		n = b
	_place(n, idx)
	return n

func _place(n: Control, idx: int) -> void:
	var col := idx % columns
	var row := idx / columns
	n.position = Vector2(_x0 + col * (_cell.x + H_SEP), row * (_cell.y + V_SEP))
	n.size = _cell

func _release(idx: int) -> void:
	var n: Control = _shown.get(idx)
	_shown.erase(idx)
	if n == null or not is_instance_valid(n):
		return
	n.visible = false
	if n is CardView:
		_free_views.append(n)
	elif n is CardBack:
		_free_backs.append(n)

func _on_pressed(c: CardInstance) -> void:
	card_pressed.emit(c)
