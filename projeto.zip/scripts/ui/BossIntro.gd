class_name BossIntro
extends Control
## 0.12.0: entrada dos bosses (e da Némesis). O ecrã escurece, entram faixas de cinema em cima e em baixo,
## o retrato do boss cai do tamanho gigante com um estrondo (rugido, abanão), o nome entra pela direita e
## uma faixa de luz varre o ecrã. Tocar em qualquer sítio salta. Com o movimento reduzido é só um fundido.
## 0.12.1: o tempo para ler (nome e regra) já não acelera com a velocidade das animações — depende do
## tamanho do texto (3 a 7 s) — e a entrada aparece também na velocidade instantânea (sem animação).

signal finished

const READ_MIN := 3.0      # segundos mínimos com o texto no ecrã (não acelera)
const READ_MAX := 7.0
const READ_PER_CHAR := 0.045
const TAP_GRACE := 0.4     # um toque logo a seguir à entrada não a fecha (o dedo ainda vinha do mapa)

var _enemy: Dictionary = {}
var _dim: ColorRect
var _bar_top: ColorRect
var _bar_bot: ColorRect
var _portrait: EnemyPortrait
var _name: Label
var _sub: Label
var _sweep: ColorRect
var _text: VBoxContainer
var _hint: Label
var _done := false
var _born_ms := 0

## Mostra a entrada por cima de `parent` (a cena da batalha). Devolve null se não houver entrada.
static func play(parent: Control, enemy: Dictionary, archetype: String, tint: Color, subtitle: String) -> BossIntro:
	if parent == null or not parent.is_inside_tree():
		return null
	if DisplayServer.get_name() == "headless":
		return null
	var b := BossIntro.new()
	b._enemy = enemy
	parent.add_child(b)
	b._build(archetype, tint, subtitle)
	b._run()
	return b

## Duração mínima (entrada + leitura + saída); a real cresce com o texto e acaba com um toque.
static func duration() -> float:
	return Settings.dur(0.45) + READ_MIN + Settings.dur(0.4)

## Segundos para ler o nome e a regra (não depende da velocidade das animações).
static func read_time(text: String) -> float:
	return clampf(READ_MIN + READ_PER_CHAR * float(text.length()) - 1.2, READ_MIN, READ_MAX)

func _init() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	z_index = 60   # por cima das dicas da batalha (50)

func _build(archetype: String, tint: Color, subtitle: String) -> void:
	var nemesis := String(_enemy.get("variant", "")) == "nemesis"
	var accent := Color(0.95, 0.35, 0.3) if not nemesis else Color(0.75, 0.45, 1.0)
	_dim = ColorRect.new()
	_dim.color = Color(0.02, 0.01, 0.04, 0.0)
	_dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	_dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_dim)
	var vp := get_viewport_rect().size
	_bar_top = ColorRect.new()
	_bar_top.color = Color(0, 0, 0, 0.95)
	_bar_top.size = Vector2(vp.x, 86)
	_bar_top.position = Vector2(0, -86)
	_bar_top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_bar_top)
	_bar_bot = ColorRect.new()
	_bar_bot.color = Color(0, 0, 0, 0.95)
	_bar_bot.size = Vector2(vp.x, 86)
	_bar_bot.position = Vector2(0, vp.y)
	_bar_bot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_bar_bot)
	_sweep = ColorRect.new()
	_sweep.color = Color(accent.lightened(0.5), 0.0)
	_sweep.size = Vector2(140, vp.y * 1.6)
	_sweep.position = Vector2(-300, -vp.y * 0.3)
	_sweep.rotation = 0.35
	_sweep.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_sweep)
	_portrait = EnemyPortrait.new()
	_portrait.archetype = archetype
	_portrait.tint = tint
	_portrait.boss = true
	_portrait.art_id = String(_enemy.get("id", ""))
	_portrait.size = Vector2(240, 240)
	_portrait.position = Vector2(vp.x * 0.27 - 120, vp.y * 0.5 - 120)
	_portrait.pivot_offset = Vector2(120, 120)
	add_child(_portrait)
	_text = VBoxContainer.new()
	_text.name = "Text"
	_text.add_theme_constant_override("separation", 4)
	_text.position = Vector2(vp.x * 0.45, vp.y * 0.5 - 100)
	_text.custom_minimum_size = Vector2(vp.x * 0.5, 0)
	_text.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_text)
	var title := UiKit.label(tr("NÉMESIS") if nemesis else tr("BOSS"), 26, accent)
	title.name = "Kind"
	_text.add_child(title)
	_name = UiKit.label(tr(String(_enemy.get("name", ""))), 50, Color(1, 0.93, 0.8), true)
	_name.name = "BossName"
	_name.add_theme_color_override("font_outline_color", Color(0.25, 0.04, 0.06))
	_name.add_theme_constant_override("outline_size", 10)
	_text.add_child(_name)
	_sub = UiKit.label(subtitle, 20, Color(0.92, 0.86, 0.95), true)
	_sub.name = "Sub"
	_text.add_child(_sub)
	_text.modulate.a = 0.0
	_hint = UiKit.label(tr("Toca para continuar"), 16, Color(0.85, 0.8, 0.9))
	_hint.name = "Hint"
	_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hint.size = Vector2(vp.x, 24)
	_hint.position = Vector2(0, vp.y - 86.0 + 31.0)
	_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hint.modulate.a = 0.0
	add_child(_hint)

func _run() -> void:
	_born_ms = Time.get_ticks_msec()
	var motion := Settings.motion_ok()
	var t_in := Settings.dur(0.45)
	var hold := read_time(_name.text + " " + _sub.text)
	var vp := get_viewport_rect().size
	var tw := create_tween().set_parallel(true)
	tw.tween_property(_dim, "color:a", 0.8, t_in)
	tw.tween_property(_bar_top, "position:y", 0.0, t_in).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
	tw.tween_property(_bar_bot, "position:y", vp.y - 86.0, t_in).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
	_portrait.modulate.a = 0.0
	if motion:
		_portrait.scale = Vector2(2.4, 2.4)
		tw.tween_property(_portrait, "scale", Vector2.ONE, t_in).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
		tw.tween_property(_portrait, "modulate:a", 1.0, t_in * 0.6)
		var x0 := _text.position.x
		_text.position.x = x0 + 160.0
		tw.tween_property(_text, "position:x", x0, t_in * 1.2).set_delay(t_in * 0.7).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
		tw.tween_property(_sweep, "position:x", vp.x + 200.0, t_in * 2.2).set_delay(t_in)
		tw.tween_property(_sweep, "color:a", 0.22, t_in * 0.4).set_delay(t_in)
	else:
		tw.tween_property(_portrait, "modulate:a", 1.0, t_in)
	tw.tween_property(_text, "modulate:a", 1.0, t_in * 0.8).set_delay(t_in * 0.7)
	tw.tween_property(_hint, "modulate:a", 0.75, 0.3).set_delay(t_in + 0.6)
	# Linha do tempo à parte: estrondo quando o retrato chega e fecho depois de o mostrar.
	var seq := create_tween()
	seq.tween_interval(t_in)
	seq.tween_callback(_impact)
	seq.tween_interval(hold)
	seq.tween_callback(close)

## O retrato bate no chão: rugido, vibração e abanão.
func _impact() -> void:
	Sfx.boss()
	Settings.vibrate(90)
	if Settings.motion_ok():
		var base := position
		var tw := create_tween()
		for i in 5:
			var off := Vector2(randf_range(-12, 12), randf_range(-9, 9)) * (1.0 - i / 5.0)
			tw.tween_property(self, "position", base + off, 0.03)
		tw.tween_property(self, "position", base, 0.04)
		_portrait.hit()

func close() -> void:
	if _done:
		return
	_done = true
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var tw := create_tween()
	tw.tween_property(self, "modulate:a", 0.0, Settings.dur(0.4))
	tw.tween_callback(func():
		finished.emit()
		queue_free())

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and (event as InputEventMouseButton).pressed:
		accept_event()
		if Time.get_ticks_msec() - _born_ms >= int(TAP_GRACE * 1000.0):
			close()
