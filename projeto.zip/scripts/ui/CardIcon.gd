class_name CardIcon
extends Control
## Ícone vetorial desenhado em código (sem imagens): tipo de carta ou pip de cor.
##   kind: "creature" (espada) · "sorcery" (pergaminho) · "instant" (raio) · "land" (montanha) · "pip" (círculo)
##         · "seal" · "relic" · "curse" (losango riscado) · "climate" (sol e nuvem) · "contract" (pergaminho
##         com selo) · "wheel" (roda do Tribunal) · "chain" (elos: a carta combina com o baralho)
##         · 0.11.0: "enchantment" (estrela num anel) · "mana" (cristal) · "vigilance" (olho) ·
##         "lifelink" (coração com +) · "protection" (escudo com estrela)
##         · 0.12.0: "flying" (asa) · "trample" (seta a furar o escudo) · "first_strike" (duas setas) ·
##         "landfall" (montanha com seta: Chegada de Terreno)

var kind: String = "creature":
	set(v):
		kind = v
		queue_redraw()
var mana_color: String = ""   # cor de mana de um pip ("white", "blue"…): símbolo no modo daltónico
var color: Color = Color.WHITE:
	set(v):
		color = v
		queue_redraw()

func _init(p_kind: String = "creature", p_color: Color = Color.WHITE, size_px: float = 20.0) -> void:
	kind = p_kind
	color = p_color
	custom_minimum_size = Vector2(size_px, size_px)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	var s := minf(size.x, size.y)
	var o := (size - Vector2(s, s)) / 2.0
	var u := s / 20.0   # unidade: o ícone é desenhado numa grelha 20×20
	match kind:
		"creature":
			# lâmina diagonal
			draw_polygon(PackedVector2Array([o + Vector2(15, 2) * u, o + Vector2(18, 5) * u, o + Vector2(8, 15) * u, o + Vector2(5, 12) * u]), PackedColorArray([color]))
			# guarda e punho
			draw_line(o + Vector2(3, 10) * u, o + Vector2(10, 17) * u, color, 2.2 * u, true)
			draw_line(o + Vector2(5, 15) * u, o + Vector2(2, 18) * u, color, 2.6 * u, true)
		"sorcery":
			# pergaminho: retângulo com duas pontas enroladas
			var r := Rect2(o + Vector2(4, 3) * u, Vector2(12, 14) * u)
			draw_rect(r, color, false, 2.0 * u, true)
			draw_line(o + Vector2(7, 7) * u, o + Vector2(13, 7) * u, color, 1.6 * u, true)
			draw_line(o + Vector2(7, 10) * u, o + Vector2(13, 10) * u, color, 1.6 * u, true)
			draw_line(o + Vector2(7, 13) * u, o + Vector2(11, 13) * u, color, 1.6 * u, true)
		"instant":
			# raio
			draw_polygon(PackedVector2Array([o + Vector2(11, 1) * u, o + Vector2(4, 11) * u, o + Vector2(9, 11) * u, o + Vector2(7, 19) * u, o + Vector2(16, 8) * u, o + Vector2(11, 8) * u]), PackedColorArray([color]))
		"land":
			# duas montanhas e uma linha de chão
			draw_polygon(PackedVector2Array([o + Vector2(1, 17) * u, o + Vector2(8, 5) * u, o + Vector2(13, 13) * u, o + Vector2(11, 17) * u]), PackedColorArray([color]))
			draw_polygon(PackedVector2Array([o + Vector2(9, 17) * u, o + Vector2(14, 8) * u, o + Vector2(19, 17) * u]), PackedColorArray([Color(color, 0.75)]))
		"pip":
			draw_circle(o + Vector2(10, 10) * u, 7.0 * u, color)
			draw_arc(o + Vector2(10, 10) * u, 7.0 * u, 0.0, TAU, 24, Color(0, 0, 0, 0.45), 1.5 * u, true)
			if mana_color != "" and Settings.colorblind:
				_draw_mana_symbol(o, u)
		"seal":
			# selo de cera: círculo cheio, anel e estrela clara no meio
			draw_circle(o + Vector2(10, 10) * u, 9.0 * u, color)
			draw_arc(o + Vector2(10, 10) * u, 7.0 * u, 0.0, TAU, 28, Color(1, 1, 1, 0.55), 1.2 * u, true)
			draw_polygon(PackedVector2Array([o + Vector2(10, 4) * u, o + Vector2(11.6, 8.4) * u, o + Vector2(16, 10) * u, o + Vector2(11.6, 11.6) * u, o + Vector2(10, 16) * u, o + Vector2(8.4, 11.6) * u, o + Vector2(4, 10) * u, o + Vector2(8.4, 8.4) * u]), PackedColorArray([Color(1, 1, 1, 0.9)]))
		"curse":
			# olho riscado: losango com um X
			draw_polyline(PackedVector2Array([o + Vector2(10, 2) * u, o + Vector2(18, 10) * u, o + Vector2(10, 18) * u, o + Vector2(2, 10) * u, o + Vector2(10, 2) * u]), color, 2.0 * u, true)
			draw_line(o + Vector2(6, 6) * u, o + Vector2(14, 14) * u, color, 2.2 * u, true)
			draw_line(o + Vector2(14, 6) * u, o + Vector2(6, 14) * u, color, 2.2 * u, true)
		"climate":
			# sol meio escondido por uma nuvem
			draw_circle(o + Vector2(13, 7) * u, 4.5 * u, Color(color, 0.85))
			for k in 6:
				var a := TAU * k / 6.0
				draw_line(o + Vector2(13, 7) * u + Vector2(cos(a), sin(a)) * 6.0 * u, o + Vector2(13, 7) * u + Vector2(cos(a), sin(a)) * 8.0 * u, Color(color, 0.85), 1.4 * u, true)
			draw_circle(o + Vector2(7, 13) * u, 4.0 * u, color)
			draw_circle(o + Vector2(11, 11) * u, 4.5 * u, color)
			draw_circle(o + Vector2(15, 14) * u, 3.5 * u, color)
			draw_rect(Rect2(o + Vector2(5, 13) * u, Vector2(12, 4) * u), color)
		"shield":
			draw_colored_polygon(PackedVector2Array([o + Vector2(4, 3) * u, o + Vector2(16, 3) * u, o + Vector2(16, 10) * u, o + Vector2(10, 18) * u, o + Vector2(4, 10) * u]), color)
			draw_line(o + Vector2(10, 5) * u, o + Vector2(10, 15) * u, Color(0, 0, 0, 0.35), 1.4 * u, true)
		"skull":
			draw_circle(o + Vector2(10, 8.5) * u, 6.8 * u, color)
			draw_rect(Rect2(o + Vector2(6.5, 12) * u, Vector2(7, 5) * u), color)
			draw_circle(o + Vector2(7.6, 8.8) * u, 1.9 * u, Color(0, 0, 0, 0.8))
			draw_circle(o + Vector2(12.4, 8.8) * u, 1.9 * u, Color(0, 0, 0, 0.8))
			draw_line(o + Vector2(8.6, 14.5) * u, o + Vector2(8.6, 17) * u, Color(0, 0, 0, 0.6), 1.0 * u)
			draw_line(o + Vector2(11.4, 14.5) * u, o + Vector2(11.4, 17) * u, Color(0, 0, 0, 0.6), 1.0 * u)
		"coin":
			draw_circle(o + Vector2(10, 10) * u, 7.5 * u, color)
			draw_arc(o + Vector2(10, 10) * u, 5.2 * u, 0.0, TAU, 24, Color(0, 0, 0, 0.35), 1.2 * u, true)
			draw_line(o + Vector2(10, 6.5) * u, o + Vector2(10, 13.5) * u, Color(0, 0, 0, 0.45), 1.6 * u, true)
		"cross":
			draw_rect(Rect2(o + Vector2(7.8, 3) * u, Vector2(4.4, 14) * u), color)
			draw_rect(Rect2(o + Vector2(3, 7.8) * u, Vector2(14, 4.4) * u), color)
		"burst":
			var pts := PackedVector2Array()
			for k in 16:
				var a := TAU * k / 16.0 - PI / 2.0
				var r := (8.5 if k % 2 == 0 else 4.0) * u
				pts.append(o + Vector2(10, 10) * u + Vector2(cos(a), sin(a)) * r)
			draw_colored_polygon(pts, color)
		"card":
			draw_rect(Rect2(o + Vector2(5, 2.5) * u, Vector2(10, 15) * u), color, false, 1.8 * u)
			draw_line(o + Vector2(7, 6) * u, o + Vector2(13, 14) * u, color, 1.6 * u, true)
			draw_line(o + Vector2(13, 6) * u, o + Vector2(7, 14) * u, color, 1.6 * u, true)
		"check":
			draw_polyline(PackedVector2Array([o + Vector2(3.5, 10.5) * u, o + Vector2(8, 15) * u, o + Vector2(16.5, 5) * u]), color, 2.6 * u, true)
		"heart":
			draw_circle(o + Vector2(6.5, 7.5) * u, 4.6 * u, color)
			draw_circle(o + Vector2(13.5, 7.5) * u, 4.6 * u, color)
			draw_colored_polygon(PackedVector2Array([o + Vector2(2.1, 9.2) * u, o + Vector2(17.9, 9.2) * u, o + Vector2(10, 18) * u]), color)
		"wheel":
			# roda da sorte com raios e ponteiro
			draw_arc(o + Vector2(10, 11) * u, 7.5 * u, 0.0, TAU, 32, color, 2.0 * u, true)
			for k in 4:
				var a := TAU * k / 8.0
				draw_line(o + Vector2(10, 11) * u - Vector2(cos(a), sin(a)) * 7.0 * u, o + Vector2(10, 11) * u + Vector2(cos(a), sin(a)) * 7.0 * u, color, 1.4 * u, true)
			draw_colored_polygon(PackedVector2Array([o + Vector2(7, 0) * u, o + Vector2(13, 0) * u, o + Vector2(10, 4.5) * u]), color)
		"contract":
			# pergaminho com selo
			draw_rect(Rect2(o + Vector2(4, 2) * u, Vector2(12, 16) * u), color, false, 2.0 * u, true)
			draw_line(o + Vector2(7, 6) * u, o + Vector2(13, 6) * u, color, 1.5 * u, true)
			draw_line(o + Vector2(7, 9) * u, o + Vector2(13, 9) * u, color, 1.5 * u, true)
			draw_circle(o + Vector2(13, 15) * u, 3.0 * u, Color(0.85, 0.25, 0.25))
		"chain":
			# dois elos entrelaçados (sinergia com o baralho)
			for c in [Vector2(7, 13), Vector2(13, 7)]:
				var pts := PackedVector2Array()
				for k in 25:
					var a := TAU * k / 24.0
					var p := Vector2(cos(a) * 5.4, sin(a) * 2.9).rotated(-PI / 4.0)
					pts.append(o + (c + p) * u)
				draw_polyline(pts, color, 2.0 * u, true)
		"enchantment":
			# anel com uma estrela de 4 pontas (fica em jogo)
			draw_arc(o + Vector2(10, 10) * u, 8.0 * u, 0.0, TAU, 28, color, 1.6 * u, true)
			draw_polygon(PackedVector2Array([o + Vector2(10, 3.5) * u, o + Vector2(11.6, 8.4) * u, o + Vector2(16.5, 10) * u, o + Vector2(11.6, 11.6) * u, o + Vector2(10, 16.5) * u, o + Vector2(8.4, 11.6) * u, o + Vector2(3.5, 10) * u, o + Vector2(8.4, 8.4) * u]), PackedColorArray([color]))
		"mana":
			# cristal de mana (losango facetado)
			draw_colored_polygon(PackedVector2Array([o + Vector2(10, 1.5) * u, o + Vector2(16.5, 8) * u, o + Vector2(10, 18.5) * u, o + Vector2(3.5, 8) * u]), color)
			draw_line(o + Vector2(3.5, 8) * u, o + Vector2(16.5, 8) * u, Color(1, 1, 1, 0.55), 1.2 * u, true)
			draw_line(o + Vector2(10, 1.5) * u, o + Vector2(7.5, 8) * u, Color(1, 1, 1, 0.55), 1.0 * u, true)
			draw_line(o + Vector2(10, 1.5) * u, o + Vector2(12.5, 8) * u, Color(1, 1, 1, 0.55), 1.0 * u, true)
			draw_line(o + Vector2(7.5, 8) * u, o + Vector2(10, 18.5) * u, Color(1, 1, 1, 0.35), 1.0 * u, true)
		"vigilance":
			# olho aberto (está sempre de guarda)
			var eye := PackedVector2Array()
			for k in 13:
				var t := float(k) / 12.0
				eye.append(o + Vector2(2 + 16 * t, 10 - sin(t * PI) * 6.0) * u)
			for k in 13:
				var t := 1.0 - float(k) / 12.0
				eye.append(o + Vector2(2 + 16 * t, 10 + sin(t * PI) * 6.0) * u)
			draw_colored_polygon(eye, color)
			draw_circle(o + Vector2(10, 10) * u, 3.4 * u, _inner())
			draw_circle(o + Vector2(11, 9) * u, 1.1 * u, color)
		"lifelink":
			# coração com um + (cura ao atacar)
			draw_circle(o + Vector2(6.5, 7.5) * u, 4.6 * u, color)
			draw_circle(o + Vector2(13.5, 7.5) * u, 4.6 * u, color)
			draw_colored_polygon(PackedVector2Array([o + Vector2(2.1, 9.2) * u, o + Vector2(17.9, 9.2) * u, o + Vector2(10, 18) * u]), color)
			draw_line(o + Vector2(10, 6.5) * u, o + Vector2(10, 13) * u, _inner(), 2.0 * u, true)
			draw_line(o + Vector2(6.8, 9.7) * u, o + Vector2(13.2, 9.7) * u, _inner(), 2.0 * u, true)
		"protection":
			# escudo com uma estrela (o inimigo não lhe toca)
			draw_colored_polygon(PackedVector2Array([o + Vector2(3.5, 2.5) * u, o + Vector2(16.5, 2.5) * u, o + Vector2(16.5, 10) * u, o + Vector2(10, 18.5) * u, o + Vector2(3.5, 10) * u]), color)
			draw_polygon(PackedVector2Array([o + Vector2(10, 5) * u, o + Vector2(11.2, 8.6) * u, o + Vector2(14.5, 9.2) * u, o + Vector2(11.6, 11.2) * u, o + Vector2(12.4, 14.6) * u, o + Vector2(10, 12.6) * u, o + Vector2(7.6, 14.6) * u, o + Vector2(8.4, 11.2) * u, o + Vector2(5.5, 9.2) * u, o + Vector2(8.8, 8.6) * u]), PackedColorArray([_inner()]))
		"flying":
			# asa (os lacaios não a travam)
			var wing := PackedVector2Array([o + Vector2(2, 15) * u, o + Vector2(6, 7) * u, o + Vector2(12, 3) * u,
				o + Vector2(18.5, 2.5) * u, o + Vector2(15, 6) * u, o + Vector2(17.5, 7.5) * u, o + Vector2(13.5, 10) * u,
				o + Vector2(15.5, 12) * u, o + Vector2(10.5, 13.5) * u, o + Vector2(11.5, 15.5) * u, o + Vector2(6, 15.8) * u])
			draw_colored_polygon(wing, color)
			draw_line(o + Vector2(5, 13.5) * u, o + Vector2(13, 6) * u, _inner(), 1.2 * u, true)
		"trample":
			# seta grossa a furar uma barra (o escudo)
			draw_rect(Rect2(o + Vector2(11, 2) * u, Vector2(2.4, 16) * u), Color(color, 0.55))
			draw_colored_polygon(PackedVector2Array([o + Vector2(1.5, 7.5) * u, o + Vector2(11, 7.5) * u, o + Vector2(11, 3.5) * u,
				o + Vector2(18.5, 10) * u, o + Vector2(11, 16.5) * u, o + Vector2(11, 12.5) * u, o + Vector2(1.5, 12.5) * u]), color)
		"first_strike":
			# duas setas para a frente (dispara primeiro)
			for dx in [0.0, 7.0]:
				draw_colored_polygon(PackedVector2Array([o + Vector2(2 + dx, 3) * u, o + Vector2(10 + dx, 10) * u, o + Vector2(2 + dx, 17) * u,
					o + Vector2(5 + dx, 10) * u]), color)
		"landfall":
			# montanha com uma seta para baixo (quando jogas um Terreno)
			draw_colored_polygon(PackedVector2Array([o + Vector2(1.5, 18) * u, o + Vector2(8, 8) * u, o + Vector2(11, 12) * u,
				o + Vector2(13.5, 9) * u, o + Vector2(18.5, 18) * u]), color)
			draw_colored_polygon(PackedVector2Array([o + Vector2(7, 1.5) * u, o + Vector2(13, 1.5) * u, o + Vector2(10, 6.5) * u]), color)
		"relic":
			# estrela de 4 pontas
			draw_polygon(PackedVector2Array([o + Vector2(10, 1) * u, o + Vector2(12.5, 7.5) * u, o + Vector2(19, 10) * u, o + Vector2(12.5, 12.5) * u, o + Vector2(10, 19) * u, o + Vector2(7.5, 12.5) * u, o + Vector2(1, 10) * u, o + Vector2(7.5, 7.5) * u]), PackedColorArray([color]))

## Cor dos detalhes por dentro de um ícone (o + do coração, a estrela do escudo, a pupila do olho):
## escura nos ícones claros e clara nos escuros, para se ver nas cartas de qualquer cor.
func _inner() -> Color:
	return Color(0.08, 0.08, 0.1, 0.9) if color.get_luminance() > 0.55 else Color(1, 1, 1, 0.92)

## Modo daltónico: sol (branco), gota (azul), caveira (preto), chama (vermelho), árvore (verde),
## losango (incolor) — desenhados por cima do pip com uma cor que contrasta.
func _draw_mana_symbol(o: Vector2, u: float) -> void:
	var ink := Color(0.95, 0.95, 0.95) if mana_color == "black" else Color(0.08, 0.08, 0.1, 0.92)
	var c := o + Vector2(10, 10) * u
	match mana_color:
		"white":
			var pts := PackedVector2Array()
			for k in 16:
				var a := TAU * k / 16.0
				pts.append(c + Vector2(cos(a), sin(a)) * (5.0 if k % 2 == 0 else 2.4) * u)
			draw_colored_polygon(pts, ink)
		"blue":
			draw_circle(c + Vector2(0, 1.6) * u, 3.0 * u, ink)
			draw_colored_polygon(PackedVector2Array([c + Vector2(-2.9, 0.9) * u, c + Vector2(0, -5.2) * u, c + Vector2(2.9, 0.9) * u]), ink)
		"black":
			draw_circle(c + Vector2(0, -0.8) * u, 3.8 * u, ink)
			draw_rect(Rect2(c + Vector2(-2.2, 2.0) * u, Vector2(4.4, 2.6) * u), ink)
			draw_circle(c + Vector2(-1.5, -0.8) * u, 1.1 * u, color)
			draw_circle(c + Vector2(1.5, -0.8) * u, 1.1 * u, color)
		"red":
			draw_circle(c + Vector2(0, 1.8) * u, 3.0 * u, ink)
			draw_colored_polygon(PackedVector2Array([c + Vector2(-3.0, 1.4) * u, c + Vector2(-0.6, -5.4) * u, c + Vector2(1.2, -2.0) * u, c + Vector2(2.4, -4.0) * u, c + Vector2(3.0, 1.4) * u]), ink)
		"green":
			draw_colored_polygon(PackedVector2Array([c + Vector2(0, -5.2) * u, c + Vector2(4.2, 2.2) * u, c + Vector2(-4.2, 2.2) * u]), ink)
			draw_rect(Rect2(c + Vector2(-0.9, 2.2) * u, Vector2(1.8, 2.8) * u), ink)
		_:
			draw_colored_polygon(PackedVector2Array([c + Vector2(0, -4.5) * u, c + Vector2(4.5, 0) * u, c + Vector2(0, 4.5) * u, c + Vector2(-4.5, 0) * u]), ink)

## Pip de cor (com o símbolo do modo daltónico, se estiver ligado).
static func pip(mana: String, size_px: float = 12.0) -> CardIcon:
	var col: Color = CardView.COLORS.get(mana, CardView.COLORS.colorless)
	var p := CardIcon.new("pip", col, size_px + (4.0 if Settings.colorblind else 0.0))
	p.mana_color = mana
	return p

static func kind_for(d: CardData) -> String:
	if d.is_curse():
		return "curse"
	if d.is_creature():
		return "creature"
	if d.is_land():
		return "land"
	if d.is_enchantment():
		return "enchantment"
	return "instant" if d.subtype == "instant" else "sorcery"
