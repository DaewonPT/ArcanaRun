class_name CardIcon
extends Control
## Ícone vetorial desenhado em código (sem imagens): tipo de carta ou pip de cor.
##   kind: "creature" (espada) · "sorcery" (pergaminho) · "instant" (raio) · "land" (montanha) · "pip" (círculo)

var kind: String = "creature":
	set(v):
		kind = v
		queue_redraw()
var color: Color = Color.WHITE:
	set(v):
		color = v
		queue_redraw()

func _init(p_kind: String = "creature", p_color: Color = Color.WHITE, size_px: float = 20.0) -> void:
	kind = p_kind
	color = p_color
	custom_minimum_size = Vector2(size_px, size_px)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	var s := minf(size.x, size.y)
	var o := (size - Vector2(s, s)) / 2.0
	var u := s / 20.0   # unidade: o ícone é desenhado numa grelha 20×20
	match kind:
		"creature":
			# lâmina diagonal
			draw_polygon(PackedVector2Array([o + Vector2(15, 2) * u, o + Vector2(18, 5) * u, o + Vector2(8, 15) * u, o + Vector2(5, 12) * u]), PackedColorArray([color]))
			# guarda e punho
			draw_line(o + Vector2(3, 10) * u, o + Vector2(10, 17) * u, color, 2.2 * u, true)
			draw_line(o + Vector2(5, 15) * u, o + Vector2(2, 18) * u, color, 2.6 * u, true)
		"sorcery":
			# pergaminho: retângulo com duas pontas enroladas
			var r := Rect2(o + Vector2(4, 3) * u, Vector2(12, 14) * u)
			draw_rect(r, color, false, 2.0 * u, true)
			draw_line(o + Vector2(7, 7) * u, o + Vector2(13, 7) * u, color, 1.6 * u, true)
			draw_line(o + Vector2(7, 10) * u, o + Vector2(13, 10) * u, color, 1.6 * u, true)
			draw_line(o + Vector2(7, 13) * u, o + Vector2(11, 13) * u, color, 1.6 * u, true)
		"instant":
			# raio
			draw_polygon(PackedVector2Array([o + Vector2(11, 1) * u, o + Vector2(4, 11) * u, o + Vector2(9, 11) * u, o + Vector2(7, 19) * u, o + Vector2(16, 8) * u, o + Vector2(11, 8) * u]), PackedColorArray([color]))
		"land":
			# duas montanhas e uma linha de chão
			draw_polygon(PackedVector2Array([o + Vector2(1, 17) * u, o + Vector2(8, 5) * u, o + Vector2(13, 13) * u, o + Vector2(11, 17) * u]), PackedColorArray([color]))
			draw_polygon(PackedVector2Array([o + Vector2(9, 17) * u, o + Vector2(14, 8) * u, o + Vector2(19, 17) * u]), PackedColorArray([Color(color, 0.75)]))
		"pip":
			draw_circle(o + Vector2(10, 10) * u, 7.0 * u, color)
			draw_arc(o + Vector2(10, 10) * u, 7.0 * u, 0.0, TAU, 24, Color(0, 0, 0, 0.45), 1.5 * u, true)
		"seal":
			# selo de cera: círculo cheio, anel e estrela clara no meio
			draw_circle(o + Vector2(10, 10) * u, 9.0 * u, color)
			draw_arc(o + Vector2(10, 10) * u, 7.0 * u, 0.0, TAU, 28, Color(1, 1, 1, 0.55), 1.2 * u, true)
			draw_polygon(PackedVector2Array([o + Vector2(10, 4) * u, o + Vector2(11.6, 8.4) * u, o + Vector2(16, 10) * u, o + Vector2(11.6, 11.6) * u, o + Vector2(10, 16) * u, o + Vector2(8.4, 11.6) * u, o + Vector2(4, 10) * u, o + Vector2(8.4, 8.4) * u]), PackedColorArray([Color(1, 1, 1, 0.9)]))
		"relic":
			# estrela de 4 pontas
			draw_polygon(PackedVector2Array([o + Vector2(10, 1) * u, o + Vector2(12.5, 7.5) * u, o + Vector2(19, 10) * u, o + Vector2(12.5, 12.5) * u, o + Vector2(10, 19) * u, o + Vector2(7.5, 12.5) * u, o + Vector2(1, 10) * u, o + Vector2(7.5, 7.5) * u]), PackedColorArray([color]))

static func kind_for(d: CardData) -> String:
	if d.is_creature():
		return "creature"
	if d.is_land():
		return "land"
	return "instant" if d.subtype == "instant" else "sorcery"
