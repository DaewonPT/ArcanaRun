class_name CardIcon
extends Control
## Ícone vetorial desenhado em código (sem imagens): tipo de carta ou pip de cor.
##   kind: "creature" (espada) · "sorcery" (pergaminho) · "instant" (raio) · "land" (montanha) · "pip" (círculo)
##         · "seal" · "relic" · "curse" (losango riscado) · "climate" (sol e nuvem) · "contract" (pergaminho
##         com selo) · "wheel" (roda do Tribunal) · "chain" (elos: a carta combina com o baralho)
##         · 0.11.0: "enchantment" (estrela num anel) · "mana" (cristal) · "vigilance" (olho) ·
##         "lifelink" (coração com +) · "protection" (escudo com estrela)
##         · 0.12.0: "flying" (asa) · "trample" (seta a furar o escudo) · "first_strike" (duas setas) ·
##         "landfall" (montanha com seta: Chegada de Terreno)
##         · 0.13.0: "lock" (cadeado) · "mirror" (espelho) · "star" (estrela) · "replay" (seta em círculo) ·
##         "exile" (espiral) · "potion" (frasco) · "scroll" (pergaminho enrolado com fita) · mapa: "crown",
##         "shop", "anvil", "chest", "book", "campfire", "flag"
##         · 0.15.0: "prowess" (Destreza) · "persist" (Persistir) · "energy" (Energia) · "blood" (Mana de Sangue: gota) ·
##         "weak" (Ponto fraco: mira) · "hourglass" (ritual do boss)
##         · 0.16.0 (ícones próprios em todo o jogo): "swords" (atacar) · "pause" · "undo" · "speed" · "sort" ·
##         "mult" · "x" (remover, fechar) · "ticket" (Vale) · "cards" (ver o baralho) · "menu" (casa) · "pack" (booster) · "gear" (Configurações) · "play" (continuar)
##         · 0.16.1: "mana_symbol" (só o símbolo da cor de `mana_color`, sem o círculo; `color` = o fundo)

var kind: String = "creature":
	set(v):
		kind = v
		queue_redraw()
var mana_color: String = ""   # cor de mana de um pip ("white", "blue"…): símbolo no modo daltónico
var color: Color = Color.WHITE:
	set(v):
		color = v
		queue_redraw()

func _init(p_kind: String = "creature", p_color: Color = Color.WHITE, size_px: float = 20.0) -> void:
	kind = p_kind
	color = p_color
	custom_minimum_size = Vector2(size_px, size_px)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	var s := minf(size.x, size.y)
	var o := (size - Vector2(s, s)) / 2.0
	var u := s / 20.0   # unidade: o ícone é desenhado numa grelha 20×20
	match kind:
		"creature":
			# lâmina diagonal
			draw_polygon(PackedVector2Array([o + Vector2(15, 2) * u, o + Vector2(18, 5) * u, o + Vector2(8, 15) * u, o + Vector2(5, 12) * u]), PackedColorArray([color]))
			# guarda e punho
			draw_line(o + Vector2(3, 10) * u, o + Vector2(10, 17) * u, color, 2.2 * u, true)
			draw_line(o + Vector2(5, 15) * u, o + Vector2(2, 18) * u, color, 2.6 * u, true)
		"equipment":
			# 0.18.0 (19) Equipamento: martelo de forja (cabo na diagonal e cabeça atravessada)
			draw_line(o + Vector2(3.5, 17.5) * u, o + Vector2(12.5, 8.5) * u, color, 2.4 * u, true)
			draw_colored_polygon(PackedVector2Array([o + Vector2(9.2, 4.6) * u, o + Vector2(13.4, 0.4) * u, o + Vector2(19.6, 6.6) * u,
				o + Vector2(15.4, 10.8) * u]), color)
		"sorcery":
			# pergaminho: retângulo com duas pontas enroladas
			var r := Rect2(o + Vector2(4, 3) * u, Vector2(12, 14) * u)
			draw_rect(r, color, false, 2.0 * u, true)
			draw_line(o + Vector2(7, 7) * u, o + Vector2(13, 7) * u, color, 1.6 * u, true)
			draw_line(o + Vector2(7, 10) * u, o + Vector2(13, 10) * u, color, 1.6 * u, true)
			draw_line(o + Vector2(7, 13) * u, o + Vector2(11, 13) * u, color, 1.6 * u, true)
		"instant":
			# raio
			draw_polygon(PackedVector2Array([o + Vector2(11, 1) * u, o + Vector2(4, 11) * u, o + Vector2(9, 11) * u, o + Vector2(7, 19) * u, o + Vector2(16, 8) * u, o + Vector2(11, 8) * u]), PackedColorArray([color]))
		"land":
			# duas montanhas e uma linha de chão
			draw_polygon(PackedVector2Array([o + Vector2(1, 17) * u, o + Vector2(8, 5) * u, o + Vector2(13, 13) * u, o + Vector2(11, 17) * u]), PackedColorArray([color]))
			draw_polygon(PackedVector2Array([o + Vector2(9, 17) * u, o + Vector2(14, 8) * u, o + Vector2(19, 17) * u]), PackedColorArray([Color(color, 0.75)]))
		"mana_symbol":   # 0.16.1 (V52): só o símbolo da cor, nos botões de cor (o fundo do botão é a cor)
			_draw_mana_symbol(o, u)
		"pip":
			draw_circle(o + Vector2(10, 10) * u, 7.0 * u, color)
			draw_arc(o + Vector2(10, 10) * u, 7.0 * u, 0.0, TAU, 24, Color(0, 0, 0, 0.45), 1.5 * u, true)
			if mana_color != "" and Settings.colorblind:
				_draw_mana_symbol(o, u)
		"seal":
			# selo de cera: círculo cheio, anel e estrela clara no meio
			draw_circle(o + Vector2(10, 10) * u, 9.0 * u, color)
			draw_arc(o + Vector2(10, 10) * u, 7.0 * u, 0.0, TAU, 28, Color(1, 1, 1, 0.55), 1.2 * u, true)
			draw_polygon(PackedVector2Array([o + Vector2(10, 4) * u, o + Vector2(11.6, 8.4) * u, o + Vector2(16, 10) * u, o + Vector2(11.6, 11.6) * u, o + Vector2(10, 16) * u, o + Vector2(8.4, 11.6) * u, o + Vector2(4, 10) * u, o + Vector2(8.4, 8.4) * u]), PackedColorArray([Color(1, 1, 1, 0.9)]))
		"curse":
			# olho riscado: losango com um X
			draw_polyline(PackedVector2Array([o + Vector2(10, 2) * u, o + Vector2(18, 10) * u, o + Vector2(10, 18) * u, o + Vector2(2, 10) * u, o + Vector2(10, 2) * u]), color, 2.0 * u, true)
			draw_line(o + Vector2(6, 6) * u, o + Vector2(14, 14) * u, color, 2.2 * u, true)
			draw_line(o + Vector2(14, 6) * u, o + Vector2(6, 14) * u, color, 2.2 * u, true)
		"climate":
			# sol meio escondido por uma nuvem
			draw_circle(o + Vector2(13, 7) * u, 4.5 * u, Color(color, 0.85))
			for k in 6:
				var a := TAU * k / 6.0
				draw_line(o + Vector2(13, 7) * u + Vector2(cos(a), sin(a)) * 6.0 * u, o + Vector2(13, 7) * u + Vector2(cos(a), sin(a)) * 8.0 * u, Color(color, 0.85), 1.4 * u, true)
			draw_circle(o + Vector2(7, 13) * u, 4.0 * u, color)
			draw_circle(o + Vector2(11, 11) * u, 4.5 * u, color)
			draw_circle(o + Vector2(15, 14) * u, 3.5 * u, color)
			draw_rect(Rect2(o + Vector2(5, 13) * u, Vector2(12, 4) * u), color)
		"shield":
			draw_colored_polygon(PackedVector2Array([o + Vector2(4, 3) * u, o + Vector2(16, 3) * u, o + Vector2(16, 10) * u, o + Vector2(10, 18) * u, o + Vector2(4, 10) * u]), color)
			draw_line(o + Vector2(10, 5) * u, o + Vector2(10, 15) * u, Color(0, 0, 0, 0.35), 1.4 * u, true)
		"skull":
			draw_circle(o + Vector2(10, 8.5) * u, 6.8 * u, color)
			draw_rect(Rect2(o + Vector2(6.5, 12) * u, Vector2(7, 5) * u), color)
			draw_circle(o + Vector2(7.6, 8.8) * u, 1.9 * u, Color(0, 0, 0, 0.8))
			draw_circle(o + Vector2(12.4, 8.8) * u, 1.9 * u, Color(0, 0, 0, 0.8))
			draw_line(o + Vector2(8.6, 14.5) * u, o + Vector2(8.6, 17) * u, Color(0, 0, 0, 0.6), 1.0 * u)
			draw_line(o + Vector2(11.4, 14.5) * u, o + Vector2(11.4, 17) * u, Color(0, 0, 0, 0.6), 1.0 * u)
		"coin":
			_draw_coin(o + Vector2(10, 10) * u, u)
		"cross":
			draw_rect(Rect2(o + Vector2(7.8, 3) * u, Vector2(4.4, 14) * u), color)
			draw_rect(Rect2(o + Vector2(3, 7.8) * u, Vector2(14, 4.4) * u), color)
		"burst":
			var pts := PackedVector2Array()
			for k in 16:
				var a := TAU * k / 16.0 - PI / 2.0
				var r := (8.5 if k % 2 == 0 else 4.0) * u
				pts.append(o + Vector2(10, 10) * u + Vector2(cos(a), sin(a)) * r)
			draw_colored_polygon(pts, color)
		"card":
			draw_rect(Rect2(o + Vector2(5, 2.5) * u, Vector2(10, 15) * u), color, false, 1.8 * u)
			draw_line(o + Vector2(7, 6) * u, o + Vector2(13, 14) * u, color, 1.6 * u, true)
			draw_line(o + Vector2(13, 6) * u, o + Vector2(7, 14) * u, color, 1.6 * u, true)
		"check":
			draw_polyline(PackedVector2Array([o + Vector2(3.5, 10.5) * u, o + Vector2(8, 15) * u, o + Vector2(16.5, 5) * u]), color, 2.6 * u, true)
		"speaker", "speaker_off":
			# 0.19.0 (271): som ligado (com ondas) ou desligado (com um risco)
			draw_colored_polygon(PackedVector2Array([o + Vector2(2.5, 7.5) * u, o + Vector2(6, 7.5) * u, o + Vector2(10.5, 3) * u,
				o + Vector2(10.5, 17) * u, o + Vector2(6, 12.5) * u, o + Vector2(2.5, 12.5) * u]), color)
			if kind == "speaker":
				draw_arc(o + Vector2(11, 10) * u, 3.5 * u, -0.9, 0.9, 10, color, 1.6 * u, true)
				draw_arc(o + Vector2(11, 10) * u, 6.5 * u, -0.9, 0.9, 14, color, 1.6 * u, true)
			else:
				draw_line(o + Vector2(13, 6.5) * u, o + Vector2(18.5, 13.5) * u, color, 2.0 * u, true)
				draw_line(o + Vector2(18.5, 6.5) * u, o + Vector2(13, 13.5) * u, color, 2.0 * u, true)
		"bell":
			# 0.19.0 (137): sino dos avisos
			draw_colored_polygon(PackedVector2Array([o + Vector2(10, 2.5) * u, o + Vector2(14.5, 6) * u, o + Vector2(15.5, 13.5) * u,
				o + Vector2(17.5, 15.5) * u, o + Vector2(2.5, 15.5) * u, o + Vector2(4.5, 13.5) * u, o + Vector2(5.5, 6) * u]), color)
			draw_circle(o + Vector2(10, 17.5) * u, 2.0 * u, color)
			draw_circle(o + Vector2(10, 2.2) * u, 1.3 * u, color)
		"heart":
			draw_circle(o + Vector2(6.5, 7.5) * u, 4.6 * u, color)
			draw_circle(o + Vector2(13.5, 7.5) * u, 4.6 * u, color)
			draw_colored_polygon(PackedVector2Array([o + Vector2(2.1, 9.2) * u, o + Vector2(17.9, 9.2) * u, o + Vector2(10, 18) * u]), color)
		"wheel":
			# roda da sorte com raios e ponteiro
			draw_arc(o + Vector2(10, 11) * u, 7.5 * u, 0.0, TAU, 32, color, 2.0 * u, true)
			for k in 4:
				var a := TAU * k / 8.0
				draw_line(o + Vector2(10, 11) * u - Vector2(cos(a), sin(a)) * 7.0 * u, o + Vector2(10, 11) * u + Vector2(cos(a), sin(a)) * 7.0 * u, color, 1.4 * u, true)
			draw_colored_polygon(PackedVector2Array([o + Vector2(7, 0) * u, o + Vector2(13, 0) * u, o + Vector2(10, 4.5) * u]), color)
		"contract":
			# pergaminho com selo
			draw_rect(Rect2(o + Vector2(4, 2) * u, Vector2(12, 16) * u), color, false, 2.0 * u, true)
			draw_line(o + Vector2(7, 6) * u, o + Vector2(13, 6) * u, color, 1.5 * u, true)
			draw_line(o + Vector2(7, 9) * u, o + Vector2(13, 9) * u, color, 1.5 * u, true)
			draw_circle(o + Vector2(13, 15) * u, 3.0 * u, Color(0.85, 0.25, 0.25))
		"chain":
			# dois elos entrelaçados (sinergia com o baralho)
			for c in [Vector2(7, 13), Vector2(13, 7)]:
				var pts := PackedVector2Array()
				for k in 25:
					var a := TAU * k / 24.0
					var p := Vector2(cos(a) * 5.4, sin(a) * 2.9).rotated(-PI / 4.0)
					pts.append(o + (c + p) * u)
				draw_polyline(pts, color, 2.0 * u, true)
		"enchantment":
			# anel com uma estrela de 4 pontas (fica em jogo)
			draw_arc(o + Vector2(10, 10) * u, 8.0 * u, 0.0, TAU, 28, color, 1.6 * u, true)
			draw_polygon(PackedVector2Array([o + Vector2(10, 3.5) * u, o + Vector2(11.6, 8.4) * u, o + Vector2(16.5, 10) * u, o + Vector2(11.6, 11.6) * u, o + Vector2(10, 16.5) * u, o + Vector2(8.4, 11.6) * u, o + Vector2(3.5, 10) * u, o + Vector2(8.4, 8.4) * u]), PackedColorArray([color]))
		"mana":
			# cristal de mana (losango facetado)
			draw_colored_polygon(PackedVector2Array([o + Vector2(10, 1.5) * u, o + Vector2(16.5, 8) * u, o + Vector2(10, 18.5) * u, o + Vector2(3.5, 8) * u]), color)
			draw_line(o + Vector2(3.5, 8) * u, o + Vector2(16.5, 8) * u, Color(1, 1, 1, 0.55), 1.2 * u, true)
			draw_line(o + Vector2(10, 1.5) * u, o + Vector2(7.5, 8) * u, Color(1, 1, 1, 0.55), 1.0 * u, true)
			draw_line(o + Vector2(10, 1.5) * u, o + Vector2(12.5, 8) * u, Color(1, 1, 1, 0.55), 1.0 * u, true)
			draw_line(o + Vector2(7.5, 8) * u, o + Vector2(10, 18.5) * u, Color(1, 1, 1, 0.35), 1.0 * u, true)
		"vigilance":
			# olho aberto (está sempre de guarda)
			var eye := PackedVector2Array()
			for k in 13:
				var t := float(k) / 12.0
				eye.append(o + Vector2(2 + 16 * t, 10 - sin(t * PI) * 6.0) * u)
			for k in 13:
				var t := 1.0 - float(k) / 12.0
				eye.append(o + Vector2(2 + 16 * t, 10 + sin(t * PI) * 6.0) * u)
			draw_colored_polygon(eye, color)
			draw_circle(o + Vector2(10, 10) * u, 3.4 * u, _inner())
			draw_circle(o + Vector2(11, 9) * u, 1.1 * u, color)
		"lifelink":
			# coração com um + (cura ao atacar)
			draw_circle(o + Vector2(6.5, 7.5) * u, 4.6 * u, color)
			draw_circle(o + Vector2(13.5, 7.5) * u, 4.6 * u, color)
			draw_colored_polygon(PackedVector2Array([o + Vector2(2.1, 9.2) * u, o + Vector2(17.9, 9.2) * u, o + Vector2(10, 18) * u]), color)
			draw_line(o + Vector2(10, 6.5) * u, o + Vector2(10, 13) * u, _inner(), 2.0 * u, true)
			draw_line(o + Vector2(6.8, 9.7) * u, o + Vector2(13.2, 9.7) * u, _inner(), 2.0 * u, true)
		"protection":
			# escudo com uma estrela (o inimigo não lhe toca)
			draw_colored_polygon(PackedVector2Array([o + Vector2(3.5, 2.5) * u, o + Vector2(16.5, 2.5) * u, o + Vector2(16.5, 10) * u, o + Vector2(10, 18.5) * u, o + Vector2(3.5, 10) * u]), color)
			draw_polygon(PackedVector2Array([o + Vector2(10, 5) * u, o + Vector2(11.2, 8.6) * u, o + Vector2(14.5, 9.2) * u, o + Vector2(11.6, 11.2) * u, o + Vector2(12.4, 14.6) * u, o + Vector2(10, 12.6) * u, o + Vector2(7.6, 14.6) * u, o + Vector2(8.4, 11.2) * u, o + Vector2(5.5, 9.2) * u, o + Vector2(8.8, 8.6) * u]), PackedColorArray([_inner()]))
		"flying":
			# asa (os lacaios não a travam)
			var wing := PackedVector2Array([o + Vector2(2, 15) * u, o + Vector2(6, 7) * u, o + Vector2(12, 3) * u,
				o + Vector2(18.5, 2.5) * u, o + Vector2(15, 6) * u, o + Vector2(17.5, 7.5) * u, o + Vector2(13.5, 10) * u,
				o + Vector2(15.5, 12) * u, o + Vector2(10.5, 13.5) * u, o + Vector2(11.5, 15.5) * u, o + Vector2(6, 15.8) * u])
			draw_colored_polygon(wing, color)
			draw_line(o + Vector2(5, 13.5) * u, o + Vector2(13, 6) * u, _inner(), 1.2 * u, true)
		"trample":
			# seta grossa a furar uma barra (o escudo)
			draw_rect(Rect2(o + Vector2(11, 2) * u, Vector2(2.4, 16) * u), Color(color, 0.55))
			draw_colored_polygon(PackedVector2Array([o + Vector2(1.5, 7.5) * u, o + Vector2(11, 7.5) * u, o + Vector2(11, 3.5) * u,
				o + Vector2(18.5, 10) * u, o + Vector2(11, 16.5) * u, o + Vector2(11, 12.5) * u, o + Vector2(1.5, 12.5) * u]), color)
		"first_strike":
			# duas setas para a frente (dispara primeiro)
			for dx in [0.0, 7.0]:
				draw_colored_polygon(PackedVector2Array([o + Vector2(2 + dx, 3) * u, o + Vector2(10 + dx, 10) * u, o + Vector2(2 + dx, 17) * u,
					o + Vector2(5 + dx, 10) * u]), color)
		"landfall":
			# montanha com uma seta para baixo (quando jogas um Terreno)
			draw_colored_polygon(PackedVector2Array([o + Vector2(1.5, 18) * u, o + Vector2(8, 8) * u, o + Vector2(11, 12) * u,
				o + Vector2(13.5, 9) * u, o + Vector2(18.5, 18) * u]), color)
			draw_colored_polygon(PackedVector2Array([o + Vector2(7, 1.5) * u, o + Vector2(13, 1.5) * u, o + Vector2(10, 6.5) * u]), color)
		"prowess":
			# 0.15.0 Destreza: faísca de quatro pontas com um "+" (cada feitiço dá Mult)
			var sp := PackedVector2Array()
			for k in 8:
				var a := -PI / 2.0 + TAU * k / 8.0
				sp.append(o + (Vector2(8.5, 11.5) + Vector2(cos(a), sin(a)) * (7.5 if k % 2 == 0 else 2.4)) * u)
			draw_colored_polygon(sp, color)
			draw_line(o + Vector2(16, 2.5) * u, o + Vector2(16, 8.5) * u, color, 2.0 * u, true)
			draw_line(o + Vector2(13, 5.5) * u, o + Vector2(19, 5.5) * u, color, 2.0 * u, true)
		"persist":
			# 0.15.0 Persistir: seta que sobe de uma lápide (volta à Arena)
			draw_rect(Rect2(o + Vector2(3, 15) * u, Vector2(14, 3) * u), color)
			draw_line(o + Vector2(10, 15) * u, o + Vector2(10, 6) * u, color, 2.4 * u, true)
			draw_colored_polygon(PackedVector2Array([o + Vector2(10, 1.5) * u, o + Vector2(15, 7.5) * u, o + Vector2(5, 7.5) * u]), color)
		"energy":
			# 0.15.0 Energia: raio dentro de um anel
			draw_arc(o + Vector2(10, 10) * u, 8.4 * u, 0.0, TAU, 28, color, 1.6 * u, true)
			draw_colored_polygon(PackedVector2Array([o + Vector2(11, 3.5) * u, o + Vector2(6, 11) * u, o + Vector2(9.5, 11) * u,
				o + Vector2(8.5, 16.5) * u, o + Vector2(14, 8.5) * u, o + Vector2(10.5, 8.5) * u]), color)
		"blood":
			# 0.15.0 Mana de Sangue: uma gota (bico em cima, redonda em baixo) com um brilho
			draw_colored_polygon(PackedVector2Array([o + Vector2(10, 1.6) * u, o + Vector2(15.1, 10.6) * u, o + Vector2(4.9, 10.6) * u]), color)
			draw_circle(o + Vector2(10, 12.4) * u, 5.6 * u, color)
			draw_circle(o + Vector2(8.1, 12.6) * u, 1.4 * u, Color(1, 1, 1, 0.45))
		"weak":
			# 0.15.0 Ponto fraco: mira (anel com quatro traços e um ponto)
			draw_arc(o + Vector2(10, 10) * u, 6.2 * u, 0.0, TAU, 24, color, 1.8 * u, true)
			for d in [Vector2(0, -1), Vector2(0, 1), Vector2(-1, 0), Vector2(1, 0)]:
				draw_line(o + (Vector2(10, 10) + d * 3.4) * u, o + (Vector2(10, 10) + d * 9.4) * u, color, 1.8 * u, true)
			draw_circle(o + Vector2(10, 10) * u, 1.6 * u, color)
		"hourglass":
			# 0.15.0 Ritual: ampulheta
			draw_line(o + Vector2(4, 2.5) * u, o + Vector2(16, 2.5) * u, color, 2.0 * u, true)
			draw_line(o + Vector2(4, 17.5) * u, o + Vector2(16, 17.5) * u, color, 2.0 * u, true)
			draw_colored_polygon(PackedVector2Array([o + Vector2(5.5, 3.5) * u, o + Vector2(14.5, 3.5) * u, o + Vector2(10, 10) * u]), color)
			draw_colored_polygon(PackedVector2Array([o + Vector2(10, 10) * u, o + Vector2(14.5, 16.5) * u, o + Vector2(5.5, 16.5) * u]), Color(color, 0.55))
		"lock":
			# 0.13.0: cadeado (presa no ataque seguinte)
			draw_arc(o + Vector2(10, 8) * u, 4.6 * u, PI, TAU, 16, color, 2.2 * u, true)
			draw_line(o + Vector2(5.4, 8) * u, o + Vector2(5.4, 10) * u, color, 2.2 * u, true)
			draw_line(o + Vector2(14.6, 8) * u, o + Vector2(14.6, 10) * u, color, 2.2 * u, true)
			draw_rect(Rect2(o + Vector2(3.5, 9.5) * u, Vector2(13, 9) * u), color)
			draw_circle(o + Vector2(10, 13.2) * u, 1.5 * u, _inner())
			draw_line(o + Vector2(10, 13.5) * u, o + Vector2(10, 16) * u, _inner(), 1.2 * u, true)
		"mirror":
			# 0.13.0: espelho oval com um reflexo
			var ring := PackedVector2Array()
			for k in 25:
				var a := TAU * k / 24.0
				ring.append(o + (Vector2(10, 9) + Vector2(cos(a) * 6.0, sin(a) * 7.5)) * u)
			draw_colored_polygon(ring, color)
			draw_line(o + Vector2(7.5, 6) * u, o + Vector2(9.5, 4.5) * u, _inner(), 1.4 * u, true)
			draw_line(o + Vector2(10, 16.5) * u, o + Vector2(10, 19) * u, color, 2.0 * u, true)
		"star":
			# 0.13.0: estrela de 5 pontas (jogada perfeita, estrelas dos Desafios)
			var pts := PackedVector2Array()
			for k in 10:
				var a := -PI / 2.0 + TAU * k / 10.0
				var r := (9.0 if k % 2 == 0 else 3.8) * u
				pts.append(o + Vector2(10, 10.5) * u + Vector2(cos(a), sin(a)) * r)
			draw_colored_polygon(pts, color)
		"replay":
			# 0.13.0: seta em círculo (rever o ataque)
			draw_arc(o + Vector2(10, 10) * u, 6.5 * u, -PI * 0.15, PI * 1.45, 24, color, 2.2 * u, true)
			draw_colored_polygon(PackedVector2Array([o + Vector2(14.5, 1.8) * u, o + Vector2(18.5, 7.8) * u, o + Vector2(12, 8.2) * u]), color)
		"exile":
			# 0.13.0: portal (espiral) — exilada
			var sp := PackedVector2Array()
			for k in 40:
				var t := float(k) / 39.0
				var a := t * TAU * 1.6
				sp.append(o + Vector2(10, 10) * u + Vector2(cos(a), sin(a)) * (1.0 + 7.5 * t) * u)
			draw_polyline(sp, color, 2.0 * u, true)
		"potion":
			# frasco redondo com gargalo, rolha e líquido (metade de baixo cheia)
			var c := o + Vector2(10, 12.5) * u
			draw_circle(c, 6.5 * u, Color(color, 0.35))
			var liquid := PackedVector2Array()
			for k in 17:
				var a := PI * float(k) / 16.0
				liquid.append(c + Vector2(cos(a), sin(a)) * 6.5 * u)
			draw_colored_polygon(liquid, color)
			draw_arc(c, 6.5 * u, 0.0, TAU, 28, color, 1.6 * u, true)
			draw_rect(Rect2(o + Vector2(8, 2.5) * u, Vector2(4, 4.5) * u), color, false, 1.5 * u, true)
			draw_rect(Rect2(o + Vector2(7.3, 1.0) * u, Vector2(5.4, 2.0) * u), color)
			draw_circle(c + Vector2(-2.6, -2.4) * u, 1.2 * u, Color(1, 1, 1, 0.75))
		"scroll":
			# pergaminho enrolado nas pontas, com uma fita no meio
			draw_rect(Rect2(o + Vector2(5, 4) * u, Vector2(10, 12) * u), Color(color, 0.35))
			draw_rect(Rect2(o + Vector2(5, 4) * u, Vector2(10, 12) * u), color, false, 1.6 * u, true)
			draw_circle(o + Vector2(5, 4) * u, 2.2 * u, color)
			draw_circle(o + Vector2(15, 4) * u, 2.2 * u, color)
			draw_circle(o + Vector2(5, 16) * u, 2.2 * u, color)
			draw_circle(o + Vector2(15, 16) * u, 2.2 * u, color)
			draw_line(o + Vector2(10, 4) * u, o + Vector2(10, 16) * u, _inner(), 1.6 * u, true)
			draw_colored_polygon(PackedVector2Array([o + Vector2(8, 10) * u, o + Vector2(12, 10) * u, o + Vector2(13, 13) * u, o + Vector2(10, 11.5) * u, o + Vector2(7, 13) * u]), _inner())
		"crown":
			# 0.13.0 (mapa): coroa do boss
			draw_colored_polygon(PackedVector2Array([o + Vector2(3, 15) * u, o + Vector2(3.5, 6) * u, o + Vector2(7, 10) * u, o + Vector2(10, 4) * u,
				o + Vector2(13, 10) * u, o + Vector2(16.5, 6) * u, o + Vector2(17, 15) * u]), color)
			draw_rect(Rect2(o + Vector2(3, 15.8) * u, Vector2(14, 2.4) * u), color)
			draw_circle(o + Vector2(10, 12.2) * u, 1.3 * u, _inner())
		"shop":
			# 0.13.0 (mapa): banca com toldo às riscas
			draw_colored_polygon(PackedVector2Array([o + Vector2(2, 8) * u, o + Vector2(4, 3) * u, o + Vector2(16, 3) * u, o + Vector2(18, 8) * u]), color)
			for k in 3:
				var x := 6.2 + 3.8 * k
				draw_line(o + Vector2(x, 3.2) * u, o + Vector2(x - 0.6 + 0.6 * k, 7.8) * u, _inner(), 1.0 * u, true)
			draw_rect(Rect2(o + Vector2(4, 9) * u, Vector2(12, 8) * u), color)
			draw_rect(Rect2(o + Vector2(8.5, 11.5) * u, Vector2(3, 5.5) * u), _inner())
		"anvil":
			# 0.13.0 (mapa): bigorna com faíscas (Forja)
			draw_colored_polygon(PackedVector2Array([o + Vector2(2, 7) * u, o + Vector2(15, 7) * u, o + Vector2(18.5, 9.2) * u, o + Vector2(13, 9.8) * u,
				o + Vector2(12, 12) * u, o + Vector2(14.5, 15.5) * u, o + Vector2(5.5, 15.5) * u, o + Vector2(8, 12) * u, o + Vector2(4.5, 10.5) * u]), color)
			draw_rect(Rect2(o + Vector2(5, 16) * u, Vector2(10, 2) * u), color)
			for sp in [[Vector2(13, 5), Vector2(14.5, 2)], [Vector2(15.5, 5.5), Vector2(18, 3.2)], [Vector2(11, 5), Vector2(11, 2)]]:
				draw_line(o + (sp[0] as Vector2) * u, o + (sp[1] as Vector2) * u, color, 1.2 * u, true)
		"chest":
			# 0.13.0 (mapa): baú (Tesouro, Cofre)
			var lid := PackedVector2Array([o + Vector2(3, 9) * u])
			for k in 9:
				var a := PI + PI * float(k) / 8.0
				lid.append(o + Vector2(10, 9) * u + Vector2(cos(a) * 7.0, sin(a) * 4.5) * u)
			lid.append(o + Vector2(17, 9) * u)
			draw_colored_polygon(lid, color)
			draw_rect(Rect2(o + Vector2(3, 9) * u, Vector2(14, 8) * u), color)
			draw_line(o + Vector2(3, 10.4) * u, o + Vector2(17, 10.4) * u, _inner(), 1.1 * u, true)
			draw_rect(Rect2(o + Vector2(8.8, 9.5) * u, Vector2(2.4, 3.2) * u), _inner())
		"book":
			# 0.13.0 (mapa): livro aberto (Biblioteca)
			draw_colored_polygon(PackedVector2Array([o + Vector2(2, 5) * u, o + Vector2(9.6, 6.5) * u, o + Vector2(9.6, 17) * u, o + Vector2(2, 15.5) * u]), color)
			draw_colored_polygon(PackedVector2Array([o + Vector2(18, 5) * u, o + Vector2(10.4, 6.5) * u, o + Vector2(10.4, 17) * u, o + Vector2(18, 15.5) * u]), Color(color, 0.85))
			for k in 3:
				var y := 8.5 + 2.4 * k
				draw_line(o + Vector2(3.6, y) * u, o + Vector2(8.2, y + 0.7) * u, _inner(), 0.9 * u, true)
				draw_line(o + Vector2(16.4, y) * u, o + Vector2(11.8, y + 0.7) * u, _inner(), 0.9 * u, true)
		"campfire":
			# 0.13.0 (mapa): fogueira (Acampamento)
			draw_line(o + Vector2(4, 17.5) * u, o + Vector2(16, 13.5) * u, color, 2.2 * u, true)
			draw_line(o + Vector2(4, 13.5) * u, o + Vector2(16, 17.5) * u, color, 2.2 * u, true)
			draw_colored_polygon(PackedVector2Array([o + Vector2(10, 2.5) * u, o + Vector2(13.8, 8.5) * u, o + Vector2(13, 12) * u, o + Vector2(10, 13.4) * u,
				o + Vector2(7, 12) * u, o + Vector2(6.2, 8.5) * u]), color)
			draw_colored_polygon(PackedVector2Array([o + Vector2(10, 7) * u, o + Vector2(11.6, 10) * u, o + Vector2(10, 12) * u, o + Vector2(8.4, 10) * u]), _inner())
		"flag":
			# 0.13.0 (mapa): bandeira (fim do ato)
			draw_line(o + Vector2(5, 2) * u, o + Vector2(5, 18) * u, color, 1.8 * u, true)
			draw_colored_polygon(PackedVector2Array([o + Vector2(5.8, 3) * u, o + Vector2(16, 3) * u, o + Vector2(13, 6.5) * u, o + Vector2(16, 10) * u, o + Vector2(5.8, 10) * u]), color)
		"relic":
			# estrela de 4 pontas
			draw_polygon(PackedVector2Array([o + Vector2(10, 1) * u, o + Vector2(12.5, 7.5) * u, o + Vector2(19, 10) * u, o + Vector2(12.5, 12.5) * u, o + Vector2(10, 19) * u, o + Vector2(7.5, 12.5) * u, o + Vector2(1, 10) * u, o + Vector2(7.5, 7.5) * u]), PackedColorArray([color]))
		"swords":
			# 0.16.0: duas espadas cruzadas (atacar, o golpe do inimigo)
			for m in [1.0, -1.0]:
				var segs := [[Vector2(6.2, 13.8), Vector2(17.2, 2.8), 2.4], [Vector2(3.4, 11.6), Vector2(8.4, 16.6), 1.8], [Vector2(2.4, 17.6), Vector2(5.4, 14.6), 2.4]]
				for sg in segs:
					var p0: Vector2 = sg[0]
					var p1: Vector2 = sg[1]
					draw_line(o + Vector2(10.0 + (p0.x - 10.0) * m, p0.y) * u, o + Vector2(10.0 + (p1.x - 10.0) * m, p1.y) * u, color, float(sg[2]) * u, true)
		"pause":
			# 0.16.0: duas barras (pausa)
			draw_rect(Rect2(o + Vector2(5, 3.5) * u, Vector2(3.6, 13) * u), color)
			draw_rect(Rect2(o + Vector2(11.4, 3.5) * u, Vector2(3.6, 13) * u), color)
		"undo":
			# 0.16.0: seta curva para trás (desfazer)
			draw_arc(o + Vector2(11, 11) * u, 6.0 * u, 0.35, -PI, 20, color, 2.3 * u, true)
			draw_colored_polygon(PackedVector2Array([o + Vector2(1.8, 9.6) * u, o + Vector2(8.2, 9.6) * u, o + Vector2(5.0, 14.6) * u]), color)
		"speed":
			# 0.16.0: dois triângulos (velocidade das animações)
			draw_colored_polygon(PackedVector2Array([o + Vector2(2.5, 4) * u, o + Vector2(10, 10) * u, o + Vector2(2.5, 16) * u]), color)
			draw_colored_polygon(PackedVector2Array([o + Vector2(10, 4) * u, o + Vector2(17.5, 10) * u, o + Vector2(10, 16) * u]), color)
		"sort":
			# 0.16.0: três barras a encolher (ordenar a mão)
			for k in 3:
				draw_rect(Rect2(o + Vector2(3, 4 + 4.6 * k) * u, Vector2(14 - 4 * k, 2.6) * u), color)
		"mult":
			# 0.16.0: um × grosso (Mult)
			draw_line(o + Vector2(4.5, 4.5) * u, o + Vector2(15.5, 15.5) * u, color, 3.2 * u, true)
			draw_line(o + Vector2(15.5, 4.5) * u, o + Vector2(4.5, 15.5) * u, color, 3.2 * u, true)
		"x":
			# 0.16.0: cruz de remover / fechar
			draw_line(o + Vector2(4.5, 4.5) * u, o + Vector2(15.5, 15.5) * u, color, 2.6 * u, true)
			draw_line(o + Vector2(15.5, 4.5) * u, o + Vector2(4.5, 15.5) * u, color, 2.6 * u, true)
		"play":
			# 0.16.0: triângulo de «continuar»
			draw_colored_polygon(PackedVector2Array([o + Vector2(6, 3.5) * u, o + Vector2(16.5, 10) * u, o + Vector2(6, 16.5) * u]), color)
		"gear":
			# 0.16.0: roda dentada (Configurações)
			var gc := o + Vector2(10, 10) * u
			var teeth := PackedVector2Array()
			for k in 16:
				var a := TAU * k / 16.0
				var rr := (8.6 if k % 2 == 0 else 6.6) * u
				teeth.append(gc + Vector2(cos(a - 0.12), sin(a - 0.12)) * rr)
				teeth.append(gc + Vector2(cos(a + 0.12), sin(a + 0.12)) * rr)
			draw_colored_polygon(teeth, color)
			draw_circle(gc, 2.8 * u, _inner())
		"pack":
			# 0.16.0: pacote de booster (faixas serrilhadas em cima e em baixo, losango ao meio)
			draw_rect(Rect2(o + Vector2(4.5, 3.5) * u, Vector2(11, 13) * u), color)
			for top in [true, false]:
				var y0 := 3.5 if top else 16.5
				var tz := PackedVector2Array()
				for k in 7:
					var x := 4.5 + 11.0 * k / 6.0
					tz.append(o + Vector2(x, y0 + (-1.4 if (k % 2 == 0) == top else 0.0) * (1.0 if top else -1.0)) * u)
				tz.append(o + Vector2(15.5, y0 + (1.6 if top else -1.6)) * u)
				tz.append(o + Vector2(4.5, y0 + (1.6 if top else -1.6)) * u)
				draw_colored_polygon(tz, color.lightened(0.35))
			draw_colored_polygon(PackedVector2Array([o + Vector2(10, 6.6) * u, o + Vector2(12.6, 10) * u, o + Vector2(10, 13.4) * u, o + Vector2(7.4, 10) * u]), _inner())
		"ticket":
			# 0.16.0: bilhete dourado com dois recortes e o picotado (Vales)
			var t := PackedVector2Array([o + Vector2(2, 5) * u, o + Vector2(18, 5) * u])
			for k in 7:
				var a := -PI / 2.0 - PI * float(k) / 6.0
				t.append(o + (Vector2(18, 10) + Vector2(cos(a), sin(a)) * 2.4) * u)
			t.append_array([o + Vector2(18, 15) * u, o + Vector2(2, 15) * u])
			for k in 7:
				var a := PI / 2.0 - PI * float(k) / 6.0
				t.append(o + (Vector2(2, 10) + Vector2(cos(a), sin(a)) * 2.4) * u)
			draw_colored_polygon(t, color)
			for k in 4:
				draw_line(o + Vector2(13.4, 6.2 + 2.3 * k) * u, o + Vector2(13.4, 7.4 + 2.3 * k) * u, _inner(), 1.0 * u)
			var st := PackedVector2Array()
			for k in 8:
				var a := TAU * k / 8.0 - PI / 2.0
				st.append(o + (Vector2(7.6, 10) + Vector2(cos(a), sin(a)) * (3.0 if k % 2 == 0 else 1.1)) * u)
			draw_colored_polygon(st, _inner())
		"cards":
			# 0.16.0: duas cartas (ver o baralho)
			draw_rect(Rect2(o + Vector2(7.5, 2.5) * u, Vector2(9.5, 13) * u), Color(color, 0.55))
			draw_rect(Rect2(o + Vector2(3, 4.5) * u, Vector2(9.5, 13) * u), color)
			draw_rect(Rect2(o + Vector2(4.6, 6.1) * u, Vector2(6.3, 9.8) * u), _inner(), false, 1.0 * u)
		"menu":
			# 0.16.0: casa (voltar ao menu)
			draw_colored_polygon(PackedVector2Array([o + Vector2(1.8, 10) * u, o + Vector2(10, 2.5) * u, o + Vector2(18.2, 10) * u]), color)
			draw_rect(Rect2(o + Vector2(4.5, 9.5) * u, Vector2(11, 8) * u), color)
			draw_rect(Rect2(o + Vector2(8.5, 12) * u, Vector2(3, 5.5) * u), _inner())

## Cor dos detalhes por dentro de um ícone (o + do coração, a estrela do escudo, a pupila do olho):
## escura nos ícones claros e clara nos escuros, para se ver nas cartas de qualquer cor.
func _inner() -> Color:
	return Color(0.08, 0.08, 0.1, 0.9) if color.get_luminance() > 0.55 else Color(1, 1, 1, 0.92)

## Modo daltónico (0.15.0: desenhos próprios): estrela (branco), onda (azul), lua (preto), faísca (vermelho),
## folha (verde), losango (incolor) — desenhados por cima do pip com uma cor que contrasta.
func _draw_mana_symbol(o: Vector2, u: float) -> void:
	var ink := Color(0.95, 0.95, 0.95) if mana_color == "black" else Color(0.08, 0.08, 0.1, 0.92)
	var c := o + Vector2(10, 10) * u
	match mana_color:
		"white":
			# estrela de quatro pontas
			var pts := PackedVector2Array()
			for k in 8:
				var a := TAU * k / 8.0 - PI / 2.0
				pts.append(c + Vector2(cos(a), sin(a)) * (5.4 if k % 2 == 0 else 1.7) * u)
			draw_colored_polygon(pts, ink)
		"blue":
			# duas ondas
			for dy in [-1.8, 2.0]:
				var w := PackedVector2Array()
				for k in 9:
					var x := -4.6 + k * 1.15
					w.append(c + Vector2(x, dy + sin(k * 0.8) * 1.3) * u)
				draw_polyline(w, ink, 1.7 * u, true)
		"black":
			# lua em quarto crescente
			draw_circle(c, 4.6 * u, ink)
			draw_circle(c + Vector2(2.2, -1.2) * u, 3.9 * u, color)
		"red":
			# faísca em zigue-zague
			draw_colored_polygon(PackedVector2Array([c + Vector2(1.6, -5.4) * u, c + Vector2(-3.2, 0.8) * u, c + Vector2(-0.2, 0.8) * u,
				c + Vector2(-1.8, 5.4) * u, c + Vector2(3.4, -1.2) * u, c + Vector2(0.4, -1.2) * u]), ink)
		"green":
			# folha com nervura
			var leaf := PackedVector2Array()
			for k in 13:
				var t := k / 12.0
				leaf.append(c + Vector2(-4.4 + 8.8 * t, -sin(t * PI) * 3.4) * u)
			for k in range(11, 0, -1):
				var t := k / 12.0
				leaf.append(c + Vector2(-4.4 + 8.8 * t, sin(t * PI) * 2.0) * u)
			draw_colored_polygon(leaf, ink)
			draw_line(c + Vector2(-4.4, 0) * u, c + Vector2(4.4, -0.4) * u, color, 0.9 * u, true)
		_:
			draw_colored_polygon(PackedVector2Array([c + Vector2(0, -4.5) * u, c + Vector2(4.5, 0) * u, c + Vector2(0, 4.5) * u, c + Vector2(-4.5, 0) * u]), ink)

## Pip de cor (com o símbolo do modo daltónico, se estiver ligado).
static func pip(mana: String, size_px: float = 12.0) -> CardIcon:
	var col: Color = CardView.COLORS.get(mana, CardView.COLORS.colorless)
	var p := CardIcon.new("pip", col, size_px + (4.0 if Settings.colorblind else 0.0))
	p.mana_color = mana
	return p

static func kind_for(d: CardData) -> String:
	if d.is_curse():
		return "curse"
	if d.is_creature():
		return "creature"
	if d.is_land():
		return "land"
	if d.is_enchantment():
		return "enchantment"
	if d.is_equipment():
		return "equipment"
	return "instant" if d.subtype == "instant" else "sorcery"

## 0.16.0 (a moeda nova, escolhida pelo AlizeOnMe): aro escuro com um filete claro, cara com luz de cima à
## esquerda, uma estrela de 4 pontas cunhada (sombra clara por baixo, traço escuro por cima) e um brilho.
## Só polígonos e círculos cheios (nada de arcos suaves): poucos comandos de desenho, nítida em qualquer tamanho.
func _draw_coin(c: Vector2, u: float) -> void:
	draw_circle(c + Vector2(0, 0.7) * u, 8.8 * u, Color(0, 0, 0, 0.32))
	draw_circle(c, 8.7 * u, color.darkened(0.45))
	draw_circle(c, 8.0 * u, color.lightened(0.28))
	# Cara: um leque de cores (claro no ponto de luz, mais escuro na borda).
	var lc := c + Vector2(-1.7, -1.9) * u
	var pts := PackedVector2Array([lc])
	var cols := PackedColorArray([color.lightened(0.42)])
	for i in 25:
		var a := TAU * i / 24.0
		pts.append(c + Vector2(cos(a), sin(a)) * 7.0 * u)
		cols.append(color.darkened(0.16).lerp(color, 0.5 + 0.5 * cos(a + 2.3)))
	draw_polygon(pts, cols)
	# Estrela cunhada.
	var star := PackedVector2Array()
	for k in 8:
		var a := -PI / 2.0 + PI / 4.0 * k
		var r := (4.6 if k % 2 == 0 else 1.5) * u
		star.append(Vector2(cos(a), sin(a)) * r)
	var light := PackedVector2Array()
	var dark := PackedVector2Array()
	for q in star:
		light.append(c + q + Vector2(0.45, 0.45) * u)
		dark.append(c + q)
	draw_colored_polygon(light, Color(color.lightened(0.55), 0.85))
	draw_colored_polygon(dark, color.darkened(0.38))
	# Brilho em cima à esquerda.
	var sc := c + Vector2(-3.0, -4.3) * u
	var spec := PackedVector2Array([sc])
	var scol := PackedColorArray([Color(1, 1, 1, 0.62)])
	for i in 13:
		var a := TAU * i / 12.0
		spec.append(sc + Vector2(cos(a) * 2.5, sin(a) * 1.1).rotated(-0.55) * u)
		scol.append(Color(1, 1, 1, 0.0))
	draw_polygon(spec, scol)
