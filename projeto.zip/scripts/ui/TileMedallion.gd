class_name TileMedallion
extends Control
## 0.13.1 (visual "Grimório dourado"): medalhão redondo nos botões do menu, com a ilustração de um ícone
## do mapa (assets/art/mapnodes), aro dourado e um brilho suave por trás. Sem a ilustração fica só o aro.

const GOLD := Color(0.97, 0.84, 0.5)

var art_id := ""
var _tex: Texture2D = null

func _init(p_art_id: String = "", p_size: float = 46.0) -> void:
	art_id = p_art_id
	custom_minimum_size = Vector2(p_size, p_size)
	size_flags_vertical = Control.SIZE_SHRINK_CENTER
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _ready() -> void:
	if art_id != "" and ArtLib.has("mapnode", art_id):
		_tex = ArtLib.texture("mapnode", art_id)
	resized.connect(queue_redraw)

func has_art() -> bool:
	return _tex != null

func _draw() -> void:
	var c := size * 0.5
	var r := minf(size.x, size.y) * 0.5 - 2.0
	if r <= 2.0:
		return
	draw_texture_rect(MenuBackdrop.glow_texture(), Rect2(c - Vector2(r, r) * 1.6, Vector2(r, r) * 3.2), false, Color(GOLD, 0.28))
	draw_circle(c, r, Color(0.08, 0.06, 0.13))
	if _tex != null:
		ArtLib.draw_round(self, _tex, c, r - 1.0)
	draw_arc(c, r, 0.0, TAU, 48, GOLD, 2.0, true)
