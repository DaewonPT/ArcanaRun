class_name CelebrationFx
extends Node2D
## 0.13.0: fim da batalha com mais festa — "confetti" (vitória: papelinhos coloridos a rebentar de dois
## canhões nos cantos de baixo e a cair a rodar) e "ash" (derrota: cinza a cair devagar pelo ecrã todo,
## com brasas a apagar). Desenhado em código, ~2.4 s; nada com o movimento reduzido; menos peças no
## modo de desempenho.

const CONFETTI_COLORS := [Color(0.98, 0.78, 0.3), Color(0.95, 0.35, 0.45), Color(0.4, 0.75, 1.0), Color(0.5, 0.9, 0.55), Color(0.85, 0.55, 1.0), Color(1, 1, 1)]

var kind := "confetti"
var _bits: Array = []
var _t := 0.0
var _dur := 2.4
var _rng := RandomNumberGenerator.new()

static func play(parent: Node, area: Rect2, p_kind: String) -> void:
	if parent == null or not is_instance_valid(parent) or not parent.is_inside_tree() or not Settings.motion_ok():
		return
	var fx := CelebrationFx.new()
	fx.kind = p_kind
	fx.z_index = 60
	parent.add_child(fx)
	fx.global_position = Vector2.ZERO
	fx._start(area)

func _start(area: Rect2) -> void:
	_rng.randomize()
	var many := not Settings.performance_mode
	if kind == "confetti":
		for side in [0, 1]:
			var origin := Vector2(area.position.x + (area.size.x * 0.08 if side == 0 else area.size.x * 0.92), area.end.y + 10.0)
			for i in (70 if many else 30):
				var a := -PI / 2.0 + (0.45 if side == 0 else -0.45) + _rng.randf_range(-0.35, 0.35)
				var v := Vector2(cos(a), sin(a)) * _rng.randf_range(650.0, 1150.0)
				_bits.append({"p": origin, "v": v, "rot": _rng.randf() * TAU, "spin": _rng.randf_range(-9.0, 9.0),
					"w": _rng.randf_range(6.0, 11.0), "h": _rng.randf_range(3.0, 6.0),
					"c": CONFETTI_COLORS[_rng.randi() % CONFETTI_COLORS.size()], "delay": _rng.randf() * 0.25})
	else:
		_dur = 2.8
		for i in (90 if many else 40):
			var p := Vector2(area.position.x + _rng.randf() * area.size.x, area.position.y - _rng.randf() * area.size.y * 0.6)
			var ember := _rng.randf() < 0.18
			_bits.append({"p": p, "v": Vector2(_rng.randf_range(-25.0, 25.0), _rng.randf_range(60.0, 140.0)), "rot": _rng.randf() * TAU,
				"spin": _rng.randf_range(-2.0, 2.0), "w": _rng.randf_range(3.0, 7.0), "h": _rng.randf_range(2.0, 4.0),
				"c": Color(1.0, 0.55, 0.2) if ember else Color(0.55, 0.55, 0.58).lightened(_rng.randf_range(-0.2, 0.2)),
				"delay": _rng.randf() * 0.6, "ember": ember})

func _process(delta: float) -> void:
	_t += delta
	for b in _bits:
		if _t < float(b["delay"]):
			continue
		var v: Vector2 = b["v"]
		if kind == "confetti":
			v.y += 1300.0 * delta
			v *= pow(0.12, delta)   # arrasto do ar: depois de subir, flutua
			v.x += sin(_t * 6.0 + float(b["rot"])) * 30.0 * delta
		else:
			v.x += sin(_t * 2.0 + float(b["rot"])) * 20.0 * delta
		b["v"] = v
		b["p"] = (b["p"] as Vector2) + v * delta
		b["rot"] = float(b["rot"]) + float(b["spin"]) * delta
	queue_redraw()
	if _t >= _dur:
		queue_free()

func _draw() -> void:
	var fade := clampf((_dur - _t) / 0.6, 0.0, 1.0)
	for b in _bits:
		if _t < float(b["delay"]):
			continue
		var col: Color = b["c"]
		var a := fade
		if bool(b.get("ember", false)):
			a *= 0.5 + 0.5 * sin(_t * 9.0 + float(b["rot"]))
		var w: float = b["w"]
		var h: float = b["h"]
		if kind == "confetti":
			h *= absf(cos(float(b["rot"]) * 1.7)) * 0.8 + 0.2   # vira no ar
		draw_set_transform(b["p"], float(b["rot"]), Vector2.ONE)
		draw_rect(Rect2(-w * 0.5, -h * 0.5, w, h), Color(col, col.a * a))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
