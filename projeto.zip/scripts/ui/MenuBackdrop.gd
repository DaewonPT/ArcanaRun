class_name MenuBackdrop
extends Control
## Fundo animado do ecrã inicial, desenhado em código. Redesenha a ~30 fps; com o movimento reduzido fica
## parado (desenhado uma vez); no modo de desempenho tem menos partículas e 20 fps.
## 0.13.1 (visual "Grimório dourado" com o fundo "Arcano vivo"): a ilustração das ilhas a flutuar
## (background act_E), escurecida à esquerda para o título se ler; atrás do título um círculo de runas em
## duas camadas que rodam devagar em sentidos contrários; faíscas nas cinco cores de mana a subir, poeira
## dourada e estrelas a cintilar. Sem a ilustração, fica o fundo da 0.12.0 (aurora, orbes e cartas fantasma).
## 0.14.0: o círculo de runas é desenhado uma só vez, em duas camadas (RuneRing) que só rodam — antes era
## refeito peça a peça 30 vezes por segundo (~220 peças) e pesava no telemóvel; cada camada são agora 2 ou 3
## comandos de desenho. Fica centrado no texto do título e volta ao sítio certo sempre que o título muda de
## lugar (também com "Reduzir movimento", em que o fundo não anima).

const MANA := [Color(0.93, 0.89, 0.74), Color(0.38, 0.56, 0.88), Color(0.55, 0.42, 0.72), Color(0.86, 0.36, 0.30), Color(0.40, 0.66, 0.40)]
## Cores das faíscas (mais vivas do que as das orbes, porque são pequenas).
const SPARK := [Color(1.0, 0.95, 0.77), Color(0.37, 0.71, 1.0), Color(0.78, 0.61, 1.0), Color(1.0, 0.42, 0.37), Color(0.44, 0.88, 0.54)]
const RUNE_VIOLET := Color(0.78, 0.65, 1.0)
const RUNE_GOLD := Color(0.97, 0.84, 0.5)
const ART_ID := "act_E"
## 0.16.1 (V57): fundo dos ecrãs de menu (Coleção, Construtor, Talentos, Estatísticas) — sem o círculo de
## runas, mais escuro para a grelha se ler, a ~15 fps e só nos segundos a seguir a um toque (parado no
## resto do tempo: com o modo de baixo consumo desses ecrãs, o telemóvel quase não trabalha).
var quiet := false
## 0.16.1 (69): o céu acompanha a hora do telemóvel — madrugada rosada, dia limpo, fim de tarde dourado e
## noite azul-escura com mais estrelas. Fica escolhida ao abrir o ecrã (hora local).
var sky := ""

var anchor := Vector2(0.27, 0.36)   # centro das órbitas/runas (fração do ecrã) se não houver título
## O título do menu: o círculo de runas fica centrado nele (e muda de sítio com ele).
var title_node: Control = null:
	set(v):
		if title_node != null and is_instance_valid(title_node) and title_node.item_rect_changed.is_connected(_queue_place):
			title_node.item_rect_changed.disconnect(_queue_place)
		title_node = v
		if title_node != null:
			title_node.item_rect_changed.connect(_queue_place)
			# A coluna do título também se pode mexer sem o título mudar de sítio dentro dela.
			var parent := title_node.get_parent() as Control
			if parent != null and not parent.item_rect_changed.is_connected(_queue_place):
				parent.item_rect_changed.connect(_queue_place)
		_queue_place()
var art: Texture2D = null
var _rune_a: RuneRing = null        # anel de pontos, anel dourado, setas e runas (roda num sentido)
var _rune_b: RuneRing = null        # anel tracejado e estrela de seis pontas (roda no outro)
var _place_queued := false
var _t := 0.0
var _acc := 0.0
var _stars: Array = []
var _sparks: Array = []
var _motes: Array = []
var _glyphs: Array = []             # runas: cada uma é uma lista de segmentos [a, b] numa grelha 3×4
var _rng := RandomNumberGenerator.new()
static var _glow_tex: GradientTexture2D

## Mancha redonda e suave (branco no centro a transparente na borda), pintada com a cor que se quiser.
static func glow_texture() -> GradientTexture2D:
	if _glow_tex == null:
		var g := Gradient.new()
		g.set_color(0, Color(1, 1, 1, 1))
		g.set_color(1, Color(1, 1, 1, 0))
		g.add_point(0.45, Color(1, 1, 1, 0.45))
		var t := GradientTexture2D.new()
		t.gradient = g
		t.fill = GradientTexture2D.FILL_RADIAL
		t.fill_from = Vector2(0.5, 0.5)
		t.fill_to = Vector2(1.0, 0.5)
		t.width = 128
		t.height = 128
		_glow_tex = t
	return _glow_tex

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)

## A fase do dia de uma hora (0–23): "dawn" (5–7), "day" (8–16), "dusk" (17–19) ou "night".
static func sky_for_hour(hour: int) -> String:
	if hour >= 5 and hour < 8:
		return "dawn"
	if hour >= 8 and hour < 17:
		return "day"
	if hour >= 17 and hour < 20:
		return "dusk"
	return "night"

## 297: o fundo do menu — «act» (o ato da tua última run; sem runs, o de sempre), «faction» (a paisagem da cor
## do baralho que mais jogas) ou «plain» (liso, sem ilustração).
const FACTION_ART := {"red": "clim_scorching_sands", "blue": "clim_high_tide", "green": "clim_fertile_land",
	"black": "clim_blood_moon", "white": "clim_comet_sky", "colorless": "clim_mana_eclipse"}

static func menu_art_id() -> String:
	match String(Settings.opt("menu_bg")):
		"plain":
			return ""
		"faction":
			var dp = Stats.stats().get("decks_played", {})
			var best := ""
			var most := 0
			if dp is Dictionary:
				for k in dp:
					if int(float(dp[k])) > most:
						most = int(float(dp[k]))
						best = String(k)
			var cols: Array = CardDB.get_deck(best).get("colors", []) if best != "" else []
			return String(FACTION_ART.get(String(cols[0]) if not cols.is_empty() else "colorless", ART_ID))
	var slot := GameState.latest_slot()
	if slot > 0:
		var a := int(GameState.slot_info(slot).get("ante", 0))
		if a > 0:
			var act := clampi(GameState.act_of_ante(a), 1, 4)
			return "act_%d" % act
	return ART_ID

func _ready() -> void:
	Settings.changed.connect(queue_redraw)   # 0.19.0 (216): o tema preto (e as outras opções) redesenham já
	_rng.seed = 2026
	if sky == "":
		sky = sky_for_hour(int(Time.get_datetime_dict_from_system().get("hour", 12)))
	var aid := menu_art_id()   # 0.19.0 (297): o fundo do menu à escolha
	if aid != "" and ArtLib.has("background", aid):
		art = ArtLib.texture("background", aid)
	var few := Settings.performance_mode or quiet
	var n := (40 if few else 90) if art == null else (16 if few else 34)
	if sky == "night":
		n = int(n * 1.6)   # mais estrelas à noite
	for i in n:
		_stars.append({"x": _rng.randf(), "y": _rng.randf(), "r": _rng.randf_range(0.6, 1.8), "s": _rng.randf_range(0.006, 0.02),
			"ph": _rng.randf() * TAU, "tw": _rng.randf_range(0.6, 2.2)})
	for i in (8 if few else 16):
		# Faíscas: nascem em baixo (sobretudo do lado do título), sobem uns 25–40 % do ecrã e apagam-se.
		var left_side := i % 4 != 3
		_sparks.append({"x": _rng.randf_range(0.03, 0.55) if left_side else _rng.randf_range(0.58, 0.98), "y": _rng.randf_range(0.82, 1.04),
			"d": _rng.randf_range(0.25, 0.4), "p": _rng.randf_range(5.0, 8.5), "ph": _rng.randf(), "c": i % SPARK.size(),
			"r": _rng.randf_range(2.0, 3.0), "sw": _rng.randf() * TAU})
	for i in (4 if few else 9):
		_motes.append({"x": _rng.randf_range(0.05, 0.95), "y": _rng.randf_range(0.55, 1.0), "d": _rng.randf_range(0.18, 0.3),
			"p": _rng.randf_range(7.0, 10.0), "ph": _rng.randf(), "r": _rng.randf_range(1.4, 2.2)})
	for i in 16:
		var segs: Array = []
		for k in _rng.randi_range(2, 3):
			var a := Vector2(_rng.randi_range(0, 2), _rng.randi_range(0, 3))
			var b := Vector2(_rng.randi_range(0, 2), _rng.randi_range(0, 3))
			if a == b:
				b = Vector2(2 - a.x, 3 - a.y)
			segs.append([a, b])
		_glyphs.append(segs)
	_t = _rng.randf() * 10.0
	if art != null and not quiet and not Settings.black_theme():
		_rune_a = RuneRing.new()
		_rune_a.name = "RunesOuter"
		_rune_a.outer = true
		_rune_a.glyphs = _glyphs
		add_child(_rune_a)
		_rune_b = RuneRing.new()
		_rune_b.name = "RunesInner"
		_rune_b.outer = false
		add_child(_rune_b)
	resized.connect(_queue_place)
	set_process(Settings.motion_ok())
	_queue_place()
	queue_redraw()

func _process(delta: float) -> void:
	if quiet and not SceneRouter.is_awake():
		return   # parado (nada se redesenha) até voltares a tocar no ecrã
	if SceneRouter.decor_still() or Settings.black_theme():
		return   # 0.19.0 (207, 208, 216, 224): por trás de uma janela, sem foco, a descansar ou no tema preto
	_t += delta
	_acc += delta
	_place_runes(false)   # só posição e rotação (as camadas não se redesenham)
	var step := 1.0 / (15.0 if quiet else (20.0 if Settings.performance_mode else 30.0))
	if _acc >= step:
		_acc = 0.0
		queue_redraw()

func _queue_place() -> void:
	if _place_queued or not is_inside_tree():
		return
	_place_queued = true
	_place_runes.call_deferred()

## Põe o círculo no centro do título e no tamanho do ecrã (as camadas só se redesenham se o raio mudar).
func _place_runes(redraw: bool = true) -> void:
	if redraw:
		_place_queued = false
	if _rune_a == null:
		return
	var c := rune_center()
	var r := size.y * 0.36
	for ring in [_rune_a, _rune_b]:
		(ring as RuneRing).position = c
		if absf((ring as RuneRing).r - r) > 0.5:
			(ring as RuneRing).r = r
			(ring as RuneRing).queue_redraw()
	_turn_runes()
	if not redraw:
		return
	queue_redraw()   # o brilho por trás do círculo
	# O layout pode ainda não ter assentado (título com tamanho 0): volta a tentar no frame seguinte.
	if title_node != null and is_instance_valid(title_node) and title_node.size.x <= 0.0 and not get_tree().process_frame.is_connected(_queue_place):
		get_tree().process_frame.connect(_queue_place, CONNECT_ONE_SHOT)

func _turn_runes() -> void:
	if _rune_a != null:
		_rune_a.rotation = _t * TAU / 60.0
		_rune_b.rotation = -_t * TAU / 90.0

## Centro do círculo de runas: o meio do texto do título (ou a âncora, sem título). 0.14.0: a caixa do
## título estica nos ecrãs largos; conta só a largura do texto (alinhado à esquerda).
func rune_center() -> Vector2:
	if title_node != null and is_instance_valid(title_node) and title_node.is_inside_tree() and title_node.size.x > 0.0:
		var w := title_node.size.x
		var lbl := title_node as Label
		if lbl != null and lbl.horizontal_alignment == HORIZONTAL_ALIGNMENT_LEFT:
			var font := lbl.get_theme_font("font")
			if font != null:
				w = minf(w, font.get_string_size(lbl.text, HORIZONTAL_ALIGNMENT_LEFT, -1, lbl.get_theme_font_size("font_size")).x)
		# No sítio do título no layout (sem a escala da animação de entrada do próprio título).
		var local := title_node.position + Vector2(w * 0.5, title_node.size.y * 0.5)
		var parent := title_node.get_parent() as CanvasItem
		var global := parent.get_global_transform() * local if parent != null else local
		return get_global_transform().affine_inverse() * global
	return Vector2(size.x * anchor.x, size.y * anchor.y)

func _draw() -> void:
	var s := size
	if s.x < 10.0:
		return
	if Settings.black_theme():   # 0.19.0 (216): preto a sério (nos OLED, preto é ecrã apagado)
		draw_rect(Rect2(Vector2.ZERO, s), Color.BLACK)
		return
	if art != null:
		_draw_art(s)
	else:
		_draw_aurora(s)
	_draw_sky(s)
	if quiet:
		draw_rect(Rect2(Vector2.ZERO, s), Color(0.04, 0.03, 0.08, 0.38))
	# Estrelas: sobem devagar e cintilam.
	for st in _stars:
		var y := fmod(float(st.y) - _t * float(st.s) + 10.0, 1.0)
		var a := 0.25 + 0.35 * (0.5 + 0.5 * sin(_t * float(st.tw) + float(st.ph)))
		draw_circle(Vector2(float(st.x) * s.x, y * s.y), float(st.r), Color(1, 0.96, 0.88, a * (0.8 if art != null else 1.0)))
	if art != null:
		if not quiet:
			var r := s.y * 0.36
			draw_texture_rect(glow_texture(), Rect2(rune_center() - Vector2(r, r) * 1.1, Vector2(r, r) * 2.2), false, Color(0.55, 0.35, 1.0, 0.18))
		_draw_sparks(s)
	else:
		for i in 2:
			var cx := s.x * (0.12 + 0.3 * i) + 30.0 * sin(_t * 0.2 + i)
			var cy := s.y * (0.72 - 0.08 * i) + 18.0 * cos(_t * 0.17 + i * 2.0)
			_ghost_card(Vector2(cx, cy), 0.22 * sin(_t * 0.12 + i * 1.7), 0.75 + 0.15 * i)
		_draw_orbs(s)

## A ilustração a cobrir o ecrã, escurecida: mais à esquerda (título e texto) e nos cantos.
func _draw_art(s: Vector2) -> void:
	draw_texture_rect_region(art, Rect2(Vector2.ZERO, s), ArtLib.cover_region(art, s, 0.5))
	var dark := Color(0.055, 0.035, 0.11)
	var l := Color(dark, 0.86)
	var m := Color(dark, 0.52)
	var r := Color(dark, 0.78)
	draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(s.x * 0.5, 0), Vector2(s.x * 0.5, s.y), Vector2(0, s.y)]), PackedColorArray([l, m, m, l]))
	draw_polygon(PackedVector2Array([Vector2(s.x * 0.5, 0), Vector2(s.x, 0), Vector2(s.x, s.y), Vector2(s.x * 0.5, s.y)]), PackedColorArray([m, r, r, m]))
	# Vinheta: cantos mais escuros (quatro manchas grandes e suaves fora do ecrã).
	for corner in [Vector2(0, 0), Vector2(s.x, 0), Vector2(0, s.y), Vector2(s.x, s.y)]:
		var rad := s.y * 0.75
		draw_texture_rect(glow_texture(), Rect2(corner - Vector2(rad, rad), Vector2(rad, rad) * 2.0), false, Color(0.02, 0.01, 0.05, 0.55))

## O tom da hora do dia por cima da ilustração: em cima (o céu) e junto ao horizonte.
func _draw_sky(s: Vector2) -> void:
	var top := Color(0, 0, 0, 0)
	var low := Color(0, 0, 0, 0)
	match sky:
		"dawn":
			top = Color(0.55, 0.35, 0.65, 0.16)
			low = Color(1.0, 0.55, 0.45, 0.2)
		"dusk":
			top = Color(0.45, 0.2, 0.5, 0.18)
			low = Color(1.0, 0.5, 0.22, 0.24)
		"night":
			top = Color(0.02, 0.03, 0.12, 0.4)
			low = Color(0.05, 0.08, 0.25, 0.28)
		_:
			return
	var mid := Color(low, low.a * 0.4)
	draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(s.x, 0), Vector2(s.x, s.y * 0.55), Vector2(0, s.y * 0.55)]), PackedColorArray([top, top, mid, mid]))
	draw_polygon(PackedVector2Array([Vector2(0, s.y * 0.55), Vector2(s.x, s.y * 0.55), Vector2(s.x, s.y), Vector2(0, s.y)]), PackedColorArray([mid, mid, low, low]))

func _draw_aurora(s: Vector2) -> void:
	for i in 3:
		var col: Color = MANA[(i * 2 + 1) % MANA.size()]
		var c := Vector2(s.x * (0.25 + 0.5 * (0.5 + 0.5 * sin(_t * 0.05 + i * 2.1))), s.y * (0.3 + 0.4 * (0.5 + 0.5 * sin(_t * 0.037 + i * 1.3))))
		var r := s.y * (0.6 + 0.1 * sin(_t * 0.08 + i))
		draw_texture_rect(glow_texture(), Rect2(c - Vector2(r, r), Vector2(r, r) * 2.0), false, Color(col, 0.09))

## Círculo de runas atrás do título, numa camada que se desenha uma vez (à volta do seu centro) e depois
## só roda. Camada de fora: anel de pontos, anel dourado com quatro setas e dezasseis runas. Camada de
## dentro: anel tracejado e estrela de seis pontas. Junta as peças iguais num só comando de desenho.
class RuneRing extends Node2D:
	var outer := true
	var r := 0.0
	var glyphs: Array = []            # runas: segmentos [a, b] numa grelha 3×4

	func _draw() -> void:
		if r < 4.0:
			return
		if outer:
			_draw_outer()
		else:
			_draw_inner()

	func _draw_outer() -> void:
		# Pontos (pequenos quadrados tangentes ao anel) e as quatro setas: um só lote de triângulos.
		var pts := PackedVector2Array()
		var cols := PackedColorArray()
		var idx := PackedInt32Array()
		var violet := Color(MenuBackdrop.RUNE_VIOLET, 0.42)
		for i in 96:
			var ang := TAU * i / 96.0
			var dir := Vector2(cos(ang), sin(ang))
			var side := Vector2(-dir.y, dir.x)
			var c := dir * r
			var n0 := pts.size()
			pts.append_array(PackedVector2Array([c + (dir + side) * 1.2, c + (dir - side) * 1.2, c - (dir + side) * 1.2, c - (dir - side) * 1.2]))
			for j in 4:
				cols.append(violet)
			idx.append_array(PackedInt32Array([n0, n0 + 1, n0 + 2, n0, n0 + 2, n0 + 3]))
		var arrow := Color(MenuBackdrop.RUNE_GOLD, 0.55)
		for k in 4:
			var ang := TAU * k / 4.0 - PI / 2.0
			var dir := Vector2(cos(ang), sin(ang))
			var side := Vector2(-dir.y, dir.x)
			var base := dir * r * 0.965
			var n := pts.size()
			pts.append_array(PackedVector2Array([base - dir * 14.0, base + side * 7.0, base - side * 7.0]))
			for j in 3:
				cols.append(arrow)
			idx.append_array(PackedInt32Array([n, n + 1, n + 2]))
		RenderingServer.canvas_item_add_triangle_array(get_canvas_item(), idx, pts, cols)
		draw_arc(Vector2.ZERO, r * 0.93, 0.0, TAU, 128, Color(MenuBackdrop.RUNE_GOLD, 0.36), 1.2, true)
		# Runas entre os anéis, viradas para fora: todos os traços num só comando.
		var segs := PackedVector2Array()
		var gr := r * 0.86
		for i in glyphs.size():
			var ang := TAU * (i + 0.5) / glyphs.size()
			var xf := Transform2D(ang + PI / 2.0, Vector2(cos(ang), sin(ang)) * gr)
			for seg in glyphs[i]:
				var a: Vector2 = seg[0]
				var b: Vector2 = seg[1]
				segs.append(xf * Vector2(a.x * 5.0 - 5.0, a.y * 5.0 - 7.5))
				segs.append(xf * Vector2(b.x * 5.0 - 5.0, b.y * 5.0 - 7.5))
		if not segs.is_empty():
			draw_multiline(segs, Color(MenuBackdrop.RUNE_GOLD, 0.42), 1.4, true)

	func _draw_inner() -> void:
		# Anel tracejado (traço comprido, traço curto): cada traço comprido em dois bocados retos.
		var segs := PackedVector2Array()
		var ri := r * 0.79
		var unit := 32.0 / ri   # ângulo de um padrão "14 8 2 8"
		var steps := int(TAU / unit)
		for i in steps:
			var a0 := i * unit
			var am := a0 + 7.0 / ri
			var a1 := a0 + 14.0 / ri
			segs.append_array(PackedVector2Array([_on(ri, a0), _on(ri, am), _on(ri, am), _on(ri, a1), _on(ri, a0 + 22.0 / ri), _on(ri, a0 + 24.0 / ri)]))
		draw_multiline(segs, Color(0.62, 0.48, 1.0, 0.4), 1.1, true)
		# Estrela de seis pontas (dois triângulos).
		var star := PackedVector2Array()
		var rh := r * 0.7
		for tri in 2:
			for k in 3:
				var a := TAU * k / 3.0 + (PI / 3.0 if tri == 1 else 0.0) - PI / 2.0
				var b := TAU * (k + 1) / 3.0 + (PI / 3.0 if tri == 1 else 0.0) - PI / 2.0
				star.append(_on(rh, a))
				star.append(_on(rh, b))
		draw_multiline(star, Color(MenuBackdrop.RUNE_VIOLET, 0.3), 1.1, true)

	static func _on(radius: float, ang: float) -> Vector2:
		return Vector2(cos(ang), sin(ang)) * radius

## Faíscas nas cinco cores a subir e poeira dourada.
func _draw_sparks(s: Vector2) -> void:
	var tex := glow_texture()
	for sp in _sparks:
		var p := fmod(_t / float(sp.p) + float(sp.ph), 1.0)
		var a := smoothstep(0.0, 0.2, p) * (1.0 - p)
		var pos := Vector2(float(sp.x) * s.x + 6.0 * sin(_t * 1.3 + float(sp.sw)), (float(sp.y) - p * float(sp.d)) * s.y)
		var col: Color = SPARK[int(sp.c)]
		var rad := float(sp.r)
		draw_texture_rect(tex, Rect2(pos - Vector2(rad, rad) * 5.0, Vector2(rad, rad) * 10.0), false, Color(col, 0.5 * a))
		draw_circle(pos, rad, Color(col.lightened(0.25), a))
	for m in _motes:
		var p := fmod(_t / float(m.p) + float(m.ph), 1.0)
		var a := smoothstep(0.0, 0.15, p) * (1.0 - p)
		var pos := Vector2(float(m.x) * s.x + 10.0 * sin(_t * 0.7 + float(m.ph) * 6.0), (float(m.y) - p * float(m.d)) * s.y)
		var rad := float(m.r)
		draw_texture_rect(tex, Rect2(pos - Vector2(rad, rad) * 4.0, Vector2(rad, rad) * 8.0), false, Color(1.0, 0.84, 0.47, 0.45 * a))
		draw_circle(pos, rad, Color(1.0, 0.93, 0.66, 0.9 * a))

func _draw_orbs(s: Vector2) -> void:
	var o := Vector2(s.x * anchor.x, s.y * anchor.y)
	for i in 5:
		var ang := _t * 0.35 + TAU * i / 5.0
		var p := o + Vector2(cos(ang) * s.x * 0.17, sin(ang) * s.y * 0.11)
		var depth := 0.5 + 0.5 * sin(ang)
		var col2: Color = MANA[i]
		var halo := 26.0 + 12.0 * depth
		draw_texture_rect(glow_texture(), Rect2(p - Vector2(halo, halo), Vector2(halo, halo) * 2.0), false, Color(col2, 0.25 + 0.2 * depth))
		draw_circle(p, 7.0 + 4.0 * depth, Color(col2, 0.22 + 0.25 * depth))
		draw_circle(p, 2.5 + 1.5 * depth, Color(1, 1, 1, 0.35 + 0.4 * depth))

func _ghost_card(c: Vector2, rot: float, sc: float) -> void:
	var w := 120.0 * sc
	var h := 170.0 * sc
	draw_set_transform(c, rot, Vector2.ONE)
	var r := Rect2(-w / 2.0, -h / 2.0, w, h)
	draw_rect(r, Color(0.7, 0.6, 1.0, 0.035))
	draw_rect(r, Color(0.85, 0.75, 1.0, 0.09), false, 2.0)
	draw_arc(Vector2.ZERO, w * 0.28, 0.0, TAU, 32, Color(0.85, 0.75, 1.0, 0.08), 2.0)
	for k in 5:
		var a := TAU * k / 5.0 - PI / 2.0
		draw_line(Vector2.ZERO, Vector2(cos(a), sin(a)) * w * 0.28, Color(0.85, 0.75, 1.0, 0.06), 1.5)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
