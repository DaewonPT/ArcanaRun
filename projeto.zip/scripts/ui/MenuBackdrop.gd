class_name MenuBackdrop
extends Control
## 0.12.0: fundo animado do ecrã inicial, desenhado em código. Uma aurora lenta (manchas nas cinco cores
## de mana a deslizar), poeira de estrelas a subir e a cintilar, cinco orbes de mana a orbitar devagar
## atrás do título e duas cartas fantasma a rodar ao longe. Redesenha a ~30 fps; com o movimento
## reduzido fica parado (desenhado uma vez); no modo de desempenho tem menos estrelas e 20 fps.

const MANA := [Color(0.93, 0.89, 0.74), Color(0.38, 0.56, 0.88), Color(0.55, 0.42, 0.72), Color(0.86, 0.36, 0.30), Color(0.40, 0.66, 0.40)]

var anchor := Vector2(0.27, 0.36)   # centro das órbitas (fração do ecrã), atrás do título
var _t := 0.0
var _acc := 0.0
var _stars: Array = []
var _rng := RandomNumberGenerator.new()
static var _glow_tex: GradientTexture2D

## Mancha redonda e suave (branco no centro a transparente na borda), pintada com a cor que se quiser.
static func glow_texture() -> GradientTexture2D:
	if _glow_tex == null:
		var g := Gradient.new()
		g.set_color(0, Color(1, 1, 1, 1))
		g.set_color(1, Color(1, 1, 1, 0))
		g.add_point(0.45, Color(1, 1, 1, 0.45))
		var t := GradientTexture2D.new()
		t.gradient = g
		t.fill = GradientTexture2D.FILL_RADIAL
		t.fill_from = Vector2(0.5, 0.5)
		t.fill_to = Vector2(1.0, 0.5)
		t.width = 128
		t.height = 128
		_glow_tex = t
	return _glow_tex

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)

func _ready() -> void:
	_rng.seed = 2026
	var n := 40 if Settings.performance_mode else 90
	for i in n:
		_stars.append({"x": _rng.randf(), "y": _rng.randf(), "r": _rng.randf_range(0.6, 1.8), "s": _rng.randf_range(0.006, 0.02),
			"ph": _rng.randf() * TAU, "tw": _rng.randf_range(0.6, 2.2)})
	_t = _rng.randf() * 10.0
	set_process(Settings.motion_ok())
	queue_redraw()

func _process(delta: float) -> void:
	_t += delta
	_acc += delta
	var step := 1.0 / (20.0 if Settings.performance_mode else 30.0)
	if _acc >= step:
		_acc = 0.0
		queue_redraw()

func _draw() -> void:
	var s := size
	if s.x < 10.0:
		return
	# Aurora: manchas grandes e suaves (círculos concêntricos de alfa baixo).
	for i in 3:
		var col: Color = MANA[(i * 2 + 1) % MANA.size()]
		var c := Vector2(s.x * (0.25 + 0.5 * (0.5 + 0.5 * sin(_t * 0.05 + i * 2.1))), s.y * (0.3 + 0.4 * (0.5 + 0.5 * sin(_t * 0.037 + i * 1.3))))
		var r := s.y * (0.6 + 0.1 * sin(_t * 0.08 + i))
		draw_texture_rect(glow_texture(), Rect2(c - Vector2(r, r), Vector2(r, r) * 2.0), false, Color(col, 0.09))
	# Estrelas: sobem devagar e cintilam.
	for st in _stars:
		var y := fmod(float(st.y) - _t * float(st.s) + 10.0, 1.0)
		var a := 0.25 + 0.35 * (0.5 + 0.5 * sin(_t * float(st.tw) + float(st.ph)))
		draw_circle(Vector2(float(st.x) * s.x, y * s.y), float(st.r), Color(1, 0.96, 0.88, a))
	# Cartas fantasma a rodar ao longe.
	for i in 2:
		var cx := s.x * (0.12 + 0.3 * i) + 30.0 * sin(_t * 0.2 + i)
		var cy := s.y * (0.72 - 0.08 * i) + 18.0 * cos(_t * 0.17 + i * 2.0)
		_ghost_card(Vector2(cx, cy), 0.22 * sin(_t * 0.12 + i * 1.7), 0.75 + 0.15 * i)
	# Orbes de mana a orbitar atrás do título.
	var o := Vector2(s.x * anchor.x, s.y * anchor.y)
	for i in 5:
		var ang := _t * 0.35 + TAU * i / 5.0
		var p := o + Vector2(cos(ang) * s.x * 0.17, sin(ang) * s.y * 0.11)
		var depth := 0.5 + 0.5 * sin(ang)
		var col2: Color = MANA[i]
		var halo := 26.0 + 12.0 * depth
		draw_texture_rect(glow_texture(), Rect2(p - Vector2(halo, halo), Vector2(halo, halo) * 2.0), false, Color(col2, 0.25 + 0.2 * depth))
		draw_circle(p, 7.0 + 4.0 * depth, Color(col2, 0.22 + 0.25 * depth))
		draw_circle(p, 2.5 + 1.5 * depth, Color(1, 1, 1, 0.35 + 0.4 * depth))

func _ghost_card(c: Vector2, rot: float, sc: float) -> void:
	var w := 120.0 * sc
	var h := 170.0 * sc
	draw_set_transform(c, rot, Vector2.ONE)
	var r := Rect2(-w / 2.0, -h / 2.0, w, h)
	draw_rect(r, Color(0.7, 0.6, 1.0, 0.035))
	draw_rect(r, Color(0.85, 0.75, 1.0, 0.09), false, 2.0)
	draw_arc(Vector2.ZERO, w * 0.28, 0.0, TAU, 32, Color(0.85, 0.75, 1.0, 0.08), 2.0)
	for k in 5:
		var a := TAU * k / 5.0 - PI / 2.0
		draw_line(Vector2.ZERO, Vector2(cos(a), sin(a)) * w * 0.28, Color(0.85, 0.75, 1.0, 0.06), 1.5)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
