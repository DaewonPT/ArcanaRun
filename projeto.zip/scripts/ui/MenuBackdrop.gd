class_name MenuBackdrop
extends Control
## Fundo animado do ecrã inicial, desenhado em código. Redesenha a ~30 fps; com o movimento reduzido fica
## parado (desenhado uma vez); no modo de desempenho tem menos partículas e 20 fps.
## 0.13.1 (visual "Grimório dourado" com o fundo "Arcano vivo"): a ilustração das ilhas a flutuar
## (background act_E), escurecida à esquerda para o título se ler; atrás do título um círculo de runas em
## duas camadas que rodam devagar em sentidos contrários; faíscas nas cinco cores de mana a subir, poeira
## dourada e estrelas a cintilar. Sem a ilustração, fica o fundo da 0.12.0 (aurora, orbes e cartas fantasma).

const MANA := [Color(0.93, 0.89, 0.74), Color(0.38, 0.56, 0.88), Color(0.55, 0.42, 0.72), Color(0.86, 0.36, 0.30), Color(0.40, 0.66, 0.40)]
## Cores das faíscas (mais vivas do que as das orbes, porque são pequenas).
const SPARK := [Color(1.0, 0.95, 0.77), Color(0.37, 0.71, 1.0), Color(0.78, 0.61, 1.0), Color(1.0, 0.42, 0.37), Color(0.44, 0.88, 0.54)]
const RUNE_VIOLET := Color(0.78, 0.65, 1.0)
const RUNE_GOLD := Color(0.97, 0.84, 0.5)
const ART_ID := "act_E"

var anchor := Vector2(0.27, 0.36)   # centro das órbitas/runas (fração do ecrã) se não houver título
var title_node: Control = null      # o título do menu: o círculo de runas fica centrado nele
var art: Texture2D = null
var _t := 0.0
var _acc := 0.0
var _stars: Array = []
var _sparks: Array = []
var _motes: Array = []
var _glyphs: Array = []             # runas: cada uma é uma lista de segmentos [a, b] numa grelha 3×4
var _rng := RandomNumberGenerator.new()
static var _glow_tex: GradientTexture2D

## Mancha redonda e suave (branco no centro a transparente na borda), pintada com a cor que se quiser.
static func glow_texture() -> GradientTexture2D:
	if _glow_tex == null:
		var g := Gradient.new()
		g.set_color(0, Color(1, 1, 1, 1))
		g.set_color(1, Color(1, 1, 1, 0))
		g.add_point(0.45, Color(1, 1, 1, 0.45))
		var t := GradientTexture2D.new()
		t.gradient = g
		t.fill = GradientTexture2D.FILL_RADIAL
		t.fill_from = Vector2(0.5, 0.5)
		t.fill_to = Vector2(1.0, 0.5)
		t.width = 128
		t.height = 128
		_glow_tex = t
	return _glow_tex

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)

func _ready() -> void:
	_rng.seed = 2026
	if ArtLib.has("background", ART_ID):
		art = ArtLib.texture("background", ART_ID)
	var few := Settings.performance_mode
	var n := (40 if few else 90) if art == null else (16 if few else 34)
	for i in n:
		_stars.append({"x": _rng.randf(), "y": _rng.randf(), "r": _rng.randf_range(0.6, 1.8), "s": _rng.randf_range(0.006, 0.02),
			"ph": _rng.randf() * TAU, "tw": _rng.randf_range(0.6, 2.2)})
	for i in (8 if few else 16):
		# Faíscas: nascem em baixo (sobretudo do lado do título), sobem uns 25–40 % do ecrã e apagam-se.
		var left_side := i % 4 != 3
		_sparks.append({"x": _rng.randf_range(0.03, 0.55) if left_side else _rng.randf_range(0.58, 0.98), "y": _rng.randf_range(0.82, 1.04),
			"d": _rng.randf_range(0.25, 0.4), "p": _rng.randf_range(5.0, 8.5), "ph": _rng.randf(), "c": i % SPARK.size(),
			"r": _rng.randf_range(2.0, 3.0), "sw": _rng.randf() * TAU})
	for i in (4 if few else 9):
		_motes.append({"x": _rng.randf_range(0.05, 0.95), "y": _rng.randf_range(0.55, 1.0), "d": _rng.randf_range(0.18, 0.3),
			"p": _rng.randf_range(7.0, 10.0), "ph": _rng.randf(), "r": _rng.randf_range(1.4, 2.2)})
	for i in 16:
		var segs: Array = []
		for k in _rng.randi_range(2, 3):
			var a := Vector2(_rng.randi_range(0, 2), _rng.randi_range(0, 3))
			var b := Vector2(_rng.randi_range(0, 2), _rng.randi_range(0, 3))
			if a == b:
				b = Vector2(2 - a.x, 3 - a.y)
			segs.append([a, b])
		_glyphs.append(segs)
	_t = _rng.randf() * 10.0
	set_process(Settings.motion_ok())
	queue_redraw()

func _process(delta: float) -> void:
	_t += delta
	_acc += delta
	var step := 1.0 / (20.0 if Settings.performance_mode else 30.0)
	if _acc >= step:
		_acc = 0.0
		queue_redraw()

## Centro do círculo de runas: o meio do título (ou a âncora, sem título).
func rune_center() -> Vector2:
	if title_node != null and is_instance_valid(title_node) and title_node.is_inside_tree() and title_node.size.x > 0.0:
		var r := title_node.get_global_rect()
		return r.get_center() - get_global_rect().position
	return Vector2(size.x * anchor.x, size.y * anchor.y)

func _draw() -> void:
	var s := size
	if s.x < 10.0:
		return
	if art != null:
		_draw_art(s)
	else:
		_draw_aurora(s)
	# Estrelas: sobem devagar e cintilam.
	for st in _stars:
		var y := fmod(float(st.y) - _t * float(st.s) + 10.0, 1.0)
		var a := 0.25 + 0.35 * (0.5 + 0.5 * sin(_t * float(st.tw) + float(st.ph)))
		draw_circle(Vector2(float(st.x) * s.x, y * s.y), float(st.r), Color(1, 0.96, 0.88, a * (0.8 if art != null else 1.0)))
	if art != null:
		_draw_runes(rune_center(), s.y * 0.36)
		_draw_sparks(s)
	else:
		for i in 2:
			var cx := s.x * (0.12 + 0.3 * i) + 30.0 * sin(_t * 0.2 + i)
			var cy := s.y * (0.72 - 0.08 * i) + 18.0 * cos(_t * 0.17 + i * 2.0)
			_ghost_card(Vector2(cx, cy), 0.22 * sin(_t * 0.12 + i * 1.7), 0.75 + 0.15 * i)
		_draw_orbs(s)

## A ilustração a cobrir o ecrã, escurecida: mais à esquerda (título e texto) e nos cantos.
func _draw_art(s: Vector2) -> void:
	draw_texture_rect_region(art, Rect2(Vector2.ZERO, s), ArtLib.cover_region(art, s, 0.5))
	var dark := Color(0.055, 0.035, 0.11)
	var l := Color(dark, 0.86)
	var m := Color(dark, 0.52)
	var r := Color(dark, 0.78)
	draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(s.x * 0.5, 0), Vector2(s.x * 0.5, s.y), Vector2(0, s.y)]), PackedColorArray([l, m, m, l]))
	draw_polygon(PackedVector2Array([Vector2(s.x * 0.5, 0), Vector2(s.x, 0), Vector2(s.x, s.y), Vector2(s.x * 0.5, s.y)]), PackedColorArray([m, r, r, m]))
	# Vinheta: cantos mais escuros (quatro manchas grandes e suaves fora do ecrã).
	for corner in [Vector2(0, 0), Vector2(s.x, 0), Vector2(0, s.y), Vector2(s.x, s.y)]:
		var rad := s.y * 0.75
		draw_texture_rect(glow_texture(), Rect2(corner - Vector2(rad, rad), Vector2(rad, rad) * 2.0), false, Color(0.02, 0.01, 0.05, 0.55))

func _draw_aurora(s: Vector2) -> void:
	for i in 3:
		var col: Color = MANA[(i * 2 + 1) % MANA.size()]
		var c := Vector2(s.x * (0.25 + 0.5 * (0.5 + 0.5 * sin(_t * 0.05 + i * 2.1))), s.y * (0.3 + 0.4 * (0.5 + 0.5 * sin(_t * 0.037 + i * 1.3))))
		var r := s.y * (0.6 + 0.1 * sin(_t * 0.08 + i))
		draw_texture_rect(glow_texture(), Rect2(c - Vector2(r, r), Vector2(r, r) * 2.0), false, Color(col, 0.09))

## Círculo de runas atrás do título: anel de pontos, anel dourado com quatro setas e dezasseis runas a
## rodar num sentido; anel tracejado e estrela de seis pontas a rodar no outro.
func _draw_runes(c: Vector2, r: float) -> void:
	var a1 := _t * TAU / 60.0
	var a2 := -_t * TAU / 90.0
	draw_texture_rect(glow_texture(), Rect2(c - Vector2(r, r) * 1.1, Vector2(r, r) * 2.2), false, Color(0.55, 0.35, 1.0, 0.18))
	var violet := Color(RUNE_VIOLET, 0.42)
	var gold := Color(RUNE_GOLD, 0.36)
	for i in 96:
		var ang := a1 + TAU * i / 96.0
		draw_circle(c + Vector2(cos(ang), sin(ang)) * r, 1.3, violet)
	draw_arc(c, r * 0.93, 0.0, TAU, 128, gold, 1.2, true)
	for k in 4:
		var ang := a1 + TAU * k / 4.0 - PI / 2.0
		var dir := Vector2(cos(ang), sin(ang))
		var side := Vector2(-dir.y, dir.x)
		var base := c + dir * r * 0.965
		draw_colored_polygon(PackedVector2Array([base - dir * 14.0, base + side * 7.0, base - side * 7.0]), Color(RUNE_GOLD, 0.55))
	# Runas entre os anéis, viradas para fora.
	var gr := r * 0.86
	for i in _glyphs.size():
		var ang := a1 + TAU * (i + 0.5) / _glyphs.size()
		var p := c + Vector2(cos(ang), sin(ang)) * gr
		draw_set_transform(p, ang + PI / 2.0, Vector2.ONE)
		for seg in _glyphs[i]:
			var a: Vector2 = seg[0]
			var b: Vector2 = seg[1]
			draw_line(Vector2(a.x * 5.0 - 5.0, a.y * 5.0 - 7.5), Vector2(b.x * 5.0 - 5.0, b.y * 5.0 - 7.5), Color(RUNE_GOLD, 0.42), 1.4, true)
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	# Anel tracejado (traço comprido, traço curto) a rodar ao contrário.
	var ri := r * 0.79
	var unit := 32.0 / ri   # ângulo de um padrão "14 8 2 8"
	var steps := int(TAU / unit)
	for i in steps:
		var a0 := a2 + i * unit
		draw_arc(c, ri, a0, a0 + 14.0 / ri, 4, Color(0.62, 0.48, 1.0, 0.4), 1.1, true)
		draw_arc(c, ri, a0 + 22.0 / ri, a0 + 24.0 / ri, 2, Color(0.62, 0.48, 1.0, 0.4), 1.1, true)
	# Estrela de seis pontas (dois triângulos).
	var rh := r * 0.7
	for tri in 2:
		var pts := PackedVector2Array()
		for k in 4:
			var ang := a2 + TAU * k / 3.0 + (PI / 3.0 if tri == 1 else 0.0) - PI / 2.0
			pts.append(c + Vector2(cos(ang), sin(ang)) * rh)
		draw_polyline(pts, Color(RUNE_VIOLET, 0.3), 1.1, true)

## Faíscas nas cinco cores a subir e poeira dourada.
func _draw_sparks(s: Vector2) -> void:
	var tex := glow_texture()
	for sp in _sparks:
		var p := fmod(_t / float(sp.p) + float(sp.ph), 1.0)
		var a := smoothstep(0.0, 0.2, p) * (1.0 - p)
		var pos := Vector2(float(sp.x) * s.x + 6.0 * sin(_t * 1.3 + float(sp.sw)), (float(sp.y) - p * float(sp.d)) * s.y)
		var col: Color = SPARK[int(sp.c)]
		var rad := float(sp.r)
		draw_texture_rect(tex, Rect2(pos - Vector2(rad, rad) * 5.0, Vector2(rad, rad) * 10.0), false, Color(col, 0.5 * a))
		draw_circle(pos, rad, Color(col.lightened(0.25), a))
	for m in _motes:
		var p := fmod(_t / float(m.p) + float(m.ph), 1.0)
		var a := smoothstep(0.0, 0.15, p) * (1.0 - p)
		var pos := Vector2(float(m.x) * s.x + 10.0 * sin(_t * 0.7 + float(m.ph) * 6.0), (float(m.y) - p * float(m.d)) * s.y)
		var rad := float(m.r)
		draw_texture_rect(tex, Rect2(pos - Vector2(rad, rad) * 4.0, Vector2(rad, rad) * 8.0), false, Color(1.0, 0.84, 0.47, 0.45 * a))
		draw_circle(pos, rad, Color(1.0, 0.93, 0.66, 0.9 * a))

func _draw_orbs(s: Vector2) -> void:
	var o := Vector2(s.x * anchor.x, s.y * anchor.y)
	for i in 5:
		var ang := _t * 0.35 + TAU * i / 5.0
		var p := o + Vector2(cos(ang) * s.x * 0.17, sin(ang) * s.y * 0.11)
		var depth := 0.5 + 0.5 * sin(ang)
		var col2: Color = MANA[i]
		var halo := 26.0 + 12.0 * depth
		draw_texture_rect(glow_texture(), Rect2(p - Vector2(halo, halo), Vector2(halo, halo) * 2.0), false, Color(col2, 0.25 + 0.2 * depth))
		draw_circle(p, 7.0 + 4.0 * depth, Color(col2, 0.22 + 0.25 * depth))
		draw_circle(p, 2.5 + 1.5 * depth, Color(1, 1, 1, 0.35 + 0.4 * depth))

func _ghost_card(c: Vector2, rot: float, sc: float) -> void:
	var w := 120.0 * sc
	var h := 170.0 * sc
	draw_set_transform(c, rot, Vector2.ONE)
	var r := Rect2(-w / 2.0, -h / 2.0, w, h)
	draw_rect(r, Color(0.7, 0.6, 1.0, 0.035))
	draw_rect(r, Color(0.85, 0.75, 1.0, 0.09), false, 2.0)
	draw_arc(Vector2.ZERO, w * 0.28, 0.0, TAU, 32, Color(0.85, 0.75, 1.0, 0.08), 2.0)
	for k in 5:
		var a := TAU * k / 5.0 - PI / 2.0
		draw_line(Vector2.ZERO, Vector2(cos(a), sin(a)) * w * 0.28, Color(0.85, 0.75, 1.0, 0.06), 1.5)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
