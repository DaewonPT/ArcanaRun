class_name ArenaMat
extends StyleBox
## Tapete da Arena (cosmético, 0.12.0): o fundo por trás das criaturas na batalha, desenhado em código
## (sem imagens) como o "panel" do BoardScroll. Cada tapete tem duas cores e um padrão:
## stars (pontinhos de estrelas), marble (veios), tiles (lajes), stripes (riscas de circo), strata
## (camadas de pedra), grass (erva), embers (brasas), frost (cristais de gelo). Tudo com alfa baixo,
## para as cartas continuarem a ler-se bem. "classic" = sem tapete (StyleBoxEmpty).

var pattern := ""
var c0 := Color(0, 0, 0, 0)
var c1 := Color(1, 1, 1)
var seed_value := 1

## Estilo para o tapete escolhido (null = sem tapete).
static func make(id: String) -> StyleBox:
	var d := CardDB.get_cosmetic("mat", id)
	if id == "classic" or d.is_empty() or String(d.get("pattern", "")) == "":
		return StyleBoxEmpty.new()
	var m := ArenaMat.new()
	m.pattern = String(d.get("pattern", ""))
	var cols: Array = d.get("colors", ["#101018", "#ffffff"])
	m.c0 = Color(String(cols[0]))
	m.c1 = Color(String(cols[1]))
	m.seed_value = hash(id)
	return m

func _draw(ci: RID, rect: Rect2) -> void:
	var rs := RenderingServer
	var r := rect.grow(-2)
	rs.canvas_item_add_rect(ci, r, Color(c0, 0.62))
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value
	var ink := Color(c1, 0.16)
	match pattern:
		"stars":
			for i in 70:
				var p := r.position + Vector2(rng.randf() * r.size.x, rng.randf() * r.size.y)
				rs.canvas_item_add_circle(ci, p, rng.randf_range(0.8, 2.2), Color(c1, rng.randf_range(0.15, 0.5)))
			for i in 4:
				var p2 := r.position + Vector2(rng.randf() * r.size.x, rng.randf() * r.size.y)
				rs.canvas_item_add_circle(ci, p2, rng.randf_range(16, 34), Color(c1, 0.035))
		"marble":
			for v in 6:
				var pts := PackedVector2Array()
				var y := r.position.y + rng.randf() * r.size.y
				var amp := rng.randf_range(6, 18)
				var ph := rng.randf() * TAU
				for k in 25:
					var x := r.position.x + r.size.x * k / 24.0
					pts.append(Vector2(x, clampf(y + sin(k * 0.55 + ph) * amp + rng.randf_range(-3, 3), r.position.y, r.end.y)))
				rs.canvas_item_add_polyline(ci, pts, PackedColorArray([Color(c1, 0.16)]), rng.randf_range(1.0, 2.6), true)
		"tiles":
			var step := 46.0
			var x0 := r.position.x
			while x0 < r.end.x:
				rs.canvas_item_add_line(ci, Vector2(x0, r.position.y), Vector2(x0, r.end.y), ink, 1.0)
				x0 += step
			var y0 := r.position.y
			var row := 0
			while y0 < r.end.y:
				rs.canvas_item_add_line(ci, Vector2(r.position.x, y0), Vector2(r.end.x, y0), ink, 1.0)
				y0 += step * 0.75
				row += 1
		"stripes":
			var w := 34.0
			var x1 := r.position.x - r.size.y
			var n := 0
			while x1 < r.end.x:
				if n % 2 == 0:
					var poly := PackedVector2Array([Vector2(x1, r.end.y), Vector2(x1 + w, r.end.y), Vector2(x1 + w + r.size.y, r.position.y), Vector2(x1 + r.size.y, r.position.y)])
					var clipped := _clip(poly, r)
					if clipped.size() >= 3:
						rs.canvas_item_add_polygon(ci, clipped, PackedColorArray([Color(c1, 0.1)]))
				x1 += w
				n += 1
		"strata":
			var bands := 6
			for b in bands:
				var pts2 := PackedVector2Array()
				var by := r.position.y + r.size.y * (b + 0.5) / bands
				for k in 21:
					var x2 := r.position.x + r.size.x * k / 20.0
					pts2.append(Vector2(x2, by + sin(k * 0.8 + b) * 4.0 + rng.randf_range(-2, 2)))
				rs.canvas_item_add_polyline(ci, pts2, PackedColorArray([Color(c1, 0.12 + 0.03 * (b % 2))]), 3.0, true)
		"grass":
			for i in 90:
				var bx := r.position.x + rng.randf() * r.size.x
				var by2 := r.position.y + rng.randf() * r.size.y
				var h := rng.randf_range(5, 12)
				rs.canvas_item_add_line(ci, Vector2(bx, by2), Vector2(bx + rng.randf_range(-3, 3), by2 - h), Color(c1, rng.randf_range(0.1, 0.24)), 1.4, true)
		"embers":
			for i in 60:
				var ex := r.position.x + rng.randf() * r.size.x
				var ey := r.position.y + r.size.y * pow(rng.randf(), 0.5)
				rs.canvas_item_add_circle(ci, Vector2(ex, ey), rng.randf_range(1.0, 2.6), Color(c1, rng.randf_range(0.2, 0.55)))
			rs.canvas_item_add_rect(ci, Rect2(r.position.x, r.end.y - r.size.y * 0.25, r.size.x, r.size.y * 0.25), Color(c1, 0.06))
		"frost":
			for i in 7:
				var c := r.position + Vector2(rng.randf() * r.size.x, rng.randf() * r.size.y)
				var rad := rng.randf_range(14, 30)
				for a in 6:
					var ang := TAU * a / 6.0 + rng.randf() * 0.3
					var tip := c + Vector2(cos(ang), sin(ang)) * rad
					rs.canvas_item_add_line(ci, c, tip, Color(c1, 0.2), 1.2, true)
					var mid := c.lerp(tip, 0.6)
					rs.canvas_item_add_line(ci, mid, mid + Vector2(cos(ang + 0.6), sin(ang + 0.6)) * rad * 0.3, Color(c1, 0.16), 1.0, true)
	# Moldura fina do tapete.
	var edge := Color(c1, 0.3)
	rs.canvas_item_add_rect(ci, Rect2(r.position, Vector2(r.size.x, 2)), edge)
	rs.canvas_item_add_rect(ci, Rect2(Vector2(r.position.x, r.end.y - 2), Vector2(r.size.x, 2)), edge)
	rs.canvas_item_add_rect(ci, Rect2(r.position, Vector2(2, r.size.y)), edge)
	rs.canvas_item_add_rect(ci, Rect2(Vector2(r.end.x - 2, r.position.y), Vector2(2, r.size.y)), edge)

## Corta um polígono ao retângulo (as riscas não saem do tapete).
static func _clip(poly: PackedVector2Array, r: Rect2) -> PackedVector2Array:
	var box := PackedVector2Array([r.position, Vector2(r.end.x, r.position.y), r.end, Vector2(r.position.x, r.end.y)])
	var res := Geometry2D.intersect_polygons(poly, box)
	return res[0] if not res.is_empty() else PackedVector2Array()
