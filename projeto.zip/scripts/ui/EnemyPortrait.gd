class_name EnemyPortrait
extends Control
## Retrato redondo de um inimigo, desenhado em código (sem imagens): disco escuro com um brilho da cor
## do inimigo (tint), a silhueta do arquétipo com um contorno de luz, olhos a brilhar e um anel da
## mesma cor por cima (com um anel dourado por fora nos bosses).
## Arquétipos: blob, rogue, robed, goblin, golem, hydra, brute, dragon, sphinx, lich, judge, void,
## queen, knight, demon, dummy (boneco de treino); um desconhecido usa brute.
## Respira devagar (o corpo estica 3 % e os olhos pulsam, ~3 s) e hit() dá um recuo com clarão; as
## duas coisas só com movimento ligado (Settings.motion_ok()). Legível a 72×72; acima de ~100 px
## ganha os detalhes finos. A geometria fica em cache: por frame só se repete o desenho.

const ARCHETYPES := ["blob", "rogue", "robed", "goblin", "golem", "hydra", "brute", "dragon", "sphinx", "lich", "judge", "void", "queen", "knight", "demon", "dummy"]
const BREATH_PERIOD := 3.0
const HIT_TIME := 0.25
const DISC_R := 45.4      # raio do disco de fundo (grelha 100×100, centro em 50,50)
const CLIP_R := 47.0      # a figura é cortada aqui (o bordo fica escondido debaixo do anel)
const BACKDROP := Color(0.055, 0.045, 0.08)
const GOLD := Color(0.98, 0.75, 0.25)

var archetype: String = "brute":
	set(v):
		archetype = v
		_dirty = true
		queue_redraw()
var tint: Color = Color(0.55, 0.42, 0.85):
	set(v):
		tint = v
		_dirty = true
		queue_redraw()
var breathing: bool = true:
	set(v):
		breathing = v
		_update_process()
		queue_redraw()
var boss: bool = false:
	set(v):
		boss = v
		queue_redraw()
## 0.12.0: id do inimigo (ou planeswalker) para a ilustração opcional (assets/art/portraits/<id>.webp).
## Com imagem, o disco mostra-a em vez da silhueta (os anéis, a respiração e o clarão ficam).
var art_id: String = "":
	set(v):
		art_id = v
		_art_tex = ArtLib.texture("portrait", v) if v != "" else null
		queue_redraw()
var _art_tex: Texture2D

# Construção (grelha 100×100)
var _dirty := true
var _built_size := Vector2.ZERO
var _fine := true          # detalhes finos (só em tamanhos maiores)
var _layers: Array = []    # camadas do corpo: [[PackedVector2Array, ...], ...]
var _back: Array = []      # detalhes por trás do corpo
var _details: Array = []   # detalhes por cima do corpo
var _eyes: Array = []
# Paleta
var _t := Color.WHITE      # tint com um mínimo de luminosidade (as cores muito escuras não se leem)
var _c_top := Color.WHITE
var _c_bot := Color.BLACK
var _rim := Color.WHITE
var _eye_col := Color.WHITE
# Cache em coordenadas de ecrã
var _u := 1.0
var _o := Vector2.ZERO
var _s_layers: Array = []  # [[{"pts", "line", "cols"}, ...], ...]
var _s_back: Array = []
var _s_details: Array = []
var _s_eyes: Array = []
var _disc_pts := PackedVector2Array()
# Animação
var _time := 0.0
var _hit_t := 0.0
var _was_animating := false

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _ready() -> void:
	# fase própria (sem mexer no gerador global): retratos lado a lado não respiram em sincronia
	_time = fmod(float(get_instance_id() % 9973) * 0.618, BREATH_PERIOD)
	_update_process()

## Recuo com clarão (0.25 s). Não faz nada com o movimento reduzido.
func hit() -> void:
	if not Settings.motion_ok():
		return
	_hit_t = HIT_TIME
	_update_process()
	queue_redraw()

func _update_process() -> void:
	set_process((breathing and not Settings.performance_mode) or _hit_t > 0.0)

func _process(delta: float) -> void:
	var motion := Settings.motion_ok()
	if _hit_t > 0.0:
		_hit_t = maxf(0.0, _hit_t - delta) if motion else 0.0
		queue_redraw()
	var animating := breathing and motion and not Settings.performance_mode
	if animating:
		_time = fmod(_time + delta, BREATH_PERIOD * 1000.0)
		if is_visible_in_tree():
			queue_redraw()
	elif _was_animating:
		queue_redraw()   # volta à pose parada
	_was_animating = animating
	if not breathing and _hit_t <= 0.0:
		set_process(false)

# --- Desenho ---

func _draw() -> void:
	if size.x < 8.0 or size.y < 8.0:
		return
	if _dirty or size != _built_size:
		_rebuild()
	var u := _u
	var c := _o + Vector2(50, 50) * u
	var animating := breathing and Settings.motion_ok()
	var breath := (0.5 - 0.5 * cos(TAU * _time / BREATH_PERIOD)) if animating else 0.0
	var hit_k := clampf(_hit_t / HIT_TIME, 0.0, 1.0)
	var flash := hit_k * hit_k * 0.75
	var glow_k := (0.7 + 0.3 * breath) if animating else 0.88

	if _art_tex != null:
		_draw_art(c, breath, flash)
		_draw_rings(c)
		return
	# Fundo: disco escuro e um brilho da cor do inimigo atrás da cabeça.
	draw_colored_polygon(_disc_pts, BACKDROP)
	var aura_c := _o + Vector2(50, 40) * u
	var aura := Color(_t.lightened(0.1), 0.42 + 0.06 * breath + 0.3 * hit_k)
	_fan(aura_c, _disc_pts, aura, Color(_t, 0.0))

	# Figura: respira a partir da base do disco; no golpe encolhe, treme e fica branca.
	var pivot := _o + Vector2(50, 96) * u
	var sc := Vector2(1.0 + 0.005 * breath - 0.03 * hit_k, 1.0 + 0.03 * breath - 0.05 * hit_k)
	var off := Vector2(sin(hit_k * PI * 3.0) * 2.6, -1.2) * u * hit_k
	draw_set_transform(pivot - pivot * sc + off, 0.0, sc)
	for d in _s_back:
		_draw_detail(d, flash)
	var rim := _rim.lerp(Color.WHITE, flash)
	for layer in _s_layers:
		for part in layer:
			draw_polyline(part.line, rim, 2.6 * u, true)
		for part in layer:
			var cols: PackedColorArray = part.cols if flash <= 0.0 else _flashed(part.cols, flash)
			draw_polygon(part.pts, cols)
			draw_polyline_colors(part.line, _close_cols(cols), 0.9 * u, true)
	for d in _s_details:
		_draw_detail(d, flash)
	for e in _s_eyes:
		_draw_eye(e, glow_k, flash)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

	_draw_rings(c)

## Vinheta por dentro do anel e os anéis (com o dourado dos bosses).
func _draw_rings(c: Vector2) -> void:
	var u := _u
	_ring_fade(c, DISC_R * u, (DISC_R - 9.0) * u, Color(0, 0, 0, 0.55))
	if boss:
		draw_arc(c, 45.9 * u, 0.0, TAU, 72, _t.lightened(0.05), 2.4 * u, true)
		draw_arc(c, 48.4 * u, 0.0, TAU, 72, GOLD, 2.8 * u, true)
		draw_arc(c, 48.4 * u, -PI * 0.8, -PI * 0.3, 24, GOLD.lightened(0.5), 1.0 * u, true)
		for i in 8:
			var a := TAU * i / 8.0 - PI / 2.0
			var p := c + Vector2(cos(a), sin(a)) * 48.4 * u
			_fill_now(_diamond(p, 1.7 * u, a), GOLD.lightened(0.25))
	else:
		draw_arc(c, 47.3 * u, 0.0, TAU, 72, _t.lightened(0.05), 3.6 * u, true)
		draw_arc(c, 47.6 * u, -PI * 0.8, -PI * 0.3, 24, Color(_t.lightened(0.5), 0.8), 1.1 * u, true)

## A ilustração dentro do disco (polígono com UVs): respira com um zoom de 3 % e fica branca no golpe.
func _draw_art(c: Vector2, breath: float, flash: float) -> void:
	draw_colored_polygon(_disc_pts, BACKDROP)
	var ts := _art_tex.get_size()
	var side := minf(ts.x, ts.y)
	var zoom := 1.0 - 0.03 * breath
	var half := side * 0.5 * zoom
	var src_c := Vector2(ts.x * 0.5, ts.y * 0.45)
	var r := DISC_R * _u
	var uvs := PackedVector2Array()
	for p in _disc_pts:
		var rel := (p - c) / r          # -1..1 dentro do disco
		uvs.append((src_c + rel * half) / ts)
	var col := Color(1, 1, 1, 1).lerp(Color(1.6, 1.6, 1.6, 1), flash)
	var cols := PackedColorArray()
	cols.resize(_disc_pts.size())
	cols.fill(col)
	draw_polygon(_disc_pts, cols, uvs, _art_tex)
	if flash > 0.0:
		draw_colored_polygon(_disc_pts, Color(1, 1, 1, flash * 0.5))

func _flashed(cols: PackedColorArray, flash: float) -> PackedColorArray:
	var out := cols.duplicate()
	for i in out.size():
		out[i] = out[i].lerp(Color.WHITE, flash)
	return out

## Cores de um polígono para o contorno fechado (repete a primeira no fim, como a linha).
func _close_cols(cols: PackedColorArray) -> PackedColorArray:
	var out := cols.duplicate()
	if out.size() > 0:
		out.append(out[0])
	return out

func _draw_detail(d: Dictionary, flash: float) -> void:
	var col: Color = d.col
	if flash > 0.0:
		col = col.lerp(Color(1, 1, 1, col.a), flash)
	if d.has("line"):
		draw_polyline(d.line, col, d.w, true)
		return
	draw_colored_polygon(d.pts, col)
	var n: int = d.pts.size()
	var cols := PackedColorArray()
	cols.resize(n * 2)
	var clear := Color(col, 0.0)
	for i in n:
		cols[i] = col
		cols[n + i] = clear
	RenderingServer.canvas_item_add_triangle_array(get_canvas_item(), d.idx, d.ring, cols)

func _draw_eye(e: Dictionary, glow_k: float, flash: float) -> void:
	var core: Color = _eye_col.lerp(Color.WHITE, flash)
	var u := _u
	var halo := Color(_eye_col, 0.5 * glow_k)
	match String(e.shape):
		"line":
			draw_polyline(e.pts, Color(_eye_col, 0.35 * glow_k), 3.2 * u, true)
			draw_polyline(e.pts, core, 1.2 * u, true)
			return
		"visor":
			_glow(e.pos, e.r * 2.6, halo)
			draw_colored_polygon(e.pts, core)
			draw_polyline(e.line, Color(core, 0.8), 0.8 * u, true)
			return
		"x":
			_glow(e.pos, e.r * 2.4, Color(_eye_col, 0.4 * glow_k))
			var r: float = e.r
			draw_line(e.pos + Vector2(-r, -r) * 0.7, e.pos + Vector2(r, r) * 0.7, core, 1.3 * u, true)
			draw_line(e.pos + Vector2(r, -r) * 0.7, e.pos + Vector2(-r, r) * 0.7, core, 1.3 * u, true)
			return
	_glow(e.pos, e.r * (3.4 if e.shape == "orb" else 2.8), halo)
	if e.shape == "iris":
		draw_colored_polygon(e.pts, core)
		_fill_now(_lens_screen(e.pos, e.r * 0.42, e.r * 1.5, PI / 2.0), Color(0.03, 0.02, 0.05).lerp(Color.WHITE, flash * 0.5))
		_fill_now(_circle(e.pos + Vector2(-0.35, -0.4) * e.r, e.r * 0.22, 10), Color(1, 1, 1, 0.85))
		return
	_fill_now(e.pts, core)
	if e.shape == "round" or e.shape == "orb":
		_fill_now(_circle(e.pos + Vector2(-0.3, -0.32) * e.r, e.r * 0.32, 10), Color(1, 1, 1, 0.9))

# --- Construção da geometria (cache) ---

func _rebuild() -> void:
	_dirty = false
	_built_size = size
	var s := minf(size.x, size.y)
	_u = s / 100.0
	_o = (size - Vector2(s, s)) / 2.0
	_fine = s >= 100.0
	_layers.clear()
	_back.clear()
	_details.clear()
	_eyes.clear()
	_t = tint
	if _t.v < 0.66:
		_t.v = 0.66
	_c_top = _t.darkened(0.42)
	_c_bot = _t.darkened(0.82)
	_rim = Color(_t.lightened(0.3), 0.92)
	_eye_col = Color(1.0, 0.93, 0.6).lerp(_t.lightened(0.55), 0.3)
	match archetype if archetype in ARCHETYPES else "brute":
		"blob":
			_shape_blob()
		"rogue":
			_shape_rogue()
		"robed":
			_shape_robed()
		"goblin":
			_shape_goblin()
		"golem":
			_shape_golem()
		"hydra":
			_shape_hydra()
		"brute":
			_shape_brute()
		"dragon":
			_shape_dragon()
		"sphinx":
			_shape_sphinx()
		"lich":
			_shape_lich()
		"judge":
			_shape_judge()
		"void":
			_shape_void()
		"queen":
			_shape_queen()
		"knight":
			_shape_knight()
		"demon":
			_shape_demon()
		"dummy":
			_shape_dummy()
	var clip := _ell(Vector2(50, 50), CLIP_R, CLIP_R, 72)
	_disc_pts = _to_screen(_ell(Vector2(50, 50), DISC_R, DISC_R, 72))
	_s_layers.clear()
	for layer in _layers:
		var parts: Array = []
		for poly in layer:
			for piece in _clip_poly(poly, clip):
				var pts := _to_screen(piece)
				var cols := PackedColorArray()
				for p in piece:
					cols.append(_c_top.lerp(_c_bot, clampf((p.y - 14.0) / 80.0, 0.0, 1.0)))
				parts.append({"pts": pts, "line": _closed_line(pts), "cols": cols})
		_s_layers.append(parts)
	_s_back = _screen_details(_back, clip)
	_s_details = _screen_details(_details, clip)
	_s_eyes.clear()
	for e in _eyes:
		var se := {"shape": e.shape, "pos": _o + e.pos * _u, "r": e.r * _u}
		if e.has("pts"):
			se.pts = _to_screen(e.pts)
			se.line = _closed_line(se.pts)
		_s_eyes.append(se)

func _screen_details(list: Array, clip: PackedVector2Array) -> Array:
	var out: Array = []
	for d in list:
		if d.has("line"):
			for piece in _clip_line(d.line, clip):
				out.append({"line": _to_screen(piece), "col": d.col, "w": d.w * _u})
			continue
		for piece in _clip_poly(d.pts, clip):
			var pts := _to_screen(piece)
			var ring := _feather_ring(pts, clampf(_u * 0.9, 0.6, 1.4))
			var n := pts.size()
			var idx := PackedInt32Array()
			for i in n:
				var j := (i + 1) % n
				idx.append_array(PackedInt32Array([i, j, n + j, i, n + j, n + i]))
			out.append({"pts": pts, "ring": ring, "idx": idx, "col": d.col})
	return out

## Recorta pelo disco só se for preciso (evita o trabalho nas formas que já estão dentro).
func _clip_poly(poly: PackedVector2Array, clip: PackedVector2Array) -> Array:
	for p in poly:
		if p.distance_to(Vector2(50, 50)) > CLIP_R - 0.5:
			return Geometry2D.intersect_polygons(poly, clip)
	return [poly]

func _clip_line(line: PackedVector2Array, clip: PackedVector2Array) -> Array:
	for p in line:
		if p.distance_to(Vector2(50, 50)) > CLIP_R - 0.5:
			return Geometry2D.intersect_polyline_with_polygon(line, clip)
	return [line]

func _to_screen(pts: PackedVector2Array) -> PackedVector2Array:
	var out := PackedVector2Array()
	out.resize(pts.size())
	for i in pts.size():
		out[i] = _o + pts[i] * _u
	return out

## Contorno fechado que começa a meio do primeiro lado (a junção não se nota).
func _closed_line(pts: PackedVector2Array) -> PackedVector2Array:
	var out := PackedVector2Array()
	if pts.size() < 2:
		return out
	out.append_array(pts)
	out.append(pts[0])
	return out

## Pontos da orla suave (1 px para fora) de um polígono.
func _feather_ring(pts: PackedVector2Array, f: float) -> PackedVector2Array:
	var n := pts.size()
	var area := 0.0
	for i in n:
		area += pts[i].x * pts[(i + 1) % n].y - pts[(i + 1) % n].x * pts[i].y
	var sgn := 1.0 if area > 0.0 else -1.0
	var ring := PackedVector2Array()
	ring.resize(n * 2)
	for i in n:
		var cur := pts[i]
		var nrm := ((cur - pts[(i - 1 + n) % n]).normalized().orthogonal() + (pts[(i + 1) % n] - cur).normalized().orthogonal()).normalized()
		ring[i] = cur
		ring[n + i] = cur + nrm * sgn * f
	return ring

## Forma cheia já em coordenadas de ecrã, com orla suave.
func _fill_now(pts: PackedVector2Array, col: Color) -> void:
	if pts.size() < 3:
		return
	draw_colored_polygon(pts, col)
	var n := pts.size()
	var ring := _feather_ring(pts, clampf(_u * 0.9, 0.6, 1.4))
	var cols := PackedColorArray()
	cols.resize(n * 2)
	var idx := PackedInt32Array()
	for i in n:
		cols[i] = col
		cols[n + i] = Color(col, 0.0)
		var j := (i + 1) % n
		idx.append_array(PackedInt32Array([i, j, n + j, i, n + j, n + i]))
	RenderingServer.canvas_item_add_triangle_array(get_canvas_item(), idx, ring, cols)

## Leque com uma cor no centro a desvanecer até ao contorno dado.
func _fan(center: Vector2, boundary: PackedVector2Array, inner: Color, outer: Color) -> void:
	var n := boundary.size()
	var pts := PackedVector2Array([center])
	pts.append_array(boundary)
	var cols := PackedColorArray([inner])
	var idx := PackedInt32Array()
	for i in n:
		cols.append(outer)
		idx.append_array(PackedInt32Array([0, 1 + i, 1 + (i + 1) % n]))
	RenderingServer.canvas_item_add_triangle_array(get_canvas_item(), idx, pts, cols)

func _glow(center: Vector2, r: float, col: Color) -> void:
	_fan(center, _circle(center, r, 18), col, Color(col, 0.0))

## Anel que desvanece do raio r0 (cor col) para dentro até r1 (transparente).
func _ring_fade(c: Vector2, r0: float, r1: float, col: Color) -> void:
	var segs := 64
	var pts := PackedVector2Array()
	var cols := PackedColorArray()
	var idx := PackedInt32Array()
	for i in segs:
		var d := Vector2(cos(TAU * i / segs), sin(TAU * i / segs))
		pts.append(c + d * r0)
		pts.append(c + d * r1)
		cols.append(col)
		cols.append(Color(col, 0.0))
		var a := i * 2
		var b := ((i + 1) % segs) * 2
		idx.append_array(PackedInt32Array([a, b, a + 1, b, b + 1, a + 1]))
	RenderingServer.canvas_item_add_triangle_array(get_canvas_item(), idx, pts, cols)

func _circle(c: Vector2, r: float, segs: int) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in segs:
		pts.append(c + Vector2(cos(TAU * i / segs), sin(TAU * i / segs)) * r)
	return pts

func _diamond(c: Vector2, r: float, ang: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in 4:
		var a := ang + TAU * i / 4.0
		pts.append(c + Vector2(cos(a), sin(a)) * r)
	return pts

## Amêndoa (olho) em coordenadas de ecrã: largura w, altura h, rodada.
func _lens_screen(c: Vector2, w: float, h: float, rot: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for j in 9:
		var x := -0.5 + j / 8.0
		pts.append(c + Vector2(x * w, -h * 0.5 * (1.0 - 4.0 * x * x)).rotated(rot))
	for j in range(7, 0, -1):
		var x := -0.5 + j / 8.0
		pts.append(c + Vector2(x * w, h * 0.5 * (1.0 - 4.0 * x * x)).rotated(rot))
	return pts

# --- Construtores na grelha 100×100 ---

func _body(pts: PackedVector2Array, layer: int = 0) -> void:
	while _layers.size() <= layer:
		_layers.append([])
	_layers[layer].append(pts)

func _detail(pts: PackedVector2Array, col: Color, behind: bool = false) -> void:
	(_back if behind else _details).append({"pts": pts, "col": col})

func _stroke(pts: Array, col: Color, w: float, behind: bool = false) -> void:
	(_back if behind else _details).append({"line": PackedVector2Array(pts), "col": col, "w": w})

## Olho: "round", "slit" (amêndoa rodada), "dot", "square", "orb", "gem", "iris", "x", "visor" ou "line".
func _eye(shape: String, pos: Vector2, r: float, ang: float = 0.0) -> void:
	var e := {"shape": shape, "pos": pos, "r": r}
	match shape:
		"slit":
			e.pts = _lens(pos, r * 2.0, r * 0.95, ang)
		"square":
			e.pts = PackedVector2Array([pos + Vector2(-r, -r * 0.7), pos + Vector2(r, -r * 0.7), pos + Vector2(r, r * 0.7), pos + Vector2(-r, r * 0.7)])
		"gem":
			e.pts = _ell(pos, r * 0.8, r * 1.15, 4, 0.0)
		"iris":
			e.pts = _ell(pos, r, r, 24)
		"x":
			pass
		_:
			e.pts = _ell(pos, r, r, 18)
	_eyes.append(e)

func _eye_pts(shape: String, pos: Vector2, r: float, pts: PackedVector2Array) -> void:
	_eyes.append({"shape": shape, "pos": pos, "r": r, "pts": pts})

func _ell(c: Vector2, rx: float, ry: float, segs: int = 28, rot: float = 0.0) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in segs:
		var a := TAU * i / segs
		pts.append(c + Vector2(cos(a) * rx, sin(a) * ry).rotated(rot))
	return pts

func _lens(c: Vector2, w: float, h: float, rot: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for j in 9:
		var x := -0.5 + j / 8.0
		pts.append(c + Vector2(x * w, -h * 0.5 * (1.0 - 4.0 * x * x)).rotated(rot))
	for j in range(7, 0, -1):
		var x := -0.5 + j / 8.0
		pts.append(c + Vector2(x * w, h * 0.5 * (1.0 - 4.0 * x * x)).rotated(rot))
	return pts

func _pv(arr: Array) -> PackedVector2Array:
	return PackedVector2Array(arr)

## Espelha um contorno esquerdo (de cima para baixo) em x = 50 e fecha-o.
func _sym(left: Array) -> PackedVector2Array:
	var out := PackedVector2Array(left)
	for i in range(left.size() - 1, -1, -1):
		var p: Vector2 = left[i]
		if absf(p.x - 50.0) > 0.01:
			out.append(Vector2(100.0 - p.x, p.y))
	return out

## Espelho de uma forma em x = 50.
func _mx(pts: PackedVector2Array) -> PackedVector2Array:
	var out := PackedVector2Array()
	for i in range(pts.size() - 1, -1, -1):
		out.append(Vector2(100.0 - pts[i].x, pts[i].y))
	return out

## Curva de Bézier cúbica (n segmentos); skip_first tira o primeiro ponto (para encadear curvas).
func _bz(p0: Vector2, p1: Vector2, p2: Vector2, p3: Vector2, n: int = 8, skip_first: bool = false) -> Array:
	var out: Array = []
	for j in range(1 if skip_first else 0, n + 1):
		out.append(p0.bezier_interpolate(p1, p2, p3, float(j) / n))
	return out

## Tubo ao longo de um caminho, da largura w0 à largura w1 (corno, pescoço, tentáculo).
func _tube(path: Array, w0: float, w1: float) -> PackedVector2Array:
	var left := PackedVector2Array()
	var right := PackedVector2Array()
	var n := path.size()
	for i in n:
		var p: Vector2 = path[i]
		var a: Vector2 = path[maxi(0, i - 1)]
		var b: Vector2 = path[mini(n - 1, i + 1)]
		var nrm := (b - a).normalized().orthogonal()
		var w := lerpf(w0, w1, float(i) / maxf(1.0, n - 1)) * 0.5
		left.append(p + nrm * w)
		right.append(p - nrm * w)
	right.reverse()
	left.append_array(right)
	return left

## Ombros/peito: do pescoço (meia largura neck, altura y0) aos ombros (meia largura sw, altura ys).
func _shoulders(neck: float, y0: float, sw: float, ys: float) -> PackedVector2Array:
	var left: Array = [Vector2(50, y0), Vector2(50 - neck, y0)]
	left += _bz(Vector2(50 - neck, y0), Vector2(50 - neck, ys - 5), Vector2(50 - sw + 7, ys - 6), Vector2(50 - sw, ys + 5), 8, true)
	left += _bz(Vector2(50 - sw, ys + 5), Vector2(50 - sw - 3, ys + 14), Vector2(50 - sw - 4, 98), Vector2(50 - sw - 4, 106), 4, true)
	left.append(Vector2(50, 106))
	return _sym(left)

## Pedregulho irregular.
func _rock(c: Vector2, rx: float, ry: float, rot: float = 0.0) -> PackedVector2Array:
	var k := [1.0, 0.9, 1.06, 0.94, 1.02, 0.88, 1.05, 0.93]
	var pts := PackedVector2Array()
	for i in 8:
		var a := TAU * i / 8.0 + 0.2
		pts.append(c + Vector2(cos(a) * rx, sin(a) * ry).rotated(rot) * float(k[i]))
	return pts

# --- Cores de apoio ---

func _dark() -> Color:
	return Color(0.035, 0.03, 0.055)

func _mid() -> Color:
	return _t.darkened(0.25)

func _light(a: float = 1.0) -> Color:
	return Color(_t.lightened(0.25), a)

func _face() -> Color:
	return _t.darkened(0.18).lerp(Color(0.72, 0.64, 0.56), 0.3)

func _bone() -> Color:
	return Color(0.84, 0.81, 0.72).lerp(_t, 0.18)

# --- Arquétipos ---

func _shape_blob() -> void:
	_body(_ell(Vector2(50, 75), 40, 45, 44))
	_body(_tube(_bz(Vector2(50, 36), Vector2(51, 28), Vector2(55, 22), Vector2(63, 19), 8), 13, 2.0))
	_detail(_ell(Vector2(35, 47), 4.5, 8.5, 20, 0.55), _light(0.35))
	if _fine:
		_detail(_ell(Vector2(66, 79), 2.6, 2.6, 12), _light(0.22))
		_detail(_ell(Vector2(29, 72), 1.8, 1.8, 10), _light(0.2))
	_stroke([Vector2(39, 71), Vector2(44.5, 74.5), Vector2(50, 71.5), Vector2(55.5, 74.5), Vector2(61, 71)], _dark(), 2.0)
	_eye("round", Vector2(41, 58), 5.4)
	_eye("round", Vector2(59, 58), 5.4)

func _shape_rogue() -> void:
	_body(_shoulders(12, 60, 34, 72))
	var hood: Array = _bz(Vector2(22, 78), Vector2(20, 54), Vector2(29, 30), Vector2(56, 11), 12)
	hood += _bz(Vector2(56, 11), Vector2(67, 22), Vector2(80, 42), Vector2(78, 78), 12, true)
	hood += _bz(Vector2(78, 78), Vector2(66, 87), Vector2(34, 87), Vector2(22, 78), 8, true)
	hood.pop_back()
	_body(PackedVector2Array(hood), 1)
	_detail(_ell(Vector2(50, 47), 13, 15.5, 28), _dark())
	_detail(_pv([Vector2(37.5, 50.5), Vector2(62.5, 50.5), Vector2(61, 59), Vector2(50, 63), Vector2(39, 59)]), _mid())
	if _fine:
		_stroke([Vector2(40, 54.5), Vector2(50, 57.5), Vector2(60, 54.5)], _t.darkened(0.45), 1.0)
		_stroke(_bz(Vector2(30, 70), Vector2(38, 76), Vector2(62, 76), Vector2(70, 70), 8), _t.darkened(0.55), 1.0)
	_eye("slit", Vector2(44.5, 45.2), 3.6, 0.2)
	_eye("slit", Vector2(55.5, 45.2), 3.6, -0.2)

func _shape_robed() -> void:
	_stroke([Vector2(80, 99), Vector2(80, 30)], _t.darkened(0.35), 3.4, true)
	_body(_shoulders(13, 62, 36, 74))
	var left: Array = [Vector2(50, 15)]
	left += _bz(Vector2(50, 15), Vector2(38, 15), Vector2(27, 25), Vector2(26, 44), 10, true)
	left += _bz(Vector2(26, 44), Vector2(25, 58), Vector2(24, 70), Vector2(22, 84), 6, true)
	left.append(Vector2(50, 84))
	_body(_sym(left), 1)
	_detail(_ell(Vector2(50, 49), 11.5, 15.5, 28), _dark())
	_stroke([Vector2(37, 74), Vector2(50, 90), Vector2(63, 74)], _light(0.75), 2.2)
	if _fine:
		_stroke([Vector2(31, 40), Vector2(30, 62)], _t.darkened(0.6), 1.2)
		_stroke([Vector2(69, 40), Vector2(70, 62)], _t.darkened(0.6), 1.2)
	_eye("orb", Vector2(80, 25), 4.6)
	_eye("dot", Vector2(45.5, 48.5), 2.3)
	_eye("dot", Vector2(54.5, 48.5), 2.3)

func _shape_goblin() -> void:
	_body(_shoulders(10, 64, 27, 78))
	var ear := _pv([Vector2(37, 40), Vector2(22, 33), Vector2(7, 29), Vector2(15, 38), Vector2(24, 45), Vector2(36, 53)])
	_body(ear)
	_body(_mx(ear))
	_body(_ell(Vector2(50, 47), 16.5, 15.5, 32))
	var inner := _pv([Vector2(33, 42), Vector2(15, 33.5), Vector2(32, 48.5)])
	_detail(inner, _t.darkened(0.65))
	_detail(_mx(inner), _t.darkened(0.65))
	_detail(_pv([Vector2(39, 54), Vector2(61, 54), Vector2(57, 60), Vector2(50, 62), Vector2(43, 60)]), _dark())
	_detail(_pv([Vector2(43.5, 54), Vector2(47, 54), Vector2(45.3, 57.8)]), _bone())
	_detail(_pv([Vector2(53, 54), Vector2(56.5, 54), Vector2(54.7, 57.8)]), _bone())
	_detail(_pv([Vector2(38, 38.5), Vector2(47.5, 41), Vector2(47, 43), Vector2(38, 41)]), _dark())
	_detail(_mx(_pv([Vector2(38, 38.5), Vector2(47.5, 41), Vector2(47, 43), Vector2(38, 41)])), _dark())
	_detail(_ell(Vector2(50, 50), 2.6, 2.0, 12), _t.darkened(0.3))
	_eye("round", Vector2(43.5, 45.8), 3.6)
	_eye("round", Vector2(56.5, 45.8), 3.6)

func _shape_golem() -> void:
	_body(_pv([Vector2(30, 62), Vector2(70, 62), Vector2(78, 106), Vector2(22, 106)]))
	_body(_rock(Vector2(22, 72), 18, 17, -0.3), 1)
	_body(_rock(Vector2(78, 72), 18, 17, 0.3), 1)
	_body(_pv([Vector2(38, 24), Vector2(62, 24), Vector2(69, 36), Vector2(68, 56), Vector2(60, 62), Vector2(40, 62), Vector2(32, 56), Vector2(31, 36)]), 2)
	_detail(_pv([Vector2(38.5, 25), Vector2(52, 25), Vector2(47, 32.5), Vector2(32.5, 36.5)]), _t.darkened(0.3))
	_detail(_pv([Vector2(9, 64), Vector2(17, 57), Vector2(28, 57.5), Vector2(19, 63)]), _t.darkened(0.3))
	_detail(_pv([Vector2(72, 57.5), Vector2(83, 57), Vector2(91, 64), Vector2(81, 63)]), _t.darkened(0.3))
	if _fine:
		_stroke([Vector2(14, 74), Vector2(20, 78), Vector2(18, 85)], _t.darkened(0.65), 1.0)
		_stroke([Vector2(86, 74), Vector2(80, 79), Vector2(83, 86)], _t.darkened(0.65), 1.0)
	_detail(_pv([Vector2(31.5, 37), Vector2(68.5, 37), Vector2(67, 43), Vector2(33, 43)]), _dark())
	_detail(_pv([Vector2(42, 54), Vector2(58, 54), Vector2(57, 56.5), Vector2(43, 56.5)]), _dark())
	if _fine:
		_stroke([Vector2(36, 54), Vector2(41, 52), Vector2(44, 56)], _t.darkened(0.65), 1.0)
		_stroke([Vector2(62, 29), Vector2(58, 33), Vector2(60, 36)], _t.darkened(0.65), 1.0)
	_eye_pts("line", Vector2(50, 80), 1.0, _pv([Vector2(47, 69), Vector2(51.5, 75), Vector2(48, 81), Vector2(53, 89)]))
	_eye("square", Vector2(42.5, 47.5), 3.3)
	_eye("square", Vector2(57.5, 47.5), 3.3)

## Cabeça de serpente de frente (larga atrás, afunila para o focinho), centrada em c.
func _snake_head(c: Vector2, k: float, ang: float) -> PackedVector2Array:
	var local := [Vector2(0, -8.5), Vector2(5.5, -6.5), Vector2(8, -1), Vector2(6.5, 4), Vector2(3, 8), Vector2(0, 9.5), Vector2(-3, 8), Vector2(-6.5, 4), Vector2(-8, -1), Vector2(-5.5, -6.5)]
	var pts := PackedVector2Array()
	for p in local:
		pts.append(c + (p * k).rotated(ang))
	return pts

func _shape_hydra() -> void:
	_body(_tube(_bz(Vector2(28, 106), Vector2(26, 82), Vector2(14, 64), Vector2(23, 46), 12), 15, 9))
	_body(_tube(_bz(Vector2(72, 106), Vector2(74, 82), Vector2(86, 64), Vector2(77, 46), 12), 15, 9))
	_body(_snake_head(Vector2(23, 40), 0.88, -0.35))
	_body(_snake_head(Vector2(77, 40), 0.88, 0.35))
	_body(_tube(_bz(Vector2(50, 106), Vector2(53, 80), Vector2(45, 56), Vector2(50, 38), 12), 17, 10), 1)
	_body(_snake_head(Vector2(50, 29), 1.05, 0.0), 1)
	for h in [[Vector2(23, 40), 0.88, -0.35], [Vector2(50, 29), 1.05, 0.0], [Vector2(77, 40), 0.88, 0.35]]:
		var c: Vector2 = h[0]
		var k: float = h[1]
		var ang: float = h[2]
		_eye("slit", c + (Vector2(-3.6, -0.5) * k).rotated(ang), 2.0 * k, ang + 0.35)
		_eye("slit", c + (Vector2(3.6, -0.5) * k).rotated(ang), 2.0 * k, ang - 0.35)
		_detail(_ell(c + (Vector2(-1.5, 7) * k).rotated(ang), 0.7 * k, 0.5 * k, 8), _dark())
		_detail(_ell(c + (Vector2(1.5, 7) * k).rotated(ang), 0.7 * k, 0.5 * k, 8), _dark())
	if _fine:
		for i in 4:
			var y := 52.0 + i * 9.0
			_stroke([Vector2(45, y), Vector2(50, y + 3), Vector2(55, y)], _t.darkened(0.6), 1.0)

func _shape_brute() -> void:
	var left: Array = [Vector2(50, 50), Vector2(40, 50)]
	left += _bz(Vector2(40, 50), Vector2(30, 50), Vector2(17, 54), Vector2(12, 66), 8, true)
	left += _bz(Vector2(12, 66), Vector2(8, 76), Vector2(6, 92), Vector2(6, 106), 4, true)
	left.append(Vector2(50, 106))
	_body(_sym(left))
	var spike := _pv([Vector2(15, 61), Vector2(7, 47), Vector2(22, 56)])
	var spike2 := _pv([Vector2(25, 55), Vector2(23, 41), Vector2(32, 52)])
	_body(spike)
	_body(spike2)
	_body(_mx(spike))
	_body(_mx(spike2))
	var head: Array = [Vector2(50, 27)]
	head += _bz(Vector2(50, 27), Vector2(42, 27), Vector2(37, 32), Vector2(37, 41), 6, true)
	head += _bz(Vector2(37, 41), Vector2(36, 50), Vector2(38, 57), Vector2(44, 60), 6, true)
	head.append(Vector2(50, 61))
	_body(_sym(head), 1)
	_detail(_pv([Vector2(37.5, 37), Vector2(50, 40.5), Vector2(62.5, 37), Vector2(62.5, 41), Vector2(50, 44), Vector2(37.5, 41)]), _dark())
	_stroke([Vector2(44, 55.5), Vector2(56, 55.5)], _dark(), 1.6)
	_detail(_pv([Vector2(42.8, 56), Vector2(44.6, 50), Vector2(46.6, 56)]), _bone())
	_detail(_pv([Vector2(53.4, 56), Vector2(55.4, 50), Vector2(57.2, 56)]), _bone())
	_eye("slit", Vector2(44.5, 45.6), 3.0, 0.28)
	_eye("slit", Vector2(55.5, 45.6), 3.0, -0.28)

func _shape_dragon() -> void:
	var wing := _pv([Vector2(40, 66), Vector2(32, 50), Vector2(23, 34), Vector2(17, 22), Vector2(16, 34), Vector2(10, 42), Vector2(16.5, 46), Vector2(11, 56), Vector2(19.5, 58), Vector2(17, 68), Vector2(26, 68), Vector2(30, 76)])
	_body(wing)
	_body(_mx(wing))
	if _fine:
		for tip in [Vector2(16, 34), Vector2(10, 42), Vector2(11, 56), Vector2(17, 68)]:
			_stroke([Vector2(31, 52), tip], _t.darkened(0.6), 0.9)
			_stroke([Vector2(69, 52), Vector2(100.0 - tip.x, tip.y)], _t.darkened(0.6), 0.9)
	_body(_shoulders(11, 58, 26, 78), 1)
	var horn := _tube(_bz(Vector2(40.5, 28), Vector2(34, 20), Vector2(27, 15.5), Vector2(20, 15.5), 12), 7.0, 0.8)
	var horn2 := _tube(_bz(Vector2(36, 34), Vector2(32, 30), Vector2(28, 28), Vector2(24, 28), 6), 4.0, 0.6)
	var frill := _pv([Vector2(34.5, 40), Vector2(24, 43), Vector2(36, 47)])
	for part in [horn, horn2, frill]:
		_body(part, 1)
		_body(_mx(part), 1)
	_body(_sym([Vector2(50, 23), Vector2(43, 24), Vector2(38, 28), Vector2(35, 34), Vector2(33.5, 41), Vector2(36, 47), Vector2(41, 52), Vector2(40.5, 58), Vector2(42, 63.5), Vector2(45.5, 66.5), Vector2(50, 67)]), 1)
	_detail(_pv([Vector2(37, 35), Vector2(46, 38.5), Vector2(45.5, 40.5), Vector2(37, 38)]), _dark())
	_detail(_mx(_pv([Vector2(37, 35), Vector2(46, 38.5), Vector2(45.5, 40.5), Vector2(37, 38)])), _dark())
	_detail(_ell(Vector2(46.5, 60.5), 1.5, 0.9, 10, 0.4), _dark())
	_detail(_ell(Vector2(53.5, 60.5), 1.5, 0.9, 10, -0.4), _dark())
	_detail(_pv([Vector2(43.2, 63.5), Vector2(45.8, 65.2), Vector2(44.2, 69.5)]), _bone())
	_detail(_pv([Vector2(54.2, 65.2), Vector2(56.8, 63.5), Vector2(55.8, 69.5)]), _bone())
	_eye("slit", Vector2(42.8, 42), 3.2, 0.38)
	_eye("slit", Vector2(57.2, 42), 3.2, -0.38)

func _shape_sphinx() -> void:
	_body(_shoulders(14, 62, 38, 74))
	_body(_sym([Vector2(50, 16), Vector2(40, 17), Vector2(32, 22), Vector2(28, 32), Vector2(27, 46), Vector2(24, 56), Vector2(20.5, 64), Vector2(24.5, 79), Vector2(33, 80), Vector2(37, 64), Vector2(38, 54), Vector2(50, 54)]), 1)
	var face := _sym([Vector2(50, 28), Vector2(43, 29.5), Vector2(40.5, 36), Vector2(40.5, 46), Vector2(43, 54), Vector2(47, 58), Vector2(50, 59)])
	_detail(face, _face())
	_detail(_pv([Vector2(47.6, 58), Vector2(52.4, 58), Vector2(52, 68), Vector2(48, 68)]), _face().darkened(0.35))
	_stroke([Vector2(33, 27), Vector2(50, 25), Vector2(67, 27)], _light(0.8), 1.6)
	var band := _light(0.55 if _fine else 0.4)
	for i in 4:
		var y := 58.0 + i * 5.5
		var t := (y - 56.0) / 23.0
		_stroke([Vector2(lerpf(23.0, 24.5, t) + 1.0, y), Vector2(lerpf(37.0, 33.0, t) - 1.0, y)], band, 1.3)
		_stroke([Vector2(100.0 - lerpf(37.0, 33.0, t) + 1.0, y), Vector2(100.0 - lerpf(23.0, 24.5, t) - 1.0, y)], band, 1.3)
	_stroke([Vector2(40.5, 41.5), Vector2(37.5, 43)], _dark(), 1.0)
	_stroke([Vector2(59.5, 41.5), Vector2(62.5, 43)], _dark(), 1.0)
	_eye("gem", Vector2(50, 23.5), 2.2)
	_eye("slit", Vector2(45, 41.5), 2.9, 0.08)
	_eye("slit", Vector2(55, 41.5), 2.9, -0.08)

func _shape_lich() -> void:
	var sh := _sym([Vector2(50, 60), Vector2(38, 60), Vector2(27, 64), Vector2(18, 72), Vector2(15, 78), Vector2(19, 80), Vector2(11, 88), Vector2(16, 90), Vector2(8, 106), Vector2(50, 106)])
	_body(sh)
	var hood: Array = [Vector2(50, 13)]
	hood += _bz(Vector2(50, 13), Vector2(39, 14), Vector2(29, 22), Vector2(28, 37), 8, true)
	hood += [Vector2(27, 50), Vector2(24, 63), Vector2(29, 60), Vector2(27, 71), Vector2(33, 66), Vector2(35, 74), Vector2(50, 74)]
	_body(_sym(hood), 1)
	_detail(_ell(Vector2(50, 45), 14, 16, 28), _dark())
	var bone := _bone().darkened(0.12)
	_detail(_ell(Vector2(50, 42.5), 10.5, 11.5, 28), bone)
	_detail(_pv([Vector2(43.6, 48), Vector2(56.4, 48), Vector2(55, 58), Vector2(45, 58)]), bone)
	_detail(_ell(Vector2(45.6, 43.5), 3.5, 3.3, 14), _dark())
	_detail(_ell(Vector2(54.4, 43.5), 3.5, 3.3, 14), _dark())
	_detail(_pv([Vector2(50, 47.5), Vector2(48.4, 51), Vector2(51.6, 51)]), _dark())
	if _fine:
		for x in [46.5, 48.8, 51.2, 53.5]:
			_stroke([Vector2(x, 53.5), Vector2(x, 57)], _dark(), 0.8)
		_stroke([Vector2(45, 53.5), Vector2(55, 53.5)], _dark(), 0.8)
	else:
		_stroke([Vector2(45, 54), Vector2(55, 54)], _dark(), 1.2)
	_detail(_pv([Vector2(39, 34), Vector2(39.5, 23), Vector2(43.5, 29.5), Vector2(46, 19), Vector2(50, 27), Vector2(54, 19), Vector2(56.5, 29.5), Vector2(60.5, 23), Vector2(61, 34)]), _t.darkened(0.15))
	_eye("gem", Vector2(50, 30.5), 1.7)
	_eye("dot", Vector2(45.6, 43.6), 1.8)
	_eye("dot", Vector2(54.4, 43.6), 1.8)

func _shape_judge() -> void:
	_body(_shoulders(13, 62, 37, 74))
	_body(_ell(Vector2(50, 31), 17, 12, 28), 1)
	for side in [-1.0, 1.0]:
		_body(_ell(Vector2(50 + side * 17, 40), 7, 6.5, 20), 1)
		_body(_ell(Vector2(50 + side * 18, 50.5), 7, 6.5, 20), 1)
		_body(_ell(Vector2(50 + side * 17, 61), 6.5, 6, 20), 1)
	if _fine:
		for side in [-1.0, 1.0]:
			for y in [40.0, 50.5, 61.0]:
				var cx: float = 50.0 + side * (18.0 if y == 50.5 else 17.0)
				_stroke(_arc_pts(Vector2(cx, y), 3.6, 0.3, 4.6), _light(0.5), 1.0)
	_detail(_sym([Vector2(50, 33), Vector2(43, 34), Vector2(40.5, 41), Vector2(41, 50), Vector2(44.5, 57), Vector2(50, 59)]), _face())
	_detail(_pv([Vector2(46.2, 64), Vector2(49.6, 64), Vector2(49.2, 77), Vector2(46.6, 76)]), Color(0.86, 0.85, 0.8).darkened(0.15))
	_detail(_pv([Vector2(50.4, 64), Vector2(53.8, 64), Vector2(53.4, 76), Vector2(50.8, 77)]), Color(0.86, 0.85, 0.8).darkened(0.15))
	_detail(_pv([Vector2(41.5, 40.5), Vector2(48.5, 41.5), Vector2(48.5, 43), Vector2(41.5, 42.3)]), _dark())
	_detail(_mx(_pv([Vector2(41.5, 40.5), Vector2(48.5, 41.5), Vector2(48.5, 43), Vector2(41.5, 42.3)])), _dark())
	_stroke([Vector2(46, 53.2), Vector2(54, 53.2)], _dark(), 1.4)
	_eye("slit", Vector2(45.4, 46), 2.7, 0.1)
	_eye("slit", Vector2(54.6, 46), 2.7, -0.1)

func _arc_pts(c: Vector2, r: float, a0: float, a1: float) -> Array:
	var out: Array = []
	for j in 9:
		var a := lerpf(a0, a1, j / 8.0)
		out.append(c + Vector2(cos(a), sin(a)) * r)
	return out

func _shape_void() -> void:
	_body(_ell(Vector2(50, 52), 29, 29, 40))
	for i in 7:
		var a := TAU * i / 7.0 + 0.3
		var p0 := Vector2(50, 52) + Vector2(cos(a), sin(a)) * 22.0
		var p3 := Vector2(50, 52) + Vector2(cos(a + 0.75), sin(a + 0.75)) * 44.0
		var p1 := Vector2(50, 52) + Vector2(cos(a + 0.1), sin(a + 0.1)) * 34.0
		var p2 := Vector2(50, 52) + Vector2(cos(a + 0.55), sin(a + 0.55)) * 38.0
		_body(_tube(_bz(p0, p1, p2, p3, 10), 11, 1.2))
	for i in 3:
		var a0 := TAU * i / 3.0
		var arm: Array = []
		for j in 13:
			var t := j / 12.0
			var a := a0 + t * 2.3
			arm.append(Vector2(50, 52) + Vector2(cos(a), sin(a)) * (14.0 + 14.0 * t))
		_stroke(arm, Color(_t.lightened(0.1), 0.55), 1.4)
	_detail(_lens(Vector2(50, 52), 30, 16, 0.0), _dark())
	_stroke(_lens_arc(Vector2(50, 52), 30, 16), _light(0.7), 1.2)
	_eye("iris", Vector2(50, 52), 6.2)
	for p in [Vector2(30, 39), Vector2(70, 37), Vector2(67, 71), Vector2(33, 70)]:
		_eye("dot", p, 1.5)

func _lens_arc(c: Vector2, w: float, h: float) -> Array:
	var out: Array = []
	for j in 17:
		var x := -0.5 + j / 16.0
		out.append(c + Vector2(x * w, -h * 0.5 * (1.0 - 4.0 * x * x)))
	return out

func _shape_queen() -> void:
	_body(_sym([Vector2(50, 21), Vector2(40, 22), Vector2(32, 29), Vector2(29, 42), Vector2(28.5, 56), Vector2(26, 70), Vector2(21, 84), Vector2(19, 106), Vector2(50, 106)]))
	_body(_shoulders(9, 63, 29, 77), 1)
	var collar := _pv([Vector2(39, 67), Vector2(30, 51), Vector2(37, 54), Vector2(45, 65)])
	_body(collar, 1)
	_body(_mx(collar), 1)
	_body(_pv([Vector2(46.2, 52), Vector2(53.8, 52), Vector2(54.8, 66), Vector2(45.2, 66)]), 1)
	_detail(_sym([Vector2(50, 30), Vector2(43.5, 31.5), Vector2(41, 38), Vector2(41.5, 46), Vector2(44.5, 53), Vector2(50, 56)]), _face())
	_detail(_lens(Vector2(50, 50.2), 4.6, 1.8, 0.0), Color(0.62, 0.2, 0.26))
	_detail(_pv([Vector2(40, 33.5), Vector2(39, 21), Vector2(44.5, 27.5), Vector2(50, 13.5), Vector2(55.5, 27.5), Vector2(61, 21), Vector2(60, 33.5)]), GOLD.darkened(0.08))
	_detail(_pv([Vector2(40, 30.5), Vector2(60, 30.5), Vector2(60, 33.5), Vector2(40, 33.5)]), GOLD.darkened(0.35))
	_eye("gem", Vector2(50, 25.5), 1.9)
	_eye("slit", Vector2(45.8, 42.3), 2.6, 0.06)
	_eye("slit", Vector2(54.2, 42.3), 2.6, -0.06)

func _shape_knight() -> void:
	var plume: Array = _bz(Vector2(50, 24), Vector2(53, 13), Vector2(70, 10), Vector2(80, 30), 14)
	_detail(_tube(plume, 10.5, 3.0), _t.darkened(0.05), true)
	for i in range(2, 13, 2):
		var p: Vector2 = plume[i]
		var q: Vector2 = plume[i + 1]
		var side := (q - p).normalized().orthogonal()
		_stroke([p - side * 4.0, p + side * 1.0 + (q - p) * 1.4], _t.darkened(0.4), 0.9, true)
	_body(_shoulders(14, 64, 36, 76))
	_body(_sym([Vector2(50, 19)] + _bz(Vector2(50, 19), Vector2(41, 19), Vector2(35, 26), Vector2(35, 38), 8, true) + [Vector2(35.5, 58), Vector2(38.5, 65), Vector2(50, 67)]), 1)
	_body(_ell(Vector2(25, 78), 15, 11, 28, -0.25), 2)
	_body(_ell(Vector2(75, 78), 15, 11, 28, 0.25), 2)
	_stroke([Vector2(50, 20.5), Vector2(50, 39)], _light(0.75), 1.6)
	if _fine:
		_stroke(_arc_pts(Vector2(25, 78), 10.5, PI * 1.05, PI * 1.75), _light(0.5), 1.0)
		_stroke(_arc_pts(Vector2(75, 78), 10.5, PI * 1.25, PI * 1.95), _light(0.5), 1.0)
		for p in [Vector2(42, 51), Vector2(42, 55), Vector2(58, 51), Vector2(58, 55)]:
			_detail(_ell(p, 0.9, 0.9, 8), _dark())
	_eye_pts("visor", Vector2(50, 45), 5.0, _pv([Vector2(38.5, 40.5), Vector2(61.5, 40.5), Vector2(61.5, 44.3), Vector2(52, 44.3), Vector2(52, 56), Vector2(48, 56), Vector2(48, 44.3), Vector2(38.5, 44.3)]))

func _shape_demon() -> void:
	var horn := _tube(_bz(Vector2(41, 33), Vector2(28, 33), Vector2(21, 25), Vector2(26, 13), 12), 8.5, 0.8)
	_body(horn)
	_body(_mx(horn))
	_body(_shoulders(12, 60, 36, 72))
	_body(_sym([Vector2(50, 26), Vector2(42, 27), Vector2(36, 34), Vector2(35, 44), Vector2(38, 54), Vector2(44, 61), Vector2(50, 65)]), 1)
	var ear := _pv([Vector2(36.5, 40), Vector2(27, 34.5), Vector2(31, 44), Vector2(36.5, 47)])
	_body(ear, 1)
	_body(_mx(ear), 1)
	_detail(_pv([Vector2(38, 37.5), Vector2(50, 41.5), Vector2(62, 37.5), Vector2(62, 40.5), Vector2(50, 44.5), Vector2(38, 40.5)]), _dark())
	_detail(_pv([Vector2(41, 52), Vector2(59, 52), Vector2(55, 58), Vector2(50, 59.5), Vector2(45, 58)]), _dark())
	_detail(_pv([Vector2(43.8, 52), Vector2(46.6, 52), Vector2(45.2, 56.8)]), _bone())
	_detail(_pv([Vector2(53.4, 52), Vector2(56.2, 52), Vector2(54.8, 56.8)]), _bone())
	_eye("slit", Vector2(44.5, 45.6), 3.2, 0.32)
	_eye("slit", Vector2(55.5, 45.6), 3.2, -0.32)

func _shape_dummy() -> void:
	_body(_pv([Vector2(46, 56), Vector2(54, 56), Vector2(54.5, 106), Vector2(45.5, 106)]))
	_body(_pv([Vector2(11, 63.5), Vector2(89, 63.5), Vector2(89, 70.5), Vector2(11, 70.5)]))
	_body(_ell(Vector2(50, 84), 20, 18, 32), 1)
	_body(_ell(Vector2(50, 42), 15, 16, 32), 1)
	var rope := Color(0.62, 0.5, 0.32).lerp(_t, 0.2).darkened(0.25)
	_detail(_pv([Vector2(43.5, 55), Vector2(56.5, 55), Vector2(55.5, 59.5), Vector2(44.5, 59.5)]), rope)
	_detail(_ell(Vector2(50, 84), 9, 9, 28), Color(0.72, 0.2, 0.2))
	_detail(_ell(Vector2(50, 84), 6, 6, 24), Color(0.88, 0.84, 0.76).darkened(0.1))
	_detail(_ell(Vector2(50, 84), 3, 3, 16), Color(0.72, 0.2, 0.2))
	if _fine:
		_stroke([Vector2(50, 27), Vector2(50, 34)], _t.darkened(0.6), 1.0)
		for y in [28.5, 31.5]:
			_stroke([Vector2(48.6, y), Vector2(51.4, y)], _t.darkened(0.6), 0.8)
		for x in [12.0, 88.0]:
			var dx := -1.0 if x < 50.0 else 1.0
			_stroke([Vector2(x, 64), Vector2(x + dx * 4.0, 61)], rope, 1.0)
			_stroke([Vector2(x, 67), Vector2(x + dx * 4.5, 67)], rope, 1.0)
			_stroke([Vector2(x, 70), Vector2(x + dx * 4.0, 73)], rope, 1.0)
	_stroke([Vector2(43, 50), Vector2(57, 50)], _dark(), 1.2)
	for x in [45.0, 48.5, 52.0, 55.5]:
		_stroke([Vector2(x, 48.5), Vector2(x + 0.6, 51.5)], _dark(), 0.9)
	_eye("x", Vector2(44, 41.5), 3.0)
	_eye("x", Vector2(56, 41.5), 3.0)
