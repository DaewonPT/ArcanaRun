class_name TurnPips
extends Control
## Turnos da batalha em pips: ● os já jogados, o atual com um anel a pulsar, ○ os que faltam.
## Os turnos extra (Relógio, planeswalker…) aparecem a dourado depois dos normais.
## O resto da informação (ante, ato, tipo de inimigo, Selo) está na pausa.

const R := 8.0
const STEP := 24.0
const DONE := Color(0.98, 0.75, 0.25)
const LEFT := Color(0.42, 0.38, 0.55)
const EXTRA := Color(1.0, 0.86, 0.45)
const LAST := Color(0.95, 0.3, 0.3)   # 0.20.0 (B7): a bolinha do último turno

var turn: int = 1
var total: int = 5          # turnos normais
var extra: int = 0          # turnos extra
var last: bool = false      # 0.20.0 (B7): o turno atual é o último (se o inimigo não cair, perdes)
var _t := 0.0
var _acc := 0.0
## 0.16.0 (74): o anel do turno pulsa só nos primeiros segundos do turno, a 20 redesenhos por segundo (antes
## redesenhava a cada frame, a batalha toda).
const PULSE_TIME := 4.0
const PULSE_FPS := 20.0

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_PASS
	custom_minimum_size = Vector2(5 * STEP + 8, 40)

func set_turns(p_turn: int, p_total: int, p_extra: int, p_last: bool = false) -> void:
	turn = p_turn
	last = p_last
	total = maxi(1, p_total)
	extra = maxi(0, p_extra)
	custom_minimum_size.x = (total + extra) * STEP + 8
	tooltip_text = TranslationServer.translate("Turno %d/%d") % [turn, total + extra]
	update_minimum_size()
	_t = 0.0
	set_process(Settings.motion_ok())
	queue_redraw()

func _process(delta: float) -> void:
	if not Settings.motion_ok():
		set_process(false)
		return
	_t += delta
	_acc += delta
	if _t >= PULSE_TIME:
		set_process(false)   # o anel fica parado até ao turno seguinte
		queue_redraw()
		return
	if _acc >= 1.0 / PULSE_FPS:
		_acc = 0.0
		queue_redraw()

func _draw() -> void:
	var n := total + extra
	var y := size.y / 2.0
	var x0 := (size.x - (n - 1) * STEP) / 2.0
	for i in n:
		var c := Vector2(x0 + i * STEP, y)
		var number := i + 1
		var col := EXTRA if i >= total else DONE
		if number < turn:
			draw_circle(c, R, col.darkened(0.25))
		elif number == turn:
			var cur := LAST if last else col
			draw_circle(c, R, cur)
			var pulse := 0.5 + 0.5 * sin(_t * 3.2) if Settings.motion_ok() and _t < PULSE_TIME else 1.0
			draw_arc(c, R + 3.0 + pulse * 2.0, 0.0, TAU, 28, Color(cur, 0.35 + 0.4 * pulse), 2.0, true)
		else:
			draw_arc(c, R - 1.0, 0.0, TAU, 24, (EXTRA if i >= total else LEFT), 2.0, true)
