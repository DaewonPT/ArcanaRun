class_name TurnPips
extends Control
## Turnos da batalha em pips: ● os já jogados, o atual com um anel a pulsar, ○ os que faltam.
## Os turnos extra (Relógio, planeswalker…) aparecem a dourado depois dos normais.
## O resto da informação (ante, ato, tipo de inimigo, Selo) está na pausa.

const R := 8.0
const STEP := 24.0
const DONE := Color(0.98, 0.75, 0.25)
const LEFT := Color(0.42, 0.38, 0.55)
const EXTRA := Color(1.0, 0.86, 0.45)

var turn: int = 1
var total: int = 5          # turnos normais
var extra: int = 0          # turnos extra
var _t := 0.0

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_PASS
	custom_minimum_size = Vector2(5 * STEP + 8, 40)

func set_turns(p_turn: int, p_total: int, p_extra: int) -> void:
	turn = p_turn
	total = maxi(1, p_total)
	extra = maxi(0, p_extra)
	custom_minimum_size.x = (total + extra) * STEP + 8
	tooltip_text = TranslationServer.translate("Turno %d/%d") % [turn, total + extra]
	update_minimum_size()
	queue_redraw()

func _process(delta: float) -> void:
	if not Settings.motion_ok():
		return
	_t += delta
	queue_redraw()

func _draw() -> void:
	var n := total + extra
	var y := size.y / 2.0
	var x0 := (size.x - (n - 1) * STEP) / 2.0
	for i in n:
		var c := Vector2(x0 + i * STEP, y)
		var number := i + 1
		var col := EXTRA if i >= total else DONE
		if number < turn:
			draw_circle(c, R, col.darkened(0.25))
		elif number == turn:
			draw_circle(c, R, col)
			var pulse := 0.5 + 0.5 * sin(_t * 3.2) if Settings.motion_ok() else 1.0
			draw_arc(c, R + 3.0 + pulse * 2.0, 0.0, TAU, 28, Color(col, 0.35 + 0.4 * pulse), 2.0, true)
		else:
			draw_arc(c, R - 1.0, 0.0, TAU, 24, (EXTRA if i >= total else LEFT), 2.0, true)
