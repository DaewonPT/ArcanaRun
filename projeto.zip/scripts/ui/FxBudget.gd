class_name FxBudget
extends RefCounted
## 0.19.0 (212): um teto comum de partículas no ecrã — clima, explosões, confetes e cacos pedem a sua parte e
## recebem o que ainda cabe (no mínimo umas poucas, para o efeito se ver). Os pedidos acabam quando o nó sai
## do ecrã ou passado o tempo dado (as explosões de um nó que fica).

const CAP := 220
const CAP_PERF := 110
const MIN_GRANT := 6

static var _live: Dictionary = {}   # instance_id -> [quantidade, até (s; 0 = enquanto o nó existir), weakref]

static func cap() -> int:
	return CAP_PERF if Settings.performance_mode else CAP

## Quantas partículas estão em uso agora.
static func used() -> int:
	var now := Time.get_ticks_msec() / 1000.0
	var n := 0
	for id in _live.keys():
		var e: Array = _live[id]
		var ref: WeakRef = e[2]
		if ref.get_ref() == null or (float(e[1]) > 0.0 and now > float(e[1])):
			_live.erase(id)
			continue
		n += int(e[0])
	return n

## Pede `want` partículas para `node` (um pedido novo do mesmo nó substitui o anterior). Devolve as que pode usar.
static func grant(node: Object, want: int, seconds: float = 0.0) -> int:
	if node == null or want <= 0:
		return 0
	var id := node.get_instance_id()
	_live.erase(id)
	var free := cap() - used()
	var give := clampi(free, 0, want)
	if give < mini(want, MIN_GRANT):
		give = mini(want, MIN_GRANT)
	_live[id] = [give, Time.get_ticks_msec() / 1000.0 + seconds if seconds > 0.0 else 0.0, weakref(node)]
	return give

static func release(node: Object) -> void:
	if node != null:
		_live.erase(node.get_instance_id())

static func clear() -> void:
	_live.clear()
