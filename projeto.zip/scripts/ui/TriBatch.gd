class_name TriBatch
extends RefCounted
## 0.14.0: junta muitas formas simples (polígonos, anéis, traços, círculos) num só lote de triângulos com cor
## por vértice e desenha-o num único comando (RenderingServer.canvas_item_add_triangle_array). Serve para os
## enfeites das cartas: com draw_polyline/draw_arc/draw_polygon cada peça era um comando de desenho (as
## linhas suaves, vários), e com uma mão de cartas isso somava centenas por frame.
## As bordas suaves fazem-se com uma orla de ~1 px que vai a transparente (feather).

var pts := PackedVector2Array()
var cols := PackedColorArray()
var idx := PackedInt32Array()
var offset := Vector2.ZERO     # somado a todos os pontos (p.ex. para desenhar nas coordenadas da carta)

func is_empty() -> bool:
	return idx.is_empty()

func _v(p: Vector2, c: Color) -> int:
	pts.append(p + offset)
	cols.append(c)
	return pts.size() - 1

## Polígono convexo (leque a partir do 1.º ponto); uma cor ou uma cor por ponto.
func convex(poly: PackedVector2Array, colors: PackedColorArray) -> void:
	if poly.size() < 3:
		return
	var base := pts.size()
	for i in poly.size():
		_v(poly[i], colors[i] if colors.size() == poly.size() else colors[0])
	for i in range(1, poly.size() - 1):
		idx.append_array(PackedInt32Array([base, base + i, base + i + 1]))

## Anel entre dois contornos fechados com o mesmo número de pontos (cor por ponto ou uma só cor em cada).
func strip(outer: PackedVector2Array, inner: PackedVector2Array, c_out: PackedColorArray, c_in: PackedColorArray) -> void:
	var n := mini(outer.size(), inner.size())
	if n < 2:
		return
	var base := pts.size()
	for i in n:
		_v(outer[i], c_out[i] if c_out.size() == n else c_out[0])
		_v(inner[i], c_in[i] if c_in.size() == n else c_in[0])
	for i in n:
		var a := base + 2 * i
		var b := base + 2 * ((i + 1) % n)
		idx.append_array(PackedInt32Array([a, b, a + 1, b, b + 1, a + 1]))

## Traço reto de largura w (sem pontas redondas), com cor que pode variar de a para b.
func seg(a: Vector2, b: Vector2, w: float, ca: Color, cb: Color = Color(0, 0, 0, -1)) -> void:
	var d := b - a
	if d.length() < 0.01:
		return
	var n := Vector2(-d.y, d.x).normalized() * (w * 0.5)
	var end_c := ca if cb.a < 0.0 else cb
	var i0 := _v(a + n, ca)
	var i1 := _v(b + n, end_c)
	var i2 := _v(b - n, end_c)
	var i3 := _v(a - n, ca)
	idx.append_array(PackedInt32Array([i0, i1, i2, i0, i2, i3]))

## Círculo cheio com orla suave.
func disc(c: Vector2, r: float, col: Color, segments: int = 16) -> void:
	var ring := _circle(c, r, segments)
	var base := _v(c, col)
	for i in segments:
		_v(ring[i], col)
	for i in segments:
		idx.append_array(PackedInt32Array([base, base + 1 + i, base + 1 + (i + 1) % segments]))
	strip(_circle(c, r + 0.8, segments), ring, PackedColorArray([Color(col, 0.0)]), PackedColorArray([col]))

## Anel circular (de r0 a r1).
func circle_ring(c: Vector2, r0: float, r1: float, col: Color, segments: int = 32) -> void:
	strip(_circle(c, r1, segments), _circle(c, r0, segments), PackedColorArray([col]), PackedColorArray([col]))

## Orla suave à volta de um contorno (de col no contorno a transparente a w px para fora/dentro).
func feather(contour: PackedVector2Array, grown: PackedVector2Array, col: Color) -> void:
	strip(grown, contour, PackedColorArray([Color(col, 0.0)]), PackedColorArray([col]))

## Desenha o lote no CanvasItem (um só comando) e esvazia-o.
func flush(ci: CanvasItem) -> void:
	if idx.is_empty():
		return
	RenderingServer.canvas_item_add_triangle_array(ci.get_canvas_item(), idx, pts, cols)
	pts = PackedVector2Array()
	cols = PackedColorArray()
	idx = PackedInt32Array()

static func _circle(c: Vector2, r: float, segments: int) -> PackedVector2Array:
	var out := PackedVector2Array()
	for i in segments:
		var a := TAU * i / segments
		out.append(c + Vector2(cos(a), sin(a)) * r)
	return out
