class_name OrnamentDivider
extends Control
## 0.13.1 (visual "Grimório dourado"): divisória por baixo do título do menu — duas linhas douradas que
## se apagam nas pontas e um losango no meio, com um brilho suave.

const GOLD := Color(0.97, 0.84, 0.5)

func _init(p_width: float = 540.0) -> void:
	custom_minimum_size = Vector2(p_width, 16)
	size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _ready() -> void:
	resized.connect(queue_redraw)

func _draw() -> void:
	var w := size.x
	var y := size.y * 0.5
	var mid := w * 0.5
	var gap := 12.0
	var on := Color(GOLD, 1.0)
	var off := Color(GOLD, 0.0)
	draw_polygon(PackedVector2Array([Vector2(0, y - 1), Vector2(mid - gap, y - 1), Vector2(mid - gap, y + 1), Vector2(0, y + 1)]), PackedColorArray([off, on, on, off]))
	draw_polygon(PackedVector2Array([Vector2(mid + gap, y - 1), Vector2(w, y - 1), Vector2(w, y + 1), Vector2(mid + gap, y + 1)]), PackedColorArray([on, off, off, on]))
	draw_texture_rect(MenuBackdrop.glow_texture(), Rect2(Vector2(mid, y) - Vector2(16, 16), Vector2(32, 32)), false, Color(GOLD, 0.7))
	draw_colored_polygon(PackedVector2Array([Vector2(mid, y - 6), Vector2(mid + 6, y), Vector2(mid, y + 6), Vector2(mid - 6, y)]), GOLD)
