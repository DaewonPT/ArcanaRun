class_name DamageVignette
extends Control
## 0.12.0: quando levas dano, as bordas do ecrã ficam vermelhas por um instante (mais fortes quanto maior
## a fatia da tua vida) e três garras riscam o ecrã. Desenhado em código; com o movimento reduzido só
## fica o vermelho, mais leve.

var strength := 0.6
var _t := 0.0
var _dur := 0.55
var _slashes: Array = []

static func flash(parent: Node, strength_0_1: float) -> void:
	if parent == null or not is_instance_valid(parent) or not parent.is_inside_tree():
		return
	var v := DamageVignette.new()
	v.strength = clampf(strength_0_1, 0.25, 1.0) * (1.0 if Settings.motion_ok() else 0.5)
	v._dur = maxf(0.25, Settings.dur(0.55))
	parent.add_child(v)
	v._setup()

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	z_index = 15

func _setup() -> void:
	if Settings.motion_ok():
		var rng := RandomNumberGenerator.new()
		rng.randomize()
		var c := get_viewport_rect().size * Vector2(rng.randf_range(0.42, 0.58), rng.randf_range(0.55, 0.7))
		for i in 3:
			var off := Vector2((i - 1) * 46.0, (i - 1) * 8.0)
			_slashes.append([c + off + Vector2(-90, -110), c + off + Vector2(70, 120)])

func _process(delta: float) -> void:
	_t += delta
	if _t >= _dur:
		queue_free()
		return
	queue_redraw()

func _draw() -> void:
	var k := clampf(_t / _dur, 0.0, 1.0)
	var a := strength * (1.0 - k) * (1.0 - k)
	var s := size
	var w := minf(s.x, s.y) * 0.22
	var red := Color(0.85, 0.08, 0.1, 0.55 * a)
	var clear := Color(0.85, 0.08, 0.1, 0.0)
	# Quatro bordas em gradiente (polígonos com cores por vértice).
	_edge(PackedVector2Array([Vector2.ZERO, Vector2(s.x, 0), Vector2(s.x - w, w), Vector2(w, w)]), red, clear)
	_edge(PackedVector2Array([Vector2(0, s.y), Vector2(s.x, s.y), Vector2(s.x - w, s.y - w), Vector2(w, s.y - w)]), red, clear)
	_edge(PackedVector2Array([Vector2.ZERO, Vector2(0, s.y), Vector2(w, s.y - w), Vector2(w, w)]), red, clear)
	_edge(PackedVector2Array([Vector2(s.x, 0), Vector2(s.x, s.y), Vector2(s.x - w, s.y - w), Vector2(s.x - w, w)]), red, clear)
	# Garras: aparecem depressa (riscadas) e apagam-se.
	var grow := clampf(k / 0.25, 0.0, 1.0)
	for sl in _slashes:
		var p0: Vector2 = sl[0]
		var p1: Vector2 = p0.lerp(sl[1], grow)
		draw_line(p0, p1, Color(0.9, 0.15, 0.15, 0.5 * (1.0 - k)), 11.0 * (1.0 - k) + 1.0, true)
		draw_line(p0, p1, Color(1.0, 0.85, 0.85, 0.85 * (1.0 - k)), 5.0 * (1.0 - k) + 1.0, true)

func _edge(pts: PackedVector2Array, outer: Color, inner: Color) -> void:
	draw_polygon(pts, PackedColorArray([outer, outer, inner, inner]))
