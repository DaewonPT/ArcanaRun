class_name Opening
extends Control
## 0.16.1 (66): abertura animada (1,5 s) ao abrir o jogo — cinco faíscas nas cores de mana voam das
## pontas para o centro, acendem um anel e aparece o título dourado; depois tudo se desvanece para o menu.
## Só na primeira vez que o menu abre em cada sessão. Tocar salta-a. Sem ela com «Reduzir movimento».

signal finished

const DURATION := 1.5
const TITLE_FONT := preload("res://assets/fonts/NewRocker-Regular.ttf")
const SPARK := [Color(1.0, 0.95, 0.77), Color(0.37, 0.71, 1.0), Color(0.78, 0.61, 1.0), Color(1.0, 0.42, 0.37), Color(0.44, 0.88, 0.54)]

static var played := false

var _t := 0.0
var _done := false

## Mostra a abertura por cima do menu, se ainda não foi vista nesta sessão. Devolve null se não houver.
static func play_if_first(host: Control) -> Opening:
	if played or not Settings.motion_ok() or DisplayServer.get_name() == "headless":
		played = true
		return null
	played = true
	var o := Opening.new()
	host.add_child(o)
	return o

func _init() -> void:
	name = "Opening"
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	z_index = 50

func _process(delta: float) -> void:
	_t += delta
	queue_redraw()
	if _t >= DURATION:
		_finish()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and not event.pressed:
		accept_event()
		_finish()   # tocar salta a abertura

func _finish() -> void:
	if _done:
		return
	_done = true
	set_process(false)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var tw := create_tween()
	tw.tween_property(self, "modulate:a", 0.0, 0.25 if _t < DURATION else 0.12)
	tw.tween_callback(func():
		finished.emit()
		queue_free())

func _draw() -> void:
	var s := size
	if s.x < 10.0:
		return
	var c := s * 0.5 + Vector2(0, -20)
	# Fundo: escuro, a clarear para o menu no fim.
	var fade_bg := clampf((_t - 1.05) / 0.45, 0.0, 1.0)
	draw_rect(Rect2(Vector2.ZERO, s), Color(0.03, 0.02, 0.06, 1.0 - fade_bg * 0.85))
	var glow := MenuBackdrop.glow_texture()
	# 1) As faíscas vêm das pontas para o centro (0–0,55 s), com rasto.
	var fly := clampf(_t / 0.55, 0.0, 1.0)
	var e3 := 1.0 - pow(1.0 - fly, 3.0)
	for i in 5:
		var ang := -PI / 2.0 + TAU * i / 5.0
		var start := c + Vector2(cos(ang), sin(ang)) * s.length() * 0.6
		var ctrl := c + Vector2(cos(ang + 1.1), sin(ang + 1.1)) * s.y * 0.45
		var col: Color = SPARK[i]
		if fly < 1.0:
			for k in 6:
				var f := clampf(e3 - 0.05 * k, 0.0, 1.0)
				var u := 1.0 - f
				var p := start * (u * u) + ctrl * (2.0 * u * f) + c * (f * f)
				var r := 7.0 - k
				draw_texture_rect(glow, Rect2(p - Vector2(r, r) * 3.0, Vector2(r, r) * 6.0), false, Color(col, 0.5 * (1.0 - k / 6.0)))
				draw_circle(p, maxf(1.0, r * 0.45), Color(col.lightened(0.4), 1.0 - k / 6.0))
	# 2) O anel acende-se e abre (0,5–1,1 s).
	var ring := clampf((_t - 0.5) / 0.6, 0.0, 1.0)
	if ring > 0.0:
		var rr := lerpf(20.0, s.y * 0.3, 1.0 - pow(1.0 - ring, 2.0))
		var a := (1.0 - ring) * 0.9 + 0.1
		draw_texture_rect(glow, Rect2(c - Vector2(rr, rr) * 1.4, Vector2(rr, rr) * 2.8), false, Color(0.62, 0.45, 1.0, 0.35 * a))
		draw_arc(c, rr, 0.0, TAU, 96, Color(0.97, 0.84, 0.5, 0.85 * a), 3.0, true)
		draw_arc(c, rr * 0.86, 0.0, TAU, 96, Color(0.78, 0.65, 1.0, 0.5 * a), 1.5, true)
	# 3) O título aparece (0,55–1,0 s), dourado, a crescer um pouco.
	var tt := clampf((_t - 0.55) / 0.45, 0.0, 1.0)
	if tt > 0.0:
		var title := "ZERO-SUM"
		var fs := int(lerpf(84.0, 104.0, 1.0 - pow(1.0 - tt, 3.0)))
		var w := TITLE_FONT.get_string_size(title, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		var pos := Vector2(c.x - w * 0.5, c.y + fs * 0.32)
		draw_string_outline(TITLE_FONT, pos, title, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, 10, Color(0.14, 0.08, 0.2, tt))
		draw_string(TITLE_FONT, pos, title, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(0.98, 0.82, 0.42, tt))
