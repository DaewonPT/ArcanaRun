class_name CardArt
extends Control
## A ilustração de uma carta numa janela de cantos redondos, com a cor toda (0.14.0, visual "Vidro arcano"):
## um contorno fino e um brilho suave na cor de mana da carta. Usada na carta pequena (CardView) e na
## carta em grande (CardZoom). Até à 0.13 era desenhada por trás do texto, em faixas com transparência,
## o que deixava a arte velada e com riscas horizontais.
## Dois comandos de desenho: a ilustração (um polígono com UV) e, num só lote (TriBatch), o brilho e o contorno.

var texture: Texture2D:
	set(v):
		texture = v
		queue_redraw()
var radius := 8.0:
	set(v):
		radius = v
		queue_redraw()
## Contorno fino (alfa 0 = sem contorno).
var outline := Color(1, 1, 1, 0):
	set(v):
		outline = v
		queue_redraw()
var outline_width := 1.0
## Brilho à volta da janela (alfa 0 = sem brilho).
var glow := Color(1, 1, 1, 0):
	set(v):
		glow = v
		queue_redraw()
## Onde fica o corte na vertical quando a ilustração é mais alta do que a janela (0 = em cima, 1 = em baixo).
var bias_y := 0.4

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	if texture == null or size.x < 4.0 or size.y < 4.0:
		return
	var r := Rect2(Vector2.ZERO, size)
	ArtLib.draw_rounded(self, texture, r, radius, bias_y)
	var b := TriBatch.new()
	if glow.a > 0.0:
		b.strip(ArtLib.rounded_rect_points(r.grow(5.0), radius + 5.0, 4), ArtLib.rounded_rect_points(r, radius, 4),
			PackedColorArray([Color(glow, 0.0)]), PackedColorArray([glow]))
	if outline.a > 0.0:
		var edge := ArtLib.rounded_rect_points(r, radius, 4)
		var inner := ArtLib.rounded_rect_points(r.grow(-outline_width), maxf(0.0, radius - outline_width), 4)
		b.strip(edge, inner, PackedColorArray([outline]), PackedColorArray([outline]))
		b.feather(inner, ArtLib.rounded_rect_points(r.grow(-outline_width - 0.8), maxf(0.0, radius - outline_width - 0.8), 4), Color(outline, outline.a * 0.6))
	b.flush(self)
