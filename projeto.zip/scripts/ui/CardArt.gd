class_name CardArt
extends Control
## 0.12.0: a ilustração de uma carta por trás do texto — forte em cima (atrás do nome) e a desvanecer
## para baixo, onde fica só um véu para o texto continuar a ler-se. Desenhada em faixas horizontais
## com alfa a descer (sem shader). Usada na carta pequena (CardView) e na carta em grande (CardZoom).

var texture: Texture2D:
	set(v):
		texture = v
		queue_redraw()
var top_alpha := 0.6        # alfa no cimo
var fade_from := 0.15       # fração da altura onde começa a desvanecer
var fade_to := 0.55         # fração onde chega ao alfa de baixo
var floor_alpha := 0.14     # alfa por trás do texto
var height_frac := 1.0      # só desenha até esta fração da altura
const STRIPS := 18

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	if texture == null or size.x < 4.0 or size.y < 4.0:
		return
	var draw_h := size.y * height_frac
	var src := ArtLib.cover_region(texture, Vector2(size.x, draw_h), 0.35)
	for i in STRIPS:
		var y0 := draw_h * i / STRIPS
		var y1 := draw_h * (i + 1) / STRIPS
		var mid := (y0 + y1) * 0.5 / size.y
		var a := top_alpha
		if mid > fade_from:
			var k := clampf((mid - fade_from) / maxf(0.01, fade_to - fade_from), 0.0, 1.0)
			a = lerpf(top_alpha, floor_alpha, k * k * (3.0 - 2.0 * k))
		if a <= 0.005:
			continue
		var sy0 := src.position.y + src.size.y * (y0 / draw_h)
		var sy1 := src.position.y + src.size.y * (y1 / draw_h)
		draw_texture_rect_region(texture, Rect2(0.0, y0, size.x, y1 - y0 + 0.5), Rect2(src.position.x, sy0, src.size.x, sy1 - sy0), Color(1, 1, 1, a))
