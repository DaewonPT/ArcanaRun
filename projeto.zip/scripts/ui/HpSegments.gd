class_name HpSegments
extends Control
## 0.16.0 (63, no visual «Arte em destaque»): a barra de vida do boss em segmentos de vidro — um brilho por cima
## de cada segmento e uma divisória em cada fase (a metade, nos bosses que despertam), para se ver quanto falta
## para a 2.ª fase. Quando ele desperta, o segmento que acabou de esvaziar estala (rachas a abrir em 0,4 s,
## que ficam). Fica por cima da barra (dentro do HPStack) e não apanha toques.

var marks: Array[float] = []
var passed := 0               # fases já passadas: os segmentos de cima dessas divisórias estão rachados
var _crack_t := 1.0           # 0..1: as rachas do último segmento a estalar (1 = abertas)
const CRACK_TIME := 0.4

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_process(false)

func set_marks(p_marks: Array[float], p_passed: int) -> void:
	var was := passed
	if p_marks == marks and p_passed == passed:
		return
	marks = p_marks
	passed = p_passed
	if passed > was and Settings.motion_ok():
		_crack_t = 0.0
		set_process(true)
	queue_redraw()

func _process(delta: float) -> void:
	_crack_t = minf(1.0, _crack_t + delta / CRACK_TIME)
	if _crack_t >= 1.0:
		set_process(false)
	queue_redraw()

func _draw() -> void:
	var w := size.x
	var h := size.y
	if w < 8.0 or marks.is_empty():
		return
	var cuts: Array[float] = [0.0]
	for m in marks:
		cuts.append(clampf(m, 0.0, 1.0))
	cuts.append(1.0)
	cuts.sort()
	# Brilho do vidro: uma faixa clara em cima de cada segmento.
	for i in cuts.size() - 1:
		var x0 := cuts[i] * w + (2.0 if i > 0 else 1.0)
		var x1 := cuts[i + 1] * w - (2.0 if i < cuts.size() - 2 else 1.0)
		if x1 - x0 < 2.0:
			continue
		draw_rect(Rect2(x0, 2.0, x1 - x0, h * 0.32), Color(1, 1, 1, 0.13))
	# Divisórias.
	for m in marks:
		var x := clampf(m, 0.0, 1.0) * w
		draw_rect(Rect2(x - 1.5, 0, 3.0, h), Color(0.04, 0.02, 0.06, 0.85))
		draw_line(Vector2(x + 1.5, 1), Vector2(x + 1.5, h - 1), Color(1, 0.9, 0.7, 0.55), 1.0)
	# Os segmentos que esvaziaram (de cima para baixo, um por fase passada) estalam; o último a abrir as rachas.
	for b in mini(passed, cuts.size() - 2):
		var top := cuts[cuts.size() - 2 - b]
		var top_end := cuts[cuts.size() - 1 - b]
		var x0 := top * w
		var k := _crack_t if b == passed - 1 else 1.0
		var col := Color(0.95, 0.9, 1.0, 0.8)
		var paths := [
			[Vector2(0.0, 0.5), Vector2(0.18, 0.2), Vector2(0.34, 0.62), Vector2(0.52, 0.3), Vector2(0.7, 0.75), Vector2(0.9, 0.4)],
			[Vector2(0.34, 0.62), Vector2(0.4, 1.0)],
			[Vector2(0.52, 0.3), Vector2(0.6, 0.0)],
			[Vector2(0.7, 0.75), Vector2(0.82, 1.0)],
		]
		var seg_w := (top_end - top) * w
		for path in paths:
			var pts := PackedVector2Array()
			var n := maxi(2, int(ceil(path.size() * k)))
			for i in mini(n, path.size()):
				var q: Vector2 = path[i]
				pts.append(Vector2(x0 + q.x * seg_w, q.y * h))
			if pts.size() >= 2:
				draw_polyline(pts, col, 1.4, true)
