class_name ManaPips
extends Control
## Mana em cristais: um losango por ponto de mana deste turno — cheio = disponível, vazio = gasto.
## (Substitui o texto "Mana 3/5"; o número fica ao lado, pequeno.)
## 0.13.0: os cristais enchem-se de baixo para cima com um brilho (um de cada vez, no início do turno) e
## esvaziam ao gastar; a mana guardada do turno anterior (talento Reserva, Cântaro de Mana) aparece em
## cristais dourados a mais. Sem animações (reduzir movimento), muda logo.

const FILL := Color(0.45, 0.72, 1.0)
const EMPTY := Color(0.45, 0.72, 1.0, 0.28)
const SAVED := Color(0.98, 0.78, 0.3)
const PIP_W := 13.0
const GAP := 2.0
const MAX_DRAWN := 10
const FILL_TIME := 0.22      # segundos para encher um cristal
const STAGGER := 0.06        # atraso entre cristais ao encher

var available: int = 0
var total: int = 0
var _fill: Array[float] = []     # 0..1 por cristal (o que se vê)
var _delay: Array[float] = []    # espera antes de começar a encher
var _glow: Array[float] = []     # brilho a desvanecer
var _saved_glow := 0.0

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(PIP_W, 24)
	set_process(false)

func set_mana(p_available: int, p_total: int) -> void:
	available = maxi(0, p_available)
	total = maxi(0, p_total)
	var n := _count()
	custom_minimum_size.x = maxf(PIP_W, n * (PIP_W + GAP))
	var animate := Settings.motion_ok() and is_inside_tree()
	var k := 0
	while _fill.size() < n:
		_fill.append(0.0 if animate else 1.0)
		_delay.append(0.0)
		_glow.append(0.0)
	while _fill.size() > n:
		_fill.pop_back()
		_delay.pop_back()
		_glow.pop_back()
	for i in n:
		var target := 1.0 if i < available else 0.0
		if not animate:
			_fill[i] = target
			_delay[i] = 0.0
		elif target > _fill[i] and _delay[i] <= 0.0 and _fill[i] <= 0.0:
			_delay[i] = STAGGER * k   # os que enchem agora entram um a um
			k += 1
	set_process(animate)
	queue_redraw()

## Cristais desenhados: os do turno (total) e os dourados da mana guardada (disponível acima do total).
func _count() -> int:
	return mini(maxi(total, available), MAX_DRAWN)

## Brilho dourado nos cristais da mana guardada (início do turno).
func flash_saved(_n: int) -> void:
	_saved_glow = 1.0
	set_process(Settings.motion_ok())
	queue_redraw()

func _process(delta: float) -> void:
	var busy := false
	for i in _fill.size():
		var target := 1.0 if i < available else 0.0
		if _delay[i] > 0.0:
			_delay[i] = maxf(0.0, _delay[i] - delta)
			busy = true
			continue
		if _fill[i] < target:
			_fill[i] = minf(target, _fill[i] + delta / FILL_TIME)
			if _fill[i] >= target:
				_glow[i] = 1.0   # acabou de encher: brilha
			busy = true
		elif _fill[i] > target:
			_fill[i] = maxf(target, _fill[i] - delta / (FILL_TIME * 0.7))
			busy = true
		if _glow[i] > 0.0:
			_glow[i] = maxf(0.0, _glow[i] - delta * 2.2)
			busy = true
	if _saved_glow > 0.0:
		_saved_glow = maxf(0.0, _saved_glow - delta * 0.8)
		busy = true
	queue_redraw()
	if not busy:
		set_process(false)

func _draw() -> void:
	var n := _count()
	var cy := size.y / 2.0
	for i in n:
		var cx := i * (PIP_W + GAP) + PIP_W / 2.0
		var saved := i >= total
		var col := SAVED if saved else FILL
		var f: float = _fill[i] if i < _fill.size() else (1.0 if i < available else 0.0)
		var glow: float = _glow[i] if i < _glow.size() else 0.0
		if saved:
			glow = maxf(glow, _saved_glow)
		if glow > 0.0:
			draw_circle(Vector2(cx, cy), 10.0 + 3.0 * glow, Color(col, 0.35 * glow))
		var pts := PackedVector2Array([Vector2(cx, cy - 9), Vector2(cx + 6, cy), Vector2(cx, cy + 9), Vector2(cx - 6, cy)])
		draw_colored_polygon(pts, Color(col, 0.28))
		if f > 0.0:
			draw_colored_polygon(_filled_part(cx, cy, f), col.lerp(Color.WHITE, 0.35 * glow))
		if f >= 1.0:
			draw_line(Vector2(cx, cy - 6), Vector2(cx + 3, cy - 1), Color(1, 1, 1, 0.7), 1.5, true)
		else:
			pts.append(pts[0])
			draw_polyline(pts, col, 1.2, true)

## Parte cheia do losango, de baixo até à altura f (0..1).
func _filled_part(cx: float, cy: float, f: float) -> PackedVector2Array:
	if f >= 0.999:
		return PackedVector2Array([Vector2(cx, cy - 9), Vector2(cx + 6, cy), Vector2(cx, cy + 9), Vector2(cx - 6, cy)])
	var level := cy + 9.0 - 18.0 * f   # y da linha da "água"
	if level >= cy:
		var w := 6.0 * (cy + 9.0 - level) / 9.0
		return PackedVector2Array([Vector2(cx - w, level), Vector2(cx + w, level), Vector2(cx, cy + 9)])
	var w2 := 6.0 * (level - (cy - 9.0)) / 9.0
	return PackedVector2Array([Vector2(cx - w2, level), Vector2(cx + w2, level), Vector2(cx + 6, cy), Vector2(cx, cy + 9), Vector2(cx - 6, cy)])
