class_name ManaPips
extends Control
## Mana em cristais: um losango por ponto de mana deste turno — cheio = disponível, vazio = gasto.
## (Substitui o texto "Mana 3/5"; o número fica ao lado, pequeno.)

const FILL := Color(0.45, 0.72, 1.0)
const EMPTY := Color(0.45, 0.72, 1.0, 0.28)
const PIP_W := 13.0
const GAP := 2.0
const MAX_DRAWN := 10

var available: int = 0
var total: int = 0

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(PIP_W, 24)

func set_mana(p_available: int, p_total: int) -> void:
	available = maxi(0, p_available)
	total = maxi(0, p_total)
	custom_minimum_size.x = maxf(PIP_W, mini(total, MAX_DRAWN) * (PIP_W + GAP))
	queue_redraw()

func _draw() -> void:
	var n := mini(total, MAX_DRAWN)
	var cy := size.y / 2.0
	for i in n:
		var cx := i * (PIP_W + GAP) + PIP_W / 2.0
		var pts := PackedVector2Array([Vector2(cx, cy - 9), Vector2(cx + 6, cy), Vector2(cx, cy + 9), Vector2(cx - 6, cy)])
		if i < available:
			draw_colored_polygon(pts, FILL)
			draw_line(Vector2(cx, cy - 6), Vector2(cx + 3, cy - 1), Color(1, 1, 1, 0.7), 1.5, true)
		else:
			draw_colored_polygon(pts, EMPTY)
			pts.append(pts[0])
			draw_polyline(pts, FILL, 1.2, true)
