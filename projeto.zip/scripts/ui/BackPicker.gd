class_name BackPicker
extends HBoxContainer
## 0.16.1 (V12): escolher as costas de um baralho — as costas em pequeno e um botão que roda entre
## «padrão» (as das Configurações) e as costas que já tens. Fica guardado por baralho
## (GameState.set_deck_back) e vale no grimório da batalha, na troca de ecrã e na loja dessa run.

signal changed(back_id: String)

var deck_id := "":
	set(v):
		deck_id = v
		_refresh()
var _preview: CardBack
var _btn: Button

static func make(p_deck_id: String, height: int = 44) -> BackPicker:
	var p := BackPicker.new()
	p.name = "BackPicker"
	p._build(height)
	p.deck_id = p_deck_id
	return p

func _build(height: int) -> void:
	add_theme_constant_override("separation", 8)
	_preview = CardBack.new()
	_preview.name = "BackPreview"
	_preview.custom_minimum_size = Vector2(round(height * 0.72), height)
	_preview.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	add_child(_preview)
	_btn = UiKit.button("", height, 16)
	_btn.name = "BackButton"
	_btn.custom_minimum_size.x = 210
	_btn.clip_text = true
	_btn.pressed.connect(_on_pressed)
	add_child(_btn)

## As opções: "" (padrão) e as costas desbloqueadas.
func options() -> Array:
	var out: Array = [""]
	out.append_array(Settings.unlocked_cosmetics("back"))
	return out

func _on_pressed() -> void:
	if deck_id == "":
		return
	var opts := options()
	var cur := GameState.deck_back(deck_id)
	var nxt := String(opts[(opts.find(cur) + 1) % opts.size()])
	GameState.set_deck_back(deck_id, nxt)
	Sfx.select()
	_refresh()
	changed.emit(nxt)

func _refresh() -> void:
	if _btn == null:
		return
	var cur := GameState.deck_back(deck_id) if deck_id != "" else ""
	_preview.back_id = cur if cur != "" else Settings.card_back
	var name := tr("padrão") if cur == "" else tr(String(CardDB.get_cosmetic("back", cur).get("name", cur)))
	_btn.text = tr("Costas: %s") % name + ("  ▸" if options().size() > 1 else "")
	_btn.disabled = deck_id == "" or options().size() <= 1
	_btn.tooltip_text = tr("Toca para escolher as costas deste baralho (o grimório, a troca de ecrã e a loja).")
