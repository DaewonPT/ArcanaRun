class_name SoldStamp
extends Control
## 0.16.0 (V22): carimbo «VENDIDO» por cima de uma oferta comprada na loja (em vez do «✓» no fim do texto):
## tinta vermelha, contorno duplo e inclinado, como um carimbo de verdade. Entra com um pequeno «bater».
## Fica no meio do pai (cartas) ou encostado à direita (linhas de relíquias, poções e Vales).

var text := "VENDIDO"
var tilt := -0.2
var _font: Font

func _init(p_text: String = "VENDIDO") -> void:
	text = p_text
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_font = load("res://assets/fonts/Lora-Bold.ttf")

## Põe o carimbo num controlo: centered = no meio (cartas); senão encostado à direita (linhas). Com `at`
## (um retângulo no host), fica exatamente aí.
static func stamp(host: Control, centered: bool, animate: bool = true, at: Rect2 = Rect2(), word: String = "VENDIDO") -> SoldStamp:
	var old := host.get_node_or_null("SoldStamp")
	if old != null:
		return old as SoldStamp
	var st := SoldStamp.new(TranslationServer.translate(word))   # 0.19.0 (79): também «RESERVADA»
	st.name = "SoldStamp"
	host.add_child(st)
	var w := 150.0 if centered else 132.0
	var h := 50.0 if centered else 42.0
	if at.size.x > 0.0:
		w = at.size.x
		h = at.size.y
		st.position = at.position
		st.size = at.size
	elif centered:
		st.set_anchors_preset(Control.PRESET_CENTER)
		st.offset_left = -w * 0.5
		st.offset_right = w * 0.5
		st.offset_top = -h * 0.5
		st.offset_bottom = h * 0.5
	else:
		st.set_anchors_preset(Control.PRESET_CENTER_RIGHT)
		st.offset_left = -w - 14.0
		st.offset_right = -14.0
		st.offset_top = -h * 0.5
		st.offset_bottom = h * 0.5
	if animate and Settings.motion_ok() and Settings.anim_scale() > 0.0 and DisplayServer.get_name() != "headless":
		st.pivot_offset = Vector2(w, h) * 0.5
		st.scale = Vector2(1.6, 1.6)
		st.modulate.a = 0.0
		var tw := st.create_tween().set_parallel(true)
		tw.tween_property(st, "scale", Vector2.ONE, 0.16).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
		tw.tween_property(st, "modulate:a", 1.0, 0.1)
	return st

func _draw() -> void:
	var s := size
	if s.x < 10.0:
		return
	var ink := Color(0.86, 0.18, 0.2, 0.92)
	draw_set_transform(s * 0.5, tilt, Vector2.ONE)
	var r := Rect2(-s * 0.5, s)
	var outer := StyleBoxFlat.new()
	outer.draw_center = true
	outer.bg_color = Color(0.1, 0.03, 0.05, 0.55)
	outer.set_border_width_all(3)
	outer.border_color = ink
	outer.set_corner_radius_all(8)
	draw_style_box(outer, r)
	var inner := StyleBoxFlat.new()
	inner.draw_center = false
	inner.set_border_width_all(1)
	inner.border_color = Color(ink, 0.7)
	inner.set_corner_radius_all(5)
	draw_style_box(inner, r.grow(-6.0))
	var fs := int(clampf(s.y * 0.48, 14.0, 26.0))
	var tw := _font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
	while tw > s.x - 22.0 and fs > 12:
		fs -= 1
		tw = _font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
	draw_string(_font, Vector2(-tw * 0.5, _font.get_ascent(fs) * 0.38), text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1.0, 0.42, 0.42))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
