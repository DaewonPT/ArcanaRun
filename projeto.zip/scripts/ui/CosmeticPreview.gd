class_name CosmeticPreview
extends RefCounted
## 0.16.1: pré-visualizações dos cosméticos — no separador COSMÉTICOS da Coleção e no aviso de cosmético
## novo (V62). Costas: CardBack; moldura: carta em miniatura com o aro; tapete: ArenaMat; efeito do golpe:
## uma explosão na cor do efeito.

## Pré-visualização de um cosmético: costas (CardBack), moldura (carta em miniatura com o aro), tapete
## (ArenaMat) ou efeito do golpe (explosão na cor do efeito).
static func make(kind: String, id: String, px: Vector2) -> Control:
	match kind:
		"back":
			var cb := CardBack.new()
			cb.back_id = id
			cb.custom_minimum_size = px
			cb.mouse_filter = Control.MOUSE_FILTER_IGNORE
			return cb
		"frame":
			var fp := FramePreview.new()
			fp.frame_id = id
			fp.custom_minimum_size = px
			return fp
		"mat":
			var p := Panel.new()
			p.custom_minimum_size = px
			p.mouse_filter = Control.MOUSE_FILTER_IGNORE
			var base := UiKit.flat(Color(0.2, 0.17, 0.3), 10, Color(1, 1, 1, 0.16), 1, 0)
			p.add_theme_stylebox_override("panel", base)
			var mat := Panel.new()
			mat.set_anchors_preset(Control.PRESET_FULL_RECT)
			mat.mouse_filter = Control.MOUSE_FILTER_IGNORE
			mat.add_theme_stylebox_override("panel", ArenaMat.make(id))
			p.add_child(mat)
			return p
		_:
			var ep := EffectPreview.new()
			ep.effect_id = id
			ep.custom_minimum_size = px
			return ep

## Carta em miniatura com o aro de uma moldura (cor e espessura como nas cartas comuns).
class FramePreview extends Control:
	var frame_id := "classic"

	func _init() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _draw() -> void:
		var f := CardDB.get_cosmetic("frame", frame_id)
		var hex := String(f.get("color", ""))
		var col := Color(0.5, 0.45, 0.65) if (frame_id == "classic" or hex == "") else Color(hex)
		var r := Rect2(Vector2(2, 2), size - Vector2(4, 4))
		var bw := 3 if frame_id == "stone" else 2
		if frame_id == "neon":
			draw_style_box(UiKit.flat(Color(0, 0, 0, 0), 10, Color(col, 0.35), 6, 0), r.grow(2.0))
		draw_style_box(UiKit.flat(Color(0.15, 0.12, 0.22), 10, col, bw, 0), r)
		if frame_id == "royal":
			draw_rect(Rect2(r.position + Vector2(8, 0), Vector2(r.size.x - 16, 4)), col)
			draw_rect(Rect2(Vector2(r.position.x + 8, r.end.y - 4), Vector2(r.size.x - 16, 4)), col)
		var art := Rect2(r.position + Vector2(6, 6), Vector2(r.size.x - 12, r.size.y * 0.42))
		draw_style_box(UiKit.flat(Color(0.26, 0.22, 0.38), 6), art)
		for i in 3:
			var y := art.end.y + 12.0 + i * 10.0
			draw_line(Vector2(r.position.x + 12, y), Vector2(r.end.x - 12 - i * 8, y), Color(1, 1, 1, 0.18), 2.0)
		draw_circle(Vector2(r.end.x - 12, r.position.y + 12), 7.0, Color(col, 0.9))

## Efeito do golpe: uma explosão na cor do efeito (o «Clássico» em dourado).
class EffectPreview extends Control:
	var effect_id := "classic"

	func _init() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _draw() -> void:
		var f := CardDB.get_cosmetic("effect", effect_id)
		var hex := String(f.get("color", ""))
		var col := Color(1.0, 0.82, 0.4) if hex == "" else Color(hex)
		var c := size * 0.5
		var r := minf(size.x, size.y) * 0.5 - 4.0
		draw_circle(c, r, Color(0.08, 0.06, 0.13))
		draw_texture_rect(MenuBackdrop.glow_texture(), Rect2(c - Vector2(r, r), Vector2(r, r) * 2.0), false, Color(col, 0.55))
		var rays := PackedVector2Array()
		for i in 12:
			var a := TAU * i / 12.0 + 0.2
			var len := r * (0.92 if i % 2 == 0 else 0.62)
			rays.append(c + Vector2(cos(a), sin(a)) * r * 0.2)
			rays.append(c + Vector2(cos(a), sin(a)) * len)
		draw_multiline(rays, Color(col.lightened(0.3), 0.9), 2.0, true)
		draw_circle(c, r * 0.18, Color(1, 1, 1, 0.9))
		draw_arc(c, r - 1.0, 0.0, TAU, 40, Color(col, 0.6), 2.0, true)
