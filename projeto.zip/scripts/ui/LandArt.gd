class_name LandArt
extends Control
## Paisagem dos Terrenos, desenhada em código (0.11.0): uma "janela" na parte de baixo da carta com o
## terreno da cor — branco: planície com sol · azul: ilha no mar · preto: pântano com lua e árvores
## secas · vermelho: montanhas e vulcão · verde: floresta de pinheiros · incolor: ermo com pedras.
## Terrenos de várias cores dividem a janela (à esquerda a 1.ª cor, à direita a 2.ª). Serve para se
## ver logo que a carta é um Terreno (as outras cartas têm o sigilo). Não reage a toques.

var colors: Array = []:
	set(v):
		colors = v
		queue_redraw()
## Tinta (cor e alfa) com que se desenha: escura nas cartas claras, clara nas escuras.
var ink: Color = Color(0, 0, 0, 0.3):
	set(v):
		ink = v
		queue_redraw()
## Id da carta: pequenas variações (número de árvores, altura dos picos) sempre iguais na mesma carta.
var card_id: String = "":
	set(v):
		card_id = v
		queue_redraw()
## Janela em frações do tamanho do controlo (x, y, largura, altura).
var window := Rect2(0.06, 0.6, 0.88, 0.31):
	set(v):
		window = v
		queue_redraw()

const MOTIFS := ["white", "blue", "black", "red", "green"]

var _rng := RandomNumberGenerator.new()

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	if size.x < 20.0 or size.y < 20.0:
		return
	var r := Rect2(size * window.position, size * window.size)
	_rng.seed = hash(card_id)
	# Céu: um retângulo arredondado suave, para a paisagem ter uma moldura.
	var sky := StyleBoxFlat.new()
	sky.bg_color = Color(ink, ink.a * 0.32)
	sky.set_corner_radius_all(int(maxf(4.0, r.size.y * 0.12)))
	draw_style_box(sky, r)
	var motifs: Array = []
	for c in colors:
		if String(c) in MOTIFS and not (String(c) in motifs):
			motifs.append(String(c))
	if motifs.is_empty():
		motifs = ["colorless"]
	var n := mini(motifs.size(), 2)
	var w := r.size.x / float(n)
	for i in n:
		var part := Rect2(r.position + Vector2(w * i, 0), Vector2(w, r.size.y)).grow(-maxf(2.0, r.size.y * 0.06))
		_draw_motif(String(motifs[i]), part)
	# Chão comum a toda a janela.
	var ground_y := r.end.y - r.size.y * 0.1
	draw_line(Vector2(r.position.x + 4, ground_y), Vector2(r.end.x - 4, ground_y), Color(ink, ink.a * 0.9), maxf(1.0, r.size.y * 0.025), true)

func _fill(points: PackedVector2Array, alpha_mul: float = 1.0) -> void:
	if points.size() >= 3:
		draw_colored_polygon(points, Color(ink, minf(1.0, ink.a * alpha_mul)))

func _stroke(points: PackedVector2Array, width: float, alpha_mul: float = 1.0) -> void:
	if points.size() >= 2:
		draw_polyline(points, Color(ink, minf(1.0, ink.a * alpha_mul)), width, true)

func _draw_motif(kind: String, r: Rect2) -> void:
	var h := r.size.y
	var w := r.size.x
	var base := r.end.y - h * 0.08
	var lw := maxf(1.0, h * 0.035)
	match kind:
		"white":
			# Planície: sol com raios e colinas suaves com espigas.
			var sun := r.position + Vector2(w * 0.28, h * 0.32)
			var sr := h * 0.14
			draw_circle(sun, sr, Color(ink, ink.a * 1.1))
			for k in 8:
				var a := TAU * k / 8.0
				draw_line(sun + Vector2(cos(a), sin(a)) * sr * 1.35, sun + Vector2(cos(a), sin(a)) * sr * 1.9, Color(ink, ink.a), lw, true)
			for layer in 2:
				var pts := PackedVector2Array()
				var amp := h * (0.12 if layer == 0 else 0.08)
				var y0 := base - h * (0.22 if layer == 0 else 0.08)
				var ph := _rng.randf() * TAU
				pts.append(Vector2(r.position.x, base))
				for k in 17:
					var t := float(k) / 16.0
					pts.append(Vector2(r.position.x + w * t, y0 - sin(t * PI * 1.6 + ph) * amp))
				pts.append(Vector2(r.end.x, base))
				_fill(pts, 0.7 if layer == 0 else 1.0)
			for k in 4:
				var x := r.position.x + w * (0.55 + 0.1 * k)
				draw_line(Vector2(x, base - h * 0.05), Vector2(x + h * 0.03, base - h * 0.2), Color(ink, ink.a * 1.2), lw * 0.8, true)
		"blue":
			# Ilha: monte no meio do mar, ondas e uma gaivota.
			var cx := r.position.x + w * (0.45 + _rng.randf() * 0.1)
			var hump := PackedVector2Array()
			for k in 17:
				var t := float(k) / 16.0
				hump.append(Vector2(cx - w * 0.28 + w * 0.56 * t, base - h * 0.18 - sin(t * PI) * h * 0.32))
			hump.append(Vector2(cx + w * 0.28, base - h * 0.18))
			hump.append(Vector2(cx - w * 0.28, base - h * 0.18))
			_fill(hump, 1.1)
			for row in 3:
				var pts := PackedVector2Array()
				var y := base - h * 0.16 + row * h * 0.08
				for k in 25:
					var t := float(k) / 24.0
					pts.append(Vector2(r.position.x + w * t, y + sin(t * TAU * 3.0 + row) * h * 0.025))
				_stroke(pts, lw, 1.0 - row * 0.2)
			var gx := r.position.x + w * 0.2
			var gy := r.position.y + h * 0.25
			_stroke(PackedVector2Array([Vector2(gx - h * 0.08, gy), Vector2(gx, gy + h * 0.05), Vector2(gx + h * 0.08, gy)]), lw)
		"black":
			# Pântano: lua em quarto, árvores secas e água parada.
			var moon := r.position + Vector2(w * 0.74, h * 0.28)
			var mr := h * 0.13
			var crescent := PackedVector2Array()
			for k in 13:
				var a := -PI / 2.0 + PI * k / 12.0
				crescent.append(moon + Vector2(cos(a), sin(a)) * mr)
			for k in 13:
				var a := PI / 2.0 - PI * k / 12.0
				crescent.append(moon + Vector2(cos(a) * 0.45, sin(a)) * mr)
			_fill(crescent, 1.2)
			for tree in 2:
				var tx := r.position.x + w * (0.22 + tree * 0.3 + _rng.randf() * 0.06)
				var th := h * (0.48 + _rng.randf() * 0.15)
				var top := Vector2(tx, base - th)
				draw_line(Vector2(tx, base), top, Color(ink, ink.a * 1.2), lw * 1.6, true)
				draw_line(top + Vector2(0, th * 0.3), top + Vector2(-th * 0.25, th * 0.12), Color(ink, ink.a * 1.1), lw, true)
				draw_line(top + Vector2(0, th * 0.45), top + Vector2(th * 0.22, th * 0.28), Color(ink, ink.a * 1.1), lw, true)
				draw_line(top, top + Vector2(th * 0.1, -th * 0.08), Color(ink, ink.a * 1.1), lw * 0.8, true)
			for k in 3:
				var y := base - h * 0.04 - k * h * 0.06
				var x := r.position.x + w * (0.1 + 0.25 * k)
				draw_line(Vector2(x, y), Vector2(x + w * 0.22, y), Color(ink, ink.a * 0.8), lw * 0.8, true)
		"red":
			# Montanhas: três picos recortados e um vulcão a fumegar.
			var peaks := PackedVector2Array([Vector2(r.position.x, base)])
			var xs := [0.0, 0.2, 0.35, 0.5, 0.68, 0.85, 1.0]
			var ys := [0.15, 0.6, 0.35, 0.78 + _rng.randf() * 0.1, 0.4, 0.62, 0.2]
			for k in xs.size():
				peaks.append(Vector2(r.position.x + w * float(xs[k]), base - h * float(ys[k])))
			peaks.append(Vector2(r.end.x, base))
			_fill(peaks, 1.0)
			var crater := Vector2(r.position.x + w * 0.5, base - h * 0.84)
			for k in 3:
				draw_circle(crater + Vector2(h * 0.06 * k, -h * (0.08 + 0.07 * k)), h * (0.04 + 0.015 * k), Color(ink, ink.a * (0.9 - 0.2 * k)))
		"green":
			# Floresta: pinheiros de várias alturas.
			var count := 4 + _rng.randi_range(0, 1)
			for k in count:
				var tx := r.position.x + w * (0.1 + 0.8 * float(k) / float(count - 1))
				var th := h * (0.45 + _rng.randf() * 0.35)
				var tw := th * 0.42
				for layer in 3:
					var ly := base - th * (0.18 + 0.27 * layer)
					var lw2 := tw * (1.0 - 0.25 * layer)
					_fill(PackedVector2Array([Vector2(tx - lw2 / 2.0, ly), Vector2(tx + lw2 / 2.0, ly), Vector2(tx, ly - th * 0.38)]), 1.1)
				draw_line(Vector2(tx, base), Vector2(tx, base - th * 0.18), Color(ink, ink.a * 1.2), lw * 1.4, true)
		_:
			# Ermo incolor: pedras e um monólito.
			var mx := r.position.x + w * 0.62
			_fill(PackedVector2Array([Vector2(mx - h * 0.09, base), Vector2(mx - h * 0.07, base - h * 0.62), Vector2(mx + h * 0.07, base - h * 0.66), Vector2(mx + h * 0.09, base)]), 1.1)
			for k in 3:
				var c := Vector2(r.position.x + w * (0.15 + 0.15 * k), base - h * 0.06)
				draw_circle(c, h * (0.08 - 0.015 * k), Color(ink, ink.a))
