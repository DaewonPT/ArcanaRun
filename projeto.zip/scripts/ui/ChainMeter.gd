class_name ChainMeter
extends Control
## Medidor da Cadeia de cor: uma corrente com um elo por lugar na Arena; os elos acendem na cor da maior
## sequência de criaturas seguidas da mesma cor. A marca dourada por baixo diz onde começa o ×1.5 (3; 2 com o
## Elo da Cadeia); a Arena inteira dá ×2.
## 0.16.0 («Elos», a escolha do AlizeOnMe): antes eram quadradinhos soltos. Ao chegar ao mínimo a corrente fecha
## (os elos ficam mais claros) e aparece o Mult numa pastilha vermelha; antes disso, quantas faltam.
## Desenhado só quando muda (set_chain), com caixas de estilo (um comando cada).

const LINK := Vector2(24, 16)     # elo visto de frente
const PITCH := 19.0               # distância entre elos (encaixam uns nos outros)
const PAD := 9.0
const EMPTY := Color(0.24, 0.21, 0.33)
const MULT_RED := Color(0.95, 0.23, 0.33)

var length: int = 0
var color_name: String = ""
var needed: int = 3
var slots: int = 5
var _label: String = ""

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(_chain_w(5) + 2.0 * PAD + 64.0, 30)

static func _chain_w(n: int) -> float:
	return (n - 1) * PITCH + LINK.x

func set_chain(p_length: int, p_color: String, p_needed: int, p_slots: int = 5) -> void:
	length = p_length
	color_name = p_color
	needed = p_needed
	slots = maxi(p_slots, 1)
	var m := EffectResolver.chain_mult(length)
	_label = ("×" + Cascade.fmt_mult(m)) if m > 1.0 else ""
	custom_minimum_size = Vector2(_chain_w(slots) + 2.0 * PAD + 64.0, 30)
	queue_redraw()

func _ring(r: Rect2, border: int, radius: int, col: Color, glow: bool) -> void:
	var st := StyleBoxFlat.new()
	st.draw_center = false
	st.set_border_width_all(border)
	st.set_corner_radius_all(radius)
	st.border_color = col
	st.anti_aliasing = true
	if glow:
		st.shadow_color = Color(col, 0.45)
		st.shadow_size = 5
	draw_style_box(st, r)

func _draw() -> void:
	var font := get_theme_default_font()
	var col: Color = CardView.COLORS.get(color_name, CardView.COLORS.colorless)
	var closed := length >= needed
	var lit_col := col.lightened(0.22) if closed else col
	var cw := _chain_w(slots)
	var label_w := 0.0
	var label_txt := _label
	if label_txt == "" and length > 0:
		label_txt = tr("faltam %d") % maxi(1, needed - length)
	if label_txt != "" and font != null:
		label_w = font.get_string_size(label_txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 15).x + 16.0
	var total := cw + 2.0 * PAD + (label_w + 8.0 if label_w > 0.0 else 0.0)
	var x0 := (size.x - total) * 0.5
	# Fundo próprio (a faixa dos feitiços fica transparente quando está vazia).
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.08, 0.06, 0.13, 0.8)
	bg.set_corner_radius_all(11)
	bg.set_border_width_all(1)
	bg.border_color = Color(1, 1, 1, 0.08)
	draw_style_box(bg, Rect2(Vector2(x0, 0.0), Vector2(total, size.y)))
	var cy := size.y * 0.5 - 1.0
	var lx := x0 + PAD
	# Elos de frente.
	for i in slots:
		var r := Rect2(Vector2(lx + i * PITCH, cy - LINK.y * 0.5), LINK)
		var on := i < length
		_ring(r, 4, 8, lit_col if on else EMPTY, on)
	# Elos de lado (passam por dentro dos dois vizinhos).
	for i in slots - 1:
		var jx := lx + i * PITCH + LINK.x - (LINK.x - PITCH) * 0.5 - 1.5
		var r := Rect2(Vector2(jx - 4.5, cy - 6.5), Vector2(9.0, 13.0))
		var on := i + 1 < length
		_ring(r, 3, 4, lit_col.lightened(0.1) if on else EMPTY.lightened(0.08), false)
	# Marca do mínimo da Cadeia (por baixo do último elo que é preciso).
	if needed >= 1 and needed <= slots:
		var tx := lx + (needed - 1) * PITCH + LINK.x * 0.5
		draw_rect(Rect2(Vector2(tx - 1.0, cy + LINK.y * 0.5 + 1.0), Vector2(2.0, 4.0)), Color(1.0, 0.85, 0.45, 0.9))
	# O Mult da Cadeia (ou quantas faltam).
	if label_w > 0.0 and font != null:
		var pr := Rect2(Vector2(lx + cw + PAD + 8.0 - PAD, cy - 11.0), Vector2(label_w, 22.0))
		var ps := StyleBoxFlat.new()
		ps.set_corner_radius_all(8)
		ps.bg_color = MULT_RED if _label != "" else Color(0.29, 0.23, 0.33)
		if _label != "":
			ps.shadow_color = Color(MULT_RED, 0.5)
			ps.shadow_size = 6
		draw_style_box(ps, pr)
		var tcol := Color.WHITE if _label != "" else Color(0.75, 0.7, 0.82)
		draw_string(font, Vector2(pr.position.x + 8.0, pr.position.y + 16.0), label_txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 15, tcol)
