class_name ChainMeter
extends Control
## Medidor da Cadeia de cor: um segmento por lugar na Arena, pintado com a cor da maior sequência de
## criaturas seguidas da mesma cor. A marca indica onde começa o ×1.5 (3; 2 com o Elo da Cadeia);
## a Arena inteira dá ×2.

const SEG := Vector2(22, 9)
const GAP := 5.0
const EMPTY := Color(0.24, 0.21, 0.33)

var length: int = 0
var color_name: String = ""
var needed: int = 3
var slots: int = 5
var _label: String = ""

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(5 * (SEG.x + GAP) + 64, 18)

func set_chain(p_length: int, p_color: String, p_needed: int, p_slots: int = 5) -> void:
	length = p_length
	color_name = p_color
	needed = p_needed
	slots = maxi(p_slots, 1)
	var m := EffectResolver.chain_mult(length)
	_label = ("×" + Cascade.fmt_mult(m)) if m > 1.0 else ""
	queue_redraw()

func _draw() -> void:
	var font := get_theme_default_font()
	var col: Color = CardView.COLORS.get(color_name, CardView.COLORS.colorless)
	var w := slots * (SEG.x + GAP) - GAP
	var x0 := (size.x - w - 60.0) / 2.0
	var y := (size.y - SEG.y) / 2.0
	for i in slots:
		var r := Rect2(Vector2(x0 + i * (SEG.x + GAP), y), SEG)
		var on := i < length
		draw_rect(r, col if on else EMPTY, true)
		if on and length >= needed:
			draw_rect(r.grow(1.0), Color(1, 0.92, 0.6, 0.55), false, 1.0)
	# Marca do fim do mínimo da Cadeia (a partir dali já conta).
	var tx := x0 + needed * (SEG.x + GAP) - GAP * 0.5
	draw_line(Vector2(tx, y - 4.0), Vector2(tx, y + SEG.y + 4.0), Color(1, 0.92, 0.6, 0.7), 2.0)
	if _label != "" and font != null:
		draw_string(font, Vector2(x0 + w + 8.0, y + SEG.y + 1.0), _label, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(0.72, 0.35, 0.95).lightened(0.3))
