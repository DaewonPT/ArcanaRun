class_name Jukebox
extends RefCounted
## 0.19.0 (274): a jukebox — ouvir as faixas do jogo e escolher a música do menu (Configurações → Som).
## A escolha guarda-se em Settings.opt("menu_track") ("" = a de sempre).

const NAMES := {"menu": "Menu", "act1": "Ato I", "act2": "Ato II", "act3": "Ato III", "act4": "Ato IV", "endless": "Infinito",
	"boss": "Boss", "guild_wu": "Livro II · Azul e Branco", "guild_ub": "Livro II · Negro e Azul", "guild_br": "Livro II · Vermelho e Negro",
	"guild_rg": "Livro II · Verde e Vermelho", "guild_gw": "Livro II · Branco e Verde", "guild_wb": "Livro II · Branco e Negro",
	"guild_ur": "Livro II · Azul e Vermelho", "guild_bg": "Livro II · Negro e Verde", "guild_rw": "Livro II · Vermelho e Branco",
	"guild_gu": "Livro II · Verde e Azul"}

static func tracks() -> Array[String]:
	var out: Array[String] = []
	for t in Music.TRACK_BPM:
		if Music.has_track(String(t)):
			out.append(String(t))
	return out

static func track_name(t: String) -> String:
	return TranslationServer.translate(String(NAMES.get(t, t)))

static func open() -> Control:
	var t := func(x: String) -> String: return TranslationServer.translate(x)
	var before := Music.current
	var o := Control.new()
	o.name = "Jukebox"
	o.set_anchors_preset(Control.PRESET_FULL_RECT)
	o.mouse_filter = Control.MOUSE_FILTER_STOP
	o.add_child(UiKit.dim(0.82))
	SceneRouter.show_overlay(o)
	var close := func():
		Music.play(before)
		UiKit.close_animated(o)
	var body := UiKit.window(o, 760, t.call("JUKEBOX"), UiKit.GOLD, close, t.call("Ouve as faixas e escolhe a do menu"))
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.custom_minimum_size = Vector2(0, 360)
	body.add_child(scroll)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 6)
	scroll.add_child(list)
	var rows: Array = []
	var refresh := func():
		for r in rows:
			var tr_id := String((r as Control).get_meta("track"))
			var pick := (r as Control).get_node("Pick") as Button
			var mine := String(Settings.opt("menu_track")) == tr_id or (String(Settings.opt("menu_track")) == "" and tr_id == "menu")
			pick.text = t.call("NO MENU ✓") if mine else t.call("PÔR NO MENU")
			pick.disabled = mine
	for track in tracks():
		var row := HBoxContainer.new()
		row.name = "Track_" + track
		row.set_meta("track", track)
		row.add_theme_constant_override("separation", 10)
		list.add_child(row)
		rows.append(row)
		var play := UiKit.button("▶", 48, 18)
		play.name = "Play"
		play.custom_minimum_size.x = 64
		var tk := track
		play.pressed.connect(func(): Music.play(tk))
		row.add_child(play)
		var l := UiKit.label(track_name(track), 18, Color.WHITE)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(l)
		var pick := UiKit.button("", 48, 16)
		pick.name = "Pick"
		pick.custom_minimum_size.x = 190
		pick.pressed.connect(func():
			Sfx.select()
			Settings.set_opt("menu_track", "" if tk == "menu" else tk)
			refresh.call())
		row.add_child(pick)
	refresh.call()
	var done := UiKit.button(t.call("FECHAR"), 52, 20, UiKit.PRIMARY)
	done.pressed.connect(close)
	body.add_child(done)
	UiKit.pop_in(body.get_meta("panel"))
	return o
