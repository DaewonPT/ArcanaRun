class_name ScrollFling
extends Node
## 0.19.0 (21): listas com inércia também com o rato (computador, Chromebook, tablet com rato). No telemóvel o
## Godot já desliza as listas com o dedo e trava-as devagar; aqui, arrastar com o rato numa parte vazia da lista
## desliza-a e, ao largar, ela continua e trava devagar. O SceneRouter põe um em cada lista quando não há ecrã tátil.

const DECEL := 2400.0      # px/s² de travagem
const MIN_SPEED := 40.0    # abaixo disto pára
const SAMPLE_MS := 110     # a velocidade conta com os últimos 110 ms do arrasto

var _scroll: ScrollContainer
var _drag := false
var _from := Vector2.ZERO
var _start := Vector2.ZERO
var _speed := Vector2.ZERO
var _samples: Array = []   # [ms, Vector2 posição da lista]

static func attach(sc) -> void:
	if not is_instance_valid(sc) or not (sc is ScrollContainer) or sc.has_node("ScrollFling") or sc.has_meta("keep_child_input"):
		return
	var f := ScrollFling.new()
	f.name = "ScrollFling"
	f._scroll = sc
	sc.add_child(f)
	(sc as ScrollContainer).gui_input.connect(f._on_input)

func _ready() -> void:
	set_process(false)

func _pos() -> Vector2:
	return Vector2(_scroll.scroll_horizontal, _scroll.scroll_vertical)

func _on_input(ev: InputEvent) -> void:
	if ev is InputEventMouseButton and (ev as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
		var mb := ev as InputEventMouseButton
		if mb.device == InputEvent.DEVICE_ID_EMULATION:
			return   # o dedo: o próprio Godot trata disto
		if mb.pressed:
			_drag = true
			_speed = Vector2.ZERO
			set_process(false)
			_from = mb.global_position
			_start = _pos()
			_samples = [[Time.get_ticks_msec(), _start]]
		elif _drag:
			_drag = false
			_speed = _release_speed()
			set_process(_speed.length() > MIN_SPEED)
	elif ev is InputEventMouseMotion and _drag:
		var d := (ev as InputEventMouseMotion).global_position - _from
		if _scroll.vertical_scroll_mode != ScrollContainer.SCROLL_MODE_DISABLED:
			_scroll.scroll_vertical = int(_start.y - d.y)
		if _scroll.horizontal_scroll_mode != ScrollContainer.SCROLL_MODE_DISABLED:
			_scroll.scroll_horizontal = int(_start.x - d.x)
		var now := Time.get_ticks_msec()
		_samples.append([now, _pos()])
		while _samples.size() > 2 and now - int(_samples[0][0]) > SAMPLE_MS:
			_samples.pop_front()

func _release_speed() -> Vector2:
	if _samples.size() < 2:
		return Vector2.ZERO
	var a: Array = _samples[0]
	var b: Array = _samples[_samples.size() - 1]
	var dt := float(int(b[0]) - int(a[0])) / 1000.0
	if dt <= 0.0 or Time.get_ticks_msec() - int(b[0]) > 80:
		return Vector2.ZERO   # parou antes de largar
	return (Vector2(b[1]) - Vector2(a[1])) / dt

func _process(delta: float) -> void:
	if not is_instance_valid(_scroll) or _drag:
		set_process(false)
		return
	var before := _pos()
	_scroll.scroll_vertical = int(before.y + _speed.y * delta)
	_scroll.scroll_horizontal = int(before.x + _speed.x * delta)
	if _pos() == before:
		set_process(false)   # chegou ao fim da lista
		return
	_speed = _speed.move_toward(Vector2.ZERO, DECEL * delta)
	if _speed.length() < MIN_SPEED:
		set_process(false)
