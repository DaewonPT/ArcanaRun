class_name ArtViewer
extends Control
## 0.16.1 (53): «SÓ A ARTE» — a ilustração sozinha, o maior possível no ecrã, com o nome por baixo.
## Abre-se na carta em grande e na Galeria da Coleção; tocar (ou «retroceder») fecha.

var _art: Texture2D
var _title := ""
var _sub := ""
var _frame: Control

## Mostra a imagem por cima de tudo (null = não faz nada). Devolve o painel (para os testes).
static func open(tex: Texture2D, title: String = "", subtitle: String = "") -> ArtViewer:
	if tex == null:
		return null
	var v := ArtViewer.new()
	v._art = tex
	v._title = title
	v._sub = subtitle
	SceneRouter.show_overlay(v)
	return v

func _init() -> void:
	name = "ArtViewer"
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP

func _ready() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.015, 0.04, 0.94)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(dim)
	_frame = Control.new()
	_frame.name = "Art"
	_frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_frame.set_anchors_preset(Control.PRESET_FULL_RECT)
	_frame.draw.connect(_draw_art)
	add_child(_frame)
	resized.connect(_frame.queue_redraw)
	if Settings.motion_ok():
		_frame.modulate.a = 0.0
		create_tween().tween_property(_frame, "modulate:a", 1.0, 0.18)

## A imagem inteira (sem cortes), centrada, com cantos redondos e um aro fino; o nome e a dica por baixo.
func _draw_art() -> void:
	var s := size
	var ts := _art.get_size()
	if ts.x <= 0.0 or ts.y <= 0.0 or s.x < 10.0:
		return
	var max_w := s.x * 0.9
	var max_h := s.y - 150.0
	var k := minf(max_w / ts.x, max_h / ts.y)
	var w := ts.x * k
	var h := ts.y * k
	var r := Rect2(Vector2((s.x - w) * 0.5, maxf(24.0, (s.y - h - 92.0) * 0.5)), Vector2(w, h))
	_frame.draw_texture_rect(MenuBackdrop.glow_texture(), r.grow(60.0), false, Color(0.55, 0.42, 0.95, 0.16))
	ArtLib.draw_rounded(_frame, _art, r, 16.0, 0.5)
	var pts := ArtLib.rounded_rect_points(r, 16.0, 5)
	pts.append(pts[0])
	_frame.draw_polyline(pts, Color(UiKit.GOLD, 0.7), 2.0, true)
	var font := get_theme_default_font()
	var y := r.end.y + 34.0
	if _title != "":
		var tf: Font = load("res://assets/fonts/Lora-Bold.ttf")
		var tw := tf.get_string_size(_title, HORIZONTAL_ALIGNMENT_LEFT, -1, 26).x
		_frame.draw_string(tf, Vector2((s.x - tw) * 0.5, y), _title, HORIZONTAL_ALIGNMENT_LEFT, -1, 26, UiKit.GOLD)
		y += 26.0
	if _sub != "":
		var sw := font.get_string_size(_sub, HORIZONTAL_ALIGNMENT_LEFT, -1, 16).x
		_frame.draw_string(font, Vector2((s.x - sw) * 0.5, y), _sub, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, UiKit.TEXT_DIM)
		y += 22.0
	var hint := tr("Toca para fechar")
	var hw := font.get_string_size(hint, HORIZONTAL_ALIGNMENT_LEFT, -1, 14).x
	_frame.draw_string(font, Vector2((s.x - hw) * 0.5, minf(y + 4.0, s.y - 40.0)), hint, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(UiKit.TEXT_DIM, 0.7))

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and not event.pressed:
		accept_event()
		close()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and is_inside_tree() and SceneRouter.top_overlay() == self:
		close()

func close() -> void:
	if is_queued_for_deletion() or has_meta("closing"):
		return
	Sfx.select()
	set_meta("closing", true)
	queue_free()
