class_name UiKit
extends RefCounted
## Widgets com o aspeto do jogo, para os painéis construídos em código (pausa, configurações, zoom…).
## 0.10.0 (menos molduras): um só estilo de botão (cantos de 12, sem contorno por omissão; o mesmo do
## tema), três tamanhos de texto (TEXT_SMALL / TEXT_BODY / TEXT_TITLE) e mais espaço entre blocos.

const BG := Color(0.13, 0.11, 0.19)
const BG_LIGHT := Color(0.17, 0.14, 0.25)
const BORDER := Color(0.35, 0.3, 0.5)
const PRIMARY := Color(0.85, 0.55, 0.15)
const DANGER := Color(0.62, 0.2, 0.24)
const GOLD := Color(0.98, 0.75, 0.25)
const TEXT_DIM := Color(0.7, 0.7, 0.8)
const BTN_BG := Color(0.19, 0.16, 0.28)
const TEXT_SMALL := 16
const HC_BORDER := Color(0.92, 0.9, 1.0, 0.85)
const HC_DIM := Color(0.9, 0.9, 0.96)

## 0.12.0 (alto contraste): os textos apagados ficam quase brancos; o resto fica igual.
static func contrast_color(c: Color) -> Color:
	if Settings.high_contrast and c.is_equal_approx(TEXT_DIM):
		return HC_DIM
	return c

## Contorno que contrasta com a cor do texto (escuro num texto claro e vice-versa).
static func outline_for(l: Control, text_color: Color, px: int) -> void:
	l.add_theme_constant_override("outline_size", px)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.92) if text_color.get_luminance() >= 0.45 else Color(1, 1, 1, 0.85))
const TEXT_BODY := 20
const TEXT_TITLE := 28
const GAP := 12

static func flat(bg: Color, radius: int = 12, border: Color = Color(0, 0, 0, 0), border_w: int = 0, margin: int = 10) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.set_corner_radius_all(radius)
	s.set_content_margin_all(margin)
	if border_w > 0:
		s.set_border_width_all(border_w)
		s.border_color = border
	return s

static func button(text: String, height: int = 60, font_size: int = 24, bg: Color = BTN_BG, border: Color = Color(0, 0, 0, 0)) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, height)
	b.add_theme_font_size_override("font_size", font_size)
	if Settings.high_contrast and border.a <= 0.0:
		border = HC_BORDER   # 0.12.0: alto contraste — todos os botões com contorno claro
	var normal := flat(bg, 12, border, 2 if border.a > 0 else 0, 10)
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", flat(bg.lightened(0.06), 12, border, 2 if border.a > 0 else 0, 10))
	b.add_theme_stylebox_override("pressed", flat(bg.lightened(0.15), 12, border, 2 if border.a > 0 else 0, 10))
	b.add_theme_stylebox_override("disabled", flat(bg.darkened(0.35), 12, Color(0, 0, 0, 0), 0, 10))
	b.focus_mode = Control.FOCUS_NONE
	return b

## Botão com texto em várias linhas. O Godot 4.3 calcula mal a altura de um Button com autowrap quando a
## lista é refeita (a 1.ª linha da campanha ficava gigante ao trocar de livro): o texto vai num Label por
## dentro, ancorado ao botão, que não mexe no tamanho mínimo do botão. Ler/mudar o texto com
## wrap_text()/set_wrap_text(); desativado, o texto fica mais apagado.
static func wrap_button(text: String, height: int = 66, font_size: int = 18, bg: Color = BTN_BG, border: Color = Color(0, 0, 0, 0), color: Color = Color.WHITE) -> Button:
	var b := button("", height, font_size, bg, border)
	b.clip_contents = true
	var l := Label.new()
	l.name = "WrapLabel"
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.set_anchors_preset(Control.PRESET_FULL_RECT)
	l.offset_left = 14
	l.offset_right = -14
	l.offset_top = 4
	l.offset_bottom = -4
	b.add_child(l)
	b.set_meta("wrap_label", l)
	b.draw.connect(func(): l.modulate.a = 0.45 if b.disabled else 1.0)
	return b

static func wrap_label(b: Button) -> Label:
	return b.get_meta("wrap_label", null) as Label if b.has_meta("wrap_label") else null

static func wrap_text(b: Button) -> String:
	var l := wrap_label(b)
	return l.text if l != null else b.text

static func set_wrap_text(b: Button, text: String) -> void:
	var l := wrap_label(b)
	if l != null:
		l.text = text
	else:
		b.text = text

## Tira os filhos de um contentor já (remove_child) antes de os libertar: com só queue_free ainda ficam
## no contentor até ao fim do frame e baralham a arrumação dos novos.
static func clear_children(node: Node) -> void:
	for c in node.get_children():
		node.remove_child(c)
		c.queue_free()

static func label(text: String, font_size: int = 20, color: Color = Color.WHITE, autowrap: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", contrast_color(color))
	if Settings.high_contrast:
		outline_for(l, contrast_color(color), 3 if font_size < 26 else 5)
	if autowrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	if font_size >= 26:
		l.theme_type_variation = &"TitleLabel"   # títulos em Lora Bold (assets/theme.tres)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

## Chip com ícone (CardIcon) e texto; tocar chama on_tap (se não houver um overlay aberto).
## O Label fica em get_meta("label") para se poder mudar o texto depois.
static func info_chip(kind: String, text: String, color: Color, on_tap: Callable, height: int = 46) -> PanelContainer:
	var chip := PanelContainer.new()
	chip.custom_minimum_size = Vector2(0, height)
	chip.mouse_filter = Control.MOUSE_FILTER_STOP
	chip.add_theme_stylebox_override("panel", flat(Color(0.12, 0.1, 0.18), 10, color, 2, 8))
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 6)
	chip.add_child(row)
	var icon := CardIcon.new(kind, color, 22.0)
	icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(icon)
	var l := label(text, 15, color)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.size_flags_vertical = Control.SIZE_FILL
	row.add_child(l)
	chip.set_meta("label", l)
	chip.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed:
			if not SceneRouter.has_overlay():
				Sfx.select()
				on_tap.call())
	return chip

## Fundo escuro semi-transparente que cobre o ecrã (deixa passar os toques para o root).
static func dim(alpha: float = 0.74) -> ColorRect:
	var r := ColorRect.new()
	r.color = Color(0, 0, 0, alpha)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	r.set_anchors_preset(Control.PRESET_FULL_RECT)
	return r

## Painel centrado no ecrã (dentro de um CenterContainer de ecrã inteiro).
static func centered_panel(root: Control, width: float, bg: Color = BG, border: Color = BORDER) -> PanelContainer:
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(width, 0)
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	panel.add_theme_stylebox_override("panel", flat(bg, 18, border, 2, 24))
	center.add_child(panel)
	return panel

## Entrada animada de um painel (escala + alpha), já com a velocidade das configurações.
static func pop_in(panel: Control) -> void:
	panel.modulate.a = 0.0
	await panel.get_tree().process_frame
	if not is_instance_valid(panel) or panel.is_queued_for_deletion():
		return
	panel.pivot_offset = panel.size / 2.0
	panel.scale = Vector2(0.88, 0.88)
	var d := Settings.dur(0.16)
	var tw := panel.create_tween().set_parallel(true)
	tw.tween_property(panel, "modulate:a", 1.0, d)
	tw.tween_property(panel, "scale", Vector2.ONE, d).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
