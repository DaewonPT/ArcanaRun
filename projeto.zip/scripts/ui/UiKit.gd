class_name UiKit
extends RefCounted
## Widgets com o aspeto do jogo, para os painéis construídos em código (pausa, configurações, zoom…).
## 0.10.0 (menos molduras): um só estilo de botão (cantos de 12, sem contorno por omissão; o mesmo do
## tema), três tamanhos de texto (TEXT_SMALL / TEXT_BODY / TEXT_TITLE) e mais espaço entre blocos.

const BG := Color(0.13, 0.11, 0.19)
const BG_LIGHT := Color(0.17, 0.14, 0.25)
const BORDER := Color(0.35, 0.3, 0.5)
const PRIMARY := Color(0.76, 0.48, 0.12)   # 0.19.0 (167): mais escuro, para o texto branco se ler (era 0.85, 0.55, 0.15)
const DANGER := Color(0.62, 0.2, 0.24)
const GOLD := Color(0.98, 0.75, 0.25)
const TEXT_DIM := Color(0.7, 0.7, 0.8)
const BTN_BG := Color(0.19, 0.16, 0.28)
const TEXT_SMALL := 16
const HC_BORDER := Color(0.92, 0.9, 1.0, 0.85)
const HC_DIM := Color(0.9, 0.9, 0.96)

## 0.12.0 (alto contraste): os textos apagados ficam quase brancos; o resto fica igual.
static func contrast_color(c: Color) -> Color:
	if Settings.high_contrast and c.is_equal_approx(TEXT_DIM):
		return HC_DIM
	return c

## Contorno que contrasta com a cor do texto (escuro num texto claro e vice-versa).
static func outline_for(l: Control, text_color: Color, px: int) -> void:
	l.add_theme_constant_override("outline_size", px)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.92) if text_color.get_luminance() >= 0.45 else Color(1, 1, 1, 0.85))
const TEXT_BODY := 20
const TEXT_TITLE := 28
const GAP := 12

## 0.19.0 (7): proteção contra toques duplos — dois toques seguidos (em menos de 0,35 s) em COMPRAR, VENDER ou
## NOVAS OFERTAS contam como um. Nos testes (sem ecrã) só conta quando o teste a liga.
static var tap_guard_on := DisplayServer.get_name() != "headless"
static var _last_taps: Dictionary = {}

static func allow_tap(key: String, ms: int = 350) -> bool:
	if not tap_guard_on:
		return true
	var now := Time.get_ticks_msec()
	if now - int(_last_taps.get(key, -100000)) < ms:
		return false
	_last_taps[key] = now
	return true

## 0.19.0 (25): mão dominante em todo o jogo — com a mão esquerda, as filas de colunas e de botões ficam ao
## contrário (os botões de agir do lado da mão dominante, como na batalha). Pode chamar-se outra vez: só vira
## quando a opção mudou.
static func hand_mirror(box: Node) -> void:
	if box == null:
		return
	var want := Settings.left_handed
	if bool(box.get_meta("hand_mirrored", false)) == want:
		return
	var kids := box.get_children()
	kids.reverse()
	for i in kids.size():
		box.move_child(kids[i], i)
	box.set_meta("hand_mirrored", want)

static func flat(bg: Color, radius: int = 12, border: Color = Color(0, 0, 0, 0), border_w: int = 0, margin: int = 10) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.set_corner_radius_all(radius)
	s.set_content_margin_all(margin)
	if border_w > 0:
		s.set_border_width_all(border_w)
		s.border_color = border
	return s

## 0.19.0 (295): a cor de destaque da interface — dourado (a de sempre), azul, verde ou vermelho. Os botões
## principais (os que usam PRIMARY, também mais claros ou escuros) passam para a cor escolhida.
const ACCENTS := {"gold": Color(0.76, 0.48, 0.12), "blue": Color(0.2, 0.45, 0.82), "green": Color(0.2, 0.56, 0.32), "red": Color(0.72, 0.22, 0.24)}

static func accent() -> Color:
	return ACCENTS.get(String(Settings.opt("accent")), PRIMARY)

static func accented(c: Color) -> Color:
	var a := accent()
	if a == PRIMARY or absf(c.h - PRIMARY.h) > 0.02 or absf(c.s - PRIMARY.s) > 0.12:
		return c
	return Color.from_hsv(a.h, a.s, clampf(a.v * (c.v / PRIMARY.v), 0.0, 1.0), c.a)

static func button(text: String, height: int = 60, font_size: int = 24, bg: Color = BTN_BG, border: Color = Color(0, 0, 0, 0)) -> Button:
	var b := Button.new()
	b.text = calm_caps(text)
	b.custom_minimum_size = Vector2(0, height)
	bg = accented(bg)   # 0.19.0 (295): a cor de destaque escolhida nos botões principais
	b.add_theme_font_size_override("font_size", font_size)
	if Settings.high_contrast and border.a <= 0.0:
		border = HC_BORDER   # 0.12.0: alto contraste — todos os botões com contorno claro
	var normal := flat(bg, 12, border, 2 if border.a > 0 else 0, 10)
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", flat(bg.lightened(0.06), 12, border, 2 if border.a > 0 else 0, 10))
	b.add_theme_stylebox_override("pressed", flat(bg.lightened(0.15), 12, border, 2 if border.a > 0 else 0, 10))
	b.add_theme_stylebox_override("disabled", flat(bg.darkened(0.35), 12, Color(0, 0, 0, 0), 0, 10))
	b.focus_mode = Control.FOCUS_NONE
	return b

## Botão com texto em várias linhas. O Godot 4.3 calcula mal a altura de um Button com autowrap quando a
## lista é refeita (a 1.ª linha da campanha ficava gigante ao trocar de livro): o texto vai num Label por
## dentro, ancorado ao botão, que não mexe no tamanho mínimo do botão. Ler/mudar o texto com
## wrap_text()/set_wrap_text(); desativado, o texto fica mais apagado.
static func wrap_button(text: String, height: int = 66, font_size: int = 18, bg: Color = BTN_BG, border: Color = Color(0, 0, 0, 0), color: Color = Color.WHITE) -> Button:
	var b := button("", height, font_size, bg, border)
	b.clip_contents = true
	var l := Label.new()
	l.name = "WrapLabel"
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.set_anchors_preset(Control.PRESET_FULL_RECT)
	l.offset_left = 14
	l.offset_right = -14
	l.offset_top = 4
	l.offset_bottom = -4
	b.add_child(l)
	b.set_meta("wrap_label", l)
	b.draw.connect(func(): l.modulate.a = 0.45 if b.disabled else 1.0)
	return b

static func wrap_label(b: Button) -> Label:
	return b.get_meta("wrap_label", null) as Label if b.has_meta("wrap_label") else null

static func wrap_text(b: Button) -> String:
	var l := wrap_label(b)
	return l.text if l != null else b.text

static func set_wrap_text(b: Button, text: String) -> void:
	var l := wrap_label(b)
	if l != null:
		l.text = text
	else:
		b.text = text

## Tira os filhos de um contentor já (remove_child) antes de os libertar: com só queue_free ainda ficam
## no contentor até ao fim do frame e baralham a arrumação dos novos.
static func clear_children(node: Node) -> void:
	for c in node.get_children():
		node.remove_child(c)
		c.queue_free()

static func label(text: String, font_size: int = 20, color: Color = Color.WHITE, autowrap: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", contrast_color(color))
	if Settings.high_contrast:
		outline_for(l, contrast_color(color), 3 if font_size < 26 else 5)
	if autowrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	if font_size >= 26:
		l.theme_type_variation = &"TitleLabel"   # títulos em Lora Bold (assets/theme.tres)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

## 0.16.1 (V52): botão de cor com o símbolo da mana (estrela, ondas, lua, raio, folha; losango no incolor),
## para os filtros de cor da Coleção e do Construtor. Ligado = aro dourado e a cor mais viva.
static func mana_button(mana: String, height: int = 44, width: int = 52) -> Button:
	var col: Color = CardView.COLORS.get(mana, CardView.COLORS["colorless"])
	var b := Button.new()
	b.name = "Color_" + mana
	b.toggle_mode = true
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(width, height)
	b.tooltip_text = TranslationServer.translate(String(MANA_NAMES.get(mana, mana)))
	var off := flat(col.darkened(0.12), 12, Color(col.lightened(0.2), 0.5), 1, 4)
	b.add_theme_stylebox_override("normal", off)
	b.add_theme_stylebox_override("hover", flat(col, 12, Color(col.lightened(0.3), 0.7), 1, 4))
	b.add_theme_stylebox_override("pressed", flat(col.lightened(0.12), 12, GOLD, 3, 4))
	b.add_theme_stylebox_override("hover_pressed", flat(col.lightened(0.16), 12, GOLD, 3, 4))
	b.add_theme_stylebox_override("disabled", flat(col.darkened(0.6), 12))
	var icon := CardIcon.new("mana_symbol", col.darkened(0.12), 34.0)
	icon.name = "Symbol"
	icon.mana_color = mana
	icon.set_anchors_preset(Control.PRESET_CENTER)
	icon.offset_left = -17.0
	icon.offset_right = 17.0
	icon.offset_top = -17.0
	icon.offset_bottom = 17.0
	b.add_child(icon)
	# Ligado: o fundo do símbolo acompanha a cor mais viva do botão (a lua do preto recorta-se nela).
	b.toggled.connect(func(on: bool): icon.color = col.lightened(0.12) if on else col.darkened(0.12))
	return b

const MANA_NAMES := {"white": "Branco", "blue": "Azul", "black": "Preto", "red": "Vermelho", "green": "Verde", "colorless": "Incolor"}

## 0.16.1: uma etiqueta (botão em pílula) que liga e desliga — os filtros de tipo do Construtor.
static func chip_button(text: String, height: int = 40) -> Button:
	var b := Button.new()
	b.text = text
	b.toggle_mode = true
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(0, height)
	b.add_theme_font_size_override("font_size", 15)
	var n := flat(Color(1, 1, 1, 0.05), height / 2, Color(1, 1, 1, 0.1), 1, 0)
	var on := flat(Color(0.42, 0.33, 0.68, 0.55), height / 2, Color(0.72, 0.62, 1.0, 0.9), 2, 0)
	for st in [n, on]:
		(st as StyleBoxFlat).content_margin_left = 16
		(st as StyleBoxFlat).content_margin_right = 16
	b.add_theme_stylebox_override("normal", n)
	b.add_theme_stylebox_override("hover", n)
	b.add_theme_stylebox_override("pressed", on)
	b.add_theme_stylebox_override("hover_pressed", on)
	b.add_theme_color_override("font_color", Color(0.86, 0.84, 0.92))
	b.add_theme_color_override("font_pressed_color", Color.WHITE)
	b.add_theme_color_override("font_hover_pressed_color", Color.WHITE)
	return b

## 0.16.1: fila de etiquetas de filtro («Todas 87», «● Comuns 26»…) que se escolhem uma de cada vez.
## items: [[id, texto, cor do ponto (Color(0,0,0,0) = sem ponto)], …]. on_pick(id) ao tocar.
static func chip_row(items: Array, current: String, on_pick: Callable, height: int = 40) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.name = "Chips"
	row.add_theme_constant_override("separation", 8)
	var group := ButtonGroup.new()
	for it in items:
		var id := String(it[0])
		var dot: Color = it[2] if it.size() > 2 and it[2] is Color else Color(0, 0, 0, 0)
		var b := Button.new()
		b.name = "Chip_" + id
		b.text = String(it[1])
		b.toggle_mode = true
		b.button_group = group
		b.focus_mode = Control.FOCUS_NONE
		b.custom_minimum_size = Vector2(0, height)
		b.add_theme_font_size_override("font_size", 15)
		var pad_l := 30 if dot.a > 0.0 else 16
		var n := flat(Color(1, 1, 1, 0.05), height / 2, Color(1, 1, 1, 0.1), 1, 0)
		var on := flat(Color(0.42, 0.33, 0.68, 0.55), height / 2, Color(0.72, 0.62, 1.0, 0.9), 2, 0)
		for st in [n, on]:
			(st as StyleBoxFlat).content_margin_left = pad_l
			(st as StyleBoxFlat).content_margin_right = 16
		b.add_theme_stylebox_override("normal", n)
		b.add_theme_stylebox_override("hover", n)
		b.add_theme_stylebox_override("pressed", on)
		b.add_theme_stylebox_override("hover_pressed", on)
		b.add_theme_color_override("font_color", Color(0.86, 0.84, 0.92))
		b.add_theme_color_override("font_pressed_color", Color.WHITE)
		b.add_theme_color_override("font_hover_pressed_color", Color.WHITE)
		if dot.a > 0.0:
			b.draw.connect(func(): b.draw_circle(Vector2(17, b.size.y * 0.5), 5.0, dot))
		b.button_pressed = id == current
		b.pressed.connect(func():
			Sfx.select()
			b.set_pressed_no_signal(true)   # também quando o toque vem do código (testes)
			on_pick.call(id))
		row.add_child(b)
	return row

## Chip com ícone (CardIcon) e texto; tocar chama on_tap (se não houver um overlay aberto).
## O Label fica em get_meta("label") para se poder mudar o texto depois.
## 0.16.1 (V58): `art` (opcional) mostra a ilustração num círculo em vez do ícone (poções e pergaminhos).
## 0.19.0 (145): o «?» que abre o Como Jogar na página deste ecrã.
static func help_button() -> Button:
	var b := button("?", 48, 22)
	b.name = "HelpBtn"
	b.custom_minimum_size.x = 52
	b.tooltip_text = TranslationServer.translate("Ajuda deste ecrã (Como Jogar)")
	b.pressed.connect(func():
		if not SceneRouter.has_overlay():
			SceneRouter.open_help())
	return b

## 0.19.0 (165): os textos compridos todos em maiúsculas (3 palavras ou mais, 18 letras ou mais) leem-se melhor
## em letra normal: «NÃO LEVAR NADA» fica «Não levar nada». Os curtos (ATACAR, COMPRAR) ficam como estão.
static func calm_caps(t: String) -> String:
	if t != t.to_upper() or t.split(" ", false).size() < 3:
		return t
	var letters := 0
	for ch in t:
		if ch.to_upper() != ch.to_lower():
			letters += 1
	if letters < 18:
		return t
	var low := t.to_lower()
	for i in low.length():
		if low[i].to_upper() != low[i]:
			return low.substr(0, i) + low[i].to_upper() + low.substr(i + 1)
	return low

## 0.19.0 (154): «TEXTO E HUD» → «Texto e HUD» (só a 1.ª letra grande; as siglas ficam).
const ACRONYMS := ["HUD", "FPS", "APK", "PT", "EN", "UI", "MB", "KB", "GB", "OLED", "JPG", "PNG", "ZS1"]

static func sentence(t: String) -> String:
	var words := t.split(" ")
	for i in words.size():
		var w := String(words[i])
		if w in ACRONYMS or w.lstrip("(«\"").rstrip(")».,:;!?\"") in ACRONYMS:
			continue
		w = w.to_lower()
		if i == 0 and w.length() > 0:
			w = w[0].to_upper() + w.substr(1)
		words[i] = w
	return " ".join(words)

## 0.19.0 (121): um botão desligado explica-se — tocar nele mostra porquê. `why` devolve o texto ("" = nada a
## dizer); é chamado na altura do toque, por isso vê sempre o estado de agora.
static func explain(b: BaseButton, why: Callable) -> void:
	b.set_meta("why_fn", why)
	if b.has_meta("why_on"):
		return
	b.set_meta("why_on", true)
	b.gui_input.connect(_explain_input.bind(b))

static func _explain_input(ev: InputEvent, b: BaseButton) -> void:
	if not is_instance_valid(b) or not b.disabled or not (ev is InputEventMouseButton):
		return
	var mb := ev as InputEventMouseButton
	if mb.button_index != MOUSE_BUTTON_LEFT or mb.pressed:
		return
	var t := why_text(b)
	if t != "":
		Sfx.deny()
		SceneRouter.toast(t, 1.8)

## O porquê de um botão desligado (também usado pelos testes).
static func why_text(b: BaseButton) -> String:
	if b == null or not b.has_meta("why_fn"):
		return ""
	var fn: Callable = b.get_meta("why_fn")
	return String(fn.call()) if fn.is_valid() else ""

## «Faltam 3 de ouro.» (ou "" se chega).
static func why_gold(price: int) -> String:
	return TranslationServer.translate("Faltam %d de ouro.") % (price - GameState.gold) if GameState.gold < price else ""

static func info_chip(kind: String, text: String, color: Color, on_tap: Callable, height: int = 46, art: Texture2D = null) -> PanelContainer:
	var chip := PanelContainer.new()
	chip.custom_minimum_size = Vector2(0, height)
	chip.mouse_filter = Control.MOUSE_FILTER_STOP
	chip.add_theme_stylebox_override("panel", flat(Color(0.12, 0.1, 0.18), 10, color, 2, 8))
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 6)
	chip.add_child(row)
	if art != null:
		var med := Control.new()
		med.name = "Art"
		med.custom_minimum_size = Vector2(30, 30)
		med.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		med.mouse_filter = Control.MOUSE_FILTER_IGNORE
		med.draw.connect(func():
			var c := med.size * 0.5
			med.draw_circle(c, 15.0, Color(0.08, 0.06, 0.13))
			ArtLib.draw_round(med, art, c, 13.5)
			med.draw_arc(c, 14.5, 0.0, TAU, 32, color, 1.6, true))
		row.add_child(med)
	else:
		var icon := CardIcon.new(kind, color, 22.0)
		icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		row.add_child(icon)
	var l := label(text, 15, color)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.size_flags_vertical = Control.SIZE_FILL
	row.add_child(l)
	chip.set_meta("label", l)
	chip.gui_input.connect(func(ev: InputEvent):
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not ev.pressed:
			if not SceneRouter.has_overlay():
				Sfx.select()
				on_tap.call())
	return chip

## Fundo escuro semi-transparente que cobre o ecrã (deixa passar os toques para o root).
## 0.16.0 (V45): por trás das janelas a cena fica desfocada (shader blur_dim), menos no modo de desempenho.
const BLUR_SHADER := preload("res://assets/shaders/blur_dim.gdshader")

static func dim(alpha: float = 0.74) -> ColorRect:
	var r := ColorRect.new()
	r.color = Color(0, 0, 0, alpha)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	r.set_anchors_preset(Control.PRESET_FULL_RECT)
	if blur_ok():
		r.color = Color(1, 1, 1, 1)
		var m := ShaderMaterial.new()
		m.shader = BLUR_SHADER
		m.set_shader_parameter("amount", clampf(alpha * 0.82, 0.0, 0.92))
		r.material = m
		r.set_meta("blur", true)
	return r

## O desfocado custa um pouco de GPU em cada frame: fica de fora no modo de desempenho e sem ecrã (testes).
static func blur_ok() -> bool:
	return not Settings.performance_mode and DisplayServer.get_name() != "headless"

## Painel centrado no ecrã (dentro de um CenterContainer de ecrã inteiro).
## 0.16.0 (V44): todas as janelas com a mesma moldura — sombra e cantos dourados como os botões do menu.
static func centered_panel(root: Control, width: float, bg: Color = BG, border: Color = BORDER) -> PanelContainer:
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(width, 0)
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	panel.add_theme_stylebox_override("panel", window_style(bg, border, 24))
	panel.draw.connect(draw_gold_corners.bind(panel))
	if Settings.light_theme() and bg.get_luminance() < 0.3:
		panel.set_meta("light_surface", true)   # 0.19.0 (296): as letras daqui de dentro passam a escuras
	center.add_child(panel)
	return panel

## 296: a cor de uma letra clara posta em pergaminho — a mesma cor, escura.
static func ink_for(c: Color) -> Color:
	if c.get_luminance() <= 0.5:
		return c
	return Color.from_hsv(c.h, minf(1.0, c.s * 1.15), clampf(1.0 - c.v * 0.8, 0.13, 0.4), c.a)

## Estilo das janelas: fundo, contorno e uma sombra que as levanta do ecrã.
## 0.19.0 (296): o pergaminho do tema claro.
const PARCH := Color(0.95, 0.91, 0.82)
const INK := Color(0.16, 0.11, 0.06)

static func window_style(bg: Color, border: Color, margin: int) -> StyleBoxFlat:
	if Settings.light_theme() and bg.get_luminance() < 0.3:
		bg = Color(PARCH, maxf(bg.a, 0.97))
	var s := flat(bg, 18, border, 2, margin)
	s.shadow_color = Color(0, 0, 0, 0.5)
	s.shadow_size = 16
	s.shadow_offset = Vector2(0, 8)
	return s

## Cantoneiras douradas nos quatro cantos de uma janela (desenhadas no próprio painel, por baixo do conteúdo).
static func draw_gold_corners(panel: Control) -> void:
	var w := panel.size.x
	var h := panel.size.y
	if w < 40.0 or h < 40.0:
		return
	var c := Color(PlaqueDeco.GOLD, 0.85)
	var k := 14.0
	var m := 7.0
	for corner in [[Vector2(m, m), Vector2(1, 1)], [Vector2(w - m, m), Vector2(-1, 1)], [Vector2(m, h - m), Vector2(1, -1)], [Vector2(w - m, h - m), Vector2(-1, -1)]]:
		var p: Vector2 = corner[0]
		var d: Vector2 = corner[1]
		panel.draw_polyline(PackedVector2Array([p + Vector2(0, k * d.y), p, p + Vector2(k * d.x, 0)]), c, 2.0, true)

## 0.16.0 (V44): janela com a moldura comum — faixa de título na cor do tipo, cantos dourados, sombra e um ✕
## no canto (on_close; sem ele o ✕ não aparece). Devolve a caixa onde vai o conteúdo; o painel fica em
## get_meta("panel") (para o pop_in e o fecho animado).
static func window(root: Control, width: float, title: String, accent: Color = GOLD, on_close: Callable = Callable(), subtitle: String = "") -> VBoxContainer:
	root.set_meta("menu_text", true)   # 0.19.0 (136): o texto das janelas segue o «Texto dos menus»
	var panel := centered_panel(root, width, BG, accent.darkened(0.25))
	panel.add_theme_stylebox_override("panel", window_style(BG, accent.darkened(0.25), 0))
	var outer := VBoxContainer.new()
	outer.add_theme_constant_override("separation", 0)
	outer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(outer)
	var band := PanelContainer.new()
	band.name = "TitleBand"
	band.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bs := flat(Color(accent.darkened(0.55), 0.95), 0, Color(0, 0, 0, 0), 0, 0)
	bs.corner_radius_top_left = 17
	bs.corner_radius_top_right = 17
	bs.content_margin_left = 24
	bs.content_margin_right = 12 if on_close.is_valid() else 24
	bs.content_margin_top = 10
	bs.content_margin_bottom = 10
	bs.border_width_bottom = 2
	bs.border_color = Color(accent, 0.75)
	band.add_theme_stylebox_override("panel", bs)
	outer.add_child(band)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	band.add_child(row)
	var titles := VBoxContainer.new()
	titles.add_theme_constant_override("separation", 0)
	titles.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	titles.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(titles)
	var tl := label(title, 28, accent.lightened(0.2), true)
	tl.name = "Title"
	titles.add_child(tl)
	if subtitle != "":
		var sl := label(subtitle, 16, TEXT_DIM)
		sl.name = "Subtitle"
		titles.add_child(sl)
	if on_close.is_valid():
		var x := Button.new()
		x.name = "CloseX"
		x.custom_minimum_size = Vector2(48, 48)
		x.focus_mode = Control.FOCUS_NONE
		x.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		x.add_theme_stylebox_override("normal", flat(Color(0, 0, 0, 0.25), 24))
		x.add_theme_stylebox_override("hover", flat(Color(1, 1, 1, 0.08), 24))
		x.add_theme_stylebox_override("pressed", flat(Color(1, 1, 1, 0.16), 24))
		x.tooltip_text = TranslationServer.translate("Fechar")
		var xi := CardIcon.new("x", Color(1, 1, 1, 0.85), 20.0)
		x.add_child(xi)
		xi.set_anchors_preset(Control.PRESET_CENTER)
		xi.offset_left = -10.0
		xi.offset_right = 10.0
		xi.offset_top = -10.0
		xi.offset_bottom = 10.0
		x.pressed.connect(func(): on_close.call())
		row.add_child(x)
	var margin := MarginContainer.new()
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 24 if side != "top" else 16)
	outer.add_child(margin)
	var body := VBoxContainer.new()
	body.add_theme_constant_override("separation", 10)
	body.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(body)
	body.set_meta("panel", panel)
	body.set_meta("title", tl)
	return body

## 0.16.0 (V46): fecha um overlay a encolher e a desvanecer (0,12 s); com movimento reduzido ou sem
## animações sai logo. Enquanto fecha já não conta como aberto (SceneRouter.has_overlay) nem recebe toques.
static func close_animated(node: Control, panel: Control = null) -> void:
	if node == null or not is_instance_valid(node) or node.is_queued_for_deletion() or node.has_meta("closing"):
		return
	node.set_meta("closing", true)
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ignore_input(node)
	var d := Settings.dur(0.12)
	if d <= 0.0 or not Settings.motion_ok() or not node.is_inside_tree() or DisplayServer.get_name() == "headless":
		node.queue_free()
		return
	if panel == null or not is_instance_valid(panel):
		panel = overlay_panel(node)
	var target: Control = panel if panel != null else node
	target.pivot_offset = target.size / 2.0
	var tw := node.create_tween().set_parallel(true)
	tw.tween_property(node, "modulate:a", 0.0, d)
	tw.tween_property(target, "scale", Vector2(0.9, 0.9), d).set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUAD)
	tw.chain().tween_callback(node.queue_free)

## O painel de um overlay feito com centered_panel/window (o primeiro PanelContainer dentro de um CenterContainer).
static func overlay_panel(node: Node) -> Control:
	for c in node.get_children():
		if c is CenterContainer:
			for cc in c.get_children():
				if cc is PanelContainer:
					return cc
	return null

static func _ignore_input(n: Node) -> void:
	for c in n.get_children():
		if c is Control:
			(c as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
		_ignore_input(c)

## 0.16.0 (V59): ícone desenhado + texto numa linha (moeda e ouro, coração e vida…). O Label fica em get_meta("label").
static func icon_text(kind: String, text: String, font_size: int = 20, color: Color = Color.WHITE, icon_color: Color = Color(0, 0, 0, 0)) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", maxi(3, font_size / 5))
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var icon := CardIcon.new(kind, icon_color if icon_color.a > 0.0 else color, float(font_size) * 1.05)
	icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(icon)
	var l := label(text, font_size, color)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(l)
	row.set_meta("label", l)
	row.set_meta("icon", icon)
	return row

const COIN := Color(0.98, 0.8, 0.3)
const COIN_DIM := Color(0.62, 0.57, 0.5)   # moeda de um preço que não chega (o número fica vermelho)
const PRICE_SHORT := Color(1.0, 0.42, 0.38)

## 0.16.0 (V18): preço com a moeda; fica vermelho quando o ouro não chega.
static func price(amount: int, affordable: bool = true, font_size: int = 18) -> HBoxContainer:
	var row := icon_text("coin", str(amount), font_size, COIN if affordable else PRICE_SHORT, COIN if affordable else COIN_DIM)
	row.name = "Price"
	return row

static func set_price(row: Control, amount: int, affordable: bool) -> void:
	if row == null or not row.has_meta("label"):
		return
	var l: Label = row.get_meta("label")
	l.text = str(amount)
	if row.has_meta("ink"):   # 0.19.0 (167): em fundos claros (o bilhete do Vale), cores escuras
		l.add_theme_color_override("font_color", row.get_meta("ink") if affordable else Color(0.52, 0.07, 0.05))
	else:
		l.add_theme_color_override("font_color", COIN if affordable else PRICE_SHORT)
	var icon: CardIcon = row.get_meta("icon")
	icon.color = COIN if affordable else COIN_DIM

## 0.19.0 (80): ao lado de um preço (UiKit.price), o preço sem o desconto riscado. `old` ≤ `now` esconde-o.
static func set_old_price(row: Control, old: int, now: int) -> void:
	if row == null:
		return
	var l: Label = row.get_node_or_null("Old")
	if old <= now or old < 0:
		if l != null:
			l.visible = false
		return
	if l == null:
		var fs := 14
		if row.has_meta("label"):
			fs = maxi(11, int((row.get_meta("label") as Label).get_theme_font_size("font_size") * 0.78))
		l = label("", fs, Color(0.78, 0.74, 0.84, 0.85))
		l.name = "Old"
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		l.mouse_filter = Control.MOUSE_FILTER_IGNORE
		l.draw.connect(_strike.bind(l))
		row.add_child(l)
		row.move_child(l, 0)
	l.text = str(old)
	l.visible = true
	if row.has_meta("ink"):   # 0.19.0 (167): no bilhete dourado do Vale, o preço antigo também escuro
		l.add_theme_color_override("font_color", Color(row.get_meta("ink"), 0.72))
	l.queue_redraw()

static func _strike(l: Label) -> void:
	var y := l.size.y * 0.55
	l.draw_line(Vector2(-1, y), Vector2(l.size.x + 1, y), Color(1.0, 0.45, 0.45, 0.95), 2.0)

## 0.16.0: ícone desenhado num botão, preso por âncoras (ao centro, sem texto; ou à esquerda, com o texto
## empurrado para a direita). Desligado, o ícone apaga-se como o texto.
static func button_icon(b: Button, kind: String, color: Color = Color.WHITE, px: float = 22.0, centered: bool = false) -> CardIcon:
	var icon := CardIcon.new(kind, color, px)
	icon.name = "Icon"
	b.add_child(icon)
	icon.set_anchors_preset(Control.PRESET_CENTER if centered else Control.PRESET_CENTER_LEFT)
	icon.offset_left = -px * 0.5 if centered else 14.0
	icon.offset_right = px * 0.5 if centered else 14.0 + px
	icon.offset_top = -px * 0.5
	icon.offset_bottom = px * 0.5
	b.draw.connect(_icon_alpha.bind(icon, b))
	if not centered:
		for st in ["normal", "hover", "pressed", "disabled", "focus"]:
			var sb := b.get_theme_stylebox(st)
			if sb != null:
				var c: StyleBox = sb.duplicate()
				c.content_margin_left = px + 22.0
				b.add_theme_stylebox_override(st, c)
	return icon

static func _icon_alpha(icon, b) -> void:
	if is_instance_valid(icon) and is_instance_valid(b):
		(icon as Control).modulate.a = 0.4 if (b as BaseButton).disabled else 1.0

## 0.16.0 (V59): o botão de voltar ao menu dos ecrãs (a casa em vez do «◀»).
static func menu_button(height: int = 48, font_size: int = 18) -> Button:
	var b := button(TranslationServer.translate("MENU"), height, font_size)
	b.custom_minimum_size.x = maxf(b.custom_minimum_size.x, 132.0)
	button_icon(b, "menu", Color.WHITE, 20.0, false)
	return b

## 0.16.0 (V61): placa dourada (luz de cima, cantoneiras e, no principal, o brilho a passar) num botão.
static func gold_plate(b: Control, primary: bool = false) -> void:
	if b == null or b.has_node("PlaqueDeco"):
		return
	PlaqueDeco.attach(b, 12.0, true, primary, 0.18 if primary else 0.08)

## Entrada animada de um painel (escala + alpha), já com a velocidade das configurações.
static func pop_in(panel: Control) -> void:
	panel.modulate.a = 0.0
	await panel.get_tree().process_frame
	if not is_instance_valid(panel) or panel.is_queued_for_deletion():
		return
	panel.pivot_offset = panel.size / 2.0
	panel.scale = Vector2(0.88, 0.88)
	var d := Settings.dur(0.16)
	var tw := panel.create_tween().set_parallel(true)
	tw.tween_property(panel, "modulate:a", 1.0, d)
	tw.tween_property(panel, "scale", Vector2.ONE, d).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
