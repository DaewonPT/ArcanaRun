class_name UiKit
extends RefCounted
## Widgets com o aspeto do jogo, para os painéis construídos em código (pausa, configurações, zoom…).

const BG := Color(0.13, 0.11, 0.19)
const BG_LIGHT := Color(0.17, 0.14, 0.25)
const BORDER := Color(0.35, 0.3, 0.5)
const PRIMARY := Color(0.85, 0.55, 0.15)
const DANGER := Color(0.62, 0.2, 0.24)
const GOLD := Color(0.98, 0.75, 0.25)
const TEXT_DIM := Color(0.7, 0.7, 0.8)

static func flat(bg: Color, radius: int = 12, border: Color = Color(0, 0, 0, 0), border_w: int = 0, margin: int = 10) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.set_corner_radius_all(radius)
	s.set_content_margin_all(margin)
	if border_w > 0:
		s.set_border_width_all(border_w)
		s.border_color = border
	return s

static func button(text: String, height: int = 60, font_size: int = 24, bg: Color = BG_LIGHT, border: Color = BORDER) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, height)
	b.add_theme_font_size_override("font_size", font_size)
	var normal := flat(bg, 12, border, 2 if border.a > 0 else 0, 10)
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", normal)
	b.add_theme_stylebox_override("pressed", flat(bg.lightened(0.15), 12, border, 2 if border.a > 0 else 0, 10))
	b.add_theme_stylebox_override("disabled", flat(bg.darkened(0.35), 12, Color(0, 0, 0, 0), 0, 10))
	return b

static func label(text: String, font_size: int = 20, color: Color = Color.WHITE, autowrap: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	if autowrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

## Fundo escuro semi-transparente que cobre o ecrã (deixa passar os toques para o root).
static func dim(alpha: float = 0.74) -> ColorRect:
	var r := ColorRect.new()
	r.color = Color(0, 0, 0, alpha)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	r.set_anchors_preset(Control.PRESET_FULL_RECT)
	return r

## Painel centrado no ecrã (dentro de um CenterContainer de ecrã inteiro).
static func centered_panel(root: Control, width: float, bg: Color = BG, border: Color = BORDER) -> PanelContainer:
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(width, 0)
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	panel.add_theme_stylebox_override("panel", flat(bg, 18, border, 2, 24))
	center.add_child(panel)
	return panel

## Entrada animada de um painel (escala + alpha), já com a velocidade das configurações.
static func pop_in(panel: Control) -> void:
	panel.modulate.a = 0.0
	await panel.get_tree().process_frame
	if not is_instance_valid(panel) or panel.is_queued_for_deletion():
		return
	panel.pivot_offset = panel.size / 2.0
	panel.scale = Vector2(0.88, 0.88)
	var d := Settings.dur(0.16)
	var tw := panel.create_tween().set_parallel(true)
	tw.tween_property(panel, "modulate:a", 1.0, d)
	tw.tween_property(panel, "scale", Vector2.ONE, d).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
