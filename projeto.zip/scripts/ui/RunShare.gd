class_name RunShare
extends RefCounted
## 0.12.0: PARTILHAR no fim da run. Monta uma imagem quadrada (1080×1080, boa para o WhatsApp) com o
## resultado, o baralho, os números da run, a carta MVP e o dano por ante; grava-a em
## user://partilhas/ e abre-a no visualizador do telemóvel (de onde se partilha). Copia também um
## resumo em texto para colar numa mensagem — funciona mesmo que a imagem não abra.

const SIZE := Vector2i(1080, 1080)
const DIR := "user://partilhas/"
const BG_TOP := Color(0.1, 0.08, 0.16)
const BG_BOTTOM := Color(0.2, 0.11, 0.26)

## Resumo da run que acabou (chamar antes de a gravação ser apagada).
static func summary_from_state(won: bool, endless_end: bool) -> Dictionary:
	var log_: Dictionary = GameState.run_log
	var total := 0
	var by_ante: Dictionary = log_.get("damage_by_ante", {}) if log_.get("damage_by_ante") is Dictionary else {}
	var last := 0
	for k in by_ante:
		total += int(by_ante[k])
		last = maxi(last, int(k))
	var vals: Array = []
	for a in range(1, last + 1):
		vals.append(int(by_ante.get(str(a), 0)))
	var mvp := GameState.top_of(log_.get("card_dmg", {}) if log_.get("card_dmg") is Dictionary else {})
	var mode_label := GameState.mode_name(GameState.mode)
	if GameState.mode == "campaign" and GameState.free_mode:
		mode_label = "Modo Livre"
	var what := String(GameState.deck_def.get("name", ""))
	if GameState.challenge_id != "":
		what = String(CardDB.get_challenge(GameState.challenge_id).get("name", what))
	elif GameState.saga_id != "":
		what = String(CardDB.get_saga_chapter(GameState.saga_id).get("name", what))
	return {
		"won": won, "endless": endless_end, "mode": mode_label, "what": what, "deck_color": _deck_color(),
		"ante": GameState.ante, "max_ante": GameState.max_ante, "difficulty": GameState.difficulty_name(),
		"stake": GameState.stake, "best_hit": int(log_.get("best_hit", 0)), "damage": total,
		"relics": GameState.relic_ids.size() + GameState.boss_relics.size() + GameState.blessings.size(),
		"cards": GameState.deck.size(), "mvp": String(mvp.get("id", "")), "mvp_damage": int(mvp.get("damage", 0)),
		"seed": GameState.seed_value, "name": GameState.run_name, "by_ante": vals,
		"date": Time.get_datetime_string_from_system(false, true),
	}

static func _deck_color() -> String:
	var cols: Array = GameState.deck_def.get("colors", [])
	return String(cols[0]) if not cols.is_empty() else "colorless"

static func result_text(s: Dictionary) -> String:
	if bool(s.get("endless", false)):
		return TranslationServer.translate("INFINITO · ANTE %d") % int(s.get("ante", 1))
	return TranslationServer.translate("VITÓRIA") if bool(s.get("won", false)) else TranslationServer.translate("DERROTA")

## Resumo em texto (vai para a área de transferência).
static func share_text(s: Dictionary) -> String:
	var res := ""
	if bool(s.get("won", false)):
		res = String(TranslationServer.translate("Venci"))
	elif bool(s.get("endless", false)):
		res = String(TranslationServer.translate("Cheguei ao ante %d no Infinito")) % int(s.get("ante", 1))
	else:
		res = String(TranslationServer.translate("Caí no ante %d")) % int(s.get("ante", 1))
	var lines: PackedStringArray = []
	lines.append("🎴 Zero-Sum — %s!" % res)
	lines.append("%s · %s · %s" % [TranslationServer.translate(String(s.get("what", ""))), TranslationServer.translate(String(s.get("mode", ""))), TranslationServer.translate(String(s.get("difficulty", "")))])
	lines.append(String(TranslationServer.translate("Maior golpe: %s · dano total: %s")) % [Cascade.fmt_int(int(s.get("best_hit", 0))), Cascade.fmt_int(int(s.get("damage", 0)))])
	var mvp := String(s.get("mvp", ""))
	var cd: CardData = CardDB.get_card(mvp) if mvp != "" else null
	if cd != null:
		lines.append(String(TranslationServer.translate("Carta MVP: %s")) % cd.display_name())
	lines.append(String(TranslationServer.translate("Fazemos Ameaças, não promessas.")))
	return "\n".join(lines)

## A imagem montada em Controls (para a SubViewport).
static func build_card(s: Dictionary) -> Control:
	var root := Control.new()
	root.size = Vector2(SIZE)
	var bg := _Bg.new()
	bg.size = Vector2(SIZE)
	bg.accent = CardView.COLORS.get(String(s.get("deck_color", "colorless")), CardView.COLORS.colorless)
	root.add_child(bg)
	var m := MarginContainer.new()
	m.size = Vector2(SIZE)
	for side in ["left", "right"]:
		m.add_theme_constant_override("margin_" + side, 64)
	m.add_theme_constant_override("margin_top", 44)
	m.add_theme_constant_override("margin_bottom", 40)
	root.add_child(m)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	m.add_child(v)
	var logo := UiKit.label("ZERO-SUM", 84, UiKit.GOLD)
	logo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(logo)
	var motto := UiKit.label(TranslationServer.translate("Fazemos Ameaças, não promessas."), 30, Color(1, 0.86, 0.55))
	motto.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	motto.theme_type_variation = &"TitleLabel"
	v.add_child(motto)
	var won := bool(s.get("won", false))
	var res_col := Color(0.55, 0.95, 0.62) if won else (Color(0.98, 0.75, 0.25) if bool(s.get("endless", false)) else Color(0.95, 0.47, 0.45))
	var res := UiKit.label(result_text(s), 86, res_col)
	res.name = "Result"
	res.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	res.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.6))
	res.add_theme_constant_override("outline_size", 10)
	v.add_child(res)
	var who := TranslationServer.translate(String(s.get("what", "")))
	if String(s.get("name", "")) != "":
		who = "«%s» · %s" % [String(s.get("name", "")), who]
	var sub := UiKit.label("%s  ·  %s  ·  %s" % [who, TranslationServer.translate(String(s.get("mode", ""))), TranslationServer.translate(String(s.get("difficulty", "")))], 32, Color.WHITE)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(sub)
	# Números da run em seis caixas.
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 16)
	grid.add_theme_constant_override("v_separation", 16)
	grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	v.add_child(grid)
	var cells := [
		["Ante", "%d/%d" % [int(s.get("ante", 1)), int(s.get("max_ante", 8))]],
		["Maior golpe", Cascade.fmt_int(int(s.get("best_hit", 0)))],
		["Dano total", Cascade.fmt_int(int(s.get("damage", 0)))],
		["Relíquias", str(int(s.get("relics", 0)))],
		["Baralho", TranslationServer.translate("%d cartas") % int(s.get("cards", 0))],
		["Selo", str(int(s.get("stake", 1)))],
	]
	for c in cells:
		var p := PanelContainer.new()
		p.custom_minimum_size = Vector2(300, 0)
		p.add_theme_stylebox_override("panel", UiKit.flat(Color(0, 0, 0, 0.35), 18, Color(1, 1, 1, 0.12), 2, 10))
		var pv := VBoxContainer.new()
		pv.add_theme_constant_override("separation", 0)
		p.add_child(pv)
		var k := UiKit.label(TranslationServer.translate(String(c[0])), 24, Color(0.82, 0.8, 0.9))
		k.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		pv.add_child(k)
		var val := UiKit.label(String(c[1]), 36, Color.WHITE)
		val.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		pv.add_child(val)
		grid.add_child(p)
	# Carta MVP e o dano por ante, lado a lado.
	var low := HBoxContainer.new()
	low.alignment = BoxContainer.ALIGNMENT_CENTER
	low.add_theme_constant_override("separation", 40)
	low.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(low)
	var mvp := String(s.get("mvp", ""))
	if CardDB.get_card(mvp) != null:
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 6)
		low.add_child(col)
		var cap := UiKit.label(TranslationServer.translate("Carta MVP"), 24, UiKit.GOLD)
		cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(cap)
		# Os contentores repõem a escala dos filhos: a carta fica num Control simples, centrada no meio
		# do espaço (o pivot da carta é o centro, por isso cresce para todos os lados por igual).
		var holder := Control.new()
		holder.custom_minimum_size = CardView.SIZE_NORMAL * 1.3
		col.add_child(holder)
		var mid := Control.new()
		mid.position = CardView.SIZE_NORMAL * 1.3 / 2.0
		holder.add_child(mid)
		var view: CardView = load("res://scenes/ui/CardView.tscn").instantiate()
		view.custom_minimum_size = CardView.SIZE_NORMAL
		view.mouse_filter = Control.MOUSE_FILTER_IGNORE
		view.position = -CardView.SIZE_NORMAL / 2.0
		view.scale = Vector2(1.3, 1.3)
		mid.add_child(view)
		view.setup(CardDB.new_instance(mvp))
		var dmg := UiKit.label(TranslationServer.translate("%s de dano") % Cascade.fmt_int(int(s.get("mvp_damage", 0))), 22, Color(0.85, 0.85, 0.92))
		dmg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(dmg)
	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 8)
	right.alignment = BoxContainer.ALIGNMENT_CENTER
	low.add_child(right)
	right.add_child(UiKit.label(TranslationServer.translate("Dano por ante"), 24, UiKit.GOLD))
	var chart := DamageChart.new()
	chart.custom_minimum_size = Vector2(520, 200)
	chart.set_values(s.get("by_ante", []))
	right.add_child(chart)
	var foot := UiKit.label("%s  ·  Seed %d" % [String(s.get("date", "")).substr(0, 16).replace("T", " "), int(s.get("seed", 0))], 20, Color(0.75, 0.72, 0.85))
	foot.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(foot)
	return root

## Desenha a imagem numa SubViewport e devolve-a (null sem ecrã, por exemplo nos testes headless).
static func render(host: Node, s: Dictionary) -> Image:
	if host == null or not host.is_inside_tree() or DisplayServer.get_name() == "headless":
		return null
	var vp := SubViewport.new()
	vp.size = SIZE
	vp.transparent_bg = false
	vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	host.add_child(vp)
	vp.add_child(build_card(s))
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var img := vp.get_texture().get_image()
	vp.queue_free()
	return img

## Grava a imagem e devolve o caminho ("" se falhar).
static func save(img: Image) -> String:
	if img == null or img.is_empty():
		return ""
	DirAccess.make_dir_recursive_absolute(DIR)
	var stamp := Time.get_datetime_string_from_system(false, false).replace(":", "").replace("-", "").replace("T", "-")
	var path := DIR + "zero-sum-%s.png" % stamp
	return path if img.save_png(path) == OK else ""

## Tudo de uma vez: texto para a área de transferência, imagem gravada e aberta. Devolve a mensagem.
static func share(host: Node, s: Dictionary) -> String:
	DisplayServer.clipboard_set(share_text(s))
	var img: Image = await render(host, s)
	var path := save(img)
	if path == "":
		return TranslationServer.translate("Resumo copiado — cola-o numa mensagem.")
	var err := OS.shell_open(ProjectSettings.globalize_path(path))
	if err != OK:
		return TranslationServer.translate("Imagem guardada em %s e resumo copiado.") % ProjectSettings.globalize_path(path)
	return TranslationServer.translate("Imagem criada e resumo copiado — toca em Partilhar e escolhe o WhatsApp.")

## Fundo da imagem: gradiente, um brilho da cor do baralho e estrelas.
class _Bg extends Control:
	var accent := Color(0.6, 0.5, 0.9)

	func _draw() -> void:
		var s := size
		draw_polygon(PackedVector2Array([Vector2.ZERO, Vector2(s.x, 0), s, Vector2(0, s.y)]),
			PackedColorArray([RunShare.BG_TOP, RunShare.BG_TOP, RunShare.BG_BOTTOM, RunShare.BG_BOTTOM]))
		var g := MenuBackdrop.glow_texture()
		draw_texture_rect(g, Rect2(Vector2(s.x * 0.5 - 520, 120), Vector2(1040, 700)), false, Color(accent, 0.22))
		var rng := RandomNumberGenerator.new()
		rng.seed = 2026
		for i in 120:
			draw_circle(Vector2(rng.randf() * s.x, rng.randf() * s.y), rng.randf_range(0.8, 2.4), Color(1, 0.96, 0.88, rng.randf_range(0.2, 0.6)))
		draw_rect(Rect2(Vector2(14, 14), s - Vector2(28, 28)), Color(UiKit.GOLD, 0.55), false, 3.0)
