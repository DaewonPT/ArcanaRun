class_name SwipeArea
extends Node
## 0.19.0 (9, 13): um deslizar rápido para o lado dentro de uma área — trocar de separador na Coleção, nas
## Estatísticas, nas Configurações e nos Talentos, ou trocar de alvo na Dupla. Não atrapalha os toques (só conta
## um gesto de ≥ 90 px em menos de 0,6 s, bem mais na horizontal do que na vertical), o deslizar das listas (que é
## na vertical) nem os cursores e as caixas de texto (um gesto que começa em cima deles não conta).
## Fica como filho do ecrã; só reage quando a área está na janela de cima.

signal swiped(direction: int)   # −1: para a esquerda (o seguinte) · +1: para a direita (o anterior)

const MIN_DX := 90.0
const MAX_MS := 600
const RATIO := 1.8

var area: Control
var _start := Vector2.ZERO
var _t0 := 0
var _on := false

## Liga uma área a `cb(direction)`. Devolve o detetor (filho de `parent`).
static func attach(parent: Node, area_ctl: Control, cb: Callable) -> SwipeArea:
	var s := SwipeArea.new()
	s.name = "SwipeArea"
	s.area = area_ctl
	parent.add_child(s)
	s.swiped.connect(cb)
	return s

## Avança num array de ids pelo gesto: «para a esquerda» passa ao seguinte, «para a direita» ao anterior.
## Devolve o id novo (o mesmo nas pontas).
static func step_id(ids: Array, current, direction: int):
	var i := ids.find(current)
	if i < 0:
		return current
	var j := clampi(i - direction, 0, ids.size() - 1)
	return ids[j]

func _input(event: InputEvent) -> void:
	if area == null or not is_instance_valid(area) or not area.is_visible_in_tree():
		return
	if not (event is InputEventMouseButton) or (event as InputEventMouseButton).button_index != MOUSE_BUTTON_LEFT:
		return
	var mb := event as InputEventMouseButton
	if mb.pressed:
		_on = _topmost() and area.get_global_rect().has_point(mb.position) and not _blocked(area, mb.position)
		_start = mb.position
		_t0 = Time.get_ticks_msec()
		return
	if not _on:
		return
	_on = false
	var d := mb.position - _start
	if Time.get_ticks_msec() - _t0 <= MAX_MS and absf(d.x) >= MIN_DX and absf(d.x) > absf(d.y) * RATIO:
		swiped.emit(-1 if d.x < 0.0 else 1)

## Testes: o mesmo que um gesto do dedo de `from` até `to`.
func simulate(from: Vector2, to: Vector2) -> void:
	_on = true
	_start = from
	_t0 = Time.get_ticks_msec()
	var mb := InputEventMouseButton.new()
	mb.button_index = MOUSE_BUTTON_LEFT
	mb.pressed = false
	mb.position = to
	_input(mb)

## A área está na janela de cima (ou no ecrã, sem janelas abertas)?
func _topmost() -> bool:
	var top := SceneRouter.top_overlay()
	if top == null:
		return true
	return top == area or top.is_ancestor_of(area)

## O gesto começou em cima de um cursor, de uma caixa de texto ou de uma lista que desliza para o lado?
static func _blocked(n: Node, pos: Vector2) -> bool:
	if n is CanvasItem and not (n as CanvasItem).visible:
		return false
	if n is Control:
		var c := n as Control
		if (c is Range or c is LineEdit or c is TextEdit) and c.get_global_rect().has_point(pos):
			return true
		if c is ScrollContainer and (c as ScrollContainer).horizontal_scroll_mode in [ScrollContainer.SCROLL_MODE_AUTO, ScrollContainer.SCROLL_MODE_SHOW_ALWAYS] \
				and c.get_global_rect().has_point(pos) and c.get_child_count() > 0:
			var inner := (c as ScrollContainer).get_child(0) as Control
			if inner != null and inner.size.x > c.size.x + 4.0:
				return true
	for ch in n.get_children():
		if _blocked(ch, pos):
			return true
	return false
