class_name SkillGem
extends Control
## 0.16.0: o custo de uma habilidade do patrono numa gema hexagonal — verde quando sobe a lealdade (+1), vermelha
## quando a gasta (−2, −6), cinzenta quando não se pode usar. Na batalha (nos botões) e na janela do patrono.

const FONT := preload("res://assets/fonts/Lora-Bold.ttf")

var cost := 0
var off := false:
	set(v):
		if v != off:
			off = v
			queue_redraw()

func _init(p_cost: int = 0, px: Vector2 = Vector2(42, 40)) -> void:
	cost = p_cost
	custom_minimum_size = px
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func text() -> String:
	return ("+%d" % cost) if cost > 0 else ("−%d" % absi(cost))

func _draw() -> void:
	var up := cost > 0
	var top := Color(0.73, 1.0, 0.84) if up else Color(1.0, 0.76, 0.73)
	var mid := Color(0.25, 0.81, 0.5) if up else Color(0.94, 0.35, 0.3)
	var low := Color(0.07, 0.48, 0.26) if up else Color(0.56, 0.11, 0.11)
	if off:
		top = Color(0.64, 0.63, 0.69)
		mid = Color(0.37, 0.35, 0.44)
		low = Color(0.2, 0.19, 0.25)
	var s := size
	var pts := PackedVector2Array([Vector2(s.x * 0.25, 0), Vector2(s.x * 0.75, 0), Vector2(s.x, s.y * 0.5), Vector2(s.x * 0.75, s.y), Vector2(s.x * 0.25, s.y), Vector2(0, s.y * 0.5)])
	draw_polygon(pts, PackedColorArray([top, mid, mid, low, low, mid]))
	draw_line(Vector2(s.x * 0.27, 1.2), Vector2(s.x * 0.73, 1.2), Color(1, 1, 1, 0.55), 1.5)
	var fs := int(clampf(s.y * 0.43, 12.0, 22.0))
	var txt := text()
	var ts := FONT.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
	var pos := Vector2((s.x - ts.x) * 0.5, s.y * 0.5 + FONT.get_ascent(fs) * 0.36)
	draw_string_outline(FONT, pos, txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, 4, Color(0.05, 0.02, 0.04, 0.8))
	draw_string(FONT, pos, txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color.WHITE if not off else Color(0.85, 0.84, 0.9))
