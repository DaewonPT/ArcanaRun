class_name ColorBurst
extends Node2D
## Explosão curta quando uma carta dispara na cascata do ataque, na cor da carta (desenhada em código,
## sem imagens): "red" = fogo (faúlhas laranja→vermelho a subir), "blue" = gelo (estilhaços azuis a
## abrir, com um anel), "green" = folhas (pedacinhos verdes a cair às voltas), "white" = luz (raios e
## brilhos branco-amarelos), "black" = fumo (baforadas roxas escuras e lentas); qualquer outra (incolor)
## = faíscas cinza e ouro. Dura ~0.6–0.9 s (um pouco menos na velocidade rápida) e liberta-se sozinha.
## Não faz nada com o movimento reduzido; nunca há mais de MAX_ALIVE vivas ao mesmo tempo, para uma
## cascata longa não encher o ecrã. Fogo, gelo, luz e faíscas somam luz (mistura aditiva); folhas e
## fumo tapam (mistura normal).

const MAX_ALIVE := 12

static var _alive: int = 0
static var _additive: CanvasItemMaterial

var kind := "colorless"
var _parts: Array = []
var _t := 0.0
var _dur := 0.8
var _speed := 1.0
var _counted := false
var _rng := RandomNumberGenerator.new()

## Cria uma explosão em global_pos, como filha de parent (que tem de estar na árvore).
static func spawn(parent: Node, global_pos: Vector2, color_name: String) -> void:
	if parent == null or not is_instance_valid(parent) or not parent.is_inside_tree():
		return
	if not Settings.motion_ok() or _alive >= MAX_ALIVE:
		return
	var b := ColorBurst.new()
	b.kind = color_name
	b._counted = true
	_alive += 1
	parent.add_child(b)
	b.global_position = global_pos
	b._start()

func _exit_tree() -> void:
	if _counted:
		_counted = false
		_alive = maxi(0, _alive - 1)

func _start() -> void:
	_rng.randomize()
	_speed = 1.0 / sqrt(clampf(Settings.anim_scale(), 0.3, 1.0))
	if kind != "green" and kind != "black":
		if _additive == null:
			_additive = CanvasItemMaterial.new()
			_additive.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		material = _additive
	match kind:
		"red":
			for i in 22:
				var a := -PI / 2.0 + _rng.randf_range(-1.05, 1.05)
				_add("spark", a, _rng.randf_range(150.0, 360.0), _rng.randf_range(0.45, 0.8), _rng.randf_range(2.2, 4.4), Vector2(0, -160.0), 2.3)
			for i in 6:
				_add("ember", -PI / 2.0 + _rng.randf_range(-0.8, 0.8), _rng.randf_range(40.0, 90.0), _rng.randf_range(0.7, 0.9), _rng.randf_range(2.0, 3.2), Vector2(0, -60.0), 1.2)
		"blue":
			for i in 14:
				var a := TAU * i / 14.0 + _rng.randf_range(-0.2, 0.2)
				_add("shard", a, _rng.randf_range(200.0, 400.0), _rng.randf_range(0.45, 0.7), _rng.randf_range(7.0, 12.0), Vector2.ZERO, 4.6)
			for i in 10:
				_add("speck", _rng.randf() * TAU, _rng.randf_range(60.0, 170.0), _rng.randf_range(0.4, 0.65), _rng.randf_range(1.6, 2.6), Vector2.ZERO, 3.0)
		"green":
			for i in 14:
				var a := -PI / 2.0 + _rng.randf_range(-1.4, 1.4)
				_add("leaf", a, _rng.randf_range(110.0, 240.0), _rng.randf_range(0.7, 0.9), _rng.randf_range(6.5, 9.5), Vector2(0, 340.0), 2.6)
		"white":
			for i in 16:
				_add("star", _rng.randf() * TAU, _rng.randf_range(110.0, 290.0), _rng.randf_range(0.45, 0.75), _rng.randf_range(4.5, 8.0), Vector2.ZERO, 4.0)
		"black":
			for i in 10:
				var a := -PI / 2.0 + _rng.randf_range(-1.7, 1.7)
				_add("puff", a, _rng.randf_range(30.0, 90.0), _rng.randf_range(0.7, 0.9), _rng.randf_range(10.0, 15.0), Vector2(0, -40.0), 1.6)
			for i in 8:
				_add("speck", _rng.randf() * TAU, _rng.randf_range(70.0, 150.0), _rng.randf_range(0.4, 0.7), _rng.randf_range(1.6, 2.4), Vector2(0, -20.0), 2.5)
		_:
			for i in 20:
				_add("diamond", _rng.randf() * TAU, _rng.randf_range(140.0, 320.0), _rng.randf_range(0.5, 0.8), _rng.randf_range(2.8, 4.6), Vector2(0, 240.0), 2.4)
	_dur = 0.0
	for p in _parts:
		_dur = maxf(_dur, p.life)
	_dur += 0.05

## Partícula: forma, ângulo e velocidade iniciais, vida (s), tamanho, gravidade e travagem.
func _add(shape: String, ang: float, speed: float, life: float, sz: float, grav: Vector2, drag: float) -> void:
	_parts.append({
		"shape": shape, "p": Vector2.ZERO, "v": Vector2(cos(ang), sin(ang)) * speed,
		"life": life, "size": sz, "g": grav, "drag": drag,
		"rot": _rng.randf() * TAU, "spin": _rng.randf_range(-7.0, 7.0), "tone": _rng.randf(),
		"sway": _rng.randf() * TAU,
	})

func _process(delta: float) -> void:
	var dt := delta * _speed
	_t += dt
	for p in _parts:
		p.v += p.g * dt
		p.v *= exp(-p.drag * dt)
		var d: Vector2 = p.v * dt
		if p.shape == "leaf":
			d.x += sin(_t * 9.0 + p.sway) * 40.0 * dt
		p.p += d
		p.rot += p.spin * dt
	if _t >= _dur:
		queue_free()
	else:
		queue_redraw()

func _draw() -> void:
	# Efeito no centro (clarão, anel ou raios), só no início.
	var k0 := clampf(_t / 0.35, 0.0, 1.0)
	var e0 := 1.0 - (1.0 - k0) * (1.0 - k0)   # abre depressa e abranda
	match kind:
		"red":
			_soft(Vector2.ZERO, 14.0 + 34.0 * e0, Color(1.0, 0.55, 0.15, 0.55 * (1.0 - k0)))
			_soft(Vector2.ZERO, 10.0 * (1.0 - k0) + 1.0, Color(1.0, 0.92, 0.6, 0.8 * (1.0 - k0)))
		"blue":
			var kr := clampf(_t / 0.42, 0.0, 1.0)
			var er := 1.0 - (1.0 - kr) * (1.0 - kr)
			draw_arc(Vector2.ZERO, 8.0 + 60.0 * er, 0.0, TAU, 48, Color(0.75, 0.92, 1.0, 0.75 * (1.0 - kr)), 3.0 * (1.0 - kr) + 0.6, true)
			_soft(Vector2.ZERO, 22.0, Color(0.7, 0.9, 1.0, 0.5 * (1.0 - k0)))
		"white":
			var kr := clampf(_t / 0.45, 0.0, 1.0)
			var er := 1.0 - (1.0 - kr) * (1.0 - kr)
			var col := Color(1.0, 0.97, 0.8, 0.9 * (1.0 - kr))
			for i in 12:
				var a := TAU * i / 12.0 + 0.3
				var d := Vector2(cos(a), sin(a))
				var inner := 6.0 + 30.0 * er
				var outer := inner + (40.0 if i % 2 == 0 else 22.0) * (1.0 - kr * 0.5)
				_ray(d * inner, d * outer, 4.0 * (1.0 - kr) + 1.2, col, Color(col, 0.0))
			_soft(Vector2.ZERO, 34.0 * (1.0 - k0 * 0.5), Color(1.0, 0.96, 0.8, 0.45 * (1.0 - k0)))
			_soft(Vector2.ZERO, 12.0 * (1.0 - k0) + 2.0, Color(1.0, 1.0, 0.95, 0.9 * (1.0 - k0)))
		"black":
			_soft(Vector2.ZERO, 18.0 + 14.0 * e0, Color(0.32, 0.16, 0.42, 0.55 * (1.0 - k0)))
		_:
			_soft(Vector2.ZERO, 12.0 + 24.0 * e0, Color(1.0, 0.85, 0.5, 0.45 * (1.0 - k0)))
	for p in _parts:
		var k := clampf(_t / float(p.life), 0.0, 1.0)
		if k < 1.0:
			_draw_part(p, k)

func _draw_part(p: Dictionary, k: float) -> void:
	var pos: Vector2 = p.p
	var sz: float = p.size
	var v: Vector2 = p.v
	var fade := 1.0 - k * k
	match String(p.shape):
		"spark", "ember":
			var col := Color(1.0, 0.95, 0.65).lerp(Color(1.0, 0.55, 0.15), clampf(k * 1.8, 0.0, 1.0)).lerp(Color(0.85, 0.18, 0.1), clampf(k * 2.0 - 1.0, 0.0, 1.0))
			var dir := v.normalized() if v.length() > 1.0 else Vector2.UP
			var length := sz * 1.2 + v.length() * 0.05
			if p.shape == "ember":
				_soft(pos, sz * 2.4, Color(1.0, 0.45, 0.12, 0.3 * fade))
			_ray(pos, pos - dir * length, maxf(1.6, sz * 0.7), Color(col, 0.9 * fade), Color(col, 0.0))
			draw_circle(pos, maxf(0.8, sz * 0.36), Color(Color(1.0, 0.97, 0.8).lerp(col, k), fade))
		"shard":
			var dir := v.normalized() if v.length() > 1.0 else Vector2.RIGHT.rotated(p.rot)
			var n := dir.orthogonal()
			var s := sz * (1.0 - 0.35 * k)
			var pts := PackedVector2Array([pos + dir * s, pos + n * s * 0.28, pos - dir * s * 0.55, pos - n * s * 0.28])
			draw_colored_polygon(pts, Color(0.62, 0.86, 1.0, 0.85 * fade))
			draw_line(pts[0], pts[2], Color(1, 1, 1, 0.8 * fade), 1.0, true)
		"leaf":
			var greens := [Color(0.45, 0.8, 0.35), Color(0.3, 0.62, 0.3), Color(0.68, 0.86, 0.38)]
			var col: Color = greens[int(p.tone * 3.0) % 3]
			var dir := Vector2.RIGHT.rotated(p.rot)
			var n := dir.orthogonal() * (0.4 + 0.6 * absf(sin(p.rot * 1.7)))
			var pts := PackedVector2Array()
			for j in 7:
				var t := j / 6.0
				pts.append(pos + dir * sz * (t - 0.5) * 2.0 + n * sz * 0.45 * sin(PI * t))
			for j in range(5, 0, -1):
				var t := j / 6.0
				pts.append(pos + dir * sz * (t - 0.5) * 2.0 - n * sz * 0.45 * sin(PI * t))
			draw_colored_polygon(pts, Color(col, fade))
			draw_line(pos - dir * sz, pos + dir * sz * 0.8, Color(col.darkened(0.4), fade), 0.8, true)
		"star":
			var tw := 0.75 + 0.25 * sin(_t * 30.0 + p.tone * TAU)
			var s := sz * (1.0 - 0.5 * k) * tw
			var col := Color(1.0, 0.97, 0.8).lerp(Color(1.0, 0.88, 0.5), k)
			_soft(pos, s * 1.6, Color(1.0, 0.95, 0.7, 0.25 * fade))
			draw_colored_polygon(_star(pos, s, p.rot * 0.2), Color(col, fade))
		"puff":
			var r := sz * (1.0 + 1.4 * k)
			var col := Color(0.44, 0.28, 0.58).lerp(Color(0.22, 0.13, 0.3), k)
			_soft(pos, r, Color(col, 0.8 * fade))
			_soft(pos + Vector2(0.15, 0.2) * r, r * 0.6, Color(0.08, 0.04, 0.12, 0.45 * fade))
			_soft(pos + Vector2(-0.3, -0.32) * r, r * 0.5, Color(0.62, 0.46, 0.78, 0.32 * fade))
		"speck":
			var col := Color(0.8, 0.95, 1.0) if kind == "blue" else Color(0.65, 0.45, 0.85)
			draw_rect(Rect2(pos - Vector2(sz, sz) * 0.5, Vector2(sz, sz)), Color(col, 0.8 * fade))
		_:
			var col := Color(0.85, 0.86, 0.92) if p.tone < 0.5 else Color(1.0, 0.8, 0.38)
			var s := sz * (1.0 - 0.4 * k)
			var pts := PackedVector2Array()
			for j in 4:
				var a: float = p.rot + TAU * j / 4.0
				pts.append(pos + Vector2(cos(a), sin(a)) * s * (1.0 if j % 2 == 0 else 0.55))
			draw_colored_polygon(pts, Color(col, fade))

## Raio afunilado com degradê: largura w e cor c0 em a, a acabar em ponta com a cor c1 em b.
func _ray(a: Vector2, b: Vector2, w: float, c0: Color, c1: Color) -> void:
	var n := (b - a).normalized().orthogonal() * w * 0.5
	draw_polygon(PackedVector2Array([a + n, b + n * 0.15, b - n * 0.15, a - n]), PackedColorArray([c0, c1, c1, c0]))

func _star(c: Vector2, s: float, rot: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for j in 8:
		var a := rot - PI / 2.0 + TAU * j / 8.0
		pts.append(c + Vector2(cos(a), sin(a)) * (s if j % 2 == 0 else s * 0.28))
	return pts

## Círculo suave (cor no centro, transparente no bordo).
func _soft(c: Vector2, r: float, col: Color) -> void:
	if r <= 0.5 or col.a <= 0.005:
		return
	var segs := 16
	var pts := PackedVector2Array([c])
	var cols := PackedColorArray([col])
	var idx := PackedInt32Array()
	var clear := Color(col, 0.0)
	for i in segs:
		pts.append(c + Vector2(cos(TAU * i / segs), sin(TAU * i / segs)) * r)
		cols.append(clear)
		idx.append_array(PackedInt32Array([0, 1 + i, 1 + (i + 1) % segs]))
	RenderingServer.canvas_item_add_triangle_array(get_canvas_item(), idx, pts, cols)
