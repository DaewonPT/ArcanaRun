class_name LightBand
extends Control
## 0.16.0 (letreiro «Faixa de luz», a escolha do Paulo): por trás dos letreiros grandes da batalha («Turno 2»,
## «Vitória», «O Boss desperta»), uma faixa escura de ponta a ponta do ecrã que se apaga nas pontas, com um
## filete dourado em cima e outro em baixo e uma luz quente por trás das letras. A linha pequena (o «ANTE 4»
## por cima, ou o «+2 DE ATAQUE» por baixo) vai num Label próprio, espaçado, entre dois losangos; sem ela, um
## losango com dois traços faz de ornamento. O texto grande é o Label do letreiro (fica por cima disto).
## Desenhado uma vez por letreiro (não redesenha enquanto anima: só mexem a escala e a transparência).

const BAND_H := 150.0
const GOLD := Color(0.98, 0.84, 0.5)
const RED := Color(1.0, 0.45, 0.4)

var sub_text := ""
var sub_on_top := true
var tone := "gold"                 # "gold" | "red" (derrotas)
var main_center_y := 0.0           # onde fica o meio do texto grande (coordenadas deste nó)
var main_width := 300.0            # largura do texto grande (a luz por trás acompanha-a)
var _sub: Label

static var _sub_font: FontVariation

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_sub = Label.new()
	_sub.name = "Sub"
	_sub.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_sub.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	if _sub_font == null:
		_sub_font = FontVariation.new()
		_sub_font.base_font = load("res://assets/fonts/Inter-Medium.otf")
		_sub_font.spacing_glyph = 5
	_sub.add_theme_font_override("font", _sub_font)
	_sub.add_theme_font_size_override("font_size", 19)
	_sub.add_theme_color_override("font_outline_color", Color(0.04, 0.02, 0.06, 0.9))
	_sub.add_theme_constant_override("outline_size", 4)
	add_child(_sub)

func accent() -> Color:
	return RED if tone == "red" else GOLD

## Arruma a faixa para um letreiro: a linha pequena, o tom e onde/quanto ocupa o texto grande.
func setup(p_sub: String, p_top: bool, p_tone: String, p_center_y: float, p_width: float) -> void:
	sub_text = p_sub
	sub_on_top = p_top
	tone = p_tone
	main_center_y = p_center_y
	main_width = p_width
	_sub.text = p_sub.to_upper()
	_sub.visible = p_sub != ""
	_sub.add_theme_color_override("font_color", accent().lerp(Color.WHITE, 0.08) if tone == "red" else Color(0.9, 0.77, 0.5))
	_sub.reset_size()
	var sy := main_center_y + (-58.0 if sub_on_top else 46.0)
	_sub.size = Vector2(size.x, 28.0)
	_sub.position = Vector2(0.0, sy - 14.0)
	queue_redraw()

func _draw() -> void:
	var w := size.x
	if w < 10.0:
		return
	var h := BAND_H if sub_text != "" else BAND_H - 22.0
	var cy := main_center_y + (-10.0 if sub_text != "" and sub_on_top else (10.0 if sub_text != "" else 0.0))
	var top := cy - h * 0.5
	var bot := cy + h * 0.5
	# A faixa: escura no meio, a apagar-se para as pontas (cinco paragens, cada uma com a sua cor).
	var dark := Color(0.04, 0.03, 0.08) if tone != "red" else Color(0.08, 0.02, 0.04)
	var xs := [0.0, 0.2, 0.5, 0.8, 1.0]
	var al := [0.0, 0.8, 0.9, 0.8, 0.0]
	for i in 4:
		var x0: float = float(xs[i]) * w
		var x1: float = float(xs[i + 1]) * w
		var c0 := Color(dark, float(al[i]))
		var c1 := Color(dark, float(al[i + 1]))
		draw_polygon(PackedVector2Array([Vector2(x0, top), Vector2(x1, top), Vector2(x1, bot), Vector2(x0, bot)]), PackedColorArray([c0, c1, c1, c0]))
	# Luz quente por trás das letras.
	var glow := Color(1.0, 0.72, 0.3) if tone != "red" else Color(1.0, 0.3, 0.25)
	var gc := Vector2(w * 0.5, main_center_y)
	var rx := clampf(main_width * 0.62, 180.0, w * 0.4)
	var ry := 56.0
	var pts := PackedVector2Array([gc])
	var cols := PackedColorArray([Color(glow, 0.24)])
	for i in 25:
		var a := TAU * i / 24.0
		pts.append(gc + Vector2(cos(a) * rx, sin(a) * ry))
		cols.append(Color(glow, 0.0))
	draw_polygon(pts, cols)
	# Filetes dourados em cima e em baixo (mais claros no meio, apagados nas pontas).
	var line_c := accent()
	for y in [top, bot - 2.0]:
		var lx := [0.04, 0.3, 0.5, 0.7, 0.96]
		var la := [0.0, 0.85, 1.0, 0.85, 0.0]
		for i in 4:
			var x0: float = float(lx[i]) * w
			var x1: float = float(lx[i + 1]) * w
			var c0 := Color(line_c.lightened(0.25 if i == 1 or i == 2 else 0.0), float(la[i]))
			var c1 := Color(line_c.lightened(0.25 if i == 1 or i == 2 else 0.0), float(la[i + 1]))
			draw_polygon(PackedVector2Array([Vector2(x0, y), Vector2(x1, y), Vector2(x1, y + 2.0), Vector2(x0, y + 2.0)]), PackedColorArray([c0, c1, c1, c0]))
	# Ornamentos: losangos à volta da linha pequena, ou um losango com dois traços por cima do texto grande.
	if sub_text != "":
		var font := _sub.get_theme_font("font")
		var tw := font.get_string_size(_sub.text, HORIZONTAL_ALIGNMENT_LEFT, -1, 19).x + 5.0 * _sub.text.length()
		var y := _sub.position.y + _sub.size.y * 0.5
		for sd in [-1.0, 1.0]:
			var side: float = sd
			var d := Vector2(w * 0.5 + side * (tw * 0.5 + 16.0), y)
			_diamond(d, 4.5, line_c)
			_fade_line(d + Vector2(side * 10.0, 0.0), d + Vector2(side * 100.0, 0.0), line_c)
	else:
		var d := Vector2(w * 0.5, main_center_y - 50.0)
		_diamond(d, 5.0, line_c)
		_fade_line(d + Vector2(-12.0, 0.0), d + Vector2(-130.0, 0.0), line_c)
		_fade_line(d + Vector2(12.0, 0.0), d + Vector2(130.0, 0.0), line_c)

func _diamond(c: Vector2, r: float, col: Color) -> void:
	draw_polygon(PackedVector2Array([c + Vector2(0, -r), c + Vector2(r, 0), c + Vector2(0, r), c + Vector2(-r, 0)]), PackedColorArray([col.lightened(0.3)]))

## Traço de 1,5 px que se apaga do primeiro ponto para o segundo.
func _fade_line(a: Vector2, b: Vector2, col: Color) -> void:
	var n := Vector2(0, 0.75)
	var c0 := Color(col, 0.95)
	var c1 := Color(col, 0.0)
	draw_polygon(PackedVector2Array([a - n, b - n, b + n, a + n]), PackedColorArray([c0, c1, c1, c0]))
