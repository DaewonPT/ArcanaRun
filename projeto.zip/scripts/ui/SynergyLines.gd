class_name SynergyLines
extends Control
## 0.16.0 (59): setas de sinergia. Com uma carta da mão escolhida, linhas finas (néon, na cor da carta) ligam-na
## às criaturas da Arena com que ela interage. Curvas suaves com um ponto a correr até ao alvo; desenhadas por
## cima de tudo e sem apanhar toques. Só anima (~30 fps) enquanto há linhas.

var _from := Vector2.ZERO
var _to: Array[Vector2] = []
var _color := Color(1, 0.85, 0.4)
var _t := 0.0
var _acc := 0.0

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	top_level = true
	z_index = 35
	set_process(false)

func set_links(from: Vector2, to: Array[Vector2], color: Color) -> void:
	_from = from
	_to = to
	_color = color
	global_position = Vector2.ZERO
	size = get_viewport_rect().size
	_t = 0.0
	set_process(Settings.motion_ok())
	queue_redraw()

func clear() -> void:
	if _to.is_empty():
		return
	_to = []
	set_process(false)
	queue_redraw()

func has_links() -> bool:
	return not _to.is_empty()

func _process(delta: float) -> void:
	if SceneRouter.decor_still():
		return   # 0.19.0 (208)
	_t += delta
	_acc += delta
	if _acc >= 1.0 / 30.0:
		_acc = 0.0
		queue_redraw()

func _draw() -> void:
	for p in _to:
		var mid := (_from + p) * 0.5 + Vector2(0, -minf(90.0, _from.distance_to(p) * 0.22))
		var pts := PackedVector2Array()
		for i in 21:
			var t := float(i) / 20.0
			pts.append(_from.lerp(mid, t).lerp(mid.lerp(p, t), t))
		draw_polyline(pts, Color(_color, 0.22), 7.0, true)
		draw_polyline(pts, Color(_color.lightened(0.35), 0.9), 2.0, true)
		var k := fmod(_t * 0.9, 1.0)
		var idx := clampi(int(k * 20.0), 0, 19)
		draw_circle(pts[idx], 4.0, Color(1, 1, 1, 0.9))
		draw_circle(p, 6.0, Color(_color, 0.55))
		draw_arc(p, 9.0, 0.0, TAU, 20, Color(_color.lightened(0.3), 0.9), 2.0, true)
