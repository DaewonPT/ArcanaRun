class_name ArtLib
extends RefCounted
## 0.12.0: ilustrações opcionais. 0.13.0: as imagens fazem-se no Gemini em folhas (tools/art_sheets.json,
## prompts com tools/make_art_prompts.py) e entram no jogo com tools/import_art.py, que as corta e põe em
## assets/art/<pasta>/<id>.webp.
## Se a imagem existir, a carta / o retrato / a relíquia / o fundo mostram-na; senão fica o desenho em
## código de sempre (sigilo, retrato vetorial, ícone, paisagem do ato). Configurações → Visual → Ilustrações.
## Guarda-se só se o ficheiro existe; as texturas ficam a cargo do ResourceLoader (libertam-se sozinhas).

const DIRS := {
	"card": "res://assets/art/cards/",
	"portrait": "res://assets/art/portraits/",
	"relic": "res://assets/art/relics/",
	"background": "res://assets/art/backgrounds/",
	"item": "res://assets/art/items/",   # 0.13.0: poções e pergaminhos
	"mapnode": "res://assets/art/mapnodes/",   # 0.13.0: medalhões do mapa (paragens e batalhas)
}
const EXTS := ["webp", "png", "jpg"]

static var _paths: Dictionary = {}   # "tipo:id" → caminho ("" = não há)
static var _counts: Dictionary = {}  # tipo → n.º de imagens
## Texturas postas à mão ("tipo:id" → Texture2D), para os testes não dependerem de imagens no projeto.
static var overrides: Dictionary = {}

static func path(kind: String, id: String) -> String:
	if id == "":
		return ""
	var key := kind + ":" + id
	if _paths.has(key):
		return String(_paths[key])
	var found := ""
	var dir := String(DIRS.get(kind, ""))
	if dir != "":
		for e in EXTS:
			var p: String = dir + id + "." + String(e)
			if ResourceLoader.exists(p):
				found = p
				break
	_paths[key] = found
	return found

static func has(kind: String, id: String) -> bool:
	return Settings.show_art and (overrides.has(kind + ":" + id) or path(kind, id) != "")

static func texture(kind: String, id: String) -> Texture2D:
	if not Settings.show_art:
		return null
	if overrides.has(kind + ":" + id):
		return overrides[kind + ":" + id]
	var p := path(kind, id)
	if p == "":
		return null
	return load(p) as Texture2D

## Quantas imagens há de um tipo (na exportação os ficheiros aparecem como "<nome>.webp.import").
static func count(kind: String) -> int:
	if _counts.has(kind):
		return int(_counts[kind])
	var n := 0
	var d := DirAccess.open(String(DIRS.get(kind, "")))
	if d != null:
		var seen := {}
		for f in d.get_files():
			var base := f.trim_suffix(".import").trim_suffix(".remap")
			for e in EXTS:
				if base.ends_with("." + e):
					seen[base] = true
		n = seen.size()
	_counts[kind] = n
	return n

static func total() -> int:
	var n := 0
	for k in DIRS:
		n += count(String(k))
	return n

## Depois de importar imagens novas (testes): esquece o que estava em cache.
static func clear_cache() -> void:
	_paths.clear()
	_counts.clear()

## Desenha uma textura a cobrir `rect` (corta o que sobra, centrado; `bias_y` puxa o corte para cima).
static func cover_region(tex: Texture2D, rect_size: Vector2, bias_y: float = 0.4) -> Rect2:
	var ts := tex.get_size()
	if ts.x <= 0.0 or ts.y <= 0.0 or rect_size.x <= 0.0 or rect_size.y <= 0.0:
		return Rect2(Vector2.ZERO, ts)
	var want := rect_size.x / rect_size.y
	var have := ts.x / ts.y
	if have > want:
		var w := ts.y * want
		return Rect2((ts.x - w) / 2.0, 0.0, w, ts.y)
	var h := ts.x / want
	return Rect2(0.0, (ts.y - h) * bias_y, ts.x, h)

## 0.13.0: desenha a textura dentro de um círculo (poções e pergaminhos nos espaços redondos).
static func draw_round(ci: CanvasItem, tex: Texture2D, center: Vector2, radius: float) -> void:
	var ts := tex.get_size()
	var side := minf(ts.x, ts.y) * 0.5
	var pts := PackedVector2Array()
	var uvs := PackedVector2Array()
	for i in 36:
		var a := TAU * i / 36.0
		var d := Vector2(cos(a), sin(a))
		pts.append(center + d * radius)
		uvs.append((ts * 0.5 + d * side) / ts)
	var cols := PackedColorArray()
	cols.resize(36)
	cols.fill(Color.WHITE)
	ci.draw_polygon(pts, cols, uvs, tex)
