class_name ArtLib
extends RefCounted
## 0.12.0: ilustrações opcionais. 0.13.0: as imagens fazem-se no Gemini em folhas (tools/art_sheets.json,
## prompts com tools/make_art_prompts.py) e entram no jogo com tools/import_art.py, que as corta e põe em
## assets/art/<pasta>/<id>.webp.
## Se a imagem existir, a carta / o retrato / a relíquia / o fundo mostram-na; senão fica o desenho em
## código de sempre (sigilo, retrato vetorial, ícone, paisagem do ato). Configurações → Visual → Ilustrações.
## Guarda-se só se o ficheiro existe; as texturas ficam a cargo do ResourceLoader (libertam-se sozinhas).

const DIRS := {
	"card": "res://assets/art/cards/",
	"portrait": "res://assets/art/portraits/",
	"relic": "res://assets/art/relics/",
	"background": "res://assets/art/backgrounds/",
	"item": "res://assets/art/items/",   # 0.13.0: poções e pergaminhos
	"mapnode": "res://assets/art/mapnodes/",   # 0.13.0: medalhões do mapa (paragens e batalhas)
	"event": "res://assets/art/events/",   # 0.16: imagem por cima do texto dos eventos e paragens
	"card_thumb": "res://assets/art/cards_256/",   # 0.16.1 (76): miniaturas de 256 px com mipmaps (tools/make_thumbs.py)
	"place_thumb": "res://assets/art/places_320/",   # 0.16.1: fundos e eventos ("ev_<id>") a 320 px, para a Galeria
}
const EXTS := ["webp", "png", "jpg"]

static var _paths: Dictionary = {}   # "tipo:id" → caminho ("" = não há)
static var _counts: Dictionary = {}  # tipo → n.º de imagens
## Texturas postas à mão ("tipo:id" → Texture2D), para os testes não dependerem de imagens no projeto.
static var overrides: Dictionary = {}

static func path(kind: String, id: String) -> String:
	if id == "":
		return ""
	var key := kind + ":" + id
	if _paths.has(key):
		return String(_paths[key])
	var found := ""
	var dir := String(DIRS.get(kind, ""))
	if dir != "":
		for e in EXTS:
			var p: String = dir + id + "." + String(e)
			if ResourceLoader.exists(p):
				found = p
				break
	_paths[key] = found
	return found

static func has(kind: String, id: String) -> bool:
	return Settings.show_art and (overrides.has(kind + ":" + id) or path(kind, id) != "")

static func texture(kind: String, id: String) -> Texture2D:
	if not Settings.show_art:
		return null
	if overrides.has(kind + ":" + id):
		return overrides[kind + ":" + id]
	var p := path(kind, id)
	if p == "":
		return null
	if _warm.has(p):   # 0.16.0 (77): já pedida noutra thread — apanha-a (espera só se ainda estiver a carregar)
		_warm.erase(p)
		var st := ResourceLoader.load_threaded_get_status(p)
		if st == ResourceLoader.THREAD_LOAD_LOADED or st == ResourceLoader.THREAD_LOAD_IN_PROGRESS:
			var t := ResourceLoader.load_threaded_get(p) as Texture2D
			if t != null:
				return t
	return load(p) as Texture2D

# --- 0.16.0 (77): carregar antes, noutra thread ---
## Caminhos pedidos ao ResourceLoader com load_threaded_request e ainda por apanhar.
static var _warm: Dictionary = {}

## Pede estas imagens ([[tipo, id], …]) para irem carregando noutra thread — o mapa pede as do baralho e o
## fundo do ato enquanto escolhes o caminho. As que já não estão na lista largam-se.
static func preload_async(items: Array) -> void:
	var want := {}
	if Settings.show_art:
		for it in items:
			if it is Array and (it as Array).size() >= 2:
				var p := path(String(it[0]), String(it[1]))
				if p != "":
					want[p] = true
	for p in _warm.keys():
		if not want.has(p):
			_drop_warm(String(p))
	for p in want:
		if _warm.has(p):
			continue
		if ResourceLoader.load_threaded_request(String(p), "Texture2D") == OK:
			_warm[p] = true

## Larga uma imagem pedida (só se já acabou de carregar: apanhar uma a meio bloquearia o jogo).
static func _drop_warm(p: String) -> void:
	var st := ResourceLoader.load_threaded_get_status(p)
	if st == ResourceLoader.THREAD_LOAD_IN_PROGRESS:
		return
	if st == ResourceLoader.THREAD_LOAD_LOADED:
		ResourceLoader.load_threaded_get(p)
	_warm.erase(p)

## A batalha fica com as que já estão prontas enquanto dura (assim não se voltam a ler do disco quando as cartas
## voltam à mão). As que ainda carregam ficam pedidas: texture() apanha-as quando forem precisas.
static func collect_warm() -> Array[Texture2D]:
	var out: Array[Texture2D] = []
	for p in _warm.keys():
		var st := ResourceLoader.load_threaded_get_status(String(p))
		if st == ResourceLoader.THREAD_LOAD_LOADED:
			var t := ResourceLoader.load_threaded_get(String(p)) as Texture2D
			if t != null:
				out.append(t)
			_warm.erase(p)
		elif st != ResourceLoader.THREAD_LOAD_IN_PROGRESS:
			_warm.erase(p)
	return out

static func warm_count() -> int:
	return _warm.size()

## 0.16.1 (76): a ilustração de uma carta para mostrar em pequeno (mão, Arena, Coleção, Construtor, pilhas):
## a miniatura de 256 px com mipmaps (um quarto da memória e mais limpa em pequeno); sem ela, a de 512 px.
## A carta em grande usa sempre a de 512 (small = false).
static func card_art(id: String, small: bool = true) -> Texture2D:
	if small:
		var t := texture("card_thumb", id)
		if t != null:
			return t
	return texture("card", id)

## O kind certo para pré-carregar a ilustração pequena de uma carta (a miniatura, se existir).
static func card_art_kind(id: String) -> String:
	return "card_thumb" if path("card_thumb", id) != "" else "card"

## Quantas imagens há de um tipo (na exportação os ficheiros aparecem como "<nome>.webp.import").
static func count(kind: String) -> int:
	if _counts.has(kind):
		return int(_counts[kind])
	var n := 0
	var d := DirAccess.open(String(DIRS.get(kind, "")))
	if d != null:
		var seen := {}
		for f in d.get_files():
			var base := f.trim_suffix(".import").trim_suffix(".remap")
			for e in EXTS:
				if base.ends_with("." + e):
					seen[base] = true
		n = seen.size()
	_counts[kind] = n
	return n

static func total() -> int:
	var n := 0
	for k in DIRS:
		n += count(String(k))
	return n

## Depois de importar imagens novas (testes): esquece o que estava em cache.
static func clear_cache() -> void:
	_paths.clear()
	_counts.clear()
	_blur.clear()

## 0.16.0 (V28): versão desfocada de uma ilustração, para fundos (o painel do inimigo): reduzida a 18 px e
## voltada a aumentar com suavização. Feita uma vez por imagem (fica em cache); null sem imagem.
static var _blur: Dictionary = {}

static func blurred(kind: String, id: String) -> Texture2D:
	var key := kind + ":" + id
	if _blur.has(key):
		return _blur[key]
	var out: Texture2D = null
	var tex := texture(kind, id)
	if tex != null:
		var img := tex.get_image()
		if img != null and not img.is_empty():
			img = img.duplicate()
			if img.is_compressed():
				img.decompress()
			img.convert(Image.FORMAT_RGBA8)
			img.resize(18, 18, Image.INTERPOLATE_BILINEAR)
			img.resize(96, 96, Image.INTERPOLATE_CUBIC)
			out = ImageTexture.create_from_image(img)
	_blur[key] = out
	return out

## Desenha uma textura a cobrir `rect` (corta o que sobra, centrado; `bias_y` puxa o corte para cima).
static func cover_region(tex: Texture2D, rect_size: Vector2, bias_y: float = 0.4) -> Rect2:
	var ts := tex.get_size()
	if ts.x <= 0.0 or ts.y <= 0.0 or rect_size.x <= 0.0 or rect_size.y <= 0.0:
		return Rect2(Vector2.ZERO, ts)
	var want := rect_size.x / rect_size.y
	var have := ts.x / ts.y
	if have > want:
		var w := ts.y * want
		return Rect2((ts.x - w) / 2.0, 0.0, w, ts.y)
	var h := ts.x / want
	return Rect2(0.0, (ts.y - h) * bias_y, ts.x, h)

## 0.14.0: pontos de um retângulo de cantos redondos (no sentido dos ponteiros do relógio, a começar no
## canto de cima à direita), para polígonos com textura, contornos e brilhos.
static func rounded_rect_points(r: Rect2, radius: float, seg: int = 4) -> PackedVector2Array:
	# Dá sempre 4 × (seg + 1) pontos (com raio 0 ficam no canto), para dois contornos com o mesmo seg
	# se poderem ligar ponto a ponto (anéis, brilhos, contornos).
	var rad := clampf(radius, 0.0, maxf(0.0, minf(r.size.x, r.size.y) * 0.5))
	var pts := PackedVector2Array()
	var centers := [Vector2(r.end.x - rad, r.position.y + rad), Vector2(r.end.x - rad, r.end.y - rad),
		Vector2(r.position.x + rad, r.end.y - rad), Vector2(r.position.x + rad, r.position.y + rad)]
	for k in 4:
		var start := -PI / 2.0 + PI / 2.0 * k
		for i in seg + 1:
			var a := start + (PI / 2.0) * i / seg
			pts.append((centers[k] as Vector2) + Vector2(cos(a), sin(a)) * rad)
	return pts

## 0.14.0: a textura a cobrir um retângulo de cantos redondos (um só polígono com UV; sem máscaras).
static func draw_rounded(ci: CanvasItem, tex: Texture2D, rect: Rect2, radius: float, bias_y: float = 0.4, tint: Color = Color.WHITE) -> void:
	var ts := tex.get_size()
	if ts.x <= 0.0 or ts.y <= 0.0 or rect.size.x <= 0.0 or rect.size.y <= 0.0:
		return
	var src := cover_region(tex, rect.size, bias_y)
	var pts := rounded_rect_points(rect, radius, 5)
	var uvs := PackedVector2Array()
	for p in pts:
		var f := (p - rect.position) / rect.size
		uvs.append((src.position + src.size * f) / ts)
	ci.draw_polygon(pts, PackedColorArray([tint]), uvs, tex)

## 0.13.0: desenha a textura dentro de um círculo (poções e pergaminhos nos espaços redondos).
static func draw_round(ci: CanvasItem, tex: Texture2D, center: Vector2, radius: float) -> void:
	var ts := tex.get_size()
	var side := minf(ts.x, ts.y) * 0.5
	var pts := PackedVector2Array()
	var uvs := PackedVector2Array()
	for i in 36:
		var a := TAU * i / 36.0
		var d := Vector2(cos(a), sin(a))
		pts.append(center + d * radius)
		uvs.append((ts * 0.5 + d * side) / ts)
	var cols := PackedColorArray()
	cols.resize(36)
	cols.fill(Color.WHITE)
	ci.draw_polygon(pts, cols, uvs, tex)
