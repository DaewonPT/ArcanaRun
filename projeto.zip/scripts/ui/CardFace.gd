class_name CardFace
extends Control
## 0.14.1: visual das cartas "Arte em destaque" (escolhido pelo AlizeOnMe; substitui o "Vidro arcano" da 0.14.0).
## Tudo o que a carta desenha, menos as letras, fica em duas camadas (dois nós deste tipo):
##   layer 0, por trás: a ilustração a toda a largura, com os cantos de cima redondos; sem ela, a zona da
##     arte na cor da carta (por baixo do sigilo ou da paisagem do Terreno);
##   layer 1, à frente (por baixo das letras): o escuro em cima da ilustração (o nome lê-se sempre), o
##     esbatido da ilustração para o fundo, o fundo da zona do texto, o fio da raridade, o contorno em degradê
##     das cartas de várias cores, a esfera do custo, os pips, a pílula do tipo (com o ícone e o losango da
##     raridade), as pílulas do Poder e da Vida e os discos por trás dos ícones das palavras-chave.
## Cada camada é um comando de desenho (mais um para a ilustração) e só se redesenha quando a carta ou o
## layout mudam (nunca a cada frame). O dono (CardView, CardZoom) diz onde fica cada peça, em coordenadas
## deste nó, e chama queue_redraw().

## Paleta de cada cor (a mesma do desenho B): contorno, fundo (em cima e em baixo), esfera do custo
## (clara, cor, escura) e pip.
const PALETTE := {
	"white": {"border": Color("e6cf92"), "top": Color("2d2a1e"), "bottom": Color("16140d"), "orb": [Color("fff3cf"), Color("e6cf92"), Color("8c7442")], "pip": Color("f4ecd0")},
	"blue": {"border": Color("4a8be6"), "top": Color("16264a"), "bottom": Color("0c1529"), "orb": [Color("d4e8ff"), Color("5c9bf0"), Color("1f4a99")], "pip": Color("4f8fe8")},
	"black": {"border": Color("8460b4"), "top": Color("24173a"), "bottom": Color("120b1e"), "orb": [Color("eadcff"), Color("8e6bc0"), Color("33204d")], "pip": Color("8e6bc0")},
	"red": {"border": Color("e8583c"), "top": Color("3a1610"), "bottom": Color("1e0b08"), "orb": [Color("ffe0cc"), Color("ec6a4b"), Color("8a2316")], "pip": Color("ec6a4b")},
	"green": {"border": Color("4fae5e"), "top": Color("15301c"), "bottom": Color("0b1a10"), "orb": [Color("dcf8d2"), Color("59b766"), Color("1d5e30")], "pip": Color("59b766")},
	"colorless": {"border": Color("a9a8b6"), "top": Color("26262f"), "bottom": Color("121218"), "orb": [Color("f2f2f8"), Color("aeadbd"), Color("4b4a5a")], "pip": Color("c4c3d0")},
	"curse": {"border": Color("d14d8f"), "top": Color("2e1024"), "bottom": Color("170812"), "orb": [Color("ffd6ea"), Color("d14d8f"), Color("5a1236")], "pip": Color("d14d8f")},
}
## Fundo das cartas de várias cores (azul-ardósia neutro, como no desenho).
const MULTI_BG := [Color("232a3e"), Color("121828")]
## Cor da pílula do tipo.
const PILL := {"creature": Color("8e2f22"), "token": Color("4a4a56"), "sorcery": Color("234a96"), "instant": Color("5b2c96"),
	"enchantment": Color("13706c"), "land": Color("6b4f1d"), "curse": Color("4f1f46"), "equipment": Color("7a5a2e")}
## Fio da raridade por dentro do contorno (as comuns não têm) e losango na pílula do tipo.
const RARITY_RING := {"uncommon": Color(0.839, 0.863, 0.918, 0.75), "rare": Color(0.949, 0.757, 0.306, 0.95), "mythic": Color(1.0, 0.588, 0.314, 0.95)}
const RARITY_GEM := {"uncommon": Color("d6dcea"), "rare": Color("f2c14e"), "mythic": Color("ff8a3d")}
## Pílulas de baixo: Poder (azul), Vida (vermelha) e Terrenos (dourada), em degradê de cima para baixo.
const POWER_PILL := [Color("3f86f0"), Color("1b4796")]
const TOUGH_PILL := [Color("ea4f69"), Color("9c1f37")]
const LAND_PILL := [Color("a8843a"), Color("5a4214")]
## Escuro por cima da ilustração (para o nome).
const SHADE := Color(0.024, 0.02, 0.047, 0.8)

var layer := 0:
	set(v):
		layer = v
		# 0.16.1 (76): a ilustração (miniatura com mipmaps) lê-se mais limpa em pequeno com o filtro com mipmaps.
		texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS if v == 0 else CanvasItem.TEXTURE_FILTER_PARENT_NODE
var card_size := Vector2.ZERO
var radius := 11.0            # canto de fora
var border_width := 2.0
## Chaves da paleta da carta (1 a 3; "curse" nas maldições, "colorless" nas incolores).
var keys: Array[String] = ["colorless"]
var gradient_border := false
var bg_top := Color("26262f")
var bg_bottom := Color("121218")
# Ilustração (layer 0) — sem textura, a zona da arte fica na cor da carta.
var texture: Texture2D
var art_rect := Rect2()
var art_radius := 9.0
var art_bias_y := 0.4
var art_tint := Color(0.3, 0.3, 0.35)
## 0.16.1 (54): arte viva das míticas — aproximação (1 = nenhuma) e deriva (fração do recorte) da ilustração.
var art_zoom := 1.0
var art_drift := Vector2.ZERO
var shade := SHADE
# Raridade
var ring_color := Color(1, 1, 1, 0)
var ring_width := 1.0
# Custo
var orb_rect := Rect2()
var orb_glow := true
# Pips (fora do modo daltónico, em que são ícones com símbolo)
var pip_rects: Array[Rect2] = []
var pip_colors: Array[Color] = []
# Pílula do tipo, com o ícone e o losango da raridade
var pill_rect := Rect2()
var pill_color := Color("8e2f22")
var pill_icon := ""
var pill_icon_rect := Rect2()
var gem_rect := Rect2()
var gem_color := Color(1, 1, 1, 0)
var gem_glow := false
# Pílulas de baixo (vazias = sem pílula)
var power_rect := Rect2()
var power_icon_rect := Rect2()
var tough_rect := Rect2()
var tough_icon_rect := Rect2()
var land_rect := Rect2()
# Discos por trás dos ícones das palavras-chave
var kw_rects: Array[Rect2] = []
# 0.15.0 Veteranos: estrelas douradas em cima da pílula do Poder (0 a 3)
var vet_stars := 0

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

static func palette(key: String) -> Dictionary:
	return PALETTE.get(key, PALETTE["colorless"])

## Chaves da paleta de uma carta: as suas cores (até 3); Maldições e incolores à parte.
static func color_keys(d: CardData) -> Array[String]:
	var out: Array[String] = []
	if d.is_curse():
		out.append("curse")
		return out
	for c in d.colors:
		if out.size() < 3 and PALETTE.has(String(c)):
			out.append(String(c))
	if out.is_empty():
		out.append("colorless")
	return out

## Cor do contorno (a das cartas de várias cores fica a meio entre as duas primeiras).
static func border_color(d: CardData) -> Color:
	var k := color_keys(d)
	var c: Color = palette(k[0])["border"]
	if k.size() >= 2:
		c = c.lerp(palette(k[1])["border"], 0.5)
	if d.token:
		c = c.lerp(Color(0.8, 0.8, 0.86), 0.4)
	return c

## Fundo da carta [em cima, em baixo].
static func backgrounds(d: CardData) -> Array[Color]:
	var k := color_keys(d)
	var out: Array[Color] = []
	if k.size() >= 2:
		out.append(MULTI_BG[0])
		out.append(MULTI_BG[1])
	else:
		out.append(palette(k[0])["top"])
		out.append(palette(k[0])["bottom"])
	if d.token:
		for i in out.size():
			out[i] = out[i].lerp(Color(0.2, 0.2, 0.24), 0.35)
	return out

## Cor do degradê do contorno em t (0 = canto de cima à esquerda, 1 = de baixo à direita): clara, as cores
## da carta pelo meio, escura no fim (como no desenho: creme → dourado → azul → azul-escuro).
func border_at(t: float) -> Color:
	var cols: Array[Color] = []
	for k in keys:
		cols.append(palette(k)["border"])
	if cols.size() < 2:
		return cols[0] if not cols.is_empty() else Color.WHITE
	var stops: Array[float] = []
	var pal: Array[Color] = [cols[0].lerp(Color.WHITE, 0.32)]
	stops.append(0.0)
	var n := cols.size()
	for i in n:
		pal.append(cols[i])
		stops.append(0.4 + 0.2 * float(i) / float(n - 1) if n == 2 else 0.28 + 0.44 * float(i) / float(n - 1))
	pal.append(cols[n - 1].darkened(0.38))
	stops.append(1.0)
	t = clampf(t, 0.0, 1.0)
	for i in range(1, stops.size()):
		if t <= stops[i]:
			var f := (t - stops[i - 1]) / maxf(0.0001, stops[i] - stops[i - 1])
			return pal[i - 1].lerp(pal[i], f)
	return pal[pal.size() - 1]

func _draw() -> void:
	if card_size.x < 8.0 or card_size.y < 8.0:
		return
	if layer == 0:
		_draw_back()
	else:
		_draw_front()

# --- Camada de trás: a ilustração ---

func _draw_back() -> void:
	if art_rect.size.x < 2.0 or art_rect.size.y < 2.0:
		return
	var pts := top_rounded(art_rect, art_radius, 5)
	if texture != null:
		var ts := texture.get_size()
		if ts.x <= 0.0 or ts.y <= 0.0:
			return
		var src := ArtLib.cover_region(texture, art_rect.size, art_bias_y)
		if art_zoom > 1.0001:
			var shrink := src.size / art_zoom
			var cpos := src.get_center() + art_drift * src.size
			src = Rect2(cpos - shrink * 0.5, shrink)
			src.position = src.position.clamp(Vector2.ZERO, ts - src.size)
		var uvs := PackedVector2Array()
		for p in pts:
			var f := (p - art_rect.position) / art_rect.size
			uvs.append((src.position + src.size * f) / ts)
		draw_polygon(pts, PackedColorArray([Color.WHITE]), uvs, texture)
		return
	# Sem ilustração: a zona da arte na cor da carta, a esbater para o fundo (o sigilo ou a paisagem vêm por cima).
	var b := TriBatch.new()
	var cols := PackedColorArray()
	for p in pts:
		cols.append(art_tint.lerp(bg_top, clampf((p.y - art_rect.position.y) / art_rect.size.y, 0.0, 1.0)))
	b.convex(pts, cols)
	b.flush(self)

# --- Camada da frente: tudo o resto ---

func _draw_front() -> void:
	var b := TriBatch.new()
	var bw := border_width
	var inner := Rect2(Vector2(bw, bw), card_size - Vector2(bw, bw) * 2.0)
	var ir := maxf(0.0, radius - bw)
	var has_art := art_rect.size.y > 2.0
	if has_art:
		var top := art_rect.position.y
		var h := art_rect.size.y
		# Escuro em cima (30 % da altura da arte): o nome lê-se sobre qualquer ilustração.
		if shade.a > 0.0:
			var lim := top + h * 0.3
			var poly := clip_half(top_rounded(art_rect, art_radius, 5), Vector2(0, 1), lim)
			var cols := PackedColorArray()
			for p in poly:
				cols.append(Color(shade, shade.a * (1.0 - clampf((p.y - top) / (h * 0.3), 0.0, 1.0))))
			b.convex(poly, cols)
		# Em baixo (dos 58 % ao fim), a ilustração esbate para o fundo da carta.
		if texture != null:
			var y0 := top + h * 0.58
			var y1 := art_rect.end.y + 1.0
			b.convex(PackedVector2Array([Vector2(art_rect.position.x, y0), Vector2(art_rect.end.x, y0), Vector2(art_rect.end.x, y1), Vector2(art_rect.position.x, y1)]),
				PackedColorArray([Color(bg_top, 0.0), Color(bg_top, 0.0), bg_top, bg_top]))
	# Fundo da zona do texto: da cor de cima (junto à arte) à de baixo (a do painel, que fecha os cantos).
	var ty0 := art_rect.end.y if has_art else inner.position.y
	var ty1 := inner.end.y - ir
	if ty1 > ty0 + 1.0:
		b.convex(PackedVector2Array([Vector2(inner.position.x, ty0), Vector2(inner.end.x, ty0), Vector2(inner.end.x, ty1), Vector2(inner.position.x, ty1)]),
			PackedColorArray([bg_top, bg_top, bg_bottom, bg_bottom]))
	# Fio da raridade, por dentro do contorno (por cima da ilustração).
	if ring_color.a > 0.0:
		var o := ArtLib.rounded_rect_points(inner, ir, 6)
		var i := ArtLib.rounded_rect_points(inner.grow(-ring_width), maxf(0.0, ir - ring_width), 6)
		b.strip(o, i, PackedColorArray([ring_color]), PackedColorArray([ring_color]))
		b.feather(i, ArtLib.rounded_rect_points(inner.grow(-ring_width - 0.8), maxf(0.0, ir - ring_width - 0.8), 6), ring_color)
	if gradient_border and keys.size() >= 2:
		_gradient_border(b, inner, ir)
	if orb_rect.size.x > 2.0:
		_orb(b)
	for i in mini(pip_rects.size(), pip_colors.size()):
		var pc := pip_rects[i].get_center()
		var pr := minf(pip_rects[i].size.x, pip_rects[i].size.y) * 0.5
		b.disc(pc, pr, Color(0, 0, 0, 0.6), 14)
		b.disc(pc, maxf(1.0, pr - maxf(1.0, pr * 0.26)), pip_colors[i], 14)
	if pill_rect.size.x > 4.0:
		_pill(b, pill_rect, pill_color, pill_color, Color(1, 1, 1, 0.35))
		if pill_icon != "":
			icon(b, pill_icon, pill_icon_rect, Color.WHITE)
	if gem_rect.size.x > 1.0 and gem_color.a > 0.0:
		_gem(b, gem_rect, gem_color, gem_glow)
	if power_rect.size.x > 4.0:
		_pill(b, power_rect, POWER_PILL[0], POWER_PILL[1], Color(1, 1, 1, 0.5))
		icon(b, "swords", power_icon_rect, Color.WHITE)
		# 0.15.0 Veteranos: uma estrela por cada 5 ataques, sentadas no rebordo de cima da pílula.
		if vet_stars > 0:
			var sr := maxf(2.5, power_rect.size.y * 0.24)
			var x0 := power_rect.position.x + sr * 1.6
			for k in vet_stars:
				var sc := Vector2(x0 + k * sr * 2.3, power_rect.position.y + sr * 0.2)
				b.fan(sc, star_points(sc, sr + 1.2, 0.48), Color(0.1, 0.06, 0.02, 0.9), PackedColorArray([Color(0.1, 0.06, 0.02, 0.9)]))
				b.fan(sc, star_points(sc, sr, 0.48), Color(1.0, 0.92, 0.55), PackedColorArray([Color(0.98, 0.72, 0.2)]))
	if tough_rect.size.x > 4.0:
		_pill(b, tough_rect, TOUGH_PILL[0], TOUGH_PILL[1], Color(1, 1, 1, 0.5))
		icon(b, "heart", tough_icon_rect, Color.WHITE)
	if land_rect.size.x > 4.0:
		_pill(b, land_rect, LAND_PILL[0], LAND_PILL[1], Color(1, 1, 1, 0.45))
	for r in kw_rects:
		var kc := r.get_center()
		var kr := minf(r.size.x, r.size.y) * 0.5 + maxf(2.0, r.size.x * 0.16)
		b.disc(kc, kr, Color(0.03, 0.02, 0.07, 0.74), 18)
		b.circle_ring(kc, kr - 1.0, kr, Color(1, 1, 1, 0.22), 18)
	b.flush(self)

## Contorno das cartas de várias cores: as cores seguem a diagonal (de cima à esquerda para baixo à
## direita), por cima do contorno do painel, com uma orla suave por fora.
func _gradient_border(b: TriBatch, inner: Rect2, ir: float) -> void:
	var outer_r := Rect2(Vector2.ZERO, card_size)
	var o := ArtLib.rounded_rect_points(outer_r, radius, 6)
	var i := ArtLib.rounded_rect_points(inner, ir, 6)
	var c_out := PackedColorArray()
	var c_in := PackedColorArray()
	var diag := card_size.x + card_size.y
	for p in o:
		c_out.append(border_at((p.x + p.y) / diag))
	for p in i:
		c_in.append(border_at((p.x + p.y) / diag))
	b.strip(o, i, c_out, c_in)
	var fade := PackedColorArray()
	for c in c_out:
		fade.append(Color(c, 0.0))
	b.strip(ArtLib.rounded_rect_points(outer_r.grow(0.8), radius + 0.8, 6), o, fade, c_out)

## Esfera do custo: brilho à volta, cor em degradê (luz em cima à esquerda), aro claro por dentro. Nas
## cartas de duas ou mais cores parte-se na diagonal com as duas primeiras.
func _orb(b: TriBatch) -> void:
	var c := orb_rect.get_center()
	var r := minf(orb_rect.size.x, orb_rect.size.y) * 0.5
	var n := 28
	var p1 := palette(keys[0])
	var o1: Array = p1["orb"]
	var glow_col: Color = p1["border"]
	if keys.size() >= 2:
		glow_col = glow_col.lerp(palette(keys[1])["border"], 0.5)
	if orb_glow:
		var g := maxf(3.0, r * 0.45)
		b.strip(circle_points(c, r + g, n), circle_points(c, r, n), PackedColorArray([Color(glow_col, 0.0)]), PackedColorArray([Color(glow_col, 0.7)]))
	var circle := circle_points(c, r, n)
	if keys.size() < 2:
		# Disco em anéis, com a cor pela distância à luz (35 %, 30 % do quadrado, como no desenho).
		var hl := c + Vector2(-0.3, -0.4) * r
		var rings: Array[PackedVector2Array] = [circle_points(c, r * 0.36, n), circle_points(c, r * 0.7, n), circle]
		var ring_cols: Array[PackedColorArray] = []
		for ring in rings:
			var cols := PackedColorArray()
			for p in ring:
				cols.append(_orb_color(o1, p.distance_to(hl) / (r * 1.3)))
			ring_cols.append(cols)
		b.fan(c, rings[0], _orb_color(o1, c.distance_to(hl) / (r * 1.3)), ring_cols[0])
		b.strip(rings[1], rings[0], ring_cols[1], ring_cols[0])
		b.strip(rings[2], rings[1], ring_cols[2], ring_cols[1])
	else:
		var o2: Array = palette(keys[1])["orb"]
		var split := Vector2(0.7071, 0.7071)
		var lim := c.dot(split)
		var h1 := clip_half(circle, split, lim)      # em cima à esquerda: 1.ª cor (clara → cor)
		var h2 := clip_half(circle, -split, -lim)    # em baixo à direita: 2.ª cor (cor → escura)
		var c1 := PackedColorArray()
		for p in h1:
			c1.append((o1[0] as Color).lerp(o1[1], clampf((p - c).dot(split) / r + 1.0, 0.0, 1.0)))
		var c2 := PackedColorArray()
		for p in h2:
			c2.append((o2[1] as Color).lerp(o2[2], clampf((p - c).dot(split) / r, 0.0, 1.0)))
		b.convex(h1, c1)
		b.convex(h2, c2)
	var rim := maxf(1.0, r * 0.07)
	b.strip(circle, circle_points(c, r - rim, n), PackedColorArray([Color(1, 1, 1, 0.55)]), PackedColorArray([Color(1, 1, 1, 0.55)]))
	b.feather(circle, circle_points(c, r + 0.8, n), Color(1, 1, 1, 0.45))

## Degradê da esfera: clara (0) → cor (0,4) → escura (1).
static func _orb_color(o: Array, t: float) -> Color:
	t = clampf(t, 0.0, 1.0)
	if t < 0.4:
		return (o[0] as Color).lerp(o[1], t / 0.4)
	return (o[1] as Color).lerp(o[2], (t - 0.4) / 0.6)

## Pílula (cantos de meia altura) em degradê de cima para baixo, com contorno fino e orla suave.
func _pill(b: TriBatch, r: Rect2, top: Color, bottom: Color, edge: Color) -> void:
	var pr := r.size.y * 0.5
	var pts := ArtLib.rounded_rect_points(r, pr, 5)
	var cols := PackedColorArray()
	for p in pts:
		cols.append(top.lerp(bottom, clampf((p.y - r.position.y) / r.size.y, 0.0, 1.0)))
	b.convex(pts, cols)
	var ew := maxf(1.0, r.size.y / 16.0)
	b.strip(pts, ArtLib.rounded_rect_points(r.grow(-ew), maxf(0.0, pr - ew), 5), PackedColorArray([edge]), PackedColorArray([edge]))
	b.feather(pts, ArtLib.rounded_rect_points(r.grow(0.8), pr + 0.8, 5), edge)

## Losango da raridade (com contorno escuro; as raras e míticas brilham).
func _gem(b: TriBatch, r: Rect2, col: Color, glow: bool) -> void:
	var c := r.get_center()
	var s := minf(r.size.x, r.size.y) * 0.5
	if glow:
		var g := s + maxf(2.0, s * 0.7)
		b.fan(c, _diamond(c, g), Color(col, 0.55), PackedColorArray([Color(col, 0.0)]))
	b.convex(_diamond(c, s + 1.0), PackedColorArray([Color(0, 0, 0, 0.5)]))
	var d := _diamond(c, s)
	b.convex(d, PackedColorArray([col]))

static func _diamond(c: Vector2, s: float) -> PackedVector2Array:
	return PackedVector2Array([c + Vector2(0, -s), c + Vector2(s, 0), c + Vector2(0, s), c + Vector2(-s, 0)])

## Ícones simples (numa grelha de 16×16, como os do desenho), feitos de triângulos e traços para irem no
## mesmo lote: tipo (garras, livro, raio, estrela, montanhas, maldição), espadas cruzadas e coração.
## 0.15.0: estrela de 5 pontas (contorno, a partir do topo); inner = raio de dentro em fração do de fora.
static func star_points(c: Vector2, r: float, inner: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for k in 10:
		var a := -PI / 2.0 + TAU * k / 10.0
		pts.append(c + Vector2(cos(a), sin(a)) * (r if k % 2 == 0 else r * inner))
	return pts

static func icon(b: TriBatch, kind: String, rect: Rect2, col: Color) -> void:
	if rect.size.x < 2.0:
		return
	var s := minf(rect.size.x, rect.size.y)
	var o := rect.position + (rect.size - Vector2(s, s)) * 0.5
	var u := s / 16.0
	var P := func(x: float, y: float) -> Vector2: return o + Vector2(x, y) * u
	match kind:
		"creature", "token":
			# três garras
			b.seg(P.call(4.0, 13.5), P.call(7.0, 3.0), 2.0 * u, col)
			b.seg(P.call(8.0, 14.0), P.call(10.5, 4.5), 2.0 * u, col)
			b.seg(P.call(12.0, 13.5), P.call(13.5, 8.0), 2.0 * u, col)
		"sorcery":
			# livro aberto
			for side in [-1.0, 1.0]:
				var a: Vector2 = P.call(8.0 - 5.5 * side, 3.5)
				var m: Vector2 = P.call(8.0, 4.2)
				var m2: Vector2 = P.call(8.0, 13.0)
				var e: Vector2 = P.call(8.0 - 5.5 * side, 12.5)
				b.convex(PackedVector2Array([a, m, m2, e]), PackedColorArray([Color(col, 0.28)]))
				b.seg(a, m, 1.6 * u, col)
				b.seg(e, m2, 1.6 * u, col)
				b.seg(a, e, 1.6 * u, col)
			b.seg(P.call(8.0, 4.2), P.call(8.0, 13.0), 1.4 * u, col)
		"instant":
			# raio
			b.tri(P.call(9.5, 1.0), P.call(3.0, 9.2), P.call(7.3, 9.2), col)
			b.tri(P.call(9.5, 1.0), P.call(7.3, 9.2), P.call(8.6, 6.6), col)
			b.tri(P.call(8.6, 6.6), P.call(7.3, 9.2), P.call(13.0, 6.6), col)
			b.tri(P.call(7.3, 9.2), P.call(6.2, 15.0), P.call(13.0, 6.6), col)
		"enchantment":
			# estrela de quatro pontas
			var star := PackedVector2Array()
			for i in 8:
				var a := -PI / 2.0 + TAU * i / 8.0
				star.append(P.call(8.0, 8.0) + Vector2(cos(a), sin(a)) * (6.8 if i % 2 == 0 else 2.4) * u)
			b.fan(P.call(8.0, 8.0), star, col, PackedColorArray([col]))
		"equipment":
			# 0.18.0 (19): martelo de forja
			b.seg(P.call(2.8, 14.2), P.call(10.0, 7.0), 1.9 * u, col)
			b.convex(PackedVector2Array([P.call(7.4, 3.7), P.call(10.8, 0.3), P.call(15.7, 5.2), P.call(12.3, 8.6)]), PackedColorArray([col]))
		"land":
			# duas montanhas
			b.tri(P.call(1.0, 14.0), P.call(6.5, 4.0), P.call(12.0, 14.0), col)
			b.tri(P.call(7.5, 14.0), P.call(11.5, 7.0), P.call(15.5, 14.0), Color(col, 0.75))
		"curse":
			# losango riscado
			var dm := [P.call(8.0, 1.5), P.call(14.5, 8.0), P.call(8.0, 14.5), P.call(1.5, 8.0)]
			for i in 4:
				b.seg(dm[i], dm[(i + 1) % 4], 1.6 * u, col)
			b.seg(P.call(5.0, 5.0), P.call(11.0, 11.0), 1.6 * u, col)
		"swords":
			# espadas cruzadas (lâminas, guardas e punhos)
			b.seg(P.call(3.0, 3.0), P.call(11.5, 11.5), 1.8 * u, col)
			b.seg(P.call(13.0, 3.0), P.call(4.5, 11.5), 1.8 * u, col)
			b.seg(P.call(9.5, 13.5), P.call(13.5, 9.5), 1.8 * u, col)
			b.seg(P.call(2.5, 9.5), P.call(6.5, 13.5), 1.8 * u, col)
			b.seg(P.call(12.0, 12.0), P.call(14.0, 14.0), 1.8 * u, col)
			b.seg(P.call(4.0, 12.0), P.call(2.0, 14.0), 1.8 * u, col)
		"heart":
			var pts := PackedVector2Array()
			for i in 32:
				var t := TAU * i / 32.0
				var x := 16.0 * pow(sin(t), 3)
				var y := -(13.0 * cos(t) - 5.0 * cos(2.0 * t) - 2.0 * cos(3.0 * t) - cos(4.0 * t))
				pts.append(P.call(8.0 + x * 0.42, 7.6 + y * 0.42))
			b.fan(P.call(8.0, 8.4), pts, col, PackedColorArray([col]))

# --- Geometria ---

## Retângulo com só os cantos de cima redondos (a ilustração encosta ao contorno da carta).
static func top_rounded(r: Rect2, rad: float, seg: int = 5) -> PackedVector2Array:
	var rr := clampf(rad, 0.0, minf(r.size.x, r.size.y) * 0.5)
	var pts := PackedVector2Array()
	var ctr_r := Vector2(r.end.x - rr, r.position.y + rr)
	for i in seg + 1:
		var a := -PI / 2.0 + (PI / 2.0) * i / seg
		pts.append(ctr_r + Vector2(cos(a), sin(a)) * rr)
	pts.append(r.end)
	pts.append(Vector2(r.position.x, r.end.y))
	var ctr_l := Vector2(r.position.x + rr, r.position.y + rr)
	for i in seg + 1:
		var a := PI + (PI / 2.0) * i / seg
		pts.append(ctr_l + Vector2(cos(a), sin(a)) * rr)
	return pts

static func circle_points(c: Vector2, r: float, n: int) -> PackedVector2Array:
	var out := PackedVector2Array()
	for i in n:
		var a := TAU * i / n
		out.append(c + Vector2(cos(a), sin(a)) * r)
	return out

## Corta um polígono convexo pelo semiplano p·dir <= lim (Sutherland–Hodgman com um só plano).
static func clip_half(pts: PackedVector2Array, dir: Vector2, lim: float) -> PackedVector2Array:
	var out := PackedVector2Array()
	var n := pts.size()
	for i in n:
		var a := pts[i]
		var b := pts[(i + 1) % n]
		var da := a.dot(dir) - lim
		var db := b.dot(dir) - lim
		if da <= 0.0:
			out.append(a)
		if (da <= 0.0) != (db <= 0.0):
			out.append(a.lerp(b, da / (da - db)))
	return out
