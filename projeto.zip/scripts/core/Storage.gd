class_name Storage
extends RefCounted
## 0.19.0 (secção 8): o que o jogo guarda no telemóvel — espaço ocupado por pasta (233), limpar, o aviso de fecho
## inesperado (230) e exportar/importar o progresso para um ficheiro (231, 232).

const SESSION_LOCK := "user://session.lock"
const EXPORT_NAME := "zero-sum-progresso"
const EXPORT_EXT := "zs1"

## Fecho inesperado: o arranque anterior deixou o cadeado (não passou por um fecho normal nem por segundo plano).
static var crashed_before := false

static func dir_size(dir: String) -> int:
	var d := DirAccess.open(dir)
	if d == null:
		return 0
	var n := 0
	d.include_hidden = true
	for f in d.get_files():
		var fa := FileAccess.open(dir.path_join(f), FileAccess.READ)
		if fa != null:
			n += fa.get_length()
			fa.close()
	for sub in d.get_directories():
		n += dir_size(dir.path_join(sub))
	return n

static func clear_dir(dir: String) -> void:
	var d := DirAccess.open(dir)
	if d == null:
		return
	d.include_hidden = true
	for f in d.get_files():
		DirAccess.remove_absolute(dir.path_join(f))
	for sub in d.get_directories():
		clear_dir(dir.path_join(sub))
		DirAccess.remove_absolute(dir.path_join(sub))

## 233: [[id, nome, bytes, limpar?]] — gravações, imagens partilhadas, conteúdo descarregado, miniaturas, cache e registos.
static func usage() -> Array:
	var saves := 0
	var d := DirAccess.open("user://")
	if d != null:
		for f in d.get_files():
			if f.ends_with(".json") or f.ends_with(".bak") or f.ends_with(".cfg") or f.contains("save") or f.contains("progress"):
				var fa := FileAccess.open("user://" + f, FileAccess.READ)
				if fa != null:
					saves += fa.get_length()
		for sub in ["saves", "trash", "backups"]:
			saves += dir_size("user://" + sub)
	return [
		["saves", "Jogos guardados e progresso", saves, false],
		["share", "Imagens partilhadas", dir_size(RunShare.DIR), true],
		["content", "Conteúdo descarregado", dir_size("user://content"), true],
		["thumbs", "Miniaturas das cartas", dir_size(ThumbCache.DIR), true],
		["cache", "Dados prontos a ler (cache)", dir_size(DataCache.DIR), true],
		["logs", "Registos de erros", dir_size("user://logs"), true],
	]

static func clear(id: String) -> void:
	match id:
		"share":
			clear_dir(RunShare.DIR)
		"content":
			ContentUpdate.clear_downloaded()
		"thumbs":
			ThumbCache.clear()
		"cache":
			DataCache.clear()
		"logs":
			var d := DirAccess.open("user://logs")
			if d != null:
				for f in d.get_files():
					if f != "godot.log":   # o desta sessão está aberto
						DirAccess.remove_absolute("user://logs/" + f)

static func fmt_bytes(n: int) -> String:
	if n < 1024:
		return "%d B" % n
	if n < 1024 * 1024:
		return "%d KB" % int(round(n / 1024.0))
	return ("%.1f MB" % (n / 1048576.0)).replace(".", "," if Settings.effective_language() == "pt" else ".")

# --- 230: fecho inesperado ---

## No arranque: se o cadeado ficou, o jogo fechou-se sozinho da última vez. Depois põe o cadeado desta sessão.
static func session_start() -> void:
	crashed_before = FileAccess.file_exists(SESSION_LOCK)
	lock(true)

static func lock(on: bool) -> void:
	if on:
		var f := FileAccess.open(SESSION_LOCK, FileAccess.WRITE)
		if f != null:
			f.store_string(Time.get_datetime_string_from_system())
			f.close()
	elif FileAccess.file_exists(SESSION_LOCK):
		DirAccess.remove_absolute(SESSION_LOCK)

# --- 231, 232: o progresso num ficheiro ---

## Onde vai o ficheiro: a pasta Transferências do telemóvel (se der para escrever lá) ou a pasta do jogo.
static func export_dirs() -> PackedStringArray:
	var out: PackedStringArray = []
	var dl := OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)
	if dl != "":
		out.append(dl)
	var docs := OS.get_system_dir(OS.SYSTEM_DIR_DOCUMENTS)
	if docs != "" and docs != dl:
		out.append(docs)
	out.append(ProjectSettings.globalize_path("user://exports"))
	return out

## Grava o código do progresso num ficheiro; devolve o caminho ("" se não deu em lado nenhum).
static func export_progress_file(code: String) -> String:
	var stamp := Time.get_date_string_from_system().replace("-", "")
	for dir in export_dirs():
		DirAccess.make_dir_recursive_absolute(dir)
		var path := dir.path_join("%s-%s.%s" % [EXPORT_NAME, stamp, EXPORT_EXT])
		var f := FileAccess.open(path, FileAccess.WRITE)
		if f == null:
			continue
		f.store_string(code + "\n")
		f.close()
		if FileAccess.file_exists(path):
			return path
	return ""

## Os ficheiros de progresso que se encontram (os mais recentes primeiro): [[caminho, data]].
static func find_progress_files() -> Array:
	var out: Array = []
	for dir in export_dirs():
		var d := DirAccess.open(dir)
		if d == null:
			continue
		for f in d.get_files():
			if f.begins_with(EXPORT_NAME) and (f.ends_with("." + EXPORT_EXT) or f.ends_with("." + EXPORT_EXT + ".txt")):
				var p := dir.path_join(f)
				out.append([p, FileAccess.get_modified_time(p)])
	out.sort_custom(func(a, b): return int(a[1]) > int(b[1]))
	return out

## O código dentro de um ficheiro de progresso ("" se não tem um).
static func read_progress_file(path: String) -> String:
	if not FileAccess.file_exists(path):
		return ""
	var t := FileAccess.get_file_as_string(path).strip_edges()
	var i := t.find(Settings.EXPORT_PREFIX)
	return t.substr(i).split("\n")[0].strip_edges() if i >= 0 else ""
