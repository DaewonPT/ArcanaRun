class_name Thermal
extends Node
## 0.19.0 (secção 7, gestão térmica): um nó do SceneRouter que vigia a sessão toda.
## - 205: mede os FPS sempre (janelas de 5 s), não só na 1.ª cascata; guarda a média e o mínimo da sessão (223).
## - 206: quedas longas (4 janelas seguidas abaixo de 62 % do alvo, num ecrã de jogo) são sinal de aquecimento:
##   liga o modo de desempenho sozinho (opção «auto_perf»), avisa e fica marcado para o poderes desligar.
## - 214: na batalha, com o ecrã sempre ligado, escurece o ecrã ao fim de 2 minutos sem toques (o 1.º toque
##   só acende).
## - 215: ao fim de 5 minutos sem toques, deixa o telemóvel apagar o ecrã (mesmo na batalha).

const WINDOW := 5.0
const SLOW_RATIO := 0.62
const SLOW_WINDOWS := 4
const DIM_AFTER := 120.0
const SCREEN_AFTER := 300.0
const GAME_SCENES := ["battle", "map", "shop", "event"]

var _acc := 0.0
var _frames := 0
var _target_sum := 0.0
var windows := 0
var fps_sum := 0.0
var fps_min := 0.0
var _slow_run := 0
var auto_done := false
var _dim: CanvasLayer
var _screen_released := false

func _ready() -> void:
	name = "Thermal"
	process_mode = Node.PROCESS_MODE_ALWAYS

func _process(delta: float) -> void:
	if DisplayServer.get_name() == "headless":
		return
	_sample(delta)
	_idle_tick()

## 205: uma janela de FPS a cada 5 s (com a app à vista; um salto grande é a app em segundo plano).
func _sample(delta: float) -> void:
	if not SceneRouter.app_focused or delta > 0.5:
		return
	_acc += delta
	_frames += 1
	_target_sum += float(Engine.max_fps if Engine.max_fps > 0 else 60)
	if _acc < WINDOW:
		return
	var fps := float(_frames) / _acc
	var target := _target_sum / float(_frames)
	add_window(fps, target)
	_acc = 0.0
	_frames = 0
	_target_sum = 0.0

## Uma janela medida (também para os testes): conta para a média e o mínimo e para o aquecimento.
func add_window(fps: float, target: float) -> void:
	windows += 1
	fps_sum += fps
	fps_min = fps if windows == 1 else minf(fps_min, fps)
	var slow := fps < target * SLOW_RATIO and SceneRouter.scene_key() in GAME_SCENES
	_slow_run = _slow_run + 1 if slow else 0
	if _slow_run >= SLOW_WINDOWS:
		_slow_run = 0
		heat_detected()

func avg_fps() -> float:
	return fps_sum / float(windows) if windows > 0 else 0.0

## 206: o telemóvel está a aquecer (ou é lento): modo de desempenho, uma vez por sessão, se a opção deixar.
func heat_detected() -> bool:
	if auto_done or Settings.performance_mode or not bool(Settings.opt("auto_perf")):
		return false
	auto_done = true
	Settings.performance_mode = true
	Settings.set_opt("auto_perf_on", true, false)
	Settings.apply()
	Settings.save_settings()
	SceneRouter.toast(tr("O telemóvel está a aquecer: liguei o modo de desempenho. Podes desligá-lo em Configurações → Desempenho."), 4.5)
	return true

## 223: a linha do relatório de erros.
func report_line() -> String:
	if windows == 0:
		return "FPS (sessão): sem medição"
	return "FPS (sessão): média %.0f · mínimo %.0f · %d janelas de %ds · modo de desempenho %s%s" % [avg_fps(), fps_min, windows, int(WINDOW),
		"ligado" if Settings.performance_mode else "desligado", " (automático)" if bool(Settings.opt("auto_perf_on")) else ""]

# --- 214, 215: o ecrã parado ---

func _idle_tick() -> void:
	var idle := SceneRouter.idle_secs()
	var battle_on := Settings.screen_on_wanted and Settings.keep_screen_on
	if battle_on and bool(Settings.opt("dim_idle")) and idle >= DIM_AFTER and not dimmed():
		set_dimmed(true)
	if battle_on and bool(Settings.opt("screen_limit")) and idle >= SCREEN_AFTER and not _screen_released:
		_screen_released = true
		DisplayServer.screen_set_keep_on(false)

## Tocaram no ecrã: acende (devolve true se estava escuro — esse toque não conta para o jogo).
func wake() -> bool:
	if _screen_released:
		_screen_released = false
		if Settings.screen_on_wanted and DisplayServer.get_name() != "headless":
			DisplayServer.screen_set_keep_on(Settings.keep_screen_on)
	if dimmed():
		set_dimmed(false)
		return true
	return false

func dimmed() -> bool:
	return _dim != null and _dim.visible

func set_dimmed(on: bool) -> void:
	if on and _dim == null:
		_dim = CanvasLayer.new()
		_dim.name = "IdleDim"
		_dim.layer = 126
		var r := ColorRect.new()
		r.name = "Shade"
		r.color = Color(0, 0, 0, 0.62)
		r.mouse_filter = Control.MOUSE_FILTER_STOP
		r.set_anchors_preset(Control.PRESET_FULL_RECT)
		_dim.add_child(r)
		var l := UiKit.label(tr("Toca para continuar"), 18, Color(1, 1, 1, 0.55))
		l.set_anchors_preset(Control.PRESET_FULL_RECT)
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		l.mouse_filter = Control.MOUSE_FILTER_IGNORE
		r.add_child(l)
		add_child(_dim)
	if _dim != null:
		_dim.visible = on
