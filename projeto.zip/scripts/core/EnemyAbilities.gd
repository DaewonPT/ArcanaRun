class_name EnemyAbilities
extends RefCounted
## Habilidades do inimigo (lidas de enemies.json). Correm depois do ataque do inimigo.
##
## Triggers: turn_end | every_n_turns (campo "n")
## Actions:  steal_gold | heal_self | heal_self_pct (% da vida máxima) | destroy_strongest |
##           damage_all_creatures | discard_random | steal_card (0.11.0: a carta mais cara da mão vai
##           para o exílio até ao fim da batalha) | mirror_best (0.11.0: no ataque seguinte a criatura
##           mais forte não dá Poder base)
## Com Raízes Protetoras (Reação) as habilidades contra criaturas não disparam nesse turno, e as
## criaturas com Proteção (palavra-chave) nunca são alvo.

var battle: BattleManager

func _init(p_battle: BattleManager) -> void:
	battle = p_battle

func on_turn_end(turn: int) -> void:
	for a in battle.enemy.get("abilities", []):
		var trig: String = a.get("trigger", "turn_end")
		if trig == "turn_end" or (trig == "every_n_turns" and turn % int(a.get("n", 1)) == 0):
			_apply(a)

func _apply(a: Dictionary) -> void:
	var v: int = int(a.get("value", 0))
	var action: String = a.get("action", "")
	if battle.protect_creatures and action in ["destroy_strongest", "damage_all_creatures", "mirror_best"]:
		return
	match action:
		"heal_self_pct":
			if battle.enemy.hp > 0:
				var h := int(round(float(battle.enemy.max_hp) * float(v) / 100.0))
				battle.enemy.hp = min(battle.enemy.max_hp, battle.enemy.hp + h)
				EventBus.enemy_hp_changed.emit(battle.enemy.hp, battle.enemy.max_hp)
		"steal_gold":
			var stolen: int = min(v, GameState.gold)
			if stolen > 0:
				GameState.add_gold(-stolen)
		"heal_self":
			if battle.enemy.hp > 0:
				battle.enemy.hp = min(battle.enemy.max_hp, battle.enemy.hp + v)
				EventBus.enemy_hp_changed.emit(battle.enemy.hp, battle.enemy.max_hp)
		"destroy_strongest":
			var creatures := battle.board.filter(func(c): return c.data.is_creature() and not battle.is_protected(c))
			if creatures.is_empty():
				return
			creatures.sort_custom(func(x, y): return x.power() > y.power())
			battle.kill_creature(creatures[0])
		"damage_all_creatures":
			for c in battle.board.duplicate():
				if c.data.is_creature() and not battle.is_protected(c):
					c.damage += v
					if c.is_dead():
						battle.kill_creature(c)
		"discard_random":
			for i in v:
				if battle.deck.hand.is_empty():
					break
				var idx := GameState.rng.randi_range(0, battle.deck.hand.size() - 1)
				var card: CardInstance = battle.deck.hand[idx]
				battle.deck.remove_from_hand(card)
				battle.deck.to_graveyard(card)
		"steal_card":
			var stolen := battle.steal_best_card()
			if stolen == null:
				return
			EventBus.card_stolen.emit(stolen)
		"mirror_best":
			var copied := battle.mirror_best_creature()
			if copied == null:
				return
			EventBus.creature_mirrored.emit(copied)
		_:
			push_warning("EnemyAbilities: ação desconhecida: " + action)
			return
	EventBus.enemy_ability_used.emit(battle.enemy.name, action)
