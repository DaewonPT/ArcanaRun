class_name EnemyAbilities
extends RefCounted
## Habilidades do inimigo (lidas de enemies.json). Correm depois do ataque do inimigo.
##
## Triggers: turn_end | every_n_turns (campo "n")
## Actions:  steal_gold | heal_self | heal_self_pct (% da vida máxima) | destroy_strongest |
##           damage_all_creatures | discard_random | steal_card (0.11.0: a carta mais cara da mão vai
##           para o exílio até ao fim da batalha) | mirror_best (0.11.0: no ataque seguinte a criatura
##           mais forte não dá Poder base)
## 0.12.0: grow_attack (o ataque dele sobe) · drain_mana (−N de mana no teu turno seguinte) ·
##   grow_shield (o escudo sobe N % até 20 %) · jail_strongest (a criatura mais forte fica presa no
##   ataque seguinte: nem Poder nem habilidades) · shuffle_board (baralha a ordem da tua Arena) ·
##   punish_channel (trigger "on_channel": cada canalização custa N de vida, nunca a última).
## 0.13.0: charge_attack (carrega um golpe: o contra-ataque do turno SEGUINTE vale ×(1 + N/100); a intenção
##   avisa um turno antes e o ataque desse turno aparece já multiplicado) · steal_relic (desliga a tua
##   relíquia mais à esquerda até ao fim da batalha).
## Com Raízes Protetoras (Reação) as habilidades contra criaturas não disparam nesse turno, e as
## criaturas com Proteção (palavra-chave) nunca são alvo.

var battle: BattleManager

func _init(p_battle: BattleManager) -> void:
	battle = p_battle

func on_turn_end(turn: int) -> void:
	for a in battle.enemy.get("abilities", []):
		var trig: String = a.get("trigger", "turn_end")
		if trig == "turn_end" or (trig == "every_n_turns" and turn % int(a.get("n", 1)) == 0):
			_apply(a)

## 0.15.0: uma habilidade solta (o fim de um ritual do boss).
func apply_ability(a: Dictionary) -> void:
	if String(a.get("action", "")) != "":
		_apply(a)

## Canalizaste uma carta: habilidades com o gatilho "on_channel" (Inquisidor do Silêncio).
func on_channel() -> void:
	for a in battle.enemy.get("abilities", []):
		if String(a.get("trigger", "")) == "on_channel":
			_apply(a)

func _apply(a: Dictionary) -> void:
	var v: int = int(a.get("value", 0))
	var action: String = a.get("action", "")
	if battle.protect_creatures and action in ["destroy_strongest", "damage_all_creatures", "mirror_best", "jail_strongest", "shuffle_board"]:
		return
	match action:
		"grow_attack":
			battle.enemy["attack"] = int(battle.enemy.get("attack", 0)) + v
		"drain_mana":
			battle.mana_drain += v
		"grow_shield":
			battle.enemy["shield_pct"] = minf(float(battle.enemy.get("shield_pct", 0.0)) + float(v), 20.0)
		"jail_strongest":
			var jailed := battle.jail_strongest_creature()
			if jailed == null:
				return
			EventBus.creature_jailed.emit(jailed)
		"shuffle_board":
			if not battle.shuffle_board():
				return
			EventBus.board_shuffled.emit()
		"punish_channel":
			if GameState.player_hp <= 1:
				return
			battle.lose_life(mini(v, GameState.player_hp - 1))
		"heal_self_pct":
			if battle.enemy.hp > 0:
				var h := int(round(float(battle.enemy.max_hp) * float(v) / 100.0))
				battle.enemy.hp = min(battle.enemy.max_hp, battle.enemy.hp + h)
				EventBus.enemy_hp_changed.emit(battle.enemy.hp, battle.enemy.max_hp)
		"steal_gold":
			var stolen: int = min(v, GameState.gold)
			if stolen > 0:
				GameState.add_gold(-stolen)
		"heal_self":
			if battle.enemy.hp > 0:
				battle.enemy.hp = min(battle.enemy.max_hp, battle.enemy.hp + v)
				EventBus.enemy_hp_changed.emit(battle.enemy.hp, battle.enemy.max_hp)
		"destroy_strongest":
			var target := battle._strongest_unprotected(battle.board)   # o mesmo alvo que a seta mostrou
			if target == null:
				return
			battle.kill_creature(target)
		"charge_attack":
			battle.charge_mult = maxf(battle.charge_mult, 1.0 + float(v) / 100.0)
		"damage_all_creatures":
			for c in battle.board.duplicate():
				if c.data.is_creature() and not battle.is_protected(c):
					c.damage += v
					if c.is_dead():
						battle.kill_creature(c)
		"discard_random":
			for i in v:
				if battle.deck.hand.is_empty():
					break
				var idx := GameState.rng.randi_range(0, battle.deck.hand.size() - 1)
				var card: CardInstance = battle.deck.hand[idx]
				battle.deck.remove_from_hand(card)
				battle.deck.to_graveyard(card)
		"steal_card":
			var stolen := battle.steal_best_card()
			if stolen == null:
				return
			EventBus.card_stolen.emit(stolen)
		"mirror_best":
			var copied := battle.mirror_best_creature()
			if copied == null:
				return
			EventBus.creature_mirrored.emit(copied)
		"steal_relic":   # 0.13.0 Ladra de Relíquias: a tua relíquia mais à esquerda desliga-se até ao fim da batalha
			if battle.steal_relic() == "":
				return
		_:
			push_warning("EnemyAbilities: ação desconhecida: " + action)
			return
	EventBus.enemy_ability_used.emit(battle.enemy.name, action)
