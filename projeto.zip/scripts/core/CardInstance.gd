class_name CardInstance
extends RefCounted
## Uma carta concreta dentro de uma batalha: tem estado (dano, buffs, zona).
## Os bónus PERMANENTES (crescimento verde, selo, cor, fusão) vivem na entrada do baralho em
## GameState, para sobreviverem de batalha para batalha.

enum Zone { DECK, HAND, BOARD, GRAVEYARD, EXILE }

static var _next_uid: int = 1

var uid: int
var data: CardData
var front: CardData               # face da frente (data troca pela de trás ao transformar)
var zone: Zone = Zone.DECK
var deck_entry: Dictionary = {}   # {"id", "power_bonus", "mult_bonus", "seal", ...} — partilhada com GameState.deck
var entry_index: int = -1         # posição em GameState.deck (para gravar/retomar a batalha)

# Estado mutável desta batalha. O dano acumula-se entre turnos ("feridas").
var damage: int = 0
var power_bonus: int = 0
var toughness_bonus: int = 0
var consumed: bool = false   # usou uma Canalização ao entrar (Vampiro Lacerador)
var exiled: bool = false     # feitiço já lançado nesta batalha: fica no cemitério, não volta ao grimório
var transformed: bool = false
var mission_count: int = 0   # progresso da missão (dupla face) nesta batalha
var turns_in_hand: int = 0

func _init(p_data: CardData, p_entry: Dictionary = {}) -> void:
	data = p_data
	front = p_data
	deck_entry = p_entry
	uid = _next_uid
	_next_uid += 1

func perm_power() -> int:
	return int(deck_entry.get("power_bonus", 0))

func perm_mult() -> float:
	return float(deck_entry.get("mult_bonus", 0.0))

func power() -> int:
	return max(0, data.power + power_bonus + perm_power())

func toughness() -> int:
	return data.toughness + toughness_bonus

## Pontos de resistência que ainda restam antes de morrer.
func remaining() -> int:
	return toughness() - damage

func is_dead() -> bool:
	return data.is_creature() and damage >= toughness()

## Crescimento permanente (fica na run inteira).
func grow(amount: int) -> void:
	if deck_entry.is_empty():
		power_bonus += amount
	else:
		deck_entry["power_bonus"] = perm_power() + amount

func grow_mult(amount: float) -> void:
	if not deck_entry.is_empty():
		deck_entry["mult_bonus"] = perm_mult() + amount

## Selo de guilda aplicado na loja ("" = nenhum).
func seal() -> String:
	return String(deck_entry.get("seal", ""))

func has_mission() -> bool:
	return not transformed and data.has_mission()

func mission_trigger() -> String:
	return String(data.mission.get("trigger", "")) if has_mission() else ""

func mission_target() -> int:
	return int(data.mission.get("count", 1)) if has_mission() else 0

## Vira para a face de trás (dupla face). Devolve false se não tiver.
func transform() -> bool:
	if transformed or not data.has_mission():
		return false
	data = front.back_face()
	transformed = true
	return true
