class_name CardInstance
extends RefCounted
## Uma carta concreta dentro de uma batalha: tem estado (dano, buffs, zona).

enum Zone { DECK, HAND, BOARD, GRAVEYARD }

static var _next_uid: int = 1

var uid: int
var data: CardData
var zone: Zone = Zone.DECK

# Estado mutável (só relevante em criaturas)
var damage: int = 0
var power_bonus: int = 0
var toughness_bonus: int = 0
var summoning_sick: bool = true

func _init(p_data: CardData) -> void:
	data = p_data
	uid = _next_uid
	_next_uid += 1

func power() -> int:
	return max(0, data.power + power_bonus)

func toughness() -> int:
	return data.toughness + toughness_bonus

func is_dead() -> bool:
	return data.is_creature() and damage >= toughness()

func reset_turn() -> void:
	summoning_sick = false
