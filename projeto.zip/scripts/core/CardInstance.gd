class_name CardInstance
extends RefCounted
## Uma carta concreta dentro de uma batalha: tem estado (dano, buffs, zona).
## Os bónus PERMANENTES (crescimento verde, selo, cor, fusão) vivem na entrada do baralho em
## GameState, para sobreviverem de batalha para batalha.

enum Zone { DECK, HAND, BOARD, GRAVEYARD, EXILE, ENCHANT, EQUIP }

static var _next_uid: int = 1

var uid: int
var data: CardData
var front: CardData               # face da frente (data troca pela de trás ao transformar)
var zone: Zone = Zone.DECK
var deck_entry: Dictionary = {}   # {"id", "power_bonus", "mult_bonus", "seal", ...} — partilhada com GameState.deck
var entry_index: int = -1         # posição em GameState.deck (para gravar/retomar a batalha)

# Estado mutável desta batalha. O dano acumula-se entre turnos ("feridas").
var damage: int = 0
var power_bonus: int = 0
var toughness_bonus: int = 0
var consumed: bool = false   # usou uma Canalização ao entrar (Vampiro do Crescente)
var exiled: bool = false     # feitiço já lançado nesta batalha: fica no cemitério, não volta ao grimório
var transformed: bool = false
var mission_count: int = 0   # progresso da missão (dupla face) nesta batalha
var turns_in_hand: int = 0
var kicked: bool = false     # jogada com Reforço: os efeitos do reforço somam-se aos da carta
var granted_keywords: Array = []   # 0.12.0: palavras-chave dadas por outras cartas (só nesta batalha)
var persisted: bool = false  # 0.15.0 Persistir: já voltou uma vez nesta batalha
var temp_copy: bool = false  # 0.15.0 Selo do Espelho: cópia com metade do Poder que desaparece no fim do turno
var equipped_uid: int = -1   # 0.18.0 (19) Equipamento: uid da criatura que o tem (-1 = à espera de uma)
var equip_keywords: Array = []   # 0.18.0: palavras-chave que o equipamento desta criatura lhe dá (BattleManager)

func _init(p_data: CardData, p_entry: Dictionary = {}) -> void:
	data = p_data
	front = p_data
	deck_entry = p_entry
	uid = _next_uid
	_next_uid += 1

## Efeitos em vigor: os da carta e, se foi jogada com Reforço, os do reforço.
func effects() -> Array:
	if kicked and data.has_kicker():
		var out: Array = data.effects.duplicate()
		out.append_array(data.kicker.get("effects", []))
		return out
	return data.effects

func is_token() -> bool:
	return data.token or temp_copy

## 0.13.0 (Avatar do Silêncio): as palavras-chave não funcionam nesta batalha. Liga-o a batalha.
static var keywords_off := false

## Palavra-chave da carta ou dada por outra carta nesta batalha (0.15.0: o Selo do Guardião dá Vigilância).
func has_keyword(k: String) -> bool:
	if keywords_off:
		return false
	return data.has_keyword(k) or k in granted_keywords or k in equip_keywords or (k == "vigilance" and seal() == "guardian")

## Todas as palavras-chave (as da carta primeiro, depois as dadas).
func keywords() -> Array:
	var out: Array = data.keywords.duplicate()
	for k in granted_keywords:
		if not (k in out):
			out.append(k)
	for k in equip_keywords:   # 0.18.0: as do equipamento
		if not (k in out):
			out.append(k)
	if seal() == "guardian" and not ("vigilance" in out):
		out.append("vigilance")
	return out

func grant_keyword(k: String) -> bool:
	# (as do equipamento não contam: se o equipamento sair, a palavra-chave dada por outra carta fica)
	var owned := data.has_keyword(k) or k in granted_keywords or (k == "vigilance" and seal() == "guardian")
	if (owned and not keywords_off) or not (k in CardData.KEYWORDS):
		return false
	granted_keywords.append(k)
	return true

func perm_power() -> int:
	return int(deck_entry.get("power_bonus", 0))

func perm_mult() -> float:
	return float(deck_entry.get("mult_bonus", 0.0))

func power() -> int:
	return max(0, data.power + power_bonus + perm_power())

func toughness() -> int:
	return data.toughness + toughness_bonus

## Pontos de resistência que ainda restam antes de morrer.
func remaining() -> int:
	return toughness() - damage

func is_dead() -> bool:
	return data.is_creature() and damage >= toughness()

## Crescimento permanente (fica na run inteira).
func grow(amount: int) -> void:
	if deck_entry.is_empty():
		power_bonus += amount
	else:
		deck_entry["power_bonus"] = perm_power() + amount

func grow_mult(amount: float) -> void:
	if not deck_entry.is_empty():
		deck_entry["mult_bonus"] = perm_mult() + amount

## 0.13.0: edição da carta ("" = normal; "shiny" Brilhante, "holo" Holográfica, "poly" Policromática).
func edition() -> String:
	return String(deck_entry.get("edition", ""))

## Selo de guilda aplicado na loja ("" = nenhum).
func seal() -> String:
	return String(deck_entry.get("seal", ""))

## 0.15.0 Veteranos: estrelas ganhas a atacar (0 a 3), guardadas na entrada do baralho.
func vet_stars() -> int:
	return int(deck_entry.get("vet_stars", 0))

func has_mission() -> bool:
	return not transformed and data.has_mission()

func mission_trigger() -> String:
	return String(data.mission.get("trigger", "")) if has_mission() else ""

func mission_target() -> int:
	return int(data.mission.get("count", 1)) if has_mission() else 0

## Vira para a face de trás (dupla face). Devolve false se não tiver.
func transform() -> bool:
	if transformed or not data.has_mission():
		return false
	data = front.back_face()
	transformed = true
	return true
