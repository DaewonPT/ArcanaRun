class_name Deck
extends RefCounted
## Biblioteca + mão + cemitério de uma batalha. Baralha com o RNG da run (seed reproduzível).

var library: Array[CardInstance] = []
var hand: Array[CardInstance] = []
var graveyard: Array[CardInstance] = []

func _init(ids: Array[String], rng: RandomNumberGenerator) -> void:
	for id in ids:
		var inst := CardDB.new_instance(id)
		if inst:
			library.append(inst)
	_shuffle(rng)

func _shuffle(rng: RandomNumberGenerator) -> void:
	for i in range(library.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var tmp := library[i]
		library[i] = library[j]
		library[j] = tmp

func draw(count: int = 1) -> Array[CardInstance]:
	var drawn: Array[CardInstance] = []
	for i in count:
		if library.is_empty():
			break
		var c := library.pop_back()
		c.zone = CardInstance.Zone.HAND
		hand.append(c)
		drawn.append(c)
		EventBus.card_drawn.emit(c)
	return drawn

func remove_from_hand(card: CardInstance) -> void:
	hand.erase(card)

func to_graveyard(card: CardInstance) -> void:
	card.zone = CardInstance.Zone.GRAVEYARD
	graveyard.append(card)
