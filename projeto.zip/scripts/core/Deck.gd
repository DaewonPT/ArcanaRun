class_name Deck
extends RefCounted
## Biblioteca + mão + cemitério de uma batalha. Baralha com o RNG da run (seed reproduzível).

var library: Array[CardInstance] = []
var hand: Array[CardInstance] = []
var graveyard: Array[CardInstance] = []

func _init(ids: Array[String], rng: RandomNumberGenerator) -> void:
	for id in ids:
		var inst := CardDB.new_instance(id)
		if inst:
			library.append(inst)
	_shuffle(rng)

func _shuffle(rng: RandomNumberGenerator) -> void:
	for i in range(library.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var tmp := library[i]
		library[i] = library[j]
		library[j] = tmp

## Mão inicial garantida: volta a baralhar (até 6 vezes) até ter 2 ou 3 terrenos.
func draw_opening_hand(count: int, rng: RandomNumberGenerator) -> Array[CardInstance]:
	for attempt in 6:
		var lands := 0
		for i in min(count, library.size()):
			if library[library.size() - 1 - i].data.is_land():
				lands += 1
		if lands >= 2 and lands <= 3:
			break
		_shuffle(rng)
	return draw(count)

## Compra até ter `size` cartas na mão.
func refill(size: int, rng: RandomNumberGenerator) -> Array[CardInstance]:
	return draw(max(0, size - hand.size()), rng)

## Se o baralho acabar, o cemitério volta a ser baralhado para a biblioteca.
func draw(count: int = 1, rng: RandomNumberGenerator = null) -> Array[CardInstance]:
	var drawn: Array[CardInstance] = []
	for i in count:
		if library.is_empty():
			if graveyard.is_empty() or rng == null:
				break
			library = graveyard.duplicate()
			graveyard.clear()
			for g in library:
				g.zone = CardInstance.Zone.DECK
				g.damage = 0
			_shuffle(rng)
		var c: CardInstance = library.pop_back()
		c.zone = CardInstance.Zone.HAND
		hand.append(c)
		drawn.append(c)
		EventBus.card_drawn.emit(c)
	return drawn

func remove_from_hand(card: CardInstance) -> void:
	hand.erase(card)

func to_graveyard(card: CardInstance) -> void:
	card.zone = CardInstance.Zone.GRAVEYARD
	graveyard.append(card)
