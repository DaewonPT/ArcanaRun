class_name Deck
extends RefCounted
## Biblioteca + mão + cemitério de uma batalha. Baralha com o RNG da run (seed reproduzível).

var library: Array[CardInstance] = []
var hand: Array[CardInstance] = []
var graveyard: Array[CardInstance] = []
var exile: Array[CardInstance] = []   # Recapitular já usado nesta batalha: fora até ao fim
var rng: RandomNumberGenerator

func _init(entries: Array[Dictionary], p_rng: RandomNumberGenerator) -> void:
	rng = p_rng
	for i in entries.size():
		var e: Dictionary = entries[i]
		if e.get("exiled_run", false):
			continue   # exilada da run (Selo da Corrupção a 0, Infeção de Óleo)
		var inst := CardDB.new_instance(String(e["id"]), e)
		if inst:
			inst.entry_index = i
			library.append(inst)
	_shuffle()

## Mulligan de Londres: a mão volta ao grimório, baralha-se e compra-se outra vez.
func shuffle_hand_in() -> void:
	for c in hand:
		c.zone = CardInstance.Zone.DECK
		library.append(c)
	hand.clear()
	_shuffle()

func to_exile(card: CardInstance) -> void:
	card.zone = CardInstance.Zone.EXILE
	card.damage = 0
	exile.append(card)

## Feitiços no cemitério com Recapitular (ainda não exilados).
func flashback_cards() -> Array[CardInstance]:
	var out: Array[CardInstance] = []
	for g in graveyard:
		if g.data.flashback and g.data.is_spell():
			out.append(g)
	return out

func _shuffle() -> void:
	for i in range(library.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var tmp := library[i]
		library[i] = library[j]
		library[j] = tmp

## Mão inicial garantida: volta a baralhar (até 6 vezes) até ter pelo menos uma carta
## jogável no 1.º turno (custo 1 que não seja terreno), se o baralho tiver alguma.
func draw_opening_hand(count: int) -> Array[CardInstance]:
	var has_one_drop := false
	for c in library:
		if not c.data.is_land() and c.data.cost <= 1:
			has_one_drop = true
			break
	if has_one_drop:
		for attempt in 6:
			var ok := false
			for i in min(count, library.size()):
				var c := library[library.size() - 1 - i]
				if not c.data.is_land() and c.data.cost <= 1:
					ok = true
					break
			if ok:
				break
			_shuffle()
	return draw(count)

## Compra até ter `size` cartas na mão.
func refill(size: int) -> Array[CardInstance]:
	return draw(max(0, size - hand.size()))

func _recyclable() -> int:
	var n := 0
	for g in graveyard:
		if not g.exiled:
			n += 1
	return n

## Se o baralho acabar, o cemitério volta a ser baralhado para a biblioteca.
func draw(count: int = 1) -> Array[CardInstance]:
	var drawn: Array[CardInstance] = []
	for i in count:
		if library.is_empty():
			if _recyclable() == 0:
				break
			shuffle_graveyard_in()
		var c: CardInstance = library.pop_back()
		c.zone = CardInstance.Zone.HAND
		c.kicked = false
		hand.append(c)
		drawn.append(c)
		EventBus.card_drawn.emit(c)
	return drawn

## Feitiços já lançados ("exilados") ficam no cemitério: cada feitiço é de uso único por batalha.
func shuffle_graveyard_in() -> void:
	var keep: Array[CardInstance] = []
	for g in graveyard:
		if g.exiled:
			keep.append(g)
			continue
		g.zone = CardInstance.Zone.DECK
		g.damage = 0
		library.append(g)
	graveyard = keep
	_shuffle()

func remove_from_hand(card: CardInstance) -> void:
	hand.erase(card)

func to_graveyard(card: CardInstance) -> void:
	card.zone = CardInstance.Zone.GRAVEYARD
	card.damage = 0
	graveyard.append(card)

func to_library_bottom(card: CardInstance) -> void:
	card.zone = CardInstance.Zone.DECK
	library.push_front(card)

## Topo do grimório para o cemitério.
func mill(count: int) -> Array[CardInstance]:
	var out: Array[CardInstance] = []
	for i in count:
		if library.is_empty():
			break
		var c: CardInstance = library.pop_back()
		to_graveyard(c)
		out.append(c)
	return out

## Devolve até N cartas do cemitério (as últimas) à mão.
func recover(count: int) -> void:
	for i in count:
		if graveyard.is_empty():
			break
		var c: CardInstance = graveyard.pop_back()
		c.zone = CardInstance.Zone.HAND
		c.kicked = false
		hand.append(c)

## Procura no grimório a primeira carta que passe no predicado e traz para a mão.
func tutor(pred: Callable) -> CardInstance:
	var best: CardInstance = null
	for c in library:
		if pred.call(c):
			best = c
			break
	if best != null:
		library.erase(best)
		best.zone = CardInstance.Zone.HAND
		best.kicked = false
		hand.append(best)
	return best

func tutor_strongest() -> CardInstance:
	var best: CardInstance = null
	for c in library:
		if c.data.is_creature() and (best == null or c.power() > best.power()):
			best = c
	if best != null:
		library.erase(best)
		best.zone = CardInstance.Zone.HAND
		best.kicked = false
		hand.append(best)
	return best

func lands_in_hand() -> Array[CardInstance]:
	var out: Array[CardInstance] = []
	for c in hand:
		if c.data.is_land():
			out.append(c)
	return out
