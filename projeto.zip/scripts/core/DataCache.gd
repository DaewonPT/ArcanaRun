class_name DataCache
extends RefCounted
## 0.19.0 (244, 245): o arranque lê os dados uma vez e guarda-os já prontos em user://cache/:
## - os JSON de data/ num formato binário do Godot (var_to_bytes), que se lê ~2× mais depressa do que o texto;
## - as traduções (i18n/en.json + nomes e textos das cartas) já juntas, numa OptimizedTranslation (ler: ~0,2 ms;
##   juntá-las de novo: ~40 ms no computador, mais no telemóvel).
## Cada ficheiro guardado leva uma chave (versão da app e do conteúdo e o MD5 dos ficheiros de origem): se algo
## mudar (atualização, conteúdo descarregado, ficheiro editado), lê-se do original e guarda-se outra vez.

const DIR := "user://cache/"

static var enabled := true
static var hits := 0
static var misses := 0

static func key_for(paths: Array) -> String:
	var parts: PackedStringArray = ["app%d" % ContentUpdate.APP_VERSION_CODE, "c%d" % ContentUpdate.installed_version()]
	for p in paths:
		var real := String(p)
		parts.append(real.get_file() + ":" + (FileAccess.get_md5(real) if FileAccess.file_exists(real) else "-"))
	return "|".join(parts)

static func _file(name: String) -> String:
	return DIR + name.replace("/", "_").replace(":", "_")

## Os dados guardados com esta chave (null se não há ou a chave mudou).
static func load_var(name: String, key: String):
	if not enabled:
		return null
	var path := _file(name) + ".bin"
	if not FileAccess.file_exists(path):
		misses += 1
		return null
	var v = bytes_to_var(FileAccess.get_file_as_bytes(path))
	if v is Array and (v as Array).size() == 2 and String(v[0]) == key:
		hits += 1
		return v[1]
	misses += 1
	return null

static func save_var(name: String, key: String, data) -> void:
	if not enabled:
		return
	DirAccess.make_dir_recursive_absolute(DIR)
	var f := FileAccess.open(_file(name) + ".bin.tmp", FileAccess.WRITE)
	if f == null:
		return
	f.store_buffer(var_to_bytes([key, data]))
	f.close()
	DirAccess.rename_absolute(_file(name) + ".bin.tmp", _file(name) + ".bin")

## A tradução guardada (null se não há ou a chave mudou).
static func load_translation(name: String, key: String) -> Translation:
	if not enabled:
		return null
	var res := _file(name) + ".res"
	var kf := _file(name) + ".key"
	if not FileAccess.file_exists(res) or not FileAccess.file_exists(kf) or FileAccess.get_file_as_string(kf) != key:
		misses += 1
		return null
	var t := ResourceLoader.load(res, "", ResourceLoader.CACHE_MODE_IGNORE) as Translation
	if t != null:
		hits += 1
	return t

static func save_translation(name: String, key: String, t: Translation) -> Translation:
	if not enabled or t == null:
		return t
	DirAccess.make_dir_recursive_absolute(DIR)
	var o := OptimizedTranslation.new()
	o.generate(t)
	o.locale = t.locale
	if ResourceSaver.save(o, _file(name) + ".res") == OK:
		var f := FileAccess.open(_file(name) + ".key", FileAccess.WRITE)
		if f != null:
			f.store_string(key)
			f.close()
		return o
	return t

## Quanto ocupa a cache (bytes), para o Espaço ocupado das Configurações.
static func size_bytes() -> int:
	return Storage.dir_size(DIR)

static func clear() -> void:
	Storage.clear_dir(DIR)
