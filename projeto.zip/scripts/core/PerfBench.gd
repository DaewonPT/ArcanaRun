class_name PerfBench
extends RefCounted
## 0.19.0 (251, 253): teste de desempenho para o emulador do Actions (e para o modo programador).
## Se existir user://perf_test.flag (o Actions põe-no com «adb shell run-as»), o menu abre uma batalha cheia
## (5 criaturas, 6 cartas na mão, 5 relíquias), mede os FPS parado e durante o ataque, e escreve no registo
## «ZS_PERF …» e em user://perf_result.json. O Actions lê a linha e avisa se os FPS descerem.

const FLAG := "user://perf_test.flag"
const RESULT := "user://perf_result.json"
const IDLE_SECS := 4.0
const ATTACK_MAX := 20.0

static var last: Dictionary = {}

static func requested() -> bool:
	return FileAccess.file_exists(FLAG)

static func battle_state() -> Dictionary:
	var e: Dictionary = CardDB.enemy_def("bandit").duplicate(true)
	e["hp"] = 999999
	e["max_hp"] = 999999
	var hand: Array = []
	for id in ["c010", "c002", "c008", "c004", "c006", "c012"]:
		hand.append({"id": id, "entry": -1})
	var board: Array = []
	for id in ["c001", "c003", "c005", "c007", "c009"]:
		board.append({"id": id, "entry": -1})
	return {"enemy": e, "turn": 2, "max_turns": 5, "mana_total": 6, "mana_available": 6, "discards_left": 3,
		"player_hp": GameState.player_hp, "library": [{"id": "c011", "entry": -1}, {"id": "c013", "entry": -1}], "hand": hand,
		"graveyard": [], "board": board, "exile": []}

## Corre o teste (no SceneRouter, que sobrevive à troca de ecrã). Devolve o resultado.
static func run(router: Node) -> Dictionary:
	if FileAccess.file_exists(FLAG):
		DirAccess.remove_absolute(FLAG)
	var tree := router.get_tree()
	GameState.new_run("deck01", 4242)
	GameState.relic_ids.clear()
	for id in ["relic_drum", "relic_ruby", "relic_bolas_eye", "relic_mirror", "relic_anvil"]:
		if CardDB.relics.has(id):
			GameState.add_relic(id)
	GameState.pending_battle = battle_state()
	# A mão tem cartas e mana: sem isto, «Atacar sem gastar a mana?» ficava aberta e o ataque não chegava a
	# acontecer (no 1.º teste do emulador, steps=0). Não se grava: só vale para este arranque.
	var warn: bool = Settings.warn_mana
	Settings.warn_mana = false
	SceneRouter.go("battle")
	# O ecrã carrega noutro fio: esperar pela batalha (no emulador pode demorar mais de 3 s).
	var b: Node = null
	var t_wait := Time.get_ticks_msec()
	while Time.get_ticks_msec() - t_wait < 20000:
		await tree.process_frame
		var cs := tree.current_scene
		if cs != null and cs.has_method("_on_end_turn") and cs.get("battle") != null:
			b = cs
			break
	await tree.create_timer(1.5).timeout
	var idle := await _measure(tree, IDLE_SECS)
	var attack := 0.0
	var steps := 0
	if b != null and is_instance_valid(b):
		var t0 := Time.get_ticks_msec()
		var f0 := Engine.get_frames_drawn()
		b.call("_on_end_turn")
		while Time.get_ticks_msec() - t0 < ATTACK_MAX * 1000.0:
			await tree.process_frame
			var bm = b.get("battle")
			if bm != null and not bool(bm.resolving) and Time.get_ticks_msec() - t0 > 1500:
				break
		var secs := (Time.get_ticks_msec() - t0) / 1000.0
		attack = (Engine.get_frames_drawn() - f0) / maxf(0.01, secs)
		var c = b.get("_last_cascade")
		steps = (c as Cascade).steps.size() if c is Cascade else 0
	last = {"idle_fps": snappedf(idle, 0.1), "attack_fps": snappedf(attack, 0.1), "steps": steps,
		"nodes": int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT)),
		"static_mb": snappedf(Performance.get_monitor(Performance.MEMORY_STATIC) / 1048576.0, 0.1),
		"texture_mb": snappedf(Performance.get_monitor(Performance.RENDER_TEXTURE_MEM_USED) / 1048576.0, 0.1),
		"draw_calls": int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)),
		"model": OS.get_model_name(), "ram_mb": int(OS.get_memory_info().get("physical", 0) / 1048576)}
	var f := FileAccess.open(RESULT, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(last))
		f.close()
	print("ZS_PERF idle_fps=%s attack_fps=%s steps=%d nodes=%d static_mb=%s texture_mb=%s draw_calls=%d ram_mb=%d" % [last["idle_fps"], last["attack_fps"], steps,
		last["nodes"], last["static_mb"], last["texture_mb"], last["draw_calls"], last["ram_mb"]])
	GameState.clear_saved_run()
	Settings.warn_mana = warn
	return last

static func _measure(tree: SceneTree, secs: float) -> float:
	var t0 := Time.get_ticks_msec()
	var f0 := Engine.get_frames_drawn()
	await tree.create_timer(secs).timeout
	return (Engine.get_frames_drawn() - f0) / maxf(0.01, (Time.get_ticks_msec() - t0) / 1000.0)
