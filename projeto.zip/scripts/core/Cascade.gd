class_name Cascade
extends RefCounted
## Resultado de um ataque, calculado de uma vez e depois animado passo a passo pela UI.
## Dano final = Poder × Mult. Cada Step regista quem disparou, o que fez e o estado a seguir.

class Step:
	var source_kind: String = ""     # "creature" | "spell" | "formation" | "hand" | "relic" | "library"
	var source_name: String = ""
	var source_card: CardInstance = null   # criatura/feitiço/carta na mão que disparou
	var source_id: String = ""             # relic id ou formation id
	var action: String = ""          # "power_add" | "mult_add" | "mult_mul" | "gold"
	var value: float = 0.0
	var label: String = ""           # "+3 Poder", "+2 Mult", "×1.5 Mult", "Reativa"
	var grow: int = 0                # crescimento permanente a aplicar à criatura (verde)
	var retrigger: bool = false      # passo vindo de uma reativação (para a UI assinalar)
	var power_after: int = 0
	var mult_after: float = 1.0

var steps: Array[Step] = []
var power: int = 0
var mult: float = 1.0
var formations: Array[String] = []   # nomes das formações ativas (para a UI)
var formation_ids: Array[String] = []
var gold: int = 0                    # ouro ganho durante a cascata (aplicado no fim)
var damage_mult: float = 1.0         # vulnerabilidade do inimigo (Maldição das Correntes)

func total() -> int:
	return int(round(power * mult * damage_mult))

func is_empty() -> bool:
	return steps.is_empty()

func add(step: Step) -> Step:
	match step.action:
		"power_add":
			power += int(step.value)
		"mult_add":
			mult += step.value
		"mult_mul":
			mult *= step.value
		"gold":
			gold += int(step.value)
	step.power_after = power
	step.mult_after = mult
	steps.append(step)
	return step

static func fmt_mult(m: float) -> String:
	return str(int(m)) if is_equal_approx(m, floor(m)) else ("%.1f" % m)

static func fmt_int(n: int) -> String:
	# 12345 -> "12 345"
	var s := str(n)
	var out := ""
	var count := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		count += 1
		if count % 3 == 0 and i > 0:
			out = " " + out
	return out

static func label_for(action: String, value: float) -> String:
	match action:
		"power_add":
			return TranslationServer.translate("+%d Poder") % int(value)
		"mult_add":
			return TranslationServer.translate("+%s Mult") % fmt_mult(value)
		"mult_mul":
			return TranslationServer.translate("×%s Mult") % fmt_mult(value)
		"gold":
			return TranslationServer.translate("+%d ouro") % int(value)
	return ""
