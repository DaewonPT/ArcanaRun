class_name Cascade
extends RefCounted
## Resultado de um ataque, calculado de uma vez e depois animado passo a passo pela UI.
## Dano final = Poder × Mult. Cada Step regista quem disparou, o que fez e o estado a seguir.

class Step:
	var source_kind: String = ""     # "creature" | "formation" | "relic"
	var source_name: String = ""
	var source_card: CardInstance = null   # quando source_kind == "creature"
	var source_id: String = ""             # relic id ou formation id
	var action: String = ""          # "power_add" | "mult_add" | "mult_mul"
	var value: float = 0.0
	var label: String = ""           # "+3 Poder", "+2 Mult", "×1.5 Mult"
	var grow: int = 0                # crescimento permanente a aplicar à criatura (verde)
	var power_after: int = 0
	var mult_after: float = 1.0

var steps: Array[Step] = []
var power: int = 0
var mult: float = 1.0
var formations: Array[String] = []   # nomes das formações ativas (para a UI)

func total() -> int:
	return int(round(power * mult))

func is_empty() -> bool:
	return steps.is_empty()

func add(step: Step) -> Step:
	match step.action:
		"power_add":
			power += int(step.value)
		"mult_add":
			mult += step.value
		"mult_mul":
			mult *= step.value
	step.power_after = power
	step.mult_after = mult
	steps.append(step)
	return step

static func fmt_mult(m: float) -> String:
	return str(int(m)) if is_equal_approx(m, floor(m)) else ("%.1f" % m)

static func label_for(action: String, value: float) -> String:
	match action:
		"power_add":
			return "+%d Poder" % int(value)
		"mult_add":
			return "+%s Mult" % fmt_mult(value)
		"mult_mul":
			return "×%s Mult" % fmt_mult(value)
	return ""
