class_name Cascade
extends RefCounted
## Resultado de um ataque, calculado de uma vez e depois animado passo a passo pela UI.
## Dano final = Poder × Mult. Cada Step regista quem disparou, o que fez e o estado a seguir.

class Step:
	var source_kind: String = ""     # "creature" | "spell" | "formation" | "chain" | "seal_set" | "tribe" | "enchantment" | "equipment" (0.18.0) |
	                                 # "hand" | "relic" | "library" | "planeswalker" | "climate" | "rule"
	var tag: String = ""             # "seal" (selo de guilda) | "level" (formação com nível) | "minion" (bloqueado) | "" — para a UI colorir
	var level: int = 0               # nível da formação (Selo da Sabedoria)
	var source_name: String = ""
	var source_card: CardInstance = null   # criatura/feitiço/carta na mão que disparou
	var source_id: String = ""             # relic id ou formation id
	var action: String = ""          # "power_add" | "mult_add" | "mult_mul" | "gold" | "heal" | "self_damage"
	var value: float = 0.0
	var label: String = ""           # "+3 Poder", "+2 Mult", "×1.5 Mult", "Reativa"
	var grow: int = 0                # crescimento permanente a aplicar à criatura (verde)
	var retrigger: bool = false      # passo vindo de uma reativação (para a UI assinalar)
	var power_after: int = 0
	var mult_after: float = 1.0

var steps: Array[Step] = []
var power: int = 0
var mult: float = 1.0
var formations: Array[String] = []   # nomes das formações ativas (para a UI)
var formation_ids: Array[String] = []
var formation_levels: Array[int] = []  # nível de cada uma (0 = base)
var gold: int = 0                    # ouro ganho durante a cascata (aplicado no fim)
var heal: int = 0                    # vida curada (Sino de Casamento), aplicada no fim
var self_damage: int = 0             # vida perdida pelo próprio ataque (Demónio Corrompido)
var damage_mult: float = 1.0         # vulnerabilidade do inimigo (Grilhões Espectrais)
var shield: int = 0                  # escudo do inimigo: absorve os primeiros X do ataque
var chain_len: int = 0               # maior Cadeia de cor deste ataque (para a UI)
var chain_color: String = ""
var energy_spent: int = 0            # 0.15.0: Energia gasta pelas cartas neste ataque (descontada no fim)

func total() -> int:
	return int(round(power * mult * damage_mult))

## Dano que chega ao inimigo depois do escudo.
func net_total() -> int:
	return maxi(0, total() - shield)

func is_empty() -> bool:
	return steps.is_empty()

func add(step: Step) -> Step:
	match step.action:
		"power_add":
			power += int(step.value)
		"mult_add":
			mult += step.value
		"mult_mul":
			mult *= step.value
		"gold":
			gold += int(step.value)
		"heal":
			heal += int(step.value)
		"self_damage":
			self_damage += int(step.value)
	step.power_after = power
	step.mult_after = mult
	steps.append(step)
	return step

static func fmt_mult(m: float) -> String:
	return str(int(m)) if is_equal_approx(m, floor(m)) else ("%.1f" % m)

static func fmt_int(n: int) -> String:
	# 12345 -> "12 345" (0.15.0: o sinal dos negativos já não conta como algarismo)
	var s := str(absi(n))
	var out := ""
	var count := 0
	var sep := thousands_sep()
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		count += 1
		if count % 3 == 0 and i > 0:
			out = sep + out
	return ("-" + out) if n < 0 else out

## 0.19.0 (294): o separador dos milhares — com espaço (por omissão), à portuguesa (12.345) ou à inglesa (12,345).
static func thousands_sep() -> String:
	match String(Settings.opt("number_format")):
		"pt":
			return "."
		"en":
			return ","
	return " "

## 0.15.0: números muito grandes abreviados — 1,2 M (milhões), 3,4 mM (mil milhões), 5,6 Bi (biliões); em
## inglês 1.2M, 3.4B, 5.6T. Abaixo de um milhão fica o número inteiro com espaços (fmt_int).
static func fmt_short(n: int) -> String:
	var a := absi(n)
	if a < 1000000:
		return fmt_int(n)
	var en := TranslationServer.get_locale().begins_with("en")
	var units := [[1000000000000, "Bi", "T"], [1000000000, "mM", "B"], [1000000, "M", "M"]]
	for u in units:
		var base := int(u[0])
		if a >= base:
			var v := float(n) / float(base)
			var txt := ("%.1f" % v) if absf(v) < 100.0 else str(int(v))
			if txt.ends_with(".0"):
				txt = txt.substr(0, txt.length() - 2)
			return (txt + String(u[2])) if en else (txt.replace(".", ",") + " " + String(u[1]))
	return fmt_int(n)

static func label_for(action: String, value: float) -> String:
	match action:
		"power_add":
			return TranslationServer.translate("+%d Poder") % int(value)
		"mult_add":
			return TranslationServer.translate("+%s Mult") % fmt_mult(value)
		"mult_mul":
			return TranslationServer.translate("×%s Mult") % fmt_mult(value)
		"gold":
			return TranslationServer.translate("+%d ouro") % int(value)
		"heal":
			return TranslationServer.translate("+%d vida") % int(value)
		"self_damage":
			return TranslationServer.translate("−%d vida") % int(value)
	return ""
