class_name Economy
extends RefCounted
## 0.19.0 (secção 3 — loot e economia): as contas da run e as peças novas da economia.
##  • O estado da run vive em GameState.econ (grava-se com a run): proteção contra azar (74), reserva (79),
##    empréstimo (84), desconto do booster (76), cartas depois das batalhas (75), troca de relíquias (95), último
##    uso do ouro (86), risco a troco de ouro (100) e as lojas da Torre e da Corrida (87, 88).
##  • O que aconteceu ao ouro fica no run_log: por ante (72), por categoria e o que se comprou (73), por ato (92) e
##    o que cada Vale deu (98). Entre runs (GameState.progress): o ouro que cada talento rendeu (99) e os
##    fragmentos dos cosméticos (90).

const RARE_PITY := 6              # 74: lojas seguidas sem uma rara → a seguinte mostra uma
const RESERVE_PRICE := 1          # 79
const LOAN_AMOUNT := 10           # 84: o Mercador Cego empresta 10…
const LOAN_DUE := 13              # …e cobra 13 na loja seguinte
const BOOSTER_RENEW_PRICE := 2    # 81
const LOOT_RENEW_PRICE := 6       # 82
const HAGGLE_PCT := 0.2           # 83: ±20 % nas ofertas desta visita…
const HAGGLE_WIN := 0.6           # …com 60 % de sair desconto
const CARD_SKIP_GOLD := 2         # 75: saltar a carta depois da batalha
const FINAL_HP_COST := 2          # 86: 1 de vida por cada 2 ouro…
const FINAL_TALENT_COST := 10     # …ou 1 ponto de talento por cada 10
const FIRST_WIN_DECK := 3         # 89: 1.ª vitória com um baralho…
const FIRST_WIN_STAKE := 2        # …e com cada Selo Planar novo
const FRAGMENT_PRICES := {"back": 25, "frame": 30, "mat": 35, "effect": 40}   # 90
const TOWER_SHOP_EVERY := 5       # 87: a loja da Torre abre nos andares de boss
const RUSH_SHOP_EVERY := 3        # 88: o Mercador da Corrida, de 3 em 3 bosses
const RUSH_BOSS_GOLD := 8
const SIDE_HEAL_PCT := 0.3
const SIDE_HEAL_PRICE := 6
const RELIC_WEIGHTS := {"common": 60.0, "uncommon": 30.0, "rare": 10.0}
const ELITE_RARITY_W := {"common": 50.0, "uncommon": 35.0, "rare": 15.0}
const RARITY_ORDER := ["common", "uncommon", "rare", "mythic"]
const RARITY_NAMES := {"common": "Comum", "uncommon": "Incomum", "rare": "Rara", "mythic": "Mítica"}
## 100: regras difíceis a troco de ouro (o ouro é `gold` + o ante).
const RISKS := [
	{"id": "hp", "text": "O inimigo tem +30 % de vida.", "gold": 4},
	{"id": "turn", "text": "Tens menos 1 turno.", "gold": 5},
	{"id": "atk", "text": "O inimigo ataca +2.", "gold": 3},
]
const RISK_HP_MULT := 1.3
const RISK_ATTACK := 2
## 73: nomes das categorias de gastos.
const SPENT_NAMES := {"card": "Cartas", "relic": "Relíquias", "service": "Serviços", "reroll": "Novas ofertas", "booster": "Boosters",
	"voucher": "Vales", "item": "Poções e pergaminhos", "pw": "Patronos", "constellation": "Constelações", "reserve": "Reservas",
	"event": "Eventos", "loan": "Empréstimos", "final": "Último uso do ouro", "other": "Outros"}

static func _e() -> Dictionary:
	return GameState.econ

static func _rl() -> Dictionary:
	GameState._ensure_run_log()
	return GameState.run_log

static func _dict(d: Dictionary, key: String) -> Dictionary:
	if not (d.get(key) is Dictionary):
		d[key] = {}
	return d[key]

# --- 72, 73, 92: o que acontece ao ouro ---

## Chamado por GameState.add_gold / spend_gold: o ouro que entrou ou saiu, por ante, por categoria e por ato.
static func log_gold(delta: int, reason: String) -> void:
	if delta == 0 or GameState.puzzle_id != "" or GameState.deck_def.is_empty():
		return
	var rl := _rl()
	var by := _dict(rl, "gold_by_ante")
	var key := str(GameState.ante)
	var row: Dictionary = by.get(key, {}) if by.get(key) is Dictionary else {}
	if delta > 0:
		row["in"] = int(row.get("in", 0)) + delta
		if reason == "interest":
			row["interest"] = int(row.get("interest", 0)) + delta
		elif reason == "sale":
			row["sold"] = int(row.get("sold", 0)) + delta
		_act_add("gold", delta)
	else:
		row["out"] = int(row.get("out", 0)) - delta
		var spent := _dict(rl, "spent")
		var cat := reason if reason != "" else "other"
		spent[cat] = int(spent.get(cat, 0)) - delta
	by[key] = row

static func _act_add(kind: String, n: int) -> void:
	if GameState.puzzle_id != "" or GameState.mode in ["tower", "rush"]:
		return
	var acts := _dict(_rl(), "act_log")
	var k := str(GameState.act_of_ante(GameState.ante))
	var row: Dictionary = acts.get(k, {}) if acts.get(k) is Dictionary else {}
	row[kind] = int(row.get(kind, 0)) + n
	acts[k] = row

static func note_card_gained() -> void:
	_act_add("cards", 1)

static func note_relic_gained() -> void:
	_act_add("relics", 1)

## 92: o que se ganhou num ato: {"gold", "cards", "relics"}.
static func act_summary(act: int) -> Dictionary:
	var acts: Dictionary = GameState.run_log.get("act_log", {}) if GameState.run_log.get("act_log") is Dictionary else {}
	return acts.get(str(act), {}) if acts.get(str(act)) is Dictionary else {}

## 73: uma compra (para «a compra que mais rendeu»).
static func note_purchase(kind: String, id: String, price: int) -> void:
	var rl := _rl()
	if not (rl.get("bought") is Array):
		rl["bought"] = []
	(rl["bought"] as Array).append({"k": kind, "id": id, "p": price, "a": GameState.ante})

## 73: a carta ou relíquia comprada que mais dano deu: {"k", "id", "p", "dmg"} ({} se nenhuma deu).
static func best_purchase(rl: Dictionary = {}) -> Dictionary:
	var log_: Dictionary = rl if not rl.is_empty() else GameState.run_log
	var best := {}
	var cd: Dictionary = log_.get("card_dmg", {}) if log_.get("card_dmg") is Dictionary else {}
	var rd: Dictionary = log_.get("relic_dmg", {}) if log_.get("relic_dmg") is Dictionary else {}
	for b in log_.get("bought", []):
		if not (b is Dictionary):
			continue
		var k := String(b.get("k", ""))
		var id := String(b.get("id", ""))
		var dmg := int(cd.get(id, 0)) if k == "card" else (int(rd.get(id, 0)) if k == "relic" else 0)
		if dmg > int(best.get("dmg", 0)):
			best = {"k": k, "id": id, "p": int(b.get("p", 0)), "dmg": dmg}
	return best

## 72: [{"ante", "in", "out", "interest", "sold"}] pela ordem dos antes.
static func gold_rows(rl: Dictionary = {}) -> Array:
	var log_: Dictionary = rl if not rl.is_empty() else GameState.run_log
	var by: Dictionary = log_.get("gold_by_ante", {}) if log_.get("gold_by_ante") is Dictionary else {}
	var last := 0
	for k in by:
		last = maxi(last, int(k))
	var out: Array = []
	for a in range(1, last + 1):
		var r: Dictionary = by.get(str(a), {}) if by.get(str(a)) is Dictionary else {}
		out.append({"ante": a, "in": int(r.get("in", 0)), "out": int(r.get("out", 0)), "interest": int(r.get("interest", 0)), "sold": int(r.get("sold", 0))})
	return out

## 73: «Cartas 24 · Relíquias 18…», do que mais gastaste para o que menos.
static func spent_lines(rl: Dictionary = {}) -> Array[String]:
	var log_: Dictionary = rl if not rl.is_empty() else GameState.run_log
	var spent: Dictionary = log_.get("spent", {}) if log_.get("spent") is Dictionary else {}
	var keys: Array = spent.keys()
	keys.sort_custom(func(a, b): return int(spent[a]) > int(spent[b]))
	var out: Array[String] = []
	for k in keys:
		if int(spent[k]) > 0:
			out.append(TranslationServer.translate("%s: %d ouro") % [TranslationServer.translate(String(SPENT_NAMES.get(String(k), String(k)))), int(spent[k])])
	return out

# --- 98, 99: quanto deu cada Vale e cada talento ---

static func credit_voucher(effect_key: String, amount: int) -> void:
	if amount <= 0:
		return
	for vid in GameState.vouchers:
		if (CardDB.get_voucher(vid).get("effect", {}) as Dictionary).has(effect_key):
			var vg := _dict(_rl(), "voucher_gold")
			vg[vid] = int(vg.get(vid, 0)) + amount
			return

static func voucher_gold(vid: String) -> int:
	var vg = GameState.run_log.get("voucher_gold", {})
	return int((vg as Dictionary).get(vid, 0)) if vg is Dictionary else 0

## O que um Vale fez nesta run (para «A minha run»): ouro, ou o efeito que está sempre ligado.
static func voucher_result(vid: String) -> String:
	var g := voucher_gold(vid)
	if g > 0:
		return TranslationServer.translate("Este Vale já te deu +%d ouro.") % g
	var eff: Dictionary = CardDB.get_voucher(vid).get("effect", {})
	for k in ["interest_cap", "reward_plus", "service_discount", "reroll_discount"]:
		if eff.has(k):
			return TranslationServer.translate("Ainda não te deu ouro nesta run.")
	return TranslationServer.translate("Sempre ligado até ao fim da run.")

static func credit_talent(effect: String, amount: int) -> void:
	if amount <= 0 or GameState.talent_value(effect) <= 0.0:
		return
	for t in CardDB.talents:
		if not (t is Dictionary) or String(t.get("effect", "")) != effect:
			continue
		var tid := String(t.get("id", ""))
		if GameState.talent_level(tid) <= 0:
			continue
		var tg := _dict(GameState.progress, "talent_gold")
		tg[tid] = int(tg.get(tid, 0)) + amount
		return

static func talent_gold(tid: String) -> int:
	var tg = GameState.progress.get("talent_gold", {})
	return int((tg as Dictionary).get(tid, 0)) if tg is Dictionary else 0

## O desconto do talento Freguês nesta compra (a diferença para o preço sem ele).
static func talent_discount(base: int) -> int:
	var t := int(GameState.talent_value("shop_discount"))
	if t <= 0:
		return 0
	var full := maxi(1, base + int(GameState.relic_passive("shop_tax")))
	return maxi(0, full - GameState.shop_price(base))

# --- 69: juros ---

static func interest_for(g: int, cap: int) -> int:
	var due := mini(cap, int(maxi(0, g) / 5))
	if "relic_double_tithe" in GameState.relic_ids:
		due = mini(cap * 2, due * 2)
	return due

## Os juros que se ganham na próxima loja saindo desta com `g` de ouro.
static func next_interest(g: int) -> int:
	return interest_for(g, GameState.interest_cap())

## Juros pagos agora: o que veio do Vale do Cofre e do talento Investidor (98, 99).
static func credit_interest(g: int) -> void:
	var v := int(GameState.voucher_value("interest_cap"))
	var t := int(GameState.talent_value("interest_cap"))
	var cap := GameState.interest_cap()
	credit_voucher("interest_cap", interest_for(g, cap) - interest_for(g, cap - v))
	credit_talent("interest_cap", interest_for(g, cap - v) - interest_for(g, cap - v - t))

# --- 71: ouro previsto para a próxima loja ---

## {"gold", "battle", "interest", "loan", "total"}: o que tens, o da batalha (Batedor, 2 turnos a sobrar), os juros.
static func next_shop_forecast() -> Dictionary:
	var g := GameState.gold
	var b := 0
	if GameState.map_phase == "battle":
		var opts: Array = GameState.map_options(GameState.ante).get("battle", [])
		var variant := "scout" if "scout" in opts else (String(opts[0]) if not opts.is_empty() else "scout")
		b = GameState.battle_gold_for(variant, 2)
		var rk := risk_active()
		if not rk.is_empty():
			b += int(rk.get("gold", 0))
	var debt := loan()
	var before := maxi(0, g + b - debt)
	var interest := 0 if GameState.interest_ante == GameState.ante and GameState.map_phase != "battle" else next_interest(before)
	return {"gold": g, "battle": b, "interest": interest, "loan": debt, "total": before + interest}

# --- 67: probabilidades ---

## Raridade → % entre as cartas que a loja pode oferecer (ponderadas como a loja) ou do booster (todas iguais).
static func card_odds(weighted: bool = true) -> Dictionary:
	var by := {}
	var tot := 0.0
	for c in CardDB.shop_pool():
		var w := float(CardDB.SHOP_WEIGHTS.get(c.rarity, 1.0)) if weighted else 1.0
		by[c.rarity] = float(by.get(c.rarity, 0.0)) + w
		tot += w
	return _pct(by, tot)

## Raridade → % de uma relíquia oferecida na loja (das que ainda não tens).
static func relic_odds() -> Dictionary:
	var by := {}
	var tot := 0.0
	for r in CardDB.relics.values():
		if String(r.get("id", "")) in GameState.relic_ids or bool(r.get("legendary", false)) or bool(r.get("boss", false)) or not CardDB.is_relic_available(r):
			continue
		var rar := String(r.get("rarity", "common"))
		var w := float(RELIC_WEIGHTS.get(rar, 30.0))
		by[rar] = float(by.get(rar, 0.0)) + w
		tot += w
	return _pct(by, tot)

static func _pct(by: Dictionary, tot: float) -> Dictionary:
	var out := {}
	if tot <= 0.0:
		return out
	for k in by:
		out[k] = 100.0 * float(by[k]) / tot
	return out

## «Comum 45 % · Incomum 30 % · Rara 21 % · Mítica 4 %».
static func odds_text(d: Dictionary) -> String:
	var parts: Array[String] = []
	for k in RARITY_ORDER:
		if d.has(k):
			parts.append("%s %s %%" % [TranslationServer.translate(String(RARITY_NAMES[k])), _pct_str(float(d[k]))])
	return "  ·  ".join(PackedStringArray(parts))

static func _pct_str(v: float) -> String:
	if v >= 10.0 or is_equal_approx(v, roundf(v)):
		return str(int(round(v)))
	return GameState.fmt_dec(snappedf(v, 0.1))

# --- 74: proteção contra azar ---

static func is_rare(c: CardData) -> bool:
	return c != null and String(c.rarity) in ["rare", "mythic"]

static func drought() -> int:
	return int(_e().get("rare_drought", 0))

## Lojas até a rara ser garantida (contando esta) — 0 se a desta loja foi garantida.
static func pity_in() -> int:
	return maxi(1, RARE_PITY + 1 - drought())

## Primeiras ofertas de uma visita: se já houve RARE_PITY lojas sem raras, a última oferta passa a ser uma rara.
## Atualiza a contagem. Devolve true se a rara foi garantida.
static func apply_pity(offers: Array[CardData], editions: Array[String], rng: RandomNumberGenerator) -> bool:
	var has := offers.any(is_rare)
	var forced := false
	if not has and drought() >= RARE_PITY and not offers.is_empty():
		var rares: Array = CardDB.shop_pool().filter(func(c): return is_rare(c) and not (c in offers))
		if not rares.is_empty():
			var pick: CardData = rares[rng.randi_range(0, rares.size() - 1)]
			offers[offers.size() - 1] = pick
			if editions.size() >= offers.size():
				editions[offers.size() - 1] = GameState.roll_edition(pick)
			forced = true
			has = true
	_e()["rare_drought"] = 0 if has else drought() + 1
	return forced

## NOVAS OFERTAS com uma rara também acabam com a seca.
static func note_reroll(offers: Array[CardData]) -> void:
	if offers.any(is_rare):
		_e()["rare_drought"] = 0

# --- 79: reservar ---

static func reserved() -> Dictionary:
	return _e().get("reserve", {}) if _e().get("reserve") is Dictionary else {}

static func reserve(kind: String, id: String, edition: String = "") -> bool:
	if not reserved().is_empty() or not GameState.spend_gold(RESERVE_PRICE, "reserve"):
		return false
	_e()["reserve"] = {"kind": kind, "id": id, "edition": edition, "ante": GameState.ante}
	return true

## A reserva para a loja de agora (só numa loja de um ante a seguir ao da reserva); sai da reserva.
static func take_reserved() -> Dictionary:
	var r := reserved()
	if r.is_empty() or int(r.get("ante", 0)) >= GameState.ante:
		return {}
	_e().erase("reserve")
	return r

# --- 84: empréstimo do Mercador Cego ---

static func loan() -> int:
	return int(_e().get("loan", 0))

static func take_loan() -> bool:
	if loan() > 0:
		return false
	_e()["loan"] = LOAN_DUE
	_e()["loan_ante"] = GameState.ante
	GameState.add_gold(LOAN_AMOUNT, "loan")
	return true

## Na loja seguinte (outro ante): paga o que der; o que faltar fica para a próxima. Devolve o que pagou.
static func pay_loan() -> int:
	var due := loan()
	if due <= 0 or int(_e().get("loan_ante", 0)) >= GameState.ante:
		return 0
	var paid := mini(due, GameState.gold)
	if paid > 0:
		GameState.spend_gold(paid, "loan")
	_e()["loan"] = due - paid
	if loan() <= 0:
		_e().erase("loan")
		_e().erase("loan_ante")
	return paid

# --- 76: o booster que não serviu ---

static func booster_half() -> bool:
	return bool(_e().get("booster_half", false))

static func set_booster_half(on: bool) -> void:
	if on:
		_e()["booster_half"] = true
	else:
		_e().erase("booster_half")

# --- 82: renovar o Baú de Espólio ---

static func loot_renewed() -> bool:
	return int(_e().get("loot_renewed", 0)) == GameState.ante

static func renew_loot() -> bool:
	if loot_renewed() or GameState.loot_offer.is_empty() or not GameState.spend_gold(GameState.shop_price(LOOT_RENEW_PRICE), "service"):
		return false
	_e()["loot_renewed"] = GameState.ante
	var old: Array = GameState.loot_offer.duplicate()
	var pool: Array = CardDB.relics.values().filter(func(r): return bool(r.get("boss", false)) and not (String(r.get("id", "")) in GameState.boss_relics) and not (String(r.get("id", "")) in old))
	if pool.is_empty():
		pool = CardDB.relics.values().filter(func(r): return bool(r.get("boss", false)) and not (String(r.get("id", "")) in GameState.boss_relics))
	var r := RandomNumberGenerator.new()
	r.seed = GameState.seed_value * 23 + GameState.ante * 50021
	GameState.loot_offer.clear()
	for i in GameState.LOOT_CHOICES:
		if pool.is_empty():
			break
		var pick: Dictionary = pool[r.randi_range(0, pool.size() - 1)]
		pool.erase(pick)
		GameState.loot_offer.append(String(pick.get("id", "")))
	return true

# --- 96: a raridade da relíquia de cada Elite (sorteio próprio por ante) ---

static func elite_rarity(a: int) -> String:
	var r := RandomNumberGenerator.new()
	r.seed = GameState.seed_value * 61 + a * 977
	var tot := 0.0
	for k in ELITE_RARITY_W:
		tot += float(ELITE_RARITY_W[k])
	var roll := r.randf() * tot
	for k in ELITE_RARITY_W:
		roll -= float(ELITE_RARITY_W[k])
		if roll <= 0.0:
			return String(k)
	return "common"

# --- 100: risco a troco de ouro ---

## A regra difícil que se pode aceitar antes da batalha deste ante (sorteio próprio).
static func risk_offer(a: int) -> Dictionary:
	var r := RandomNumberGenerator.new()
	r.seed = GameState.seed_value * 211 + a * 6151
	var d: Dictionary = (RISKS[r.randi_range(0, RISKS.size() - 1)] as Dictionary).duplicate()
	d["gold"] = int(d.get("gold", 3)) + a
	return d

static func risk_allowed() -> bool:
	return GameState.map_phase == "battle" and not GameState.arena_battle and not (GameState.mode in ["tower", "rush"]) \
		and GameState.puzzle_id == "" and not GameState.is_boss_ante(GameState.ante)

## O risco aceite para a batalha deste ante ({} se nenhum).
static func risk_active() -> Dictionary:
	var rk = _e().get("risk", {})
	if not (rk is Dictionary) or int((rk as Dictionary).get("ante", 0)) != GameState.ante or GameState.arena_battle:
		return {}
	return rk

static func set_risk(on: bool) -> void:
	if on and risk_allowed():
		var d := risk_offer(GameState.ante)
		d["ante"] = GameState.ante
		_e()["risk"] = d
	else:
		_e().erase("risk")

static func risk_is(id: String) -> bool:
	return String(risk_active().get("id", "")) == id

static func clear_risk() -> void:
	_e().erase("risk")

# --- 75: uma carta depois de cada batalha (opção da run) ---

static func card_rewards_on() -> bool:
	return bool(_e().get("card_rewards", false))

static func set_card_rewards(on: bool) -> void:
	_e()["card_rewards"] = on

static func pending_card_reward() -> Array:
	return (_e().get("card_reward", []) as Array) if _e().get("card_reward") is Array else []

## Depois de uma batalha ganha: 3 cartas das cores do baralho (sorteio próprio por ante e batalha).
static func prepare_card_reward() -> void:
	var r := RandomNumberGenerator.new()
	r.seed = GameState.seed_value * 131 + GameState.ante * 17 + (7 if GameState.arena_battle else 0)
	var ids: Array = []
	for c in CardDB.random_shop_offers(3, r):
		ids.append(c.id)
	if not ids.is_empty():
		_e()["card_reward"] = ids

static func take_card_reward(id: String) -> bool:
	if not (id in pending_card_reward()):
		return false
	var cd := CardDB.get_card(id)
	_e().erase("card_reward")
	if cd == null:
		return false
	GameState.add_card(id, false, GameState.roll_edition(cd))
	return true

static func skip_card_reward() -> int:
	if pending_card_reward().is_empty():
		return 0
	_e().erase("card_reward")
	GameState.add_gold(CARD_SKIP_GOLD)
	return CARD_SKIP_GOLD

# --- 86: o último uso do ouro, antes do boss final ---

static func final_trade_due() -> bool:
	return not GameState.endless and GameState.ante >= GameState.max_ante and GameState.is_boss_ante(GameState.ante) \
		and GameState.map_phase == "battle" and GameState.gold >= FINAL_HP_COST and not bool(_e().get("final_trade", false)) \
		and not (GameState.mode in ["tower", "rush"]) and GameState.puzzle_id == ""

## "hp" (vida), "talent" (pontos de talento) ou "keep". Devolve o texto do resultado.
static func final_trade(kind: String) -> String:
	_e()["final_trade"] = true
	match kind:
		"hp":
			var n := int(GameState.gold / FINAL_HP_COST)
			if n <= 0:
				return ""
			GameState.spend_gold(n * FINAL_HP_COST, "final")
			GameState.change_max_hp(n)
			GameState.heal(n)
			return TranslationServer.translate("+%d de vida máxima (e curas %d).") % [n, n]
		"talent":
			var t := int(GameState.gold / FINAL_TALENT_COST)
			if t <= 0:
				return ""
			GameState.spend_gold(t * FINAL_TALENT_COST, "final")
			GameState.progress["talent_points"] = GameState.talent_points() + t
			GameState.save_progress()
			return TranslationServer.translate("+%d pontos de talento.") % t
	return ""

# --- 95: trocar uma relíquia (uma vez por run) ---

static func can_trade_relic() -> bool:
	return not bool(_e().get("relic_trade", false)) and GameState.relics_allowed()

## Troca a relíquia por outra da mesma raridade, ao acaso, no mesmo lugar. Devolve o id novo ("" se não deu).
static func trade_relic(rid: String) -> String:
	if not can_trade_relic() or not (rid in GameState.relic_ids):
		return ""
	var rar := String(CardDB.relics.get(rid, {}).get("rarity", "common"))
	var pool: Array = CardDB.relics.keys().filter(func(k): return not (k in GameState.relic_ids) and String(CardDB.relics[k].get("rarity", "common")) == rar \
		and not bool(CardDB.relics[k].get("legendary", false)) and not bool(CardDB.relics[k].get("boss", false)) and CardDB.is_relic_available(CardDB.relics[k]))
	if pool.is_empty():
		return ""
	var r := RandomNumberGenerator.new()
	r.seed = GameState.seed_value * 307 + GameState.ante * 31337
	var nid := String(pool[r.randi_range(0, pool.size() - 1)])
	var at := GameState.relic_ids.find(rid)
	GameState.remove_relic(rid)
	if not GameState.add_relic(nid):
		GameState.add_relic(rid)
		return ""
	GameState.move_relic(nid, at)
	_e()["relic_trade"] = true
	return nid

# --- 77, 78: vender poções e cartas ---

static func consumable_sale_value(id: String) -> int:
	return maxi(1, int(CardDB.get_consumable(id).get("price", 4)) / 2)

## Remover uma carta na loja devolve 1 a 3 ouro conforme a raridade (as maldições e as fichas não valem nada).
static func card_sale_value(cd: CardData) -> int:
	if cd == null or cd.is_curse() or cd.token:
		return 0
	match String(cd.rarity):
		"uncommon":
			return 2
		"rare", "mythic":
			return 3
	return 1

# --- 87, 88: a loja da Torre e o Mercador da Corrida ---

## Ouro de uma batalha ganha na Torre (mais nos andares de boss) e na Corrida.
static func side_gold_for_win() -> int:
	if GameState.mode == "tower":
		var g := 2 + int(GameState.ante / 5)
		return g * 3 if GameState.is_boss_ante(GameState.ante) else g
	if GameState.mode == "rush":
		return RUSH_BOSS_GOLD
	return 0

## A loja abre-se agora? (Torre: no prémio de um andar de boss; Corrida: antes do boss 4, 7, 10…)
static func side_shop_open() -> bool:
	if GameState.mode == "tower":
		return GameState.tower_phase == "reward" and GameState.ante % TOWER_SHOP_EVERY == 0
	if GameState.mode == "rush":
		return GameState.ante > 1 and (GameState.ante - 1) % RUSH_SHOP_EVERY == 0
	return false

## As ofertas desta loja (sorteio próprio; gravam-se com a run): {"key", "cards", "editions", "relic", "item", "bought"}.
static func side_shop() -> Dictionary:
	var key := "%s:%d" % [GameState.mode, GameState.ante]
	var cur = _e().get("side_shop", {})
	if cur is Dictionary and String((cur as Dictionary).get("key", "")) == key:
		return cur
	var r := RandomNumberGenerator.new()
	r.seed = GameState.seed_value * 409 + GameState.ante * 7027
	var cards: Array = []
	var eds: Array = []
	for c in CardDB.random_shop_offers(3, r):
		cards.append(c.id)
		eds.append("")
	var rel := ""
	if GameState.relics_allowed():
		var ro := CardDB.random_relic_offer(r, GameState.relic_ids.duplicate())
		rel = String(ro.get("id", ""))
	var pool: Array = CardDB.consumables
	var item := String(pool[r.randi_range(0, pool.size() - 1)].get("id", "")) if not pool.is_empty() else ""
	var d := {"key": key, "cards": cards, "editions": eds, "relic": rel, "item": item, "bought": []}
	_e()["side_shop"] = d
	return d

static func side_bought(key: String) -> bool:
	return key in (side_shop().get("bought", []) as Array)

static func side_price(kind: String, id: String) -> int:
	match kind:
		"card":
			var cd := CardDB.get_card(id)
			return GameState.shop_price(cd.price if cd != null else 5)
		"relic":
			return GameState.shop_price(int(CardDB.relics.get(id, {}).get("price", 6)))
		"item":
			return GameState.shop_price(int(CardDB.get_consumable(id).get("price", 4)))
		"heal":
			return GameState.shop_price(SIDE_HEAL_PRICE)
	return 99

static func side_heal_amount() -> int:
	return maxi(1, int(round(GameState.player_max_hp * SIDE_HEAL_PCT)))

## Compra na loja da Torre / do Mercador da Corrida. `replace`: a relíquia que sai quando estão cheias.
## Devolve o texto do aviso ("" se não comprou).
static func side_buy(kind: String, id: String, replace: String = "") -> String:
	var shop := side_shop()
	var key := kind + ":" + id
	if side_bought(key):
		return ""
	var price := side_price(kind, id)
	if GameState.gold < price:
		return ""
	var txt := ""
	match kind:
		"card":
			if not (id in (shop.get("cards", []) as Array)):
				return ""
			GameState.spend_gold(price, "card")
			GameState.add_card(id)
			txt = TranslationServer.translate("%s juntou-se ao baralho.") % TranslationServer.translate(CardDB.get_card(id).name)
		"relic":
			if id != String(shop.get("relic", "")):
				return ""
			if GameState.relic_ids.size() >= GameState.max_relics():
				if replace == "" or not (replace in GameState.relic_ids):
					return ""
				GameState.remove_relic(replace)
			GameState.spend_gold(price, "relic")
			GameState.add_relic(id)
			txt = TranslationServer.translate("%s é tua.") % TranslationServer.translate(String(CardDB.relics.get(id, {}).get("name", id)))
		"item":
			if id != String(shop.get("item", "")) or not GameState.can_add_consumable():
				return ""
			GameState.spend_gold(price, "item")
			GameState.add_consumable(id)
			txt = TranslationServer.translate("Recebes: %s.") % TranslationServer.translate(String(CardDB.get_consumable(id).get("name", id)))
		"heal":
			if GameState.player_hp >= GameState.player_max_hp:
				return ""
			GameState.spend_gold(price, "service")
			GameState.heal(side_heal_amount())
			txt = TranslationServer.translate("Curas %d.") % side_heal_amount()
		_:
			return ""
	if kind != "heal":
		(shop["bought"] as Array).append(key)
	note_purchase(kind, id, price)
	return txt

# --- 89, 90: prémio da 1.ª vez e fragmentos ---

## 89: pontos a mais na 1.ª vitória com um baralho e com cada Selo Planar novo (a partir do 2).
static func first_win_bonus(deck_id: String, p_stake: int) -> int:
	var b := 0
	if GameState.wins(deck_id) == 0:
		b += FIRST_WIN_DECK
	if p_stake > 1 and p_stake > GameState.stake_won(deck_id):
		b += FIRST_WIN_STAKE
	return b

static func fragments() -> int:
	return int(GameState.progress.get("fragments", 0))

## Fragmentos de uma run: 1 por ante (andar/5 na Torre, 1 por boss na Corrida), +5 se venceres.
static func fragments_for_run(reached: int, victory: bool) -> int:
	if GameState.puzzle_id != "":
		return 0
	var n := reached
	if GameState.mode == "tower":
		n = int(reached / 5)
	elif GameState.mode == "rush":
		n = GameState.rush_turns.size()
	return maxi(0, n) + (5 if victory else 0)

static func add_fragments(n: int) -> void:
	if n > 0:
		GameState.progress["fragments"] = fragments() + n

static func cosmetic_price(kind: String) -> int:
	return int(FRAGMENT_PRICES.get(kind, 30))

## Compra um cosmético bloqueado com fragmentos (nunca com dinheiro a sério). Grava logo.
static func buy_cosmetic(kind: String, id: String) -> bool:
	var price := cosmetic_price(kind)
	if id == "classic" or id in Settings.unlocked_cosmetics(kind) or fragments() < price or CardDB.get_cosmetic(kind, id).is_empty():
		return false
	GameState.progress["fragments"] = fragments() - price
	Stats.grant_unlock(kind, id)
	GameState.save_progress()
	return true

# --- 94: a tabela de preços (Como Jogar) ---

static func price_table() -> String:
	var tr_ := func(s: String) -> String: return TranslationServer.translate(s)
	var shop: Script = load("res://scenes/shop/Shop.gd")
	var k: Dictionary = shop.get_script_constant_map()
	var lines: Array[String] = []
	var by: Dictionary = {}
	for c in CardDB.collectible_cards():
		var cd := c as CardData
		if cd.is_curse() or cd.is_land():
			continue
		var cur: Array = by.get(cd.rarity, [999, 0])
		by[cd.rarity] = [mini(int(cur[0]), cd.price), maxi(int(cur[1]), cd.price)]
	var parts: Array[String] = []
	for r in RARITY_ORDER:
		if by.has(r):
			parts.append("%s %d–%d" % [tr_.call(String(RARITY_NAMES[r])), int(by[r][0]), int(by[r][1])])
	var eds: Array = []
	for ed in EffectResolver.EDITIONS:
		eds.append(int(EffectResolver.EDITIONS[ed]["price"]))
	lines.append(tr_.call("Cartas: %s ouro (com edição: +%s).") % [", ".join(PackedStringArray(parts)), _range(eds)])
	var rb: Dictionary = {}
	for r in CardDB.relics.values():
		if bool(r.get("boss", false)) or bool(r.get("blessing", false)):
			continue
		var rar := "legendary" if bool(r.get("legendary", false)) else String(r.get("rarity", "common"))
		var cur2: Array = rb.get(rar, [999, 0])
		rb[rar] = [mini(int(cur2[0]), int(r.get("price", 5))), maxi(int(cur2[1]), int(r.get("price", 5)))]
	var rparts: Array[String] = []
	for r in ["common", "uncommon", "rare", "legendary"]:
		if rb.has(r):
			rparts.append("%s %d–%d" % [tr_.call("Lendária" if r == "legendary" else String(RARITY_NAMES[r])), int(rb[r][0]), int(rb[r][1])])
	lines.append(tr_.call("Relíquias: %s ouro. Vendem-se por metade.") % ", ".join(PackedStringArray(rparts)))
	lines.append(tr_.call("Booster (1 de 3): %d · Novas ofertas: %d, +1 por cada vez nesta loja.") % [int(k.get("BOOSTER_PRICE", 5)), int(k.get("REROLL_BASE", 2))])
	lines.append(tr_.call("Curar %d: %d · Vida máxima +%d: %d · Melhorar uma carta: %d · Selar: %d · Constelação: %d.") % [int(k.get("HEAL_AMOUNT", 5)), int(k.get("HEAL_PRICE", 3)), int(k.get("MAX_HP_AMOUNT", 5)), int(k.get("MAX_HP_PRICE", 8)), int(k.get("UPGRADE_PRICE", 4)), int(k.get("SEAL_PRICE", 6)), int(k.get("CONSTELLATION_PRICE", 5))])
	lines.append(tr_.call("Remover uma carta: 2 + 1 por cada 3 antes (devolve 1 a 3 ouro conforme a raridade).") )
	var vp: Array = CardDB.vouchers.map(func(v): return int(v.get("price", 10)))
	var ip: Array = CardDB.consumables.map(func(c): return int(c.get("price", 4)))
	var pp: Array = CardDB.planeswalkers.map(func(x): return int(x.get("price", 10)))
	lines.append(tr_.call("Vales: %s · Poções e pergaminhos: %s (vendem-se por metade) · Patronos: %s · Reservar: %d.") % [_range(vp), _range(ip), _range(pp), RESERVE_PRICE])
	lines.append(tr_.call("Sobem os preços: as relíquias de boss com taxa (+2 em tudo) e regatear mal (+20 %). Descem: o talento Freguês, o Vale do Artesão (serviços), o Vale do Regateio (novas ofertas), regatear bem (−20 %) e o booster que não serviu (metade no seguinte)."))
	lines.append(tr_.call("Juros ao entrar na loja: 1 ouro por cada 5 que tens (máx. 5; mais com o Vale do Cofre e o talento Investidor)."))
	return "\n".join(PackedStringArray(lines))

static func _range(vals: Array) -> String:
	if vals.is_empty():
		return "—"
	var lo := 999
	var hi := 0
	for v in vals:
		lo = mini(lo, int(v))
		hi = maxi(hi, int(v))
	return str(lo) if lo == hi else "%d–%d" % [lo, hi]
