class_name Speech
extends RefCounted
## 0.19.0 (255, 256, 257): a voz do telemóvel (o Godot usa a do Android). Lê as cartas em grande, os botões no
## modo leitor e a descrição das ilustrações. Sem vozes instaladas (ou nos testes), não diz nada.

static var last := ""   # o último texto pedido (testes)

static func voice() -> String:
	if not DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH):
		return ""
	var lang := "en" if Settings.effective_language() == "en" else "pt"
	var v := DisplayServer.tts_get_voices_for_language(lang)
	return String(v[0]) if not v.is_empty() else ""

static func available() -> bool:
	return voice() != ""

## Diz o texto (corta o que estiver a dizer). Devolve true se havia voz.
static func say(text: String) -> bool:
	last = clean(text)
	var v := voice()
	if v == "" or last == "":
		return false
	DisplayServer.tts_stop()
	DisplayServer.tts_speak(last, v, 70, 1.0, 1.0)
	Music.duck_for_speech(last.length())   # 0.19.1: a música baixa enquanto a voz lê
	return true

static func stop() -> void:
	if DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH):
		DisplayServer.tts_stop()
	Music.unduck()

## 0.19.1: a voz ainda está a falar? (Sem voz no aparelho, nunca.)
static func speaking() -> bool:
	return DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH) and DisplayServer.tts_is_speaking()

## Sem marcas de BBCode, sem os carateres de controlo e com os símbolos ditos por extenso.
static func clean(text: String) -> String:
	var re := RegEx.create_from_string("\\[[^\\]]*\\]")
	var t := re.sub(text, "", true)
	t = t.replace(String.chr(1), "").replace(String.chr(2), "")
	var t2 := func(x: String) -> String: return TranslationServer.translate(x)
	t = t.replace("×", " " + t2.call("vezes") + " ").replace("♥", " " + t2.call("vida") + " ").replace("·", ",").replace("▸", "").replace("◀", "").replace("▶", "")
	return " ".join(t.split(" ", false)).strip_edges()

## 255, 257: o que se diz de uma carta — nome, tipo, custo, Poder, texto e a ilustração.
static func card_text(c: CardData) -> String:
	var t := func(x: String) -> String: return TranslationServer.translate(x)
	var parts: Array[String] = [c.display_name()]
	parts.append(t.call("Custo %d") % c.cost)
	if c.is_creature():
		parts.append(t.call("%d de Poder") % c.power)
	if c.display_text() != "":
		parts.append(c.display_text())
	var art := ArtLib.describe("card", c.id)
	if art != "":
		parts.append(art)
	return ". ".join(PackedStringArray(parts))
