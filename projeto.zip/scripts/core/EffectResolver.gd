class_name EffectResolver
extends RefCounted
## Interpreta os "effects" de cartas e relíquias (dados em JSON) contra o BattleManager.
## É aqui que vivem os "jokers": relíquias são efeitos permanentes que distorcem regras.
##
## Formato de um efeito: {"trigger": "...", "action": "...", "value": N, "filter": {...}}
## Triggers: turn_start | land_played | creature_summoned | on_cast (feitiços) | passive
## Actions:  damage_enemy | heal_player | draw | buff_power | gold | cost_reduction | damage_mult

var battle: BattleManager

func _init(p_battle: BattleManager) -> void:
	battle = p_battle

## Reúne efeitos de todas as relíquias ativas + cartas no tabuleiro.
func _active_effects() -> Array:
	var out: Array = []
	for relic_id in GameState.relic_ids:
		var relic: Dictionary = CardDB.relics.get(relic_id, {})
		for e in relic.get("effects", []):
			out.append({"effect": e, "source": relic.get("name", relic_id)})
	for c in battle.board:
		for e in c.data.effects:
			out.append({"effect": e, "source": c.data.name, "card": c})
	return out

func trigger(trigger_name: String, context: CardInstance = null) -> void:
	for entry in _active_effects():
		var e: Dictionary = entry.effect
		if e.get("trigger", "") != trigger_name:
			continue
		if not _passes_filter(e.get("filter", {}), context):
			continue
		_apply(e, context)

func resolve_spell(card: CardInstance) -> void:
	for e in card.data.effects:
		if e.get("trigger", "on_cast") == "on_cast":
			_apply(e, card)

## Custo efetivo de uma carta depois de reduções passivas.
func cost_of(card: CardInstance) -> int:
	var cost := card.data.cost
	for entry in _active_effects():
		var e: Dictionary = entry.effect
		if e.get("trigger") == "passive" and e.get("action") == "cost_reduction":
			if _passes_filter(e.get("filter", {}), card):
				cost -= int(e.get("value", 0))
	return max(0, cost)

## Multiplicadores de dano passivos (o "mult" do Balatro).
func modify_damage(amount: int) -> int:
	var mult := 1.0
	for entry in _active_effects():
		var e: Dictionary = entry.effect
		if e.get("trigger") == "passive" and e.get("action") == "damage_mult":
			mult *= float(e.get("value", 1.0))
	return int(round(amount * mult))

func _passes_filter(f: Dictionary, card: CardInstance) -> bool:
	if f.is_empty():
		return true
	if card == null:
		return false
	if f.has("color") and card.data.color != f.color:
		return false
	if f.has("type") and card.data.type != f.type:
		return false
	return true

func _apply(e: Dictionary, context: CardInstance) -> void:
	var v: int = int(e.get("value", 0))
	match e.get("action", ""):
		"damage_enemy":
			battle.enemy.hp = max(0, battle.enemy.hp - v)
			EventBus.damage_dealt.emit("enemy", v)
			EventBus.enemy_hp_changed.emit(battle.enemy.hp, battle.enemy.max_hp)
		"heal_player":
			GameState.player_hp = min(GameState.player_max_hp, GameState.player_hp + v)
			EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)
		"draw":
			battle.deck.draw(v)
		"buff_power":
			for c in battle.board:
				if c.data.is_creature() and _passes_filter(e.get("filter", {}), c):
					c.power_bonus += v
		"gold":
			GameState.add_gold(v)
		_:
			pass  # passives tratados em cost_of / modify_damage
