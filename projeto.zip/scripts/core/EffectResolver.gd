class_name EffectResolver
extends RefCounted
## Interpreta os "effects" de cartas e relíquias (dados em JSON) contra o BattleManager.
##
## Formato: {"trigger", "action", "value", "per", "per_div", "cap", "filter", "cond", "exclude_self"}
##
## Triggers
##   on_attack        criatura, em cada ataque (cascata)
##   on_cast          feitiço: ações imediatas ao lançar; ações de cascata contam no ataque deste turno
##   on_play          criatura ao entrar (ações imediatas)
##   in_hand          carta na mão durante o ataque (cascata)
##   in_hand_on_play  carta na mão quando jogas uma criatura (grow_played)
##   on_discard       quando a carta é canalizada (descartada)
##   turn_start       início do turno (relíquias)
##   passive          cost_reduction (relíquias)
##
## Ações de cascata: power_add | mult_add | mult_mul | gold | heal | self_damage | grow | power_double_self | power_pct_enemy
##                   retrigger (left|right|self|all|first|best|last_spell|last_creature|spells|formations|relics|hand)
##                   cascade_library (top|strongest|graveyard_spell)
## Ações imediatas:  draw | gold | mill | mill_half | discard_random | silence_enemy | extra_turn | discard_plus
##                   consume_discard | shuffle_graveyard | enemy_max_hp_pct | recover | tutor_land |
##                   tutor_strongest | tutor_creature | grow_self | grow_hand | grow_left | grow_board |
##                   grow_played | grow_mult_self | destroy_left | destroy_right | enemy_vulnerable |
##                   heal_player | damage_enemy
##
## "per" conta: attacker | spell | played | hand | graveyard | library | land_hand | land | gold | colors |
##              graveyard_types | relics | drawn_this_turn | discards_used | neighbors | max_power |
##              tokens | enchantments | tribe (só nos bónus de tribo)
## "filter": color | type | subtype | colorless | colored | cost | cost_min | cost_max | power_min | tribe | token
## "cond": ver _cond_ok.
##
## 0.10.0 — triggers novos: reaction (Mágicas lançadas na janela de reação, ver BattleManager) e
## turn_start / passive também nas cartas em jogo (encantamentos; Chefe Guerreiro Goblin).
## Ações imediatas novas: create_token N (+ "token": id) · devour_token N · mana_now N · grow_weakest N.
## Passos novos da cascata, depois das formações: Cadeia de cor → Conjunto de selos → Tribos →
## Encantamentos; e no fim as regras da run e das Míticas ("rule").

const IMMEDIATE := ["draw", "mill", "mill_half", "discard_random", "silence_enemy", "extra_turn", "discard_plus",
	"consume_discard", "shuffle_graveyard", "enemy_max_hp_pct", "recover", "tutor_land", "tutor_strongest",
	"tutor_creature", "grow_self", "grow_hand", "grow_left", "grow_board", "grow_played", "grow_mult_self",
	"destroy_left", "destroy_right", "enemy_vulnerable", "heal_player", "damage_enemy", "buff_power",
	"buff_right", "bonus_turn", "create_token", "devour_token", "mana_now", "grow_weakest",
	"buff_self", "grant_keyword"]
const PHYREXIAN_MULT := 2.5
const CHAIN_MIN := 3            # cartas seguidas da mesma cor para a Cadeia
const CHAIN_MULT := 1.5
const CHAIN_FULL := 5           # Arena inteira da mesma cor
const CHAIN_FULL_MULT := 2.0
const SEAL_SET_MIN := 3         # cartas com o mesmo selo no ataque
const FINAL_MULT := 1.5         # Motor do Infinito
const TOKEN_ENGINE_POWER := 20  # Comandante da Alvorada

var battle: BattleManager

# Contexto de uma cascata em construção.
var _attackers: Array[CardInstance] = []
var _spells: Array[CardInstance] = []
var _formations: Array[String] = []
var _retrigger_formations: int = 0
var _retrigger_relics: int = 0
var _retrigger_hand: int = 0
var _tribe_n: int = 0           # contagem da tribo do passo de tribo em curso (per "tribe")

func _init(p_battle: BattleManager) -> void:
	battle = p_battle

# ---------------------------------------------------------------------------
# Efeitos imediatos
# ---------------------------------------------------------------------------

func is_immediate(action: String) -> bool:
	return action in IMMEDIATE or (action == "gold" and true)

## Regra de boss "color_silenced": as cartas dessa cor perdem os efeitos (mantêm Poder e custo).
func silenced(card: CardInstance) -> bool:
	var col := String(battle.rule.get("color_silenced", ""))
	return col != "" and card != null and card.data.has_color(col)

## Corre as ações imediatas de uma carta para um trigger (on_play, on_cast, on_discard).
func run_immediate(card: CardInstance, trigger: String) -> void:
	_prepare_context()
	if silenced(card):
		return
	for e in card.effects():
		if e.get("trigger", "") != trigger:
			continue
		var action: String = e.get("action", "")
		if not (action in IMMEDIATE or action == "gold"):
			continue
		if not _cond_ok(e, card):
			continue
		_apply_immediate(e, card)
	if trigger == "on_play":
		for h in battle.deck.hand:
			for e in h.effects():
				if e.get("trigger", "") == "in_hand_on_play" and _filter_ok(e.get("filter", {}), card):
					var g := int(e.get("value", 0)) * battle.growth_factor()
					card.grow(g)
					EventBus.card_grew.emit(card, g)

## Relíquias: triggers simples (battle_start, turn_start, land_played...).
func trigger_relics(trigger_name: String, context: CardInstance = null) -> void:
	if battle.rule.get("relics_off", false):
		return
	for relic_id in GameState.active_relic_ids():
		var relic: Dictionary = CardDB.relics.get(relic_id, {})
		for e in relic.get("effects", []):
			if e.get("trigger", "") != trigger_name:
				continue
			if not _filter_ok(e.get("filter", {}), context):
				continue
			_apply_immediate(e, context)

## Custo efetivo de uma carta depois de reduções passivas (relíquias).
func cost_of(card: CardInstance) -> int:
	if card.data.is_land():
		return 0
	# Feitiços custam 1 a menos (mínimo 1): disparam uma vez, as criaturas atacam todos os turnos.
	var cost := card.data.cost
	if battle.cheap_hand and card.zone == CardInstance.Zone.HAND:
		return 1   # planeswalker: este turno tudo na mão custa 1
	# História (capítulo azul): o primeiro feitiço de cada turno não custa nada.
	if card.data.is_spell() and bool(battle.rule.get("first_spell_free", false)) and battle.spells_this_turn.is_empty() and card.zone == CardInstance.Zone.HAND:
		return 0
	if card.data.is_spell():
		cost = max(1, cost - 1) + int(battle.rule.get("spell_cost_plus", 0))
		if battle.climate == "aether_tide":
			if battle.turn == 1:
				return 0
			if battle.turn >= 4:
				cost += 1
	elif card.data.is_creature():
		cost += int(battle.rule.get("creature_cost_plus", 0)) - int(battle.rule.get("creature_cost_minus", 0))
	for relic_id in GameState.active_relic_ids():
		var relic: Dictionary = CardDB.relics.get(relic_id, {})
		for e in relic.get("effects", []):
			if e.get("trigger") == "passive" and e.get("action") == "cost_reduction":
				if _filter_ok(e.get("filter", {}), card):
					cost -= int(e.get("value", 0))
	# Passivas das cartas em jogo (Chefe Guerreiro Goblin): baixam o custo das outras.
	for src in battle.in_play():
		if src == card or silenced(src):
			continue
		for e in src.effects():
			if e.get("trigger") == "passive" and e.get("action") == "cost_reduction" and _filter_ok(e.get("filter", {}), card):
				cost -= int(e.get("value", 0))
	return max(0, cost)

func _apply_immediate(e: Dictionary, source: CardInstance) -> void:
	var v := float(e.get("value", 0))
	var deck := battle.deck
	match e.get("action", ""):
		"buff_self":
			# 0.12.0: Poder só para esta batalha (as Chegadas de Terreno usam isto).
			if source != null:
				source.power_bonus += int(v)
				EventBus.card_grew.emit(source, int(v))
		"grant_keyword":
			# 0.12.0: dá uma palavra-chave (Voar, Atropelar, Primeiro Golpe…) até ao fim da batalha.
			var kw := String(e.get("keyword", ""))
			for t in _keyword_targets(e, source):
				if t.grant_keyword(kw):
					if not battle.puzzle:
						Stats.add("keywords_granted")
					EventBus.keyword_granted.emit(t, kw)
		"draw":
			battle.draw(int(v))
		"gold":
			GameState.add_gold(int(v))
		"mill":
			deck.mill(int(v))
		"mill_half":
			deck.mill(int(deck.library.size() / 2))
		"discard_random":
			battle.discard_random(int(v))
		"silence_enemy":
			battle.silenced = true
		"extra_turn":
			battle.grant_extra_turn()
		"discard_plus":
			battle.discards_left += int(v)
		"consume_discard":
			if battle.discards_left > 0 and source != null:
				battle.discards_left -= 1
				source.consumed = true
		"shuffle_graveyard":
			deck.shuffle_graveyard_in()
		"enemy_max_hp_pct":
			var cut := int(round(battle.enemy.max_hp * v / 100.0))
			battle.enemy.max_hp = max(1, battle.enemy.max_hp - cut)
			battle.enemy.hp = min(battle.enemy.hp, battle.enemy.max_hp)
			EventBus.enemy_hp_changed.emit(battle.enemy.hp, battle.enemy.max_hp)
		"recover":
			deck.recover(int(v))
		"tutor_land":
			deck.tutor(func(c): return c.data.is_land())
		"tutor_strongest":
			deck.tutor_strongest()
		"tutor_creature":
			deck.tutor(func(c): return c.data.is_creature() and c.power() <= 25)
		"grow_self":
			if source != null:
				var g := int(v) * battle.growth_factor()
				source.grow(g)
				EventBus.card_grew.emit(source, g)
		"grow_hand":
			for h in deck.hand:
				if h.data.is_creature():
					h.grow(int(v) * battle.growth_factor())
		"grow_left":
			var target := _left_of(source)
			if target != null:
				var g := int(v) * battle.growth_factor()
				target.grow(g)
				EventBus.card_grew.emit(target, g)
		"grow_board":
			for c in battle.creatures():
				if e.get("exclude_self", false) and c == source:
					continue
				if _filter_ok(e.get("filter", {}), c):
					c.grow(int(v) * battle.growth_factor())
		"grow_mult_self":
			if source != null:
				source.grow_mult(v)
		"destroy_left":
			var target := _left_of(source)
			if target != null:
				battle.kill_creature(target)
		"destroy_right":
			var target := _right_of(source)
			if target != null:
				battle.kill_creature(target)
		"enemy_vulnerable":
			battle.enemy_vuln *= v
		"heal_player":
			GameState.player_hp = min(GameState.player_max_hp, GameState.player_hp + int(v))
			EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)
		"damage_enemy":
			battle.damage_enemy(int(v))
		"buff_power":
			for c in battle.creatures():
				if _filter_ok(e.get("filter", {}), c):
					c.power_bonus += int(v)
		"buff_right":
			# dupla face: as criaturas à direita da fonte ganham Poder (esta batalha)
			var cs := battle.creatures()
			var i := cs.find(source)
			if i >= 0:
				for j in range(i + 1, cs.size()):
					cs[j].power_bonus += int(v)
					EventBus.card_grew.emit(cs[j], int(v))
		"bonus_turn":
			battle.extra_turns += int(v)
		"create_token":
			battle.create_tokens(int(v), String(e.get("token", "tok_soldier")))
		"devour_token":
			battle.devour_token(source, int(v))
		"mana_now":
			battle.mana_available += int(v)
			EventBus.mana_changed.emit(battle.mana_available, battle.mana_total)
		"grow_weakest":
			var weakest: CardInstance = null
			for c in battle.creatures():
				if c.data.token:
					continue   # as Fichas desaparecem: crescer só vale nas cartas do baralho
				if weakest == null or c.power() < weakest.power():
					weakest = c
			if weakest != null:
				var g := int(v) * battle.growth_factor()
				weakest.grow(g)
				EventBus.card_grew.emit(weakest, g)

func left_of(source: CardInstance) -> CardInstance:
	return _left_of(source)

## Criatura à esquerda (jogada antes). Para feitiços: a última criatura do tabuleiro.
func _left_of(source: CardInstance) -> CardInstance:
	var cs := battle.creatures()
	if cs.is_empty():
		return null
	if source == null or not source.data.is_creature():
		return cs[cs.size() - 1]
	var i := cs.find(source)
	return cs[i - 1] if i > 0 else null

func _right_of(source: CardInstance) -> CardInstance:
	var cs := battle.creatures()
	if source == null or not source.data.is_creature():
		return null
	var i := cs.find(source)
	return cs[i + 1] if i >= 0 and i + 1 < cs.size() else null

# ---------------------------------------------------------------------------
# Cascata de ataque (Poder × Mult). Função PURA (não altera estado), por isso a UI
# pode chamá-la a qualquer momento para a pré-visualização.
# Ordem: criaturas → feitiços deste turno → formações → cartas na mão → relíquias.
# ---------------------------------------------------------------------------

func _prepare_context() -> void:
	_attackers = battle.attackers()
	_spells = battle.spells_this_turn
	_formations = _compute_formations()
	_retrigger_formations = 0
	_retrigger_relics = 0
	_retrigger_hand = 0

func build_attack_cascade() -> Cascade:
	var c := Cascade.new()
	_prepare_context()
	if _attackers.is_empty() and _spells.is_empty():
		return c
	c.damage_mult = battle.enemy_vuln

	# 1. Criaturas: as com Primeiro Golpe primeiro, depois pela ordem do tabuleiro (Eco Temporal: a 1.ª
	# do tabuleiro ativa duas vezes).
	for a in _strike_order():
		_creature_steps(c, a, 0)
	if battle.climate == "temporal_echo" and not _attackers.is_empty():
		_creature_steps(c, _attackers[0], 1, true)
	# 2. Feitiços lançados neste turno (Rainha das Labaredas: duas vezes).
	for s in _spells:
		_spell_steps(c, s, 0)
	if battle.has_rule("spells_twice"):
		for s in _spells:
			_spell_steps(c, s, 1, true)
	# 3. Formações (Avatar da Convergência: duas vezes).
	if battle.has_rule("double_formations"):
		_retrigger_formations += 1
	_formation_steps(c)
	for i in _retrigger_formations:
		_formation_steps(c, true)
	# 4. Cadeia de cor, conjunto de selos e tribos.
	_chain_steps(c)
	_seal_set_steps(c)
	_tribe_steps(c)
	# 5. Encantamentos em jogo.
	_enchantment_steps(c)
	# 6. Cartas na mão com efeitos [Na Mão].
	_hand_steps(c)
	for i in _retrigger_hand:
		_hand_steps(c, true)
	# 7. Relíquias, da esquerda para a direita (Arauto do Eco Eterno: duas vezes).
	if battle.has_rule("relics_twice"):
		_retrigger_relics += 1
	_relic_steps(c)
	for i in _retrigger_relics:
		_relic_steps(c, true)
	# 8. Planeswalker (habilidades usadas este turno).
	_planeswalker_steps(c)
	# 9. Clima Planar.
	_climate_steps(c)
	# 10. Regras da run (História) e das Míticas que fecham a cascata.
	_rule_steps(c)
	# Escudo do inimigo: absorve os primeiros X de cada ataque; cada criatura com Atropelar corta-o a meio.
	c.shield = battle.shield_amount()
	if c.shield > 0:
		for a in _attackers:
			if a.has_keyword("trample") and not silenced(a):
				c.shield = int(c.shield / 2)
	return c

## A quem uma carta dá a palavra-chave: "self", "left" (feitiços e Terrenos: a última criatura), "right",
## "first" (a 1.ª da Arena) ou "board" (as tuas criaturas, com filtro).
func _keyword_targets(e: Dictionary, source: CardInstance) -> Array:
	var out: Array = []
	match String(e.get("target", "board")):
		"self":
			if source != null and source.data.is_creature():
				out.append(source)
		"first":
			if not battle.board.is_empty():
				out.append(battle.board[0])
		"left":
			var l := _left_of(source)
			if l != null:
				out.append(l)
		"right":
			var r := _right_of(source)
			if r != null:
				out.append(r)
		_:
			for c in battle.creatures():
				if e.get("exclude_self", false) and c == source:
					continue
				if _filter_ok(e.get("filter", {}), c):
					out.append(c)
	return out

## Ordem de disparo das criaturas: Primeiro Golpe primeiro (0.12.0), o resto pela ordem do tabuleiro.
func _strike_order() -> Array:
	var first: Array = []
	var rest: Array = []
	for a in _attackers:
		if a.has_keyword("first_strike") and not silenced(a):
			first.append(a)
		else:
			rest.append(a)
	first.append_array(rest)
	return first

## Lugar do atacante na fila que os lacaios travam (as com Voar não entram): -1 se voa.
func _minion_slot(a: CardInstance) -> int:
	if a.has_keyword("flying") and not silenced(a):
		return -1
	var k := 0
	for x in _attackers:
		if x == a:
			return k
		if not (x.has_keyword("flying") and not silenced(x)):
			k += 1
	return -1

# ---------------------------------------------------------------------------
# 0.10.0 — Cadeia de cor, conjunto de selos, tribos, encantamentos e regras
# ---------------------------------------------------------------------------

## Cartas seguidas precisas para a Cadeia (3; 2 com o Elo da Cadeia).
static func chain_needed() -> int:
	return maxi(2, CHAIN_MIN - int(GameState.relic_passive("chain_min")))

## Maior sequência de criaturas seguidas (ordem do tabuleiro) com uma cor em comum.
## Devolve {"len", "color"}; as cartas "de qualquer cor" contam, as incolores cortam.
static func chain_of(cards: Array) -> Dictionary:
	var best := 0
	var best_color := ""
	for col in CardData.ALL_COLORS:
		var run := 0
		for a in cards:
			if (a as CardInstance).data.has_color(col):
				run += 1
				if run > best:
					best = run
					best_color = col
			else:
				run = 0
	return {"len": best, "color": best_color}

static func chain_mult(length: int) -> float:
	if length >= CHAIN_FULL:
		return CHAIN_FULL_MULT
	if length >= chain_needed():
		return CHAIN_MULT
	return 1.0

func _chain_steps(c: Cascade) -> void:
	var info := chain_of(_attackers)
	c.chain_len = int(info["len"])
	c.chain_color = String(info["color"])
	var m := chain_mult(c.chain_len)
	if m <= 1.0:
		return
	var s := Cascade.Step.new()
	s.source_kind = "chain"
	s.source_name = TranslationServer.translate("Cadeia de %d") % c.chain_len
	s.source_id = c.chain_color
	s.action = "mult_mul"
	s.value = m
	s.label = Cascade.label_for("mult_mul", m)
	c.add(s)

## 3+ cartas jogadas com o mesmo selo de guilda: o bónus de conjunto do selo (seals.json "set_bonus").
func _seal_set_steps(c: Cascade) -> void:
	var counts := {}
	for p in _played():
		var sid := p.seal()
		if sid != "":
			counts[sid] = int(counts.get(sid, 0)) + 1
	for sid in counts:
		if int(counts[sid]) < SEAL_SET_MIN:
			continue
		var sd := CardDB.get_seal(String(sid))
		var bonus: Dictionary = sd.get("set_bonus", {})
		var sname := TranslationServer.translate(String(bonus.get("name", sd.get("name", sid))))
		for e in bonus.get("effects", []):
			_effect_step(c, e, null, "seal_set", String(sid), 0, false, sname)

## Bónus de tribo (data/tribes.json): só conta o escalão mais alto atingido por cada tribo.
func _tribe_steps(c: Cascade) -> void:
	var extra := battle.tribe_plus()
	for t in CardDB.tribes:
		var tid := String(t.get("id", ""))
		var n := 0
		for a in _attackers:
			if a.data.tribe == tid:
				n += 1
		if n == 0:
			continue
		n += extra
		var tier: Dictionary = {}
		for tr_ in t.get("tiers", []):
			if n >= int(tr_.get("min", 99)):
				tier = tr_
		if tier.is_empty():
			continue
		_tribe_n = n
		var tname := TranslationServer.translate(String(tier.get("name", t.get("name", tid))))
		for e in tier.get("effects", []):
			_effect_step(c, e, null, "tribe", tid, 0, false, tname)
	_tribe_n = 0

## Tribo, quantos atacantes dela e o escalão atingido (para a UI).
func tribe_summary() -> Array:
	var out: Array = []
	var extra := battle.tribe_plus()
	for t in CardDB.tribes:
		var tid := String(t.get("id", ""))
		var n := 0
		for a in battle.attackers():
			if a.data.tribe == tid:
				n += 1
		if n == 0:
			continue
		var active := false
		for tr_ in t.get("tiers", []):
			if n + extra >= int(tr_.get("min", 99)):
				active = true
		out.append({"id": tid, "count": n + extra, "active": active})
	return out

func _enchantment_steps(c: Cascade) -> void:
	for en in battle.enchantments:
		if silenced(en):
			continue
		for e in en.effects():
			if e.get("trigger", "") != "on_attack":
				continue
			_effect_step(c, e, en, "enchantment", "", 0, false)

## Regras da run (capítulo vermelho da História: +Mult por feitiço) e o ×Mult final do Motor do Infinito.
## 0.12.0: talento Golpe de Abertura (+Mult no 1.º turno de cada batalha).
func _rule_steps(c: Cascade) -> void:
	var opener := GameState.talent_value("turn1_mult")
	if opener > 0.0 and battle.turn == 1 and not battle.puzzle:
		var o := Cascade.Step.new()
		o.source_kind = "rule"
		o.source_name = TranslationServer.translate("Golpe de Abertura")
		o.action = "mult_add"
		o.value = opener
		o.label = Cascade.label_for("mult_add", opener)
		c.add(o)
	var per_spell := float(battle.rule.get("spell_mult", 0))
	if per_spell > 0.0 and not _spells.is_empty():
		var s := Cascade.Step.new()
		s.source_kind = "rule"
		s.source_name = TranslationServer.translate(String(battle.rule.get("rule_name", "Regra")))
		s.action = "mult_add"
		s.value = per_spell * _spells.size()
		s.label = Cascade.label_for("mult_add", s.value)
		c.add(s)
	if battle.has_rule("final_mult"):
		var m := Cascade.Step.new()
		m.source_kind = "rule"
		m.source_name = battle.rule_card_name("final_mult")
		m.source_card = battle.rule_card("final_mult")
		m.action = "mult_mul"
		m.value = FINAL_MULT
		m.label = Cascade.label_for("mult_mul", FINAL_MULT)
		c.add(m)

## Passos do Clima Planar no fim da cascata (source_kind "climate").
func _climate_steps(c: Cascade) -> void:
	if battle.climate == "":
		return
	var cname := battle.climate_name()
	match battle.climate:
		"guild_market":
			if _count("colors", {}, null, false) >= 2:
				_add_climate_step(c, cname, "gold", 2.0, null)
		"meteor_rain":
			if _attackers.size() >= 3:
				_add_climate_step(c, cname, "power_add", 20.0, _attackers[2])
		"mana_eclipse":
			if not _formations.is_empty():
				_add_climate_step(c, cname, "mult_add", 2.0 * _formations.size(), null)
		"blood_moon":
			var cols: Array = ["black", "red"] if battle.is_night() else ["white", "green"]
			var n := 0
			for p in _played():
				for col in cols:
					if p.data.has_color(col):
						n += 1
						break
			if n > 0:
				_add_climate_step(c, cname, "mult_add", 3.0 * n, null)
		"scorching_sands":
			if battle.turn >= 4:
				_add_climate_step(c, cname, "mult_mul", 1.5, null)

func _add_climate_step(c: Cascade, cname: String, action: String, value: float, card: CardInstance) -> void:
	var s := Cascade.Step.new()
	s.source_kind = "climate"
	s.source_name = cname
	s.source_card = card
	s.source_id = battle.climate
	s.action = action
	s.value = value
	s.label = Cascade.label_for(action, value)
	c.add(s)

## Poder base de uma carta na cascata (Ferrugem de Óleo: −5 nas cartas sem selo).
func _base_power(card: CardInstance) -> int:
	var p := card.power()
	if battle.climate == "oil_rust" and card.seal() == "":
		p = maxi(0, p - 5)
	if card.data.token and battle.has_rule("token_engine"):
		p += TOKEN_ENGINE_POWER
	return p

func _planeswalker_steps(c: Cascade) -> void:
	var pw_name := String(GameState.planeswalker_def().get("name", ""))
	if pw_name == "":
		return
	var add := battle.pw_mult_add + battle.pw_mult_per_attacker * _attackers.size() + battle.pw_mult_per_token * _count("tokens", {}, null, false)
	if add > 0.0:
		var s := Cascade.Step.new()
		s.source_kind = "planeswalker"; s.source_name = pw_name; s.action = "mult_add"; s.value = add
		s.label = Cascade.label_for("mult_add", add)
		c.add(s)
	if battle.pw_mult_mul != 1.0:
		var m := Cascade.Step.new()
		m.source_kind = "planeswalker"; m.source_name = pw_name; m.action = "mult_mul"; m.value = battle.pw_mult_mul
		m.label = Cascade.label_for("mult_mul", m.value)
		c.add(m)

## Selos de guilda que entram na cascata: Fúria (reativa) e Phyrexiano (×2.5 Mult).
func _seal_steps(c: Cascade, card: CardInstance, depth: int, retrig: bool) -> void:
	if retrig or depth >= 1:
		return
	match card.seal():
		"phyrexian":
			var s := Cascade.Step.new()
			s.source_kind = "creature" if card.data.is_creature() else "spell"
			s.source_name = card.data.name; s.source_card = card; s.tag = "seal"
			s.action = "mult_mul"; s.value = PHYREXIAN_MULT; s.label = Cascade.label_for("mult_mul", PHYREXIAN_MULT)
			c.add(s)
		"fury":
			if card.data.is_creature():
				_creature_steps(c, card, depth + 1, true)
			else:
				_spell_steps(c, card, depth + 1, true)

func _creature_steps(c: Cascade, a: CardInstance, depth: int, retrig: bool = false) -> void:
	# 0.12.0 Carcereiro: a criatura presa não conta neste ataque (nem Poder nem habilidades).
	if battle.jailed_uid == a.uid and not battle.is_protected(a):
		if depth == 0 and not retrig:
			var j := Cascade.Step.new()
			j.source_kind = "creature"; j.source_name = a.data.name; j.source_card = a
			j.action = "power_add"; j.value = 0; j.tag = "jail"
			j.label = TranslationServer.translate("Presa")
			c.add(j)
		return
	var s := Cascade.Step.new()
	s.source_kind = "creature"
	s.source_name = a.data.name
	s.source_card = a
	s.action = "power_add"
	s.retrigger = retrig
	# Lacaios do inimigo: travam o Poder base das primeiras criaturas (as habilidades disparam na mesma);
	# as que têm Voar passam por cima (0.12.0).
	var i := _minion_slot(a)
	if depth == 0 and not retrig and i >= 0 and i < battle.minions.size():
		s.value = 0
		s.tag = "minion"
		s.label = TranslationServer.translate("Lacaio bloqueia")
	elif depth == 0 and not retrig and battle.mirror_uid == a.uid and not battle.is_protected(a):
		s.value = 0
		s.tag = "mirror"
		s.label = TranslationServer.translate("O espelho anula")
	else:
		s.value = _base_power(a)
		s.label = Cascade.label_for("power_add", s.value)
	c.add(s)
	if a.perm_mult() > 0.0:
		var m := Cascade.Step.new()
		m.source_kind = "creature"; m.source_name = a.data.name; m.source_card = a
		m.action = "mult_add"; m.value = a.perm_mult(); m.label = Cascade.label_for("mult_add", m.value); m.retrigger = retrig
		c.add(m)
	if silenced(a):
		return
	for e in a.effects():
		if e.get("trigger", "") != "on_attack":
			continue
		_effect_step(c, e, a, "creature", "", depth, retrig)
	# Vínculo Vital: cada ataque cura 1.
	if a.has_keyword("lifelink"):
		_effect_step(c, {"trigger": "on_attack", "action": "heal", "value": 1}, a, "creature", "", depth, retrig)
	_seal_steps(c, a, depth, retrig)

func _spell_steps(c: Cascade, sp: CardInstance, depth: int, retrig: bool = false) -> void:
	# O poder base do feitiço também conta (como no Mana Cascade).
	if sp.data.power > 0:
		var s := Cascade.Step.new()
		s.source_kind = "spell"; s.source_name = sp.data.name; s.source_card = sp
		s.action = "power_add"; s.value = _base_power(sp); s.label = Cascade.label_for("power_add", s.value); s.retrigger = retrig
		c.add(s)
	if silenced(sp):
		return
	for e in sp.effects():
		if e.get("trigger", "") != "on_cast":
			continue
		_effect_step(c, e, sp, "spell", "", depth, retrig)
	_seal_steps(c, sp, depth, retrig)

func _formation_steps(c: Cascade, retrig: bool = false) -> void:
	for fid in _formations:
		var f := CardDB.get_formation(fid)
		var s := Cascade.Step.new()
		s.source_kind = "formation"
		s.source_name = f.get("name", fid)
		s.source_id = fid
		s.action = "mult_add"
		var level := GameState.formation_level(fid)
		s.value = float(f.get("mult_add", 0)) + level * float(f.get("level_mult", 1)) + GameState.talent_value("formation_mult")
		s.label = Cascade.label_for(s.action, s.value)
		if level > 0:
			s.tag = "level"
			s.level = level
		s.retrigger = retrig
		c.add(s)
		if not retrig:
			c.formations.append(s.source_name)
			c.formation_ids.append(fid)
			c.formation_levels.append(level)

func _hand_steps(c: Cascade, retrig: bool = false) -> void:
	for h in battle.deck.hand:
		if silenced(h):
			continue
		for e in h.effects():
			if e.get("trigger", "") != "in_hand":
				continue
			_effect_step(c, e, h, "hand", "", 0, retrig)

func _relic_steps(c: Cascade, retrig: bool = false) -> void:
	if battle.rule.get("relics_off", false):
		return
	for relic_id in GameState.active_relic_ids():
		var relic: Dictionary = CardDB.relics.get(relic_id, {})
		for e in relic.get("effects", []):
			if e.get("trigger", "") != "on_attack":
				continue
			_effect_step(c, e, null, "relic", relic_id, 0, retrig, relic.get("name", relic_id))

func _effect_step(c: Cascade, e: Dictionary, source: CardInstance, kind: String, relic_id: String, depth: int, retrig: bool, relic_name: String = "") -> void:
	var action: String = e.get("action", "")
	if action in IMMEDIATE:
		return   # imediatas correm fora da cascata
	if not _cond_ok(e, source):
		return
	if action == "retrigger":
		if depth >= 1:
			return
		_do_retrigger(c, String(e.get("value", "")), e, source, depth)
		return
	if action == "cascade_library":
		if depth >= 1:
			return
		_do_cascade_library(c, String(e.get("value", "top")), depth)
		return
	var count := 1
	if e.has("per"):
		if String(e["per"]) == "relic_counter":
			count = GameState.relic_counter(relic_id)   # relíquias que escalam
		elif String(e["per"]) == "tribe":
			count = _tribe_n
		else:
			count = _count(String(e["per"]), e.get("filter", {}), source, bool(e.get("exclude_self", false)))
		if e.has("per_div"):
			count = int(count / int(e["per_div"]))
		if count <= 0:
			return
	var raw = e.get("value", 0)
	var value := float(raw) if (raw is int or raw is float) else 0.0   # (power_double_self não tem valor)
	var s := Cascade.Step.new()
	s.source_kind = kind
	s.source_name = relic_name if relic_name != "" else (source.data.name if source != null else "")
	s.source_card = source
	s.source_id = relic_id
	s.retrigger = retrig
	match action:
		"power_add":
			s.action = "power_add"
			s.value = value * count
		"mult_add":
			s.action = "mult_add"
			s.value = value * count
		"mult_mul":
			s.action = "mult_mul"
			if bool(e.get("linear", false)):
				s.value = 1.0 + value * count   # ×1 + valor por contagem (Prisma do Colecionador)
			else:
				s.value = pow(value, count) if count > 1 else value
		"gold":
			s.action = "gold"
			s.value = value * count
		"heal":
			s.action = "heal"
			s.value = value * count
		"self_damage":
			s.action = "self_damage"
			s.value = value * count
		"grow":
			s.action = "power_add"
			s.value = value * count * battle.growth_factor()
			s.grow = int(s.value)
		"power_double_self":
			if source == null:
				return
			s.action = "power_add"
			s.value = source.power()
		"power_pct_enemy":
			s.action = "power_add"
			s.value = int(round(battle.enemy.hp * value / 100.0))
		_:
			return
	if e.has("cap") and s.action == "mult_add":
		s.value = minf(s.value, float(e["cap"]))
	# Ferrugem de Óleo: os bónus de +Poder e +Mult das relíquias contam ×1.5.
	if kind == "relic" and battle.climate == "oil_rust" and (s.action == "power_add" or s.action == "mult_add"):
		s.value *= 1.5
	if s.grow > 0:
		s.label = TranslationServer.translate("Cresce +%d") % s.grow
	else:
		s.label = Cascade.label_for(s.action, s.value)
	if s.value == 0 and s.action != "mult_mul":
		return
	c.add(s)

func _do_retrigger(c: Cascade, target: String, e: Dictionary, source: CardInstance, depth: int) -> void:
	match target:
		"left":
			var t := _left_of(source)
			if t != null and _filter_ok(e.get("filter", {}), t):
				_creature_steps(c, t, depth + 1, true)
		"right":
			var t := _right_of(source)
			if t != null:
				_creature_steps(c, t, depth + 1, true)
		"self":
			if source != null and source.data.is_creature():
				_creature_steps(c, source, depth + 1, true)
			elif source != null:
				_spell_steps(c, source, depth + 1, true)
		"first":
			if not _attackers.is_empty():
				_creature_steps(c, _attackers[0], depth + 1, true)
		"all":
			for a in _attackers:
				if a != source:
					_creature_steps(c, a, depth + 1, true)
		"best":
			var best: CardInstance = null
			for a in _attackers:
				if a != source and (best == null or a.power() > best.power()):
					best = a
			if best != null:
				_creature_steps(c, best, depth + 1, true)
		"last_spell":
			if not _spells.is_empty():
				_spell_steps(c, _spells[_spells.size() - 1], depth + 1, true)
		"last_creature":
			if not _attackers.is_empty():
				_creature_steps(c, _attackers[_attackers.size() - 1], depth + 1, true)
		"spells":
			for sp in _spells:
				if sp != source:
					_spell_steps(c, sp, depth + 1, true)
		"formations":
			_retrigger_formations += 1
		"relics":
			_retrigger_relics += 1
		"hand":
			_retrigger_hand += 1

func _do_cascade_library(c: Cascade, pick: String, depth: int) -> void:
	var lib := battle.deck.library
	var chosen: CardInstance = null
	match pick:
		"top":
			if not lib.is_empty():
				chosen = lib[lib.size() - 1]
		"strongest":
			for x in lib:
				if x.data.is_creature() and (chosen == null or x.power() > chosen.power()):
					chosen = x
		"graveyard_spell":
			for x in battle.deck.graveyard:
				if x.data.is_spell():
					chosen = x
	if chosen == null:
		return
	if chosen.data.is_creature():
		_creature_steps(c, chosen, depth + 1, true)
	elif chosen.data.is_spell():
		_spell_steps(c, chosen, depth + 1, true)

# ---------------------------------------------------------------------------
# Formações
# ---------------------------------------------------------------------------

func _compute_formations() -> Array[String]:
	var out: Array[String] = []
	var n := _attackers.size()
	if (n == 0 and _spells.is_empty()) or battle.rule.get("no_formations", false):
		return out
	var creature_count := n
	for sp in _spells:
		if sp.data.counts_as_two:
			creature_count += 2
	# custos
	var cost_counts := {}
	var wild_costs := 0
	for a in _attackers:
		if a.data.token:
			continue   # as Fichas (custo 0) não fazem pares nem curvas
		if a.data.wild_cost:
			wild_costs += 1
		else:
			cost_counts[a.data.cost] = cost_counts.get(a.data.cost, 0) + 1
	var cost_form := _cost_formation(cost_counts.values(), wild_costs)
	if cost_form != "":
		out.append(cost_form)
	if creature_count >= 3:
		out.append("band")
	if _spells.size() >= 3:
		out.append("storm")
	# curva 1-2-3-4-5
	if n >= 5:
		var missing := 0
		for cost in range(1, 6):
			if not cost_counts.has(cost):
				missing += 1
		if missing <= wild_costs:
			out.append("curve")
	# devoção: alguma cor partilhada por 4+ atacantes (wild conta como qualquer)
	var wild_colors := 0
	var color_counts := {}
	for a in _attackers:
		if a.data.wild_color:
			wild_colors += 1
			continue
		for col in a.data.colors:
			color_counts[col] = color_counts.get(col, 0) + 1
	var best_color := 0
	for k in color_counts:
		best_color = max(best_color, color_counts[k])
	if best_color + wild_colors >= 4 and n >= 4:
		out.append("devotion")
	if n >= 5:
		out.append("horde")
	# WUBRG
	if n >= 5:
		var forced := false
		for a in _attackers:
			if a.data.force_formation == "wubrg":
				forced = true
		for sp in _spells:
			if sp.data.force_formation == "wubrg":
				forced = true
		var covered := {}
		for a in _attackers:
			for col in a.data.colors:
				covered[col] = true
		var missing_colors := 5 - covered.size()
		var wild_spells := 0   # 0.12.0: feitiços que contam como a cor em falta (Fenda de Mana)
		for sp in _spells:
			if sp.data.wild_color:
				wild_spells += 1
		if forced or missing_colors <= wild_colors + wild_spells:
			out.append("wubrg")
	return out

## Formação de custos (como no póquer, só a melhor conta): Quadra > Casa Cheia > Tríade >
## Pacto Duplo > Pacto Dual. As cartas com custo "selvagem" completam o grupo que mais falta faz.
static func _cost_formation(counts: Array, wild: int) -> String:
	var g: Array[int] = []
	for c in counts:
		g.append(int(c))
	g.sort()
	g.reverse()
	while g.size() < 2:
		g.append(0)
	var g1 := g[0]
	var g2 := g[1]
	if g1 + wild >= 4:
		return "quads"
	if maxi(0, 3 - g1) + maxi(0, 2 - g2) <= wild:
		return "full_house"
	if g1 + wild >= 3:
		return "trips"
	if maxi(0, 2 - g1) + maxi(0, 2 - g2) <= wild:
		return "two_pair"
	if g1 + wild >= 2:
		return "pair"
	return ""

## Uma formação "maior" também satisfaz as condições das que contém (Casa Cheia tem uma Tríade
## e um Pacto; a Quadra tem uma Tríade; o Pacto Duplo tem um Pacto).
const FORMATION_IMPLIES := {
	"two_pair": ["pair"],
	"full_house": ["trips", "pair"],
	"quads": ["trips"],
}

func has_formation(fid: String) -> bool:
	if fid in _formations:
		return true
	for f in _formations:
		if fid in FORMATION_IMPLIES.get(f, []):
			return true
	return false

# ---------------------------------------------------------------------------
# Contagens, filtros e condições
# ---------------------------------------------------------------------------

func _played() -> Array[CardInstance]:
	var out: Array[CardInstance] = []
	out.append_array(_attackers)
	out.append_array(_spells)
	return out

func _count(of: String, f: Dictionary, source: CardInstance, exclude_self: bool) -> int:
	var n := 0
	match of:
		"attacker":
			for a in _attackers:
				if exclude_self and a == source:
					continue
				if _filter_ok(f, a):
					n += 1
		"spell":
			for s in _spells:
				if exclude_self and s == source:
					continue
				if _filter_ok(f, s):
					n += 1
		"played":
			for p in _played():
				if exclude_self and p == source:
					continue
				if _filter_ok(f, p):
					n += 1
		"hand":
			for h in battle.deck.hand:
				if exclude_self and h == source:
					continue
				if _filter_ok(f, h):
					n += 1
		"graveyard":
			for g in battle.deck.graveyard:
				if _filter_ok(f, g):
					n += 1
		"library":
			n = battle.deck.library.size()
		"land_hand":
			n = battle.deck.lands_in_hand().size()
		"land":
			n = battle.ramp
		"gold":
			n = GameState.gold
		"colors":
			var seen := {}
			for p in _played():
				for col in p.data.colors:
					seen[col] = true
			n = seen.size()
		"graveyard_types":
			var seen := {}
			for g in battle.deck.graveyard:
				seen[g.data.type] = true
			n = seen.size()
		"relics":
			n = GameState.relic_ids.size()
		"drawn_this_turn":
			n = battle.drawn_this_turn
		"discards_used":
			n = battle.discards_used
		"neighbors":
			if source != null:
				if _left_of(source) != null:
					n += 1
				if _right_of(source) != null:
					n += 1
		"max_power":
			for a in _attackers:
				n = max(n, a.power())
		"formations":
			n = _formations.size()
		"tokens":
			for a in _attackers:
				if a.data.token and _filter_ok(f, a):
					n += 1
		"enchantments":
			n = battle.enchantments.size()
		"tribe":
			n = _tribe_n
		"keywords":
			# 0.12.0: palavras-chave nas criaturas atacantes (cada uma conta)
			for a in _attackers:
				if not silenced(a):
					n += a.keywords().size()
		"landfall":
			n = battle.landfalls
	return n

func _filter_ok(f: Dictionary, card: CardInstance) -> bool:
	if f.is_empty():
		return true
	if card == null:
		return false
	var d := card.data
	if f.has("color") and not d.has_color(String(f["color"])):
		return false
	if f.has("type") and not d.is_type(String(f["type"])):
		return false
	if f.has("subtype") and d.subtype != String(f["subtype"]):
		return false
	if f.get("colorless", false) and not d.is_colorless():
		return false
	if f.get("colored", false) and d.is_colorless():
		return false
	if not d.wild_cost:
		if f.has("cost") and d.cost != int(f["cost"]):
			return false
		if f.has("cost_min") and d.cost < int(f["cost_min"]):
			return false
		if f.has("cost_max") and d.cost > int(f["cost_max"]):
			return false
	if f.has("power_min") and card.power() < int(f["power_min"]):
		return false
	if f.has("tribe") and d.tribe != String(f["tribe"]):
		return false
	if f.has("token") and d.token != bool(f["token"]):
		return false
	if f.has("keyword") and not card.has_keyword(String(f["keyword"])):
		return false
	return true

func _cond_ok(e: Dictionary, source: CardInstance) -> bool:
	var cond: Dictionary = e.get("cond", {})
	if cond.is_empty():
		return true
	for key in cond:
		var v = cond[key]
		match key:
			"position":
				if source == null or not source.data.is_creature():
					return false
				var i := _attackers.find(source)
				if i < 0:
					return false
				var is_first := i == 0
				var is_last := i == 4
				if v == "first" and not is_first:
					return false
				if v == "last" and not is_last:
					return false
				if v == "edge" and not (is_first or is_last):
					return false
			"count":
				var n := _count(String(v.get("of", "attacker")), v.get("filter", {}), source, bool(e.get("exclude_self", false)))
				if v.has("min") and n < int(v["min"]):
					return false
				if v.has("max") and n > int(v["max"]):
					return false
			"formation":
				var any := false
				for fid in v:
					if has_formation(String(fid)):
						any = true
				if not any:
					return false
			"all_cost":
				for p in _played():
					if p.data.cost != int(v) and not p.data.wild_cost:
						return false
			"library_max":
				if battle.deck.library.size() > int(v):
					return false
			"hand_max":
				var others := 0
				for h in battle.deck.hand:
					if h != source:
						others += 1
				if others > int(v):
					return false
			"hand_min":
				if battle.deck.hand.size() < int(v):
					return false
			"discards_max":
				if battle.discards_left > int(v):
					return false
			"discards_min":
				if battle.discards_left < int(v):
					return false
			"gold_min":
				if GameState.gold < int(v):
					return false
			"enemy_hp_below_pct":
				if battle.enemy.hp * 100.0 / max(1, battle.enemy.max_hp) >= float(v):
					return false
			"discarded_min":
				if battle.discarded_this_turn < int(v):
					return false
			"discarded_max":
				if battle.discarded_this_turn > int(v):
					return false
			"neighbor_color":
				var ok := false
				for nb in [_left_of(source), _right_of(source)]:
					if nb != null and nb.data.has_color(String(v)):
						ok = true
				if not ok:
					return false
			"neighbor_cost":
				var ok := false
				for nb in [_left_of(source), _right_of(source)]:
					if nb != null and nb.data.cost == int(v):
						ok = true
				if not ok:
					return false
			"neighbors_min":
				var n := 0
				if _left_of(source) != null:
					n += 1
				if _right_of(source) != null:
					n += 1
				if n < int(v):
					return false
			"has_right":
				if _right_of(source) == null:
					return false
			"right_cost":
				var r := _right_of(source)
				if r == null or r.data.cost != int(v):
					return false
			"colors_all":
				var seen := {}
				for p in _played():
					for col in p.data.colors:
						seen[col] = true
				for col in v:
					if not seen.has(String(col)):
						return false
			"colors_any":
				var seen := {}
				for p in _played():
					for col in p.data.colors:
						seen[col] = true
				var any := false
				for col in v:
					if seen.has(String(col)):
						any = true
				if not any:
					return false
			"hand_has":
				for id in v:
					var found := false
					for h in battle.deck.hand:
						if h.data.id == String(id):
							found = true
					if not found:
						return false
			"hand_all_colorless":
				for h in battle.deck.hand:
					if not h.data.is_colorless():
						return false
			"consumed":
				if source == null or not source.consumed:
					return false
			_:
				pass
	return true
