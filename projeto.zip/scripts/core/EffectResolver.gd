class_name EffectResolver
extends RefCounted
## Interpreta os "effects" de cartas e relíquias (dados em JSON) contra o BattleManager.
## É aqui que vivem os "jokers": relíquias são efeitos permanentes que distorcem regras.
##
## Formato de um efeito: {"trigger": "...", "action": "...", "value": N, "filter": {...}, "per": "...", "min_attackers": N}
## Triggers: turn_start | land_played | creature_summoned | on_cast (feitiços) | passive | on_attack
## Actions imediatas: damage_enemy | heal_player | draw | buff_power | gold
## Actions passivas:  cost_reduction
## Actions de ataque (entram na cascata Poder × Mult): power_add | mult_add | mult_mul | grow
## "per" multiplica o valor pela contagem: attacker | graveyard | land  (respeita "filter")

var battle: BattleManager

func _init(p_battle: BattleManager) -> void:
	battle = p_battle

# ---------------------------------------------------------------------------
# Efeitos imediatos (triggers fora do ataque)
# ---------------------------------------------------------------------------

## Reúne efeitos de todas as relíquias ativas + cartas no tabuleiro.
func _active_effects() -> Array:
	var out: Array = []
	for relic_id in GameState.relic_ids:
		var relic: Dictionary = CardDB.relics.get(relic_id, {})
		for e in relic.get("effects", []):
			out.append({"effect": e, "source": relic.get("name", relic_id)})
	for c in battle.board:
		for e in c.data.effects:
			out.append({"effect": e, "source": c.data.name, "card": c})
	return out

func trigger(trigger_name: String, context: CardInstance = null) -> void:
	for entry in _active_effects():
		var e: Dictionary = entry.effect
		if e.get("trigger", "") != trigger_name:
			continue
		if not _passes_filter(e.get("filter", {}), context):
			continue
		_apply(e, context)

func resolve_spell(card: CardInstance) -> void:
	for e in card.data.effects:
		if e.get("trigger", "on_cast") == "on_cast":
			_apply(e, card)

## Custo efetivo de uma carta depois de reduções passivas.
func cost_of(card: CardInstance) -> int:
	var cost := card.data.cost
	for entry in _active_effects():
		var e: Dictionary = entry.effect
		if e.get("trigger") == "passive" and e.get("action") == "cost_reduction":
			if _passes_filter(e.get("filter", {}), card):
				cost -= int(e.get("value", 0))
	return max(0, cost)

func _passes_filter(f: Dictionary, card: CardInstance) -> bool:
	if f.is_empty():
		return true
	if card == null:
		return false
	if f.has("color") and card.data.color != f.color:
		return false
	if f.has("type") and card.data.type != f.type:
		return false
	return true

func _apply(e: Dictionary, _context: CardInstance) -> void:
	var v: int = int(e.get("value", 0))
	match e.get("action", ""):
		"damage_enemy":
			battle.damage_enemy(v)
		"heal_player":
			GameState.player_hp = min(GameState.player_max_hp, GameState.player_hp + v)
			EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)
		"draw":
			battle.deck.draw(v, GameState.rng)
		"buff_power":
			for c in battle.board:
				if c.data.is_creature() and _passes_filter(e.get("filter", {}), c):
					c.power_bonus += v
		"gold":
			GameState.add_gold(v)
		_:
			pass  # passivos e efeitos de ataque são tratados noutro sítio

# ---------------------------------------------------------------------------
# Cascata de ataque (Poder × Mult). Função PURA: não altera estado, por isso
# a UI pode chamá-la a qualquer momento para mostrar a pré-visualização.
# Ordem: criaturas (poder + efeitos próprios) → formações → relíquias.
# ---------------------------------------------------------------------------

func build_attack_cascade() -> Cascade:
	var c := Cascade.new()
	var attackers := battle.attackers()
	if attackers.is_empty():
		return c

	# 1. Cada criatura atacante, pela ordem do tabuleiro.
	for a in attackers:
		var s := Cascade.Step.new()
		s.source_kind = "creature"
		s.source_name = a.data.name
		s.source_card = a
		s.action = "power_add"
		s.value = a.power()
		s.label = Cascade.label_for("power_add", s.value)
		c.add(s)
		for e in a.data.effects:
			if e.get("trigger", "") == "on_attack":
				_add_attack_effect(c, e, "creature", a.data.name, a, "", attackers)

	# 2. Formações (o "tipo de mão" do Balatro).
	for f in CardDB.formations:
		if _formation_matches(f, attackers):
			var s := Cascade.Step.new()
			s.source_kind = "formation"
			s.source_name = f.get("name", f.get("id", ""))
			s.source_id = f.get("id", "")
			s.action = "mult_add"
			s.value = float(f.get("mult_add", 0))
			s.label = Cascade.label_for(s.action, s.value)
			c.add(s)
			c.formations.append(s.source_name)

	# 3. Relíquias, da esquerda para a direita.
	for relic_id in GameState.relic_ids:
		var relic: Dictionary = CardDB.relics.get(relic_id, {})
		for e in relic.get("effects", []):
			if e.get("trigger", "") == "on_attack":
				_add_attack_effect(c, e, "relic", relic.get("name", relic_id), null, relic_id, attackers)
	return c

func _add_attack_effect(c: Cascade, e: Dictionary, kind: String, name: String, card: CardInstance, relic_id: String, attackers: Array[CardInstance]) -> void:
	if attackers.size() < int(e.get("min_attackers", 0)):
		return
	var count := _count_per(e.get("per", ""), e.get("filter", {}), attackers)
	if count == 0:
		return
	var action: String = e.get("action", "")
	var s := Cascade.Step.new()
	s.source_kind = kind
	s.source_name = name
	s.source_card = card
	s.source_id = relic_id
	match action:
		"grow":
			# Verde: a criatura cresce de forma permanente E conta já neste ataque.
			s.action = "power_add"
			s.value = float(e.get("value", 0)) * count
			s.grow = int(s.value)
			s.label = "Cresce +%d" % s.grow
		"mult_mul":
			s.action = "mult_mul"
			s.value = float(e.get("value", 1.0))
			s.label = Cascade.label_for(s.action, s.value)
		"power_add", "mult_add":
			s.action = action
			s.value = float(e.get("value", 0)) * count
			s.label = Cascade.label_for(s.action, s.value)
		_:
			return
	c.add(s)

## Quantas vezes o efeito conta. "" = 1.
func _count_per(per: String, f: Dictionary, attackers: Array[CardInstance]) -> int:
	match per:
		"":
			return 1
		"attacker":
			var n := 0
			for a in attackers:
				if _passes_filter(f, a):
					n += 1
			return n
		"graveyard":
			var n := 0
			for g in battle.deck.graveyard:
				if _passes_filter(f, g):
					n += 1
			return n
		"land":
			return battle.mana_total
	return 0

func _formation_matches(f: Dictionary, attackers: Array[CardInstance]) -> bool:
	if attackers.size() < int(f.get("min_attackers", 1)):
		return false
	if f.get("same_color", false):
		var color: String = attackers[0].data.color
		for a in attackers:
			if a.data.color != color:
				return false
	return true
