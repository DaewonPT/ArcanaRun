class_name EffectResolver
extends RefCounted
## Interpreta os "effects" de cartas e relíquias (dados em JSON) contra o BattleManager.
##
## Formato: {"trigger", "action", "value", "per", "per_div", "cap", "filter", "cond", "exclude_self"}
##
## Triggers
##   on_attack        criatura, em cada ataque (cascata)
##   on_cast          feitiço: ações imediatas ao lançar; ações de cascata contam no ataque deste turno
##   on_play          criatura ao entrar (ações imediatas)
##   in_hand          carta na mão durante o ataque (cascata)
##   in_hand_on_play  carta na mão quando jogas uma criatura (grow_played)
##   on_discard       quando a carta é canalizada (descartada)
##   turn_start       início do turno (relíquias)
##   passive          cost_reduction (relíquias)
##
## Ações de cascata: power_add | mult_add | mult_mul | gold | grow | power_double_self | power_pct_enemy
##                   retrigger (left|right|self|all|first|best|last_spell|last_creature|spells|formations|relics|hand)
##                   cascade_library (top|strongest|graveyard_spell)
## Ações imediatas:  draw | gold | mill | mill_half | discard_random | silence_enemy | extra_turn | discard_plus
##                   consume_discard | shuffle_graveyard | enemy_max_hp_pct | recover | tutor_land |
##                   tutor_strongest | tutor_creature | grow_self | grow_hand | grow_left | grow_board |
##                   grow_played | grow_mult_self | destroy_left | destroy_right | enemy_vulnerable |
##                   heal_player | damage_enemy
##
## "per" conta: attacker | spell | played | hand | graveyard | library | land_hand | land | gold | colors |
##              graveyard_types | relics | drawn_this_turn | discards_used | neighbors | max_power
## "cond": ver _cond_ok.

const IMMEDIATE := ["draw", "mill", "mill_half", "discard_random", "silence_enemy", "extra_turn", "discard_plus",
	"consume_discard", "shuffle_graveyard", "enemy_max_hp_pct", "recover", "tutor_land", "tutor_strongest",
	"tutor_creature", "grow_self", "grow_hand", "grow_left", "grow_board", "grow_played", "grow_mult_self",
	"destroy_left", "destroy_right", "enemy_vulnerable", "heal_player", "damage_enemy", "buff_power"]

var battle: BattleManager

# Contexto de uma cascata em construção.
var _attackers: Array[CardInstance] = []
var _spells: Array[CardInstance] = []
var _formations: Array[String] = []
var _retrigger_formations: int = 0
var _retrigger_relics: int = 0
var _retrigger_hand: int = 0

func _init(p_battle: BattleManager) -> void:
	battle = p_battle

# ---------------------------------------------------------------------------
# Efeitos imediatos
# ---------------------------------------------------------------------------

func is_immediate(action: String) -> bool:
	return action in IMMEDIATE or (action == "gold" and true)

## Corre as ações imediatas de uma carta para um trigger (on_play, on_cast, on_discard).
func run_immediate(card: CardInstance, trigger: String) -> void:
	_prepare_context()
	for e in card.data.effects:
		if e.get("trigger", "") != trigger:
			continue
		var action: String = e.get("action", "")
		if not (action in IMMEDIATE or action == "gold"):
			continue
		if not _cond_ok(e, card):
			continue
		_apply_immediate(e, card)
	if trigger == "on_play":
		for h in battle.deck.hand:
			for e in h.data.effects:
				if e.get("trigger", "") == "in_hand_on_play" and _filter_ok(e.get("filter", {}), card):
					card.grow(int(e.get("value", 0)))
					EventBus.card_grew.emit(card, int(e.get("value", 0)))

## Relíquias: triggers simples (turn_start, land_played...).
func trigger_relics(trigger_name: String, context: CardInstance = null) -> void:
	for relic_id in GameState.relic_ids:
		var relic: Dictionary = CardDB.relics.get(relic_id, {})
		for e in relic.get("effects", []):
			if e.get("trigger", "") != trigger_name:
				continue
			if not _filter_ok(e.get("filter", {}), context):
				continue
			_apply_immediate(e, context)

## Custo efetivo de uma carta depois de reduções passivas (relíquias).
func cost_of(card: CardInstance) -> int:
	if card.data.is_land():
		return 0
	# Feitiços custam 1 a menos (mínimo 1): disparam uma vez, as criaturas atacam todos os turnos.
	var cost := card.data.cost
	if card.data.is_spell():
		cost = max(1, cost - 1)
	for relic_id in GameState.relic_ids:
		var relic: Dictionary = CardDB.relics.get(relic_id, {})
		for e in relic.get("effects", []):
			if e.get("trigger") == "passive" and e.get("action") == "cost_reduction":
				if _filter_ok(e.get("filter", {}), card):
					cost -= int(e.get("value", 0))
	return max(0, cost)

func _apply_immediate(e: Dictionary, source: CardInstance) -> void:
	var v := float(e.get("value", 0))
	var deck := battle.deck
	match e.get("action", ""):
		"draw":
			battle.draw(int(v))
		"gold":
			GameState.add_gold(int(v))
		"mill":
			deck.mill(int(v))
		"mill_half":
			deck.mill(int(deck.library.size() / 2))
		"discard_random":
			battle.discard_random(int(v))
		"silence_enemy":
			battle.silenced = true
		"extra_turn":
			battle.grant_extra_turn()
		"discard_plus":
			battle.discards_left += int(v)
		"consume_discard":
			if battle.discards_left > 0 and source != null:
				battle.discards_left -= 1
				source.consumed = true
		"shuffle_graveyard":
			deck.shuffle_graveyard_in()
		"enemy_max_hp_pct":
			var cut := int(round(battle.enemy.max_hp * v / 100.0))
			battle.enemy.max_hp = max(1, battle.enemy.max_hp - cut)
			battle.enemy.hp = min(battle.enemy.hp, battle.enemy.max_hp)
			EventBus.enemy_hp_changed.emit(battle.enemy.hp, battle.enemy.max_hp)
		"recover":
			deck.recover(int(v))
		"tutor_land":
			deck.tutor(func(c): return c.data.is_land())
		"tutor_strongest":
			deck.tutor_strongest()
		"tutor_creature":
			deck.tutor(func(c): return c.data.is_creature() and c.power() <= 25)
		"grow_self":
			if source != null:
				source.grow(int(v))
				EventBus.card_grew.emit(source, int(v))
		"grow_hand":
			for h in deck.hand:
				if h.data.is_creature():
					h.grow(int(v))
		"grow_left":
			var target := _left_of(source)
			if target != null:
				target.grow(int(v))
				EventBus.card_grew.emit(target, int(v))
		"grow_board":
			for c in battle.creatures():
				if e.get("exclude_self", false) and c == source:
					continue
				if _filter_ok(e.get("filter", {}), c):
					c.grow(int(v))
		"grow_mult_self":
			if source != null:
				source.grow_mult(v)
		"destroy_left":
			var target := _left_of(source)
			if target != null:
				battle.kill_creature(target)
		"destroy_right":
			var target := _right_of(source)
			if target != null:
				battle.kill_creature(target)
		"enemy_vulnerable":
			battle.enemy_vuln *= v
		"heal_player":
			GameState.player_hp = min(GameState.player_max_hp, GameState.player_hp + int(v))
			EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)
		"damage_enemy":
			battle.damage_enemy(int(v))
		"buff_power":
			for c in battle.creatures():
				if _filter_ok(e.get("filter", {}), c):
					c.power_bonus += int(v)

## Criatura à esquerda (jogada antes). Para feitiços: a última criatura do tabuleiro.
func _left_of(source: CardInstance) -> CardInstance:
	var cs := battle.creatures()
	if cs.is_empty():
		return null
	if source == null or not source.data.is_creature():
		return cs[cs.size() - 1]
	var i := cs.find(source)
	return cs[i - 1] if i > 0 else null

func _right_of(source: CardInstance) -> CardInstance:
	var cs := battle.creatures()
	if source == null or not source.data.is_creature():
		return null
	var i := cs.find(source)
	return cs[i + 1] if i >= 0 and i + 1 < cs.size() else null

# ---------------------------------------------------------------------------
# Cascata de ataque (Poder × Mult). Função PURA (não altera estado), por isso a UI
# pode chamá-la a qualquer momento para a pré-visualização.
# Ordem: criaturas → feitiços deste turno → formações → cartas na mão → relíquias.
# ---------------------------------------------------------------------------

func _prepare_context() -> void:
	_attackers = battle.attackers()
	_spells = battle.spells_this_turn
	_formations = _compute_formations()
	_retrigger_formations = 0
	_retrigger_relics = 0
	_retrigger_hand = 0

func build_attack_cascade() -> Cascade:
	var c := Cascade.new()
	_prepare_context()
	if _attackers.is_empty() and _spells.is_empty():
		return c
	c.damage_mult = battle.enemy_vuln

	# 1. Criaturas, pela ordem do tabuleiro.
	for a in _attackers:
		_creature_steps(c, a, 0)
	# 2. Feitiços lançados neste turno.
	for s in _spells:
		_spell_steps(c, s, 0)
	# 3. Formações.
	_formation_steps(c)
	for i in _retrigger_formations:
		_formation_steps(c, true)
	# 4. Cartas na mão com efeitos [Na Mão].
	_hand_steps(c)
	for i in _retrigger_hand:
		_hand_steps(c, true)
	# 5. Relíquias, da esquerda para a direita.
	_relic_steps(c)
	for i in _retrigger_relics:
		_relic_steps(c, true)
	return c

func _creature_steps(c: Cascade, a: CardInstance, depth: int, retrig: bool = false) -> void:
	var s := Cascade.Step.new()
	s.source_kind = "creature"
	s.source_name = a.data.name
	s.source_card = a
	s.action = "power_add"
	s.value = a.power()
	s.label = Cascade.label_for("power_add", s.value)
	s.retrigger = retrig
	c.add(s)
	if a.perm_mult() > 0.0:
		var m := Cascade.Step.new()
		m.source_kind = "creature"; m.source_name = a.data.name; m.source_card = a
		m.action = "mult_add"; m.value = a.perm_mult(); m.label = Cascade.label_for("mult_add", m.value); m.retrigger = retrig
		c.add(m)
	for e in a.data.effects:
		if e.get("trigger", "") != "on_attack":
			continue
		_effect_step(c, e, a, "creature", "", depth, retrig)

func _spell_steps(c: Cascade, sp: CardInstance, depth: int, retrig: bool = false) -> void:
	# O poder base do feitiço também conta (como no Mana Cascade).
	if sp.data.power > 0:
		var s := Cascade.Step.new()
		s.source_kind = "spell"; s.source_name = sp.data.name; s.source_card = sp
		s.action = "power_add"; s.value = sp.power(); s.label = Cascade.label_for("power_add", s.value); s.retrigger = retrig
		c.add(s)
	for e in sp.data.effects:
		if e.get("trigger", "") != "on_cast":
			continue
		_effect_step(c, e, sp, "spell", "", depth, retrig)

func _formation_steps(c: Cascade, retrig: bool = false) -> void:
	for fid in _formations:
		var f := CardDB.get_formation(fid)
		var s := Cascade.Step.new()
		s.source_kind = "formation"
		s.source_name = f.get("name", fid)
		s.source_id = fid
		s.action = "mult_add"
		s.value = float(f.get("mult_add", 0))
		s.label = Cascade.label_for(s.action, s.value)
		s.retrigger = retrig
		c.add(s)
		if not retrig:
			c.formations.append(s.source_name)
			c.formation_ids.append(fid)

func _hand_steps(c: Cascade, retrig: bool = false) -> void:
	for h in battle.deck.hand:
		for e in h.data.effects:
			if e.get("trigger", "") != "in_hand":
				continue
			_effect_step(c, e, h, "hand", "", 0, retrig)

func _relic_steps(c: Cascade, retrig: bool = false) -> void:
	for relic_id in GameState.relic_ids:
		var relic: Dictionary = CardDB.relics.get(relic_id, {})
		for e in relic.get("effects", []):
			if e.get("trigger", "") != "on_attack":
				continue
			_effect_step(c, e, null, "relic", relic_id, 0, retrig, relic.get("name", relic_id))

func _effect_step(c: Cascade, e: Dictionary, source: CardInstance, kind: String, relic_id: String, depth: int, retrig: bool, relic_name: String = "") -> void:
	var action: String = e.get("action", "")
	if action in IMMEDIATE:
		return   # imediatas correm fora da cascata
	if not _cond_ok(e, source):
		return
	if action == "retrigger":
		if depth >= 1:
			return
		_do_retrigger(c, String(e.get("value", "")), e, source, depth)
		return
	if action == "cascade_library":
		if depth >= 1:
			return
		_do_cascade_library(c, String(e.get("value", "top")), depth)
		return
	var count := 1
	if e.has("per"):
		count = _count(String(e["per"]), e.get("filter", {}), source, bool(e.get("exclude_self", false)))
		if e.has("per_div"):
			count = int(count / int(e["per_div"]))
		if count <= 0:
			return
	var value := float(e.get("value", 0))
	var s := Cascade.Step.new()
	s.source_kind = kind
	s.source_name = relic_name if kind == "relic" else (source.data.name if source != null else "")
	s.source_card = source
	s.source_id = relic_id
	s.retrigger = retrig
	match action:
		"power_add":
			s.action = "power_add"
			s.value = value * count
		"mult_add":
			s.action = "mult_add"
			s.value = value * count
		"mult_mul":
			s.action = "mult_mul"
			s.value = pow(value, count) if count > 1 else value
		"gold":
			s.action = "gold"
			s.value = value * count
		"grow":
			s.action = "power_add"
			s.value = value * count
			s.grow = int(s.value)
		"power_double_self":
			if source == null:
				return
			s.action = "power_add"
			s.value = source.power()
		"power_pct_enemy":
			s.action = "power_add"
			s.value = int(round(battle.enemy.hp * value / 100.0))
		_:
			return
	if e.has("cap") and s.action == "mult_add":
		s.value = minf(s.value, float(e["cap"]))
	if s.grow > 0:
		s.label = TranslationServer.translate("Cresce +%d") % s.grow
	else:
		s.label = Cascade.label_for(s.action, s.value)
	if s.value == 0 and s.action != "mult_mul":
		return
	c.add(s)

func _do_retrigger(c: Cascade, target: String, e: Dictionary, source: CardInstance, depth: int) -> void:
	match target:
		"left":
			var t := _left_of(source)
			if t != null and _filter_ok(e.get("filter", {}), t):
				_creature_steps(c, t, depth + 1, true)
		"right":
			var t := _right_of(source)
			if t != null:
				_creature_steps(c, t, depth + 1, true)
		"self":
			if source != null and source.data.is_creature():
				_creature_steps(c, source, depth + 1, true)
			elif source != null:
				_spell_steps(c, source, depth + 1, true)
		"first":
			if not _attackers.is_empty():
				_creature_steps(c, _attackers[0], depth + 1, true)
		"all":
			for a in _attackers:
				if a != source:
					_creature_steps(c, a, depth + 1, true)
		"best":
			var best: CardInstance = null
			for a in _attackers:
				if a != source and (best == null or a.power() > best.power()):
					best = a
			if best != null:
				_creature_steps(c, best, depth + 1, true)
		"last_spell":
			if not _spells.is_empty():
				_spell_steps(c, _spells[_spells.size() - 1], depth + 1, true)
		"last_creature":
			if not _attackers.is_empty():
				_creature_steps(c, _attackers[_attackers.size() - 1], depth + 1, true)
		"spells":
			for sp in _spells:
				if sp != source:
					_spell_steps(c, sp, depth + 1, true)
		"formations":
			_retrigger_formations += 1
		"relics":
			_retrigger_relics += 1
		"hand":
			_retrigger_hand += 1

func _do_cascade_library(c: Cascade, pick: String, depth: int) -> void:
	var lib := battle.deck.library
	var chosen: CardInstance = null
	match pick:
		"top":
			if not lib.is_empty():
				chosen = lib[lib.size() - 1]
		"strongest":
			for x in lib:
				if x.data.is_creature() and (chosen == null or x.power() > chosen.power()):
					chosen = x
		"graveyard_spell":
			for x in battle.deck.graveyard:
				if x.data.is_spell():
					chosen = x
	if chosen == null:
		return
	if chosen.data.is_creature():
		_creature_steps(c, chosen, depth + 1, true)
	elif chosen.data.is_spell():
		_spell_steps(c, chosen, depth + 1, true)

# ---------------------------------------------------------------------------
# Formações
# ---------------------------------------------------------------------------

func _compute_formations() -> Array[String]:
	var out: Array[String] = []
	var n := _attackers.size()
	if n == 0 and _spells.is_empty():
		return out
	var creature_count := n
	for sp in _spells:
		if sp.data.counts_as_two:
			creature_count += 2
	# custos
	var cost_counts := {}
	var wild_costs := 0
	for a in _attackers:
		if a.data.wild_cost:
			wild_costs += 1
		else:
			cost_counts[a.data.cost] = cost_counts.get(a.data.cost, 0) + 1
	var max_same := 0
	for k in cost_counts:
		max_same = max(max_same, cost_counts[k])
	max_same += wild_costs
	if max_same >= 3:
		out.append("trips")
	elif max_same >= 2:
		out.append("pair")
	if creature_count >= 3:
		out.append("band")
	if _spells.size() >= 3:
		out.append("storm")
	# curva 1-2-3-4-5
	if n >= 5:
		var missing := 0
		for cost in range(1, 6):
			if not cost_counts.has(cost):
				missing += 1
		if missing <= wild_costs:
			out.append("curve")
	# devoção: alguma cor partilhada por 4+ atacantes (wild conta como qualquer)
	var wild_colors := 0
	var color_counts := {}
	for a in _attackers:
		if a.data.wild_color:
			wild_colors += 1
			continue
		for col in a.data.colors:
			color_counts[col] = color_counts.get(col, 0) + 1
	var best_color := 0
	for k in color_counts:
		best_color = max(best_color, color_counts[k])
	if best_color + wild_colors >= 4 and n >= 4:
		out.append("devotion")
	if n >= 5:
		out.append("horde")
	# WUBRG
	if n >= 5:
		var forced := false
		for a in _attackers:
			if a.data.force_formation == "wubrg":
				forced = true
		for sp in _spells:
			if sp.data.force_formation == "wubrg":
				forced = true
		var covered := {}
		for a in _attackers:
			for col in a.data.colors:
				covered[col] = true
		var missing_colors := 5 - covered.size()
		if forced or missing_colors <= wild_colors:
			out.append("wubrg")
	return out

# ---------------------------------------------------------------------------
# Contagens, filtros e condições
# ---------------------------------------------------------------------------

func _played() -> Array[CardInstance]:
	var out: Array[CardInstance] = []
	out.append_array(_attackers)
	out.append_array(_spells)
	return out

func _count(of: String, f: Dictionary, source: CardInstance, exclude_self: bool) -> int:
	var n := 0
	match of:
		"attacker":
			for a in _attackers:
				if exclude_self and a == source:
					continue
				if _filter_ok(f, a):
					n += 1
		"spell":
			for s in _spells:
				if exclude_self and s == source:
					continue
				if _filter_ok(f, s):
					n += 1
		"played":
			for p in _played():
				if exclude_self and p == source:
					continue
				if _filter_ok(f, p):
					n += 1
		"hand":
			for h in battle.deck.hand:
				if exclude_self and h == source:
					continue
				if _filter_ok(f, h):
					n += 1
		"graveyard":
			for g in battle.deck.graveyard:
				if _filter_ok(f, g):
					n += 1
		"library":
			n = battle.deck.library.size()
		"land_hand":
			n = battle.deck.lands_in_hand().size()
		"land":
			n = battle.ramp
		"gold":
			n = GameState.gold
		"colors":
			var seen := {}
			for p in _played():
				for col in p.data.colors:
					seen[col] = true
			n = seen.size()
		"graveyard_types":
			var seen := {}
			for g in battle.deck.graveyard:
				seen[g.data.type] = true
			n = seen.size()
		"relics":
			n = GameState.relic_ids.size()
		"drawn_this_turn":
			n = battle.drawn_this_turn
		"discards_used":
			n = battle.discards_used
		"neighbors":
			if source != null:
				if _left_of(source) != null:
					n += 1
				if _right_of(source) != null:
					n += 1
		"max_power":
			for a in _attackers:
				n = max(n, a.power())
		"formations":
			n = _formations.size()
	return n

func _filter_ok(f: Dictionary, card: CardInstance) -> bool:
	if f.is_empty():
		return true
	if card == null:
		return false
	var d := card.data
	if f.has("color") and not d.has_color(String(f["color"])):
		return false
	if f.has("type") and not d.is_type(String(f["type"])):
		return false
	if f.has("subtype") and d.subtype != String(f["subtype"]):
		return false
	if f.get("colorless", false) and not d.is_colorless():
		return false
	if f.get("colored", false) and d.is_colorless():
		return false
	if not d.wild_cost:
		if f.has("cost") and d.cost != int(f["cost"]):
			return false
		if f.has("cost_min") and d.cost < int(f["cost_min"]):
			return false
		if f.has("cost_max") and d.cost > int(f["cost_max"]):
			return false
	if f.has("power_min") and card.power() < int(f["power_min"]):
		return false
	return true

func _cond_ok(e: Dictionary, source: CardInstance) -> bool:
	var cond: Dictionary = e.get("cond", {})
	if cond.is_empty():
		return true
	for key in cond:
		var v = cond[key]
		match key:
			"position":
				if source == null or not source.data.is_creature():
					return false
				var i := _attackers.find(source)
				if i < 0:
					return false
				var is_first := i == 0
				var is_last := i == 4
				if v == "first" and not is_first:
					return false
				if v == "last" and not is_last:
					return false
				if v == "edge" and not (is_first or is_last):
					return false
			"count":
				var n := _count(String(v.get("of", "attacker")), v.get("filter", {}), source, bool(e.get("exclude_self", false)))
				if v.has("min") and n < int(v["min"]):
					return false
				if v.has("max") and n > int(v["max"]):
					return false
			"formation":
				var any := false
				for fid in v:
					if String(fid) in _formations:
						any = true
				if not any:
					return false
			"all_cost":
				for p in _played():
					if p.data.cost != int(v) and not p.data.wild_cost:
						return false
			"library_max":
				if battle.deck.library.size() > int(v):
					return false
			"hand_max":
				var others := 0
				for h in battle.deck.hand:
					if h != source:
						others += 1
				if others > int(v):
					return false
			"hand_min":
				if battle.deck.hand.size() < int(v):
					return false
			"discards_max":
				if battle.discards_left > int(v):
					return false
			"discards_min":
				if battle.discards_left < int(v):
					return false
			"gold_min":
				if GameState.gold < int(v):
					return false
			"enemy_hp_below_pct":
				if battle.enemy.hp * 100.0 / max(1, battle.enemy.max_hp) >= float(v):
					return false
			"discarded_min":
				if battle.discarded_this_turn < int(v):
					return false
			"discarded_max":
				if battle.discarded_this_turn > int(v):
					return false
			"neighbor_color":
				var ok := false
				for nb in [_left_of(source), _right_of(source)]:
					if nb != null and nb.data.has_color(String(v)):
						ok = true
				if not ok:
					return false
			"neighbor_cost":
				var ok := false
				for nb in [_left_of(source), _right_of(source)]:
					if nb != null and nb.data.cost == int(v):
						ok = true
				if not ok:
					return false
			"neighbors_min":
				var n := 0
				if _left_of(source) != null:
					n += 1
				if _right_of(source) != null:
					n += 1
				if n < int(v):
					return false
			"has_right":
				if _right_of(source) == null:
					return false
			"right_cost":
				var r := _right_of(source)
				if r == null or r.data.cost != int(v):
					return false
			"colors_all":
				var seen := {}
				for p in _played():
					for col in p.data.colors:
						seen[col] = true
				for col in v:
					if not seen.has(String(col)):
						return false
			"colors_any":
				var seen := {}
				for p in _played():
					for col in p.data.colors:
						seen[col] = true
				var any := false
				for col in v:
					if seen.has(String(col)):
						any = true
				if not any:
					return false
			"hand_has":
				for id in v:
					var found := false
					for h in battle.deck.hand:
						if h.data.id == String(id):
							found = true
					if not found:
						return false
			"hand_all_colorless":
				for h in battle.deck.hand:
					if not h.data.is_colorless():
						return false
			"consumed":
				if source == null or not source.consumed:
					return false
			_:
				pass
	return true
