class_name Profiles
extends RefCounted
## 0.19.0 (291, 298): perfis de jogador — vários magos no mesmo telemóvel, cada um com o seu progresso,
## as suas configurações, os seus baralhos do Construtor e os seus jogos guardados.
## O perfil 1 usa os ficheiros de sempre (na raiz de user://), por isso quem já jogava não perde nada;
## os outros vivem em «user://perfil_N/». A lista fica em «user://profiles.json» (comum a todos).
## Cada perfil tem um nome (o nome do mago) e um retrato (uma das ilustrações desbloqueadas).

const PATH := "user://profiles.json"
const MAX := 4
const NAME_MAX := 20

static var _data: Dictionary = {}

static func _ensure() -> void:
	if not _data.is_empty():
		return
	var parsed = SaveIO.read_json(PATH)
	if parsed is Dictionary and parsed.get("list") is Array and not (parsed["list"] as Array).is_empty():
		_data = parsed
	else:
		_data = {"active": 1, "next": 2, "list": [{"id": 1, "name": "", "portrait": "", "created": Time.get_unix_time_from_system()}]}
	if get_profile(int(_data.get("active", 1))).is_empty():
		_data["active"] = 1

static func _save() -> void:
	SaveIO.write_json(PATH, _data)

## Perfil em uso.
static func active() -> int:
	_ensure()
	return int(_data.get("active", 1))

## Pasta dos ficheiros de um perfil (0 = o ativo). O perfil 1 é a raiz de user://.
static func dir(id: int = 0) -> String:
	var p := id if id > 0 else active()
	if p <= 1:
		return "user://"
	var d := "user://perfil_%d/" % p
	if not DirAccess.dir_exists_absolute(d):
		DirAccess.make_dir_recursive_absolute(d)
	return d

static func path(file: String, id: int = 0) -> String:
	return dir(id) + file

static func all() -> Array:
	_ensure()
	return (_data.get("list", []) as Array).duplicate(true)

static func get_profile(id: int) -> Dictionary:
	for p in _data.get("list", []):
		if p is Dictionary and int(p.get("id", 0)) == id:
			return p
	return {}

static func count() -> int:
	_ensure()
	return (_data.get("list", []) as Array).size()

static func can_add() -> bool:
	return count() < MAX

## Nome do mago de um perfil (o escrito ou «Mago N»).
static func name_of(id: int = 0) -> String:
	_ensure()
	var p := get_profile(id if id > 0 else active())
	var n := String(p.get("name", "")).strip_edges()
	return n if n != "" else TranslationServer.translate("Mago %d") % (id if id > 0 else active())

static func portrait_of(id: int = 0) -> String:
	_ensure()
	return String(get_profile(id if id > 0 else active()).get("portrait", ""))

static func clean_name(n: String) -> String:
	return n.strip_edges().replace("\n", " ").substr(0, NAME_MAX)

## Cria um perfil novo (sem progresso). Devolve o id, ou 0 se já houver MAX.
static func create(p_name: String = "") -> int:
	_ensure()
	if not can_add():
		return 0
	var id := int(_data.get("next", 2))
	_data["next"] = id + 1
	(_data["list"] as Array).append({"id": id, "name": clean_name(p_name), "portrait": "", "created": Time.get_unix_time_from_system()})
	_save()
	dir(id)
	return id

static func rename(id: int, p_name: String) -> void:
	_ensure()
	var p := get_profile(id)
	if p.is_empty():
		return
	p["name"] = clean_name(p_name)
	_save()

static func set_portrait(id: int, portrait: String) -> void:
	_ensure()
	var p := get_profile(id)
	if p.is_empty():
		return
	p["portrait"] = portrait
	_save()

## Apaga um perfil e os ficheiros dele (nunca o 1, nem o que está em uso).
static func remove(id: int) -> bool:
	_ensure()
	if id <= 1 or id == active():
		return false
	var list: Array = _data["list"]
	for i in range(list.size() - 1, -1, -1):
		if int(list[i].get("id", 0)) == id:
			list.remove_at(i)
	var d := "user://perfil_%d/" % id
	if DirAccess.dir_exists_absolute(d):
		for f in DirAccess.get_files_at(d):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(d + f))
		DirAccess.remove_absolute(ProjectSettings.globalize_path(d))
	_save()
	return true

## Muda de perfil: grava o atual, troca e volta a carregar configurações, progresso, baralhos e jogos.
static func switch_to(id: int) -> bool:
	_ensure()
	if get_profile(id).is_empty() or id == active():
		return false
	Settings.save_settings()
	GameState.save_progress()
	_data["active"] = id
	_save()
	reload_all()
	return true

## Volta a ler tudo o que é do perfil (depois de mudar de perfil).
static func reload_all() -> void:
	Settings.reload_profile()
	CardDB.load_custom_decks()
	GameState.reload_profile()

## Para os testes: esquece o que está em memória (o ficheiro volta a ser lido).
static func reset_cache() -> void:
	_data = {}
