class_name CardData
extends RefCounted
## Definição imutável de uma carta (vem do cards.json gerado a partir da base de 300 cartas).

const ALL_COLORS := ["white", "blue", "black", "red", "green"]

var id: String
var num: int = 0
var name: String
var deck: int = 0
var type: String        # "land" | "creature" | "spell"
var subtype: String = ""   # "instant" | "sorcery" | ""
var colors: Array[String] = []   # vazio = incolor
var cost: int = 0
var power: int = 0
var toughness: int = 0
var rarity: String = "common"
var price: int = 4
var text: String = ""
var effects: Array = []   # lista de dicts — ver EffectResolver
var approx: bool = false
var wild_color: bool = false      # conta como qualquer cor nas formações
var wild_cost: bool = false       # conta como qualquer custo nas formações
var counts_as_two: bool = false   # conta como 2 criaturas para Bando
var counts_as: Array = []         # tipos extra para filtros/formações
var force_formation: String = ""  # força uma formação com 5 atacantes
var return_to_library: bool = false

static func from_dict(d: Dictionary) -> CardData:
	var c := CardData.new()
	c.id = d.get("id", "")
	c.num = int(d.get("num", 0))
	c.name = d.get("name", c.id)
	c.deck = int(d.get("deck", 0))
	c.type = d.get("type", "creature")
	c.subtype = d.get("subtype", "")
	for col in d.get("colors", []):
		c.colors.append(String(col))
	c.cost = int(d.get("cost", 0))
	c.power = int(d.get("power", 0))
	c.toughness = int(d.get("toughness", 0))
	c.rarity = d.get("rarity", "common")
	c.price = int(d.get("price", 4))
	c.text = d.get("text", "")
	c.effects = d.get("effects", [])
	c.approx = bool(d.get("approx", false))
	c.wild_color = bool(d.get("wild_color", false))
	c.wild_cost = bool(d.get("wild_cost", false))
	c.counts_as_two = bool(d.get("counts_as_two", false))
	c.counts_as = d.get("counts_as", [])
	c.force_formation = d.get("force_formation", "")
	c.return_to_library = bool(d.get("return_to_library", false))
	return c

func is_land() -> bool:
	return type == "land"

func is_creature() -> bool:
	return type == "creature"

func is_spell() -> bool:
	return type == "spell"

func is_colorless() -> bool:
	return colors.is_empty()

func has_color(color: String) -> bool:
	return wild_color or color in colors

func is_type(t: String) -> bool:
	return type == t or t in counts_as

## Cor principal para a UI (a primeira; "colorless" se não tiver).
func primary_color() -> String:
	return colors[0] if not colors.is_empty() else "colorless"
