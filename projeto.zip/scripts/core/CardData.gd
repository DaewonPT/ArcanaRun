class_name CardData
extends RefCounted
## Definição imutável de uma carta (vem do cards.json gerado a partir da base de 300 cartas).
## Variantes derivadas (face transformada, cor alterada na Fonte, habilidade fundida no Altar,
## carta infetada) são cópias com os campos trocados — o resto do motor só lê `card.data`.

const ALL_COLORS := ["white", "blue", "black", "red", "green"]

var id: String
var num: int = 0
var name: String
var deck: int = 0
var type: String        # "land" | "creature" | "spell"
var subtype: String = ""   # "instant" | "sorcery" | ""
var colors: Array[String] = []   # vazio = incolor
var cost: int = 0
var power: int = 0
var toughness: int = 0
var rarity: String = "common"
var price: int = 4
var text: String = ""
var effects: Array = []   # lista de dicts — ver EffectResolver
var approx: bool = false
var wild_color: bool = false      # conta como qualquer cor nas formações
var wild_cost: bool = false       # conta como qualquer custo nas formações
var counts_as_two: bool = false   # conta como 2 criaturas para Bando
var counts_as: Array = []         # tipos extra para filtros/formações
var force_formation: String = ""  # força uma formação com 5 atacantes
var return_to_library: bool = false
var flashback: bool = false       # Recapitular: pode ser lançada do cemitério (vai para o exílio)
var mission: Dictionary = {}      # dupla face: {"trigger", "count"}; vazio = carta normal
var transformed: Dictionary = {}  # face de trás: {"name", "power", "toughness", "text", "effects"}
var is_back: bool = false         # esta definição é a face de trás (já transformada)
var fused_text: String = ""       # texto herdado no Altar (mostrado à parte)
var infected: bool = false        # Infeção de Óleo: Poder a dobrar, exila-se ao fim de 3 utilizações

static func from_dict(d: Dictionary) -> CardData:
	var c := CardData.new()
	c.id = d.get("id", "")
	c.num = int(d.get("num", 0))
	c.name = d.get("name", c.id)
	c.deck = int(d.get("deck", 0))
	c.type = d.get("type", "creature")
	c.subtype = d.get("subtype", "")
	for col in d.get("colors", []):
		c.colors.append(String(col))
	c.cost = int(d.get("cost", 0))
	c.power = int(d.get("power", 0))
	c.toughness = int(d.get("toughness", 0))
	c.rarity = d.get("rarity", "common")
	c.price = int(d.get("price", 4))
	c.text = d.get("text", "")
	c.effects = d.get("effects", [])
	c.approx = bool(d.get("approx", false))
	c.wild_color = bool(d.get("wild_color", false))
	c.wild_cost = bool(d.get("wild_cost", false))
	c.counts_as_two = bool(d.get("counts_as_two", false))
	c.counts_as = d.get("counts_as", [])
	c.force_formation = d.get("force_formation", "")
	c.return_to_library = bool(d.get("return_to_library", false))
	c.flashback = bool(d.get("flashback", false))
	c.mission = d.get("mission", {})
	c.transformed = d.get("transformed", {})
	return c

func copy() -> CardData:
	var c := CardData.new()
	c.id = id; c.num = num; c.name = name; c.deck = deck; c.type = type; c.subtype = subtype
	c.colors = colors.duplicate(); c.cost = cost; c.power = power; c.toughness = toughness
	c.rarity = rarity; c.price = price; c.text = text; c.effects = effects.duplicate(true)
	c.approx = approx; c.wild_color = wild_color; c.wild_cost = wild_cost; c.counts_as_two = counts_as_two
	c.counts_as = counts_as.duplicate(); c.force_formation = force_formation; c.return_to_library = return_to_library
	c.flashback = flashback; c.mission = mission; c.transformed = transformed; c.is_back = is_back
	c.fused_text = fused_text; c.infected = infected
	return c

## Tem uma face de trás e uma missão para lá chegar?
func has_mission() -> bool:
	return not is_back and not mission.is_empty() and not transformed.is_empty()

## A face de trás: mesma carta (id, cor, custo), com nome, Poder, resistência, texto e efeitos novos.
func back_face() -> CardData:
	var c := copy()
	c.is_back = true
	c.name = String(transformed.get("name", name))
	c.power = int(transformed.get("power", power))
	c.toughness = int(transformed.get("toughness", toughness))
	c.text = String(transformed.get("text", text))
	c.effects = (transformed.get("effects", []) as Array).duplicate(true)
	if infected:
		c.power *= 2
	return c

## Variante com as alterações permanentes guardadas na entrada do baralho (Fonte, Altar, Infeção).
func with_entry(entry: Dictionary) -> CardData:
	if entry.is_empty() or not (entry.has("colors") or entry.has("extra_effects") or entry.get("infected", false)):
		return self
	var c := copy()
	if entry.has("colors"):
		c.colors.clear()
		for col in entry["colors"]:
			c.colors.append(String(col))
	if entry.has("extra_effects"):
		c.effects.append_array((entry["extra_effects"] as Array).duplicate(true))
		c.fused_text = String(entry.get("extra_text", ""))
	if entry.get("infected", false):
		c.infected = true
		c.power *= 2
	return c

func is_land() -> bool:
	return type == "land"

func is_creature() -> bool:
	return type == "creature"

func is_spell() -> bool:
	return type == "spell"

func is_colorless() -> bool:
	return colors.is_empty()

func has_color(color: String) -> bool:
	return wild_color or color in colors

func is_type(t: String) -> bool:
	return type == t or t in counts_as

## Cor principal para a UI (a primeira; "colorless" se não tiver).
func primary_color() -> String:
	return colors[0] if not colors.is_empty() else "colorless"
