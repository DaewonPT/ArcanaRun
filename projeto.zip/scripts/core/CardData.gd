class_name CardData
extends RefCounted
## Definição imutável de uma carta (vem do cards.json gerado a partir da base de 300 cartas).
## Variantes derivadas (face transformada, cor alterada na Fonte, habilidade fundida no Altar,
## carta infetada) são cópias com os campos trocados — o resto do motor só lê `card.data`.

const ALL_COLORS := ["white", "blue", "black", "red", "green"]

var id: String
var num: int = 0
var name: String
var deck: int = 0
var type: String        # "land" | "creature" | "spell"
var subtype: String = ""   # "instant" | "sorcery" | ""
var colors: Array[String] = []   # vazio = incolor
var cost: int = 0
var power: int = 0
var toughness: int = 0
var rarity: String = "common"
var price: int = 4
var text: String = ""
var effects: Array = []   # lista de dicts — ver EffectResolver
var approx: bool = false
var wild_color: bool = false      # conta como qualquer cor nas formações
var wild_cost: bool = false       # conta como qualquer custo nas formações
var counts_as_two: bool = false   # conta como 2 criaturas para Bando
var counts_as: Array = []         # tipos extra para filtros/formações
var force_formation: String = ""  # força uma formação com 5 atacantes
var return_to_library: bool = false
var flashback: bool = false       # Recapitular: pode ser lançada do cemitério (vai para o exílio)
var mission: Dictionary = {}      # dupla face: {"trigger", "count"}; vazio = carta normal
var transformed: Dictionary = {}  # face de trás: {"name", "power", "toughness", "text", "effects"}
var is_back: bool = false         # esta definição é a face de trás (já transformada)
var fused_text: String = ""       # texto herdado no Altar (mostrado à parte)
var infected: bool = false        # Infeção de Óleo: Poder a dobrar, exila-se ao fim de 3 utilizações
# 0.10.0
var tribe: String = ""            # goblin | elf | zombie | angel | dragon | soldier ("" = nenhuma)
var token: bool = false           # Ficha: criada em jogo, desaparece ao morrer e no fim da batalha
var kicker: Dictionary = {}       # Reforço: {"cost", "text", "effects"} — mana extra por efeitos extra
var rules: Array = []             # Míticas e alguns encantamentos: regras que mudam o jogo (ver BattleManager.has_rule)
var locked: bool = false          # só entra nos sorteios depois de desbloqueada (conquistas)
var plus: bool = false            # versão "+" (Acampamento → Forjar): efeitos ×1,5
var plus_pairs: Array = []        # [[texto antigo, texto novo], …] para mostrar os números novos
var plus_power: int = 0           # versão "+" de uma carta sem efeitos numéricos: Poder ganho
# 0.11.0
var keywords: Array = []          # "vigilance" | "lifelink" | "protection" | 0.12.0: "flying" | "trample" | "first_strike"
# 0.12.0
var special_land: bool = false    # Terreno especial: aparece na loja (os outros só vêm com os baralhos)

const KEYWORD_NAMES := {"vigilance": "Vigilância", "lifelink": "Vínculo Vital", "protection": "Proteção",
	"flying": "Voar", "trample": "Atropelar", "first_strike": "Primeiro Golpe"}
const KEYWORD_TEXT := {
	"vigilance": "Vigilância: bloqueia o contra-ataque sem sofrer dano.",
	"lifelink": "Vínculo Vital: cada vez que ataca, curas 1.",
	"protection": "Proteção: as habilidades do inimigo não lhe tocam.",
	"flying": "Voar: os lacaios do inimigo não a travam.",
	"trample": "Atropelar: corta a meio o escudo do inimigo (cada uma com Atropelar).",
	"first_strike": "Primeiro Golpe: dispara antes das outras criaturas na cascata.",
}
const KEYWORDS := ["vigilance", "lifelink", "protection", "flying", "trample", "first_strike"]

const PLUS_FACTOR := 1.5
const PLUS_COUNT_ACTIONS := ["draw", "create_token", "recover", "discard_plus", "mana_now", "mill", "bonus_turn"]
## Como cada contagem aparece no texto (PT e EN), para a versão "+" mostrar o número novo.
const COUNT_PREFIXES := {
	"draw": ["Compra ", "compra ", "compras ", "compra mais ", "Draw ", "draw ", "draws "],
	"create_token": ["Cria ", "cria ", "Create ", "create ", "creates "],
	"recover": ["devolve ", "Devolve ", "return ", "Return "],
	"mana_now": ["+"],
}
## De 1 para 2 o nome passa ao plural ("cria 1 Ficha" → "cria 2 Fichas").
const COUNT_NOUNS := {
	"draw": [["carta", "cartas"], ["card", "cards"]],
	"create_token": [["Ficha", "Fichas"], ["Soldier token", "Soldier tokens"], ["token", "tokens"]],
	"recover": [["carta", "cartas"], ["card", "cards"]],
}
## (self_damage e cost_reduction ficam iguais: um é um custo, o outro já é forte.)
const PLUS_SCALE_ACTIONS := ["power_add", "mult_add", "gold", "heal", "heal_player", "grow", "grow_self", "grow_hand",
	"grow_left", "grow_board", "grow_played", "grow_weakest", "buff_power", "buff_right", "devour_token", "damage_enemy"]

static func from_dict(d: Dictionary) -> CardData:
	var c := CardData.new()
	c.id = d.get("id", "")
	c.num = int(d.get("num", 0))
	c.name = d.get("name", c.id)
	c.deck = int(d.get("deck", 0))
	c.type = d.get("type", "creature")
	c.subtype = d.get("subtype", "")
	for col in d.get("colors", []):
		c.colors.append(String(col))
	c.cost = int(d.get("cost", 0))
	c.power = int(d.get("power", 0))
	c.toughness = int(d.get("toughness", 0))
	c.rarity = d.get("rarity", "common")
	c.price = int(d.get("price", 4))
	c.text = d.get("text", "")
	c.effects = d.get("effects", [])
	c.approx = bool(d.get("approx", false))
	c.wild_color = bool(d.get("wild_color", false))
	c.wild_cost = bool(d.get("wild_cost", false))
	c.counts_as_two = bool(d.get("counts_as_two", false))
	c.counts_as = d.get("counts_as", [])
	c.force_formation = d.get("force_formation", "")
	c.return_to_library = bool(d.get("return_to_library", false))
	c.flashback = bool(d.get("flashback", false))
	c.mission = d.get("mission", {})
	c.transformed = d.get("transformed", {})
	c.tribe = String(d.get("tribe", ""))
	c.token = bool(d.get("token", false))
	c.kicker = d.get("kicker", {}) if d.get("kicker") is Dictionary else {}
	c.rules = d.get("rules", []) if d.get("rules") is Array else []
	c.locked = bool(d.get("locked", false))
	c.keywords = d.get("keywords", []) if d.get("keywords") is Array else []
	c.special_land = bool(d.get("special_land", false))
	return c

func copy() -> CardData:
	var c := CardData.new()
	c.id = id; c.num = num; c.name = name; c.deck = deck; c.type = type; c.subtype = subtype
	c.colors = colors.duplicate(); c.cost = cost; c.power = power; c.toughness = toughness
	c.rarity = rarity; c.price = price; c.text = text; c.effects = effects.duplicate(true)
	c.approx = approx; c.wild_color = wild_color; c.wild_cost = wild_cost; c.counts_as_two = counts_as_two
	c.counts_as = counts_as.duplicate(); c.force_formation = force_formation; c.return_to_library = return_to_library
	c.flashback = flashback; c.mission = mission; c.transformed = transformed; c.is_back = is_back
	c.fused_text = fused_text; c.infected = infected
	c.tribe = tribe; c.token = token; c.kicker = kicker.duplicate(true); c.rules = rules.duplicate(); c.locked = locked
	c.plus = plus; c.plus_pairs = plus_pairs.duplicate(true); c.plus_power = plus_power
	c.keywords = keywords.duplicate()
	c.special_land = special_land
	return c

func has_keyword(k: String) -> bool:
	return k in keywords

## Nomes das palavras-chave, traduzidos ("Vigilância · Proteção"); "" se não tiver.
func keywords_line() -> String:
	var names: PackedStringArray = []
	for k in keywords:
		names.append(TranslationServer.translate(String(KEYWORD_NAMES.get(k, k))))
	return " · ".join(names)

func has_kicker() -> bool:
	return not kicker.is_empty() and int(kicker.get("cost", 0)) > 0

func is_enchantment() -> bool:
	return type == "enchantment"

func is_mythic() -> bool:
	return rarity == "mythic"

## Nome para mostrar (traduzido; "+" na versão melhorada).
func display_name() -> String:
	return TranslationServer.translate(name) + ("+" if plus else "")

## Texto para mostrar (traduzido; na versão "+" com os números novos).
func display_text() -> String:
	var t := TranslationServer.translate(text)
	if not plus:
		return t
	var out := _plus_numbers(t)
	if out == t:
		if plus_power > 0:
			out += " " + TranslationServer.translate("(Versão +: +%d Poder.)") % plus_power
		else:
			out += " " + TranslationServer.translate("(Versão +: efeitos ×1,5.)")
	return out

## Texto do Reforço para mostrar (traduzido; na versão "+" com os números novos).
func display_kicker_text() -> String:
	var t := TranslationServer.translate(String(kicker.get("text", "")))
	return _plus_numbers(t) if plus else t

## Troca os números antigos pelos da versão "+" (o custo do Reforço fica igual).
func _plus_numbers(t: String) -> String:
	for pair in plus_pairs:
		var re := RegEx.new()
		re.compile("(?<![0-9.,])(?<!Reforço )(?<!Kicker )" + _re_escape(String(pair[0])) + "(?![0-9])")
		t = re.sub(t, String(pair[1]), true)
	return t

static func _re_escape(s: String) -> String:
	var out := ""
	for ch in s:
		if ch in ".+*?^$()[]{}|\\":
			out += "\\"
		out += ch
	return out

## Versão "+" (Acampamento → Forjar): valores dos efeitos ×1,5 (contagens +1; ×Mult cresce a parte
## acima de 1); cartas sem efeitos ganham +15 Poder. Também melhora o Reforço e a face de trás.
func plus_version() -> CardData:
	var c := copy()
	c._apply_plus()
	return c

func _apply_plus() -> void:
	if plus:
		return
	plus = true
	plus_pairs.clear()
	var any := false
	var boosted: Array = []
	for e in effects:
		var ne: Dictionary = _plus_effect(e)
		if ne.hash() != (e as Dictionary).hash():
			any = true
		boosted.append(ne)
	effects = boosted
	if has_kicker():
		var kb: Array = []
		for e in kicker.get("effects", []):
			kb.append(_plus_effect(e))
		kicker["effects"] = kb
	if not any and (is_creature() or is_spell()):
		plus_power = 15
		power += 15

func _plus_effect(e: Dictionary) -> Dictionary:
	var ne := e.duplicate(true)
	var action := String(e.get("action", ""))
	var raw = e.get("value", null)
	if not (raw is int or raw is float):
		return ne
	var v := float(raw)
	if action == "mult_mul":
		var nv := snappedf(1.0 + (v - 1.0) * PLUS_FACTOR, 0.1)
		if bool(e.get("linear", false)):
			nv = snappedf(v * PLUS_FACTOR, 0.01)
		ne["value"] = nv
		_note_pair("×" + _fmt(v), "×" + _fmt(nv))
	elif action in PLUS_COUNT_ACTIONS:
		ne["value"] = int(v) + 1
		if int(v) == 1:
			for prefix in COUNT_PREFIXES.get(action, []):
				for noun in COUNT_NOUNS.get(action, []):
					_note_pair(String(prefix) + "1 " + String(noun[0]), String(prefix) + "2 " + String(noun[1]))
		for prefix in COUNT_PREFIXES.get(action, []):
			_note_pair(String(prefix) + str(int(v)), String(prefix) + str(int(v) + 1))
	elif action in PLUS_SCALE_ACTIONS:
		var nv2 := snappedf(v * PLUS_FACTOR, 0.5) if action == "mult_add" else float(int(round(v * PLUS_FACTOR)))
		ne["value"] = nv2 if action == "mult_add" else int(nv2)
		_note_pair("+" + _fmt(v), "+" + _fmt(nv2))
	if e.has("cap"):
		ne["cap"] = snappedf(float(e["cap"]) * PLUS_FACTOR, 0.5)
		_note_pair("+" + _fmt(float(e["cap"])) + ")", "+" + _fmt(float(ne["cap"])) + ")")
	return ne

func _note_pair(a: String, b: String) -> void:
	if a == b:
		return
	for p in plus_pairs:
		if String(p[0]) == a:
			return
	plus_pairs.append([a, b])

static func _fmt(v: float) -> String:
	if is_equal_approx(v, round(v)):
		return str(int(round(v)))
	var s := "%.2f" % v
	while s.ends_with("0"):
		s = s.substr(0, s.length() - 1)
	return s

## Tem uma face de trás e uma missão para lá chegar?
func has_mission() -> bool:
	return not is_back and not mission.is_empty() and not transformed.is_empty()

## A face de trás: mesma carta (id, cor, custo), com nome, Poder, resistência, texto e efeitos novos.
func back_face() -> CardData:
	var c := copy()
	c.is_back = true
	c.name = String(transformed.get("name", name))
	c.power = int(transformed.get("power", power))
	c.toughness = int(transformed.get("toughness", toughness))
	c.text = String(transformed.get("text", text))
	c.effects = (transformed.get("effects", []) as Array).duplicate(true)
	if infected:
		c.power *= 2
	if plus:
		c.plus = false
		c.plus_power = 0
		c._apply_plus()
	return c

## Variante com as alterações permanentes guardadas na entrada do baralho (Fonte, Altar, Infeção, "+").
func with_entry(entry: Dictionary) -> CardData:
	if entry.is_empty() or not (entry.has("colors") or entry.has("extra_effects") or entry.get("infected", false) or entry.get("plus", false) or entry.has("keywords_plus")):
		return self
	var c := copy()
	# 0.12.0: palavras-chave ganhas para sempre (eventos Templo do Céu, Fosso dos Gladiadores, Debandada).
	for k in entry.get("keywords_plus", []):
		if not (String(k) in c.keywords):
			c.keywords.append(String(k))
	if entry.has("colors"):
		c.colors.clear()
		for col in entry["colors"]:
			c.colors.append(String(col))
	if entry.has("extra_effects"):
		c.effects.append_array((entry["extra_effects"] as Array).duplicate(true))
		c.fused_text = String(entry.get("extra_text", ""))
	if entry.get("infected", false):
		c.infected = true
		c.power *= 2
	if entry.get("plus", false):
		c._apply_plus()
	return c

func is_land() -> bool:
	return type == "land"

func is_creature() -> bool:
	return type == "creature"

func is_spell() -> bool:
	return type == "spell"

## Maldição: não se joga; só sai da mão canalizando-a (ou removendo-a na loja).
func is_curse() -> bool:
	return type == "curse"

func is_colorless() -> bool:
	return colors.is_empty()

func has_color(color: String) -> bool:
	return wild_color or color in colors

func is_type(t: String) -> bool:
	return type == t or t in counts_as

## Cor principal para a UI (a primeira; "colorless" se não tiver).
func primary_color() -> String:
	return colors[0] if not colors.is_empty() else "colorless"
