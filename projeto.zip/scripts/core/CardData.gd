class_name CardData
extends RefCounted
## Definição imutável de uma carta (vem do cards.json).

var id: String
var name: String
var type: String        # "land" | "creature" | "spell"
var color: String       # "white" | "red" | "green" | "blue" | "black" | "colorless"
var cost: int = 0
var power: int = 0
var toughness: int = 0
var rarity: String = "common"   # "starter" | "common" | "uncommon" | "rare"
var price: int = 3
var text: String = ""
var effects: Array = []   # lista de dicts {trigger, action, value} — ver docs/CARD_EFFECTS.md

static func from_dict(d: Dictionary) -> CardData:
	var c := CardData.new()
	c.id = d.get("id", "")
	c.name = d.get("name", c.id)
	c.type = d.get("type", "creature")
	c.color = d.get("color", "colorless")
	c.cost = int(d.get("cost", 0))
	c.power = int(d.get("power", 0))
	c.toughness = int(d.get("toughness", 0))
	c.rarity = d.get("rarity", "common")
	c.price = int(d.get("price", 3))
	c.text = d.get("text", "")
	c.effects = d.get("effects", [])
	return c

func is_land() -> bool:
	return type == "land"

func is_creature() -> bool:
	return type == "creature"
