class_name CardSort
extends RefCounted
## 0.19.0 (34): ordenar listas de cartas à escolha (Coleção e Construtor): pelo número, pelo custo, pelo Poder,
## pelo nome, pela raridade, pela mestria, pelas vezes jogada ou pelo dano dado (estes três das tuas runs).

const KEYS := ["num", "cost", "power", "name", "rarity", "mastery", "plays", "dmg"]
const NAMES := {"num": "Ordem: número", "cost": "Ordem: custo", "power": "Ordem: Poder", "name": "Ordem: nome",
	"rarity": "Ordem: raridade", "mastery": "Ordem: mestria", "plays": "Ordem: mais jogadas", "dmg": "Ordem: mais dano"}
const RARITY_RANK := {"common": 0, "uncommon": 1, "rare": 2, "mythic": 3, "legendary": 4}

static func next_key(key: String) -> String:
	return String(KEYS[(KEYS.find(key) + 1) % KEYS.size()])

static func label(key: String) -> String:
	return TranslationServer.translate(String(NAMES.get(key, NAMES["num"])))

## Ordena uma lista de CardData (no sítio). Os empates ficam pelo número da carta.
static func sort(list: Array, key: String) -> void:
	if key == "num" or not (key in KEYS):
		list.sort_custom(func(a: CardData, b: CardData): return a.num < b.num)
		return
	var stats := GameState.card_stats()
	list.sort_custom(func(a: CardData, b: CardData):
		var va = _value(a, key, stats)
		var vb = _value(b, key, stats)
		if va != vb:
			return va > vb if key in ["power", "rarity", "mastery", "plays", "dmg"] else va < vb
		return a.num < b.num)

static func _value(d: CardData, key: String, stats: Dictionary):
	match key:
		"cost":
			return 99 if d.is_land() else d.cost
		"power":
			return d.power
		"name":
			return d.display_name().to_lower()
		"rarity":
			return int(RARITY_RANK.get(d.rarity, 0))
		"mastery":
			var s = stats.get(d.id, {})
			return GameState.mastery_of(s) * 100000 + int((s as Dictionary).get("plays", 0)) if s is Dictionary else 0
		"plays":
			var s2 = stats.get(d.id, {})
			return int((s2 as Dictionary).get("plays", 0)) if s2 is Dictionary else 0
		"dmg":
			var s3 = stats.get(d.id, {})
			return int((s3 as Dictionary).get("dmg", 0)) if s3 is Dictionary else 0
	return d.num
