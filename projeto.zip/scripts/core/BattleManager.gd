class_name BattleManager
extends Node
## Regras de uma batalha. Sem UI — a cena Battle.tscn liga-se aos sinais do EventBus.
##
## Loop: N turnos. Em cada turno: repõe a mão até 5, joga até 1 terreno, gasta mana em criaturas/feitiços.
## Ao terminar o turno TODAS as criaturas atacam (não há "summoning sickness") através de uma
## CASCATA (Poder × Mult): primeiro cada criatura, depois as formações, depois as relíquias.
## O inimigo responde com dano fixo: bloqueia a criatura mais robusta que SOBREVIVA ao golpe;
## se nenhuma sobreviver, o jogador leva o dano — a não ser que seja letal, e aí as criaturas
## sacrificam-se da mais fraca para a mais forte. Ganhas se a vida do inimigo chegar a 0.

const MAX_CREATURES := 5
const HAND_SIZE := 5

var deck: Deck
var board: Array[CardInstance] = []
var turn: int = 0
var max_turns: int = 6
var land_played_this_turn: bool = false
var mana_total: int = 0
var mana_available: int = 0
var resolving: bool = false   # true enquanto a cascata/fase inimiga está a correr
var finished: bool = false

var enemy: Dictionary = {}   # {name, hp, max_hp, attack, text, abilities}
var effects: EffectResolver
var enemy_abilities: EnemyAbilities

func start(enemy_def: Dictionary) -> void:
	enemy = enemy_def.duplicate()
	max_turns = GameState.turns_for_ante(GameState.ante)
	deck = Deck.new(GameState.deck_ids, GameState.rng)
	board.clear()
	effects = EffectResolver.new(self)
	enemy_abilities = EnemyAbilities.new(self)
	turn = 0
	resolving = false
	finished = false
	GameState.player_hp = GameState.player_max_hp   # cada batalha começa com a vida cheia
	EventBus.battle_started.emit(enemy)
	EventBus.enemy_hp_changed.emit(enemy.hp, enemy.max_hp)
	EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)
	deck.draw_opening_hand(HAND_SIZE, GameState.rng)
	next_turn()

func next_turn() -> void:
	turn += 1
	land_played_this_turn = false
	mana_available = mana_total
	if turn > 1:
		deck.refill(HAND_SIZE, GameState.rng)
	EventBus.mana_changed.emit(mana_available, mana_total)
	EventBus.turn_started.emit(turn)
	effects.trigger("turn_start")

# --- Consultas ---

func creatures() -> Array[CardInstance]:
	var out: Array[CardInstance] = []
	for c in board:
		if c.data.is_creature():
			out.append(c)
	return out

## Todas as criaturas atacam, incluindo as jogadas neste turno.
func attackers() -> Array[CardInstance]:
	return creatures()

## Pré-visualização do ataque atual (puro, não altera nada).
func preview_attack() -> Cascade:
	return effects.build_attack_cascade()

# --- Ações do jogador ---

func can_play(card: CardInstance) -> bool:
	if resolving or finished:
		return false
	if card.zone != CardInstance.Zone.HAND:
		return false
	if card.data.is_land():
		return not land_played_this_turn
	if card.data.is_creature() and creatures().size() >= MAX_CREATURES:
		return false
	return effects.cost_of(card) <= mana_available

func play(card: CardInstance) -> bool:
	if not can_play(card):
		return false
	deck.remove_from_hand(card)
	if card.data.is_land():
		land_played_this_turn = true
		mana_total += 1
		mana_available += 1
		card.zone = CardInstance.Zone.BOARD
		board.append(card)
		EventBus.land_played.emit(card)
		effects.trigger("land_played", card)
	else:
		mana_available -= effects.cost_of(card)
		if card.data.is_creature():
			card.zone = CardInstance.Zone.BOARD
			board.append(card)
			EventBus.creature_summoned.emit(card)
			effects.trigger("creature_summoned", card)
		else:
			effects.resolve_spell(card)
			deck.to_graveyard(card)
	EventBus.card_played.emit(card)
	EventBus.mana_changed.emit(mana_available, mana_total)
	if enemy.hp <= 0:
		_finish(true)
	return true

## Corrotina: a UI chama sem await. Se houver alguém ligado a cascade_started,
## espera que a animação acabe (cascade_finished) antes de aplicar o dano.
func end_turn() -> void:
	if resolving or finished:
		return
	resolving = true
	var cascade := effects.build_attack_cascade()
	if not cascade.is_empty():
		if EventBus.cascade_started.get_connections().size() > 0:
			EventBus.cascade_started.emit(cascade)
			await EventBus.cascade_finished
		_apply_cascade(cascade)
	if enemy.hp <= 0:
		_finish(true)
		return
	await _pause(0.45)
	_enemy_phase()
	if GameState.player_hp <= 0:
		_finish(false)
		return
	enemy_abilities.on_turn_end(turn)
	EventBus.hand_changed.emit()
	EventBus.turn_ended.emit(turn)
	if turn >= max_turns:
		_finish(false)
		return
	resolving = false
	next_turn()

# --- Fases internas ---

func _apply_cascade(cascade: Cascade) -> void:
	for s in cascade.steps:
		if s.grow > 0 and s.source_card != null:
			s.source_card.power_bonus += s.grow
	damage_enemy(cascade.total())

func damage_enemy(amount: int) -> void:
	if amount <= 0 or enemy.hp <= 0:
		return
	enemy.hp = max(0, enemy.hp - amount)
	EventBus.damage_dealt.emit("enemy", amount)
	EventBus.enemy_hp_changed.emit(enemy.hp, enemy.max_hp)

func _enemy_phase() -> void:
	var dmg: int = enemy.get("attack", 0)
	if dmg <= 0:
		return
	var blockers := creatures()
	# 1. Bloqueador seguro: a criatura mais robusta que sobreviva ao golpe.
	blockers.sort_custom(func(a, b): return a.remaining() > b.remaining())
	for b in blockers:
		if b.remaining() > dmg:
			b.damage += dmg
			EventBus.creature_blocked.emit(b, dmg)
			return
	# 2. Ninguém sobrevive: o jogador leva o dano, a não ser que seja letal.
	if GameState.player_hp > dmg:
		_damage_player(dmg)
		return
	# 3. Letal: as criaturas sacrificam-se, da mais fraca para a mais forte.
	blockers.sort_custom(func(a, b): return a.remaining() < b.remaining())
	for b in blockers:
		if dmg <= 0:
			break
		var absorbed: int = min(dmg, b.remaining())
		b.damage += absorbed
		dmg -= absorbed
		if b.is_dead():
			kill_creature(b)
	if dmg > 0:
		_damage_player(dmg)

func _damage_player(amount: int) -> void:
	GameState.player_hp -= amount
	EventBus.damage_dealt.emit("player", amount)
	EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)

## Único ponto de saída de uma criatura do tabuleiro — usado pelo bloqueio e pelas habilidades.
func kill_creature(card: CardInstance) -> void:
	if not (card in board):
		return
	board.erase(card)
	deck.to_graveyard(card)
	EventBus.creature_died.emit(card)

func _pause(seconds: float) -> void:
	if is_inside_tree() and EventBus.cascade_started.get_connections().size() > 0:
		await get_tree().create_timer(seconds).timeout

func _finish(victory: bool) -> void:
	if finished:
		return
	finished = true
	resolving = false
	if victory:
		GameState.add_gold(3 + GameState.ante)
	EventBus.battle_ended.emit(victory)
