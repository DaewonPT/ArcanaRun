class_name BattleManager
extends Node
## Regras de uma batalha. Sem UI — a cena Battle.tscn liga-se aos sinais do EventBus.
##
## Loop: N turnos. No turno N tens N+1 de mana (mais os terrenos jogados). A mão repõe-se até
## HAND_SIZE. Jogas criaturas (ficam no tabuleiro, máx. MAX_CREATURES), feitiços (contam no
## ataque deste turno) e terrenos (opcionais: +1 mana permanente; na mão dão bónus).
## Canalizar: botão + toque numa carta descarta-a e compra outra (DISCARDS por batalha).
## Ao terminar o turno TODAS as criaturas atacam através de uma CASCATA (Poder × Mult):
## criaturas → feitiços → formações → cartas na mão → relíquias → planeswalker.
## O inimigo responde com dano fixo: bloqueia a criatura mais robusta que SOBREVIVA ao golpe;
## se nenhuma sobreviver, o jogador leva o dano — a não ser que seja letal, e aí as criaturas
## sacrificam-se da mais fraca para a mais forte. Ganhas se a vida do inimigo chegar a 0.
## A vida do jogador atravessa a run (cura-se na loja). Bosses trazem uma "rule":
##   discards_minus N · hand_size N · creature_cost_plus N · no_formations · relics_off · color_silenced <cor>
##
## 0.8.0: Mulligan de Londres (turno 1, antes de qualquer jogada), cartas de dupla face (missão →
## transformação), selos de guilda (Fúria/Sabedoria/Phyrexiano/Vitalidade/Dízimo), Recapitular
## (feitiços do cemitério → exílio), planeswalker (lealdade e 3 habilidades), Selos Planares
## (mão 5, 2 canalizações, 2.ª regra do boss) e quebra-cabeças (1 turno, mão fixa).
## 0.9.0: Clima Planar da batalha (`climate`), bosses em 2 fases (abaixo de metade: +ataque e fala;
## com o Selo 8 também a 2.ª regra), regras novas de boss — attack_per_graveyard N · gold_tax N ·
## max_creatures N · spell_cost_plus N · creature_cost_minus N · exile_rightmost — e os contadores
## que os contratos usam (vida perdida, maior golpe, formações, atacantes, recapitulações, terrenos).
## 0.10.0: Fichas (create_tokens), encantamentos (zona própria, máx. 2), Reforço (play(card, true)),
## janela de Reação antes do contra-ataque (EventBus.reaction_window → reaction_done), lacaios e escudo
## do inimigo, regras das Míticas (has_rule) e regras da run vindas dos Desafios e da História
## (GameState.battle_rules: cost_max · start_tokens · first_spell_free · spell_mult · enemy_attack_plus).
## 0.13.0: consumíveis (use_consumable: poções e pergaminhos), afixos das Elites (regra thorns), bosses
## novos — reverse_cascade · steal_relic · "phases" (Hidra Tricéfala) · hand_shrink N · no_keywords ·
## half_formations — maldições do Infinito (somam-se às regras) e os climas novos (Terra Fértil, Maré
## Alta, Céu de Cometas, Inverno Eterno).

const MAX_CREATURES := 5
const HAND_SIZE := 6
const DISCARDS := 3
const MAX_MANA := 10
const MIN_HAND_AFTER_MULLIGAN := 3
const INFECTED_USES := 3
const PHYREXIAN_DECAY := 10
const PHASE2_ATTACK := 2
const METEOR_DAMAGE := 2
const MAX_ENCHANTMENTS := 2
const MINION_HITS := 2                      # golpes que cada lacaio aguenta (por omissão)
const LICH_HEAL := 2                        # Lich da Eternidade: cura por cada criatura que morre
const BLOCK_AUTO := -1                      # 0.13.0: o jogo escolhe quem bloqueia (a mais robusta que sobreviva)
const BLOCK_NONE := -2                      # 0.13.0: ninguém bloqueia — levas tu (se não for letal)
const PERFECT_GOLD := 3                     # 0.13.0: ouro da jogada perfeita (vencer com toda a mana gasta)
const KEEP_MANA_MAX := 2                    # 0.13.0: mana guardada para o turno seguinte, no máximo
const DEATH_GROWTH := 20                    # 0.13.0 Senhor da Carnificina: Poder permanente por cada morte
const COMET_PCT := 3                        # 0.13.0 Céu de Cometas: % da vida máxima do inimigo por turno
const HIGH_TIDE_HAND := 1                   # 0.13.0 Maré Alta: +1 carta na mão…
const HIGH_TIDE_ATTACK := 1                 # …e +1 no ataque do inimigo

var deck: Deck
var board: Array[CardInstance] = []        # criaturas, pela ordem em que foram jogadas
var spells_this_turn: Array[CardInstance] = []
var turn: int = 0
var max_turns: int = 5
var extra_turns: int = 0
var extra_turn_granted: bool = false
var land_played_this_turn: bool = false
var ramp: int = 0                           # terrenos jogados (+1 mana permanente cada)
var mana_total: int = 0
var mana_available: int = 0
var discards_left: int = DISCARDS
var discards_used: int = 0
var discarded_this_turn: int = 0
var drawn_this_turn: int = 0
var silenced: bool = false                  # habilidades do inimigo não disparam este turno
var enemy_vuln: float = 1.0                 # multiplicador de dano ao inimigo (maldições)
var resolving: bool = false                 # true enquanto a cascata/fase inimiga está a correr
var finished: bool = false

# 0.8.0
var mulligans: int = 0
var pending_bottom: int = 0                 # cartas que ainda tens de pôr no fundo depois do mulligan
var actions_this_turn: int = 0              # jogadas/canalizações/habilidades (o mulligan só antes de tudo)
var pw_used_this_turn: bool = false
var pw_mult_add: float = 0.0                # bónus do planeswalker para o ataque deste turno
var pw_mult_mul: float = 1.0
var pw_mult_per_attacker: float = 0.0
var pw_mult_per_token: float = 0.0          # Selene: +Mult por Ficha atacante neste turno
var pw_shield: bool = false                 # o inimigo não contra-ataca este turno
var cheap_hand: bool = false                # todas as cartas na mão custam 1 este turno
var puzzle: bool = false                    # quebra-cabeças: 1 turno, sem gravação
var ascended: bool = false                  # 2.ª regra do boss já ativada (Selo Planar 8)

# 0.9.0
var climate: String = ""                    # Clima Planar desta batalha ("" = nenhum)
var phase2: bool = false                    # boss abaixo de metade da vida (desperto)
var life_lost: int = 0                      # vida perdida nesta batalha (missões, contratos)
var best_hit: int = 0                       # maior ataque desta batalha
var best_hit_pct: float = 0.0               # … em % da vida máxima do inimigo
var elite_relic: String = ""                # relíquia ganha ao vencer uma Elite ("" = nenhuma / 10 ouro)
var elite_item: String = ""                 # 0.13.0: consumível ganho ao vencer uma Elite ("" = nenhum)
var max_formations: int = 0                 # mais formações ativas num só ataque
var max_attackers: int = 0                  # mais criaturas num só ataque
var flashbacks_used: int = 0
var lands_played: int = 0
var _channel_draw: bool = false             # a compra da canalização não paga a taxa do Falsário

# 0.10.0
var enchantments: Array[CardInstance] = []  # encantamentos em jogo (ficam até ao fim da batalha)
var minions: Array[int] = []                # lacaios do inimigo: golpes que cada um ainda aguenta
var landfalls: int = 0                      # 0.12.0: Chegadas de Terreno que dispararam nesta batalha
var mana_drain: int = 0                     # 0.12.0 Sanguessuga de Mana: mana a menos no turno seguinte
var jailed_uid: int = -1                    # 0.12.0 Carcereiro: criatura presa no ataque seguinte
var creatures_entered: int = 0              # 0.12.0: criaturas que entraram na Arena nesta batalha (talento Asas Antigas)
var counter_prevented: bool = false         # Reação: o contra-ataque deste turno foi anulado
var counter_reduce: int = 0                 # Reação: dano a menos no contra-ataque deste turno
var protect_creatures: bool = false         # Reação: o inimigo não fere nem destrói criaturas neste turno
var mirror_uid: int = -1                    # 0.11.0 Espelho Vivo: criatura copiada; no ataque seguinte não dá Poder base
var reaction_used: bool = false             # uma Reação por turno
var tokens_created: int = 0
var shield_absorbed: int = 0                # dano travado pelo escudo do inimigo nesta batalha
var chosen_blocker: int = BLOCK_AUTO        # 0.13.0: quem bloqueia o contra-ataque (uid; BLOCK_AUTO ou BLOCK_NONE)
var charge_mult: float = 1.0                # 0.13.0 golpe carregado: o contra-ataque deste turno vale ×N (avisado antes)
var perfect_play: bool = false              # 0.13.0 jogada perfeita: venceu com toda a mana gasta no turno do golpe
var mana_saved: int = 0                     # 0.13.0: mana guardada no fim do turno (talento Reserva, Cântaro de Mana)
var last_mana_saved: int = 0                # … a que entrou neste turno (para a UI)
var creatures_died: int = 0                 # 0.13.0: criaturas tuas que morreram nesta batalha
var ward: bool = false                      # 0.13.0 Pergaminho de Proteção: o próximo contra-ataque não acontece
var item_mult: float = 1.0                  # 0.13.0 Elixir da Fúria: ×Mult no próximo ataque
var item_echo: bool = false                 # 0.13.0 Pergaminho do Eco: a 1.ª a disparar dispara 2 vezes no próximo ataque
var phase_index: int = 0                    # 0.13.0: fases do boss já despertas (bosses com "phases")
var items_used: int = 0                     # 0.13.0: consumíveis usados nesta batalha

var enemy: Dictionary = {}   # {name, hp, max_hp, attack, text, abilities, boss, rule}
var rule: Dictionary = {}    # regra do boss (vazio nos inimigos normais)
var hand_size: int = HAND_SIZE
var effects: EffectResolver
var enemy_abilities: EnemyAbilities

func start(enemy_def: Dictionary) -> void:
	enemy = enemy_def.duplicate(true)
	rule = (enemy.get("rule", {}) as Dictionary).duplicate()
	var run_rules := GameState.battle_rules()
	for k in run_rules:
		if not rule.has(k):
			rule[k] = run_rules[k]
	_add_endless_rules()
	climate = GameState.current_climate_id()   # antes da mão: a Maré Alta dá +1 carta
	hand_size = _hand_size_for_rule()
	max_turns = GameState.turns_for_ante(GameState.ante)
	deck = Deck.new(GameState.deck, GameState.rng)
	board.clear()
	spells_this_turn.clear()
	effects = EffectResolver.new(self)
	enemy_abilities = EnemyAbilities.new(self)
	turn = 0
	ramp = 0
	extra_turns = 0
	extra_turn_granted = false
	discards_left = max(1, GameState.discards_for_battle() - int(rule.get("discards_minus", 0)))
	discards_used = 0
	enemy_vuln = 1.0
	resolving = false
	finished = false
	mulligans = 0
	pending_bottom = 0
	ascended = false
	puzzle = false
	climate = GameState.current_climate_id()
	phase2 = false
	life_lost = 0
	best_hit = 0
	elite_relic = ""
	elite_item = ""
	best_hit_pct = 0.0
	max_formations = 0
	max_attackers = 0
	flashbacks_used = 0
	lands_played = 0
	enchantments.clear()
	minions.clear()
	for i in int(enemy.get("minions", 0)):
		minions.append(int(enemy.get("minion_hits", MINION_HITS)))
	# 0.12.0 (Desafios): lacaios e escudo extra nos inimigos.
	for i in int(rule.get("minions_plus", 0)):
		minions.append(MINION_HITS)
	if float(rule.get("enemy_shield_plus", 0.0)) > 0.0:
		enemy["shield_pct"] = float(enemy.get("shield_pct", 0.0)) + float(rule["enemy_shield_plus"])
	landfalls = 0
	mana_drain = 0
	jailed_uid = -1
	creatures_entered = 0
	tokens_created = 0
	shield_absorbed = 0
	chosen_blocker = BLOCK_AUTO
	charge_mult = 1.0
	perfect_play = false
	mana_saved = 0
	last_mana_saved = 0
	creatures_died = 0
	ward = false
	item_mult = 1.0
	item_echo = false
	phase_index = 0
	items_used = 0
	GameState.stolen_relics.clear()
	CardInstance.keywords_off = bool(rule.get("no_keywords", false))   # Avatar do Silêncio
	if climate == "eternal_winter":   # Inverno Eterno: sem canalizações
		discards_left = 0
	if GameState.player_hp <= 0:
		GameState.player_hp = 1   # nunca começar uma batalha já morto
	EventBus.battle_started.emit(enemy)
	EventBus.enemy_hp_changed.emit(enemy.hp, enemy.max_hp)
	EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)
	effects.trigger_relics("battle_start")
	if GameState.talent_value("battle_heal") > 0.0:   # talento Regeneração
		GameState.heal(int(GameState.talent_value("battle_heal")))
	if int(rule.get("start_tokens", 0)) > 0:
		create_tokens(int(rule["start_tokens"]))
	deck.draw_opening_hand(hand_size)
	next_turn()

## Quebra-cabeças: mão e tabuleiro fixos, 1 turno, 0 canalizações, mana dada. Sem baralho de run.
func start_puzzle(def: Dictionary) -> void:
	var state := {
		"enemy": {"id": "", "name": def.get("enemy_name", "Enigma"), "hp": int(def.get("hp", 1000)),
			"max_hp": int(def.get("hp", 1000)), "attack": int(def.get("attack", 0)), "text": def.get("enemy_text", ""), "abilities": [],
			"boss": false, "rule": def.get("rule", {})},
		"turn": 1, "max_turns": int(def.get("max_turns", 1)), "mana_total": int(def.get("mana", 4)), "mana_available": int(def.get("mana", 4)),
		"discards_left": 0, "player_hp": GameState.player_hp,
		"library": [], "hand": [], "graveyard": [], "board": [], "exile": [],
	}
	# 0.12.0 (lições): lacaios e escudo no inimigo, e Selos de guilda em cartas da lição.
	if int(def.get("minions", 0)) > 0:
		var m: Array = []
		for i in int(def["minions"]):
			m.append(MINION_HITS)
		state["minions"] = m
	if float(def.get("shield_pct", 0.0)) > 0.0:
		state["enemy"]["shield_pct"] = float(def["shield_pct"])
	var seals: Dictionary = def.get("seals", {}) if def.get("seals") is Dictionary else {}
	var eds: Dictionary = def.get("editions", {}) if def.get("editions") is Dictionary else {}   # 0.13.0
	for id in def.get("hand", []):
		state["hand"].append(_puzzle_card(String(id), seals, eds))
	for id in def.get("board", []):
		state["board"].append(_puzzle_card(String(id), seals, eds))
	for id in def.get("graveyard", []):
		var g := _puzzle_card(String(id), seals, eds)
		g["exiled"] = true
		state["graveyard"].append(g)
	restore(state)
	puzzle = true

static func _puzzle_card(id: String, seals: Dictionary, editions: Dictionary = {}) -> Dictionary:
	var cs := {"id": id, "entry": -1}
	if seals.has(id):
		cs["seal"] = String(seals[id])
	if editions.has(id):
		cs["edition"] = String(editions[id])
	return cs

func _hand_size_for_rule() -> int:
	var base := GameState.hand_size_for_battle()
	if climate == "high_tide":   # 0.13.0 Maré Alta
		base += HIGH_TIDE_HAND
	return min(base, int(rule.get("hand_size", base)))

## 0.13.0: as maldições do Infinito somam-se às regras do boss (custos, ataque).
func _add_endless_rules() -> void:
	if GameState.endless_curses.is_empty() or puzzle:
		return
	for k in ["enemy_attack_plus", "spell_cost_plus", "creature_cost_plus"]:
		var v := int(GameState.endless_rule_sum(k))
		if v != 0:
			rule[k] = int(rule.get(k, 0)) + v

func next_turn() -> void:
	turn += 1
	land_played_this_turn = false
	silenced = false
	discarded_this_turn = 0
	drawn_this_turn = 0
	actions_this_turn = 0
	pw_used_this_turn = false
	pw_mult_add = 0.0
	pw_mult_mul = 1.0
	pw_mult_per_attacker = 0.0
	pw_mult_per_token = 0.0
	pw_shield = false
	cheap_hand = false
	counter_prevented = false
	counter_reduce = 0
	protect_creatures = false
	reaction_used = false
	chosen_blocker = BLOCK_AUTO
	spells_this_turn.clear()
	mana_total = min(mana_cap(), turn + 1 + ramp + int(GameState.relic_passive("mana_plus")) + (1 if has_rule("mana_plus") else 0))   # turno 1 = 2 de mana
	mana_available = mana_total
	if mana_drain > 0:   # Sanguessuga de Mana
		mana_available = maxi(0, mana_available - mana_drain)
		mana_drain = 0
	# 0.13.0: a mana guardada no fim do turno anterior soma-se (pode passar do total, nunca do máximo).
	last_mana_saved = mana_saved
	if mana_saved > 0:
		mana_available = mini(mana_available + mana_saved, MAX_MANA)
		mana_saved = 0
	if turn > 1:
		if int(rule.get("hand_shrink", 0)) > 0:   # 0.13.0 Senhor das Marés: a mão encolhe 1 por turno
			hand_size = maxi(int(rule["hand_shrink"]), hand_size - 1)
		var refill_to := hand_size
		if climate == "scorching_sands" and turn >= 4:
			refill_to = mini(refill_to, 5)
		deck.refill(refill_to)
	effects.trigger_relics("turn_start")
	for en in enchantments.duplicate():
		effects.run_immediate(en, "turn_start")
	for cr in board.duplicate():   # 0.13.0: criaturas com "no início de cada turno"
		if _has_trigger(cr, "turn_start"):
			effects.run_immediate(cr, "turn_start")
	_check_missions("gold")
	EventBus.mana_changed.emit(mana_available, mana_total)
	EventBus.discards_changed.emit(discards_left)
	# turn_started vem depois das relíquias de início de turno: a UI grava a batalha neste momento.
	EventBus.turn_started.emit(turn)

# --- Consultas ---

func creatures() -> Array[CardInstance]:
	return board.duplicate()

## Todas as criaturas atacam, incluindo as jogadas neste turno.
func attackers() -> Array[CardInstance]:
	return board.duplicate()

## Mana máxima (10; 5 com o Eclipse de Mana).
func mana_cap() -> int:
	return 5 if climate == "mana_eclipse" else MAX_MANA

## Lugares na Arena (5; o Titã de Cinza deixa 3).
func max_creatures() -> int:
	return mini(MAX_CREATURES, int(rule.get("max_creatures", MAX_CREATURES)))

## Ataque do inimigo agora (a Hidra de Mil Olhos soma +1 por cada N cartas no teu cemitério).
func enemy_attack() -> int:
	var dmg := int(enemy.get("attack", 0)) + int(rule.get("enemy_attack_plus", 0))
	if climate == "high_tide":   # 0.13.0 Maré Alta
		dmg += HIGH_TIDE_ATTACK
	var per := int(rule.get("attack_per_graveyard", 0))
	if per > 0 and deck != null:
		dmg += int(deck.graveyard.size() / per)
	if charge_mult > 1.0:   # 0.13.0 golpe carregado (avisado no turno anterior)
		dmg = int(round(float(dmg) * charge_mult))
	return maxi(0, dmg - counter_reduce)

## 0.13.0: mana que fica guardada para o turno seguinte (talento Reserva + Cântaro de Mana, máx. 2).
func keep_mana_amount() -> int:
	if puzzle:
		return 0
	return mini(KEEP_MANA_MAX, int(GameState.talent_value("keep_mana")) + int(GameState.relic_passive("keep_mana")))

## O contra-ataque deste turno não acontece? (escudo do planeswalker, Algemas de Marfim no turno 1)
func counter_blocked() -> bool:
	return ward or pw_shield or counter_prevented or (turn == 1 and GameState.relic_passive("no_counter_turn1") > 0)

## Lua de Sangue: noite nos turnos pares.
func is_night() -> bool:
	return turn % 2 == 0

func climate_name() -> String:
	return String(CardDB.get_climate(climate).get("name", "")) if climate != "" else ""

# --- 0.10.0: cartas em jogo, regras das Míticas, Fichas, escudo ---

## Criaturas e encantamentos em jogo (as fontes de passivas e regras).
func in_play() -> Array[CardInstance]:
	var out: Array[CardInstance] = board.duplicate()
	out.append_array(enchantments)
	return out

## Há em jogo (e não silenciada) uma carta com esta regra? (Míticas, Estandarte Tribal)
func has_rule(r: String) -> bool:
	return rule_card(r) != null

func rule_card(r: String) -> CardInstance:
	for c in board:
		if r in c.data.rules and (effects == null or not effects.silenced(c)):
			return c
	for c in enchantments:
		if r in c.data.rules and (effects == null or not effects.silenced(c)):
			return c
	return null

func rule_card_name(r: String) -> String:
	var c := rule_card(r)
	return c.data.display_name() if c != null else ""

## Ancião do Mundo: todo o crescimento de Poder a dobrar.
func growth_factor() -> int:
	return 2 if has_rule("double_growth") else 1

## Criaturas extra que cada tribo conta (Estandarte Tribal, Tambor Tribal).
func tribe_plus() -> int:
	return (1 if has_rule("tribe_plus") else 0) + int(GameState.relic_passive("tribe_plus"))

func max_enchantments() -> int:
	return MAX_ENCHANTMENTS + int(GameState.relic_passive("ench_plus"))

## Escudo do inimigo: % da vida máxima travada em cada ataque (regenera todos os turnos).
func shield_amount() -> int:
	var pct := float(enemy.get("shield_pct", 0))
	return int(round(float(enemy.get("max_hp", 0)) * pct / 100.0)) if pct > 0.0 else 0

## Cria Fichas na Arena (até encher). Devolve quantas criou.
func create_tokens(n: int, id: String = "tok_soldier") -> int:
	var made := 0
	if has_rule("token_double"):   # 0.13.0 Mítica Coração da Colmeia
		n *= 2
	for i in n:
		if board.size() >= max_creatures():
			break
		var t := CardDB.new_instance(id)
		if t == null:
			break
		t.zone = CardInstance.Zone.BOARD
		board.append(t)
		_on_enter_board(t)
		made += 1
		EventBus.creature_summoned.emit(t)
		EventBus.token_created.emit(t)
	if made > 0:
		tokens_created += made
		if not puzzle:
			Stats.on_tokens(made)
	return made

## Sacerdotisa do Sacrifício: sacrifica uma Ficha; a fonte ganha Poder nesta batalha.
func devour_token(source: CardInstance, power: int) -> bool:
	for c in board:
		if c.data.token:
			kill_creature(c)
			if source != null:
				source.power_bonus += power
				EventBus.card_grew.emit(source, power)
			return true
	return false

# --- Reforço (kicker) ---

func kicker_cost(card: CardInstance) -> int:
	if not card.data.has_kicker():
		return 0
	return maxi(0, int(card.data.kicker.get("cost", 0)) - int(GameState.relic_passive("kicker_minus")))

func can_kick(card: CardInstance) -> bool:
	return card.data.has_kicker() and can_play(card) and effects.cost_of(card) + kicker_cost(card) <= mana_available

# --- Reação (antes do contra-ataque) ---

static func has_reaction(card: CardInstance) -> bool:
	for e in card.effects():
		if String(e.get("trigger", "")) == "reaction":
			return true
	return false

func can_react(card: CardInstance) -> bool:
	return not finished and not reaction_used and card.zone == CardInstance.Zone.HAND and has_reaction(card) \
		and effects.cost_of(card) <= mana_available

## Cartas que podem reagir agora (para a janela de reação).
func reaction_options() -> Array[CardInstance]:
	var out: Array[CardInstance] = []
	for c in deck.hand:
		if can_react(c):
			out.append(c)
	return out

## Lança uma Mágica com Reação: paga a mana que sobrou e aplica os efeitos "reaction".
func play_reaction(card: CardInstance) -> bool:
	if not can_react(card):
		return false
	reaction_used = true
	mana_available -= effects.cost_of(card)
	deck.remove_from_hand(card)
	deck.to_graveyard(card)
	for e in card.effects():
		if String(e.get("trigger", "")) == "reaction":
			_apply_reaction(e)
	if not puzzle:
		Stats.on_reaction()
	_after_play(card)
	EventBus.reaction_played.emit(card)
	EventBus.mana_changed.emit(mana_available, mana_total)
	EventBus.hand_changed.emit()
	return true

func _apply_reaction(e: Dictionary) -> void:
	var v := float(e.get("value", 0))
	match String(e.get("action", "")):
		"prevent_counter":
			counter_prevented = true
		"reduce_counter":
			counter_reduce += int(v)
		"reflect_pct":
			damage_enemy(int(round(float(enemy.max_hp) * v / 100.0)))
		"protect_creatures":
			protect_creatures = true
		"heal_player":
			GameState.heal(int(v))
		"gold":
			GameState.add_gold(int(v))
		"draw":
			draw(int(v))
		"silence_enemy":
			silenced = true
		"create_token":   # 0.13.0 (Muralha de Escudos): Fichas antes do contra-ataque (podem bloquear)
			create_tokens(int(v), String(e.get("token", "tok_soldier")))

## Pré-visualização do ataque atual (puro, não altera nada).
func preview_attack() -> Cascade:
	return effects.build_attack_cascade()

func turns_left() -> int:
	return max_turns + extra_turns - turn

## Quanto subiria o total do ataque se jogasses esta carta agora (ignora efeitos imediatos
## como compras de cartas — é uma aproximação, mas é a que o jogador precisa de ver).
func preview_play(card: CardInstance, kicked: bool = false) -> int:
	if not can_play(card):
		return 0
	var base := effects.build_attack_cascade().total()
	var c := preview_cascade_with(card, kicked)
	if c == null:
		return 0
	return c.total() - base

## 0.13.0: o ataque como ficaria se jogasses esta carta agora (puro; null se não se pode jogar). É o que
## o cálculo mostra enquanto arrastas uma carta para a Arena.
func preview_cascade_with(card: CardInstance, kicked: bool = false) -> Cascade:
	if not can_play(card):
		return null
	var idx := deck.hand.find(card)
	if idx < 0:
		return null
	var old_zone := card.zone
	var old_kicked := card.kicked
	card.kicked = kicked and can_kick(card)
	deck.hand.remove_at(idx)
	if card.data.is_creature():
		card.zone = CardInstance.Zone.BOARD
		board.append(card)
	elif card.data.is_spell():
		card.zone = CardInstance.Zone.GRAVEYARD
		spells_this_turn.append(card)
	elif card.data.is_enchantment():
		card.zone = CardInstance.Zone.ENCHANT
		enchantments.append(card)
	var cascade := effects.build_attack_cascade()
	if card.data.is_creature():
		board.erase(card)
	elif card.data.is_spell():
		spells_this_turn.erase(card)
	elif card.data.is_enchantment():
		enchantments.erase(card)
	card.zone = old_zone
	card.kicked = old_kicked
	deck.hand.insert(idx, card)
	return cascade

## 0.13.0: porque é que esta carta não se pode jogar agora ("" = pode). Para o aviso no topo do ecrã.
func play_block_reason(card: CardInstance) -> String:
	if can_play(card):
		return ""
	if resolving or finished:
		return "Espera pelo fim do ataque."
	if pending_bottom > 0:
		return "Primeiro escolhe as cartas para o fundo do grimório."
	if card.data.is_curse():
		return "As Maldições não se jogam: só ocupam a mão."
	if card.data.is_land():
		return "Só podes jogar um Terreno por turno."
	if card.data.is_creature() and board.size() >= max_creatures():
		return "A Arena está cheia."
	if card.data.is_enchantment() and enchantments.size() >= max_enchantments():
		return "Já tens o máximo de encantamentos em jogo."
	if rule.has("cost_max") and card.data.cost > int(rule["cost_max"]):
		return "Este desafio não deixa jogar cartas tão caras."
	return "Falta mana."

## Pré-visualização do contra-ataque (puro): quem bloqueia, se sobrevive, quanto levas tu.
func preview_enemy_phase() -> Dictionary:
	return counter_plan()

## 0.13.0: escolher quem bloqueia o contra-ataque deste turno: o uid de uma criatura na Arena, BLOCK_AUTO
## (o jogo escolhe) ou BLOCK_NONE (levas tu, se não for letal). Volta a automático em cada turno.
func set_blocker(uid: int) -> bool:
	if resolving or finished:
		return false
	if uid >= 0 and _index_of_uid(uid) < 0:
		return false
	if uid < 0 and uid != BLOCK_AUTO and uid != BLOCK_NONE:
		return false
	chosen_blocker = uid
	return true

## Plano do contra-ataque (puro), usado pela pré-visualização e pelo próprio contra-ataque:
## {"damage", "blocker" (CardInstance ou null), "blocker_damage", "survives", "vigilant", "chosen",
##  "player_damage", "deaths": [CardInstance], "sacrifices": [[CardInstance, dano]]}.
## Automático: Raízes Protetoras → Vigilância → a mais robusta que sobreviva → levas tu → se for letal,
## as criaturas sacrificam-se da mais fraca para a mais forte. Com uma criatura escolhida (0.13.0), é ela
## que trava o golpe: aguenta tanto quanto a vida que lhe resta e o resto passa para ti (ou para as outras,
## se for letal). Com "ninguém", levas tu — a não ser que fosse letal (aí volta ao automático).
func counter_plan() -> Dictionary:
	var dmg: int = enemy_attack()
	var out := {"damage": dmg, "blocker": null, "blocker_damage": 0, "survives": false, "vigilant": false,
		"chosen": chosen_blocker, "player_damage": 0, "deaths": [], "sacrifices": []}
	if dmg <= 0 or counter_blocked():
		out["damage"] = 0
		return out
	var blockers := creatures()
	blockers.sort_custom(func(a, b): return a.remaining() > b.remaining())
	var chosen: CardInstance = null
	if chosen_blocker >= 0:
		var ci := _index_of_uid(chosen_blocker)
		if ci >= 0:
			chosen = board[ci]
	if protect_creatures and not blockers.is_empty():
		out["blocker"] = chosen if chosen != null else blockers[0]   # Raízes Protetoras: trava sem sofrer dano
		out["survives"] = true
		return out
	if chosen != null:
		out["blocker"] = chosen
		if chosen.has_keyword("vigilance") and not effects.silenced(chosen):
			out["survives"] = true
			out["vigilant"] = true
			return out
		var absorbed := mini(dmg, chosen.remaining())
		out["blocker_damage"] = absorbed
		out["survives"] = chosen.remaining() > dmg
		if not bool(out["survives"]):
			(out["deaths"] as Array).append(chosen)
		if dmg - absorbed > 0:
			_plan_rest(out, dmg - absorbed, blockers.filter(func(x): return x != chosen))
		return out
	if chosen_blocker == BLOCK_NONE and GameState.player_hp > dmg:
		out["player_damage"] = dmg
		return out
	for b in blockers:
		if b.has_keyword("vigilance") and not effects.silenced(b):
			out["blocker"] = b
			out["survives"] = true
			out["vigilant"] = true
			return out
	for b in blockers:
		if b.remaining() > dmg:
			out["blocker"] = b
			out["survives"] = true
			out["blocker_damage"] = dmg
			return out
	_plan_rest(out, dmg, blockers)
	return out

## O que sobra do golpe: levas tu se não te matar; se matar, as criaturas sacrificam-se, da mais fraca
## para a mais forte, e só o que sobrar delas te acerta.
func _plan_rest(out: Dictionary, left: int, others: Array) -> void:
	if GameState.player_hp > left:
		out["player_damage"] = int(out["player_damage"]) + left
		return
	var order := others.duplicate()
	order.sort_custom(func(a, b): return a.remaining() < b.remaining())
	for b in order:
		if left <= 0:
			break
		var absorbed: int = mini(left, b.remaining())
		left -= absorbed
		(out["sacrifices"] as Array).append([b, absorbed])
		if absorbed >= b.remaining():
			(out["deaths"] as Array).append(b)
	out["player_damage"] = int(out["player_damage"]) + maxi(0, left)

## 0.13.0: o que o inimigo vai fazer às tuas criaturas no fim deste turno, pela ordem real (contra-ataque →
## habilidades → regra do boss → clima). Para as setas e etiquetas da Arena. Cada entrada:
## {"card": CardInstance, "kind": block|die|jail|mirror|destroy|burn|burn_die|exile|meteor|meteor_die, "value": int}.
## É uma previsão com a Arena de agora (o ataque ainda pode fazer crescer criaturas).
func threat_preview() -> Array:
	var out: Array = []
	if finished or board.is_empty():
		return out
	var plan := counter_plan()
	var hurt := {}   # uid → dano que já levou no contra-ataque
	var gone: Array = (plan["deaths"] as Array).duplicate()
	var blocker: CardInstance = plan["blocker"]
	if blocker != null:
		hurt[blocker.uid] = int(plan["blocker_damage"])
		out.append({"card": blocker, "kind": "block" if bool(plan["survives"]) else "die", "value": int(plan["blocker_damage"])})
	for s in plan["sacrifices"]:
		var sc: CardInstance = s[0]
		hurt[sc.uid] = int(s[1])
		out.append({"card": sc, "kind": "die" if sc in gone else "block", "value": int(s[1])})
	var alive: Array = board.filter(func(x): return not (x in gone))
	if not silenced:
		for a in enemy_intent(turn):
			var action := String(a.get("action", ""))
			if protect_creatures and action in ["destroy_strongest", "damage_all_creatures", "mirror_best", "jail_strongest", "shuffle_board"]:
				continue
			match action:
				"jail_strongest", "mirror_best", "destroy_strongest":
					var t := _strongest_unprotected(alive)
					if t != null:
						out.append({"card": t, "kind": {"jail_strongest": "jail", "mirror_best": "mirror", "destroy_strongest": "destroy"}[action], "value": 0})
						if action == "destroy_strongest":
							alive.erase(t)
				"damage_all_creatures":
					var v := int(a.get("value", 0))
					for c in alive.duplicate():
						if is_protected(c):
							continue
						var dies: bool = c.remaining() - int(hurt.get(c.uid, 0)) <= v
						hurt[c.uid] = int(hurt.get(c.uid, 0)) + v
						out.append({"card": c, "kind": "burn_die" if dies else "burn", "value": v})
						if dies:
							alive.erase(c)
		if bool(rule.get("exile_rightmost", false)):
			var targets := alive.filter(func(x): return not is_protected(x))
			if not targets.is_empty():
				out.append({"card": targets[targets.size() - 1], "kind": "exile", "value": 0})
				alive.erase(targets[targets.size() - 1])
	if climate == "meteor_rain" and not protect_creatures and alive.size() >= 3:
		var m: CardInstance = alive[2]
		var dies_m: bool = m.remaining() - int(hurt.get(m.uid, 0)) <= METEOR_DAMAGE
		out.append({"card": m, "kind": "meteor_die" if dies_m else "meteor", "value": METEOR_DAMAGE})
	return out

## A criatura com mais Poder sem Proteção (o alvo do Carcereiro, do Espelho Vivo e de "destruir a mais forte").
func _strongest_unprotected(pool: Array) -> CardInstance:
	var best: CardInstance = null
	for c in pool:
		if is_protected(c):
			continue
		if best == null or c.power() > best.power():
			best = c
	return best

## 0.13.0: ordem em que as criaturas disparam na cascata (Primeiro Golpe primeiro, depois pela ordem da
## Arena) — os números 1, 2, 3… nas cartas. Igual ao EffectResolver._strike_order.
func strike_order() -> Array:
	var first: Array = []
	var rest: Array = []
	for a in board:
		if a.has_keyword("first_strike") and not effects.silenced(a):
			first.append(a)
		else:
			rest.append(a)
	first.append_array(rest)
	return first

## Habilidades do inimigo que vão disparar no fim deste turno (para mostrar a intenção).
func enemy_intent(for_turn: int) -> Array:
	var out: Array = []
	for a in enemy.get("abilities", []):
		var trig: String = a.get("trigger", "turn_end")
		if trig == "turn_end" or (trig == "every_n_turns" and for_turn % int(a.get("n", 1)) == 0):
			out.append(a)
	return out

## 0.12.0 "Melhor ordem": a ordem das criaturas na Arena que dá o maior ataque. Até 6 criaturas
## experimenta todas as ordens; com mais, troca pares enquanto houver ganho. Não mexe no tabuleiro.
## Devolve {"order": Array (CardInstance), "total": melhor ataque, "current": ataque com a ordem atual}.
func best_board_order() -> Dictionary:
	var original: Array = board.duplicate()
	var current := effects.build_attack_cascade().net_total()
	var best_total := current
	var best_order: Array = original.duplicate()
	var n := original.size()
	if n >= 2 and not resolving and not finished:
		if n <= 6:
			for perm in _permutations(original):
				_set_board(perm)
				var t := effects.build_attack_cascade().net_total()
				if t > best_total:
					best_total = t
					best_order = perm.duplicate()
		else:
			var cur: Array = original.duplicate()
			var improved := true
			while improved:
				improved = false
				for i in n:
					for j in range(i + 1, n):
						var cand: Array = cur.duplicate()
						var tmp = cand[i]
						cand[i] = cand[j]
						cand[j] = tmp
						_set_board(cand)
						var t2 := effects.build_attack_cascade().net_total()
						if t2 > best_total:
							best_total = t2
							cur = cand
							best_order = cand.duplicate()
							improved = true
		_set_board(original)
	return {"order": best_order, "total": best_total, "current": current}

## Põe a Arena numa ordem (a de best_board_order).
func apply_board_order(order: Array) -> bool:
	if resolving or finished or order.size() != board.size():
		return false
	for c in order:
		if not (c in board):
			return false
	_set_board(order)
	return true

func _set_board(order: Array) -> void:
	board.clear()
	for c in order:
		board.append(c)

static func _permutations(arr: Array) -> Array:
	if arr.size() <= 1:
		return [arr.duplicate()]
	var out: Array = []
	for i in arr.size():
		var rest: Array = arr.duplicate()
		var x = rest.pop_at(i)
		for p in _permutations(rest):
			var q: Array = [x]
			q.append_array(p)
			out.append(q)
	return out

## 0.12.0 Dica de jogada (Fácil): letal → atacar; um Terreno que deixa jogar outra carta → o Terreno;
## a carta que mais sobe o ataque (ou mudar a ordem da Arena, se der mais); um Terreno; senão atacar.
## Devolve {"kind": "attack"|"land"|"card"|"order", "card": CardInstance ou null, "gain": int}.
func play_hint() -> Dictionary:
	if resolving or finished or pending_bottom > 0:
		return {}
	var now := effects.build_attack_cascade().net_total()
	if now > 0 and now >= int(enemy.get("hp", 0)):
		return {"kind": "attack", "card": null, "gain": 0, "lethal": true}
	var land: CardInstance = null
	for c in deck.hand:
		if c.data.is_land() and can_play(c):
			land = c
			break
	if land != null:
		for c in deck.hand:
			if c.data.is_land() or c.data.is_curse():
				continue
			var cost := effects.cost_of(c)
			if cost > mana_available and cost <= mana_available + 1:
				return {"kind": "land", "card": land, "gain": 0}
	var best: CardInstance = null
	var best_gain := 0
	for c in deck.hand:
		if c.data.is_land() or not can_play(c):
			continue
		var g := preview_play(c)
		if g > best_gain:
			best_gain = g
			best = c
	var order := best_board_order()
	var order_gain := int(order["total"]) - int(order["current"])
	if order_gain > best_gain:
		return {"kind": "order", "card": null, "gain": order_gain}
	if best != null:
		return {"kind": "card", "card": best, "gain": best_gain}
	if land != null:
		return {"kind": "land", "card": land, "gain": 0}
	return {"kind": "attack", "card": null, "gain": 0}

## Uma criatura entrou na Arena (jogada ou Ficha): regras do Desafio que dão palavras-chave e os
## talentos Pele Dura (+resistência) e Asas Antigas (a 1.ª criatura jogada na batalha ganha Voar).
func _on_enter_board(card: CardInstance) -> void:
	var kw := String(rule.get("creatures_keyword", ""))
	if kw != "":
		card.grant_keyword(kw)
	if puzzle:
		return
	card.toughness_bonus += int(GameState.talent_value("toughness"))
	if creatures_entered == 0 and GameState.talent_value("first_flying") > 0.0:
		card.grant_keyword("flying")
	creatures_entered += 1

static func _has_trigger(c: CardInstance, trig: String) -> bool:
	for e in c.effects():
		if String(e.get("trigger", "")) == trig:
			return true
	return false

## Reordenar criaturas (arrastar no tabuleiro): a ordem importa na cascata.
func move_creature(card: CardInstance, index: int) -> void:
	if resolving or finished or not (card in board):
		return
	board.erase(card)
	board.insert(clampi(index, 0, board.size()), card)

# --- Mulligan de Londres ---

## Só no 1.º turno, antes de qualquer jogada; cada mulligan mete mais uma carta no fundo.
func can_mulligan() -> bool:
	if resolving or finished or puzzle or turn != 1 or actions_this_turn > 0 or pending_bottom > 0:
		return false
	return hand_size - (mulligans + 1) >= MIN_HAND_AFTER_MULLIGAN

func mulligan() -> bool:
	if not can_mulligan():
		return false
	deck.shuffle_hand_in()
	deck.draw(hand_size)
	mulligans += 1
	pending_bottom = mulligans
	Stats.on_mulligan()
	EventBus.mulligan_taken.emit(pending_bottom)
	EventBus.hand_changed.emit()
	return true

## Depois do mulligan: escolhe as cartas a pôr no fundo do grimório (uma por chamada).
func bottom_card(card: CardInstance) -> bool:
	if pending_bottom <= 0 or card.zone != CardInstance.Zone.HAND:
		return false
	deck.remove_from_hand(card)
	deck.to_library_bottom(card)
	pending_bottom -= 1
	EventBus.hand_changed.emit()
	return true

# --- Ações do jogador ---

func can_play(card: CardInstance) -> bool:
	if resolving or finished or pending_bottom > 0:
		return false
	if card.zone != CardInstance.Zone.HAND or card.data.is_curse():
		return false
	if card.data.is_land():
		return not land_played_this_turn
	if card.data.is_creature() and board.size() >= max_creatures():
		return false
	if card.data.is_enchantment() and enchantments.size() >= max_enchantments():
		return false
	if rule.has("cost_max") and card.data.cost > int(rule["cost_max"]):
		return false   # Desafio "Só Miúdos"
	return effects.cost_of(card) <= mana_available

func play(card: CardInstance, kicked: bool = false) -> bool:
	if not can_play(card):
		return false
	var kick := kicked and can_kick(card)
	actions_this_turn += 1
	deck.remove_from_hand(card)
	if card.data.is_land():
		land_played_this_turn = true
		lands_played += 1
		ramp += 1
		if mana_total < mana_cap():
			mana_total += 1
			mana_available += 1
		if climate == "fertile_land":   # 0.13.0 Terra Fértil: +1 mana a mais neste turno
			mana_available = mini(mana_available + 1, MAX_MANA)
		deck.to_graveyard(card)   # o terreno "entra" no mundo; deixa de dar o bónus de mão
		EventBus.land_played.emit(card)
		effects.trigger_relics("land_played", card)
		effects.run_immediate(card, "on_play")   # 0.12.0: Terrenos especiais ("Ao jogar: …")
		if int(rule.get("land_buff", 0)) > 0:   # Desafio "Terramoto": cada Terreno dá Poder às criaturas
			for x in board:
				x.power_bonus += int(rule["land_buff"])
		# 0.12.0 Chegada de Terreno: criaturas na Arena e encantamentos com o gatilho "landfall".
		var fired := false
		for x in board.duplicate():
			if _has_trigger(x, "landfall"):
				effects.run_immediate(x, "landfall")
				fired = true
		for x in enchantments.duplicate():
			if _has_trigger(x, "landfall"):
				effects.run_immediate(x, "landfall")
				fired = true
		if fired:
			landfalls += 1
			if not puzzle:
				Stats.add("landfalls")
			EventBus.landfall.emit(card)
	else:
		mana_available -= effects.cost_of(card)
		if kick:
			mana_available -= kicker_cost(card)
			card.kicked = true
			if not puzzle:
				Stats.on_kick()
			EventBus.card_kicked.emit(card)
		if card.data.is_creature():
			card.zone = CardInstance.Zone.BOARD
			board.append(card)
			_on_enter_board(card)
			EventBus.creature_summoned.emit(card)
			effects.run_immediate(card, "on_play")
			if not card.data.token and has_rule("token_engine"):
				create_tokens(1)
		elif card.data.is_enchantment():
			card.zone = CardInstance.Zone.ENCHANT
			enchantments.append(card)
			effects.run_immediate(card, "on_play")
			if not puzzle:
				Stats.on_enchantment()
			EventBus.enchantment_played.emit(card)
		else:
			card.zone = CardInstance.Zone.GRAVEYARD
			spells_this_turn.append(card)
			effects.run_immediate(card, "on_cast")
			if card.data.return_to_library:
				deck.to_library_bottom(card)
			else:
				deck.to_graveyard(card)   # volta ao grimório quando este se esgota (reciclagem)
			EventBus.spell_cast.emit(card)
	_after_play(card)
	EventBus.card_played.emit(card)
	EventBus.mana_changed.emit(mana_available, mana_total)
	if enemy.hp <= 0:
		_finish(true)
	return true

## Selos, missões, lealdade do planeswalker e infeção — comum a jogar da mão e a Recapitular.
func _after_play(card: CardInstance) -> void:
	match card.seal():
		"tithe":
			GameState.add_gold(3)
			EventBus.seal_triggered.emit(card, "tithe")
		"vitality":
			var target := effects.left_of(card)
			if target != null:
				var g := 15 * growth_factor()
				target.grow(g)
				EventBus.card_grew.emit(target, g)
				EventBus.seal_triggered.emit(card, "vitality")
	if card.data.is_creature():
		_check_missions("creatures", card)
		_check_missions("board_full", card)
	elif card.data.is_spell():
		_check_missions("spells", card)
		_check_missions("spells_turn", card)
	if GameState.planeswalker_color() != "" and card.data.has_color(GameState.planeswalker_color()):
		GameState.change_loyalty(1)
	if card.data.infected and not card.deck_entry.is_empty():
		card.deck_entry["uses"] = int(card.deck_entry.get("uses", 0)) + 1
		if int(card.deck_entry["uses"]) >= INFECTED_USES:
			_exile_from_run(card)

func can_discard(card: CardInstance) -> bool:
	return not resolving and not finished and pending_bottom <= 0 and discards_left > 0 and card.zone == CardInstance.Zone.HAND

## Canalizar: descarta a carta e compra outra.
func discard(card: CardInstance) -> bool:
	if not can_discard(card):
		return false
	actions_this_turn += 1
	discards_left -= 1
	discards_used += 1
	discarded_this_turn += 1
	deck.remove_from_hand(card)
	deck.to_graveyard(card)
	effects.run_immediate(card, "on_discard")
	EventBus.card_discarded.emit(card)
	GameState.bump_relic_counters("channel")
	_check_missions("channel", card)
	_channel_draw = true
	draw(1)
	_channel_draw = false
	_gold_tax(1)
	if not silenced:
		enemy_abilities.on_channel()   # 0.12.0 Inquisidor do Silêncio
	EventBus.discards_changed.emit(discards_left)
	EventBus.hand_changed.emit()
	return true

func discard_random(count: int) -> void:
	for i in count:
		if deck.hand.is_empty():
			break
		var idx := GameState.rng.randi_range(0, deck.hand.size() - 1)
		var card: CardInstance = deck.hand[idx]
		deck.remove_from_hand(card)
		deck.to_graveyard(card)
		EventBus.card_discarded.emit(card)
	EventBus.hand_changed.emit()

func draw(count: int) -> void:
	var drawn := deck.draw(count)
	drawn_this_turn += drawn.size()
	if not _channel_draw:
		_gold_tax(drawn.size())

## Falsário de Moedas: −1 ouro por canalização e por carta comprada por efeitos.
func _gold_tax(times: int) -> void:
	var tax := int(rule.get("gold_tax", 0))
	if tax <= 0 or times <= 0 or GameState.gold <= 0:
		return
	GameState.add_gold(-tax * times)
	EventBus.enemy_ability_used.emit(String(enemy.get("name", "")), "gold_tax")

func grant_extra_turn() -> void:
	if extra_turn_granted:
		return
	extra_turn_granted = true
	extra_turns += 1
	EventBus.turn_started.emit(turn)   # para a UI atualizar "Turno x/y"

# --- Recapitular (flashback) ---

func flashback_cards() -> Array[CardInstance]:
	return deck.flashback_cards()

func can_flashback(card: CardInstance) -> bool:
	if resolving or finished or pending_bottom > 0 or not card.data.flashback or not card.data.is_spell():
		return false
	if card.zone != CardInstance.Zone.GRAVEYARD or not (card in deck.graveyard):
		return false
	return effects.cost_of(card) <= mana_available

## Lança um feitiço a partir do cemitério; no fim vai para o exílio até ao fim da batalha.
func play_flashback(card: CardInstance) -> bool:
	if not can_flashback(card):
		return false
	actions_this_turn += 1
	deck.graveyard.erase(card)
	mana_available -= effects.cost_of(card)
	card.zone = CardInstance.Zone.GRAVEYARD
	spells_this_turn.append(card)
	effects.run_immediate(card, "on_cast")
	deck.to_exile(card)
	flashbacks_used += 1
	Stats.on_flashback()
	var pct := GameState.relic_passive("flashback_damage_pct")
	if pct > 0.0:
		damage_enemy(int(round(enemy.max_hp * pct / 100.0)))
	EventBus.spell_cast.emit(card)
	EventBus.card_flashback.emit(card)
	_after_play(card)
	EventBus.card_played.emit(card)
	EventBus.mana_changed.emit(mana_available, mana_total)
	EventBus.hand_changed.emit()
	if enemy.hp <= 0:
		_finish(true)
	return true

# --- Dupla face ---

## Avança as missões com este gatilho (cartas na mão e no tabuleiro, menos a própria fonte).
func _check_missions(trigger: String, source: CardInstance = null) -> void:
	if deck == null:
		return
	# Missões "de estado": o progresso é o valor atual (ouro, feitiços neste turno, Arena, vida perdida).
	var state := {"gold": GameState.gold, "spells_turn": spells_this_turn.size(), "board_full": board.size(), "life_lost": life_lost}
	var candidates: Array[CardInstance] = []
	candidates.append_array(deck.hand)
	candidates.append_array(board)
	for c in candidates:
		if not c.has_mission() or c.mission_trigger() != trigger:
			continue
		if state.has(trigger):
			c.mission_count = int(state[trigger])
		elif c == source:
			continue
		else:
			c.mission_count += 1
		if c.mission_count >= c.mission_target():
			_transform(c)

func _transform(card: CardInstance) -> void:
	if not card.transform():
		return
	Stats.on_transform()
	EventBus.card_transformed.emit(card)
	effects.run_immediate(card, "on_transform")
	EventBus.hand_changed.emit()

## Reavalia as missões de ouro (chamado quando o ouro muda a meio da batalha).
func on_gold_changed() -> void:
	if deck != null and not finished:
		_check_missions("gold")

# --- Planeswalker ---

func planeswalker_skills() -> Array:
	return GameState.planeswalker_def().get("skills", [])

func can_use_planeswalker(index: int) -> bool:
	if resolving or finished or pending_bottom > 0 or pw_used_this_turn:
		return false
	var skills := planeswalker_skills()
	if index < 0 or index >= skills.size():
		return false
	var cost := int(skills[index].get("cost", 0))
	return cost > 0 or GameState.planeswalker_loyalty() >= -cost

func use_planeswalker(index: int) -> bool:
	if not can_use_planeswalker(index):
		return false
	var skill: Dictionary = planeswalker_skills()[index]
	var cost := int(skill.get("cost", 0))
	pw_used_this_turn = true
	actions_this_turn += 1
	GameState.change_loyalty(cost)
	var v := float(skill.get("value", 0))
	var color := GameState.planeswalker_color()
	match String(skill.get("action", "")):
		"buff_hand_color":
			for h in deck.hand:
				if h.data.has_color(color):
					h.power_bonus += int(v)
		"mult_add":
			pw_mult_add += v
		"cheap_hand":
			cheap_hand = true
			for h in deck.hand:
				if not h.data.is_land():
					h.power_bonus += int(v)
		"draw":
			draw(int(v))
		"channel_draw":
			discards_left += 1
			draw(int(v))
			EventBus.discards_changed.emit(discards_left)
		"extra_turn_mult":
			extra_turn_granted = false
			grant_extra_turn()
			pw_mult_mul *= v
		"buff_strongest":
			var best: CardInstance = null
			for c in board:
				if best == null or c.power() > best.power():
					best = c
			if best != null:
				best.power_bonus += int(v)
				EventBus.card_grew.emit(best, int(v))
		"enemy_max_hp_pct":
			var cut := int(round(enemy.max_hp * v / 100.0))
			enemy.max_hp = max(1, enemy.max_hp - cut)
			enemy.hp = min(enemy.hp, enemy.max_hp)
			EventBus.enemy_hp_changed.emit(enemy.hp, enemy.max_hp)
		"mult_mul_pay_life":
			pw_mult_mul *= v
			lose_life(mini(int(skill.get("life", 0)), GameState.player_hp - 1))
		"grow_random_board":
			if not board.is_empty():
				var c: CardInstance = board[GameState.rng.randi_range(0, board.size() - 1)]
				c.grow(int(v) * growth_factor())
				EventBus.card_grew.emit(c, int(v) * growth_factor())
		"buff_board_mult":
			for c in board:
				c.power_bonus += int(v)
			pw_mult_add += float(skill.get("mult", 0))
		"mult_mul_grow":
			pw_mult_mul *= v
			for c in board:
				c.grow(int(skill.get("grow", 0)) * growth_factor())
				EventBus.card_grew.emit(c, int(skill.get("grow", 0)) * growth_factor())
		"heal":
			GameState.heal(int(v))
		"mult_per_attacker":
			pw_mult_per_attacker += v
		"mult_mul_shield":
			pw_mult_mul *= v
			pw_shield = true
		"create_token":
			create_tokens(int(v))
		"mult_per_token":
			pw_mult_per_token += v
		"token_rally":
			create_tokens(max_creatures())
			for c in board:
				if c.data.token:
					c.power_bonus += int(v)
					EventBus.card_grew.emit(c, int(v))
	if cost <= -6:
		Stats.on_pw_ultimate()
	EventBus.planeswalker_changed.emit()
	EventBus.mana_changed.emit(mana_available, mana_total)
	EventBus.hand_changed.emit()
	return true

## Corrotina: a UI chama sem await. Se houver alguém ligado a cascade_started,
## espera que a animação acabe (cascade_finished) antes de aplicar o dano.
func end_turn() -> void:
	if resolving or finished or pending_bottom > 0:
		return
	resolving = true
	var cascade := effects.build_attack_cascade()
	if not cascade.is_empty():
		if EventBus.cascade_started.get_connections().size() > 0:
			EventBus.cascade_started.emit(cascade)
			await EventBus.cascade_finished
		_apply_cascade(cascade)
		# 0.13.0 Elite Espinhosa: cada ataque custa vida (nunca a última).
		if int(rule.get("thorns", 0)) > 0 and GameState.player_hp > 1:
			lose_life(mini(int(rule["thorns"]), GameState.player_hp - 1))
	item_mult = 1.0      # 0.13.0: o Elixir da Fúria e o Pergaminho do Eco valem só para este ataque
	item_echo = false
	if enemy.hp <= 0:
		# 0.13.0 jogada perfeita: o golpe que vence com a mana toda gasta neste turno.
		perfect_play = not puzzle and mana_available <= 0 and not cascade.is_empty()
		_finish(true)
		return
	_check_phase2()
	await _pause(0.45)
	# Janela de Reação: antes do contra-ataque, uma Mágica com Reação pode travá-lo ou devolver dano.
	if not counter_blocked() and enemy_attack() > 0 and not reaction_used:
		var opts := reaction_options()
		if not opts.is_empty() and EventBus.reaction_window.get_connections().size() > 0:
			EventBus.reaction_window.emit(opts)
			var chosen = await EventBus.reaction_done
			if chosen is CardInstance:
				play_reaction(chosen)
			if enemy.hp <= 0:
				_finish(true)
				return
	if not counter_blocked() and enemy_attack() > 0:
		_enemy_phase()
		await _pause(0.35)   # 0.13.0: dá tempo de ver a investida do inimigo (e as faíscas do bloqueio)
	charge_mult = 1.0   # 0.13.0: o golpe carregado gasta-se neste contra-ataque (mesmo que travado)
	if ward and int(enemy.get("attack", 0)) > 0:
		ward = false     # 0.13.0: o Pergaminho de Proteção gasta-se no contra-ataque que travou
	if GameState.player_hp <= 0:
		_finish(false)
		return
	# 0.13.0: guarda a mana que sobrou para o turno seguinte (talento Reserva, Cântaro de Mana).
	mana_saved = mini(mana_available, keep_mana_amount()) if mana_available > 0 else 0
	if not silenced:
		enemy_abilities.on_turn_end(turn)
	_boss_end_of_turn()
	_climate_end_of_turn()
	if enemy.hp <= 0:   # 0.13.0: o Céu de Cometas também pode acabar com o inimigo
		_finish(true)
		return
	_end_of_turn_cards()
	EventBus.hand_changed.emit()
	EventBus.turn_ended.emit(turn)
	if turn >= max_turns + extra_turns:
		_finish(false)
		return
	resolving = false
	next_turn()

## Fim do turno: missões de "sobreviver"/"ficar na mão" e Selo da Sabedoria.
func _end_of_turn_cards() -> void:
	for c in board.duplicate():
		if c.has_mission() and c.mission_trigger() == "attacks":
			c.mission_count += 1
			if c.mission_count >= c.mission_target():
				_transform(c)
	for h in deck.hand.duplicate():
		h.turns_in_hand += 1
		if h.has_mission() and h.mission_trigger() == "turns_in_hand":
			h.mission_count += 1
			if h.mission_count >= h.mission_target():
				_transform(h)
		if h.seal() == "wisdom":
			var fid := GameState.level_up_random_formation()
			if fid != "":
				EventBus.seal_triggered.emit(h, "wisdom")

## Bosses em 2 fases: abaixo de metade da vida o boss desperta (+ataque e uma fala); com o
## Selo Planar 8 ativa também a 2.ª regra.
func _check_phase2() -> void:
	if not bool(enemy.get("boss", false)) or enemy.hp <= 0:
		return
	var phases: Array = enemy.get("phases", []) if enemy.get("phases") is Array else []
	if not phases.is_empty():
		_check_phases(phases)
		return
	if phase2 or enemy.hp * 2 > enemy.max_hp:
		return
	phase2 = true
	enemy["attack"] = int(enemy.get("attack", 0)) + PHASE2_ATTACK
	EventBus.boss_phase2.emit(String((enemy.get("lines", {}) as Dictionary).get("phase2", "")))
	_check_ascension()

## 0.13.0 (Hidra Tricéfala): bosses com várias fases — cada limiar de vida ("pct") desperta a seguinte, com
## mais ataque, uma regra nova e uma fala. A 1.ª conta como a fase 2 de sempre (estatísticas, Selo 8).
func _check_phases(phases: Array) -> void:
	while phase_index < phases.size():
		var ph: Dictionary = phases[phase_index]
		if float(enemy.hp) * 100.0 > float(enemy.max_hp) * float(ph.get("pct", 50)):
			return
		phase_index += 1
		phase2 = true
		enemy["attack"] = int(enemy.get("attack", 0)) + int(ph.get("attack", PHASE2_ATTACK))
		var r: Dictionary = ph.get("rule", {}) if ph.get("rule") is Dictionary else {}
		for k in r:
			rule[k] = r[k]
		if r.has("hand_size"):
			hand_size = _hand_size_for_rule()
		if r.has("discards_minus"):
			discards_left = maxi(0, discards_left - int(r["discards_minus"]))
			EventBus.discards_changed.emit(discards_left)
		enemy["phase_text"] = String(ph.get("text", ""))
		EventBus.boss_phase.emit(phase_index, String(ph.get("text", "")))
		EventBus.boss_phase2.emit(String(ph.get("line", "")))
		_check_ascension()

## 0.13.0 Ladra de Relíquias: desliga a tua relíquia (normal) mais à esquerda até ao fim da batalha.
func steal_relic() -> String:
	for id in GameState.relic_ids:
		if not (id in GameState.stolen_relics):
			GameState.stolen_relics.append(id)
			EventBus.relic_stolen.emit(id)
			return id
	return ""

## 0.13.0: consumíveis. Pode usar-se este agora? (na batalha, fora do ataque e do fundo do Mulligan)
func can_use_consumable(id: String) -> bool:
	if finished or resolving or pending_bottom > 0:
		return false
	var def := CardDB.get_consumable(id)
	if def.is_empty() or String(def.get("use", "battle")) == "map":
		return false
	var eff: Dictionary = def.get("effect", {})
	if eff.has("toughness") or eff.has("power"):
		return not board.is_empty()
	if eff.has("heal"):
		return GameState.player_hp < GameState.player_max_hp
	if eff.has("ward"):
		return not ward
	if eff.has("echo"):
		return not item_echo
	return true

## Usa o consumível desta posição (GameState.consumables). Devolve false se não deu.
func use_consumable(index: int) -> bool:
	if index < 0 or index >= GameState.consumables.size():
		return false
	var id := GameState.consumables[index]
	if not can_use_consumable(id):
		return false
	var eff: Dictionary = CardDB.get_consumable(id).get("effect", {})
	GameState.remove_consumable_at(index)
	items_used += 1
	if not puzzle:
		Stats.add("consumables_used")
	if int(eff.get("heal", 0)) > 0:
		GameState.heal(int(eff["heal"]))
	if int(eff.get("mana", 0)) > 0:
		mana_available = mini(mana_available + int(eff["mana"]), MAX_MANA)
		EventBus.mana_changed.emit(mana_available, mana_total)
	if float(eff.get("attack_mult", 0.0)) > 0.0:
		item_mult *= float(eff["attack_mult"])
	if int(eff.get("toughness", 0)) > 0:
		for c in board:
			c.toughness_bonus += int(eff["toughness"])
	if int(eff.get("power", 0)) > 0:
		for c in board:
			c.power_bonus += int(eff["power"])
			EventBus.card_grew.emit(c, int(eff["power"]))
	if int(eff.get("damage_pct", 0)) > 0:
		damage_enemy(int(round(float(enemy.max_hp) * float(eff["damage_pct"]) / 100.0)))
	if int(eff.get("draw", 0)) > 0:
		draw(int(eff["draw"]))
		EventBus.hand_changed.emit()
	if int(eff.get("ward", 0)) > 0:
		ward = true
	if int(eff.get("extra_turn", 0)) > 0:
		extra_turns += int(eff["extra_turn"])
	if int(eff.get("echo", 0)) > 0:
		item_echo = true
	if int(eff.get("discards", 0)) > 0:
		discards_left += int(eff["discards"])
		EventBus.discards_changed.emit(discards_left)
	EventBus.consumable_used.emit(id)
	if enemy.hp <= 0:
		_finish(true)
	else:
		_check_phase2()
	return true

func _exit_tree() -> void:
	CardInstance.keywords_off = false   # o Avatar do Silêncio não pode silenciar o resto do jogo

## Fim do turno do boss: o Devorador de Horizontes exila a criatura mais à direita.
func _boss_end_of_turn() -> void:
	if bool(rule.get("exile_rightmost", false)) and not board.is_empty() and not silenced:
		var targets := board.filter(func(x: CardInstance): return not is_protected(x))
		if targets.is_empty():
			return
		var c: CardInstance = targets[targets.size() - 1]
		board.erase(c)
		if not c.data.token:
			deck.to_exile(c)
		EventBus.creature_exiled.emit(c)

## Fim do turno do clima: Chuva de Meteoros fere a 3.ª criatura; Lua de Sangue vira as cartas de
## dupla face no fim das noites.
func _climate_end_of_turn() -> void:
	match climate:
		"comet_sky":   # 0.13.0 Céu de Cometas: o inimigo leva 3 % da vida máxima; a 1.ª criatura leva 1
			if enemy.hp > 0:
				damage_enemy(maxi(1, int(round(float(enemy.max_hp) * COMET_PCT / 100.0))))
			if not board.is_empty() and not protect_creatures:
				var first: CardInstance = board[0]
				first.damage += 1
				EventBus.climate_hit.emit(first, 1)
				if first.is_dead():
					kill_creature(first)
		"meteor_rain":
			if board.size() >= 3 and not protect_creatures:
				var c: CardInstance = board[2]
				c.damage += METEOR_DAMAGE
				EventBus.climate_hit.emit(c, METEOR_DAMAGE)
				if c.is_dead():
					kill_creature(c)
		"blood_moon":
			if is_night():
				var flips: Array[CardInstance] = []
				for c in deck.hand + board:
					if c.has_mission():
						flips.append(c)
				for c in flips:
					_transform(c)

## Selo Planar 8: com o boss desperto, ativa a 2.ª regra.
func _check_ascension() -> void:
	if ascended or not bool(enemy.get("boss", false)) or GameState.stake < 8:
		return
	var rule2: Dictionary = enemy.get("rule2", {})
	if rule2.is_empty():
		return
	ascended = true
	for k in rule2:
		rule[k] = rule2[k]
	hand_size = _hand_size_for_rule()
	if rule2.has("discards_minus"):
		discards_left = max(0, discards_left - int(rule2["discards_minus"]))
		EventBus.discards_changed.emit(discards_left)
	EventBus.boss_ascended.emit(String(enemy.get("rule2_text", "")))

# --- Fases internas ---

func _apply_cascade(cascade: Cascade) -> void:
	for s in cascade.steps:
		if s.grow > 0 and s.source_card != null:
			s.source_card.grow(s.grow)
	if cascade.gold != 0:
		GameState.add_gold(cascade.gold)
	var total := cascade.net_total()
	if cascade.shield > 0 and cascade.total() > 0:
		var absorbed := mini(cascade.shield, cascade.total())
		shield_absorbed += absorbed
		EventBus.shield_hit.emit(absorbed)
	# Contadores para os contratos (antes do dano, contra a vida máxima atual).
	best_hit = maxi(best_hit, total)
	best_hit_pct = maxf(best_hit_pct, total * 100.0 / maxf(1.0, float(enemy.max_hp)))
	max_formations = maxi(max_formations, cascade.formation_ids.size())
	max_attackers = maxi(max_attackers, board.size())
	damage_enemy(total)
	if not puzzle:
		GameState.log_cascade(cascade, total)
		_count_combos(cascade)
	_consume_minions()
	mirror_uid = -1
	jailed_uid = -1
	if cascade.heal > 0:
		GameState.heal(cascade.heal)
	if cascade.self_damage > 0:
		lose_life(mini(cascade.self_damage, GameState.player_hp - 1))   # o pacto nunca mata
	# Selo Phyrexiano: cada ataque custa 10 Poder permanente; a 0, a carta sai da run.
	var used: Array[CardInstance] = []
	used.append_array(board)
	used.append_array(spells_this_turn)
	for c in used:
		if c.seal() == "phyrexian":
			c.grow(-PHYREXIAN_DECAY)
			EventBus.seal_triggered.emit(c, "phyrexian")
			if c.power() <= 0:
				_exile_from_run(c)

## Cada lacaio que bloqueou gasta um golpe; a 0 cai.
func _consume_minions() -> void:
	if minions.is_empty():
		return
	var walkers := 0   # as criaturas com Voar passam por cima dos lacaios
	for c in board:
		if not (c.has_keyword("flying") and not effects.silenced(c)):
			walkers += 1
	var blocked := mini(minions.size(), walkers)
	if blocked <= 0:
		return
	var left: Array[int] = []
	for i in minions.size():
		var h := minions[i] - (1 if i < blocked else 0)
		if h > 0:
			left.append(h)
	minions = left
	EventBus.minions_changed.emit(minions.size())

## Estatísticas dos combos novos (Cadeias e bónus de tribo).
func _count_combos(cascade: Cascade) -> void:
	var tribes := {}
	var set_bonus := false
	for st in cascade.steps:
		if st.source_kind == "chain":
			Stats.on_chain()
		elif st.source_kind == "tribe":
			tribes[st.source_id] = true
		elif st.source_kind == "relic_set":
			set_bonus = true
	if set_bonus:
		Stats.add("relic_set_bonus")   # 0.13.0: conjuntos de relíquias
	if not tribes.is_empty():
		Stats.on_tribe_bonus(tribes.size())

## A carta sai do baralho da run (a entrada fica marcada; GameState.purge_exiled apaga-a no fim).
func _exile_from_run(card: CardInstance) -> void:
	if not card.deck_entry.is_empty():
		card.deck_entry["exiled_run"] = true
	if card in board:
		board.erase(card)
	deck.hand.erase(card)
	deck.graveyard.erase(card)
	deck.library.erase(card)
	deck.to_exile(card)
	EventBus.card_exiled_run.emit(card)

func damage_enemy(amount: int) -> void:
	if amount <= 0 or enemy.hp <= 0:
		return
	enemy.hp = max(0, enemy.hp - amount)
	EventBus.damage_dealt.emit("enemy", amount)
	EventBus.enemy_hp_changed.emit(enemy.hp, enemy.max_hp)

## Contra-ataque: executa o plano de counter_plan() (o mesmo que a pré-visualização mostra).
func _enemy_phase() -> void:
	var plan := counter_plan()
	if int(plan["damage"]) <= 0:
		return
	EventBus.enemy_attacking.emit(int(plan["damage"]), plan["blocker"])
	var b: CardInstance = plan["blocker"]
	if b != null:
		var bd := int(plan["blocker_damage"])
		b.damage += bd
		EventBus.creature_blocked.emit(b, bd)
		if b.is_dead():
			kill_creature(b)
	for s in plan["sacrifices"]:
		var c: CardInstance = s[0]
		c.damage += int(s[1])
		if c.is_dead():
			kill_creature(c)
	if int(plan["player_damage"]) > 0:
		_damage_player(int(plan["player_damage"]))

func _damage_player(amount: int) -> void:
	lose_life(amount)

## Único ponto de perda de vida em batalha: conta para as missões e contratos e respeita o
## Coração de Vidro (um golpe mortal deixa-te com 1, uma vez por run).
func lose_life(amount: int) -> void:
	if amount <= 0:
		return
	if amount >= GameState.player_hp and GameState.can_death_save():
		amount = GameState.player_hp - 1
		GameState.use_death_save()
		EventBus.death_saved.emit()
		if amount <= 0:
			return
	life_lost += amount
	GameState.damage_player(amount)
	if not puzzle:
		GameState.bump_relic_counters("life_lost", amount)
	EventBus.damage_dealt.emit("player", amount)
	_check_missions("life_lost")

## Proteção (palavra-chave): as habilidades e regras do inimigo não tocam nesta criatura.
func is_protected(card: CardInstance) -> bool:
	return card != null and card.has_keyword("protection") and not effects.silenced(card)

## Ladra de Grimórios: tira da mão a carta mais cara (vai para o exílio até ao fim da batalha).
func steal_best_card() -> CardInstance:
	var best: CardInstance = null
	for c in deck.hand:
		if c.data.is_curse():
			continue
		if best == null or c.data.cost > best.data.cost or (c.data.cost == best.data.cost and c.power() > best.power()):
			best = c
	if best == null:
		return null
	deck.remove_from_hand(best)
	deck.to_exile(best)
	EventBus.hand_changed.emit()
	return best

## Carcereiro (0.12.0): a criatura mais forte (sem Proteção) fica presa no ataque seguinte.
func jail_strongest_creature() -> CardInstance:
	var best: CardInstance = null
	for c in creatures():
		if is_protected(c):
			continue
		if best == null or c.power() > best.power():
			best = c
	jailed_uid = best.uid if best != null else -1
	return best

## Ilusionista (0.12.0): baralha a ordem da Arena (com a semente da run). false se não houver o que baralhar.
func shuffle_board() -> bool:
	if board.size() < 2:
		return false
	var before := board.duplicate()
	for i in range(board.size() - 1, 0, -1):
		var j := GameState.rng.randi_range(0, i)
		var tmp := board[i]
		board[i] = board[j]
		board[j] = tmp
	if board == before:   # saiu igual: troca as duas primeiras
		var t2 := board[0]
		board[0] = board[1]
		board[1] = t2
	return true

## Espelho Vivo: copia a criatura mais forte (sem Proteção); no ataque seguinte o Poder base dela não conta.
func mirror_best_creature() -> CardInstance:
	var best: CardInstance = null
	for c in creatures():
		if is_protected(c):
			continue
		if best == null or c.power() > best.power():
			best = c
	mirror_uid = best.uid if best != null else -1
	return best

## Único ponto de saída de uma criatura do tabuleiro — usado pelo bloqueio e pelas habilidades.
func kill_creature(card: CardInstance) -> void:
	if not (card in board):
		return
	var heals := has_rule("counter_heals")
	effects.run_immediate(card, "on_death")   # 0.13.0: "Quando morre: …" (ainda na Arena, para contar vizinhas)
	board.erase(card)
	creatures_died += 1
	if not puzzle and not card.data.token:
		Stats.add("creatures_lost")   # 0.13.0: desbloqueia o Senhor da Carnificina
	if has_rule("death_growth"):   # 0.13.0 Mítica Senhor da Carnificina
		for c in board:
			var g := DEATH_GROWTH * growth_factor()
			c.grow(g)
			EventBus.card_grew.emit(c, g)
	if not card.data.token:
		deck.to_graveyard(card)   # as Fichas desaparecem
	EventBus.creature_died.emit(card)
	if heals:
		GameState.heal(LICH_HEAL)

func _pause(seconds: float) -> void:
	if is_inside_tree() and EventBus.cascade_started.get_connections().size() > 0:
		await get_tree().create_timer(Settings.dur(seconds)).timeout

# ---------------------------------------------------------------------------
# Gravar / retomar a meio da batalha. Chama-se to_dict() no início de cada turno (estado
# simples: sem feitiços lançados nem cascata a correr) e restore() ao continuar a run.
# ---------------------------------------------------------------------------

func to_dict() -> Dictionary:
	return {
		"enemy": enemy.duplicate(true),
		"rule": rule.duplicate(),
		"turn": turn,
		"max_turns": max_turns,
		"extra_turns": extra_turns,
		"extra_turn_granted": extra_turn_granted,
		"land_played_this_turn": land_played_this_turn,
		"ramp": ramp,
		"mana_total": mana_total,
		"mana_available": mana_available,
		"discards_left": discards_left,
		"discards_used": discards_used,
		"discarded_this_turn": discarded_this_turn,
		"drawn_this_turn": drawn_this_turn,
		"silenced": silenced,
		"enemy_vuln": enemy_vuln,
		"player_hp": GameState.player_hp,
		"mulligans": mulligans,
		"pending_bottom": pending_bottom,
		"actions_this_turn": actions_this_turn,
		"pw_used_this_turn": pw_used_this_turn,
		"pw_mult_add": pw_mult_add,
		"pw_mult_mul": pw_mult_mul,
		"pw_mult_per_attacker": pw_mult_per_attacker,
		"pw_mult_per_token": pw_mult_per_token,
		"pw_shield": pw_shield,
		"cheap_hand": cheap_hand,
		"ascended": ascended,
		"climate": climate,
		"phase2": phase2,
		"life_lost": life_lost,
		"best_hit": best_hit,
		"best_hit_pct": best_hit_pct,
		"max_formations": max_formations,
		"max_attackers": max_attackers,
		"flashbacks_used": flashbacks_used,
		"lands_played": lands_played,
		"minions": minions.duplicate(),
		"landfalls": landfalls,
		"creatures_entered": creatures_entered,
		"mana_drain": mana_drain,
		"charge_mult": charge_mult,
		"creatures_died": creatures_died,
		"ward": ward,
		"item_mult": item_mult,
		"item_echo": item_echo,
		"phase_index": phase_index,
		"items_used": items_used,
		"hand_size": hand_size,
		"stolen": GameState.stolen_relics.duplicate(),
		"blocker_index": _index_of_uid(chosen_blocker) if chosen_blocker >= 0 else chosen_blocker,
		"puzzle": puzzle,   # 0.13.0: o DESFAZER num enigma/lição/treino não pode esquecer que é um enigma
		"jailed_index": _index_of_uid(jailed_uid),
		"mirror_index": _mirror_index(),
		"tokens_created": tokens_created,
		"shield_absorbed": shield_absorbed,
		"enchantments": _zone_to_list(enchantments),
		"library": _zone_to_list(deck.library),
		"hand": _zone_to_list(deck.hand),
		"graveyard": _zone_to_list(deck.graveyard),
		"exile": _zone_to_list(deck.exile),
		"board": _zone_to_list(board),
	}

func _index_of_uid(uid: int) -> int:
	for i in board.size():
		if board[i].uid == uid:
			return i
	return -1

func _mirror_index() -> int:
	for i in board.size():
		if board[i].uid == mirror_uid:
			return i
	return -1

static func _zone_to_list(cards: Array[CardInstance]) -> Array:
	var out := []
	for c in cards:
		out.append({
			"id": c.data.id, "entry": c.entry_index, "damage": c.damage,
			"power_bonus": c.power_bonus, "toughness_bonus": c.toughness_bonus,
			"consumed": c.consumed, "exiled": c.exiled,
			"transformed": c.transformed, "mission_count": c.mission_count, "turns_in_hand": c.turns_in_hand,
			"kicked": c.kicked, "kw": c.granted_keywords.duplicate(),
			"seal": c.seal() if c.entry_index < 0 else "",
			"edition": c.edition() if c.entry_index < 0 else "",
		})
	return out

static func _card_from_state(cs: Dictionary) -> CardInstance:
	var id := String(cs.get("id", ""))
	var idx := int(cs.get("entry", -1))
	var entry: Dictionary = {}
	if idx >= 0 and idx < GameState.deck.size() and String(GameState.deck[idx].get("id", "")) == id:
		entry = GameState.deck[idx]
	elif String(cs.get("seal", "")) != "" or String(cs.get("edition", "")) != "":
		entry = {"id": id}   # carta de lição/enigma com selo ou edição (fora do baralho)
		if String(cs.get("seal", "")) != "":
			entry["seal"] = String(cs["seal"])
		if String(cs.get("edition", "")) != "":
			entry["edition"] = String(cs["edition"])
	var c := CardDB.new_instance(id, entry)
	if c == null:
		return null
	c.entry_index = idx if not entry.is_empty() and idx >= 0 else -1
	c.damage = int(cs.get("damage", 0))
	c.power_bonus = int(cs.get("power_bonus", 0))
	c.toughness_bonus = int(cs.get("toughness_bonus", 0))
	c.consumed = bool(cs.get("consumed", false))
	c.exiled = bool(cs.get("exiled", false))
	c.mission_count = int(cs.get("mission_count", 0))
	c.turns_in_hand = int(cs.get("turns_in_hand", 0))
	c.kicked = bool(cs.get("kicked", false))
	if bool(cs.get("transformed", false)):
		c.transform()
	for k in cs.get("kw", []):
		c.grant_keyword(String(k))
	return c

## Estado completo para "desfazer" dentro do turno: batalha + RNG + ouro + bónus permanentes.
func snapshot() -> Dictionary:
	var bonuses := []
	for e in GameState.deck:
		bonuses.append(e.duplicate(true))
	return {"battle": to_dict(), "rng": GameState.rng.state, "gold": GameState.gold, "bonuses": bonuses,
		"relics": GameState.relic_ids.duplicate(), "loyalty": GameState.planeswalker_loyalty(),
		"formation_levels": GameState.formation_levels.duplicate(), "player_hp": GameState.player_hp}

func restore_snapshot(snap: Dictionary) -> bool:
	if resolving or finished:
		return false
	var bonuses: Array = snap.get("bonuses", [])
	for i in min(bonuses.size(), GameState.deck.size()):
		var e: Dictionary = GameState.deck[i]
		for k in e.keys():
			if not (bonuses[i] as Dictionary).has(k):
				e.erase(k)
		for k in bonuses[i]:
			e[k] = bonuses[i][k]
	GameState.rng.state = int(snap.get("rng", GameState.rng.state))
	GameState.gold = int(snap.get("gold", GameState.gold))
	if not GameState.planeswalker.is_empty():
		GameState.planeswalker["loyalty"] = int(snap.get("loyalty", GameState.planeswalker_loyalty()))
	GameState.formation_levels = (snap.get("formation_levels", {}) as Dictionary).duplicate()
	EventBus.gold_changed.emit(GameState.gold)
	EventBus.planeswalker_changed.emit()
	return restore(snap.get("battle", {}))

## Repõe uma batalha gravada. Devolve false se os dados não prestarem (aí começa-se uma nova).
func restore(d: Dictionary) -> bool:
	var e: Dictionary = d.get("enemy", {})
	if e.is_empty() or int(d.get("turn", 0)) < 1:
		return false
	enemy = e.duplicate(true)
	enemy["hp"] = int(enemy.get("hp", 1))
	enemy["max_hp"] = int(enemy.get("max_hp", enemy["hp"]))
	enemy["attack"] = int(enemy.get("attack", 0))
	var abilities: Array = []
	for a in enemy.get("abilities", []):
		var ab: Dictionary = a.duplicate()
		if ab.has("value"):
			ab["value"] = int(ab["value"])
		if ab.has("n"):
			ab["n"] = int(ab["n"])
		abilities.append(ab)
	enemy["abilities"] = abilities
	rule = (d.get("rule", enemy.get("rule", {})) as Dictionary).duplicate()
	hand_size = _hand_size_for_rule()
	turn = int(d.get("turn", 1))
	max_turns = int(d.get("max_turns", GameState.turns_for_ante(GameState.ante)))
	extra_turns = int(d.get("extra_turns", 0))
	extra_turn_granted = bool(d.get("extra_turn_granted", false))
	land_played_this_turn = bool(d.get("land_played_this_turn", false))
	ramp = int(d.get("ramp", 0))
	mana_total = int(d.get("mana_total", turn + 1))
	mana_available = int(d.get("mana_available", mana_total))
	discards_left = int(d.get("discards_left", GameState.discards_for_battle()))
	discards_used = int(d.get("discards_used", 0))
	discarded_this_turn = int(d.get("discarded_this_turn", 0))
	drawn_this_turn = int(d.get("drawn_this_turn", 0))
	silenced = bool(d.get("silenced", false))
	enemy_vuln = float(d.get("enemy_vuln", 1.0))
	mulligans = int(d.get("mulligans", 0))
	pending_bottom = int(d.get("pending_bottom", 0))
	actions_this_turn = int(d.get("actions_this_turn", 0))
	pw_used_this_turn = bool(d.get("pw_used_this_turn", false))
	pw_mult_add = float(d.get("pw_mult_add", 0.0))
	pw_mult_mul = float(d.get("pw_mult_mul", 1.0))
	pw_mult_per_attacker = float(d.get("pw_mult_per_attacker", 0.0))
	pw_mult_per_token = float(d.get("pw_mult_per_token", 0.0))
	pw_shield = bool(d.get("pw_shield", false))
	cheap_hand = bool(d.get("cheap_hand", false))
	ascended = bool(d.get("ascended", false))
	climate = String(d.get("climate", ""))
	phase2 = bool(d.get("phase2", false))
	life_lost = int(d.get("life_lost", 0))
	best_hit = int(d.get("best_hit", 0))
	best_hit_pct = float(d.get("best_hit_pct", 0.0))
	max_formations = int(d.get("max_formations", 0))
	max_attackers = int(d.get("max_attackers", 0))
	flashbacks_used = int(d.get("flashbacks_used", 0))
	lands_played = int(d.get("lands_played", 0))
	minions.clear()
	for h in d.get("minions", []):
		minions.append(int(h))
	landfalls = int(d.get("landfalls", 0))
	tokens_created = int(d.get("tokens_created", 0))
	shield_absorbed = int(d.get("shield_absorbed", 0))
	counter_prevented = false
	counter_reduce = 0
	protect_creatures = false
	reaction_used = false
	puzzle = bool(d.get("puzzle", false))   # 0.13.0: o desfazer de um enigma continua a ser um enigma
	var empty: Array[Dictionary] = []
	deck = Deck.new(empty, GameState.rng)
	for cs in d.get("library", []):
		var c := _card_from_state(cs)
		if c:
			c.zone = CardInstance.Zone.DECK
			deck.library.append(c)
	for cs in d.get("hand", []):
		var c := _card_from_state(cs)
		if c:
			c.zone = CardInstance.Zone.HAND
			deck.hand.append(c)
	for cs in d.get("graveyard", []):
		var c := _card_from_state(cs)
		if c:
			c.zone = CardInstance.Zone.GRAVEYARD
			deck.graveyard.append(c)
	for cs in d.get("exile", []):
		var c := _card_from_state(cs)
		if c:
			c.zone = CardInstance.Zone.EXILE
			deck.exile.append(c)
	board.clear()
	for cs in d.get("board", []):
		var c := _card_from_state(cs)
		if c:
			c.zone = CardInstance.Zone.BOARD
			board.append(c)
	enchantments.clear()
	for cs in d.get("enchantments", []):
		var c := _card_from_state(cs)
		if c:
			c.zone = CardInstance.Zone.ENCHANT
			enchantments.append(c)
	var mi := int(d.get("mirror_index", -1))
	mirror_uid = board[mi].uid if mi >= 0 and mi < board.size() else -1
	var ji := int(d.get("jailed_index", -1))
	jailed_uid = board[ji].uid if ji >= 0 and ji < board.size() else -1
	mana_drain = int(d.get("mana_drain", 0))
	charge_mult = float(d.get("charge_mult", 1.0))
	creatures_died = int(d.get("creatures_died", 0))
	ward = bool(d.get("ward", false))
	item_mult = float(d.get("item_mult", 1.0))
	item_echo = bool(d.get("item_echo", false))
	phase_index = int(d.get("phase_index", 0))
	items_used = int(d.get("items_used", 0))
	hand_size = int(d.get("hand_size", hand_size))
	GameState.stolen_relics.clear()
	for r in d.get("stolen", []):
		GameState.stolen_relics.append(String(r))
	CardInstance.keywords_off = bool(rule.get("no_keywords", false))
	var bi := int(d.get("blocker_index", BLOCK_AUTO))
	chosen_blocker = board[bi].uid if bi >= 0 and bi < board.size() else (BLOCK_NONE if bi == BLOCK_NONE else BLOCK_AUTO)
	perfect_play = false
	mana_saved = 0
	last_mana_saved = 0
	creatures_entered = int(d.get("creatures_entered", board.size()))
	spells_this_turn.clear()
	effects = EffectResolver.new(self)
	enemy_abilities = EnemyAbilities.new(self)
	resolving = false
	finished = false
	GameState.player_hp = int(d.get("player_hp", GameState.player_max_hp))
	EventBus.battle_started.emit(enemy)
	EventBus.enemy_hp_changed.emit(enemy.hp, enemy.max_hp)
	EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)
	EventBus.mana_changed.emit(mana_available, mana_total)
	EventBus.discards_changed.emit(discards_left)
	EventBus.hand_changed.emit()
	EventBus.turn_started.emit(turn)
	return true

func _finish(victory: bool) -> void:
	if finished:
		return
	finished = true
	resolving = false
	CardInstance.keywords_off = false
	var had_stolen := not GameState.stolen_relics.is_empty()
	GameState.stolen_relics.clear()   # as relíquias roubadas voltam no fim da batalha
	if not puzzle and GameState.puzzle_id == "":   # 0.13.0: enigmas, lições e treino nunca mexem na run
		if victory:
			GameState.add_gold(GameState.battle_reward(turns_left(), turn))
			if had_stolen:   # 0.13.0 Ladra de Relíquias vencida
				GameState.add_gold(GameState.RELIC_THIEF_GOLD)
			var affixes: Array = enemy.get("affixes", []) if enemy.get("affixes") is Array else []
			if not affixes.is_empty():   # 0.13.0: cada afixo da Elite vale ouro
				GameState.add_gold(GameState.AFFIX_GOLD * affixes.size())
			if perfect_play:   # 0.13.0 jogada perfeita
				GameState.add_gold(PERFECT_GOLD)
				Stats.add("perfect_plays")
			GameState.bump_relic_counters("battle_won")
			if bool(enemy.get("boss", false)):
				GameState.boss_clean = not phase2   # 0.13.0: 3.ª estrela dos Desafios (o último boss vencido)
			if bool(enemy.get("boss", false)) and not phase2:
				Stats.on_boss_no_phase2()
			if String(enemy.get("variant", "")) == "elite" and not bool(enemy.get("boss", false)):
				elite_relic = GameState.grant_elite_relic()
				Stats.on_elite()
				elite_item = GameState.random_consumable()   # 0.13.0: as Elites deixam também uma poção ou pergaminho
				if elite_item != "" and not GameState.add_consumable(elite_item):
					elite_item = ""
		GameState.after_battle(self, victory)
		GameState.resolve_contract(self, victory)
		GameState.purge_exiled()
	EventBus.battle_ended.emit(victory)
