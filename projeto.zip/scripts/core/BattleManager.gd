class_name BattleManager
extends Node
## Regras de uma batalha. Sem UI — a cena Battle.tscn liga-se aos sinais do EventBus.
##
## Loop: N turnos. No turno N tens N+1 de mana (mais os terrenos jogados). A mão repõe-se até
## HAND_SIZE. Jogas criaturas (ficam no tabuleiro, máx. MAX_CREATURES), feitiços (contam no
## ataque deste turno) e terrenos (opcionais: +1 mana permanente; na mão dão bónus).
## Canalizar: botão + toque numa carta descarta-a e compra outra (DISCARDS por batalha).
## Ao terminar o turno TODAS as criaturas atacam através de uma CASCATA (Poder × Mult):
## criaturas → feitiços → formações → cartas na mão → relíquias → planeswalker.
## O inimigo responde com dano fixo: bloqueia a criatura mais robusta que SOBREVIVA ao golpe;
## se nenhuma sobreviver, o jogador leva o dano — a não ser que seja letal, e aí as criaturas
## sacrificam-se da mais fraca para a mais forte. Ganhas se a vida do inimigo chegar a 0.
## A vida do jogador atravessa a run (cura-se na loja). Bosses trazem uma "rule":
##   discards_minus N · hand_size N · creature_cost_plus N · no_formations · relics_off · color_silenced <cor>
##
## 0.8.0: Mulligan de Londres (turno 1, antes de qualquer jogada), cartas de dupla face (missão →
## transformação), selos de guilda (Fúria/Sabedoria/Phyrexiano/Vitalidade/Dízimo), Recapitular
## (feitiços do cemitério → exílio), planeswalker (lealdade e 3 habilidades), Selos Planares
## (mão 5, 2 canalizações, 2.ª regra do boss) e quebra-cabeças (1 turno, mão fixa).
## 0.9.0: Clima Planar da batalha (`climate`), bosses em 2 fases (abaixo de metade: +ataque e fala;
## com o Selo 8 também a 2.ª regra), regras novas de boss — attack_per_graveyard N · gold_tax N ·
## max_creatures N · spell_cost_plus N · creature_cost_minus N · exile_rightmost — e os contadores
## que os contratos usam (vida perdida, maior golpe, formações, atacantes, recapitulações, terrenos).

const MAX_CREATURES := 5
const HAND_SIZE := 6
const DISCARDS := 3
const MAX_MANA := 10
const MIN_HAND_AFTER_MULLIGAN := 3
const INFECTED_USES := 3
const PHYREXIAN_DECAY := 10
const PHASE2_ATTACK := 2
const METEOR_DAMAGE := 2

var deck: Deck
var board: Array[CardInstance] = []        # criaturas, pela ordem em que foram jogadas
var spells_this_turn: Array[CardInstance] = []
var turn: int = 0
var max_turns: int = 5
var extra_turns: int = 0
var extra_turn_granted: bool = false
var land_played_this_turn: bool = false
var ramp: int = 0                           # terrenos jogados (+1 mana permanente cada)
var mana_total: int = 0
var mana_available: int = 0
var discards_left: int = DISCARDS
var discards_used: int = 0
var discarded_this_turn: int = 0
var drawn_this_turn: int = 0
var silenced: bool = false                  # habilidades do inimigo não disparam este turno
var enemy_vuln: float = 1.0                 # multiplicador de dano ao inimigo (maldições)
var resolving: bool = false                 # true enquanto a cascata/fase inimiga está a correr
var finished: bool = false

# 0.8.0
var mulligans: int = 0
var pending_bottom: int = 0                 # cartas que ainda tens de pôr no fundo depois do mulligan
var actions_this_turn: int = 0              # jogadas/canalizações/habilidades (o mulligan só antes de tudo)
var pw_used_this_turn: bool = false
var pw_mult_add: float = 0.0                # bónus do planeswalker para o ataque deste turno
var pw_mult_mul: float = 1.0
var pw_mult_per_attacker: float = 0.0
var pw_shield: bool = false                 # o inimigo não contra-ataca este turno
var cheap_hand: bool = false                # todas as cartas na mão custam 1 este turno
var puzzle: bool = false                    # quebra-cabeças: 1 turno, sem gravação
var ascended: bool = false                  # 2.ª regra do boss já ativada (Selo Planar 8)

# 0.9.0
var climate: String = ""                    # Clima Planar desta batalha ("" = nenhum)
var phase2: bool = false                    # boss abaixo de metade da vida (desperto)
var life_lost: int = 0                      # vida perdida nesta batalha (missões, contratos)
var best_hit: int = 0                       # maior ataque desta batalha
var best_hit_pct: float = 0.0               # … em % da vida máxima do inimigo
var elite_relic: String = ""                # relíquia ganha ao vencer uma Elite ("" = nenhuma / 10 ouro)
var max_formations: int = 0                 # mais formações ativas num só ataque
var max_attackers: int = 0                  # mais criaturas num só ataque
var flashbacks_used: int = 0
var lands_played: int = 0
var _channel_draw: bool = false             # a compra da canalização não paga a taxa do Falsário

var enemy: Dictionary = {}   # {name, hp, max_hp, attack, text, abilities, boss, rule}
var rule: Dictionary = {}    # regra do boss (vazio nos inimigos normais)
var hand_size: int = HAND_SIZE
var effects: EffectResolver
var enemy_abilities: EnemyAbilities

func start(enemy_def: Dictionary) -> void:
	enemy = enemy_def.duplicate(true)
	rule = (enemy.get("rule", {}) as Dictionary).duplicate()
	hand_size = _hand_size_for_rule()
	max_turns = GameState.turns_for_ante(GameState.ante)
	deck = Deck.new(GameState.deck, GameState.rng)
	board.clear()
	spells_this_turn.clear()
	effects = EffectResolver.new(self)
	enemy_abilities = EnemyAbilities.new(self)
	turn = 0
	ramp = 0
	extra_turns = 0
	extra_turn_granted = false
	discards_left = max(1, GameState.discards_for_battle() - int(rule.get("discards_minus", 0)))
	discards_used = 0
	enemy_vuln = 1.0
	resolving = false
	finished = false
	mulligans = 0
	pending_bottom = 0
	ascended = false
	puzzle = false
	climate = GameState.current_climate_id()
	phase2 = false
	life_lost = 0
	best_hit = 0
	elite_relic = ""
	best_hit_pct = 0.0
	max_formations = 0
	max_attackers = 0
	flashbacks_used = 0
	lands_played = 0
	if GameState.player_hp <= 0:
		GameState.player_hp = 1   # nunca começar uma batalha já morto
	EventBus.battle_started.emit(enemy)
	EventBus.enemy_hp_changed.emit(enemy.hp, enemy.max_hp)
	EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)
	effects.trigger_relics("battle_start")
	deck.draw_opening_hand(hand_size)
	next_turn()

## Quebra-cabeças: mão e tabuleiro fixos, 1 turno, 0 canalizações, mana dada. Sem baralho de run.
func start_puzzle(def: Dictionary) -> void:
	var state := {
		"enemy": {"id": "", "name": def.get("enemy_name", "Enigma"), "hp": int(def.get("hp", 1000)),
			"max_hp": int(def.get("hp", 1000)), "attack": 0, "text": def.get("enemy_text", ""), "abilities": [],
			"boss": false, "rule": def.get("rule", {})},
		"turn": 1, "max_turns": 1, "mana_total": int(def.get("mana", 4)), "mana_available": int(def.get("mana", 4)),
		"discards_left": 0, "player_hp": GameState.player_hp,
		"library": [], "hand": [], "graveyard": [], "board": [], "exile": [],
	}
	for id in def.get("hand", []):
		state["hand"].append({"id": String(id), "entry": -1})
	for id in def.get("board", []):
		state["board"].append({"id": String(id), "entry": -1})
	for id in def.get("graveyard", []):
		state["graveyard"].append({"id": String(id), "entry": -1, "exiled": true})
	restore(state)
	puzzle = true

func _hand_size_for_rule() -> int:
	var base := GameState.hand_size_for_battle()
	return min(base, int(rule.get("hand_size", base)))

func next_turn() -> void:
	turn += 1
	land_played_this_turn = false
	silenced = false
	discarded_this_turn = 0
	drawn_this_turn = 0
	actions_this_turn = 0
	pw_used_this_turn = false
	pw_mult_add = 0.0
	pw_mult_mul = 1.0
	pw_mult_per_attacker = 0.0
	pw_shield = false
	cheap_hand = false
	spells_this_turn.clear()
	mana_total = min(mana_cap(), turn + 1 + ramp + int(GameState.relic_passive("mana_plus")))   # turno 1 = 2 de mana
	mana_available = mana_total
	if turn > 1:
		var refill_to := hand_size
		if climate == "scorching_sands" and turn >= 4:
			refill_to = mini(refill_to, 5)
		deck.refill(refill_to)
	effects.trigger_relics("turn_start")
	_check_missions("gold")
	EventBus.mana_changed.emit(mana_available, mana_total)
	EventBus.discards_changed.emit(discards_left)
	# turn_started vem depois das relíquias de início de turno: a UI grava a batalha neste momento.
	EventBus.turn_started.emit(turn)

# --- Consultas ---

func creatures() -> Array[CardInstance]:
	return board.duplicate()

## Todas as criaturas atacam, incluindo as jogadas neste turno.
func attackers() -> Array[CardInstance]:
	return board.duplicate()

## Mana máxima (10; 5 com o Eclipse de Mana).
func mana_cap() -> int:
	return 5 if climate == "mana_eclipse" else MAX_MANA

## Lugares na Arena (5; o Titã de Cinza deixa 3).
func max_creatures() -> int:
	return mini(MAX_CREATURES, int(rule.get("max_creatures", MAX_CREATURES)))

## Ataque do inimigo agora (a Hidra de Mil Olhos soma +1 por cada N cartas no teu cemitério).
func enemy_attack() -> int:
	var dmg := int(enemy.get("attack", 0))
	var per := int(rule.get("attack_per_graveyard", 0))
	if per > 0 and deck != null:
		dmg += int(deck.graveyard.size() / per)
	return dmg

## O contra-ataque deste turno não acontece? (escudo do planeswalker, Algemas de Marfim no turno 1)
func counter_blocked() -> bool:
	return pw_shield or (turn == 1 and GameState.relic_passive("no_counter_turn1") > 0)

## Lua de Sangue: noite nos turnos pares.
func is_night() -> bool:
	return turn % 2 == 0

func climate_name() -> String:
	return String(CardDB.get_climate(climate).get("name", "")) if climate != "" else ""

## Pré-visualização do ataque atual (puro, não altera nada).
func preview_attack() -> Cascade:
	return effects.build_attack_cascade()

func turns_left() -> int:
	return max_turns + extra_turns - turn

## Quanto subiria o total do ataque se jogasses esta carta agora (ignora efeitos imediatos
## como compras de cartas — é uma aproximação, mas é a que o jogador precisa de ver).
func preview_play(card: CardInstance) -> int:
	if not can_play(card):
		return 0
	var base := effects.build_attack_cascade().total()
	var idx := deck.hand.find(card)
	if idx < 0:
		return 0
	var old_zone := card.zone
	deck.hand.remove_at(idx)
	if card.data.is_creature():
		card.zone = CardInstance.Zone.BOARD
		board.append(card)
	elif card.data.is_spell():
		card.zone = CardInstance.Zone.GRAVEYARD
		spells_this_turn.append(card)
	var total := effects.build_attack_cascade().total()
	if card.data.is_creature():
		board.erase(card)
	elif card.data.is_spell():
		spells_this_turn.erase(card)
	card.zone = old_zone
	deck.hand.insert(idx, card)
	return total - base

## Pré-visualização do contra-ataque (puro): quem bloqueia, se sobrevive, quanto levas tu.
func preview_enemy_phase() -> Dictionary:
	var dmg: int = enemy_attack()
	var out := {"damage": dmg, "blocker": null, "survives": false, "player_damage": 0, "deaths": []}
	if dmg <= 0 or counter_blocked():
		out["damage"] = 0
		return out
	var blockers := creatures()
	blockers.sort_custom(func(a, b): return a.remaining() > b.remaining())
	for b in blockers:
		if b.remaining() > dmg:
			out["blocker"] = b
			out["survives"] = true
			return out
	if GameState.player_hp > dmg:
		out["player_damage"] = dmg
		return out
	blockers.sort_custom(func(a, b): return a.remaining() < b.remaining())
	var left := dmg
	var deaths: Array = []
	for b in blockers:
		if left <= 0:
			break
		var absorbed: int = min(left, b.remaining())
		left -= absorbed
		if absorbed >= b.remaining():
			deaths.append(b)
	out["deaths"] = deaths
	out["player_damage"] = max(0, left)
	return out

## Habilidades do inimigo que vão disparar no fim deste turno (para mostrar a intenção).
func enemy_intent(for_turn: int) -> Array:
	var out: Array = []
	for a in enemy.get("abilities", []):
		var trig: String = a.get("trigger", "turn_end")
		if trig == "turn_end" or (trig == "every_n_turns" and for_turn % int(a.get("n", 1)) == 0):
			out.append(a)
	return out

## Reordenar criaturas (arrastar no tabuleiro): a ordem importa na cascata.
func move_creature(card: CardInstance, index: int) -> void:
	if resolving or finished or not (card in board):
		return
	board.erase(card)
	board.insert(clampi(index, 0, board.size()), card)

# --- Mulligan de Londres ---

## Só no 1.º turno, antes de qualquer jogada; cada mulligan mete mais uma carta no fundo.
func can_mulligan() -> bool:
	if resolving or finished or puzzle or turn != 1 or actions_this_turn > 0 or pending_bottom > 0:
		return false
	return hand_size - (mulligans + 1) >= MIN_HAND_AFTER_MULLIGAN

func mulligan() -> bool:
	if not can_mulligan():
		return false
	deck.shuffle_hand_in()
	deck.draw(hand_size)
	mulligans += 1
	pending_bottom = mulligans
	Stats.on_mulligan()
	EventBus.mulligan_taken.emit(pending_bottom)
	EventBus.hand_changed.emit()
	return true

## Depois do mulligan: escolhe as cartas a pôr no fundo do grimório (uma por chamada).
func bottom_card(card: CardInstance) -> bool:
	if pending_bottom <= 0 or card.zone != CardInstance.Zone.HAND:
		return false
	deck.remove_from_hand(card)
	deck.to_library_bottom(card)
	pending_bottom -= 1
	EventBus.hand_changed.emit()
	return true

# --- Ações do jogador ---

func can_play(card: CardInstance) -> bool:
	if resolving or finished or pending_bottom > 0:
		return false
	if card.zone != CardInstance.Zone.HAND or card.data.is_curse():
		return false
	if card.data.is_land():
		return not land_played_this_turn
	if card.data.is_creature() and board.size() >= max_creatures():
		return false
	return effects.cost_of(card) <= mana_available

func play(card: CardInstance) -> bool:
	if not can_play(card):
		return false
	actions_this_turn += 1
	deck.remove_from_hand(card)
	if card.data.is_land():
		land_played_this_turn = true
		lands_played += 1
		ramp += 1
		if mana_total < mana_cap():
			mana_total += 1
			mana_available += 1
		deck.to_graveyard(card)   # o terreno "entra" no mundo; deixa de dar o bónus de mão
		EventBus.land_played.emit(card)
		effects.trigger_relics("land_played", card)
	else:
		mana_available -= effects.cost_of(card)
		if card.data.is_creature():
			card.zone = CardInstance.Zone.BOARD
			board.append(card)
			EventBus.creature_summoned.emit(card)
			effects.run_immediate(card, "on_play")
		else:
			card.zone = CardInstance.Zone.GRAVEYARD
			spells_this_turn.append(card)
			effects.run_immediate(card, "on_cast")
			if card.data.return_to_library:
				deck.to_library_bottom(card)
			else:
				deck.to_graveyard(card)   # volta ao grimório quando este se esgota (reciclagem)
			EventBus.spell_cast.emit(card)
	_after_play(card)
	EventBus.card_played.emit(card)
	EventBus.mana_changed.emit(mana_available, mana_total)
	if enemy.hp <= 0:
		_finish(true)
	return true

## Selos, missões, lealdade do planeswalker e infeção — comum a jogar da mão e a Recapitular.
func _after_play(card: CardInstance) -> void:
	match card.seal():
		"tithe":
			GameState.add_gold(3)
			EventBus.seal_triggered.emit(card, "tithe")
		"vitality":
			var target := effects.left_of(card)
			if target != null:
				target.grow(15)
				EventBus.card_grew.emit(target, 15)
				EventBus.seal_triggered.emit(card, "vitality")
	if card.data.is_creature():
		_check_missions("creatures", card)
		_check_missions("board_full", card)
	elif card.data.is_spell():
		_check_missions("spells", card)
		_check_missions("spells_turn", card)
	if GameState.planeswalker_color() != "" and card.data.has_color(GameState.planeswalker_color()):
		GameState.change_loyalty(1)
	if card.data.infected and not card.deck_entry.is_empty():
		card.deck_entry["uses"] = int(card.deck_entry.get("uses", 0)) + 1
		if int(card.deck_entry["uses"]) >= INFECTED_USES:
			_exile_from_run(card)

func can_discard(card: CardInstance) -> bool:
	return not resolving and not finished and pending_bottom <= 0 and discards_left > 0 and card.zone == CardInstance.Zone.HAND

## Canalizar: descarta a carta e compra outra.
func discard(card: CardInstance) -> bool:
	if not can_discard(card):
		return false
	actions_this_turn += 1
	discards_left -= 1
	discards_used += 1
	discarded_this_turn += 1
	deck.remove_from_hand(card)
	deck.to_graveyard(card)
	effects.run_immediate(card, "on_discard")
	EventBus.card_discarded.emit(card)
	GameState.bump_relic_counters("channel")
	_check_missions("channel", card)
	_channel_draw = true
	draw(1)
	_channel_draw = false
	_gold_tax(1)
	EventBus.discards_changed.emit(discards_left)
	EventBus.hand_changed.emit()
	return true

func discard_random(count: int) -> void:
	for i in count:
		if deck.hand.is_empty():
			break
		var idx := GameState.rng.randi_range(0, deck.hand.size() - 1)
		var card: CardInstance = deck.hand[idx]
		deck.remove_from_hand(card)
		deck.to_graveyard(card)
		EventBus.card_discarded.emit(card)
	EventBus.hand_changed.emit()

func draw(count: int) -> void:
	var drawn := deck.draw(count)
	drawn_this_turn += drawn.size()
	if not _channel_draw:
		_gold_tax(drawn.size())

## Falsário de Moedas: −1 ouro por canalização e por carta comprada por efeitos.
func _gold_tax(times: int) -> void:
	var tax := int(rule.get("gold_tax", 0))
	if tax <= 0 or times <= 0 or GameState.gold <= 0:
		return
	GameState.add_gold(-tax * times)
	EventBus.enemy_ability_used.emit(String(enemy.get("name", "")), "gold_tax")

func grant_extra_turn() -> void:
	if extra_turn_granted:
		return
	extra_turn_granted = true
	extra_turns += 1
	EventBus.turn_started.emit(turn)   # para a UI atualizar "Turno x/y"

# --- Recapitular (flashback) ---

func flashback_cards() -> Array[CardInstance]:
	return deck.flashback_cards()

func can_flashback(card: CardInstance) -> bool:
	if resolving or finished or pending_bottom > 0 or not card.data.flashback or not card.data.is_spell():
		return false
	if card.zone != CardInstance.Zone.GRAVEYARD or not (card in deck.graveyard):
		return false
	return effects.cost_of(card) <= mana_available

## Lança um feitiço a partir do cemitério; no fim vai para o exílio até ao fim da batalha.
func play_flashback(card: CardInstance) -> bool:
	if not can_flashback(card):
		return false
	actions_this_turn += 1
	deck.graveyard.erase(card)
	mana_available -= effects.cost_of(card)
	card.zone = CardInstance.Zone.GRAVEYARD
	spells_this_turn.append(card)
	effects.run_immediate(card, "on_cast")
	deck.to_exile(card)
	flashbacks_used += 1
	Stats.on_flashback()
	var pct := GameState.relic_passive("flashback_damage_pct")
	if pct > 0.0:
		damage_enemy(int(round(enemy.max_hp * pct / 100.0)))
	EventBus.spell_cast.emit(card)
	EventBus.card_flashback.emit(card)
	_after_play(card)
	EventBus.card_played.emit(card)
	EventBus.mana_changed.emit(mana_available, mana_total)
	EventBus.hand_changed.emit()
	if enemy.hp <= 0:
		_finish(true)
	return true

# --- Dupla face ---

## Avança as missões com este gatilho (cartas na mão e no tabuleiro, menos a própria fonte).
func _check_missions(trigger: String, source: CardInstance = null) -> void:
	if deck == null:
		return
	# Missões "de estado": o progresso é o valor atual (ouro, feitiços neste turno, Arena, vida perdida).
	var state := {"gold": GameState.gold, "spells_turn": spells_this_turn.size(), "board_full": board.size(), "life_lost": life_lost}
	var candidates: Array[CardInstance] = []
	candidates.append_array(deck.hand)
	candidates.append_array(board)
	for c in candidates:
		if not c.has_mission() or c.mission_trigger() != trigger:
			continue
		if state.has(trigger):
			c.mission_count = int(state[trigger])
		elif c == source:
			continue
		else:
			c.mission_count += 1
		if c.mission_count >= c.mission_target():
			_transform(c)

func _transform(card: CardInstance) -> void:
	if not card.transform():
		return
	Stats.on_transform()
	EventBus.card_transformed.emit(card)
	effects.run_immediate(card, "on_transform")
	EventBus.hand_changed.emit()

## Reavalia as missões de ouro (chamado quando o ouro muda a meio da batalha).
func on_gold_changed() -> void:
	if deck != null and not finished:
		_check_missions("gold")

# --- Planeswalker ---

func planeswalker_skills() -> Array:
	return GameState.planeswalker_def().get("skills", [])

func can_use_planeswalker(index: int) -> bool:
	if resolving or finished or pending_bottom > 0 or pw_used_this_turn:
		return false
	var skills := planeswalker_skills()
	if index < 0 or index >= skills.size():
		return false
	var cost := int(skills[index].get("cost", 0))
	return cost > 0 or GameState.planeswalker_loyalty() >= -cost

func use_planeswalker(index: int) -> bool:
	if not can_use_planeswalker(index):
		return false
	var skill: Dictionary = planeswalker_skills()[index]
	var cost := int(skill.get("cost", 0))
	pw_used_this_turn = true
	actions_this_turn += 1
	GameState.change_loyalty(cost)
	var v := float(skill.get("value", 0))
	var color := GameState.planeswalker_color()
	match String(skill.get("action", "")):
		"buff_hand_color":
			for h in deck.hand:
				if h.data.has_color(color):
					h.power_bonus += int(v)
		"mult_add":
			pw_mult_add += v
		"cheap_hand":
			cheap_hand = true
			for h in deck.hand:
				if not h.data.is_land():
					h.power_bonus += int(v)
		"draw":
			draw(int(v))
		"channel_draw":
			discards_left += 1
			draw(int(v))
			EventBus.discards_changed.emit(discards_left)
		"extra_turn_mult":
			extra_turn_granted = false
			grant_extra_turn()
			pw_mult_mul *= v
		"buff_strongest":
			var best: CardInstance = null
			for c in board:
				if best == null or c.power() > best.power():
					best = c
			if best != null:
				best.power_bonus += int(v)
				EventBus.card_grew.emit(best, int(v))
		"enemy_max_hp_pct":
			var cut := int(round(enemy.max_hp * v / 100.0))
			enemy.max_hp = max(1, enemy.max_hp - cut)
			enemy.hp = min(enemy.hp, enemy.max_hp)
			EventBus.enemy_hp_changed.emit(enemy.hp, enemy.max_hp)
		"mult_mul_pay_life":
			pw_mult_mul *= v
			lose_life(mini(int(skill.get("life", 0)), GameState.player_hp - 1))
		"grow_random_board":
			if not board.is_empty():
				var c: CardInstance = board[GameState.rng.randi_range(0, board.size() - 1)]
				c.grow(int(v))
				EventBus.card_grew.emit(c, int(v))
		"buff_board_mult":
			for c in board:
				c.power_bonus += int(v)
			pw_mult_add += float(skill.get("mult", 0))
		"mult_mul_grow":
			pw_mult_mul *= v
			for c in board:
				c.grow(int(skill.get("grow", 0)))
				EventBus.card_grew.emit(c, int(skill.get("grow", 0)))
		"heal":
			GameState.heal(int(v))
		"mult_per_attacker":
			pw_mult_per_attacker += v
		"mult_mul_shield":
			pw_mult_mul *= v
			pw_shield = true
	if cost <= -6:
		Stats.on_pw_ultimate()
	EventBus.planeswalker_changed.emit()
	EventBus.mana_changed.emit(mana_available, mana_total)
	EventBus.hand_changed.emit()
	return true

## Corrotina: a UI chama sem await. Se houver alguém ligado a cascade_started,
## espera que a animação acabe (cascade_finished) antes de aplicar o dano.
func end_turn() -> void:
	if resolving or finished or pending_bottom > 0:
		return
	resolving = true
	var cascade := effects.build_attack_cascade()
	if not cascade.is_empty():
		if EventBus.cascade_started.get_connections().size() > 0:
			EventBus.cascade_started.emit(cascade)
			await EventBus.cascade_finished
		_apply_cascade(cascade)
	if enemy.hp <= 0:
		_finish(true)
		return
	_check_phase2()
	await _pause(0.45)
	if not counter_blocked():
		_enemy_phase()
	if GameState.player_hp <= 0:
		_finish(false)
		return
	if not silenced:
		enemy_abilities.on_turn_end(turn)
	_boss_end_of_turn()
	_climate_end_of_turn()
	_end_of_turn_cards()
	EventBus.hand_changed.emit()
	EventBus.turn_ended.emit(turn)
	if turn >= max_turns + extra_turns:
		_finish(false)
		return
	resolving = false
	next_turn()

## Fim do turno: missões de "sobreviver"/"ficar na mão" e Selo da Sabedoria.
func _end_of_turn_cards() -> void:
	for c in board.duplicate():
		if c.has_mission() and c.mission_trigger() == "attacks":
			c.mission_count += 1
			if c.mission_count >= c.mission_target():
				_transform(c)
	for h in deck.hand.duplicate():
		h.turns_in_hand += 1
		if h.has_mission() and h.mission_trigger() == "turns_in_hand":
			h.mission_count += 1
			if h.mission_count >= h.mission_target():
				_transform(h)
		if h.seal() == "wisdom":
			var fid := GameState.level_up_random_formation()
			if fid != "":
				EventBus.seal_triggered.emit(h, "wisdom")

## Bosses em 2 fases: abaixo de metade da vida o boss desperta (+ataque e uma fala); com o
## Selo Planar 8 ativa também a 2.ª regra.
func _check_phase2() -> void:
	if phase2 or not bool(enemy.get("boss", false)) or enemy.hp <= 0 or enemy.hp * 2 > enemy.max_hp:
		return
	phase2 = true
	enemy["attack"] = int(enemy.get("attack", 0)) + PHASE2_ATTACK
	EventBus.boss_phase2.emit(String((enemy.get("lines", {}) as Dictionary).get("phase2", "")))
	_check_ascension()

## Fim do turno do boss: o Devorador de Horizontes exila a criatura mais à direita.
func _boss_end_of_turn() -> void:
	if bool(rule.get("exile_rightmost", false)) and not board.is_empty() and not silenced:
		var c: CardInstance = board[board.size() - 1]
		board.erase(c)
		deck.to_exile(c)
		EventBus.creature_exiled.emit(c)

## Fim do turno do clima: Chuva de Meteoros fere a 3.ª criatura; Lua de Sangue vira as cartas de
## dupla face no fim das noites.
func _climate_end_of_turn() -> void:
	match climate:
		"meteor_rain":
			if board.size() >= 3:
				var c: CardInstance = board[2]
				c.damage += METEOR_DAMAGE
				EventBus.climate_hit.emit(c, METEOR_DAMAGE)
				if c.is_dead():
					kill_creature(c)
		"blood_moon":
			if is_night():
				var flips: Array[CardInstance] = []
				for c in deck.hand + board:
					if c.has_mission():
						flips.append(c)
				for c in flips:
					_transform(c)

## Selo Planar 8: com o boss desperto, ativa a 2.ª regra.
func _check_ascension() -> void:
	if ascended or not bool(enemy.get("boss", false)) or GameState.stake < 8:
		return
	var rule2: Dictionary = enemy.get("rule2", {})
	if rule2.is_empty():
		return
	ascended = true
	for k in rule2:
		rule[k] = rule2[k]
	hand_size = _hand_size_for_rule()
	if rule2.has("discards_minus"):
		discards_left = max(0, discards_left - int(rule2["discards_minus"]))
		EventBus.discards_changed.emit(discards_left)
	EventBus.boss_ascended.emit(String(enemy.get("rule2_text", "")))

# --- Fases internas ---

func _apply_cascade(cascade: Cascade) -> void:
	for s in cascade.steps:
		if s.grow > 0 and s.source_card != null:
			s.source_card.grow(s.grow)
	if cascade.gold != 0:
		GameState.add_gold(cascade.gold)
	var total := cascade.total()
	# Contadores para os contratos (antes do dano, contra a vida máxima atual).
	best_hit = maxi(best_hit, total)
	best_hit_pct = maxf(best_hit_pct, total * 100.0 / maxf(1.0, float(enemy.max_hp)))
	max_formations = maxi(max_formations, cascade.formation_ids.size())
	max_attackers = maxi(max_attackers, board.size())
	damage_enemy(total)
	if cascade.heal > 0:
		GameState.heal(cascade.heal)
	if cascade.self_damage > 0:
		lose_life(mini(cascade.self_damage, GameState.player_hp - 1))   # o pacto nunca mata
	# Selo Phyrexiano: cada ataque custa 10 Poder permanente; a 0, a carta sai da run.
	var used: Array[CardInstance] = []
	used.append_array(board)
	used.append_array(spells_this_turn)
	for c in used:
		if c.seal() == "phyrexian":
			c.grow(-PHYREXIAN_DECAY)
			EventBus.seal_triggered.emit(c, "phyrexian")
			if c.power() <= 0:
				_exile_from_run(c)

## A carta sai do baralho da run (a entrada fica marcada; GameState.purge_exiled apaga-a no fim).
func _exile_from_run(card: CardInstance) -> void:
	if not card.deck_entry.is_empty():
		card.deck_entry["exiled_run"] = true
	if card in board:
		board.erase(card)
	deck.hand.erase(card)
	deck.graveyard.erase(card)
	deck.library.erase(card)
	deck.to_exile(card)
	EventBus.card_exiled_run.emit(card)

func damage_enemy(amount: int) -> void:
	if amount <= 0 or enemy.hp <= 0:
		return
	enemy.hp = max(0, enemy.hp - amount)
	EventBus.damage_dealt.emit("enemy", amount)
	EventBus.enemy_hp_changed.emit(enemy.hp, enemy.max_hp)

func _enemy_phase() -> void:
	var dmg: int = enemy_attack()
	if dmg <= 0:
		return
	var blockers := creatures()
	# 1. Bloqueador seguro: a criatura mais robusta que sobreviva ao golpe.
	blockers.sort_custom(func(a, b): return a.remaining() > b.remaining())
	for b in blockers:
		if b.remaining() > dmg:
			b.damage += dmg
			EventBus.creature_blocked.emit(b, dmg)
			return
	# 2. Ninguém sobrevive: o jogador leva o dano, a não ser que seja letal.
	if GameState.player_hp > dmg:
		_damage_player(dmg)
		return
	# 3. Letal: as criaturas sacrificam-se, da mais fraca para a mais forte.
	blockers.sort_custom(func(a, b): return a.remaining() < b.remaining())
	for b in blockers:
		if dmg <= 0:
			break
		var absorbed: int = min(dmg, b.remaining())
		b.damage += absorbed
		dmg -= absorbed
		if b.is_dead():
			kill_creature(b)
	if dmg > 0:
		_damage_player(dmg)

func _damage_player(amount: int) -> void:
	lose_life(amount)

## Único ponto de perda de vida em batalha: conta para as missões e contratos e respeita o
## Coração de Vidro (um golpe mortal deixa-te com 1, uma vez por run).
func lose_life(amount: int) -> void:
	if amount <= 0:
		return
	if amount >= GameState.player_hp and GameState.can_death_save():
		amount = GameState.player_hp - 1
		GameState.use_death_save()
		EventBus.death_saved.emit()
		if amount <= 0:
			return
	life_lost += amount
	GameState.damage_player(amount)
	if not puzzle:
		GameState.bump_relic_counters("life_lost", amount)
	EventBus.damage_dealt.emit("player", amount)
	_check_missions("life_lost")

## Único ponto de saída de uma criatura do tabuleiro — usado pelo bloqueio e pelas habilidades.
func kill_creature(card: CardInstance) -> void:
	if not (card in board):
		return
	board.erase(card)
	deck.to_graveyard(card)
	EventBus.creature_died.emit(card)

func _pause(seconds: float) -> void:
	if is_inside_tree() and EventBus.cascade_started.get_connections().size() > 0:
		await get_tree().create_timer(Settings.dur(seconds)).timeout

# ---------------------------------------------------------------------------
# Gravar / retomar a meio da batalha. Chama-se to_dict() no início de cada turno (estado
# simples: sem feitiços lançados nem cascata a correr) e restore() ao continuar a run.
# ---------------------------------------------------------------------------

func to_dict() -> Dictionary:
	return {
		"enemy": enemy.duplicate(true),
		"rule": rule.duplicate(),
		"turn": turn,
		"max_turns": max_turns,
		"extra_turns": extra_turns,
		"extra_turn_granted": extra_turn_granted,
		"land_played_this_turn": land_played_this_turn,
		"ramp": ramp,
		"mana_total": mana_total,
		"mana_available": mana_available,
		"discards_left": discards_left,
		"discards_used": discards_used,
		"discarded_this_turn": discarded_this_turn,
		"drawn_this_turn": drawn_this_turn,
		"silenced": silenced,
		"enemy_vuln": enemy_vuln,
		"player_hp": GameState.player_hp,
		"mulligans": mulligans,
		"pending_bottom": pending_bottom,
		"actions_this_turn": actions_this_turn,
		"pw_used_this_turn": pw_used_this_turn,
		"pw_mult_add": pw_mult_add,
		"pw_mult_mul": pw_mult_mul,
		"pw_mult_per_attacker": pw_mult_per_attacker,
		"pw_shield": pw_shield,
		"cheap_hand": cheap_hand,
		"ascended": ascended,
		"climate": climate,
		"phase2": phase2,
		"life_lost": life_lost,
		"best_hit": best_hit,
		"best_hit_pct": best_hit_pct,
		"max_formations": max_formations,
		"max_attackers": max_attackers,
		"flashbacks_used": flashbacks_used,
		"lands_played": lands_played,
		"library": _zone_to_list(deck.library),
		"hand": _zone_to_list(deck.hand),
		"graveyard": _zone_to_list(deck.graveyard),
		"exile": _zone_to_list(deck.exile),
		"board": _zone_to_list(board),
	}

static func _zone_to_list(cards: Array[CardInstance]) -> Array:
	var out := []
	for c in cards:
		out.append({
			"id": c.data.id, "entry": c.entry_index, "damage": c.damage,
			"power_bonus": c.power_bonus, "toughness_bonus": c.toughness_bonus,
			"consumed": c.consumed, "exiled": c.exiled,
			"transformed": c.transformed, "mission_count": c.mission_count, "turns_in_hand": c.turns_in_hand,
		})
	return out

static func _card_from_state(cs: Dictionary) -> CardInstance:
	var id := String(cs.get("id", ""))
	var idx := int(cs.get("entry", -1))
	var entry: Dictionary = {}
	if idx >= 0 and idx < GameState.deck.size() and String(GameState.deck[idx].get("id", "")) == id:
		entry = GameState.deck[idx]
	var c := CardDB.new_instance(id, entry)
	if c == null:
		return null
	c.entry_index = idx if not entry.is_empty() else -1
	c.damage = int(cs.get("damage", 0))
	c.power_bonus = int(cs.get("power_bonus", 0))
	c.toughness_bonus = int(cs.get("toughness_bonus", 0))
	c.consumed = bool(cs.get("consumed", false))
	c.exiled = bool(cs.get("exiled", false))
	c.mission_count = int(cs.get("mission_count", 0))
	c.turns_in_hand = int(cs.get("turns_in_hand", 0))
	if bool(cs.get("transformed", false)):
		c.transform()
	return c

## Estado completo para "desfazer" dentro do turno: batalha + RNG + ouro + bónus permanentes.
func snapshot() -> Dictionary:
	var bonuses := []
	for e in GameState.deck:
		bonuses.append(e.duplicate(true))
	return {"battle": to_dict(), "rng": GameState.rng.state, "gold": GameState.gold, "bonuses": bonuses,
		"relics": GameState.relic_ids.duplicate(), "loyalty": GameState.planeswalker_loyalty(),
		"formation_levels": GameState.formation_levels.duplicate(), "player_hp": GameState.player_hp}

func restore_snapshot(snap: Dictionary) -> bool:
	if resolving or finished:
		return false
	var bonuses: Array = snap.get("bonuses", [])
	for i in min(bonuses.size(), GameState.deck.size()):
		var e: Dictionary = GameState.deck[i]
		for k in e.keys():
			if not (bonuses[i] as Dictionary).has(k):
				e.erase(k)
		for k in bonuses[i]:
			e[k] = bonuses[i][k]
	GameState.rng.state = int(snap.get("rng", GameState.rng.state))
	GameState.gold = int(snap.get("gold", GameState.gold))
	if not GameState.planeswalker.is_empty():
		GameState.planeswalker["loyalty"] = int(snap.get("loyalty", GameState.planeswalker_loyalty()))
	GameState.formation_levels = (snap.get("formation_levels", {}) as Dictionary).duplicate()
	EventBus.gold_changed.emit(GameState.gold)
	EventBus.planeswalker_changed.emit()
	return restore(snap.get("battle", {}))

## Repõe uma batalha gravada. Devolve false se os dados não prestarem (aí começa-se uma nova).
func restore(d: Dictionary) -> bool:
	var e: Dictionary = d.get("enemy", {})
	if e.is_empty() or int(d.get("turn", 0)) < 1:
		return false
	enemy = e.duplicate(true)
	enemy["hp"] = int(enemy.get("hp", 1))
	enemy["max_hp"] = int(enemy.get("max_hp", enemy["hp"]))
	enemy["attack"] = int(enemy.get("attack", 0))
	var abilities: Array = []
	for a in enemy.get("abilities", []):
		var ab: Dictionary = a.duplicate()
		if ab.has("value"):
			ab["value"] = int(ab["value"])
		if ab.has("n"):
			ab["n"] = int(ab["n"])
		abilities.append(ab)
	enemy["abilities"] = abilities
	rule = (d.get("rule", enemy.get("rule", {})) as Dictionary).duplicate()
	hand_size = _hand_size_for_rule()
	turn = int(d.get("turn", 1))
	max_turns = int(d.get("max_turns", GameState.turns_for_ante(GameState.ante)))
	extra_turns = int(d.get("extra_turns", 0))
	extra_turn_granted = bool(d.get("extra_turn_granted", false))
	land_played_this_turn = bool(d.get("land_played_this_turn", false))
	ramp = int(d.get("ramp", 0))
	mana_total = int(d.get("mana_total", turn + 1))
	mana_available = int(d.get("mana_available", mana_total))
	discards_left = int(d.get("discards_left", GameState.discards_for_battle()))
	discards_used = int(d.get("discards_used", 0))
	discarded_this_turn = int(d.get("discarded_this_turn", 0))
	drawn_this_turn = int(d.get("drawn_this_turn", 0))
	silenced = bool(d.get("silenced", false))
	enemy_vuln = float(d.get("enemy_vuln", 1.0))
	mulligans = int(d.get("mulligans", 0))
	pending_bottom = int(d.get("pending_bottom", 0))
	actions_this_turn = int(d.get("actions_this_turn", 0))
	pw_used_this_turn = bool(d.get("pw_used_this_turn", false))
	pw_mult_add = float(d.get("pw_mult_add", 0.0))
	pw_mult_mul = float(d.get("pw_mult_mul", 1.0))
	pw_mult_per_attacker = float(d.get("pw_mult_per_attacker", 0.0))
	pw_shield = bool(d.get("pw_shield", false))
	cheap_hand = bool(d.get("cheap_hand", false))
	ascended = bool(d.get("ascended", false))
	climate = String(d.get("climate", ""))
	phase2 = bool(d.get("phase2", false))
	life_lost = int(d.get("life_lost", 0))
	best_hit = int(d.get("best_hit", 0))
	best_hit_pct = float(d.get("best_hit_pct", 0.0))
	max_formations = int(d.get("max_formations", 0))
	max_attackers = int(d.get("max_attackers", 0))
	flashbacks_used = int(d.get("flashbacks_used", 0))
	lands_played = int(d.get("lands_played", 0))
	puzzle = false
	var empty: Array[Dictionary] = []
	deck = Deck.new(empty, GameState.rng)
	for cs in d.get("library", []):
		var c := _card_from_state(cs)
		if c:
			c.zone = CardInstance.Zone.DECK
			deck.library.append(c)
	for cs in d.get("hand", []):
		var c := _card_from_state(cs)
		if c:
			c.zone = CardInstance.Zone.HAND
			deck.hand.append(c)
	for cs in d.get("graveyard", []):
		var c := _card_from_state(cs)
		if c:
			c.zone = CardInstance.Zone.GRAVEYARD
			deck.graveyard.append(c)
	for cs in d.get("exile", []):
		var c := _card_from_state(cs)
		if c:
			c.zone = CardInstance.Zone.EXILE
			deck.exile.append(c)
	board.clear()
	for cs in d.get("board", []):
		var c := _card_from_state(cs)
		if c:
			c.zone = CardInstance.Zone.BOARD
			board.append(c)
	spells_this_turn.clear()
	effects = EffectResolver.new(self)
	enemy_abilities = EnemyAbilities.new(self)
	resolving = false
	finished = false
	GameState.player_hp = int(d.get("player_hp", GameState.player_max_hp))
	EventBus.battle_started.emit(enemy)
	EventBus.enemy_hp_changed.emit(enemy.hp, enemy.max_hp)
	EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)
	EventBus.mana_changed.emit(mana_available, mana_total)
	EventBus.discards_changed.emit(discards_left)
	EventBus.hand_changed.emit()
	EventBus.turn_started.emit(turn)
	return true

func _finish(victory: bool) -> void:
	if finished:
		return
	finished = true
	resolving = false
	if not puzzle:
		if victory:
			GameState.add_gold(GameState.battle_reward(turns_left(), turn))
			GameState.bump_relic_counters("battle_won")
			if bool(enemy.get("boss", false)) and not phase2:
				Stats.on_boss_no_phase2()
			if String(enemy.get("variant", "")) == "elite" and not bool(enemy.get("boss", false)):
				elite_relic = GameState.grant_elite_relic()
				Stats.on_elite()
		GameState.resolve_contract(self, victory)
		GameState.purge_exiled()
	EventBus.battle_ended.emit(victory)
