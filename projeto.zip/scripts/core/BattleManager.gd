class_name BattleManager
extends Node
## Regras de uma batalha. Sem UI — a cena Battle.tscn liga-se aos sinais do EventBus.
##
## Loop: N turnos. No turno N tens N+1 de mana (mais os terrenos jogados). A mão repõe-se até
## HAND_SIZE. Jogas criaturas (ficam no tabuleiro, máx. MAX_CREATURES), feitiços (contam no
## ataque deste turno) e terrenos (opcionais: +1 mana permanente; na mão dão bónus).
## Canalizar: botão + toque numa carta descarta-a e compra outra (DISCARDS por batalha).
## Ao terminar o turno TODAS as criaturas atacam através de uma CASCATA (Poder × Mult):
## criaturas → feitiços → formações → cartas na mão → relíquias.
## O inimigo responde com dano fixo: bloqueia a criatura mais robusta que SOBREVIVA ao golpe;
## se nenhuma sobreviver, o jogador leva o dano — a não ser que seja letal, e aí as criaturas
## sacrificam-se da mais fraca para a mais forte. Ganhas se a vida do inimigo chegar a 0.
## A vida do jogador atravessa a run (cura-se na loja). Bosses trazem uma "rule":
##   discards_minus N · hand_size N · creature_cost_plus N · no_formations · relics_off · color_silenced <cor>

const MAX_CREATURES := 5
const HAND_SIZE := 6
const DISCARDS := 3
const MAX_MANA := 10

var deck: Deck
var board: Array[CardInstance] = []        # criaturas, pela ordem em que foram jogadas
var spells_this_turn: Array[CardInstance] = []
var turn: int = 0
var max_turns: int = 5
var extra_turns: int = 0
var extra_turn_granted: bool = false
var land_played_this_turn: bool = false
var ramp: int = 0                           # terrenos jogados (+1 mana permanente cada)
var mana_total: int = 0
var mana_available: int = 0
var discards_left: int = DISCARDS
var discards_used: int = 0
var discarded_this_turn: int = 0
var drawn_this_turn: int = 0
var silenced: bool = false                  # habilidades do inimigo não disparam este turno
var enemy_vuln: float = 1.0                 # multiplicador de dano ao inimigo (maldições)
var resolving: bool = false                 # true enquanto a cascata/fase inimiga está a correr
var finished: bool = false

var enemy: Dictionary = {}   # {name, hp, max_hp, attack, text, abilities, boss, rule}
var rule: Dictionary = {}    # regra do boss (vazio nos inimigos normais)
var hand_size: int = HAND_SIZE
var effects: EffectResolver
var enemy_abilities: EnemyAbilities

func start(enemy_def: Dictionary) -> void:
	enemy = enemy_def.duplicate(true)
	rule = enemy.get("rule", {})
	hand_size = int(rule.get("hand_size", HAND_SIZE))
	max_turns = GameState.turns_for_ante(GameState.ante)
	deck = Deck.new(GameState.deck, GameState.rng)
	board.clear()
	spells_this_turn.clear()
	effects = EffectResolver.new(self)
	enemy_abilities = EnemyAbilities.new(self)
	turn = 0
	ramp = 0
	extra_turns = 0
	extra_turn_granted = false
	discards_left = max(1, GameState.discards_for_battle() - int(rule.get("discards_minus", 0)))
	discards_used = 0
	enemy_vuln = 1.0
	resolving = false
	finished = false
	if GameState.player_hp <= 0:
		GameState.player_hp = 1   # nunca começar uma batalha já morto
	EventBus.battle_started.emit(enemy)
	EventBus.enemy_hp_changed.emit(enemy.hp, enemy.max_hp)
	EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)
	effects.trigger_relics("battle_start")
	deck.draw_opening_hand(hand_size)
	next_turn()

func next_turn() -> void:
	turn += 1
	land_played_this_turn = false
	silenced = false
	discarded_this_turn = 0
	drawn_this_turn = 0
	spells_this_turn.clear()
	mana_total = min(MAX_MANA, turn + 1 + ramp)   # turno 1 = 2 de mana: há sempre algo para jogar
	mana_available = mana_total
	if turn > 1:
		deck.refill(hand_size)
	effects.trigger_relics("turn_start")
	EventBus.mana_changed.emit(mana_available, mana_total)
	EventBus.discards_changed.emit(discards_left)
	# turn_started vem depois das relíquias de início de turno: a UI grava a batalha neste momento.
	EventBus.turn_started.emit(turn)

# --- Consultas ---

func creatures() -> Array[CardInstance]:
	return board.duplicate()

## Todas as criaturas atacam, incluindo as jogadas neste turno.
func attackers() -> Array[CardInstance]:
	return board.duplicate()

## Pré-visualização do ataque atual (puro, não altera nada).
func preview_attack() -> Cascade:
	return effects.build_attack_cascade()

func turns_left() -> int:
	return max_turns + extra_turns - turn

## Quanto subiria o total do ataque se jogasses esta carta agora (ignora efeitos imediatos
## como compras de cartas — é uma aproximação, mas é a que o jogador precisa de ver).
func preview_play(card: CardInstance) -> int:
	if not can_play(card):
		return 0
	var base := effects.build_attack_cascade().total()
	var idx := deck.hand.find(card)
	if idx < 0:
		return 0
	var old_zone := card.zone
	deck.hand.remove_at(idx)
	if card.data.is_creature():
		card.zone = CardInstance.Zone.BOARD
		board.append(card)
	elif card.data.is_spell():
		card.zone = CardInstance.Zone.GRAVEYARD
		spells_this_turn.append(card)
	var total := effects.build_attack_cascade().total()
	if card.data.is_creature():
		board.erase(card)
	elif card.data.is_spell():
		spells_this_turn.erase(card)
	card.zone = old_zone
	deck.hand.insert(idx, card)
	return total - base

## Pré-visualização do contra-ataque (puro): quem bloqueia, se sobrevive, quanto levas tu.
func preview_enemy_phase() -> Dictionary:
	var dmg: int = int(enemy.get("attack", 0))
	var out := {"damage": dmg, "blocker": null, "survives": false, "player_damage": 0, "deaths": []}
	if dmg <= 0:
		return out
	var blockers := creatures()
	blockers.sort_custom(func(a, b): return a.remaining() > b.remaining())
	for b in blockers:
		if b.remaining() > dmg:
			out["blocker"] = b
			out["survives"] = true
			return out
	if GameState.player_hp > dmg:
		out["player_damage"] = dmg
		return out
	blockers.sort_custom(func(a, b): return a.remaining() < b.remaining())
	var left := dmg
	var deaths: Array = []
	for b in blockers:
		if left <= 0:
			break
		var absorbed: int = min(left, b.remaining())
		left -= absorbed
		if absorbed >= b.remaining():
			deaths.append(b)
	out["deaths"] = deaths
	out["player_damage"] = max(0, left)
	return out

## Habilidades do inimigo que vão disparar no fim deste turno (para mostrar a intenção).
func enemy_intent(for_turn: int) -> Array:
	var out: Array = []
	for a in enemy.get("abilities", []):
		var trig: String = a.get("trigger", "turn_end")
		if trig == "turn_end" or (trig == "every_n_turns" and for_turn % int(a.get("n", 1)) == 0):
			out.append(a)
	return out

## Reordenar criaturas (arrastar no tabuleiro): a ordem importa na cascata.
func move_creature(card: CardInstance, index: int) -> void:
	if resolving or finished or not (card in board):
		return
	board.erase(card)
	board.insert(clampi(index, 0, board.size()), card)

# --- Ações do jogador ---

func can_play(card: CardInstance) -> bool:
	if resolving or finished:
		return false
	if card.zone != CardInstance.Zone.HAND:
		return false
	if card.data.is_land():
		return not land_played_this_turn
	if card.data.is_creature() and board.size() >= MAX_CREATURES:
		return false
	return effects.cost_of(card) <= mana_available

func play(card: CardInstance) -> bool:
	if not can_play(card):
		return false
	deck.remove_from_hand(card)
	if card.data.is_land():
		land_played_this_turn = true
		ramp += 1
		mana_total = min(MAX_MANA, mana_total + 1)
		mana_available += 1
		deck.to_graveyard(card)   # o terreno "entra" no mundo; deixa de dar o bónus de mão
		EventBus.land_played.emit(card)
		effects.trigger_relics("land_played", card)
	else:
		mana_available -= effects.cost_of(card)
		if card.data.is_creature():
			card.zone = CardInstance.Zone.BOARD
			board.append(card)
			EventBus.creature_summoned.emit(card)
			effects.run_immediate(card, "on_play")
		else:
			card.zone = CardInstance.Zone.GRAVEYARD
			spells_this_turn.append(card)
			effects.run_immediate(card, "on_cast")
			if card.data.return_to_library:
				deck.to_library_bottom(card)
			else:
				deck.to_graveyard(card)   # volta ao grimório quando este se esgota (reciclagem)
			EventBus.spell_cast.emit(card)
	EventBus.card_played.emit(card)
	EventBus.mana_changed.emit(mana_available, mana_total)
	if enemy.hp <= 0:
		_finish(true)
	return true

func can_discard(card: CardInstance) -> bool:
	return not resolving and not finished and discards_left > 0 and card.zone == CardInstance.Zone.HAND

## Canalizar: descarta a carta e compra outra.
func discard(card: CardInstance) -> bool:
	if not can_discard(card):
		return false
	discards_left -= 1
	discards_used += 1
	discarded_this_turn += 1
	deck.remove_from_hand(card)
	deck.to_graveyard(card)
	effects.run_immediate(card, "on_discard")
	EventBus.card_discarded.emit(card)
	draw(1)
	EventBus.discards_changed.emit(discards_left)
	EventBus.hand_changed.emit()
	return true

func discard_random(count: int) -> void:
	for i in count:
		if deck.hand.is_empty():
			break
		var idx := GameState.rng.randi_range(0, deck.hand.size() - 1)
		var card: CardInstance = deck.hand[idx]
		deck.remove_from_hand(card)
		deck.to_graveyard(card)
		EventBus.card_discarded.emit(card)
	EventBus.hand_changed.emit()

func draw(count: int) -> void:
	var drawn := deck.draw(count)
	drawn_this_turn += drawn.size()

func grant_extra_turn() -> void:
	if extra_turn_granted:
		return
	extra_turn_granted = true
	extra_turns += 1
	EventBus.turn_started.emit(turn)   # para a UI atualizar "Turno x/y"

## Corrotina: a UI chama sem await. Se houver alguém ligado a cascade_started,
## espera que a animação acabe (cascade_finished) antes de aplicar o dano.
func end_turn() -> void:
	if resolving or finished:
		return
	resolving = true
	var cascade := effects.build_attack_cascade()
	if not cascade.is_empty():
		if EventBus.cascade_started.get_connections().size() > 0:
			EventBus.cascade_started.emit(cascade)
			await EventBus.cascade_finished
		_apply_cascade(cascade)
	if enemy.hp <= 0:
		_finish(true)
		return
	await _pause(0.45)
	_enemy_phase()
	if GameState.player_hp <= 0:
		_finish(false)
		return
	if not silenced:
		enemy_abilities.on_turn_end(turn)
	EventBus.hand_changed.emit()
	EventBus.turn_ended.emit(turn)
	if turn >= max_turns + extra_turns:
		_finish(false)
		return
	resolving = false
	next_turn()

# --- Fases internas ---

func _apply_cascade(cascade: Cascade) -> void:
	for s in cascade.steps:
		if s.grow > 0 and s.source_card != null:
			s.source_card.grow(s.grow)
	if cascade.gold != 0:
		GameState.add_gold(cascade.gold)
	damage_enemy(cascade.total())

func damage_enemy(amount: int) -> void:
	if amount <= 0 or enemy.hp <= 0:
		return
	enemy.hp = max(0, enemy.hp - amount)
	EventBus.damage_dealt.emit("enemy", amount)
	EventBus.enemy_hp_changed.emit(enemy.hp, enemy.max_hp)

func _enemy_phase() -> void:
	var dmg: int = enemy.get("attack", 0)
	if dmg <= 0:
		return
	var blockers := creatures()
	# 1. Bloqueador seguro: a criatura mais robusta que sobreviva ao golpe.
	blockers.sort_custom(func(a, b): return a.remaining() > b.remaining())
	for b in blockers:
		if b.remaining() > dmg:
			b.damage += dmg
			EventBus.creature_blocked.emit(b, dmg)
			return
	# 2. Ninguém sobrevive: o jogador leva o dano, a não ser que seja letal.
	if GameState.player_hp > dmg:
		_damage_player(dmg)
		return
	# 3. Letal: as criaturas sacrificam-se, da mais fraca para a mais forte.
	blockers.sort_custom(func(a, b): return a.remaining() < b.remaining())
	for b in blockers:
		if dmg <= 0:
			break
		var absorbed: int = min(dmg, b.remaining())
		b.damage += absorbed
		dmg -= absorbed
		if b.is_dead():
			kill_creature(b)
	if dmg > 0:
		_damage_player(dmg)

func _damage_player(amount: int) -> void:
	GameState.damage_player(amount)
	EventBus.damage_dealt.emit("player", amount)

## Único ponto de saída de uma criatura do tabuleiro — usado pelo bloqueio e pelas habilidades.
func kill_creature(card: CardInstance) -> void:
	if not (card in board):
		return
	board.erase(card)
	deck.to_graveyard(card)
	EventBus.creature_died.emit(card)

func _pause(seconds: float) -> void:
	if is_inside_tree() and EventBus.cascade_started.get_connections().size() > 0:
		await get_tree().create_timer(Settings.dur(seconds)).timeout

# ---------------------------------------------------------------------------
# Gravar / retomar a meio da batalha. Chama-se to_dict() no início de cada turno (estado
# simples: sem feitiços lançados nem cascata a correr) e restore() ao continuar a run.
# ---------------------------------------------------------------------------

func to_dict() -> Dictionary:
	return {
		"enemy": enemy.duplicate(true),
		"turn": turn,
		"max_turns": max_turns,
		"extra_turns": extra_turns,
		"extra_turn_granted": extra_turn_granted,
		"land_played_this_turn": land_played_this_turn,
		"ramp": ramp,
		"mana_total": mana_total,
		"mana_available": mana_available,
		"discards_left": discards_left,
		"discards_used": discards_used,
		"discarded_this_turn": discarded_this_turn,
		"drawn_this_turn": drawn_this_turn,
		"silenced": silenced,
		"enemy_vuln": enemy_vuln,
		"player_hp": GameState.player_hp,
		"library": _zone_to_list(deck.library),
		"hand": _zone_to_list(deck.hand),
		"graveyard": _zone_to_list(deck.graveyard),
		"board": _zone_to_list(board),
	}

static func _zone_to_list(cards: Array[CardInstance]) -> Array:
	var out := []
	for c in cards:
		out.append({
			"id": c.data.id, "entry": c.entry_index, "damage": c.damage,
			"power_bonus": c.power_bonus, "toughness_bonus": c.toughness_bonus,
			"consumed": c.consumed, "exiled": c.exiled,
		})
	return out

static func _card_from_state(cs: Dictionary) -> CardInstance:
	var id := String(cs.get("id", ""))
	var idx := int(cs.get("entry", -1))
	var entry: Dictionary = {}
	if idx >= 0 and idx < GameState.deck.size() and String(GameState.deck[idx].get("id", "")) == id:
		entry = GameState.deck[idx]
	var c := CardDB.new_instance(id, entry)
	if c == null:
		return null
	c.entry_index = idx if not entry.is_empty() else -1
	c.damage = int(cs.get("damage", 0))
	c.power_bonus = int(cs.get("power_bonus", 0))
	c.toughness_bonus = int(cs.get("toughness_bonus", 0))
	c.consumed = bool(cs.get("consumed", false))
	c.exiled = bool(cs.get("exiled", false))
	return c

## Estado completo para "desfazer" dentro do turno: batalha + RNG + ouro + bónus permanentes.
func snapshot() -> Dictionary:
	var bonuses := []
	for e in GameState.deck:
		bonuses.append({"power_bonus": int(e.get("power_bonus", 0)), "mult_bonus": float(e.get("mult_bonus", 0.0))})
	return {"battle": to_dict(), "rng": GameState.rng.state, "gold": GameState.gold, "bonuses": bonuses, "relics": GameState.relic_ids.duplicate()}

func restore_snapshot(snap: Dictionary) -> bool:
	if resolving or finished:
		return false
	var bonuses: Array = snap.get("bonuses", [])
	for i in min(bonuses.size(), GameState.deck.size()):
		GameState.deck[i]["power_bonus"] = int(bonuses[i].get("power_bonus", 0))
		GameState.deck[i]["mult_bonus"] = float(bonuses[i].get("mult_bonus", 0.0))
	GameState.rng.state = int(snap.get("rng", GameState.rng.state))
	GameState.gold = int(snap.get("gold", GameState.gold))
	EventBus.gold_changed.emit(GameState.gold)
	return restore(snap.get("battle", {}))

## Repõe uma batalha gravada. Devolve false se os dados não prestarem (aí começa-se uma nova).
func restore(d: Dictionary) -> bool:
	var e: Dictionary = d.get("enemy", {})
	if e.is_empty() or int(d.get("turn", 0)) < 1:
		return false
	enemy = e.duplicate(true)
	enemy["hp"] = int(enemy.get("hp", 1))
	enemy["max_hp"] = int(enemy.get("max_hp", enemy["hp"]))
	enemy["attack"] = int(enemy.get("attack", 0))
	var abilities: Array = []
	for a in enemy.get("abilities", []):
		var ab: Dictionary = a.duplicate()
		if ab.has("value"):
			ab["value"] = int(ab["value"])
		if ab.has("n"):
			ab["n"] = int(ab["n"])
		abilities.append(ab)
	enemy["abilities"] = abilities
	rule = enemy.get("rule", {})
	hand_size = int(rule.get("hand_size", HAND_SIZE))
	turn = int(d.get("turn", 1))
	max_turns = int(d.get("max_turns", GameState.turns_for_ante(GameState.ante)))
	extra_turns = int(d.get("extra_turns", 0))
	extra_turn_granted = bool(d.get("extra_turn_granted", false))
	land_played_this_turn = bool(d.get("land_played_this_turn", false))
	ramp = int(d.get("ramp", 0))
	mana_total = int(d.get("mana_total", turn + 1))
	mana_available = int(d.get("mana_available", mana_total))
	discards_left = int(d.get("discards_left", GameState.discards_for_battle()))
	discards_used = int(d.get("discards_used", 0))
	discarded_this_turn = int(d.get("discarded_this_turn", 0))
	drawn_this_turn = int(d.get("drawn_this_turn", 0))
	silenced = bool(d.get("silenced", false))
	enemy_vuln = float(d.get("enemy_vuln", 1.0))
	var empty: Array[Dictionary] = []
	deck = Deck.new(empty, GameState.rng)
	for cs in d.get("library", []):
		var c := _card_from_state(cs)
		if c:
			c.zone = CardInstance.Zone.DECK
			deck.library.append(c)
	for cs in d.get("hand", []):
		var c := _card_from_state(cs)
		if c:
			c.zone = CardInstance.Zone.HAND
			deck.hand.append(c)
	for cs in d.get("graveyard", []):
		var c := _card_from_state(cs)
		if c:
			c.zone = CardInstance.Zone.GRAVEYARD
			deck.graveyard.append(c)
	board.clear()
	for cs in d.get("board", []):
		var c := _card_from_state(cs)
		if c:
			c.zone = CardInstance.Zone.BOARD
			board.append(c)
	spells_this_turn.clear()
	effects = EffectResolver.new(self)
	enemy_abilities = EnemyAbilities.new(self)
	resolving = false
	finished = false
	GameState.player_hp = int(d.get("player_hp", GameState.player_max_hp))
	EventBus.battle_started.emit(enemy)
	EventBus.enemy_hp_changed.emit(enemy.hp, enemy.max_hp)
	EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)
	EventBus.mana_changed.emit(mana_available, mana_total)
	EventBus.discards_changed.emit(discards_left)
	EventBus.hand_changed.emit()
	EventBus.turn_started.emit(turn)
	return true

func _finish(victory: bool) -> void:
	if finished:
		return
	finished = true
	resolving = false
	if victory:
		GameState.add_gold(4 + GameState.ante + turns_left())
	EventBus.battle_ended.emit(victory)
