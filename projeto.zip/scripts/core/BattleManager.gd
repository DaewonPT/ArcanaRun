class_name BattleManager
extends Node
## Regras de uma batalha. Sem UI — a cena Battle.tscn liga-se aos sinais do EventBus.
##
## Loop: N turnos. Em cada turno: compra 1, joga até 1 terreno, gasta mana em criaturas/feitiços,
## ataca com as criaturas sem "summoning sickness". O inimigo responde com dano fixo ao jogador.
## Ganhas se a vida do inimigo chegar a 0 antes de os turnos acabarem.

var deck: Deck
var board: Array[CardInstance] = []
var turn: int = 0
var max_turns: int = 6
var land_played_this_turn: bool = false
var mana_total: int = 0
var mana_available: int = 0

var enemy: Dictionary = {}   # {name, hp, max_hp, attack, text, abilities}
var effects: EffectResolver
var enemy_abilities: EnemyAbilities

func start(enemy_def: Dictionary) -> void:
	enemy = enemy_def.duplicate()
	max_turns = GameState.turns_for_ante(GameState.ante)
	deck = Deck.new(GameState.deck_ids, GameState.rng)
	board.clear()
	effects = EffectResolver.new(self)
	enemy_abilities = EnemyAbilities.new(self)
	turn = 0
	EventBus.battle_started.emit(enemy)
	EventBus.enemy_hp_changed.emit(enemy.hp, enemy.max_hp)
	EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)
	deck.draw(5)
	next_turn()

func next_turn() -> void:
	turn += 1
	land_played_this_turn = false
	mana_available = mana_total
	for c in board:
		c.reset_turn()
	if turn > 1:
		deck.draw(1)
	EventBus.mana_changed.emit(mana_available, mana_total)
	EventBus.turn_started.emit(turn)
	effects.trigger("turn_start")

# --- Ações do jogador ---

func can_play(card: CardInstance) -> bool:
	if card.zone != CardInstance.Zone.HAND:
		return false
	if card.data.is_land():
		return not land_played_this_turn
	return effects.cost_of(card) <= mana_available

func play(card: CardInstance) -> bool:
	if not can_play(card):
		return false
	deck.remove_from_hand(card)
	if card.data.is_land():
		land_played_this_turn = true
		mana_total += 1
		mana_available += 1
		card.zone = CardInstance.Zone.BOARD
		board.append(card)
		EventBus.land_played.emit(card)
		effects.trigger("land_played", card)
	else:
		mana_available -= effects.cost_of(card)
		if card.data.is_creature():
			card.zone = CardInstance.Zone.BOARD
			board.append(card)
			EventBus.creature_summoned.emit(card)
			effects.trigger("creature_summoned", card)
		else:
			effects.resolve_spell(card)
			deck.to_graveyard(card)
	EventBus.card_played.emit(card)
	EventBus.mana_changed.emit(mana_available, mana_total)
	return true

func end_turn() -> void:
	_attack_phase()
	if enemy.hp <= 0:
		_finish(true)
		return
	_enemy_phase()
	if GameState.player_hp <= 0:
		_finish(false)
		return
	enemy_abilities.on_turn_end(turn)
	EventBus.hand_changed.emit()
	EventBus.turn_ended.emit(turn)
	if turn >= max_turns:
		_finish(false)
		return
	next_turn()

# --- Fases internas ---

func _attack_phase() -> void:
	var total := 0
	for c in board:
		if c.data.is_creature() and not c.summoning_sick:
			total += c.power()
	total = effects.modify_damage(total)
	if total > 0:
		enemy.hp = max(0, enemy.hp - total)
		EventBus.damage_dealt.emit("enemy", total)
		EventBus.enemy_hp_changed.emit(enemy.hp, enemy.max_hp)

func _enemy_phase() -> void:
	var dmg: int = enemy.get("attack", 0)
	# Criaturas absorvem dano: a mais robusta leva o golpe primeiro.
	var blockers := board.filter(func(c): return c.data.is_creature())
	blockers.sort_custom(func(a, b): return a.toughness() > b.toughness())
	for b in blockers:
		if dmg <= 0:
			break
		var absorbed: int = min(dmg, b.toughness() - b.damage)
		b.damage += absorbed
		dmg -= absorbed
		if b.is_dead():
			kill_creature(b)
	if dmg > 0:
		GameState.player_hp -= dmg
		EventBus.damage_dealt.emit("player", dmg)
		EventBus.player_hp_changed.emit(GameState.player_hp, GameState.player_max_hp)

## Único ponto de saída de uma criatura do tabuleiro — usado pelo bloqueio e pelas habilidades.
func kill_creature(card: CardInstance) -> void:
	if not (card in board):
		return
	board.erase(card)
	deck.to_graveyard(card)
	EventBus.creature_died.emit(card)

func _finish(victory: bool) -> void:
	if victory:
		GameState.add_gold(3 + GameState.ante)
	EventBus.battle_ended.emit(victory)
