class_name SaveIO
extends RefCounted
## 0.19.0: gravações seguras, num só sítio (as 300 do documento: 225–228 e 254).
##   - write_text/write_json: escrevem primeiro em «<caminho>.tmp», confirmam que o que ficou no disco é o
##     que se queria gravar e só depois trocam pelo ficheiro verdadeiro (um corte de energia a meio nunca
##     deixa um ficheiro pela metade — 225). Com keep_backup, a versão anterior fica em «<caminho>.bak» (226).
##   - read_json: se o ficheiro estiver estragado, abre a cópia .bak e marca `recovered` (227).
##   - Falta de espaço: antes de gravar vê-se o espaço livre; se a gravação falhar, avisa-se uma vez (228).
##   - Não volta a escrever um ficheiro com o mesmo texto que já lá está (254).

const MIN_FREE_BYTES := 1024 * 1024       # abaixo disto avisa (1 MB)
const BAK := ".bak"
const TMP := ".tmp"

static var _last_text: Dictionary = {}     # caminho → último texto gravado nesta sessão
static var recovered: Array[String] = []  # caminhos lidos a partir da cópia .bak nesta sessão
static var last_error: int = OK
static var _warned_space := false
static var _warned_fail := false
static var writes := 0                    # contadores (testes e modo programador)
static var skipped := 0

## Grava `text` em `path` sem nunca deixar o ficheiro a meio. Devolve true se ficou gravado.
static func write_text(path: String, text: String, keep_backup: bool = false) -> bool:
	if String(_last_text.get(path, "")) == text and FileAccess.file_exists(path):
		skipped += 1
		return true
	_check_space(text.length())
	var tmp := path + TMP
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		_fail(FileAccess.get_open_error())
		return false
	f.store_string(text)
	f.flush()
	var err := f.get_error()
	f.close()
	if err != OK or FileAccess.get_file_as_string(tmp) != text:
		DirAccess.remove_absolute(ProjectSettings.globalize_path(tmp))
		_fail(err if err != OK else ERR_FILE_CANT_WRITE)
		return false
	var abs_path := ProjectSettings.globalize_path(path)
	if keep_backup and FileAccess.file_exists(path):
		# Só se guarda como cópia uma versão que se leia (uma estragada não substitui a boa).
		if JSON.parse_string(FileAccess.get_file_as_string(path)) != null:
			DirAccess.copy_absolute(abs_path, abs_path + BAK)
	var abs_tmp := ProjectSettings.globalize_path(tmp)
	if DirAccess.rename_absolute(abs_tmp, abs_path) != OK:
		DirAccess.remove_absolute(abs_path)
		if DirAccess.rename_absolute(abs_tmp, abs_path) != OK:
			_fail(ERR_FILE_CANT_WRITE)
			return false
	_last_text[path] = text
	writes += 1
	last_error = OK
	return true

static func write_json(path: String, data, keep_backup: bool = false) -> bool:
	return write_text(path, JSON.stringify(data), keep_backup)

## Lê um JSON; se o ficheiro estiver estragado (ou faltar) e houver uma cópia .bak que se leia, usa-a.
## Devolve null se nenhum se ler.
static func read_json(path: String):
	if FileAccess.file_exists(path):
		var text := FileAccess.get_file_as_string(path)
		var parsed = JSON.parse_string(text)
		if parsed != null:
			_last_text[path] = text
			return parsed
	var bak := path + BAK
	if FileAccess.file_exists(bak):
		var parsed_bak = JSON.parse_string(FileAccess.get_file_as_string(bak))
		if parsed_bak != null:
			if not (path in recovered):
				recovered.append(path)
			return parsed_bak
	return null

## Apaga um ficheiro e as cópias dele (.bak e .tmp).
static func remove(path: String) -> void:
	for p in [path, path + BAK, path + TMP]:
		if FileAccess.file_exists(p):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(p))
	_last_text.erase(path)

## Esquece o que se sabe deste ficheiro (outro código mexeu nele).
static func forget(path: String) -> void:
	_last_text.erase(path)

## Espaço livre na pasta das gravações, em bytes (-1 se não se souber).
static func space_left() -> int:
	var d := DirAccess.open("user://")
	if d == null:
		return -1
	return int(d.get_space_left())

static func _check_space(bytes: int) -> void:
	if _warned_space:
		return
	var left := space_left()
	if left >= 0 and left < MIN_FREE_BYTES + bytes:
		_warned_space = true
		_notify(TranslationServer.translate("Pouco espaço no telemóvel: o jogo pode deixar de conseguir gravar."))

static func _fail(err: int) -> void:
	last_error = err
	if _warned_fail:
		return
	_warned_fail = true
	_notify(TranslationServer.translate("Não deu para gravar o jogo (falta espaço no telemóvel?). Liberta espaço e volta a tentar."))

static func _notify(text: String) -> void:
	var tree := Engine.get_main_loop() as SceneTree
	if tree == null or tree.root == null:
		return
	var router = tree.root.get_node_or_null("SceneRouter")
	if router != null and router.has_method("toast"):
		router.call_deferred("toast", text, 6.0)
	push_warning(text)
