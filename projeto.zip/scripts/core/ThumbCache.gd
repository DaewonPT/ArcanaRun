class_name ThumbCache
extends RefCounted
## 0.19.0 (236): as miniaturas das cartas (256×144, para a mão, a Arena, a Coleção e o Construtor) já não vão no APK
## (eram 4,7 MB): fazem-se no telemóvel a partir das ilustrações de 512 px — devagar, uma de cada vez, no arranque
## e quando uma carta aparece — e ficam em user://thumbs/. Enquanto não há miniatura, usa-se a ilustração grande.
## No projeto (computador e testes), as de assets/art/cards_256/ continuam a ser usadas.
## 248: as texturas feitas aqui ficam numa lista das mais recentes (no máximo KEEP); as outras soltam-se.

const DIR := "user://thumbs/cards_256/"
const SIZE := Vector2i(256, 144)
const KEEP := 80
const QUALITY := 0.82

static var _tex: Dictionary = {}          # id → ImageTexture (as mais recentes)
static var _order: Array[String] = []     # ordem de uso (a última no fim)
static var _queue: Array[String] = []
static var _task := -1
static var _task_id := ""
static var _img: Image
static var _all_queued := false
static var made := 0

## Faz falta? (no APK não há miniaturas; no projeto há.)
static func needed() -> bool:
	return ArtLib.count("card_thumb") == 0 and ArtLib.count("card") > 0

static func file_for(id: String) -> String:
	return DIR + id + ".webp"

static func has_file(id: String) -> bool:
	return FileAccess.file_exists(file_for(id))

## A miniatura já feita (null se ainda não há: fica pedida).
static func texture(id: String) -> Texture2D:
	if _tex.has(id):
		_order.erase(id)
		_order.append(id)
		return _tex[id]
	if has_file(id):
		var img := Image.load_from_file(file_for(id))
		if img != null and not img.is_empty():
			img.generate_mipmaps()
			var t := ImageTexture.create_from_image(img)
			_remember(id, t)
			return t
	request(id)
	return null

static func _remember(id: String, t: Texture2D) -> void:
	_tex[id] = t
	_order.append(id)
	while _order.size() > KEEP:
		_tex.erase(_order.pop_front())

static func request(id: String) -> void:
	if id != "" and id != _task_id and not (id in _queue) and not has_file(id):
		_queue.push_front(id)   # as que se veem passam à frente das do arranque

## No arranque: as que faltam todas na fila (vão-se fazendo devagar).
static func queue_all() -> void:
	if _all_queued or not needed():
		return
	_all_queued = true
	for id in CardDB.cards:
		if ArtLib.path("card", String(id)) != "" and not has_file(String(id)) and not (String(id) in _queue):
			_queue.append(String(id))

## Chamado pelo ArtLib.pump(): lê a ilustração no fio principal (a placa gráfica só deixa aqui) e encolhe e grava
## noutro fio. Devolve true se está a trabalhar.
static func pump() -> bool:
	if _task != -1:
		if not WorkerThreadPool.is_task_completed(_task):
			return true
		WorkerThreadPool.wait_for_task_completion(_task)
		_task = -1
		_task_id = ""
		_img = null
		made += 1
		return true
	if _queue.is_empty():
		return false
	var id: String = _queue.pop_front()
	if has_file(id):
		return false
	var full := ArtLib.texture("card", id)
	if full == null:
		return false
	var img := full.get_image()
	if img == null or img.is_empty():
		return false
	_img = img.duplicate()
	_task_id = id
	DirAccess.make_dir_recursive_absolute(DIR)
	_task = WorkerThreadPool.add_task(_shrink.bind(_img, file_for(id)), false, "thumb")
	return true

static func _shrink(img: Image, path: String) -> void:
	if img.is_compressed():
		img.decompress()
	img.convert(Image.FORMAT_RGB8)
	img.resize(SIZE.x, SIZE.y, Image.INTERPOLATE_LANCZOS)
	img.save_webp(path + ".tmp", true, QUALITY)
	DirAccess.rename_absolute(path + ".tmp", path)

## Faz já uma (testes).
static func make_now(id: String) -> bool:
	var full := ArtLib.texture("card", id)
	if full == null:
		return false
	var img := full.get_image()
	if img == null or img.is_empty():
		return false
	DirAccess.make_dir_recursive_absolute(DIR)
	_shrink(img.duplicate(), file_for(id))
	return has_file(id)

static func queued() -> int:
	return _queue.size()

static func kept() -> int:
	return _tex.size()

static func trim(keep: int) -> void:
	while _order.size() > keep:
		_tex.erase(_order.pop_front())

static func clear() -> void:
	_tex.clear()
	_order.clear()
	_queue.clear()
	_all_queued = false
	Storage.clear_dir(DIR)
