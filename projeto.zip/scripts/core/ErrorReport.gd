class_name ErrorReport
extends RefCounted
## 0.12.0: "Copiar relatório de erros" (Configurações → Jogo). Junta num texto a versão, o telemóvel,
## o estado da run e os últimos erros do registo do Godot (user://logs/godot.log e o da sessão
## anterior, que é o que interessa depois de o jogo fechar sozinho), para colar numa mensagem.

const LOG_DIR := "user://logs/"
const MAX_LINES := 60
## 0.19.0 (246): tempos do arranque (ms) — cards_ms, tr_ms (CardDB e traduções) e menu_ms (até ao 1.º frame do menu).
const BOOT_GOAL_MS := 3000
static var boot: Dictionary = {}

static func boot_line() -> String:
	if not boot.has("menu_ms"):
		return "Arranque: sem medição"
	return "Arranque: menu em %d ms (meta %d ms%s) · cartas %d ms · traduções %d ms" % [int(boot["menu_ms"]), BOOT_GOAL_MS,
		"" if int(boot["menu_ms"]) <= BOOT_GOAL_MS else ", ACIMA", int(boot.get("cards_ms", 0)), int(boot.get("tr_ms", 0))]

static func build() -> String:
	var lines: PackedStringArray = []
	lines.append("Zero-Sum — relatório de erros")
	lines.append("Versão: %s (code %d) · conteúdo %d" % [_version_name(), ContentUpdate.APP_VERSION_CODE, ContentUpdate.installed_version()])
	lines.append("Data: %s" % Time.get_datetime_string_from_system(false, true))
	var screen := DisplayServer.screen_get_size()
	lines.append("Sistema: %s %s · modelo: %s · ecrã %d×%d · escala %d %%" % [OS.get_name(), OS.get_version(), OS.get_model_name(), screen.x, screen.y, int(round(Settings.ui_scale * 100.0))])
	lines.append("Idioma: %s · dificuldade: %s · animações: %s" % [Settings.effective_language(), GameState.difficulty, Settings.anim_speed])
	if SceneRouter.thermal != null:
		lines.append(SceneRouter.thermal.report_line())   # 0.19.0 (223): os telemóveis que aquecem
	lines.append(boot_line())   # 0.19.0 (246)
	if Storage.crashed_before:
		lines.append("A sessão anterior fechou-se de repente (sem passar pelo fecho normal).")   # 0.19.0 (230)
	var slot := GameState.latest_slot()
	if slot > 0:
		var info := GameState.slot_info(slot)
		lines.append("Run gravada (espaço %d): %s · %s · ante %d" % [slot, String(info.get("mode", "")), String(info.get("what", "")), int(info.get("ante", 1))])
	var st := Stats.stats()
	lines.append("Runs: %d · vitórias: %d · conquistas: %d" % [int(st.get("runs", 0)), int(st.get("wins", 0)), Stats.unlocked_count()])
	lines.append("")
	var errors := recent_errors()
	if errors.is_empty():
		lines.append("Sem erros no registo.")
	else:
		lines.append("Últimos erros:")
		lines.append_array(errors)
	return "\n".join(lines)

## A versão vem das Novidades (data/news.json), que o SmokeTest confirma bater certo com a do APK.
static func _version_name() -> String:
	if not CardDB.news.is_empty() and CardDB.news[0] is Dictionary:
		return String(CardDB.news[0].get("version", "?"))
	return "?"

## Linhas de erro/aviso dos registos (o atual e o anterior), com a linha "at:" a seguir.
static func recent_errors() -> PackedStringArray:
	var out: PackedStringArray = []
	for path in _log_files():
		var text := FileAccess.get_file_as_string(path)
		if text == "":
			continue
		var all := text.split("\n")
		var picked: PackedStringArray = []
		var i := 0
		while i < all.size():
			var l := all[i].strip_edges()
			if l.begins_with("ERROR") or l.begins_with("SCRIPT ERROR") or l.begins_with("WARNING") or l.begins_with("USER ERROR") or l.begins_with("USER SCRIPT ERROR"):
				if not _ignored(l):
					picked.append(l)
					if i + 1 < all.size() and all[i + 1].strip_edges().begins_with("at:"):
						picked.append("   " + all[i + 1].strip_edges())
			i += 1
		if not picked.is_empty():
			out.append("[%s]" % path.get_file())
			var start := maxi(0, picked.size() - MAX_LINES)
			out.append_array(picked.slice(start))
	return out

## Avisos que aparecem sempre e não dizem nada (áudio sem placa de som, fontes ainda por importar).
static func _ignored(l: String) -> bool:
	for bit in ["audio_driver", "ALSA", "All audio drivers failed", "ObjectDB instances leaked", "resources still in use"]:
		if l.contains(bit):
			return true
	return false

## O registo desta sessão (godot.log) e o mais recente das anteriores (godot<data>.log).
static func _log_files() -> PackedStringArray:
	var out: PackedStringArray = []
	var dir := DirAccess.open(LOG_DIR)
	if dir == null:
		return out
	var older: Array = []
	for f in dir.get_files():
		if not f.ends_with(".log"):
			continue
		if f == "godot.log":
			continue
		older.append(f)
	older.sort()
	if not older.is_empty():
		out.append(LOG_DIR + String(older[older.size() - 1]))
	if FileAccess.file_exists(LOG_DIR + "godot.log"):
		out.append(LOG_DIR + "godot.log")
	return out
