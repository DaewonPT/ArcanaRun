class_name DeckCode
extends RefCounted
## 0.12.0: códigos de baralho do Construtor, para partilhar um baralho por mensagem.
## Formato: "ZS1-" + base64 de "nome|12.45x2.78…" (o número de cada carta, "x2" para duas cópias).
## Ao colar, as cartas que não existem, as maldições, as fichas e as que ainda estão bloqueadas ficam de
## fora (e contam-se em "skipped"); as regras do Construtor (máx. 30 cartas, 2 cópias) também se aplicam.

const PREFIX := "ZS1-"
const MAX_CARDS := 30
const MAX_COPIES := 2

static func encode(deck_name: String, cards: Array) -> String:
	var counts := {}
	var order: Array[String] = []
	for id in cards:
		var key := String(id)
		if not counts.has(key):
			order.append(key)
		counts[key] = int(counts.get(key, 0)) + 1
	order.sort()
	var parts: PackedStringArray = []
	for id in order:
		var short := id.trim_prefix("c") if id.begins_with("c") and id.substr(1).is_valid_int() else id
		var n := int(counts[id])
		parts.append(short + ("x%d" % n if n > 1 else ""))
	var clean_name := deck_name.strip_edges().replace("|", "/").left(24)
	return PREFIX + Marshalls.utf8_to_base64(clean_name + "|" + ".".join(parts))

## {"ok", "name", "cards": Array[String], "skipped": int, "error"}.
static func decode(code: String) -> Dictionary:
	var out := {"ok": false, "name": "", "cards": [] as Array[String], "skipped": 0, "error": ""}
	var t := code.strip_edges().replace(" ", "").replace("\n", "")
	var at := t.find(PREFIX)
	if at < 0:
		out["error"] = "Isto não é um código de baralho do Zero-Sum."
		return out
	var payload := t.substr(at + PREFIX.length())
	var re := RegEx.create_from_string("^[A-Za-z0-9+/]+=*$")
	if payload.length() < 4 or re.search(payload) == null:
		out["error"] = "O código está incompleto ou estragado."
		return out
	var raw := Marshalls.base64_to_utf8(payload)
	var bar := raw.find("|")
	if raw == "" or bar < 0:
		out["error"] = "O código está incompleto ou estragado."
		return out
	out["name"] = raw.left(bar).strip_edges().left(24)
	var cards: Array[String] = []
	var skipped := 0
	for part in raw.substr(bar + 1).split(".", false):
		var bits := part.split("x")
		var short := bits[0]
		var n := int(bits[1]) if bits.size() > 1 and bits[1].is_valid_int() else 1
		var id := ("c%03d" % int(short)) if short.is_valid_int() else short
		var cd := CardDB.get_card(id)
		if cd == null or cd.token or cd.is_curse() or not CardDB.is_available(cd):
			skipped += maxi(1, n)
			continue
		for i in clampi(n, 1, MAX_COPIES):
			if cards.size() >= MAX_CARDS:
				skipped += 1
				continue
			cards.append(id)
		if n > MAX_COPIES:
			skipped += n - MAX_COPIES
	if cards.is_empty():
		out["error"] = "O código não tem cartas que possas usar."
		out["skipped"] = skipped
		return out
	out["ok"] = true
	out["cards"] = cards
	out["skipped"] = skipped
	return out
