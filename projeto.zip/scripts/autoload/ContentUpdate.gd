extends Node
## Atualizações de conteúdo sem APK novo: cartas, baralhos, relíquias, inimigos, campanha, eventos,
## conquistas e traduções (só JSON, nunca código).
##
## Ao arrancar lê BASE_URL/versao.txt (GitHub Pages), verifica a assinatura ECDSA P-256 / SHA-256
## com a chave pública embutida, e se a versão do conteúdo (c) for maior do que a instalada e a
## app for recente o suficiente (min), descarrega cada ficheiro para user://content/<caminho>,
## confirmando o SHA-256. CardDB e Settings lêem de user://content/ só quando esse conteúdo é mais
## novo do que o que vem no APK: depois de instalar um APK novo, o conteúdo descarregado para a
## versão anterior é ignorado e apagado (senão a app nova correria com os dados antigos).
## Ferramenta do lado de fora: tools/make_manifest.py (com a chave privada, que fica com o Paulo).

signal finished(updated: bool, version: int)

const BASE_URL := "https://daewonpt.github.io/zerosum-updates/"
const CONTENT_DIR := "user://content/"
const VERSION_FILE := "user://content/version.txt"
const APP_VERSION_CODE := 10
const BUNDLED_CONTENT_VERSION := 4   # versão do conteúdo que vem dentro deste APK
const ALLOWED_PREFIXES := ["data/", "i18n/"]
const PUBLIC_KEY_PEM := """-----BEGIN PUBLIC KEY-----
MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEcl9yrgOYDG9D0mPISUj3Wvu21jHD
9wFHtJ29i4FQEfEe8w9dtzuKsD4/zR4fmdKi4esxA+S1y2ia2GdfeG+wsg==
-----END PUBLIC KEY-----
"""

var checked := false
var busy := false
var last_note := ""

func _ready() -> void:
	clear_if_stale()

## Caminho a usar para um recurso: a versão descarregada, se existir e for mais nova do que o
## conteúdo do APK; senão a do APK.
static func resolve(res_path: String) -> String:
	if downloaded_version() <= BUNDLED_CONTENT_VERSION:
		return res_path
	var rel := res_path.trim_prefix("res://")
	var local := CONTENT_DIR + rel
	if FileAccess.file_exists(local):
		return local
	return res_path

## Versão do conteúdo descarregado completo (0 se não houver ou se a última descarga falhou).
static func downloaded_version() -> int:
	if not FileAccess.file_exists(VERSION_FILE):
		return 0
	return int(FileAccess.get_file_as_string(VERSION_FILE).strip_edges())

static func installed_version() -> int:
	return max(BUNDLED_CONTENT_VERSION, downloaded_version())

## Apaga o conteúdo descarregado que já não serve: mais antigo do que o do APK (por exemplo, o da
## 0.8.0 num telemóvel que instalou a 0.9.x) ou restos de uma descarga que não chegou ao fim.
static func clear_if_stale() -> void:
	if downloaded_version() <= BUNDLED_CONTENT_VERSION:
		clear_downloaded()

## Verifica (uma vez por sessão) se há conteúdo novo. Nunca bloqueia; falhas são silenciosas.
func check() -> void:
	if checked or busy or OS.has_feature("headless"):
		return
	checked = true
	busy = true
	var text := await _get_text(BASE_URL + "versao.txt")
	if text == "":
		busy = false
		finished.emit(false, installed_version())
		return
	var manifest := parse_manifest(text)
	if manifest.is_empty() or not verify(manifest):
		busy = false
		finished.emit(false, installed_version())
		return
	var version := int(manifest.get("c", 0))
	if version <= installed_version() or int(manifest.get("min", 0)) > APP_VERSION_CODE:
		busy = false
		finished.emit(false, installed_version())
		return
	# Até a descarga acabar, o conteúdo descarregado deixa de contar: se falhar a meio, a próxima
	# abertura usa o do APK (nunca uma mistura de versões) e volta a tentar.
	if FileAccess.file_exists(VERSION_FILE):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(VERSION_FILE))
	var ok := await _download_all(manifest)
	if ok:
		DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(CONTENT_DIR))
		var f := FileAccess.open(VERSION_FILE, FileAccess.WRITE)
		if f:
			f.store_string(str(version))
		last_note = String(manifest.get("notes", {}).get(Settings.effective_language(), manifest.get("notes", {}).get("pt", "")))
		CardDB.reload()
		SceneRouter.toast(tr("Conteúdo atualizado (v%d)") % version + (": " + last_note if last_note != "" else ""), 4.0)
	busy = false
	finished.emit(ok, installed_version())

# --- Manifesto ---

## Devolve {"c", "min", "notes": {lang: text}, "files": [{sha, size, path}], "body", "sig"} ou {} se mal formado.
static func parse_manifest(text: String) -> Dictionary:
	var lines := text.split("\n", false)
	if lines.is_empty() or lines[0].strip_edges() != "ZSUPD 1":
		return {}
	var out := {"c": 0, "min": 0, "notes": {}, "files": [], "sig": ""}
	var body_lines: Array[String] = []
	for raw in lines:
		var line := raw.strip_edges()
		if line == "":
			continue
		if line.begins_with("sig "):
			out["sig"] = line.substr(4).strip_edges()
			break
		body_lines.append(line)
		var parts := line.split(" ", false)
		match parts[0]:
			"c":
				out["c"] = int(parts[1]) if parts.size() > 1 else 0
			"min":
				out["min"] = int(parts[1]) if parts.size() > 1 else 0
			"n":
				if parts.size() > 2:
					out["notes"][parts[1]] = line.substr(line.find(parts[1]) + parts[1].length() + 1).strip_edges()
			"f":
				if parts.size() >= 4:
					var path := String(parts[3])
					var allowed := false
					for prefix in ALLOWED_PREFIXES:
						if path.begins_with(prefix):
							allowed = true
					if not allowed or path.contains("..") or not path.ends_with(".json"):
						return {}
					out["files"].append({"sha": String(parts[1]).to_lower(), "size": int(parts[2]), "path": path})
	out["body"] = "\n".join(PackedStringArray(body_lines)) + "\n"
	if out["sig"] == "":
		return {}
	return out

static func verify(manifest: Dictionary) -> bool:
	var key := CryptoKey.new()
	if key.load_from_string(PUBLIC_KEY_PEM, true) != OK:
		return false
	var ctx := HashingContext.new()
	ctx.start(HashingContext.HASH_SHA256)
	ctx.update(String(manifest["body"]).to_utf8_buffer())
	var digest := ctx.finish()
	var sig := Marshalls.base64_to_raw(String(manifest["sig"]))
	return Crypto.new().verify(HashingContext.HASH_SHA256, digest, sig, key)

static func sha256_hex(data: PackedByteArray) -> String:
	var ctx := HashingContext.new()
	ctx.start(HashingContext.HASH_SHA256)
	ctx.update(data)
	return ctx.finish().hex_encode()

# --- Rede ---

func _get_text(url: String) -> String:
	var bytes := await _get_bytes(url)
	return bytes.get_string_from_utf8() if not bytes.is_empty() else ""

func _get_bytes(url: String) -> PackedByteArray:
	var req := HTTPRequest.new()
	req.timeout = 20.0
	add_child(req)
	if req.request(url) != OK:
		req.queue_free()
		return PackedByteArray()
	var result: Array = await req.request_completed
	req.queue_free()
	if int(result[0]) != HTTPRequest.RESULT_SUCCESS or int(result[1]) != 200:
		return PackedByteArray()
	return result[3]

func _download_all(manifest: Dictionary) -> bool:
	for f in manifest["files"]:
		var local := CONTENT_DIR + String(f["path"])
		# Já temos este ficheiro exato? (mesmo sha) — salta.
		if FileAccess.file_exists(local) and sha256_hex(FileAccess.get_file_as_bytes(local)) == String(f["sha"]):
			continue
		var bytes := await _get_bytes(BASE_URL + "f/" + String(f["sha"]))
		if bytes.is_empty() or bytes.size() != int(f["size"]) or sha256_hex(bytes) != String(f["sha"]):
			return false
		DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(local.get_base_dir()))
		var out := FileAccess.open(local, FileAccess.WRITE)
		if out == null:
			return false
		out.store_buffer(bytes)
	return true

## Apaga o conteúdo descarregado (volta ao que vem no APK).
static func clear_downloaded() -> void:
	var dir := DirAccess.open(CONTENT_DIR)
	if dir == null:
		return
	for sub in ["data", "i18n"]:
		var d := DirAccess.open(CONTENT_DIR + sub)
		if d:
			for f in d.get_files():
				d.remove(f)
	if FileAccess.file_exists(VERSION_FILE):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(VERSION_FILE))
