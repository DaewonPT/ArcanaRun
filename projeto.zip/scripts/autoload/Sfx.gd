extends Node
## Sons. Os quatro de base são gerados em memória (o "blip" da cascata sobe meio-tom a cada ativação
## consecutiva — o truque do Balatro — via pitch_scale). 0.12.0: mais 21 efeitos, sintetizados por
## tools/make_audio.py em assets/audio/sfx/*.wav (comprar carta, jogar, Terreno, ouro, cura, escudo,
## relíquia, vitória, derrota, conquista, boss, transformar, baralhar, palavra-chave, prisão, canalizar,
## morte, recusa, subir de nível, tique, voltar). Muitos tocam sozinhos, a ouvir o EventBus.

const RATE := 22050
const POOL_SIZE := 12
## Volume (dB) e intervalo mínimo entre repetições (s) de cada efeito.
const NAMED := {
	"draw": [-15.0, 0.07], "play": [-9.0, 0.05], "land": [-6.0, 0.1], "coin": [-9.0, 0.12], "heal": [-7.0, 0.3],
	"shield": [-8.0, 0.2], "relic": [-11.0, 0.0], "victory": [-2.0, 0.5], "defeat": [-3.0, 0.5], "unlock": [-6.0, 0.25],
	"boss": [-3.0, 1.0], "transform": [-6.0, 0.2], "shuffle": [-8.0, 0.3], "keyword": [-9.0, 0.12], "jail": [-6.0, 0.3],
	"channel": [-10.0, 0.08], "death": [-8.0, 0.08], "deny": [-9.0, 0.15], "level_up": [-5.0, 0.3], "tick": [-13.0, 0.05],
	"back": [-12.0, 0.05], "reward": [-4.0, 0.4],
}

var _blip: AudioStreamWAV
var _select: AudioStreamWAV
var _boom: AudioStreamWAV
var _hit: AudioStreamWAV
var _named: Dictionary = {}       # nome → AudioStream
var _last_play: Dictionary = {}   # nome → ms do último toque
var _players: Array[AudioStreamPlayer] = []
var _next := 0
var _last_gold := -1
var _last_hp := -1

func _ready() -> void:
	_blip = _tone(261.63, 0.16, "triangle", 14.0)
	_select = _tone(420.0, 0.06, "sine", 40.0)
	_boom = _sweep(150.0, 38.0, 0.38, "saw")
	_hit = _sweep(220.0, 90.0, 0.18, "square")
	for n in NAMED:
		var path := "res://assets/audio/sfx/%s.wav" % n
		if ResourceLoader.exists(path):
			_named[n] = load(path)
	for i in POOL_SIZE:
		var p := AudioStreamPlayer.new()
		p.bus = "Sfx"   # volume controlado em Configurações
		add_child(p)
		_players.append(p)
	EventBus.card_drawn.connect(func(_c): draw())
	EventBus.card_played.connect(_on_card_played)
	EventBus.land_played.connect(func(_c): land())
	EventBus.card_discarded.connect(func(_c): channel())
	EventBus.creature_died.connect(func(_c): death())
	EventBus.card_transformed.connect(func(_c): transform())
	EventBus.keyword_granted.connect(func(_c, _k): keyword())
	EventBus.creature_jailed.connect(func(_c): jail())
	EventBus.board_shuffled.connect(shuffle)
	EventBus.shield_hit.connect(func(_a): shield())
	EventBus.achievement_unlocked.connect(func(_id): unlock())
	# 0.16.1 (V62): os cosméticos têm o seu próprio som, quando o aviso aparece (SceneRouter); o resto, já.
	EventBus.content_unlocked.connect(func(k, _id): if not (String(k) in COSMETIC_KINDS): unlock())
	EventBus.gold_changed.connect(_on_gold)
	EventBus.player_hp_changed.connect(_on_player_hp)
	EventBus.battle_started.connect(func(_e): _last_hp = GameState.player_hp)

func blip(step: int) -> void:
	# step 0 = dó central; cada passo sobe 1 meio-tom (até 2 oitavas e meia).
	_play(_blip, pow(2.0, minf(step, 30) / 12.0), -4.0)

## Um passo da cascata: as relíquias tocam um sino (mesma escala que sobe), o resto o blip de sempre.
func cascade_step(step: int, kind: String) -> void:
	if kind == "relic" and _named.has("relic"):
		_play(_named["relic"], 0.5 * pow(2.0, minf(step, 30) / 12.0), float(NAMED["relic"][0]))
	else:
		blip(step)

func select() -> void:
	_play(_select, 1.0, -10.0)

func boom() -> void:
	_play(_boom, 1.0, 0.0)

func hit() -> void:
	_play(_hit, 1.0, -6.0)

# --- 0.12.0: efeitos com nome ---

func draw() -> void: named("draw", randf_range(0.94, 1.08))
func play_card() -> void: named("play", randf_range(0.95, 1.05))
func land() -> void: named("land")
func coin() -> void: named("coin")
func heal() -> void: named("heal")
func shield() -> void: named("shield")
func victory() -> void: named("victory")
func defeat() -> void: named("defeat")
func unlock() -> void: named("unlock")
## 0.16.1 (V62): cosmético novo (harpa a subir e sinos).
func reward() -> void: named("reward")
const COSMETIC_KINDS := ["back", "frame", "mat", "effect"]
func boss() -> void: named("boss")
func transform() -> void: named("transform")
func shuffle() -> void: named("shuffle")
func keyword() -> void: named("keyword")
func jail() -> void: named("jail")
func channel() -> void: named("channel")
func death() -> void: named("death", randf_range(0.9, 1.1))
func deny() -> void: named("deny")
func level_up() -> void: named("level_up")
func tick() -> void: named("tick")
func back() -> void: named("back")

## Toca um efeito pelo nome (com o volume da tabela; repetições demasiado seguidas não tocam).
## Se o ficheiro não existir, cai num dos sons de base.
func named(n: String, pitch: float = 1.0) -> bool:
	var spec: Array = NAMED.get(n, [-8.0, 0.0])
	var now := Time.get_ticks_msec()
	if now - int(_last_play.get(n, -100000)) < int(float(spec[1]) * 1000.0):
		return false
	_last_play[n] = now
	if _named.has(n):
		_play(_named[n], pitch, float(spec[0]))
	elif n in ["victory", "unlock", "level_up", "coin", "heal"]:
		boom()
	elif n in ["deny", "defeat", "death", "jail"]:
		hit()
	else:
		select()
	return true

func _on_card_played(card) -> void:
	if card is CardInstance and (card as CardInstance).data != null and (card as CardInstance).data.is_land():
		return   # o Terreno tem o seu som (land_played)
	play_card()

## Ouro ganho (não gasto) numa cena da run: moeda.
func _on_gold(amount: int) -> void:
	var before := _last_gold
	_last_gold = amount
	if before < 0 or amount <= before or not _in_run_scene():
		return
	coin()

## Vida que sobe a meio de uma batalha: cura.
func _on_player_hp(current: int, _max_hp: int) -> void:
	var before := _last_hp
	_last_hp = current
	if before >= 0 and current > before and _in_run_scene():
		heal()

func _in_run_scene() -> bool:
	var tree := get_tree()
	if tree == null or tree.current_scene == null:
		return false
	var path := tree.current_scene.scene_file_path
	for bit in ["/battle/", "/shop/", "/loot/", "/event/", "/map/", "/tower/"]:
		if path.contains(bit):
			return true
	return false

func _play(stream: AudioStream, pitch: float, volume_db: float) -> void:
	var p := _players[_next]
	_next = (_next + 1) % POOL_SIZE
	p.stream = stream
	p.pitch_scale = pitch
	p.volume_db = volume_db
	p.play()

# --- Síntese ---

func _tone(freq: float, seconds: float, shape: String, decay: float) -> AudioStreamWAV:
	var n := int(RATE * seconds)
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var t := float(i) / RATE
		var s := _wave(fmod(t * freq, 1.0), shape)
		var env := exp(-t * decay)
		data.encode_s16(i * 2, int(clampf(s * env, -1.0, 1.0) * 32767.0))
	return _wav(data)

func _sweep(f_start: float, f_end: float, seconds: float, shape: String) -> AudioStreamWAV:
	var n := int(RATE * seconds)
	var data := PackedByteArray()
	data.resize(n * 2)
	var phase := 0.0
	for i in n:
		var t := float(i) / RATE
		var k := t / seconds
		var freq := f_start * pow(f_end / f_start, k)   # glissando exponencial
		phase = fmod(phase + freq / RATE, 1.0)
		var env := 1.0 - k
		data.encode_s16(i * 2, int(clampf(_wave(phase, shape) * env * 0.8, -1.0, 1.0) * 32767.0))
	return _wav(data)

func _wave(phase: float, shape: String) -> float:
	match shape:
		"triangle":
			return 4.0 * absf(phase - 0.5) - 1.0
		"saw":
			return 2.0 * phase - 1.0
		"square":
			return 1.0 if phase < 0.5 else -1.0
	return sin(TAU * phase)

func _wav(data: PackedByteArray) -> AudioStreamWAV:
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = RATE
	wav.stereo = false
	wav.data = data
	return wav
