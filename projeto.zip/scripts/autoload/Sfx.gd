extends Node
## Sons gerados em memória (sem ficheiros de áudio). O "blip" da cascata sobe meio-tom
## a cada ativação consecutiva — o truque do Balatro — via pitch_scale.

const RATE := 22050
const POOL_SIZE := 8

var _blip: AudioStreamWAV
var _select: AudioStreamWAV
var _boom: AudioStreamWAV
var _hit: AudioStreamWAV
var _players: Array[AudioStreamPlayer] = []
var _next := 0

func _ready() -> void:
	_blip = _tone(261.63, 0.16, "triangle", 14.0)
	_select = _tone(420.0, 0.06, "sine", 40.0)
	_boom = _sweep(150.0, 38.0, 0.38, "saw")
	_hit = _sweep(220.0, 90.0, 0.18, "square")
	for i in POOL_SIZE:
		var p := AudioStreamPlayer.new()
		p.bus = "Master"
		add_child(p)
		_players.append(p)

func blip(step: int) -> void:
	# step 0 = dó central; cada passo sobe 1 meio-tom (até 2 oitavas e meia).
	_play(_blip, pow(2.0, minf(step, 30) / 12.0), -4.0)

func select() -> void:
	_play(_select, 1.0, -10.0)

func boom() -> void:
	_play(_boom, 1.0, 0.0)

func hit() -> void:
	_play(_hit, 1.0, -6.0)

func _play(stream: AudioStreamWAV, pitch: float, volume_db: float) -> void:
	var p := _players[_next]
	_next = (_next + 1) % POOL_SIZE
	p.stream = stream
	p.pitch_scale = pitch
	p.volume_db = volume_db
	p.play()

# --- Síntese ---

func _tone(freq: float, seconds: float, shape: String, decay: float) -> AudioStreamWAV:
	var n := int(RATE * seconds)
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var t := float(i) / RATE
		var s := _wave(fmod(t * freq, 1.0), shape)
		var env := exp(-t * decay)
		data.encode_s16(i * 2, int(clampf(s * env, -1.0, 1.0) * 32767.0))
	return _wav(data)

func _sweep(f_start: float, f_end: float, seconds: float, shape: String) -> AudioStreamWAV:
	var n := int(RATE * seconds)
	var data := PackedByteArray()
	data.resize(n * 2)
	var phase := 0.0
	for i in n:
		var t := float(i) / RATE
		var k := t / seconds
		var freq := f_start * pow(f_end / f_start, k)   # glissando exponencial
		phase = fmod(phase + freq / RATE, 1.0)
		var env := 1.0 - k
		data.encode_s16(i * 2, int(clampf(_wave(phase, shape) * env * 0.8, -1.0, 1.0) * 32767.0))
	return _wav(data)

func _wave(phase: float, shape: String) -> float:
	match shape:
		"triangle":
			return 4.0 * absf(phase - 0.5) - 1.0
		"saw":
			return 2.0 * phase - 1.0
		"square":
			return 1.0 if phase < 0.5 else -1.0
	return sin(TAU * phase)

func _wav(data: PackedByteArray) -> AudioStreamWAV:
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = RATE
	wav.stereo = false
	wav.data = data
	return wav
