extends Node
## Barramento global de sinais. Tudo o que é "aconteceu X" passa por aqui,
## para que UI, lógica e efeitos de cartas não precisem de se conhecer.

# --- Run ---
signal run_started
signal run_ended(victory: bool)
signal ante_started(ante: int)

# --- Batalha ---
signal battle_started(enemy: Dictionary)
signal battle_ended(victory: bool)
signal turn_started(turn: int)
signal turn_ended(turn: int)
signal card_drawn(card: CardInstance)
signal card_played(card: CardInstance)
signal land_played(card: CardInstance)
signal creature_summoned(card: CardInstance)
signal creature_died(card: CardInstance)
signal creature_blocked(card: CardInstance, amount: int)
signal damage_dealt(target: String, amount: int)   # target: "enemy" | "player"
signal enemy_ability_used(enemy_name: String, action: String)
signal hand_changed
signal mana_changed(available: int, total: int)
signal enemy_hp_changed(current: int, max_hp: int)
signal player_hp_changed(current: int, max_hp: int)

# --- Cascata de ataque (Poder × Mult) ---
signal cascade_started(cascade: Cascade)   # o BattleManager pede à UI para animar
signal cascade_finished                     # a UI avisa que acabou; só então o dano é aplicado

# --- Loja / economia ---
signal gold_changed(amount: int)
signal shop_opened(offers: Array)
signal card_bought(card_id: String)
signal relic_gained(relic_id: String)
