extends Node
## Barramento global de sinais. Tudo o que é "aconteceu X" passa por aqui,
## para que UI, lógica e efeitos de cartas não precisem de se conhecer.

# --- Run ---
signal run_started
signal run_ended(victory: bool)
signal ante_started(ante: int)

# --- Batalha ---
signal battle_started(enemy: Dictionary)
signal battle_ended(victory: bool)
signal turn_started(turn: int)
signal turn_ended(turn: int)
signal card_drawn(card: CardInstance)
signal card_played(card: CardInstance)
signal land_played(card: CardInstance)
signal spell_cast(card: CardInstance)
signal creature_summoned(card: CardInstance)
signal creature_died(card: CardInstance)
signal creature_blocked(card: CardInstance, amount: int)
signal card_discarded(card: CardInstance)
signal card_grew(card: CardInstance, amount: int)
signal damage_dealt(target: String, amount: int)   # target: "enemy" | "player"
signal enemy_ability_used(enemy_name: String, action: String)
signal hand_changed
signal mana_changed(available: int, total: int)
signal discards_changed(left: int)
signal enemy_hp_changed(current: int, max_hp: int)
signal player_hp_changed(current: int, max_hp: int)
signal mulligan_taken(count: int)                     # mão nova; faltam `count` cartas para o fundo
signal card_transformed(card: CardInstance)           # dupla face: virou
signal card_flashback(card: CardInstance)             # feitiço lançado do cemitério (Recapitular)
signal seal_triggered(card: CardInstance, seal: String)
signal formation_leveled(id: String, level: int)      # Selo da Sabedoria
signal planeswalker_changed                           # lealdade / habilidade usada
signal card_exiled_run(card: CardInstance)            # saiu da run (Phyrexiano a 0, infeção)
signal boss_ascended(text: String)                    # Selo Planar 8: 2.ª regra ativada

# --- Cascata de ataque (Poder × Mult) ---
signal cascade_started(cascade: Cascade)   # o BattleManager pede à UI para animar
signal cascade_finished                     # a UI avisa que acabou; só então o dano é aplicado

# --- Loja / economia ---
signal gold_changed(amount: int)
signal shop_opened(offers: Array)
signal card_bought(card_id: String)
signal relic_gained(relic_id: String)
signal relics_changed                       # venda / reordenação de relíquias
signal achievement_unlocked(id: String)
