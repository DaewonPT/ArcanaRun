extends Node
## Barramento global de sinais. Tudo o que é "aconteceu X" passa por aqui,
## para que UI, lógica e efeitos de cartas não precisem de se conhecer.

# --- Cenas ---
signal scene_changed(key: String)   # 0.12.0: o SceneRouter vai mudar de cena (a música troca de faixa)

# --- Run ---
signal run_started
signal run_ended(victory: bool)
signal ante_started(ante: int)

# --- Batalha ---
signal battle_started(enemy: Dictionary)
signal battle_ended(victory: bool)
signal turn_started(turn: int)
signal turn_ended(turn: int)
signal card_drawn(card: CardInstance)
signal card_played(card: CardInstance)
signal land_played(card: CardInstance)
signal spell_cast(card: CardInstance)
signal creature_summoned(card: CardInstance)
signal creature_died(card: CardInstance)
signal creature_blocked(card: CardInstance, amount: int)
signal card_discarded(card: CardInstance)
signal card_grew(card: CardInstance, amount: int)
signal damage_dealt(target: String, amount: int)   # target: "enemy" | "player"
signal enemy_ability_used(enemy_name: String, action: String)
signal hand_changed
signal mana_changed(available: int, total: int)
signal discards_changed(left: int)
signal enemy_hp_changed(current: int, max_hp: int)
signal player_hp_changed(current: int, max_hp: int)
signal mulligan_taken(count: int)                     # mão nova; faltam `count` cartas para o fundo
signal card_transformed(card: CardInstance)           # dupla face: virou
signal card_flashback(card: CardInstance)             # feitiço lançado do cemitério (Recapitular)
signal seal_triggered(card: CardInstance, seal: String)
signal formation_leveled(id: String, level: int)      # Selo da Sabedoria
signal planeswalker_changed                           # lealdade / habilidade usada
signal card_exiled_run(card: CardInstance)            # saiu da run (Corrupção a 0, infeção)
signal boss_ascended(text: String)                    # Selo Planar 8: 2.ª regra ativada
signal boss_phase2(line: String)                      # boss abaixo de metade da vida: desperta (+ataque)
signal death_saved                                    # Coração de Vidro salvou o jogador
signal contract_resolved(success: bool, text: String)
signal creature_exiled(card: CardInstance)            # Devorador de Horizontes: vai para o exílio da batalha
signal climate_hit(card: CardInstance, amount: int)   # Chuva de Meteoros
# 0.10.0
signal token_created(card: CardInstance)              # Ficha criada na Arena
signal enchantment_played(card: CardInstance)
signal card_kicked(card: CardInstance)                # jogada com Reforço
signal reaction_window(options: Array)                # o BattleManager pergunta se queres reagir (UI)
signal reaction_done(card)                            # a UI responde: CardInstance ou null (não reagir)
signal reaction_played(card: CardInstance)
signal shield_hit(amount: int)                        # o escudo do inimigo travou parte do ataque
signal minions_changed(left: int)                     # lacaios do inimigo ainda de pé
signal content_unlocked(kind: String, id: String)     # conquista desbloqueou carta/relíquia/planeswalker/cosmético

# --- Cascata de ataque (Poder × Mult) ---
signal cascade_started(cascade: Cascade)   # o BattleManager pede à UI para animar
signal cascade_finished                     # a UI avisa que acabou; só então o dano é aplicado
## 0.13.0: a UI começou a mostrar a cascata (a música cresce). Ninguém fora da UI se liga a cascade_started:
## o BattleManager usa as ligações a esse sinal para saber se há alguém a animar (senão resolve logo).
signal cascade_presented(cascade: Cascade)

# --- Loja / economia ---
signal gold_changed(amount: int)
signal shop_opened(offers: Array)
signal card_bought(card_id: String)
signal relic_gained(relic_id: String)
signal relics_changed                       # venda / reordenação de relíquias
signal achievement_unlocked(id: String)
# 0.11.0
signal card_stolen(card)            # Ladra de Grimórios: carta tirada da mão (exílio até ao fim da batalha)
signal creature_mirrored(card)      # Espelho Vivo: criatura copiada (no ataque seguinte não dá Poder base)
# 0.12.0
signal keyword_granted(card, keyword: String)   # uma carta deu uma palavra-chave a outra (até ao fim da batalha)
signal landfall(land)                           # jogaste um Terreno: as Chegadas de Terreno disparam
signal creature_jailed(card)                    # Carcereiro: a criatura mais forte fica presa no ataque seguinte
signal board_shuffled                            # Ilusionista: a ordem da Arena foi baralhada
# 0.13.0
signal enemy_attacking(damage: int, blocker)       # o contra-ataque vai acertar (blocker: CardInstance ou null)
signal run_saved(slot: int)                         # a run foi gravada (aviso "Guardado em Jogo N")
signal consumables_changed                          # poções e pergaminhos mudaram (comprados, usados, deitados fora)
signal consumable_used(id: String)                  # usaste um consumível na batalha
signal relic_stolen(id: String)                     # Ladra de Relíquias: desligou uma relíquia até ao fim da batalha
signal boss_phase(index: int, text: String)         # Hidra Tricéfala: despertou mais uma fase (1, 2…)
# 0.15.0
signal energy_changed(amount: int)                  # Energia (⚡) da batalha mudou
signal crown_changed(has: bool)                     # ganhaste ou perdeste a Coroa
signal phyrexian_paid(card, life: int)              # pagaste Mana de Sangue com vida
signal creature_persisted(card)                     # Persistir: a criatura morreu e voltou à Arena
signal veteran_star(card, stars: int)               # Veteranos: a criatura ganhou uma estrela
signal overkill_gold(amount: int)                   # Excesso: ouro pelo dano a mais no golpe final
signal ritual_changed(ritual: Dictionary)           # o ritual do boss começou, avançou ou acabou ({} = nenhum)
signal ritual_resolved(text: String)                # o ritual aconteceu
signal ritual_broken                                # um golpe forte interrompeu o ritual
