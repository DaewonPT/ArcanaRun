extends Node
## Estado da run atual (o "save" em memória), progresso da campanha e gravação em disco.
## Não contém lógica de batalha — isso vive em BattleManager.
##
## Uma run são 8 antes em 5 atos (I: 1–2, II: 3–4 com boss, III: 5–6, IV: 7–8 com o boss final,
## V: modo infinito). Em cada ante o mapa oferece uma batalha (Batedor ou Guarda; boss nos antes
## múltiplos de 4) e depois uma paragem (Loja ou outra: evento, acampamento, Fonte de Mana,
## Altar Profano, Mercador Cego, Quadro de Contratos, Tribunal dos Deuses). Os Selos Planares
## (1–8) são a dificuldade progressiva por baralho; Fácil/Normal/Difícil é o modificador global.
## 0.9.0: cada ato tem um Clima Planar (data/climates.json); depois de um boss que não acaba a run
## há um Baú de Espólio com relíquias de boss (espaço à parte, `boss_relics`); um contrato ativo
## (data/contracts.json) é avaliado no fim da batalha seguinte.
## 0.10.0: Vales comprados na loja (`vouchers`), Némesis (rival que aparece nos antes 3, 5 e 7 no lugar
## da Elite, cada vez mais forte), Desafios (mode "challenge", regras fixas em challenges.json),
## História (mode "saga", capítulos de saga.json), resumo da run (`run_log`) e Modo Treino.
## 0.12.0: 6 espaços de gravação (cada um com uma run em curso e um nome que se pode mudar; o
## progresso é comum a todos), Run Rápida (mode "quick": 4 antes, conta só para os talentos e as
## estatísticas), histórico das últimas runs e cópias de segurança do progresso.

const LEGACY_RUN_SAVE := "user://run.json"   # até à 0.11.0 havia só uma run gravada
const SLOT_COUNT := 6
const RUN_NAME_MAX := 24
const PROGRESS_SAVE := "user://progress.json"   # perfil 1; os outros perfis usam progress_path()
const PROGRESS_BACKUPS := 3                  # cópias de segurança do progresso (progress.bak1..3.json)
const HISTORY_MAX := 30                      # runs guardadas no histórico

const DIFFICULTIES := ["facil", "normal", "dificil", "pesadelo"]
const DIFFICULTY_NAMES := {"facil": "Fácil", "normal": "Normal", "dificil": "Difícil", "pesadelo": "Pesadelo"}
const DIFFICULTY_HP := {"facil": 0.7, "normal": 1.0, "dificil": 1.5, "pesadelo": 2.0}
const DIFFICULTY_EXTRA_TURNS := {"facil": 1, "normal": 0, "dificil": 0, "pesadelo": 0}   # Fácil: 6 turnos por batalha
const DIFFICULTY_DISCARDS := {"facil": 4, "normal": 3, "dificil": 2, "pesadelo": 2}
const DIFFICULTY_ATTACK := {"pesadelo": 1}   # 0.13.0 Pesadelo: os inimigos atacam +1 (e têm o dobro da vida)
const MAX_RELICS := 5
const BOSS_EVERY := 4                 # antes 4, 8, 12… têm boss; o 8 é o boss final
const GUARD_HP_MULT := 1.25
const GUARD_GOLD := 4
const ELITE_HP_MULT := 1.6          # Elite: +60 % de vida, +2 de ataque, +6 ouro e uma relíquia garantida
const ELITE_ATTACK := 2
const ELITE_GOLD := 6
const ELITE_CHANCE := 0.6           # probabilidade de haver nó de Elite num ante (a partir do 2.º, fora dos bosses)
const ARENA_HP_MULT := 1.5          # 0.12.0 Arena: +50 % de vida e +2 de ataque, 3 turnos; vencer dá relíquia e ouro
const ARENA_TURNS := 3
const ARENA_GOLD := 10
const ARENA_LOSS := 5               # perder na Arena custa vida, não a run
## 0.18.0 (24, 25): nós de batalha especiais no mapa — batalhas com outro objetivo (Emboscada, Cerco, Fuga) e a
## Dupla (dois inimigos). A partir do ante 2 (a Dupla do 3), fora dos bosses: no lugar da Guarda quando já há
## Elite ou Némesis, senão como 3.ª opção.
const SPECIAL_CHANCE := 0.5
const AMBUSH_GOLD_PCT := 50          # Emboscada: o inimigo ataca primeiro (antes do teu 1.º turno); +50 % de ouro
const SIEGE_HEAL_PCT := 5.0          # Cerco: no fim de cada turno o inimigo cura 5 % da vida máxima…
const SIEGE_TURNS := 1               # …mas tens +1 turno…
const SIEGE_GOLD := 3                # …e +3 ouro
const ESCAPE_TURNS := 4              # Fuga: basta sobreviver 4 turnos…
const ESCAPE_HP_MULT := 2.0          # …a um inimigo mais forte (vida ×2, +2 de ataque);
const ESCAPE_ATTACK := 2
const ESCAPE_KILL_PCT := 50          # vencê-lo mesmo assim dá +50 % de ouro
const PAIR_FROM := 3                 # Dupla: a partir do ante 3…
const PAIR_HP_PCT := 0.6             # …dois inimigos com 60 % da vida de um Batedor cada…
const PAIR_GOLD := 5                 # …e +5 ouro
const SPECIAL_BATTLES := ["ambush", "siege", "escape", "pair"]
const ACT_NAMES := ["I", "II", "III", "IV", "V"]
const STAKES := [
	{"name": "Iniciado", "text": "Dificuldade padrão."},
	{"name": "Taxa da Corte", "text": "As batalhas contra Batedores não dão ouro base."},
	{"name": "Fome de Mana", "text": "A vida dos bosses sobe 35% a partir do ante 3."},
	{"name": "Decreto de Silêncio", "text": "Máximo de 2 canalizações por batalha."},
	{"name": "Marca Eterna", "text": "As relíquias compradas na loja não podem ser vendidas."},
	{"name": "Infeção de Óleo", "text": "As cartas dos boosters podem vir infetadas: Poder a dobrar, mas exilam-se ao fim de 3 utilizações."},
	{"name": "Eclipse da Mente", "text": "A mão passa a 5 cartas."},
	{"name": "Ascensão Mítica", "text": "Abaixo de metade da vida, os bosses ativam uma 2.ª regra."},
]
const STOP_NODES := ["shop", "event", "rest", "spring", "altar", "merchant", "contracts", "tribunal"]
const LOOT_CHOICES := 3
const INTEREST_CAP := 5
const NEMESIS_ANTES := {3: 1, 5: 2, 7: 3}   # ante → nível da Némesis
## 0.12.0: marcos do Infinito — vencer o boss destes antes dá ouro, pontos de talento e um cosmético.
const ENDLESS_MILESTONES := {
	12: {"gold": 15, "talent": 3, "unlock": {"type": "mat", "id": "infinity"}},
	16: {"gold": 25, "talent": 5, "unlock": {"type": "frame", "id": "starlight"}},
	20: {"gold": 40, "talent": 8, "unlock": {"type": "effect", "id": "supernova"}},
}
const MEDALS := ["", "bronze", "bronze", "bronze", "silver", "silver", "silver", "gold", "gold"]
## 0.13.0
const CONSUMABLE_SLOTS := 2          # poções e pergaminhos que se podem levar ao mesmo tempo
const AFFIX_GOLD := 2                # ouro a mais por cada afixo de uma Elite vencida
const AFFIX_TWO_FROM := 6            # a partir deste ante as Elites têm 2 afixos
const ENDLESS_CURSE_EVERY := 4       # no Infinito, uma maldição global nova de 4 em 4 antes
const RELIC_THIEF_GOLD := 5          # vencer a Ladra de Relíquias devolve-as com este ouro a mais

var rng := RandomNumberGenerator.new()
var seed_value: int = 0

# --- Run ---
var ante: int = 1
var max_ante: int = 8
var gold: int = 4
var player_max_hp: int = 20
var player_hp: int = 20
var difficulty: String = "normal"
var free_mode: bool = false          # Modo Livre: não conta para a campanha
var mode: String = "campaign"        # "campaign" | "free" | "draft"
var stake: int = 1                   # Selo Planar (1–8)
var last_victory: bool = false       # a última run terminou em vitória (para o ecrã final)
var interest_ante: int = 0           # último ante em que a loja pagou juros
var seen_events: Array[String] = []  # eventos já mostrados nesta run
var pending_event: String = ""       # evento gravado a meio (para retomar)
var current_enemy_id: String = ""    # inimigo da batalha atual (para o ecrã final)
var pair_enemy_id: String = ""       # 0.18.0 (25): o 2.º inimigo de uma Dupla (para o Bestiário)
var endless: bool = false            # modo infinito: continuar depois do ante 8
var planeswalker: Dictionary = {}    # {"id", "loyalty"} ou vazio
var formation_levels: Dictionary = {} # id da formação → nível (Selo da Sabedoria)
var relic_locked: Array[String] = [] # relíquias compradas na loja com o Selo Planar 5 (não se vendem)
var map_plan: Dictionary = {}        # ante (String) → {"battle": [...], "stop": [...]}
var map_choice: Dictionary = {}      # escolhas do ante atual: {"battle": "scout"|"guard"|"boss", "stop": "..."}
var map_history: Dictionary = {}     # ante (String) → escolhas feitas (para o mapa mostrar o caminho)
var map_phase: String = "battle"     # o que o mapa pede a seguir: "battle" ou "stop"
var puzzle_id: String = ""           # quebra-cabeças em curso ("" = nenhum)
var boss_relics: Array[String] = []  # relíquias de boss (Baú de Espólio), fora do limite de 5
var loot_offer: Array[String] = []   # ofertas do Baú de Espólio pendente (para retomar)
var climates: Dictionary = {}        # chave do ato ("1".."4", "E<n>" no infinito) → id do clima
var contract: Dictionary = {}        # contrato ativo (definição de contracts.json) ou vazio
var death_save_used: bool = false    # Coração de Vidro já salvou nesta run
var relic_counters: Dictionary = {}  # relíquias que escalam: id → contador desde que a tens
var interlude_key: String = ""       # último ato (chave do clima) cujo interlúdio já se mostrou
# 0.10.0
var vouchers: Array[String] = []     # Vales comprados nesta run
var nemesis_id: String = ""          # rival desta run ("" = ainda não escolhido)
var nemesis_beaten: Array[int] = []  # níveis da Némesis já vencidos nesta run
var challenge_id: String = ""        # Desafio em curso ("" = nenhum)
var saga_id: String = ""             # capítulo da História em curso ("" = nenhum)
var run_talents: Dictionary = {}    # 0.11.0: efeito → valor dos talentos em vigor nesta run (vazio nos Desafios)
var last_talent_points: int = 0      # pontos de talento ganhos na última run (ecrã do fim)
var last_first_bonus: int = 0        # 0.19.0 (89): desses, os do prémio da 1.ª vez (baralho / Selo Planar)
var last_fragments: int = 0          # 0.19.0 (90): fragmentos ganhos na última run
var deck_log: Array = []             # 0.19.0 (56): o que aconteceu ao baralho nesta run (log_deck)
var econ: Dictionary = {}            # 0.19.0 (secção 3): estado da economia da run (Economy.gd)
var run_log: Dictionary = {}         # resumo: {"damage_by_ante": {ante: dano}, "card_dmg": {id: dano}, "relic_dmg": {id: dano}, "best_hit": n}
var training: Dictionary = {}        # Modo Treino: {"hand": [ids], "relics": [ids], "mana": n}
var last_reward_text: String = ""    # recompensa especial da última batalha (Némesis), para a UI

# --- Baralho persistente: uma entrada por carta, com bónus permanentes ---
var deck: Array[Dictionary] = []     # {"id": "c001", "power_bonus": 0, "mult_bonus": 0.0, "seal": "", ...}
var deck_def: Dictionary = {}        # definição do baralho escolhido (decks.json)
var relic_ids: Array[String] = []

# --- Progresso da campanha (persistente) ---
var progress: Dictionary = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
var last_unlocks: Array[String] = []   # nomes desbloqueados na última run (para o ecrã final)

# --- Retoma ---
var pending_battle: Dictionary = {}    # batalha gravada a meio (BattleManager.to_dict), consumida pela cena Battle
var saved_scene: String = "battle"     # onde a run gravada estava: "battle", "shop", "event" ou "map"

# --- Espaços de gravação (0.12.0) ---
var current_slot: int = 1              # espaço onde a run em curso se grava (1–6)
var slot_confirmed: bool = false       # o jogador escolheu este espaço para um jogo novo (ou ficou livre no fim da run)
var run_name: String = ""              # nome dado pelo jogador a esta run ("" = "Jogo N")
var launch_mode: String = ""           # o que o menu pediu ao abrir a Campanha: "" ou "quick" (Run Rápida)
var run_abandoned: bool = false        # a run que está a acabar foi abandonada (para o histórico)
var bosses_seen: Array[String] = []    # 0.12.0: bosses já enfrentados nesta run (não se repetem)
var milestones_claimed: Array[int] = [] # 0.12.0: marcos do Infinito já ganhos nesta run
var last_milestone_text: String = ""   # recompensa do marco do Infinito acabado de ganhar (para a UI)
var blessings: Array[String] = []      # 0.12.0: Bênçãos do Santuário (relíquias escondidas, para o resto da run)
var next_enemy_weaken: int = 0         # 0.12.0: % de vida a menos no inimigo da próxima batalha (Alquimista Louco)
var arena_battle: bool = false         # 0.12.0: a batalha atual é a da Arena (paragem do mapa)
var restored_backup: int = 0           # >0: o progresso estava estragado e veio da cópia n.º N (aviso no menu)
# 0.13.0
var consumables: Array[String] = []    # poções e pergaminhos (consumables.json), no máximo consumable_slots()
var stolen_relics: Array[String] = []  # Ladra de Relíquias: desligadas até ao fim da batalha (gravam-se com ela)
var endless_curses: Array[String] = [] # maldições globais do Infinito (endless_curses.json)
var pact_offer: Array[String] = []     # 0.17.0 Pactos do Infinito: as maldições por escolher (vazio = nenhuma)
var pending_later: Array = []          # consequências de eventos: [{"ante": N, "effects": {...}, "text": "…", "title": "…"}]
var later_notes: Array[String] = []    # o que acabou de acontecer entre antes (o mapa mostra uma vez)
var chain_id: String = ""              # 0.17.0: história em cadeia desta run ("" = nenhuma)
var chain_part: int = 0                # … partes já vividas (0–3)
var chain_tags: Array[String] = []     # … escolhas feitas (mudam as opções das partes seguintes)
var chain_last_act: int = 0            # … ato da última parte (a seguinte só aparece num ato mais à frente)
var tower_phase: String = "climb"      # 0.17.0 Torre: "climb" (a caminho da batalha) | "reward" (prémio por escolher)
var tower_offer: Dictionary = {}       # … o prémio do andar: {"cards": [ids], "relics": [ids], "boss": bool, "heal": n}
var rush_list: Array[String] = []      # 0.17.0 Corrida de Bosses: os bosses, por ordem (o ante é o n.º do boss)
var rush_turns: Array[int] = []        # … turnos que cada boss já vencido levou
var last_side_record: bool = false     # a Torre que acabou bateu o recorde (para o ecrã do fim)
var boss_clean: bool = false           # o último boss vencido nunca chegou a despertar (3.ª estrela dos Desafios)
var last_stars: int = 0                # estrelas ganhas no Desafio que acabou (para o ecrã do fim)
var last_loss: Dictionary = {}         # 0.15.0 «Porque perdi?»: BattleManager.loss_report() da batalha perdida
var _slot_cache: Dictionary = {}       # espaço → {"mtime", "info"} (para o menu não ler os ficheiros sempre)
var _last_run_text: Dictionary = {}    # 0.19.0 (254): espaço → a última gravação (sem a hora), para não regravar igual

func _ready() -> void:
	_rotate_backups()
	load_progress()
	_migrate_legacy_run()

## 0.19.0 (291): onde ficam os ficheiros do perfil em uso.
func progress_path() -> String:
	return Profiles.path("progress.json")

func trash_path() -> String:
	return Profiles.path("run_trash.json")

## 0.19.0 (291): depois de mudar de perfil, volta a ler o progresso e esquece a run em memória.
func reload_profile() -> void:
	progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	difficulty = "normal"
	current_slot = 1
	slot_confirmed = false
	pending_battle = {}
	_slot_cache.clear()
	_last_run_text.clear()
	_rotate_backups()
	load_progress()
	_migrate_legacy_run()
	Stats._ensure()
	ensure_opened_baseline()   # 0.19.0 (45)

func new_run(deck_id: String = "deck01", seed_override: int = 0, p_stake: int = 1) -> void:
	seed_value = seed_override if seed_override != 0 else randi()
	rng.seed = seed_value
	ante = 1
	max_ante = 8
	gold = 4
	player_max_hp = 20
	player_hp = player_max_hp
	mode = "free" if free_mode else "campaign"
	stake = clampi(p_stake, 1, STAKES.size())
	relic_ids.clear()
	relic_locked.clear()
	last_unlocks.clear()
	deck_log.clear()   # 0.19.0 (56)
	last_victory = false
	last_loss = {}   # 0.15.0
	interest_ante = 0
	seen_events.clear()
	pending_event = ""
	current_enemy_id = ""
	pair_enemy_id = ""
	endless = false
	planeswalker = {}
	formation_levels = {}
	map_plan = {}
	map_choice = {}
	map_history = {}
	map_phase = "battle"
	puzzle_id = ""
	boss_relics.clear()
	loot_offer.clear()
	climates = {}
	contract = {}
	death_save_used = false
	relic_counters = {}
	interlude_key = ""
	vouchers.clear()
	nemesis_beaten.clear()
	challenge_id = ""
	saga_id = ""
	run_log = {}
	roll_random_cosmetics()   # 0.19.0 (300)
	econ = {}   # 0.19.0 (secção 3)
	run_talents = {}
	last_reward_text = ""
	nemesis_id = ""
	run_name = ""
	bosses_seen.clear()
	milestones_claimed.clear()
	last_milestone_text = ""
	blessings.clear()
	next_enemy_weaken = 0
	arena_battle = false
	consumables.clear()
	stolen_relics.clear()
	endless_curses.clear()
	pact_offer.clear()
	pending_later.clear()
	later_notes.clear()
	boss_clean = false
	last_stars = 0
	run_variant = "classic"
	deck_def = CardDB.get_deck(deck_id)
	deck.clear()
	for id in deck_def.get("cards", []):
		deck.append(_new_entry(String(id)))
	if mode == "campaign" or mode == "free":
		nemesis_id = _pick_nemesis()
	chain_id = _pick_chain()   # 0.17.0: a história em cadeia desta run
	chain_part = 0
	chain_tags.clear()
	chain_last_act = 0
	tower_phase = "climb"
	tower_offer = {}
	rush_list.clear()
	rush_turns.clear()
	last_side_record = false
	EventBus.run_started.emit()
	EventBus.gold_changed.emit(gold)

## Desafio: baralho e regras fixos (challenges.json); não conta para a campanha.
func new_challenge_run(id: String, seed_override: int = 0) -> void:
	var ch := CardDB.get_challenge(id)
	free_mode = true
	new_run(String(ch.get("deck_id", "deck01")), seed_override, 1)
	mode = "challenge"
	challenge_id = id
	nemesis_id = ""
	# 0.12.0: baralho sem criaturas, cartas extra e relíquia inicial.
	if bool(run_rule("no_creatures", false)):
		var kept: Array[Dictionary] = []
		for e in deck:
			var cd := CardDB.get_card(String(e.get("id", "")))
			if cd != null and not cd.is_creature():
				kept.append(e)
		deck = kept
	for cid in ch.get("add_cards", []):
		if CardDB.get_card(String(cid)) != null:
			deck.append(_new_entry(String(cid)))
	if String(run_rule("start_relic", "")) == "legendary":
		var rid := random_legendary_relic()
		if rid != "":
			add_relic(rid)
	_apply_start_rules()

## História: capítulo de 4 antes com regra própria, cartas extra e boss do capítulo.
func new_saga_run(id: String, seed_override: int = 0) -> void:
	var ch := CardDB.get_saga_chapter(id)
	free_mode = true
	new_run(String(ch.get("deck_id", "deck01")), seed_override, 1)
	mode = "saga"
	saga_id = id
	nemesis_id = ""
	max_ante = int(ch.get("antes", 4))
	for cid in ch.get("add_cards", []):
		if CardDB.get_card(String(cid)) != null:
			deck.append(_new_entry(String(cid)))
	_apply_start_rules()
	apply_talents()

## Regras que mexem no início da run (vida máxima; 0.12.0: ouro inicial).
func _apply_start_rules() -> void:
	var hp := int(run_rule("max_hp", 0))
	if hp > 0:
		player_max_hp = hp
		player_hp = hp
		EventBus.player_hp_changed.emit(player_hp, player_max_hp)
	var g := int(run_rule("start_gold", 0))
	if g > 0:
		add_gold(g)

## Valor de uma regra da run (Desafio ou capítulo da História); `default` se não houver.
func run_rule(key: String, fallback = null):
	if challenge_id != "":
		var r: Dictionary = CardDB.get_challenge(challenge_id).get("rules", {})
		if r.has(key):
			return r[key]
	if saga_id != "":
		var r2: Dictionary = CardDB.get_saga_chapter(saga_id).get("rule", {})
		if r2.has(key):
			return r2[key]
	return fallback

## Regras que o BattleManager junta às do boss.
func battle_rules() -> Dictionary:
	var out := {}
	if puzzle_id != "":
		return out
	if DIFFICULTY_ATTACK.has(difficulty) and run_rule("enemy_attack_plus") == null:   # 0.13.0 Pesadelo
		out["enemy_attack_plus"] = int(DIFFICULTY_ATTACK[difficulty])
	for key in ["cost_max", "start_tokens", "first_spell_free", "spell_mult", "enemy_attack_plus",
			"creatures_keyword", "minions_plus", "enemy_shield_plus", "land_buff"]:
		var v = run_rule(key)
		if v != null:
			out[key] = v
	if out.has("spell_mult") and saga_id != "":
		out["rule_name"] = String(CardDB.get_saga_chapter(saga_id).get("name", ""))
	return out

## Nome do modo para os ecrãs ("" na campanha normal).
func mode_title() -> String:
	if challenge_id != "":
		return TranslationServer.translate("Desafio") + ": " + TranslationServer.translate(String(CardDB.get_challenge(challenge_id).get("name", "")))
	if saga_id != "":
		return TranslationServer.translate(String(CardDB.get_saga_chapter(saga_id).get("name", "")))
	return ""

## Run Rápida (0.12.0): qualquer baralho, 4 antes com o boss final no 4.º; conta para os talentos e
## as estatísticas, não para os baralhos da campanha.
func new_quick_run(deck_id: String, p_stake: int = 1, seed_override: int = 0) -> void:
	free_mode = true
	new_run(deck_id, seed_override, p_stake)
	mode = "quick"
	max_ante = 4
	apply_talents()

## 0.19.0 (176, 177, 201): os modos curtos — Batalha avulsa (uma batalha, sem run), Run de 2 antes (com o boss no 2.º)
## e Só batalhas (4 antes sem lojas nem eventos). Contam como Modo Livre (não mexem na campanha).
func new_short_run(kind: String, deck_id: String, p_stake: int = 1, seed_override: int = 0) -> void:
	free_mode = true
	new_run(deck_id, seed_override, p_stake)
	mode = kind
	max_ante = {"skirmish": 1, "mini": 2, "brawl": 4}.get(kind, 4)
	apply_talents()

## Arena Draft: baralho montado na hora, run curta (4 antes), não conta para a campanha.
func new_draft_run(card_ids: Array, colors: Array, seed_override: int = 0) -> void:
	free_mode = true
	new_run("deck01", seed_override, 1)
	mode = "draft"
	max_ante = 4
	deck_def = {"id": "draft", "num": 0, "name": "Arena Draft", "colors": colors, "color_code": "", "size": card_ids.size(),
		"mechanic": "Baralho de draft", "difficulty": 3, "cards": card_ids, "custom": true}
	deck.clear()
	for id in card_ids:
		deck.append(_new_entry(String(id)))
	apply_talents()
	EventBus.run_started.emit()

# ---------------------------------------------------------------------------
# 0.17.0 (83): Torre do Arquimago
# Andares seguidos, sem loja nem mapa: em cada andar uma batalha e depois UM prémio — uma carta (1 de 3), uma
# relíquia (1 de 2) ou descansar (cura 30 % da vida máxima). A vida passa de um andar para o outro e de 5 em 5
# andares há um boss (as relíquias do prémio passam a ser de boss). Acaba quando perdes uma batalha; fica o
# andar mais alto (progress.tower_best, só no telemóvel). O andar é o `ante`; max_ante = TOWER_TOP, para nada
# do fim da run disparar. Sem clima, Némesis, histórias em cadeia, ouro nem talentos ganhos.
# ---------------------------------------------------------------------------

const TOWER_TOP := 999
const TOWER_BOSS_EVERY := 5
const TOWER_REST_PCT := 0.3
const TOWER_CARD_CHOICES := 3
const TOWER_RELIC_CHOICES := 2
## Vida dos inimigos: TOWER_HP_START × TOWER_HP_GROWTH^(andar − 1); os bosses ×TOWER_BOSS_HP (antes do hp_mult
## de cada um). Afinado com tests/Balance.gd --mode=tower.
const TOWER_HP_START := 2600.0
const TOWER_HP_GROWTH := 1.2
const TOWER_BOSS_HP := 1.3

func new_tower_run(deck_id: String, seed_override: int = 0) -> void:
	free_mode = true
	new_run(deck_id, seed_override, 1)
	mode = "tower"
	max_ante = TOWER_TOP
	nemesis_id = ""
	chain_id = ""
	gold = 0
	map_choice = {"battle": "scout"}
	apply_talents()
	EventBus.gold_changed.emit(gold)

## Vida base do inimigo de um andar (sem o hp_mult dele).
func tower_hp(floor_n: int) -> int:
	return int(round(TOWER_HP_START * pow(TOWER_HP_GROWTH, maxi(0, floor_n - 1)) * float(DIFFICULTY_HP.get(difficulty, 1.0))))

## Quem espera num andar (sorteio próprio por andar: o ecrã da Torre mostra-o antes da batalha).
## Andares 1–2: os inimigos do ante 1; 3–4: até ao ante 2… Os bosses não se repetem até os veres todos;
## os bosses finais só a partir do andar 20.
func tower_enemy_def(a: int) -> Dictionary:
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 389 + a * 15485863
	if is_boss_ante(a):
		var bosses: Array = CardDB.enemies.filter(func(e): return bool(e.get("boss", false)) and not bool(e.get("saga", false)) \
			and (not bool(e.get("final", false)) or a >= 4 * TOWER_BOSS_EVERY))
		var fresh: Array = bosses.filter(func(e): return not (String(e.get("id", "")) in bosses_seen))
		if not fresh.is_empty():
			bosses = fresh
		return bosses[r.randi_range(0, bosses.size() - 1)] if not bosses.is_empty() else {}
	var level := clampi(1 + int((a - 1) / 2), 1, 8)
	var pool: Array = CardDB.enemies.filter(func(e): return not bool(e.get("boss", false)) and not bool(e.get("saga", false)) \
		and int(e.get("min_ante", 1)) <= level)
	return pool[r.randi_range(0, pool.size() - 1)] if not pool.is_empty() else {}

func tower_enemy(a: int) -> Dictionary:
	var def := tower_enemy_def(a)
	var variant := "boss" if bool(def.get("boss", false)) else "scout"
	map_choice["battle"] = variant
	if variant == "boss" and not (String(def.get("id", "")) in bosses_seen):
		bosses_seen.append(String(def.get("id", "")))
	var base := tower_hp(a)
	if variant == "boss":
		base = int(round(base * TOWER_BOSS_HP))
	return build_enemy(def, a, variant, base)

## Andar vencido: o prémio (sorteio próprio, determinístico por andar; grava-se com a run).
func tower_prepare_offer() -> void:
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 271 + ante * 7741
	var boss := is_boss_ante(ante)
	var cards: Array = []
	for c in CardDB.random_shop_offers(TOWER_CARD_CHOICES, r):
		cards.append(c.id)
	var relics: Array = []
	if relics_allowed():
		if boss:
			var pool: Array = CardDB.relics.values().filter(func(x): return bool(x.get("boss", false)) and not (String(x.get("id", "")) in boss_relics))
			for i in TOWER_RELIC_CHOICES:
				if pool.is_empty():
					break
				var pick: Dictionary = pool[r.randi_range(0, pool.size() - 1)]
				pool.erase(pick)
				relics.append(String(pick.get("id", "")))
		else:
			var exclude: Array = relic_ids.duplicate()
			for i in TOWER_RELIC_CHOICES:
				var rel := CardDB.random_relic_offer(r, exclude)
				if rel.is_empty():
					break
				relics.append(String(rel.get("id", "")))
				exclude.append(String(rel.get("id", "")))
	tower_offer = {"cards": cards, "relics": relics, "boss": boss, "heal": tower_heal_amount()}
	tower_phase = "reward"

func tower_heal_amount() -> int:
	return maxi(1, int(round(player_max_hp * TOWER_REST_PCT)))

## Escolhe o prémio do andar: "card" (id), "relic" (id; `replace` = a relíquia que sai quando não há lugar) ou
## "rest". Passa ao andar seguinte. Devolve o texto do aviso ("" se não deu).
func tower_take(kind: String, id: String = "", replace: String = "") -> String:
	if tower_phase != "reward":
		return ""
	var txt := ""
	match kind:
		"card":
			var cd := CardDB.get_card(id)
			if cd == null or not (id in (tower_offer.get("cards", []) as Array)):
				return ""
			add_card(id, false, roll_edition(cd))
			txt = tr("%s entra no baralho.") % tr(cd.name)
		"relic":
			if not (id in (tower_offer.get("relics", []) as Array)):
				return ""
			if bool(tower_offer.get("boss", false)):
				if not add_boss_relic(id):
					return ""
			else:
				if replace != "" and replace in relic_ids and relic_ids.size() >= max_relics():
					remove_relic(replace)
				if not add_relic(id):
					return ""
			txt = tr("%s é tua.") % tr(String(CardDB.relics.get(id, {}).get("name", id)))
		"rest":
			var h := int(tower_offer.get("heal", tower_heal_amount()))
			heal(h)
			txt = tr("Descansaste: +%d de vida.") % h
		_:
			return ""
	tower_next_floor()
	return txt

## O andar seguinte: o prémio fecha-se e a batalha fica à espera no ecrã da Torre.
func tower_next_floor() -> void:
	tower_offer = {}
	tower_phase = "climb"
	next_ante()
	map_choice = {"battle": "boss" if is_boss_ante(ante) else "scout"}

func tower_best() -> int:
	return int(progress.get("tower_best", 0))

# ---------------------------------------------------------------------------
# 0.17.0 (84): Corrida de Bosses
# Os bosses da campanha que já venceste, um atrás do outro, com o baralho que escolheres; entre batalhas curas
# 30 % da vida máxima. Sem loja nem prémios. A medalha vem da média de turnos por boss: ouro até 2,5, prata até
# 3,5, bronze por acabar. Abre-se com 3 bosses vencidos. O ante é o n.º do boss (max_ante = quantos são).
# ---------------------------------------------------------------------------

const RUSH_MIN_BOSSES := 3
const RUSH_HEAL_PCT := 0.3
const RUSH_HP_ANTE := 3        # vida dos bosses: a do ante 3 (o baralho não cresce na Corrida)
const RUSH_GOLD_AVG := 2.5
const RUSH_SILVER_AVG := 3.5

func rush_unlocked() -> bool:
	return defeated_bosses().size() >= RUSH_MIN_BOSSES

## A ordem da Corrida: os bosses vencidos pela ordem do enemies.json, com os finais no fim.
func rush_order() -> Array[String]:
	var normal: Array[String] = []
	var finals: Array[String] = []
	for id in defeated_bosses():
		if bool(CardDB.enemy_def(id).get("final", false)):
			finals.append(id)
		else:
			normal.append(id)
	normal.append_array(finals)
	return normal

func new_rush_run(deck_id: String, seed_override: int = 0) -> void:
	free_mode = true
	new_run(deck_id, seed_override, 1)
	mode = "rush"
	nemesis_id = ""
	chain_id = ""
	gold = 0
	rush_list = rush_order()
	max_ante = maxi(1, rush_list.size())
	map_choice = {"battle": "boss"}
	apply_talents()
	EventBus.gold_changed.emit(gold)

## O boss n.º `a` da Corrida.
func rush_def(a: int) -> Dictionary:
	var id := rush_list[clampi(a - 1, 0, rush_list.size() - 1)] if not rush_list.is_empty() else ""
	var def := CardDB.enemy_def(id)
	return def if not def.is_empty() else CardDB.enemy_def("boss_gag")

func rush_enemy(a: int) -> Dictionary:
	map_choice["battle"] = "boss"
	return build_enemy(rush_def(a), a, "boss", enemy_hp_for_ante(RUSH_HP_ANTE))

## Boss da Corrida vencido em `turns` turnos: fica registado e curas 30 % (o seguinte é o ante a seguir).
func rush_boss_won(turns: int) -> void:
	rush_turns.append(maxi(1, turns))
	heal(rush_heal_amount())

func rush_heal_amount() -> int:
	return maxi(1, int(round(player_max_hp * RUSH_HEAL_PCT)))

func rush_next() -> void:
	next_ante()
	map_choice = {"battle": "boss"}

func rush_total_turns() -> int:
	var t := 0
	for n in rush_turns:
		t += n
	return t

func rush_avg_turns() -> float:
	return float(rush_total_turns()) / maxf(1.0, float(rush_turns.size()))

## Medalha de uma Corrida acabada pela média de turnos por boss ("gold", "silver" ou "bronze").
static func rush_medal_for(avg: float) -> String:
	if avg <= RUSH_GOLD_AVG:
		return "gold"
	if avg <= RUSH_SILVER_AVG:
		return "silver"
	return "bronze"

## O melhor da Corrida: {"medal", "avg", "bosses"} ({} se nunca acabaste uma).
func rush_record() -> Dictionary:
	return progress.get("rush", {}) if progress.get("rush") is Dictionary else {}

## Fim de uma Torre ou de uma Corrida (record_run_end): recordes, estatísticas e conquistas.
func _record_side_mode_end(victory: bool) -> void:
	last_side_record = false
	if mode == "tower":
		if ante > tower_best():
			last_side_record = tower_best() > 0
			progress["tower_best"] = ante
		Stats.set_at_least("tower_best", ante)
		return
	Stats.set_at_least("rush_best", rush_turns.size())
	if not victory:
		return
	Stats.add("rush_done")
	var avg := rush_avg_turns()
	var medal := rush_medal_for(avg)
	if medal == "gold":
		Stats.add("rush_gold")
	var rec := rush_record()
	var order := ["", "bronze", "silver", "gold"]
	var better := rec.is_empty() or order.find(medal) > order.find(String(rec.get("medal", ""))) \
		or (medal == String(rec.get("medal", "")) and avg < float(rec.get("avg", 99.0)))
	if better:
		last_side_record = not rec.is_empty()
		progress["rush"] = {"medal": medal, "avg": snappedf(avg, 0.01), "bosses": rush_turns.size()}

static func _new_entry(id: String) -> Dictionary:
	return {"id": id, "power_bonus": 0, "mult_bonus": 0.0}

## Cores do baralho atual (para a loja).
func deck_colors() -> Array:
	return deck_def.get("colors", [])

## Cor principal do baralho (a primeira; "" se for incolor) — Fonte de Mana.
func main_color() -> String:
	var cols := deck_colors()
	return String(cols[0]) if not cols.is_empty() else ""

func deck_ids() -> Array[String]:
	var out: Array[String] = []
	for e in deck:
		out.append(String(e["id"]))
	return out

## 0.19.0 (72, 73): `reason` diz de onde veio ou para onde foi o ouro ("interest", "sale", "card", "relic",
## "service", "reroll"… — Economy.SPENT_NAMES), para o gráfico e o «onde gastei» do fim da run.
func add_gold(amount: int, reason: String = "") -> void:
	var before := gold
	gold = max(0, gold + amount)
	Economy.log_gold(gold - before, reason)
	EventBus.gold_changed.emit(gold)

func spend_gold(amount: int, reason: String = "") -> bool:
	if gold < amount:
		return false
	gold -= amount
	Economy.log_gold(-amount, reason)
	EventBus.gold_changed.emit(gold)
	return true

func add_card(id: String, infected: bool = false, edition: String = "") -> void:
	var e := _new_entry(id)
	if infected:
		e["infected"] = true
	if edition != "" and EffectResolver.EDITIONS.has(edition):
		e["edition"] = edition
		Stats.on_edition(edition)
	deck.append(e)
	Stats.mark_seen("cards", id, false)
	bump_relic_counters("card_added")
	log_deck("curse" if infected else "add", id, edition)
	Economy.note_card_gained()   # 0.19.0 (92)

## 0.13.0: edição de uma carta nova da loja ou do booster ("" = normal). Só as Criaturas e os feitiços
## (as cartas que disparam na cascata) podem ter edição.
func roll_edition(cd: CardData) -> String:
	if cd == null or not (cd.is_creature() or cd.is_spell()) or cd.token:
		return ""
	var r := rng.randf()
	var acc := 0.0
	for ed in ["poly", "holo", "shiny"]:
		acc += float(EffectResolver.EDITIONS[ed]["chance"]) * (1.0 + talent_value("edition_luck") / 100.0)
		if r < acc:
			return ed
	return ""

## 0.13.0 (Forja): dá ou troca a edição de uma carta do baralho.
func set_edition(entry_index: int, edition: String) -> bool:
	if entry_index < 0 or entry_index >= deck.size() or not EffectResolver.EDITIONS.has(edition):
		return false
	deck[entry_index]["edition"] = edition
	Stats.on_edition(edition)
	log_deck("edition", String(deck[entry_index].get("id", "")), edition)
	return true

## Acampamento → Forjar: a carta passa à versão "+" (efeitos ×1,5).
func forge_plus(entry_index: int) -> bool:
	if entry_index < 0 or entry_index >= deck.size() or bool(deck[entry_index].get("plus", false)):
		return false
	deck[entry_index]["plus"] = true
	Stats.on_plus_card()
	log_deck("plus", String(deck[entry_index].get("id", "")))
	return true

## Remove UMA cópia da carta. Devolve false se não existir.
func remove_card(id: String) -> bool:
	for i in deck.size():
		if deck[i]["id"] == id:
			deck.remove_at(i)
			log_deck("remove", id)
			return true
	return false

## Apaga do baralho as entradas exiladas durante a batalha (Selo da Corrupção a 0, infeção).
func purge_exiled() -> void:
	for i in range(deck.size() - 1, -1, -1):
		if deck[i].get("exiled_run", false):
			log_deck("remove", String(deck[i].get("id", "")), "exiled")   # 0.19.0 (56)
			deck.remove_at(i)

## Custo de remover uma carta na loja: sobe com o ante para não ser trivial afinar o deck.
func removal_price() -> int:
	return 2 + int(ante / 3)

## Contagem por id, para listar o deck sem repetições.
func deck_counts() -> Dictionary:
	var counts := {}
	for e in deck:
		counts[e["id"]] = counts.get(e["id"], 0) + 1
	return counts

## Lugares para relíquias (5; +1 com o Vale da Prateleira).
func max_relics() -> int:
	return MAX_RELICS + int(voucher_value("relic_slots"))

## Desafio "Mãos Vazias": nenhuma relíquia.
func relics_allowed() -> bool:
	return not bool(run_rule("no_relics", false))

## Devolve false se já a tiveres ou se não houver espaço (max_relics()).
func add_relic(id: String) -> bool:
	if id in relic_ids or relic_ids.size() >= max_relics() or not relics_allowed():
		return false
	relic_ids.append(id)
	if CardDB.relics.get(id, {}).has("scaling"):
		relic_counters[id] = 0   # as relíquias que escalam começam do zero quando as ganhas
	Economy.note_relic_gained()   # 0.19.0 (92)
	EventBus.relic_gained.emit(id)
	return true

func remove_relic(id: String) -> void:
	relic_ids.erase(id)
	relic_locked.erase(id)
	relic_counters.erase(id)
	EventBus.relics_changed.emit()

func move_relic(id: String, index: int) -> void:
	if not (id in relic_ids):
		return
	relic_ids.erase(id)
	relic_ids.insert(clampi(index, 0, relic_ids.size()), id)
	EventBus.relics_changed.emit()

func relic_sell_price(id: String) -> int:
	return max(1, int(CardDB.relics.get(id, {}).get("price", 4)) / 2)

func has_relic(id: String) -> bool:
	return id in relic_ids or id in boss_relics

## Relíquias que disparam: as da prateleira e as de boss.
func active_relic_ids() -> Array[String]:
	var out: Array[String] = relic_ids.duplicate()
	out.append_array(boss_relics)
	out.append_array(blessings)
	if not stolen_relics.is_empty():   # 0.13.0 Ladra de Relíquias: desligadas nesta batalha
		out = out.filter(func(id): return not (id in stolen_relics))
	return out

## Bênção do Santuário (0.12.0): fica até ao fim da run, fora do limite de relíquias.
func add_blessing(id: String) -> bool:
	if id in blessings or not CardDB.relics.has(id):
		return false
	blessings.append(id)
	EventBus.relics_changed.emit()
	return true

## Soma dos valores dos efeitos "passive" com esta ação em todas as relíquias ativas.
func relic_passive(action: String) -> float:
	var total := 0.0
	for id in active_relic_ids():
		for e in CardDB.relics.get(id, {}).get("effects", []):
			if String(e.get("trigger", "")) == "passive" and String(e.get("action", "")) == action:
				total += float(e.get("value", 1))
	return total

# --- Relíquias que escalam (contador desde que a relíquia é tua) ---

func relic_counter(id: String) -> int:
	return int(relic_counters.get(id, 0))

## Avança os contadores das relíquias que escalam com este acontecimento:
## "battle_won" · "channel" · "life_lost" (quantidade = vida) · "card_added".
func bump_relic_counters(event: String, amount: int = 1) -> void:
	if amount <= 0:
		return
	for id in active_relic_ids():
		var sc: Dictionary = CardDB.relics.get(id, {}).get("scaling", {})
		if String(sc.get("event", "")) == event:
			relic_counters[id] = relic_counter(id) + amount

## "Agora: +3 Mult" — o valor atual de uma relíquia que escala ("" nas outras).
func relic_scaling_text(id: String) -> String:
	var r: Dictionary = CardDB.relics.get(id, {})
	if not r.has("scaling"):
		return ""
	var n := relic_counter(id)
	for e in r.get("effects", []):
		if String(e.get("per", "")) != "relic_counter":
			continue
		var count := n
		if e.has("per_div"):
			count = int(n / maxi(1, int(e["per_div"])))
		var v := float(e.get("value", 0))
		match String(e.get("action", "")):
			"mult_add":
				return TranslationServer.translate("Agora: +%s Mult") % Cascade.fmt_mult(v * count)
			"power_add":
				return TranslationServer.translate("Agora: +%d Poder") % int(v * count)
			"mult_mul":
				return TranslationServer.translate("Agora: ×%s Mult") % Cascade.fmt_mult(1.0 + v * count)
	return ""

## Elite vencido: uma relíquia ao acaso (se houver lugar; senão 10 ouro). Devolve o id ou "".
func grant_elite_relic() -> String:
	var id := random_new_relic(Economy.elite_rarity(ante))   # 0.19.0 (96): a raridade que o mapa mostrou
	if id != "" and add_relic(id):
		return id
	add_gold(10)
	return ""

# --- 0.13.0: consumíveis (poções e pergaminhos) ---

func consumable_slots() -> int:
	return CONSUMABLE_SLOTS + int(voucher_value("item_slots")) + int(talent_value("item_slots"))   # 0.19.0 (65): também o talento Bolsa Funda

func can_add_consumable() -> bool:
	return consumables.size() < consumable_slots()

## Junta um consumível (false se não houver lugar ou não existir).
func add_consumable(id: String) -> bool:
	if not can_add_consumable() or CardDB.get_consumable(id).is_empty():
		return false
	consumables.append(id)
	EventBus.consumables_changed.emit()
	return true

## Tira o consumível desta posição (gasto ou deitado fora). Devolve o id ("" se não havia).
func remove_consumable_at(i: int) -> String:
	if i < 0 or i >= consumables.size():
		return ""
	var id := consumables[i]
	consumables.remove_at(i)
	EventBus.consumables_changed.emit()
	return id

## Um consumível ao acaso ("potion", "scroll" ou "" para qualquer um), com o RNG da run.
func random_consumable(kind: String = "") -> String:
	var pool: Array = CardDB.consumables.filter(func(c): return kind == "" or String(c.get("kind", "")) == kind)
	if pool.is_empty():
		return ""
	return String(pool[rng.randi_range(0, pool.size() - 1)].get("id", ""))

## Onde se usa: "battle", "map" ou "any".
static func consumable_use(id: String) -> String:
	return String(CardDB.get_consumable(id).get("use", "battle"))

## Fora da batalha (mapa, loja, eventos): a Poção de Vida cura. A Purificação escolhe a carta na UI.
## Devolve o texto do resultado ("" se não se usa aqui).
func use_consumable_outside(i: int) -> String:
	if i < 0 or i >= consumables.size():
		return ""
	var def := CardDB.get_consumable(consumables[i])
	var eff: Dictionary = def.get("effect", {})
	if String(def.get("use", "battle")) == "battle" or eff.has("remove_card"):
		return ""
	var parts: Array[String] = []
	if int(eff.get("heal", 0)) > 0:
		heal(int(eff["heal"]))
		parts.append(TranslationServer.translate("Curas %d.") % int(eff["heal"]))
	remove_consumable_at(i)
	Stats.add("consumables_used")
	return " ".join(PackedStringArray(parts))

# --- 0.13.0: maldições globais do Infinito (de 4 em 4 antes depois do fim da campanha) ---

## 0.17.0 Pactos do Infinito (89): de 4 em 4 antes depois do fim já não vem uma maldição ao acaso — o mapa
## mostra 3 (sorteio próprio, pela semente) e escolhes uma; as piores pagam mais ouro (`pact_gold`).
const PACT_CHOICES := 3

func _maybe_add_endless_curse() -> void:
	if not endless or ante <= max_ante or (ante - max_ante) % ENDLESS_CURSE_EVERY != 0:
		return
	var pool: Array = CardDB.endless_curses.filter(func(c): return not (String(c.get("id", "")) in endless_curses))
	if pool.is_empty():
		return
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 977 + ante
	pact_offer.clear()
	for i in PACT_CHOICES:
		if pool.is_empty():
			break
		var pick: Dictionary = pool[r.randi_range(0, pool.size() - 1)]
		pool.erase(pick)
		pact_offer.append(String(pick.get("id", "")))
	pact_offer.sort_custom(func(a: String, b: String): return pact_gold(a) < pact_gold(b))

## Ouro que uma maldição paga quando a escolhes num Pacto do Infinito.
func pact_gold(id: String) -> int:
	return int(CardDB.get_endless_curse(id).get("pact_gold", 0))

## Aceita uma das maldições oferecidas: junta-se às outras e paga o ouro dela. Devolve o texto do aviso.
func accept_pact(id: String) -> String:
	if not (id in pact_offer):
		return ""
	pact_offer.clear()
	endless_curses.append(id)
	var g := pact_gold(id)
	if g > 0:
		add_gold(g)
	Stats.add("pacts")
	var c := CardDB.get_endless_curse(id)
	return tr("Pacto aceite: %s (+%d ouro).") % [tr(String(c.get("name", ""))), g]

## Soma de uma regra numérica de todas as maldições do Infinito ativas.
func endless_rule_sum(key: String) -> float:
	var total := 0.0
	for id in endless_curses:
		var r: Dictionary = CardDB.get_endless_curse(id).get("rule", {})
		total += float(r.get(key, 0.0))
	return total

## Soma de um campo de topo (gold_minus, turns_minus) das maldições ativas.
func endless_value(key: String) -> float:
	var total := 0.0
	for id in endless_curses:
		total += float(CardDB.get_endless_curse(id).get(key, 0.0))
	return total

func endless_hp_mult() -> float:
	var m := 1.0
	for id in endless_curses:
		m *= float(CardDB.get_endless_curse(id).get("enemy_hp_mult", 1.0))
	return m

# --- 0.13.0: consequências de eventos (resolvem-se uns antes depois) ---

## Guarda uma consequência para daqui a N antes.
func add_later(in_antes: int, effects: Dictionary, text: String, title: String = "") -> void:
	pending_later.append({"ante": ante + maxi(1, in_antes), "effects": effects.duplicate(true), "text": text, "title": title})

## Consequências cujo ante chegou: aplicam-se e ficam em later_notes para o mapa as mostrar.
func _resolve_later() -> void:
	var keep: Array = []
	for l in pending_later:
		if int(l.get("ante", 0)) > ante:
			keep.append(l)
			continue
		var lines := apply_simple_effects(l.get("effects", {}) as Dictionary)
		var head := TranslationServer.translate(String(l.get("title", "")))
		var txt := TranslationServer.translate(String(l.get("text", "")))
		var note := ((head + ": ") if head != "" else "") + txt
		if not lines.is_empty():
			note += " " + " ".join(PackedStringArray(lines))
		later_notes.append(note.strip_edges())
	pending_later = keep

## Efeitos simples (sem escolher cartas), para as consequências: gold, heal, max_hp, relic, curse, card,
## consumable, grow_random, mult_random, weaken_next, talent. Devolve as linhas do resultado.
func apply_simple_effects(effects: Dictionary) -> Array[String]:
	var out: Array[String] = []
	var g := int(effects.get("gold", 0))
	if g > 0:
		add_gold(g)
		out.append(tr("+%d ouro.") % g)
	elif g < 0:
		var paid := mini(gold, -g)
		add_gold(-paid)
		out.append(tr("Pagas %d ouro.") % paid)
		var short := -g - paid
		if short > 0:   # sem ouro que chegue, paga-se em vida (nunca a última)
			var dmg := mini(short, player_hp - 1)
			if dmg > 0:
				player_hp -= dmg
				EventBus.player_hp_changed.emit(player_hp, player_max_hp)
				out.append(tr("Faltou ouro: perdes %d de vida.") % dmg)
	if effects.has("heal"):
		var h := int(effects["heal"])
		if h > 0:
			heal(h)
			out.append(tr("Curas %d.") % h)
		elif h < 0:
			var dmg2 := mini(-h, player_hp - 1)
			if dmg2 > 0:
				player_hp -= dmg2
				EventBus.player_hp_changed.emit(player_hp, player_max_hp)
				out.append(tr("Perdes %d de vida.") % dmg2)
	if int(effects.get("max_hp", 0)) != 0:
		var m := int(effects["max_hp"])
		change_max_hp(m)
		if m > 0:
			heal(m)
		out.append(tr("Vida máxima %s%d (agora %d).") % ["+" if m > 0 else "", m, player_max_hp])
	if String(effects.get("relic", "")) != "":
		var kind := String(effects["relic"])
		var id := random_legendary_relic() if kind == "legendary" else (random_new_relic() if kind == "random" else kind)
		if id != "" and add_relic(id):
			out.append(tr("Recebes a relíquia %s.") % tr(String(CardDB.relics[id].get("name", id))))
		elif id != "":
			add_gold(relic_sell_price(id) * 2)
			out.append(tr("Sem espaço para relíquias: recebes %d ouro em vez disso.") % (relic_sell_price(id) * 2))
	if String(effects.get("card", "")) != "":
		var cd := CardDB.random_card_for_deck(rng, "rare" if String(effects["card"]) == "rare" else "")
		if cd != null:
			add_card(cd.id)
			out.append(tr("%s juntou-se ao baralho.") % tr(cd.name))
	if int(effects.get("curse", 0)) > 0:
		for i in int(effects["curse"]):
			add_card("c314")
		out.append(tr("Recebes uma %s.") % tr(CardDB.get_card("c314").name))
	if String(effects.get("consumable", "")) != "":
		var kind2 := String(effects["consumable"])
		var cid := random_consumable(kind2 if kind2 in ["potion", "scroll"] else "") if kind2 in ["random", "potion", "scroll"] else kind2
		if cid != "" and add_consumable(cid):
			out.append(tr("Recebes: %s.") % tr(String(CardDB.get_consumable(cid).get("name", cid))))
		elif cid != "":
			add_gold(4)
			out.append(tr("Sem lugar para mais consumíveis: +%d ouro.") % 4)
	if int(effects.get("grow_random", 0)) > 0 and not deck.is_empty():
		var e: Dictionary = deck[rng.randi_range(0, deck.size() - 1)]
		e["power_bonus"] = int(e.get("power_bonus", 0)) + int(effects["grow_random"])
		out.append(tr("%s: +%d Poder permanente.") % [tr(CardDB.get_card(String(e["id"])).name), int(effects["grow_random"])])
	if float(effects.get("mult_random", 0.0)) > 0.0 and not deck.is_empty():
		var e2: Dictionary = deck[rng.randi_range(0, deck.size() - 1)]
		e2["mult_bonus"] = float(e2.get("mult_bonus", 0.0)) + float(effects["mult_random"])
		out.append(tr("%s: +%s Mult permanente.") % [tr(CardDB.get_card(String(e2["id"])).name), Cascade.fmt_mult(float(effects["mult_random"]))])
	if int(effects.get("weaken_next", 0)) > 0:
		next_enemy_weaken += int(effects["weaken_next"])
		out.append(tr("O inimigo da próxima batalha começa com −%d%% de vida.") % int(effects["weaken_next"]))
	if int(effects.get("talent", 0)) > 0:
		progress["talent_points"] = talent_points() + int(effects["talent"])
		save_progress()
		out.append(tr("+%d pontos de talento.") % int(effects["talent"]))
	return out

## Baú de Espólio: 3 relíquias de boss que ainda não tenhas (sorteio próprio, determinístico por ante).
func prepare_loot() -> Array[String]:
	loot_offer.clear()
	if not relics_allowed():
		return loot_offer   # Desafio "Mãos Vazias": sem Baú de Espólio
	var pool: Array = CardDB.relics.values().filter(func(r): return bool(r.get("boss", false)) and not (String(r.get("id", "")) in boss_relics))
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 17 + ante * 104729
	for i in LOOT_CHOICES:
		if pool.is_empty():
			break
		var pick: Dictionary = pool[r.randi_range(0, pool.size() - 1)]
		pool.erase(pick)
		loot_offer.append(String(pick.get("id", "")))
	return loot_offer

func add_boss_relic(id: String) -> bool:
	if id == "" or id in boss_relics or not CardDB.relics.has(id) or not relics_allowed():
		return false
	boss_relics.append(id)
	loot_offer.clear()
	Economy.note_relic_gained()   # 0.19.0 (92)
	for e in CardDB.relics[id].get("effects", []):
		if String(e.get("trigger", "")) == "on_gain" and String(e.get("action", "")) == "max_hp":
			change_max_hp(int(e.get("value", 0)))
	Stats.mark_seen("relics", id, false)
	Stats.on_boss_relic()
	EventBus.relics_changed.emit()
	return true

## Coração de Vidro: uma vez por run, um golpe mortal deixa-te com 1 de vida.
func can_death_save() -> bool:
	return not death_save_used and (relic_passive("death_save") > 0 or talent_value("death_save") > 0.0)

func use_death_save() -> void:
	death_save_used = true

## Preço na loja (o Cálice do Abismo cobra +2 em tudo).
func shop_price(base: int) -> int:
	return maxi(1, base + int(relic_passive("shop_tax")) - int(talent_value("shop_discount")))

## Relíquia ao acaso que ainda não tenhas (para eventos; nunca lendárias). "" se não houver.
func random_new_relic(rarity: String = "") -> String:
	var pool: Array = CardDB.relics.keys().filter(func(r): return not (r in relic_ids) and not bool(CardDB.relics[r].get("legendary", false)) and not bool(CardDB.relics[r].get("boss", false)) and CardDB.is_relic_available(CardDB.relics[r]))
	if rarity != "":   # 0.19.0 (96): só desta raridade (se houver)
		var same: Array = pool.filter(func(r): return String(CardDB.relics[r].get("rarity", "common")) == rarity)
		if not same.is_empty():
			pool = same
	if pool.is_empty():
		return ""
	return String(pool[rng.randi_range(0, pool.size() - 1)])

## Relíquia lendária ao acaso que ainda não tens ("" se não houver).
func random_legendary_relic() -> String:
	var pool: Array = CardDB.legendary_relics(relic_ids)
	if pool.is_empty():
		return ""
	return String(pool[rng.randi_range(0, pool.size() - 1)].get("id", ""))

# --- Vida (persistente ao longo da run) ---

func heal(amount: int) -> void:
	player_hp = clampi(player_hp + amount, 0, player_max_hp)
	EventBus.player_hp_changed.emit(player_hp, player_max_hp)

func change_max_hp(amount: int) -> void:
	player_max_hp = max(5, player_max_hp + amount)
	player_hp = clampi(player_hp, 1, player_max_hp)
	EventBus.player_hp_changed.emit(player_hp, player_max_hp)

func damage_player(amount: int) -> void:
	player_hp = max(0, player_hp - amount)
	EventBus.player_hp_changed.emit(player_hp, player_max_hp)

## Juros da loja: +1 ouro por cada 5 guardados (máx. 5; a dobrar com o Dízimo Dobrado), uma vez por ante.
func interest_due() -> int:
	if interest_ante == ante:
		return 0
	return Economy.interest_for(gold, interest_cap())

## Máximo de juros por loja (5; 8 com o Vale do Cofre).
func interest_cap() -> int:
	return INTEREST_CAP + int(voucher_value("interest_cap")) + int(talent_value("interest_cap"))

func pay_interest() -> int:
	var due := interest_due()
	interest_ante = ante
	if due > 0:
		Economy.credit_interest(gold)   # 0.19.0 (98, 99): o que veio do Vale do Cofre e do Investidor
		add_gold(due, "interest")
	return due

# --- Planeswalker (um por run; lealdade atravessa as batalhas) ---

func planeswalker_def() -> Dictionary:
	return CardDB.get_planeswalker(String(planeswalker.get("id", ""))) if not planeswalker.is_empty() else {}

func planeswalker_color() -> String:
	return String(planeswalker_def().get("color", ""))

func planeswalker_loyalty() -> int:
	return int(planeswalker.get("loyalty", 0))

func set_planeswalker(id: String) -> void:
	var def := CardDB.get_planeswalker(id)
	if def.is_empty():
		return
	planeswalker = {"id": id, "loyalty": int(def.get("loyalty", 2))}
	Stats.mark_seen("planeswalkers", id, false)
	EventBus.planeswalker_changed.emit()

func change_loyalty(amount: int) -> void:
	if planeswalker.is_empty():
		return
	var max_l := int(planeswalker_def().get("max_loyalty", 6))
	planeswalker["loyalty"] = clampi(planeswalker_loyalty() + amount, 0, max_l)
	EventBus.planeswalker_changed.emit()

# --- Formações com nível (Selo da Sabedoria) ---

func formation_level(id: String) -> int:
	return int(formation_levels.get(id, 0))

func level_up_random_formation() -> String:
	if CardDB.formations.is_empty():
		return ""
	var f: Dictionary = CardDB.formations[rng.randi_range(0, CardDB.formations.size() - 1)]
	var id := String(f.get("id", ""))
	formation_levels[id] = formation_level(id) + 1
	EventBus.formation_leveled.emit(id, formation_levels[id])
	return id

## 0.15.0 Constelação (loja): sobe 1 nível à formação escolhida.
func level_up_formation(id: String) -> bool:
	if CardDB.get_formation(id).is_empty():
		return false
	formation_levels[id] = formation_level(id) + 1
	EventBus.formation_leveled.emit(id, formation_levels[id])
	return true

# --- 0.15.0: desfazer a última compra ou serviço da loja ---

## O que uma compra ou um serviço da loja pode mudar na run (ouro, baralho, relíquias, vida, patrono,
## formações, poções, vales, o gerador de números e os contadores das edições).
func shop_snapshot() -> Dictionary:
	return {
		"gold": gold, "deck": deck.duplicate(true), "relic_ids": relic_ids.duplicate(),
		"relic_locked": relic_locked.duplicate(), "relic_counters": relic_counters.duplicate(true),
		"player_hp": player_hp, "player_max_hp": player_max_hp, "planeswalker": planeswalker.duplicate(true),
		"formation_levels": formation_levels.duplicate(), "consumables": consumables.duplicate(),
		"vouchers": vouchers.duplicate(), "rng_state": rng.state,
		"editions": Stats.get_stat("editions"), "editions_poly": Stats.get_stat("editions_poly"),
		"econ": econ.duplicate(true), "run_log": run_log.duplicate(true),   # 0.19.0 (secção 3)
	}

## Põe a run como estava no shop_snapshot() e avisa a interface (ouro, vida, relíquias, poções, patrono).
func restore_shop_snapshot(s: Dictionary) -> void:
	if s.is_empty():
		return
	gold = int(s.get("gold", gold))
	deck.assign((s.get("deck", []) as Array).duplicate(true))
	relic_ids.assign(s.get("relic_ids", []))
	relic_locked.assign(s.get("relic_locked", []))
	relic_counters = (s.get("relic_counters", {}) as Dictionary).duplicate(true)
	player_max_hp = int(s.get("player_max_hp", player_max_hp))
	player_hp = int(s.get("player_hp", player_hp))
	planeswalker = (s.get("planeswalker", {}) as Dictionary).duplicate(true)
	formation_levels = (s.get("formation_levels", {}) as Dictionary).duplicate()
	consumables.assign(s.get("consumables", []))
	vouchers.assign(s.get("vouchers", []))
	rng.state = int(s.get("rng_state", rng.state))
	if s.get("econ") is Dictionary:   # 0.19.0: reserva, desconto do booster, contas do ouro…
		econ = (s["econ"] as Dictionary).duplicate(true)
	if s.get("run_log") is Dictionary:
		run_log = (s["run_log"] as Dictionary).duplicate(true)
	for k in ["editions", "editions_poly"]:
		var back := int(s.get(k, 0)) - Stats.get_stat(k)
		if back != 0:
			Stats.add(k, back)
	EventBus.gold_changed.emit(gold)
	EventBus.player_hp_changed.emit(player_hp, player_max_hp)
	EventBus.relics_changed.emit()
	EventBus.consumables_changed.emit()
	EventBus.planeswalker_changed.emit()

# --- Selos Planares ---

func stake_name(n: int = -1) -> String:
	var i := clampi((stake if n < 0 else n) - 1, 0, STAKES.size() - 1)
	return String(STAKES[i].get("name", ""))

func hand_size_for_battle() -> int:
	var base := 5 if stake >= 7 else BattleManager.HAND_SIZE
	base = mini(base, int(run_rule("hand_size", base)))
	var n := base + int(relic_passive("hand_plus")) + int(voucher_value("hand_plus"))
	if not endless_curses.is_empty():   # 0.13.0 Maldição do Esquecimento (Infinito)
		n = maxi(mini(n, 3), n - int(endless_rule_sum("hand_size_minus")))
	return n

func discards_for_battle() -> int:
	if bool(run_rule("no_channel", false)):
		return 0
	var n := int(DIFFICULTY_DISCARDS.get(difficulty, 3))
	if stake >= 4:
		n = mini(n, 2)
	return n - int(relic_passive("discards_minus")) + int(voucher_value("discards_plus")) + int(talent_value("discards")) - int(endless_rule_sum("discards_minus"))

## Ouro por vencer uma batalha: 4 base + ante + turnos que sobraram (+4 nos Guardas; sem base nos
## Batedores com o Selo Planar 2). Relógio de Bolso: até ao turno 3, cada turno que sobra vale +3.
## Ampulheta de Areia Negra: −3.
## 0.16.0 (V38): a parte do ouro da vitória que vem dos turnos que sobraram (para o ecrã de recompensas).
func battle_reward_turns(turns_left: int, won_on_turn: int = 99) -> int:
	if bool(run_rule("no_battle_gold", false)) or mode in ["tower", "rush"]:   # 0.17.0: sem loja, sem ouro
		return 0
	var per_turn := 1
	var early := int(relic_passive("early_bonus"))
	if early > 0 and won_on_turn <= 3:
		per_turn = early
	return maxi(0, turns_left * per_turn)

func battle_reward(turns_left: int, won_on_turn: int = 99) -> int:
	return battle_gold_for(String(map_choice.get("battle", "scout")), turns_left, won_on_turn)

## 0.19.0 (71): o ouro de uma batalha deste tipo (para a previsão do mapa sem mexer no map_choice).
func battle_gold_for(variant: String, turns_left: int, won_on_turn: int = 99) -> int:
	if bool(run_rule("no_battle_gold", false)) or mode in ["tower", "rush"]:   # 0.17.0: a Torre e a Corrida têm o seu (Economy.side_gold_for_win)
		return 0
	var base := 4
	if stake >= 2 and variant == "scout":
		base = 0
	var bonus := GUARD_GOLD if variant == "guard" else (ELITE_GOLD if variant == "elite" else 0)
	if variant == "pair":   # 0.18.0 (25)
		bonus = PAIR_GOLD
	var per_turn := 1
	var early := int(relic_passive("early_bonus"))
	if early > 0 and won_on_turn <= 3:
		per_turn = early
	return max(0, base + ante + turns_left * per_turn + bonus - int(relic_passive("reward_minus")) + int(voucher_value("reward_plus")) - int(endless_value("gold_minus")))

# --- Inimigos e bosses ---

## Livro (1-3) do baralho atual, pela campanha; 1 se não constar.
func act_of_deck() -> int:
	var id := String(deck_def.get("id", ""))
	for i in CardDB.campaign.size():
		for ch in CardDB.campaign[i].get("chapters", []):
			if String(ch.get("deck_id", "")) == id:
				# 0.13.0: um livro pode dizer de que ato são os inimigos e eventos ("enemy_act"; Livro IV = 2)
				return int(CardDB.campaign[i].get("enemy_act", i + 1))
	return 1

## Ato da run (1–5) de um ante: dois antes por ato; o infinito é o ato V.
func act_of_ante(a: int) -> int:
	if a > max_ante:
		return 5
	return clampi(int((a - 1) / 2) + 1, 1, 5)

func act_name(a: int = -1) -> String:
	return ACT_NAMES[act_of_ante(ante if a < 0 else a) - 1]

## Bosses de N em N antes (4; 2 no Desafio "Maratona de Bosses").
func boss_every() -> int:
	return maxi(1, int(run_rule("boss_every", BOSS_EVERY)))

func is_boss_ante(a: int) -> bool:
	if mode == "tower":   # 0.17.0: um boss de 5 em 5 andares
		return a % TOWER_BOSS_EVERY == 0
	if mode == "rush":    # 0.17.0: só bosses
		return true
	if mode == "skirmish":   # 0.19.0 (176): uma batalha só, sem boss
		return false
	return a % boss_every() == 0 or (mode in ["saga", "mini"] and a == max_ante)

func current_enemy_is_boss() -> bool:
	for e in CardDB.enemies:
		if String(e.get("id", "")) == current_enemy_id:
			return bool(e.get("boss", false))
	return false

## Escolhe o inimigo de um ante: boss nos antes múltiplos de 4 (final no último), senão um do
## conjunto do livro do baralho com min_ante <= ante. Devolve a definição pronta para BattleManager.start.
## O Guarda (mapa) tem +25 % de vida; o Selo Planar 3 dá +35 % aos bosses a partir do ante 3.
func pick_enemy(a: int) -> Dictionary:
	if mode == "tower":   # 0.17.0 (83): Torre do Arquimago
		return tower_enemy(a)
	if mode == "rush":    # 0.17.0 (84): Corrida de Bosses
		return rush_enemy(a)
	var act := act_of_deck()
	var def: Dictionary = {}
	var variant0 := String(map_choice.get("battle", "scout"))
	if variant0 == "nemesis" and nemesis_def().size() > 0:
		return _nemesis_enemy(a)
	if variant0 == "pair" and not is_boss_ante(a):   # 0.18.0 (25): dois inimigos de uma vez
		return _pair_enemy(a)
	if is_boss_ante(a):
		var saga_boss := String(CardDB.get_saga_chapter(saga_id).get("boss", "")) if saga_id != "" else ""
		if saga_boss != "" and a == max_ante and not CardDB.enemy_def(saga_boss).is_empty():
			def = CardDB.enemy_def(saga_boss)
		else:
			var bosses: Array = CardDB.enemies.filter(func(e): return bool(e.get("boss", false)) and not bool(e.get("saga", false)) and (bool(e.get("final", false)) == (a == max_ante) or a > max_ante))
			if bosses.is_empty():
				bosses = CardDB.enemies.filter(func(e): return bool(e.get("boss", false)) and not bool(e.get("saga", false)))
			# 0.12.0: nunca o mesmo boss duas vezes na run (no Infinito, só depois de os ver todos).
			var fresh: Array = bosses.filter(func(e): return not (String(e.get("id", "")) in bosses_seen))
			if not fresh.is_empty():
				bosses = fresh
			def = bosses[rng.randi_range(0, bosses.size() - 1)]
			var pb := planned_enemy(a) if map_phase == "battle" else ""   # 0.19.0 (123): o boss que o mapa mostrou
			if pb != "" and not CardDB.enemy_def(pb).is_empty() and bool(CardDB.enemy_def(pb).get("boss", false)):
				def = CardDB.enemy_def(pb)
			if not (String(def.get("id", "")) in bosses_seen):
				bosses_seen.append(String(def.get("id", "")))
	else:
		var pool: Array = CardDB.enemies.filter(func(e):
			if bool(e.get("boss", false)) or bool(e.get("saga", false)) or int(e.get("min_ante", 1)) > a:
				return false
			return _act_in(act, e.get("acts", [1, 2, 3])) or a > max_ante)
		if pool.is_empty():
			pool = CardDB.enemies.filter(func(e): return not bool(e.get("boss", false)))
		def = pool[rng.randi_range(0, pool.size() - 1)]
		var pe := planned_enemy(a) if map_phase == "battle" else ""   # 0.19.0 (125): o inimigo que o mapa mostrou
		if pe != "":
			for e in pool:
				if String(e.get("id", "")) == pe:
					def = e
					break
	return build_enemy(def, a, String(map_choice.get("battle", "scout")))

## 0.19.0 (123, 125): o inimigo de cada ante fica escolhido logo que o mapa o mostra (com um sorteio próprio,
## gravado no plano do mapa), para o mapa dizer quem vem. A Némesis e a Dupla têm o seu. "" na Torre e na
## Corrida.
func planned_enemy(a: int) -> String:
	if mode in ["tower", "rush"] or CardDB.enemies.is_empty():
		return ""
	var plan: Dictionary = map_options(a)
	var known := String(plan.get("enemy", ""))
	if known != "" and not CardDB.enemy_def(known).is_empty():
		return known
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 61 + a * 15485863
	var pool: Array = []
	if is_boss_ante(a):
		var saga_boss := String(CardDB.get_saga_chapter(saga_id).get("boss", "")) if saga_id != "" else ""
		if saga_boss != "" and a == max_ante and not CardDB.enemy_def(saga_boss).is_empty():
			plan["enemy"] = saga_boss
			return saga_boss
		pool = CardDB.enemies.filter(func(e): return bool(e.get("boss", false)) and not bool(e.get("saga", false)) and (bool(e.get("final", false)) == (a == max_ante) or a > max_ante))
		if pool.is_empty():
			pool = CardDB.enemies.filter(func(e): return bool(e.get("boss", false)) and not bool(e.get("saga", false)))
		# Nunca um boss já visto nesta run nem um que o mapa já pôs noutro ante.
		var taken: Array = bosses_seen.duplicate()
		for k in map_plan:
			if String(k) != str(a) and map_plan[k] is Dictionary:
				taken.append(String((map_plan[k] as Dictionary).get("enemy", "")))
		var fresh: Array = pool.filter(func(e): return not (String(e.get("id", "")) in taken))
		if not fresh.is_empty():
			pool = fresh
	else:
		var act := act_of_deck()
		pool = CardDB.enemies.filter(func(e):
			if bool(e.get("boss", false)) or bool(e.get("saga", false)) or int(e.get("min_ante", 1)) > a:
				return false
			return _act_in(act, e.get("acts", [1, 2, 3])) or a > max_ante)
	if pool.is_empty():
		return ""
	var id := String(pool[r.randi_range(0, pool.size() - 1)].get("id", ""))
	plan["enemy"] = id
	return id

## 0.19.0 (122): os tipos de nós do mapa que já visitaste (a marca NOVO fica nos outros). Os de sempre contam
## como vistos; quem já jogou antes da 0.19.0 vê NOVO só nos nós especiais da 0.18.0.
const NODE_BASELINE := ["scout", "guard", "boss", "shop", "event", "rest"]

func node_seen(kind: String) -> bool:
	if kind == "" or kind in NODE_BASELINE:
		return true
	if not (progress.get("seen_nodes") is Array):
		var arr: Array = []
		if Stats.get_stat("runs") > 0:
			arr = ["elite", "nemesis", "spring", "altar", "merchant", "contracts", "tribunal", "treasure", "sanctuary", "arena", "forge", "library", "vault"]
		progress["seen_nodes"] = arr
	return kind in (progress["seen_nodes"] as Array)

func mark_node_seen(kind: String) -> void:
	if node_seen(kind):
		return
	(progress["seen_nodes"] as Array).append(kind)
	save_progress()

## A definição pronta para BattleManager.start de um inimigo do enemies.json neste ante: vida pela tabela
## (ou `base_hp`, se vier) com os multiplicadores todos (Guarda, Elite, Selo 3, relíquias, clima, Desafio,
## Infinito, afixos), ataque, regras, habilidades, rituais… 0.17.0: separado do pick_enemy para o Treino
## contra bosses, a Torre e a Corrida usarem o mesmo.
func build_enemy(def: Dictionary, a: int, variant: String, base_hp: int = -1) -> Dictionary:
	var mult := float(def.get("hp_mult", 1.0))
	if variant == "guard" and not bool(def.get("boss", false)):
		mult *= GUARD_HP_MULT
	if variant == "elite" and not bool(def.get("boss", false)):
		mult *= ELITE_HP_MULT
	if bool(def.get("boss", false)) and stake >= 3 and a >= 3:
		mult *= 1.35
	mult *= 1.0 + relic_passive("enemy_hp_pct") / 100.0
	if climate_for_ante(a) == "temporal_echo":
		mult *= 1.15
	if variant == "arena" and not bool(def.get("boss", false)):
		mult *= ARENA_HP_MULT
	if variant == "escape" and not bool(def.get("boss", false)):   # 0.18.0 Fuga: um inimigo mais forte
		mult *= ESCAPE_HP_MULT
	mult *= float(run_rule("enemy_hp_mult", 1.0))   # Desafios (0.12.0)
	mult *= endless_hp_mult()                        # 0.13.0 Maldição da Vitalidade (Infinito)
	# 0.13.0: afixos das Elites (1; 2 a partir do ante 6), sorteados com o RNG da run.
	var affix_ids: Array[String] = []
	if variant == "elite" and not bool(def.get("boss", false)):
		affix_ids = roll_affixes(a)
		for af_id in affix_ids:
			mult *= float(CardDB.get_affix(af_id).get("hp_mult", 1.0))
	var risky := not bool(def.get("boss", false)) and variant != "arena" and not Economy.risk_active().is_empty()   # 0.19.0 (100)
	if risky and Economy.risk_is("hp"):
		mult *= Economy.RISK_HP_MULT
	if next_enemy_weaken > 0:   # Alquimista Louco: só na batalha seguinte
		mult *= maxf(0.1, 1.0 - next_enemy_weaken / 100.0)
		next_enemy_weaken = 0
	var hp := int(round((enemy_hp_for_ante(a) if base_hp < 0 else base_hp) * mult))
	current_enemy_id = String(def.get("id", ""))
	pair_enemy_id = ""
	var out := {
		"id": def.get("id", ""),
		"name": def.get("name", "?"),
		"hp": hp, "max_hp": hp,
		"attack": int(def.get("attack", 0)) + (ELITE_ATTACK if variant in ["elite", "arena"] and not bool(def.get("boss", false)) else 0) \
			+ (ESCAPE_ATTACK if variant == "escape" and not bool(def.get("boss", false)) else 0),
		"text": def.get("text", ""),
		"abilities": (def.get("abilities", []) as Array).duplicate(true),
		"boss": bool(def.get("boss", false)),
		"rule": (def.get("rule", {}) as Dictionary).duplicate(),
		"rule2": def.get("rule2", {}),
		"rule2_text": def.get("rule2_text", ""),
		"lines": def.get("lines", {}),
		"variant": variant,
		"portrait": String(def.get("portrait", "")),
		"shield_pct": float(def.get("shield_pct", 0)),
		"minions": int(def.get("minions", 0)),
		"minion_hits": int(def.get("minion_hits", BattleManager.MINION_HITS)),
		"phases": (def.get("phases", []) as Array).duplicate(true),   # 0.13.0 Hidra Tricéfala
		"art": String(def.get("art", "")),   # 0.13.0: ilustração de outro (os rivais do Livro III usam a da Némesis)
		# 0.17.0: os rituais dos bosses (0.15.0) não passavam para a batalha — só os testes os punham à mão.
		"ritual": (def.get("ritual") as Dictionary).duplicate(true) if def.get("ritual") is Dictionary else {},
		"rituals": (def.get("rituals") as Array).duplicate(true) if def.get("rituals") is Array else [],
	}
	if variant in ["ambush", "siege", "escape"] and not bool(def.get("boss", false)):
		out["objective"] = variant   # 0.18.0 (24): a regra da batalha (BattleManager.objective)
	if risky and Economy.risk_is("atk"):   # 0.19.0 (100)
		out["attack"] = int(out["attack"]) + Economy.RISK_ATTACK
	if not affix_ids.is_empty():
		out["affixes"] = affix_ids
		for af_id in affix_ids:
			var af := CardDB.get_affix(af_id)
			out["attack"] = int(out["attack"]) + int(af.get("attack", 0))
			out["shield_pct"] = float(out["shield_pct"]) + float(af.get("shield_pct", 0.0))
			(out["abilities"] as Array).append_array((af.get("abilities", []) as Array).duplicate(true))
			var r: Dictionary = af.get("rule", {})
			for k in r:
				out["rule"][k] = r[k]
	return out

## 0.18.0 (25) Dupla: dois inimigos normais diferentes deste ante, cada um com PAIR_HP_PCT da vida de um
## Batedor e sem habilidades, regras, escudo nem lacaios (só atacam). O 1.º é o alvo; o 2.º vai em "pair".
func _pair_enemy(a: int) -> Dictionary:
	var act := act_of_deck()
	var pool: Array = CardDB.enemies.filter(func(e):
		if bool(e.get("boss", false)) or bool(e.get("saga", false)) or int(e.get("min_ante", 1)) > a:
			return false
		return _act_in(act, e.get("acts", [1, 2, 3])) or a > max_ante)
	if pool.size() < 2:
		pool = CardDB.enemies.filter(func(e): return not bool(e.get("boss", false)) and not bool(e.get("saga", false)))
	var i1 := rng.randi_range(0, pool.size() - 1)
	var i2 := rng.randi_range(0, pool.size() - 2)
	if i2 >= i1:
		i2 += 1
	var hp := int(round(enemy_hp_for_ante(a) * PAIR_HP_PCT))
	var pair: Array[Dictionary] = []
	for d in [pool[i1], pool[i2]]:
		var e := build_enemy(d, a, "pair", hp)
		e["abilities"] = []
		e["rule"] = {}
		e["rule2"] = {}
		e["rule2_text"] = ""
		e["shield_pct"] = 0.0
		e["minions"] = 0
		e["ritual"] = {}
		e["rituals"] = []
		e["phases"] = []
		e["text"] = "Dupla: os dois contra-atacam. Toca num para ser o alvo; o excesso do golpe passa para o outro."
		pair.append(e)
	current_enemy_id = String(pair[0].get("id", ""))
	pair_enemy_id = String(pair[1].get("id", ""))
	var out: Dictionary = pair[0]
	out["pair"] = pair[1]
	return out

## 0.13.0: afixos de uma Elite (ids de affixes.json; sem repetir).
func roll_affixes(a: int) -> Array[String]:
	var out: Array[String] = []
	var pool: Array = CardDB.affixes.map(func(x): return String(x.get("id", "")))
	var n := 2 if a >= AFFIX_TWO_FROM else 1
	for i in n:
		if pool.is_empty():
			break
		var pick: String = pool[rng.randi_range(0, pool.size() - 1)]
		pool.erase(pick)
		out.append(pick)
	return out

## Nome traduzido dos afixos ("Vampírico, Veloz").
static func affix_names(ids: Array) -> String:
	var names: Array[String] = []
	for id in ids:
		names.append(TranslationServer.translate(String(CardDB.get_affix(String(id)).get("name", id))))
	return ", ".join(PackedStringArray(names))

# --- Némesis ---

## Rival da run: um dos de nemesis.json cuja cor o baralho não tenha (sorteio próprio, pela semente).
func _pick_nemesis() -> String:
	if CardDB.nemeses.is_empty():
		return ""
	var cols := deck_colors()
	var pool: Array = CardDB.nemeses.filter(func(n): return not (String(n.get("color", "")) in cols))
	if pool.is_empty():
		pool = CardDB.nemeses.duplicate()
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 53 + 7
	return String(pool[r.randi_range(0, pool.size() - 1)].get("id", ""))

func nemesis_def() -> Dictionary:
	if nemesis_id == "" and (mode == "campaign" or mode == "free"):
		nemesis_id = _pick_nemesis()
	return CardDB.get_nemesis(nemesis_id) if nemesis_id != "" else {}

## Nível da Némesis num ante (1–3; 0 se não aparece lá).
func nemesis_level(a: int) -> int:
	if mode != "campaign" and mode != "free":
		return 0
	return int(NEMESIS_ANTES.get(a, 0))

func _nemesis_enemy(a: int) -> Dictionary:
	var n := nemesis_def()
	var levels: Array = n.get("levels", [])
	var lv := clampi(nemesis_level(a), 1, maxi(1, levels.size()))
	var L: Dictionary = levels[lv - 1] if not levels.is_empty() else {}
	var hp := int(round(enemy_hp_for_ante(a) * float(L.get("hp_mult", 1.3)) * (1.0 + relic_passive("enemy_hp_pct") / 100.0)))
	current_enemy_id = String(n.get("id", ""))
	pair_enemy_id = ""
	return {
		"id": n.get("id", ""), "name": n.get("name", "?"), "hp": hp, "max_hp": hp,
		"attack": int(L.get("attack", 3)),
		"text": String(n.get("text", "")),
		"abilities": n.get("abilities", []),
		"boss": false, "rule": {}, "rule2": {}, "rule2_text": "",
		"lines": {"intro": String(L.get("line", "")), "defeat": String(L.get("defeat", ""))},
		"variant": "nemesis", "nemesis_level": lv,
		"portrait": String(n.get("portrait", "knight")),
		"shield_pct": float(L.get("shield_pct", 0)),
		"minions": int(L.get("minions", 0)),
		"minion_hits": BattleManager.MINION_HITS,
	}

## Recompensa por vencer a Némesis neste nível; devolve o texto do que foi dado.
func grant_nemesis_reward(level: int) -> String:
	var n := nemesis_def()
	var rewards: Array = n.get("rewards", [])
	if rewards.is_empty():
		return ""
	var parts := apply_reward(rewards[clampi(level - 1, 0, rewards.size() - 1)])
	if not (level in nemesis_beaten):
		nemesis_beaten.append(level)
	Stats.on_nemesis_win()
	return ", ".join(PackedStringArray(parts))

# --- Depois de cada batalha (regras da História, Némesis) ---

func after_battle(bm: BattleManager, victory: bool) -> void:
	last_reward_text = ""
	last_loss = {} if victory or bm.puzzle else bm.loss_report()
	if not arena_battle:
		Economy.clear_risk()   # 0.19.0 (100): o risco era só para esta batalha
	if not victory:
		return
	var heal_win := int(run_rule("heal_on_win", 0))
	if heal_win > 0:
		heal(heal_win)
	var grow_win := int(run_rule("grow_on_win", 0))
	if grow_win > 0:
		var creatures: Array = []
		for i in deck.size():
			var cd := CardDB.get_card(String(deck[i].get("id", "")))
			if cd != null and cd.is_creature():
				creatures.append(i)
		if not creatures.is_empty():
			var i: int = creatures[rng.randi_range(0, creatures.size() - 1)]
			deck[i]["power_bonus"] = int(deck[i].get("power_bonus", 0)) + grow_win
	if bool(bm.enemy.get("boss", false)) and talent_value("boss_heal") > 0.0:
		heal(int(talent_value("boss_heal")))
	# 0.12.0: talentos Caçador de Prémios e Remendo.
	if (bool(bm.enemy.get("boss", false)) or String(bm.enemy.get("variant", "")) == "elite") and talent_value("boss_gold") > 0.0:
		add_gold(int(talent_value("boss_gold")))
		Economy.credit_talent("boss_gold", int(talent_value("boss_gold")))   # 0.19.0 (99)
	# 0.19.0 (75): a carta depois da batalha (opção da run), menos no fim da run.
	if Economy.card_rewards_on() and not (mode in ["tower", "rush"]) and (ante < max_ante or endless):
		Economy.prepare_card_reward()
	if talent_value("win_heal") > 0.0:
		heal(int(talent_value("win_heal")))
	if String(bm.enemy.get("variant", "")) == "nemesis":
		last_reward_text = grant_nemesis_reward(int(bm.enemy.get("nemesis_level", 1)))
	last_milestone_text = ""
	if endless and ENDLESS_MILESTONES.has(ante) and not (ante in milestones_claimed):
		last_milestone_text = claim_endless_milestone(ante)

## Marco do Infinito (0.12.0): ouro, pontos de talento e, da 1.ª vez, um cosmético. Devolve o texto.
func claim_endless_milestone(a: int) -> String:
	var m: Dictionary = ENDLESS_MILESTONES.get(a, {})
	if m.is_empty() or a in milestones_claimed:
		return ""
	milestones_claimed.append(a)
	var parts: Array[String] = []
	var g := int(m.get("gold", 0))
	if g > 0:
		add_gold(g)
		parts.append(tr("+%d ouro") % g)
	var t := int(m.get("talent", 0))
	if t > 0:
		progress["talent_points"] = talent_points() + t
		parts.append(tr("+%d pontos de talento") % t)
	var u: Dictionary = m.get("unlock", {})
	if not u.is_empty() and Stats.grant_unlock(String(u.get("type", "")), String(u.get("id", ""))):
		parts.append(Stats.unlock_label(u, "%s: %s"))
	progress["endless_best"] = maxi(int(progress.get("endless_best", 0)), a)
	Stats.set_at_least("endless_milestones", milestones_claimed.size())
	save_progress()
	return ", ".join(PackedStringArray(parts))

## Próximo marco do Infinito depois deste ante (0 se não houver).
func next_endless_milestone(a: int = -1) -> int:
	var from := ante if a < 0 else a
	var keys := ENDLESS_MILESTONES.keys()
	keys.sort()
	for k in keys:
		if int(k) >= from and not (int(k) in milestones_claimed):
			return int(k)
	return 0

# --- Resumo da run (carta MVP, relíquia que mais deu, dano por ante) ---

## Reparte o dano de um ataque pelos passos da cascata: cada passo fica com o que fez crescer
## Poder × Mult quando disparou (os ×Mult no fim pesam muito — é mesmo assim que a cascata funciona).
func log_cascade(c: Cascade, dealt: int) -> void:
	if dealt <= 0 or c.steps.is_empty():
		return
	_ensure_run_log()
	var key := str(ante)
	run_log["damage_by_ante"][key] = int(run_log["damage_by_ante"].get(key, 0)) + dealt
	if dealt > int(run_log.get("best_hit", 0)) or not run_log.has("best_cascade"):
		run_log["best_cascade"] = cascade_snapshot(c, dealt)
	run_log["best_hit"] = maxi(int(run_log.get("best_hit", 0)), dealt)
	var full := float(c.power) * c.mult
	if full <= 0.0:
		return
	var scale := float(dealt) / full
	var prev := 0.0
	for st in c.steps:
		var now := float(st.power_after) * st.mult_after
		var gain := (now - prev) * scale
		prev = now
		if gain <= 0.0:
			continue
		if st.source_kind == "relic" and st.source_id != "":
			run_log["relic_dmg"][st.source_id] = int(run_log["relic_dmg"].get(st.source_id, 0)) + int(gain)
		elif st.source_card != null and not st.source_card.data.token:
			var id := st.source_card.front.id
			run_log["card_dmg"][id] = int(run_log["card_dmg"].get(id, 0)) + int(gain)

func _ensure_run_log() -> void:
	if run_log.is_empty():
		run_log = {"damage_by_ante": {}, "card_dmg": {}, "relic_dmg": {}, "card_plays": {}, "best_hit": 0}
	if not (run_log.get("card_plays") is Dictionary):
		run_log["card_plays"] = {}

## 0.12.0: cada carta jogada numa run conta para as estatísticas por carta (fichas e batalhas à parte não).
func log_card_play(card: CardInstance) -> void:
	if puzzle_id != "" or card == null or card.data == null or card.data.token:
		return
	_ensure_run_log()
	var id := card.front.id if card.front != null else card.data.id
	run_log["card_plays"][id] = int(run_log["card_plays"].get(id, 0)) + 1

## 0.11.0: o maior golpe guarda-se passo a passo, para o "Rever o maior golpe" do fim da run.
func cascade_snapshot(c: Cascade, dealt: int) -> Dictionary:
	var steps: Array = []
	for st in c.steps.slice(0, 80):
		steps.append({
			"name": TranslationServer.translate(st.source_name), "kind": st.source_kind, "label": st.label,
			"color": st.source_card.data.primary_color() if st.source_card != null else "",
			"power": st.power_after, "mult": st.mult_after, "retrigger": st.retrigger, "tag": st.tag,
		})
	var names: Array = []
	for f in c.formations:
		names.append(TranslationServer.translate(f))
	return {"steps": steps, "total": dealt, "ante": ante, "formations": names,
		"shield": mini(c.shield, c.total())}

## {"id", "damage"} do maior valor de um dicionário id → dano (vazio se não houver).
static func top_of(d: Dictionary) -> Dictionary:
	var best := ""
	var best_v := 0
	for k in d:
		if int(d[k]) > best_v:
			best_v = int(d[k])
			best = String(k)
	return {"id": best, "damage": best_v} if best != "" else {}

# --- Vales (melhorias da run compradas na loja) ---

func voucher_value(key: String) -> float:
	var total := 0.0
	for id in vouchers:
		total += float((CardDB.get_voucher(id).get("effect", {}) as Dictionary).get(key, 0))
	return total

## Vale à venda nesta loja (um por visita, sorteio próprio por ante; "" se já os tiveres todos).
func shop_voucher_offer() -> String:
	var pool: Array = CardDB.vouchers.filter(func(v): return not (String(v.get("id", "")) in vouchers))
	if pool.is_empty():
		return ""
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 97 + ante * 1013
	return String(pool[r.randi_range(0, pool.size() - 1)].get("id", ""))

func buy_voucher(id: String, price: int = -1) -> bool:
	var v := CardDB.get_voucher(id)
	if v.is_empty() or id in vouchers:
		return false
	if not spend_gold(shop_price(int(v.get("price", 10))) if price < 0 else price, "voucher"):   # 0.19.0 (83): o preço regateado
		return false
	vouchers.append(id)
	if (v.get("effect", {}) as Dictionary).has("relic_slots"):
		EventBus.relics_changed.emit()
	if (v.get("effect", {}) as Dictionary).has("item_slots"):
		EventBus.consumables_changed.emit()
	return true

# --- Modo Treino ---

const TRAINING_HP := 999999999

## Estado neutro para uma batalha fora da run (enigmas e Treino): nada da run gravada em disco muda.
func reset_for_side_battle(id: String) -> void:
	puzzle_id = id
	free_mode = true
	challenge_id = ""
	saga_id = ""
	vouchers.clear()
	relic_ids.clear()
	boss_relics.clear()
	planeswalker = {}
	formation_levels = {}
	stake = 1
	ante = 1
	map_choice = {}
	player_hp = 20
	player_max_hp = 20
	pending_battle = {}
	contract = {}

## 0.13.0: de onde veio uma batalha fora da run (para onde voltar).
func side_battle_home() -> String:
	if puzzle_id in ["training", "training_boss"]:
		return "training"
	if is_lesson_battle():
		return "school"
	return "puzzles"

func start_training() -> void:
	reset_for_side_battle("training")
	for id in training.get("relics", []):
		if CardDB.relics.has(String(id)) and not (String(id) in relic_ids):
			relic_ids.append(String(id))

## Definição da batalha de Treino (no formato dos quebra-cabeças: 1 turno, mão fixa, mana dada).
func training_def() -> Dictionary:
	return {"id": "training", "name": "Treino", "enemy_name": "Boneco de Treino",
		"enemy_text": "Vida infinita. Não ataca: só quer ver o teu melhor golpe.",
		"hp": TRAINING_HP, "mana": int(training.get("mana", 5)),
		"hand": training.get("hand", []), "board": [], "graveyard": []}

# --- 0.17.0 (88): Treino contra bosses ---
# No Treino, em vez do Boneco, um boss da campanha que já venceste: uma batalha a sério (os turnos, a regra,
# as habilidades, os rituais e a Ascensão dele) com o baralho e as relíquias que escolheres. Fora da run:
# puzzle_id "training_boss" — nada se grava nem conta para as estatísticas.

const TRAINING_BOSS_ANTE := 4   # vida e turnos do 1.º boss de uma run

## Bosses da campanha que já venceste (os da História ficam de fora), pela ordem do enemies.json.
func defeated_bosses() -> Array[String]:
	var out: Array[String] = []
	var d = progress.get("defeated", {})
	if not (d is Dictionary):
		return out
	for e in CardDB.enemies:
		var id := String(e.get("id", ""))
		if bool(e.get("boss", false)) and not bool(e.get("saga", false)) and int((d as Dictionary).get(id, 0)) > 0:
			out.append(id)
	return out

## 0.19.0 (200): «Treinar esta batalha» (do PORQUE PERDI?) — o mesmo inimigo, no mesmo ante, com o baralho e as
## relíquias da run que acabou. Nada se grava nem conta (como o Treino contra bosses).
func start_enemy_training(enemy_id: String, at_ante: int) -> void:
	var keep_deck := deck.duplicate(true)
	var keep_relics := relic_ids.duplicate()
	var keep_def := deck_def.duplicate(true)
	training = {"enemy": enemy_id, "ante": maxi(1, at_ante), "deck": String(keep_def.get("id", "deck01")), "relics": [], "target": "boss", "boss": enemy_id}
	start_boss_training()
	if not keep_def.is_empty():
		deck_def = keep_def
	if not keep_deck.is_empty():
		deck.assign(keep_deck)
	relic_ids.assign(keep_relics.slice(0, MAX_RELICS))
	ante = maxi(1, at_ante)
	var d := CardDB.enemy_def(enemy_id)
	map_choice = {"battle": "boss" if bool(d.get("boss", false)) else "scout"}

## Estado para a batalha contra o boss do Treino (GameState.training: "boss", "deck", "relics").
func start_boss_training() -> void:
	reset_for_side_battle("training_boss")
	_reset_battle_extras()
	mode = "free"
	ante = TRAINING_BOSS_ANTE
	max_ante = 8
	deck_def = CardDB.get_deck(String(training.get("deck", "deck01")))
	deck.clear()
	for id in deck_def.get("cards", []):
		if CardDB.get_card(String(id)) != null:
			deck.append(_new_entry(String(id)))
	for id in training.get("relics", []):
		if CardDB.relics.has(String(id)) and not (String(id) in relic_ids) and relic_ids.size() < MAX_RELICS:
			relic_ids.append(String(id))
	map_choice = {"battle": "boss"}
	rng.seed = randi()

## O que fica de uma run (ou de outro modo) e mexe numa batalha: tudo a zero para uma batalha limpa.
func _reset_battle_extras() -> void:
	endless = false
	endless_curses.clear()
	pact_offer.clear()
	blessings.clear()
	stolen_relics.clear()
	consumables.clear()
	relic_locked.clear()
	relic_counters = {}
	death_save_used = false
	run_talents = {}
	next_enemy_weaken = 0
	arena_battle = false
	pending_later.clear()
	later_notes.clear()
	climates = {}
	bosses_seen.clear()

## O boss do Treino pronto para BattleManager.start (a vida do ante 4).
func training_boss_enemy() -> Dictionary:
	if training.has("enemy"):   # 0.19.0 (200): treinar uma batalha qualquer (o mesmo inimigo, no mesmo ante)
		var ed := CardDB.enemy_def(String(training["enemy"]))
		if not ed.is_empty():
			return build_enemy(ed, int(training.get("ante", TRAINING_BOSS_ANTE)), "boss" if bool(ed.get("boss", false)) else "scout")
	var def := CardDB.enemy_def(String(training.get("boss", "")))
	if def.is_empty() or not bool(def.get("boss", false)):
		var ids := defeated_bosses()
		def = CardDB.enemy_def(ids[0] if not ids.is_empty() else "boss_gag")
	return build_enemy(def, TRAINING_BOSS_ANTE, "boss")

# --- Medalhas, Desafios e História (progresso) ---

## Medalha de um baralho pelo Selo Planar mais alto vencido: bronze (1–3), prata (4–6), ouro (7–8).
func medal_for(deck_id: String) -> String:
	return MEDALS[clampi(stake_won(deck_id), 0, MEDALS.size() - 1)]

func challenge_done(id: String) -> bool:
	return progress.get("challenges") is Dictionary and (progress["challenges"] as Dictionary).has(id)

## 0.13.0: estrelas de um Desafio (0–3; as medalhas antigas valem 1).
func challenge_stars(id: String) -> int:
	var st = progress.get("challenge_stars")
	if st is Dictionary and (st as Dictionary).has(id):
		return int(st[id])
	return 1 if challenge_done(id) else 0

func total_challenge_stars() -> int:
	var n := 0
	for c in CardDB.challenges:
		n += challenge_stars(String(c.get("id", "")))
	return n

## Estrelas da run que acabou de vencer (só faz sentido no fim de um Desafio vencido).
func challenge_stars_for_run() -> int:
	return 1 + (1 if player_hp * 2 >= player_max_hp else 0) + (1 if boss_clean else 0)

func saga_done(id: String) -> bool:
	return progress.get("saga") is Dictionary and (progress["saga"] as Dictionary).has(id)

const SAGA_BOOK_UNLOCK := 3   # capítulos do livro anterior para abrir o seguinte

## Capítulo da História disponível. Livro I: o 1.º sempre; os outros depois do anterior.
## Livro II (0.12.0, as dez guildas): abre ao acabar 3 capítulos do Livro I; aí estão todos disponíveis.
## Livro III (0.13.0, o Rival): abre com 3 capítulos do Livro II; os capítulos seguem-se por ordem.
func saga_unlocked(index: int) -> bool:
	if index < 0 or index >= CardDB.saga.size():
		return false
	var book := saga_book(index)
	if book >= 2 and not saga_book_open(book):
		return false
	if book == 2:
		return true
	for i in range(index - 1, -1, -1):
		if saga_book(i) == book:
			return saga_done(String(CardDB.saga[i].get("id", "")))
	return true

func saga_book(index: int) -> int:
	return int(CardDB.saga[index].get("book", 1)) if index >= 0 and index < CardDB.saga.size() else 1

func saga_book_open(book: int) -> bool:
	if book <= 1:
		return true
	var done := 0
	for ch in CardDB.saga:
		if int(ch.get("book", 1)) == book - 1 and saga_done(String(ch.get("id", ""))):
			done += 1
	return done >= SAGA_BOOK_UNLOCK

# --- 0.17.0: eventos em cadeia (93) ---
# Histórias em 3 partes (events.json: "chain", "part"; as opções têm "if" = só aparece com esta escolha feita
# antes e "set" = a escolha que fica registada). Só na campanha e no Modo Livre (runs de 8 antes). Cada parte
# aparece num ato mais à frente do que a anterior: o mapa guarda-lhe a paragem alternativa do 1.º ante do ato
# (chain_marked) e qualquer outro Evento desse ato também a mostra. Se a saltares, espera pelo ato seguinte.

const CHAIN_PARTS := 3

## A história desta run: uma das que existem, sorteada pela semente.
func _pick_chain() -> String:
	var ids: Array = []
	for e in CardDB.events:
		if int(e.get("part", 0)) == 1 and String(e.get("chain", "")) != "":
			ids.append(String(e["chain"]))
	if ids.is_empty():
		return ""
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 61 + 3
	return String(ids[r.randi_range(0, ids.size() - 1)])

## Id do evento da parte seguinte da história ("" se já acabou ou não há).
func chain_next_event() -> String:
	if chain_id == "" or chain_part >= CHAIN_PARTS:
		return ""
	var id := "chain_%s_%d" % [chain_id, chain_part + 1]
	return id if not CardDB.get_event(id).is_empty() else ""

## A parte seguinte pode aparecer neste ante? (um ato à frente da anterior e antes do fim da run)
func chain_due(a: int) -> bool:
	if not (mode in ["campaign", "free"]) or chain_next_event() == "" or a > max_ante or puzzle_id != "":
		return false
	return act_of_ante(a) > chain_last_act

## O mapa guarda a paragem alternativa deste ante para a história? (o 1.º ante de cada ato, se não for de boss)
func chain_marked(a: int) -> bool:
	if not chain_due(a) or is_boss_ante(a):
		return false
	return a <= 1 or act_of_ante(a - 1) < act_of_ante(a)

## Escolheste uma opção de um evento: numa história em cadeia guarda a escolha e avança a parte.
func chain_option_chosen(ev: Dictionary, opt: Dictionary) -> void:
	var cid := String(ev.get("chain", ""))
	if cid == "" or cid != chain_id:
		return
	var tag := String(opt.get("set", ""))
	if tag != "" and not (tag in chain_tags):
		chain_tags.append(tag)
	chain_part = maxi(chain_part, int(ev.get("part", 1)))
	chain_last_act = act_of_ante(ante)
	if chain_part >= CHAIN_PARTS:
		if not (progress.get("chains") is Dictionary):
			progress["chains"] = {}
		progress["chains"][cid] = true
		Stats.set_at_least("chains_done", (progress["chains"] as Dictionary).size())
		save_progress()

## Os números do JSON chegam como float: `1 in [1.0]` é falso no Godot, por isso compara-se a int.
static func _act_in(act: int, acts: Array) -> bool:
	for a in acts:
		if int(a) == act:
			return true
	return false

## Evento para o nó "evento" (ou "" se não houver). Não repete na mesma run.
## 0.17.0: se a parte seguinte da história em cadeia já pode aparecer, é ela.
func pick_event() -> String:
	if chain_due(ante):
		var cev := chain_next_event()
		seen_events.append(cev)
		return cev
	var act := act_of_deck()
	var pool: Array = CardDB.events.filter(func(e):
		return _act_in(act, e.get("acts", [1, 2, 3])) and not (String(e.get("id", "")) in seen_events))
	if pool.is_empty():
		seen_events.clear()   # quando esgotam (ou no infinito) voltam a poder repetir-se
		pool = CardDB.events.filter(func(e): return _act_in(act, e.get("acts", [1, 2, 3])))
	if pool.is_empty():
		return ""
	var ev: Dictionary = pool[rng.randi_range(0, pool.size() - 1)]
	seen_events.append(String(ev.get("id", "")))
	return String(ev.get("id", ""))

# --- Clima Planar (uma regra global por ato; no infinito muda de 2 em 2 antes) ---

func climate_key(a: int) -> String:
	if a > max_ante:
		return "E%d" % int((a - max_ante - 1) / 2)
	return str(act_of_ante(a))

## Id do clima de um ante (sorteado por run, guardado; o ato I só tira climas com min_act 1).
func climate_for_ante(a: int) -> String:
	if CardDB.climates.is_empty() or puzzle_id != "" or mode in ["tower", "rush"]:   # 0.17.0: sem clima fora das runs
		return ""
	var key := climate_key(a)
	if climates.has(key):
		return String(climates[key])
	var act := act_of_ante(a)
	var used: Array = climates.values()
	var pool: Array = CardDB.climates.filter(func(c): return int(c.get("min_act", 1)) <= act and not (String(c.get("id", "")) in used))
	if pool.is_empty():
		pool = CardDB.climates.filter(func(c): return int(c.get("min_act", 1)) <= act)
	if pool.is_empty():
		return ""
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 131 + key.hash()
	var id := String(pool[r.randi_range(0, pool.size() - 1)].get("id", ""))
	climates[key] = id
	return id

## Clima da batalha atual ("" nos quebra-cabeças).
func current_climate_id() -> String:
	if puzzle_id != "":
		return ""
	return climate_for_ante(ante)

# --- Contratos ---

func set_contract(id: String) -> void:
	contract = CardDB.get_contract(id).duplicate(true)

## Avalia o contrato ativo no fim da batalha (vitória obrigatória) e entrega a recompensa.
## Devolve {"success": bool, "text": String}; o contrato sai sempre (cumprido ou não).
func resolve_contract(bm: BattleManager, victory: bool) -> Dictionary:
	if contract.is_empty():
		return {}
	var c: Dictionary = contract
	contract = {}
	var cond: Dictionary = c.get("cond", {})
	var ok := victory
	if ok and cond.has("win_by_turn"):
		ok = bm.turn <= int(cond["win_by_turn"])
	if ok and cond.get("no_channel", false):
		ok = bm.discards_used == 0
	if ok and cond.get("no_damage", false):
		ok = bm.life_lost == 0
	if ok and cond.has("big_hit_pct"):
		ok = bm.best_hit_pct >= float(cond["big_hit_pct"])
	if ok and cond.has("formations"):
		ok = bm.max_formations >= int(cond["formations"])
	if ok and cond.has("attackers"):
		ok = bm.max_attackers >= int(cond["attackers"])
	if ok and cond.has("flashbacks"):
		ok = bm.flashbacks_used >= int(cond["flashbacks"])
	if ok and cond.get("no_lands", false):
		ok = bm.lands_played == 0
	var name := TranslationServer.translate(String(c.get("name", "")))
	var result := {"success": ok, "text": ""}
	if ok:
		var parts := apply_reward(c.get("reward", {}))
		Stats.on_contract_done()
		result["text"] = TranslationServer.translate("Contrato cumprido: %s") % name + ("  ·  " + ", ".join(PackedStringArray(parts)) if not parts.is_empty() else "")
	else:
		result["text"] = TranslationServer.translate("Contrato falhado: %s") % name
	EventBus.contract_resolved.emit(ok, String(result["text"]))
	return result

## Recompensas simples (contratos): gold, heal, max_hp, relic "random", card "rare"/"random".
## Devolve as linhas de texto do que foi dado.
func apply_reward(reward: Dictionary) -> Array[String]:
	var parts: Array[String] = []
	if int(reward.get("gold", 0)) != 0:
		add_gold(int(reward["gold"]))
		parts.append(TranslationServer.translate("+%d ouro") % int(reward["gold"]))
	if int(reward.get("heal", 0)) > 0:
		heal(int(reward["heal"]))
		parts.append(TranslationServer.translate("Curas %d.") % int(reward["heal"]))
	if int(reward.get("max_hp", 0)) != 0:
		change_max_hp(int(reward["max_hp"]))
		parts.append(TranslationServer.translate("Vida máxima +%d.") % int(reward["max_hp"]))
	if String(reward.get("relic", "")) != "":
		var id := random_new_relic()
		if id != "" and add_relic(id):
			parts.append(TranslationServer.translate("Recebes a relíquia %s.") % TranslationServer.translate(String(CardDB.relics[id].get("name", id))))
		else:
			add_gold(8)
			parts.append(TranslationServer.translate("+%d ouro") % 8)
	if String(reward.get("card", "")) != "":
		var cd := CardDB.random_card_for_deck(rng, "rare" if String(reward["card"]) == "rare" else "")
		if cd != null:
			add_card(cd.id)
			parts.append(TranslationServer.translate("%s juntou-se ao baralho.") % TranslationServer.translate(cd.name))
	return parts

## Texto curto da recompensa de um contrato (para a lista de escolha).
static func reward_text(reward: Dictionary) -> String:
	var parts: Array[String] = []
	if int(reward.get("gold", 0)) > 0:
		parts.append(TranslationServer.translate("+%d ouro") % int(reward["gold"]))
	if int(reward.get("heal", 0)) > 0:
		parts.append(TranslationServer.translate("cura %d") % int(reward["heal"]))
	if String(reward.get("relic", "")) != "":
		parts.append(TranslationServer.translate("uma relíquia"))
	if String(reward.get("card", "")) == "rare":
		parts.append(TranslationServer.translate("uma carta rara"))
	return ", ".join(PackedStringArray(parts))

func next_ante() -> void:
	map_history[str(ante)] = map_choice.duplicate()
	ante += 1
	map_choice = {}
	map_phase = "battle"
	_resolve_later()
	_maybe_add_endless_curse()
	EventBus.ante_started.emit(ante)

## Nó escolhido num ante já passado ("" se não se sabe).
func map_chosen(a: int, phase: String) -> String:
	if a == ante:
		return String(map_choice.get(phase, ""))
	return String((map_history.get(str(a), {}) as Dictionary).get(phase, ""))

# --- Mapa da run (nós por ante) ---

## Opções deste ante: {"battle": ["scout","guard"] ou ["boss"], "stop": ["shop", X]}. Determinístico
## por run (semente própria, para não mexer no RNG das batalhas).
func map_options(a: int) -> Dictionary:
	var key := str(a)
	if map_plan.has(key):
		return map_plan[key]
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 31 + a * 7919
	var battle: Array = ["boss"] if is_boss_ante(a) else ["scout", "guard"]
	if not is_boss_ante(a) and nemesis_level(a) > 0 and not nemesis_def().is_empty():
		battle.append("nemesis")   # a Némesis ocupa o lugar da Elite
		r.randf()
	elif not is_boss_ante(a) and a >= 2 and r.randf() < ELITE_CHANCE:
		battle.append("elite")
	var stop: Array = ["shop"]
	if is_boss_ante(a):
		stop.append("merchant")
	else:
		var weights := {"event": 3.0, "rest": 2.0, "contracts": 1.5, "treasure": 1.0, "library": 1.0}
		if a >= 2:
			weights["spring"] = 1.0
			weights["tribunal"] = 1.0
			weights["sanctuary"] = 1.0
			weights["arena"] = 1.2
			weights["forge"] = 1.2    # 0.13.0: Forja das Edições
			weights["vault"] = 1.0    # 0.13.0: Cofre
		if a >= 3:
			weights["altar"] = 1.0
			weights["merchant"] = 1.0
		var total := 0.0
		for k in weights:
			total += weights[k]
		var roll := r.randf() * total
		var picked := "event"
		for k in weights:
			roll -= weights[k]
			if roll <= 0.0:
				picked = k
				break
		if chain_marked(a):   # 0.17.0: a parte seguinte da história em cadeia espera num Evento
			picked = "event"
		stop.append(picked)
	# 0.18.0 (24, 25): às vezes um nó especial (sorteio próprio: não mexe nos sorteios de antes).
	if not is_boss_ante(a) and a >= 2:
		var r2 := RandomNumberGenerator.new()
		r2.seed = seed_value * 53 + a * 104729
		if r2.randf() < SPECIAL_CHANCE:
			var kinds: Array = ["ambush", "siege", "escape"]
			if a >= PAIR_FROM:
				kinds.append("pair")
			var special := String(kinds[r2.randi_range(0, kinds.size() - 1)])
			if battle.size() >= 3:
				battle[1] = special
			else:
				battle.append(special)
	var opts := {"battle": battle, "stop": stop}
	map_plan[key] = opts
	return opts

## Regista a escolha de um nó do mapa.
func choose_battle(kind: String) -> void:
	map_choice["battle"] = kind
	map_phase = "battle"

func choose_stop(kind: String) -> void:
	map_choice["stop"] = kind
	map_phase = "stop"

## Cena para a paragem escolhida (e prepara o evento, se for o caso).
func stop_scene(kind: String) -> String:
	match kind:
		"shop", "merchant":
			return "shop"
		"event":
			pending_event = pick_event()
			return "event" if pending_event != "" else "shop"
		"rest", "spring", "altar", "contracts", "tribunal", "treasure", "sanctuary", "forge", "library", "vault":
			pending_event = "node_" + kind
			return "event"
		"arena":
			arena_battle = true
			map_choice["battle_arena"] = true
			return "battle"
	return "shop"

## Inimigo da Arena: um inimigo normal deste ante com +50 % de vida e +2 de ataque (3 turnos).
func pick_arena_enemy() -> Dictionary:
	var before = map_choice.get("battle", null)
	map_choice["battle"] = "arena"
	var def := pick_enemy(ante)
	if before == null:
		map_choice.erase("battle")
	else:
		map_choice["battle"] = before
	return def

## Fim da batalha da Arena (0.12.0): vencer dá uma relíquia e ouro; perder custa vida (nunca a run).
## Devolve o texto do resultado.
func finish_arena(victory: bool) -> String:
	arena_battle = false
	if victory:
		add_gold(ARENA_GOLD)
		var id := random_new_relic()
		if id != "" and add_relic(id):
			return tr("Arena vencida: +%d ouro e %s.") % [ARENA_GOLD, tr(String(CardDB.relics[id].get("name", id)))]
		add_gold(ARENA_GOLD)
		return tr("Arena vencida: +%d ouro.") % (ARENA_GOLD * 2)
	player_hp = maxi(1, player_hp - ARENA_LOSS)
	EventBus.player_hp_changed.emit(player_hp, player_max_hp)
	return tr("Perdeste na Arena: −%d de vida. A run continua.") % ARENA_LOSS

## Alvo de "vida" do inimigo por ante — tabela afinada por simulação (tests/Balance.gd),
## multiplicada pela dificuldade. Para lá do 8: ×1,6 por ante (Eternidade Cega).
## 0.11.0: curva mais suave a partir do ante 3 (antes: 3k, 7k, 14k, 24k, 46k, 78k, 125k, 190k) — o bot passou
## de 34 % para ~55–60 % de runs ganhas no Normal (tests/Balance.gd).
const ANTE_HP := [3000, 6500, 8700, 14900, 28500, 48400, 77500, 118000]

## Curva de vida em uso (o teste de equilíbrio pode trocá-la com --ante-hp=…).
var ante_hp: Array = ANTE_HP.duplicate()

func enemy_hp_for_ante(a: int) -> int:
	var base: float
	if a <= ante_hp.size():
		base = float(ante_hp[a - 1])
	else:
		base = float(ante_hp[-1]) * pow(1.6, a - ante_hp.size())
	return int(round(base * DIFFICULTY_HP.get(difficulty, 1.0)))

var base_turns := 5   # turnos por batalha (o teste de equilíbrio pode trocá-los com --turns=…)

func turns_for_ante(_a: int) -> int:
	if arena_battle:
		return ARENA_TURNS
	var t := int(run_rule("turns", base_turns + int(DIFFICULTY_EXTRA_TURNS.get(difficulty, 0))))
	if Economy.risk_is("turn"):   # 0.19.0 (100): risco aceite — menos 1 turno
		t = maxi(2, t - 1)
	if not endless_curses.is_empty():   # 0.13.0 Maldição da Pressa (Infinito)
		t = maxi(mini(t, 3), t - int(endless_value("turns_minus")))
	return t

func difficulty_name() -> String:
	return DIFFICULTY_NAMES.get(difficulty, difficulty)

## O que a dificuldade muda, numa linha (ecrã da campanha e Configurações).
func difficulty_text() -> String:
	var t := tr("%s: inimigos com %d%% da vida, %d canalizações e %d turnos por batalha.") % [tr(difficulty_name()), int(round(float(DIFFICULTY_HP.get(difficulty, 1.0)) * 100.0)), int(DIFFICULTY_DISCARDS.get(difficulty, 3)), base_turns + int(DIFFICULTY_EXTRA_TURNS.get(difficulty, 0))]
	if DIFFICULTY_ATTACK.has(difficulty):
		t += " " + tr("Os inimigos atacam +%d.") % int(DIFFICULTY_ATTACK[difficulty])
	if difficulty == "dificil" and not nightmare_unlocked():
		t += " " + tr("Vence uma run no Difícil para abrir o Pesadelo.")
	return t

func cycle_difficulty() -> void:
	var i := DIFFICULTIES.find(difficulty)
	difficulty = DIFFICULTIES[(i + 1) % DIFFICULTIES.size()]
	if difficulty == "pesadelo" and not nightmare_unlocked():
		difficulty = DIFFICULTIES[0]   # o Pesadelo só aparece depois de venceres uma run no Difícil
	progress["difficulty"] = difficulty
	save_progress()

## 0.13.0: o Pesadelo abre-se ao vencer uma run no Difícil.
func nightmare_unlocked() -> bool:
	return Stats.get_stat("wins_hard") > 0 or Stats.get_stat("wins_nightmare") > 0

# ---------------------------------------------------------------------------
# Gravação da run (para "Continuar"). Grava-se no início de cada turno (com o estado da
# batalha), no mapa e ao entrar/sair da loja; retomar coloca o jogador exatamente nesse ponto.
# ---------------------------------------------------------------------------

func save_run(battle_state: Dictionary = {}, scene: String = "battle") -> void:
	if puzzle_id != "":
		return   # os quebra-cabeças não se gravam
	var data := {
		"version": 4,
		"deck_id": deck_def.get("id", "deck01"),
		"deck_def": deck_def if deck_def.get("custom", false) else {},
		"deck": deck,
		"relic_ids": relic_ids,
		"relic_locked": relic_locked,
		"ante": ante,
		"max_ante": max_ante,
		"gold": gold,
		"seed": seed_value,
		"rng_state": rng.state,
		"difficulty": difficulty,
		"free_mode": free_mode,
		"mode": mode,
		"stake": stake,
		"scene": scene,
		"battle": battle_state,
		"player_hp": player_hp,
		"player_max_hp": player_max_hp,
		"interest_ante": interest_ante,
		"seen_events": seen_events,
		"pending_event": pending_event,
		"current_enemy_id": current_enemy_id,
		"pair_enemy_id": pair_enemy_id,
		"endless": endless,
		"planeswalker": planeswalker,
		"formation_levels": formation_levels,
		"map_plan": map_plan,
		"map_choice": map_choice,
		"map_history": map_history,
		"map_phase": map_phase,
		"boss_relics": boss_relics,
		"loot_offer": loot_offer,
		"climates": climates,
		"contract": contract,
		"death_save_used": death_save_used,
		"relic_counters": relic_counters,
		"interlude_key": interlude_key,
		"run_channels": Stats.run_channels,
		"vouchers": vouchers,
		"nemesis_id": nemesis_id,
		"nemesis_beaten": nemesis_beaten,
		"challenge_id": challenge_id,
		"saga_id": saga_id,
		"run_log": run_log,
		"deck_log": deck_log,
		"run_talents": run_talents,
		"name": run_name,
		"bosses_seen": bosses_seen,
		"milestones_claimed": milestones_claimed,
		"blessings": blessings,
		"run_variant": run_variant,
		"next_enemy_weaken": next_enemy_weaken,
		"arena_battle": arena_battle,
		"consumables": consumables,
		"endless_curses": endless_curses,
		"pact_offer": pact_offer,
		"chain": {"id": chain_id, "part": chain_part, "tags": chain_tags, "last_act": chain_last_act},
		"tower": {"phase": tower_phase, "offer": tower_offer},
		"rush": {"list": rush_list, "turns": rush_turns},
		"pending_later": pending_later,
		"later_notes": later_notes,
		"boss_clean": boss_clean,
		"econ": econ,   # 0.19.0 (secção 3)
	}
	# 0.19.0 (254): igual à última gravação (tirando a hora)? Não volta a escrever.
	var cmp := JSON.stringify(data)
	if String(_last_run_text.get(current_slot, "")) == cmp and has_saved_run():
		return
	data["saved_at"] = Time.get_unix_time_from_system()
	if not SaveIO.write_json(run_save_path(), data, true):   # 0.19.0 (225, 226): atómico e com cópia .bak
		return
	_last_run_text[current_slot] = cmp
	_slot_cache.erase(current_slot)
	EventBus.run_saved.emit(current_slot)   # 0.13.0: aviso discreto "Guardado em Jogo N"

# --- Talentos permanentes (0.11.0) ---
# progress.talents = {id: nível}, progress.talent_points = pontos por gastar, progress.talents_off = desligados.

func talent_level(id: String) -> int:
	return int((progress["talents"] as Dictionary).get(id, 0)) if progress.get("talents") is Dictionary else 0

func talent_points() -> int:
	return int(progress.get("talent_points", 0))

func talents_enabled() -> bool:
	return not bool(progress.get("talents_off", false))

func set_talents_enabled(on: bool) -> void:
	progress["talents_off"] = not on
	save_progress()

## Custo do próximo nível (-1 se já estiver no máximo).
func talent_next_cost(id: String) -> int:
	var t := CardDB.get_talent(id)
	var costs: Array = t.get("costs", [])
	var lv := talent_level(id)
	return int(costs[lv]) if lv < costs.size() else -1

# --- Níveis de baralho e variantes (0.12.0) ---
# Cada baralho da campanha ganha experiência nas runs (o ante a que chegaste, +3 se venceste) e sobe de
# nível (1–4). Cada nível abre uma variante para começar a run: Clássico, Afiado, Rico e Lendário.

const DECK_LEVEL_XP := [0, 8, 20, 40]
const DECK_VARIANTS := ["classic", "sharp", "rich", "legend"]
const DECK_VARIANT_NAMES := {"classic": "Clássico", "sharp": "Afiado", "rich": "Rico", "legend": "Lendário"}
const DECK_VARIANT_TEXT := {
	"classic": "O baralho de sempre.",
	"sharp": "Saem as 2 cartas com menos Poder; uma criatura ao acaso recebe o Selo da Fúria.",
	"rich": "+10 ouro e uma relíquia comum ao acaso, mas −4 de vida máxima.",
	"legend": "Uma carta rara extra das cores do baralho e +5 Poder em todas as criaturas.",
}
var run_variant: String = "classic"

func deck_xp(deck_id: String) -> int:
	var d = progress.get("deck_xp", {})
	return int((d as Dictionary).get(deck_id, 0)) if d is Dictionary else 0

func deck_level(deck_id: String) -> int:
	var xp := deck_xp(deck_id)
	var lv := 1
	for i in DECK_LEVEL_XP.size():
		if xp >= int(DECK_LEVEL_XP[i]):
			lv = i + 1
	return lv

## Experiência para o nível seguinte (-1 no máximo).
func deck_next_xp(deck_id: String) -> int:
	var lv := deck_level(deck_id)
	return int(DECK_LEVEL_XP[lv]) if lv < DECK_LEVEL_XP.size() else -1

func deck_variants(deck_id: String) -> Array:
	return DECK_VARIANTS.slice(0, deck_level(deck_id))

func _add_deck_xp(reached_ante: int, victory: bool) -> void:
	var id := String(deck_def.get("id", ""))
	if not id.begins_with("deck") or mode in ["draft", "challenge", "saga"]:
		return
	if not (progress.get("deck_xp") is Dictionary):
		progress["deck_xp"] = {}
	var before := deck_level(id)
	progress["deck_xp"][id] = deck_xp(id) + maxi(0, reached_ante) + (3 if victory else 0)
	if deck_level(id) > before:
		last_unlocks.append(tr("%s subiu ao nível %d (variante %s)") % [tr(String(deck_def.get("name", ""))), deck_level(id), tr(String(DECK_VARIANT_NAMES.get(DECK_VARIANTS[deck_level(id) - 1], "")))])
		for bid in Stats.check_deck_backs():   # 0.16.1 (V8): nível 4 = as costas do baralho
			last_unlocks.append(Stats.unlock_label({"type": "back", "id": bid}, "%s: %s"))

# --- 0.16.1 (V12): costas por baralho ---
# progress.deck_backs = {id do baralho (também "custom_N"): id das costas}. Sem escolha, usam-se as das
# Configurações (Settings.card_back).

## As costas escolhidas para um baralho ("" = as das Configurações; também se deixaram de estar desbloqueadas).
func deck_back(deck_id: String) -> String:
	var m = progress.get("deck_backs", {})
	var id := String((m as Dictionary).get(deck_id, "")) if m is Dictionary else ""
	if id == "" or CardDB.get_cosmetic("back", id).is_empty():
		return ""
	return id if id == "classic" or Stats.is_content_unlocked("back", id) else ""

func set_deck_back(deck_id: String, back_id: String) -> void:
	if deck_id == "":
		return
	if not (progress.get("deck_backs") is Dictionary):
		progress["deck_backs"] = {}
	if back_id == "":
		(progress["deck_backs"] as Dictionary).erase(deck_id)
	else:
		progress["deck_backs"][deck_id] = back_id
	save_progress()

## As costas da run: as do baralho em jogo, se tiver umas escolhidas; senão as das Configurações.
## 0.19.0 (300): com «cosméticos ao acaso», as sorteadas no início da run.
func run_back() -> String:
	var rc = run_log.get("cosm", {})
	if rc is Dictionary and (rc as Dictionary).has("back"):
		return String(rc["back"])
	var d := deck_back(String(deck_def.get("id", ""))) if not deck_def.is_empty() else ""
	return d if d != "" else Settings.card_back

# --- 0.19.0 (299, 300): moldura, tapete e efeito do golpe por baralho (como as costas), e ao acaso por run ---
const DECK_COSMETIC_KINDS := ["frame", "mat", "effect"]

func deck_cosmetic(kind: String, deck_id: String) -> String:
	if kind == "back":
		return deck_back(deck_id)
	var all = progress.get("deck_cosmetics", {})
	var m = (all as Dictionary).get(kind, {}) if all is Dictionary else {}
	var id := String((m as Dictionary).get(deck_id, "")) if m is Dictionary else ""
	return id if id != "" and id in Settings.unlocked_cosmetics(kind) else ""

func set_deck_cosmetic(kind: String, deck_id: String, id: String) -> void:
	if kind == "back":
		set_deck_back(deck_id, id)
		return
	if deck_id == "":
		return
	if not (progress.get("deck_cosmetics") is Dictionary):
		progress["deck_cosmetics"] = {}
	if not (progress["deck_cosmetics"].get(kind) is Dictionary):
		progress["deck_cosmetics"][kind] = {}
	if id == "":
		(progress["deck_cosmetics"][kind] as Dictionary).erase(deck_id)
	else:
		progress["deck_cosmetics"][kind][deck_id] = id
	save_progress()

## O cosmético em uso agora: numa cena da run, o sorteado (300) ou o do baralho (299); fora dela, o das Configurações.
func run_cosmetic(kind: String) -> String:
	if kind == "back":
		return run_back() if not deck.is_empty() and SceneRouter.in_run() else Settings.cosmetic("back")
	if deck.is_empty() or not SceneRouter.in_run():
		return Settings.cosmetic(kind)
	var rc = run_log.get("cosm", {})
	if rc is Dictionary and (rc as Dictionary).has(kind):
		return String(rc[kind])
	var d := deck_cosmetic(kind, String(deck_def.get("id", "")))
	return d if d != "" else Settings.cosmetic(kind)

## 300: sorteia costas, moldura, tapete e efeito entre os desbloqueados (só com a opção ligada).
func roll_random_cosmetics() -> void:
	if not bool(Settings.opt("random_cosmetics")):
		return
	var cosm := {}
	for kind in ["back", "frame", "mat", "effect"]:
		var list := Settings.unlocked_cosmetics(kind)
		if not list.is_empty():
			cosm[kind] = String(list[randi() % list.size()])
	run_log["cosm"] = cosm

## Aplica a variante escolhida no início da run (depois de new_run e dos talentos).
func apply_deck_variant(v: String) -> void:
	run_variant = v if v in DECK_VARIANTS else "classic"
	match run_variant:
		"sharp":
			var idxs: Array = []
			for i in deck.size():
				var cd := CardDB.get_card(String(deck[i].get("id", "")))
				if cd != null and not cd.is_land():
					idxs.append(i)
			idxs.sort_custom(func(a, b): return CardDB.get_card(String(deck[a]["id"])).power < CardDB.get_card(String(deck[b]["id"])).power)
			var drop: Array = idxs.slice(0, mini(2, maxi(0, deck.size() - 6)))
			drop.sort()
			for k in range(drop.size() - 1, -1, -1):
				deck.remove_at(int(drop[k]))
			var creatures: Array = []
			for i in deck.size():
				var cd2 := CardDB.get_card(String(deck[i].get("id", "")))
				if cd2 != null and cd2.is_creature() and String(deck[i].get("seal", "")) == "":
					creatures.append(i)
			if not creatures.is_empty():
				deck[creatures[rng.randi_range(0, creatures.size() - 1)]]["seal"] = "fury"
		"rich":
			add_gold(10)
			var rid := random_new_relic()
			if rid != "" and relics_allowed():
				add_relic(rid)
			change_max_hp(-4)
		"legend":
			var c := CardDB.random_card_for_deck(rng, "rare")
			if c != null:
				deck.append(_new_entry(c.id))
			for e in deck:
				var cd3 := CardDB.get_card(String(e.get("id", "")))
				if cd3 != null and cd3.is_creature():
					e["power_bonus"] = int(e.get("power_bonus", 0)) + 5

## Árvore de talentos (0.12.0): 3 ramos (Economia, Combate, Sobrevivência); os talentos do nível 2
## pedem 5 pontos gastos nesse ramo e os do nível 3 pedem 12.
const TALENT_BRANCHES := ["economy", "combat", "survival"]
const TALENT_BRANCH_NAMES := {"economy": "Economia", "combat": "Combate", "survival": "Sobrevivência"}
const TALENT_TIER_POINTS := {1: 0, 2: 5, 3: 12}

## Pontos gastos num ramo.
func talent_branch_spent(branch: String) -> int:
	var spent := 0
	for t in CardDB.talents:
		if String(t.get("branch", "")) != branch:
			continue
		var costs: Array = t.get("costs", [])
		for i in mini(talent_level(String(t.get("id", ""))), costs.size()):
			spent += int(costs[i])
	return spent

## O nível do talento já está aberto no seu ramo?
func talent_tier_open(id: String) -> bool:
	var t := CardDB.get_talent(id)
	var need := int(TALENT_TIER_POINTS.get(int(t.get("tier", 1)), 0))
	return talent_branch_spent(String(t.get("branch", ""))) >= need

func buy_talent(id: String) -> bool:
	var cost := talent_next_cost(id)
	if cost < 0 or talent_points() < cost or not talent_tier_open(id):
		return false
	if not (progress.get("talents") is Dictionary):
		progress["talents"] = {}
	progress["talents"][id] = talent_level(id) + 1
	progress["talent_points"] = talent_points() - cost
	var bought := 0
	for k in progress["talents"]:
		bought += int(progress["talents"][k])
	Stats.set_at_least("talents_bought", bought)
	save_progress()
	return true

## Devolve todos os pontos gastos (para os voltar a distribuir).
func reset_talents() -> void:
	var refund := 0
	for t in CardDB.talents:
		var costs: Array = t.get("costs", [])
		for i in mini(talent_level(String(t.get("id", ""))), costs.size()):
			refund += int(costs[i])
	progress["talents"] = {}
	progress["talent_points"] = talent_points() + refund
	save_progress()

func talent_value(effect: String) -> float:
	return float(run_talents.get(effect, 0.0))

## Início da run (campanha, Modo Livre, História e Draft — os Desafios ficam de fora): copia os
## talentos para a run e aplica os de arranque (ouro, vida, relíquia, Poder das criaturas).
func apply_talents() -> void:
	run_talents = {}
	if not talents_enabled() or challenge_id != "":
		return
	for t in CardDB.talents:
		var lv := talent_level(String(t.get("id", "")))
		var values: Array = t.get("values", [])
		if lv > 0 and not values.is_empty():
			run_talents[String(t.get("effect", ""))] = float(values[mini(lv, values.size()) - 1])
	if talent_value("start_gold") > 0.0:
		add_gold(int(talent_value("start_gold")))
		Economy.credit_talent("start_gold", int(talent_value("start_gold")))   # 0.19.0 (99)
	if talent_value("max_hp") > 0.0:
		player_max_hp += int(talent_value("max_hp"))
		player_hp += int(talent_value("max_hp"))
		EventBus.player_hp_changed.emit(player_hp, player_max_hp)
	if talent_value("start_power") > 0.0 or talent_value("start_mult") > 0.0:
		for e in deck:
			var cd := CardDB.get_card(String(e.get("id", "")))
			if cd != null and cd.is_creature():
				e["power_bonus"] = int(e.get("power_bonus", 0)) + int(talent_value("start_power"))
				if talent_value("start_mult") > 0.0:
					e["mult_bonus"] = float(e.get("mult_bonus", 0.0)) + talent_value("start_mult")
	if talent_value("start_relic") > 0.0 and relics_allowed():
		var pool: Array = CardDB.relics.keys().filter(func(r): return String(CardDB.relics[r].get("rarity", "common")) == "common" and not bool(CardDB.relics[r].get("legendary", false)) and not bool(CardDB.relics[r].get("boss", false)) and CardDB.is_relic_available(CardDB.relics[r]) and not (r in relic_ids))
		if not pool.is_empty():
			add_relic(String(pool[rng.randi_range(0, pool.size() - 1)]))

## Escola do Mago (0.11.0): lições feitas (progress.lessons) e começar uma lição (batalha de 1 turno).
func lesson_done(id: String) -> bool:
	return progress.get("lessons") is Dictionary and (progress["lessons"] as Dictionary).has(id)

func mark_lesson_done(id: String) -> void:
	if not (progress.get("lessons") is Dictionary):
		progress["lessons"] = {}
	progress["lessons"][id] = true
	save_progress()
	var done := 0
	for l in CardDB.lessons:
		if lesson_done(String(l.get("id", ""))):
			done += 1
	Stats.set_at_least("lessons", done)

func start_lesson(id: String) -> void:
	reset_for_side_battle(id)
	# 0.12.0: a lição do planeswalker traz o seu.
	var def := CardDB.get_lesson(id)
	if String(def.get("planeswalker", "")) != "":
		var pw := CardDB.get_planeswalker(String(def["planeswalker"]))
		if not pw.is_empty():
			planeswalker = {"id": String(pw["id"]), "loyalty": int(def.get("loyalty", pw.get("loyalty", 2)))}

func is_lesson_battle() -> bool:
	return puzzle_id.begins_with("lesson_")

## Dicas (0.11.0): ids já mostrados (progress.tips_seen).
func tip_seen(id: String) -> bool:
	return progress.get("tips_seen") is Array and id in (progress["tips_seen"] as Array)

func mark_tip_seen(id: String) -> void:
	if not (progress.get("tips_seen") is Array):
		progress["tips_seen"] = []
	if not (id in progress["tips_seen"]):
		(progress["tips_seen"] as Array).append(id)
		save_progress()

func reset_tips() -> void:
	progress["tips_seen"] = []
	save_progress()

# --- Espaços de gravação ---

func slot_path(slot: int) -> String:
	return Profiles.path("run_slot%d.json" % clampi(slot, 1, SLOT_COUNT))   # 0.19.0: do perfil em uso

func run_save_path() -> String:
	return slot_path(current_slot)

## Até à 0.11.0 havia um só ficheiro (run.json): passa para o primeiro espaço livre.
func _migrate_legacy_run() -> void:
	if Profiles.active() != 1 or not FileAccess.file_exists(LEGACY_RUN_SAVE):
		return
	var target := first_free_slot()
	if target == 0:
		return
	DirAccess.rename_absolute(ProjectSettings.globalize_path(LEGACY_RUN_SAVE), ProjectSettings.globalize_path(slot_path(target)))
	_slot_cache.clear()

## Há uma run gravada no espaço `slot` (0 = o espaço atual).
func has_saved_run(slot: int = 0) -> bool:
	return FileAccess.file_exists(slot_path(slot if slot > 0 else current_slot))

func has_any_saved_run() -> bool:
	return saved_slot_count() > 0

func saved_slot_count() -> int:
	var n := 0
	for i in range(1, SLOT_COUNT + 1):
		if FileAccess.file_exists(slot_path(i)):
			n += 1
	return n

## Primeiro espaço vazio (0 se estiverem todos ocupados).
func first_free_slot() -> int:
	for i in range(1, SLOT_COUNT + 1):
		if not FileAccess.file_exists(slot_path(i)):
			return i
	return 0

## Espaço com a run gravada há menos tempo (0 se não houver nenhuma) — o CONTINUAR do menu.
func latest_slot() -> int:
	var best := 0
	var best_t := -1.0
	for i in range(1, SLOT_COUNT + 1):
		var info := slot_info(i)
		if info.is_empty():
			continue
		var t := float(info.get("saved_at", 0.0))
		if t > best_t:
			best_t = t
			best = i
	return best

## Nome do espaço: o que o jogador escreveu ou "Jogo N".
func slot_name(slot: int) -> String:
	var info := slot_info(slot)
	var n := String(info.get("name", ""))
	return n if n != "" else tr("Jogo %d") % slot

## Resumo de um espaço para o menu ({} se estiver vazio): nome, o que se joga, ante, modo,
## dificuldade, Selo, vida, ouro e quando se gravou.
func slot_info(slot: int) -> Dictionary:
	var path := slot_path(slot)
	if not FileAccess.file_exists(path):
		_slot_cache.erase(slot)
		return {}
	var mtime := FileAccess.get_modified_time(path)
	var cached: Dictionary = _slot_cache.get(slot, {})
	if not cached.is_empty() and int(cached.get("mtime", -1)) == mtime:
		return cached["info"]
	var parsed = SaveIO.read_json(path)   # 0.19.0 (227): estragado → a cópia .bak
	if not (parsed is Dictionary):
		return {}
	var info := _run_summary(parsed, slot, float(mtime))
	_slot_cache[slot] = {"mtime": mtime, "info": info}
	return info

## Resumo de uma run gravada (o dicionário do ficheiro): o que se joga, ante, modo, dificuldade…
func _run_summary(parsed: Dictionary, slot: int, fallback_time: float) -> Dictionary:
	var what := ""
	var ch_id := String(parsed.get("challenge_id", ""))
	var saga := String(parsed.get("saga_id", ""))
	if ch_id != "":
		what = tr("Desafio") + ": " + tr(String(CardDB.get_challenge(ch_id).get("name", "")))
	elif saga != "":
		what = tr(String(CardDB.get_saga_chapter(saga).get("name", "")))
	else:
		var def: Dictionary = parsed.get("deck_def", {}) if parsed.get("deck_def") is Dictionary else {}
		if def.is_empty():
			def = CardDB.get_deck(String(parsed.get("deck_id", "")))
		what = tr(String(def.get("name", "")))
	var info := {
		"slot": slot,
		"name": String(parsed.get("name", "")),
		"what": what,
		"ante": int(parsed.get("ante", 1)),
		"max_ante": int(parsed.get("max_ante", 8)),
		"mode": String(parsed.get("mode", "campaign")),
		"difficulty": String(parsed.get("difficulty", "normal")),
		"stake": int(parsed.get("stake", 1)),
		"hp": int(parsed.get("player_hp", 20)),
		"max_hp": int(parsed.get("player_max_hp", 20)),
		"gold": int(parsed.get("gold", 0)),
		"saved_at": float(parsed.get("saved_at", fallback_time)),
	}
	return info

# --- 0.13.0: a última run apagada ou substituída pode recuperar-se (Jogos guardados → RECUPERAR) ---

const RUN_TRASH := "user://run_trash.json"   # perfil 1; os outros perfis usam trash_path()
const TRASH_MAX := 6                         # 0.19.0 (229): até 6 runs apagadas…
const TRASH_DAYS := 7                        # …durante 7 dias

## Guarda uma cópia da run deste espaço antes de a apagar (as runs acabadas não contam). 0.19.0 (229): ficam
## as últimas TRASH_MAX durante TRASH_DAYS dias (antes era só a última).
func trash_slot(slot: int, reason: String = "") -> void:
	var path := slot_path(slot)
	if not FileAccess.file_exists(path):
		return
	var parsed = SaveIO.read_json(path)
	if not (parsed is Dictionary):
		return
	var items := _trash_items()
	items.push_front({"slot": slot, "deleted_at": Time.get_unix_time_from_system(), "reason": reason, "run": parsed})
	while items.size() > TRASH_MAX:
		items.pop_back()
	_write_trash(items)

## As runs no lixo, da mais recente para a mais antiga (as com mais de TRASH_DAYS dias saem).
func _trash_items() -> Array:
	var path := trash_path()
	if not FileAccess.file_exists(path):
		return []
	var parsed = SaveIO.read_json(path)
	var items: Array = []
	if parsed is Dictionary and parsed.get("items") is Array:
		items = parsed["items"]
	elif parsed is Dictionary and parsed.get("run") is Dictionary:   # até à 0.18.2 havia só uma
		items = [parsed]
	var now := Time.get_unix_time_from_system()
	var out: Array = []
	for it in items:
		if it is Dictionary and it.get("run") is Dictionary and now - float(it.get("deleted_at", 0.0)) <= TRASH_DAYS * 86400.0:
			out.append(it)
	return out

func _write_trash(items: Array) -> void:
	if items.is_empty():
		SaveIO.remove(trash_path())
	else:
		SaveIO.write_json(trash_path(), {"items": items})

func _read_trash() -> Dictionary:
	var items := _trash_items()
	return items[0] if not items.is_empty() else {}

func has_trash() -> bool:
	return not _trash_items().is_empty()

## Resumo da run que se pode recuperar ({} se não houver): o mesmo que slot_info, mais deleted_at.
func trash_info(index: int = 0) -> Dictionary:
	var items := _trash_items()
	if index < 0 or index >= items.size():
		return {}
	var t: Dictionary = items[index]
	var info := _run_summary(t["run"], int(t.get("slot", 1)), float(t.get("deleted_at", 0.0)))
	info["deleted_at"] = float(t.get("deleted_at", 0.0))
	info["reason"] = String(t.get("reason", ""))
	info["index"] = index
	return info

## 0.19.0 (229): todas as runs que se podem recuperar (resumos, da mais recente para a mais antiga).
func trash_list() -> Array:
	var out: Array = []
	for i in _trash_items().size():
		out.append(trash_info(i))
	return out

## Recupera a run apagada n.º index (0 = a mais recente): volta ao espaço de onde saiu (ou ao primeiro
## livre). Devolve o espaço, ou 0 se não houver nenhum livre.
func restore_trash(index: int = 0) -> int:
	var items := _trash_items()
	if index < 0 or index >= items.size():
		return 0
	var t: Dictionary = items[index]
	var slot := int(t.get("slot", 1))
	if slot < 1 or slot > SLOT_COUNT or has_saved_run(slot):
		slot = first_free_slot()
	if slot <= 0:
		return 0
	if not SaveIO.write_json(slot_path(slot), t["run"], true):
		return 0
	_slot_cache.erase(slot)
	_last_run_text.erase(slot)
	items.remove_at(index)
	_write_trash(items)
	return slot

const MODE_NAMES := {"campaign": "Campanha", "free": "Modo Livre", "draft": "Arena Draft", "challenge": "Desafio",
	"saga": "História", "quick": "Run Rápida", "tower": "Torre do Arquimago", "rush": "Corrida de Bosses",
	"skirmish": "Batalha avulsa", "mini": "Run de 2 antes", "brawl": "Só batalhas"}

func mode_name(m: String) -> String:
	return String(MODE_NAMES.get(m, "Campanha"))

## 0.17.0: onde vai uma run, numa etiqueta curta — «Ante 3/8», «Ante 11 (infinito)», «Andar 12» (Torre) ou
## «Boss 4/9» (Corrida). Traduzida.
static func stage_text(m: String, a: int, max_a: int) -> String:
	if m == "tower":
		return TranslationServer.translate("Andar %d") % a
	if m == "rush":
		return TranslationServer.translate("Boss %d/%d") % [a, max_a]
	if a > max_a:
		return TranslationServer.translate("Ante %d (infinito)") % a
	return TranslationServer.translate("Ante %d/%d") % [a, max_a]

func stage_label() -> String:
	return stage_text(mode, ante, max_ante)

## 0.17.0: um número com 1 casa decimal, com vírgula em português («2,4») e ponto em inglês («2.4»).
static func fmt_dec(v: float) -> String:
	var s := "%.1f" % v
	return s if TranslationServer.get_locale().begins_with("en") else s.replace(".", ",")

## Muda o nome de uma run gravada ("" volta a "Jogo N").
func rename_slot(slot: int, new_name: String) -> bool:
	var path := slot_path(slot)
	if not FileAccess.file_exists(path):
		return false
	var parsed = SaveIO.read_json(path)
	if not (parsed is Dictionary):
		return false
	var clean := new_name.strip_edges().replace("\n", " ").substr(0, RUN_NAME_MAX)
	parsed["name"] = clean
	if not SaveIO.write_json(path, parsed, true):
		return false
	_last_run_text.erase(slot)
	if slot == current_slot:
		run_name = clean
	_slot_cache.erase(slot)
	return true

## 0.19.0 (32): o que o progresso guarda por baralho do Construtor (Selo vencido, costas) troca com ele.
func swap_deck_keys(ka: String, kb: String) -> void:
	for key in ["custom_stakes", "deck_backs"]:
		if not (progress.get(key) is Dictionary):
			continue
		var d: Dictionary = progress[key]
		var va = d.get(ka)
		var vb = d.get(kb)
		d.erase(ka)
		d.erase(kb)
		if vb != null:
			d[ka] = vb
		if va != null:
			d[kb] = va
	save_progress()

# --- 0.19.0 (44): cartas favoritas (estrela na carta em grande; filtro «só favoritas» na Coleção e no Construtor) ---

func favorites() -> Array:
	return progress.get("favorites", []) if progress.get("favorites") is Array else []

func is_favorite(card_id: String) -> bool:
	return card_id in favorites()

func toggle_favorite(card_id: String) -> bool:
	var f: Array = favorites().duplicate()
	if card_id in f:
		f.erase(card_id)
	else:
		f.append(card_id)
	progress["favorites"] = f
	save_progress()
	return card_id in f

# --- 0.19.0 (45): o selo NOVO — o que já foi descoberto mas ainda não foi aberto (cartas, relíquias, cosméticos) ---

func is_opened(zone: String, id: String) -> bool:
	var o = progress.get("opened", {})
	if not (o is Dictionary):
		return false
	return id in (o.get(zone, []) if o.get(zone) is Array else [])

## Marca como vista em pormenor (o NOVO sai). Devolve true se era nova.
func mark_opened(zone: String, id: String) -> bool:
	if not (progress.get("opened") is Dictionary):
		progress["opened"] = {}
	var arr: Array = progress["opened"].get(zone, []) if progress["opened"].get(zone) is Array else []
	if id in arr:
		return false
	arr.append(id)
	progress["opened"][zone] = arr
	return true

## Está descoberta mas nunca foi aberta? (Quem já jogava antes da 0.19.0 não vê NOVO no que já tinha.)
func is_new(zone: String, id: String) -> bool:
	if not Stats.is_seen(zone, id) or is_opened(zone, id):
		return false
	return int(progress.get("opened_since", 0)) > 0

## Um cosmético já ganho que ainda não abriste na Coleção.
func is_new_cosmetic(kind: String, id: String) -> bool:
	return int(progress.get("opened_since", 0)) > 0 and not is_opened("cosmetics", kind + ":" + id) and id != "classic"

## Na 1.ª vez com a 0.19.0, tudo o que já estava descoberto conta como aberto (só o que vier depois tem NOVO).
func ensure_opened_baseline() -> void:
	if int(progress.get("opened_since", 0)) > 0:
		return
	progress["opened_since"] = int(Time.get_unix_time_from_system())
	if not (progress.get("opened") is Dictionary):
		progress["opened"] = {}
	var seen = progress.get("seen", {})
	for zone in ["cards", "relics"]:
		var arr: Array = []
		if seen is Dictionary and (seen as Dictionary).get(zone) is Dictionary:
			arr = (seen[zone] as Dictionary).keys()
		progress["opened"][zone] = arr
	var cos: Array = []
	for kind in ["back", "frame", "mat", "effect"]:
		for id in Settings.unlocked_cosmetics(kind):
			cos.append(String(kind) + ":" + String(id))
	progress["opened"]["cosmetics"] = cos

# --- 0.19.0 (56): histórico do baralho nesta run (o que entrou, saiu, foi melhorado, selado ou fundido, e onde) ---

const DECK_LOG_MAX := 80
const DECK_LOG_PLACES := {"Shop": "Loja", "Event": "Evento", "Loot": "Espólio", "Battle": "Batalha", "Map": "Mapa",
	"Tower": "Torre", "Draft": "Draft", "Campaign": "Início", "DeckBuilder": "Início", "Main": "Início"}

## Junta uma linha ao histórico do baralho: kind = "add", "remove", "plus", "seal", "edition", "power", "fuse", "curse".
func log_deck(kind: String, card_id: String, detail: String = "") -> void:
	var place := ""
	var tree := get_tree()
	if tree != null and tree.current_scene != null:
		place = String(DECK_LOG_PLACES.get(tree.current_scene.name, tree.current_scene.name))
	deck_log.append({"kind": kind, "id": card_id, "detail": detail, "ante": ante, "place": place})
	while deck_log.size() > DECK_LOG_MAX:
		deck_log.pop_front()

## 0.19.0 (32): troca as runs de dois espaços (JOGOS GUARDADOS → ▲ ▼), com as cópias .bak. O nome vai com a run.
func swap_slots(a: int, b: int) -> bool:
	if a == b or a < 1 or b < 1 or a > SLOT_COUNT or b > SLOT_COUNT:
		return false
	var pa := ProjectSettings.globalize_path(slot_path(a))
	var pb := ProjectSettings.globalize_path(slot_path(b))
	for ext in ["", SaveIO.BAK]:
		var fa: String = pa + ext
		var fb: String = pb + ext
		var tmp: String = fa + ".swap"
		var ea := FileAccess.file_exists(fa)
		var eb := FileAccess.file_exists(fb)
		if ea:
			DirAccess.rename_absolute(fa, tmp)
		if eb:
			DirAccess.rename_absolute(fb, fa)
		if ea:
			DirAccess.rename_absolute(tmp, fb)
	for sl in [a, b]:
		SaveIO.forget(slot_path(sl))
		_slot_cache.erase(sl)
		_last_run_text.erase(sl)
	if current_slot == a:
		current_slot = b
	elif current_slot == b:
		current_slot = a
	return true

## 0.19.0 (229): quantos dias faltam para uma run do lixo sair (arredondado para cima, mínimo 1).
static func trash_days_left(deleted_at: float) -> int:
	var left := TRASH_DAYS * 86400.0 - (Time.get_unix_time_from_system() - deleted_at)
	return maxi(1, ceili(left / 86400.0))

## Apaga a run de um espaço (não conta como derrota).
func delete_slot(slot: int) -> void:
	SaveIO.remove(slot_path(slot))   # 0.19.0: também a cópia .bak
	_slot_cache.erase(slot)
	_last_run_text.erase(slot)
	if slot == current_slot:
		pending_battle = {}

## Antes de começar uma run nova: se o espaço atual tem uma run que o jogador não mandou substituir
## (entrou sem passar pela escolha de espaço), passa para o primeiro espaço livre. Depois limpa-o.
func claim_slot_for_new_run() -> void:
	if not slot_confirmed and has_saved_run():
		var free := first_free_slot()
		if free > 0:
			current_slot = free
	slot_confirmed = false
	if has_saved_run():
		trash_slot(current_slot, "replaced")   # 0.13.0: a run substituída pode recuperar-se
	clear_saved_run()

func clear_all_saved_runs() -> void:
	for i in range(1, SLOT_COUNT + 1):
		delete_slot(i)

## Resumo da run gravada para o botão CONTINUAR do menu ("Falange Solar  ·  Ante 3"); "" se não houver.
func saved_run_summary(slot: int = 0) -> String:
	var info := slot_info(slot if slot > 0 else current_slot)
	if info.is_empty():
		return ""
	var ante_txt := tr("Ante %d") % int(info.get("ante", 1))
	var what := String(info.get("what", ""))
	return ante_txt if what == "" else what + "  ·  " + ante_txt

func load_run(slot: int = 0) -> bool:
	if slot > 0:
		current_slot = clampi(slot, 1, SLOT_COUNT)
	slot_confirmed = false
	if not has_saved_run():
		return false
	var parsed = SaveIO.read_json(run_save_path())   # 0.19.0 (227): estragado → a cópia .bak
	if not (parsed is Dictionary):
		return false
	var saved_def: Dictionary = parsed.get("deck_def", {}) if parsed.get("deck_def") is Dictionary else {}
	deck_def = saved_def if not saved_def.is_empty() else CardDB.get_deck(String(parsed.get("deck_id", "deck01")))
	deck.clear()
	for e in parsed.get("deck", []):
		if not (e is Dictionary):
			continue
		var entry := _new_entry(String(e.get("id", "")))
		for k in e:
			entry[k] = e[k]
		entry["power_bonus"] = int(e.get("power_bonus", 0))
		entry["mult_bonus"] = float(e.get("mult_bonus", 0.0))
		deck.append(entry)
	relic_ids.clear()
	for r in parsed.get("relic_ids", []):
		relic_ids.append(String(r))
	relic_locked.clear()
	for r in parsed.get("relic_locked", []):
		relic_locked.append(String(r))
	ante = int(parsed.get("ante", 1))
	max_ante = int(parsed.get("max_ante", 8))
	gold = int(parsed.get("gold", 4))
	seed_value = int(parsed.get("seed", 0))
	rng.seed = seed_value
	rng.state = int(parsed.get("rng_state", rng.state))
	difficulty = String(parsed.get("difficulty", "normal"))
	free_mode = bool(parsed.get("free_mode", false))
	mode = String(parsed.get("mode", "free" if free_mode else "campaign"))
	stake = int(parsed.get("stake", 1))
	player_max_hp = int(parsed.get("player_max_hp", 20))
	player_hp = clampi(int(parsed.get("player_hp", player_max_hp)), 1, player_max_hp)
	interest_ante = int(parsed.get("interest_ante", 0))
	seen_events.clear()
	for e in parsed.get("seen_events", []):
		seen_events.append(String(e))
	pending_event = String(parsed.get("pending_event", ""))
	current_enemy_id = String(parsed.get("current_enemy_id", ""))
	pair_enemy_id = String(parsed.get("pair_enemy_id", ""))
	endless = bool(parsed.get("endless", false))
	planeswalker = parsed.get("planeswalker", {}) if parsed.get("planeswalker") is Dictionary else {}
	if not planeswalker.is_empty():
		planeswalker["loyalty"] = int(planeswalker.get("loyalty", 2))
	formation_levels = {}
	var fl = parsed.get("formation_levels", {})
	if fl is Dictionary:
		for k in fl:
			formation_levels[String(k)] = int(fl[k])
	map_plan = {}
	var mp = parsed.get("map_plan", {})
	if mp is Dictionary:
		for k in mp:
			map_plan[String(k)] = mp[k]
	map_choice = parsed.get("map_choice", {}) if parsed.get("map_choice") is Dictionary else {}
	map_history = {}
	var mh = parsed.get("map_history", {})
	if mh is Dictionary:
		for k in mh:
			map_history[String(k)] = mh[k]
	map_phase = String(parsed.get("map_phase", "battle"))
	boss_relics.clear()
	for r in parsed.get("boss_relics", []):
		boss_relics.append(String(r))
	loot_offer.clear()
	for r in parsed.get("loot_offer", []):
		loot_offer.append(String(r))
	climates = {}
	var cl = parsed.get("climates", {})
	if cl is Dictionary:
		for k in cl:
			climates[String(k)] = String(cl[k])
	contract = parsed.get("contract", {}) if parsed.get("contract") is Dictionary else {}
	death_save_used = bool(parsed.get("death_save_used", false))
	relic_counters = {}
	var rc = parsed.get("relic_counters", {})
	if rc is Dictionary:
		for k in rc:
			relic_counters[String(k)] = int(rc[k])
	interlude_key = String(parsed.get("interlude_key", ""))
	deck_log = (parsed.get("deck_log", []) as Array).duplicate(true) if parsed.get("deck_log") is Array else []
	vouchers.clear()
	for v in parsed.get("vouchers", []):
		vouchers.append(String(v))
	nemesis_id = String(parsed.get("nemesis_id", ""))
	nemesis_beaten.clear()
	for lv in parsed.get("nemesis_beaten", []):
		nemesis_beaten.append(int(lv))
	challenge_id = String(parsed.get("challenge_id", ""))
	saga_id = String(parsed.get("saga_id", ""))
	run_talents = parsed.get("run_talents", {}) if parsed.get("run_talents") is Dictionary else {}
	run_name = String(parsed.get("name", ""))
	bosses_seen.clear()
	for b in parsed.get("bosses_seen", []):
		bosses_seen.append(String(b))
	milestones_claimed.clear()
	for m in parsed.get("milestones_claimed", []):
		milestones_claimed.append(int(m))
	last_milestone_text = ""
	blessings.clear()
	for b in parsed.get("blessings", []):
		if CardDB.relics.has(String(b)):
			blessings.append(String(b))
	next_enemy_weaken = int(parsed.get("next_enemy_weaken", 0))
	run_variant = String(parsed.get("run_variant", "classic"))
	arena_battle = bool(parsed.get("arena_battle", false))
	consumables.clear()
	for c in parsed.get("consumables", []):
		if not CardDB.get_consumable(String(c)).is_empty():
			consumables.append(String(c))
	stolen_relics.clear()
	endless_curses.clear()
	for c in parsed.get("endless_curses", []):
		if not CardDB.get_endless_curse(String(c)).is_empty():
			endless_curses.append(String(c))
	pact_offer.clear()
	for c in parsed.get("pact_offer", []):
		if not CardDB.get_endless_curse(String(c)).is_empty():
			pact_offer.append(String(c))
	# 0.17.0: história em cadeia (as runs gravadas antes não têm nenhuma).
	var chs: Dictionary = parsed.get("chain", {}) if parsed.get("chain") is Dictionary else {}
	chain_id = String(chs.get("id", ""))
	chain_part = int(chs.get("part", 0))
	chain_last_act = int(chs.get("last_act", 0))
	chain_tags.clear()
	for t in chs.get("tags", []):
		chain_tags.append(String(t))
	# 0.17.0: Torre do Arquimago e Corrida de Bosses.
	var tw: Dictionary = parsed.get("tower", {}) if parsed.get("tower") is Dictionary else {}
	tower_phase = "reward" if String(tw.get("phase", "")) == "reward" else "climb"
	tower_offer = tw.get("offer", {}) if tw.get("offer") is Dictionary else {}
	var rs: Dictionary = parsed.get("rush", {}) if parsed.get("rush") is Dictionary else {}
	rush_list.clear()
	for b in rs.get("list", []):
		if not CardDB.enemy_def(String(b)).is_empty():
			rush_list.append(String(b))
	rush_turns.clear()
	for n in rs.get("turns", []):
		rush_turns.append(int(n))
	last_side_record = false
	pending_later = []
	for l in parsed.get("pending_later", []):
		if l is Dictionary:
			pending_later.append(l)
	later_notes.clear()
	for n in parsed.get("later_notes", []):
		later_notes.append(String(n))
	boss_clean = bool(parsed.get("boss_clean", false))
	econ = (parsed.get("econ") as Dictionary).duplicate(true) if parsed.get("econ") is Dictionary else {}   # 0.19.0
	run_log = {}
	var rl = parsed.get("run_log", {})
	if rl is Dictionary and not rl.is_empty():
		run_log = {"damage_by_ante": {}, "card_dmg": {}, "relic_dmg": {}, "card_plays": {}, "best_hit": int(rl.get("best_hit", 0))}
		for k in ["damage_by_ante", "card_dmg", "relic_dmg", "card_plays"]:
			if rl.get(k) is Dictionary:
				for kk in rl[k]:
					run_log[k][String(kk)] = int(rl[k][kk])
		if rl.get("best_cascade") is Dictionary:
			run_log["best_cascade"] = rl["best_cascade"]
		# 0.19.0 (72, 73, 92, 98): o ouro por ante, os gastos, as compras, os atos e os Vales.
		for k in ["gold_by_ante", "act_log"]:
			if rl.get(k) is Dictionary:
				run_log[k] = {}
				for kk in rl[k]:
					if rl[k][kk] is Dictionary:
						var row := {}
						for f in rl[k][kk]:
							row[String(f)] = int(rl[k][kk][f])
						run_log[k][String(kk)] = row
		for k in ["spent", "voucher_gold"]:
			if rl.get(k) is Dictionary:
				run_log[k] = {}
				for kk in rl[k]:
					run_log[k][String(kk)] = int(rl[k][kk])
		if rl.get("bought") is Array:
			run_log["bought"] = (rl["bought"] as Array).duplicate(true)
	training = {}
	last_reward_text = ""
	puzzle_id = ""
	Stats.run_channels = int(parsed.get("run_channels", 0))
	last_unlocks.clear()
	last_victory = false
	saved_scene = String(parsed.get("scene", "battle"))
	pending_battle = {}
	if int(parsed.get("version", 1)) >= 2 and parsed.get("battle") is Dictionary:
		pending_battle = parsed["battle"]
	EventBus.gold_changed.emit(gold)
	return true

func clear_saved_run() -> void:
	pending_battle = {}
	delete_slot(current_slot)

## Abandonar a run a meio: conta como derrota no ante atual (na campanha) e apaga a gravação.
func abandon_run() -> void:
	run_abandoned = true
	record_run_end(ante, false)
	run_abandoned = false
	trash_slot(current_slot, "abandoned")   # 0.13.0: abandonar por engano pode desfazer-se
	clear_saved_run()
	last_victory = false
	EventBus.run_ended.emit(false)

## Apaga todo o progresso da campanha (Configurações → Apagar progresso).
func reset_progress() -> void:
	progress = {"best_ante": {}, "wins": {}, "difficulty": difficulty}
	Stats._ensure()
	save_progress()
	clear_all_saved_runs()

# ---------------------------------------------------------------------------
# Progresso da campanha: melhor ante por baralho, vitórias, selos vencidos, desbloqueios.
# ---------------------------------------------------------------------------

func load_progress() -> void:
	restored_backup = 0
	var parsed = null
	if FileAccess.file_exists(progress_path()):
		parsed = JSON.parse_string(FileAccess.get_file_as_string(progress_path()))
		if not (parsed is Dictionary):
			# Ficheiro estragado (p.ex. o telemóvel desligou-se a meio da gravação): usa a cópia mais recente.
			for i in range(1, PROGRESS_BACKUPS + 1):
				var b = _read_backup(i)
				if b is Dictionary:
					parsed = b
					restored_backup = i
					break
	if parsed is Dictionary:
		progress = parsed
		if not progress.has("best_ante"):
			progress["best_ante"] = {}
		if not progress.has("wins"):
			progress["wins"] = {}
		difficulty = String(progress.get("difficulty", "normal"))
		if restored_backup > 0:
			save_progress()

# --- Cópias de segurança do progresso (0.12.0) ---
# Ao abrir o jogo, o progress.json (o estado do fim da última sessão) passa a ser a cópia 1; a 1 passa
# a 2 e a 2 a 3. Abrir o jogo sem jogar não roda as cópias (o conteúdo é igual ao da cópia 1).

func backup_path(i: int) -> String:
	return Profiles.path("progress.bak%d.json" % i)   # 0.19.0: do perfil em uso

func _read_backup(i: int):
	if not FileAccess.file_exists(backup_path(i)):
		return null
	return JSON.parse_string(FileAccess.get_file_as_string(backup_path(i)))

func _rotate_backups() -> void:
	if not FileAccess.file_exists(progress_path()):
		return
	var text := FileAccess.get_file_as_string(progress_path())
	if not (JSON.parse_string(text) is Dictionary):
		return
	if FileAccess.file_exists(backup_path(1)) and FileAccess.get_file_as_string(backup_path(1)) == text:
		return
	for i in range(PROGRESS_BACKUPS, 1, -1):
		var src := ProjectSettings.globalize_path(backup_path(i - 1))
		var dst := ProjectSettings.globalize_path(backup_path(i))
		if FileAccess.file_exists(backup_path(i - 1)):
			if FileAccess.file_exists(backup_path(i)):
				DirAccess.remove_absolute(dst)
			DirAccess.rename_absolute(src, dst)
	var f := FileAccess.open(backup_path(1), FileAccess.WRITE)
	if f:
		f.store_string(text)
		f.close()

## Resumo das cópias para as Configurações: [{"index", "time", "runs", "wins", "achievements"}].
func backups_info() -> Array:
	var out: Array = []
	for i in range(1, PROGRESS_BACKUPS + 1):
		var b = _read_backup(i)
		if not (b is Dictionary):
			continue
		var st: Dictionary = b.get("stats", {}) if b.get("stats") is Dictionary else {}
		var ach = b.get("achievements", [])
		out.append({"index": i, "time": FileAccess.get_modified_time(backup_path(i)),
			"runs": int(st.get("runs", 0)), "wins": int(st.get("wins", 0)),
			"achievements": (ach as Array).size() if ach is Array else (ach as Dictionary).size() if ach is Dictionary else 0})
	return out

## Repõe a cópia n.º i (o progresso atual passa a ser a cópia 1, para se poder voltar atrás).
func restore_backup(i: int) -> bool:
	var b = _read_backup(i)
	if not (b is Dictionary):
		return false
	var current := JSON.stringify(progress)
	load_progress_from(b)
	save_progress()
	Stats._ensure()
	if i != 1:
		var f := FileAccess.open(backup_path(1), FileAccess.WRITE)
		if f:
			f.store_string(current)
			f.close()
	return true

# --- Histórico das runs (0.12.0) ---

func run_history() -> Array:
	return progress.get("history", []) if progress.get("history") is Array else []

func _record_history(reached_ante: int, victory: bool) -> void:
	if puzzle_id != "":
		return
	var total := 0
	var by_ante: Dictionary = run_log.get("damage_by_ante", {}) if run_log.get("damage_by_ante") is Dictionary else {}
	for k in by_ante:
		total += int(by_ante[k])
	var entry := {
		"t": int(Time.get_unix_time_from_system()),
		"mode": mode,
		"deck_id": String(deck_def.get("id", "")),
		"deck": String(deck_def.get("name", "")),
		"challenge": challenge_id,
		"saga": saga_id,
		"ante": reached_ante,
		"max_ante": max_ante,
		"won": victory,
		"endless": endless,
		"abandoned": run_abandoned,
		"difficulty": difficulty,
		"stake": stake,
		"best_hit": int(run_log.get("best_hit", 0)),
		"damage": total,
		"relics": relic_ids.size() + boss_relics.size(),
		"cards": deck.size(),
		"enemy": current_enemy_id,
		"mvp": String(top_of(run_log.get("card_dmg", {}) if run_log.get("card_dmg") is Dictionary else {}).get("id", "")),
		"seed": seed_value,
		"name": run_name,
		"free": free_mode,
		"secs": int(float(run_log.get("secs", 0.0))),   # 0.19.0 (171): quanto durou
	}
	# 0.19.0 (170): o tempo de jogo por modo e por baralho.
	var secs := int(float(run_log.get("secs", 0.0)))
	for pair in [["time_by_mode", mode if not (mode == "campaign" and free_mode) else "free"], ["time_by_deck", String(deck_def.get("id", ""))]]:
		if not (progress.get(pair[0]) is Dictionary):
			progress[pair[0]] = {}
		var dct: Dictionary = progress[pair[0]]
		dct[pair[1]] = int(dct.get(pair[1], 0)) + secs
	var h: Array = run_history().duplicate()
	h.push_front(entry)
	while h.size() > HISTORY_MAX:
		h.pop_back()
	progress["history"] = h

# --- Estatísticas por carta (0.12.0): dano, vezes jogada, runs e vitórias com ela no baralho ---

## {id: {"dmg", "plays", "runs", "wins"}} de todas as runs acabadas.
func card_stats() -> Dictionary:
	return progress.get("card_stats", {}) if progress.get("card_stats") is Dictionary else {}

func card_stat(id: String) -> Dictionary:
	var d = card_stats().get(id, {})
	return d if d is Dictionary else {}

func _record_card_stats(victory: bool) -> void:
	if puzzle_id != "":
		return
	var all: Dictionary = card_stats().duplicate(true)
	var before := {}   # 0.13.0: nível de mestria antes desta run (para mostrar o que subiu)
	for id in all:
		if all[id] is Dictionary:
			before[id] = mastery_of(all[id])
	var touch := func(id: String) -> Dictionary:
		if not (all.get(id) is Dictionary):
			all[id] = {"dmg": 0, "plays": 0, "runs": 0, "wins": 0}
		return all[id]
	var dmg: Dictionary = run_log.get("card_dmg", {}) if run_log.get("card_dmg") is Dictionary else {}
	for id in dmg:
		var e: Dictionary = touch.call(String(id))
		e["dmg"] = int(e.get("dmg", 0)) + int(dmg[id])
	var plays: Dictionary = run_log.get("card_plays", {}) if run_log.get("card_plays") is Dictionary else {}
	for id in plays:
		var e2: Dictionary = touch.call(String(id))
		e2["plays"] = int(e2.get("plays", 0)) + int(plays[id])
	var in_deck := {}
	for entry in deck:
		var cid := String(entry.get("id", ""))
		var cd := CardDB.get_card(cid)
		if cid != "" and cd != null and not cd.token and not cd.is_curse():
			in_deck[cid] = true
	for id in in_deck:
		var e3: Dictionary = touch.call(String(id))
		e3["runs"] = int(e3.get("runs", 0)) + 1
		if victory:
			e3["wins"] = int(e3.get("wins", 0)) + 1
	progress["card_stats"] = all
	# 0.13.0: mestria das cartas — o que subiu de nível nesta run vai para o ecrã do fim.
	var masters := 0
	for id in all:
		if not (all[id] is Dictionary):
			continue
		var lv := mastery_of(all[id])
		if lv >= MASTERY_PLAYS.size():
			masters += 1
		if lv > int(before.get(id, 0)):
			var cd2 := CardDB.get_card(String(id))
			if cd2 != null:
				last_unlocks.append(tr("Mestria %s: %s") % [tr(MASTERY_NAMES[lv - 1]), cd2.display_name()])
	Stats.set_at_least("masteries", masters)

# --- 0.13.0: mestria das cartas (jogadas em todas as runs) ---

const MASTERY_PLAYS := [15, 50, 120]          # jogadas para Bronze, Prata e Ouro
const MASTERY_NAMES := ["Bronze", "Prata", "Ouro"]
const MASTERY_COLORS := [Color(0.8, 0.5, 0.25), Color(0.78, 0.8, 0.88), Color(1.0, 0.82, 0.3)]

static func mastery_of(stat: Dictionary) -> int:
	var plays := int(stat.get("plays", 0))
	var lv := 0
	for need in MASTERY_PLAYS:
		if plays >= int(need):
			lv += 1
	return lv

## Nível de mestria de uma carta (0 = nenhum, 3 = Ouro).
func card_mastery(id: String) -> int:
	return mastery_of(card_stat(id))

# --- Exportar (0.12.0): o histórico e as estatísticas por carta em CSV, para uma folha de cálculo ---

static func _csv(v) -> String:
	var t := str(v)
	if t.contains(",") or t.contains("\"") or t.contains("\n"):
		return "\"" + t.replace("\"", "\"\"") + "\""
	return t

static func _csv_line(cells: Array) -> String:
	var out: PackedStringArray = []
	for c in cells:
		out.append(_csv(c))
	return ",".join(out)

func history_csv() -> String:
	var lines: PackedStringArray = [_csv_line(["date", "mode", "deck", "result", "ante", "max_ante", "difficulty", "stake",
		"best_hit", "damage", "relics", "cards", "mvp", "last_enemy", "seed", "name"])]
	for h in run_history():
		if not (h is Dictionary):
			continue
		var result := "abandoned" if bool(h.get("abandoned", false)) else ("win" if bool(h.get("won", false)) else "loss")
		var mvp := String(h.get("mvp", ""))
		var cd: CardData = CardDB.get_card(mvp) if mvp != "" else null
		lines.append(_csv_line([
			Time.get_datetime_string_from_unix_time(int(h.get("t", 0)), true),
			String(h.get("mode", "")), TranslationServer.translate(String(h.get("deck", ""))), result,
			int(h.get("ante", 0)), int(h.get("max_ante", 0)), String(h.get("difficulty", "")), int(h.get("stake", 1)),
			int(h.get("best_hit", 0)), int(h.get("damage", 0)), int(h.get("relics", 0)), int(h.get("cards", 0)),
			cd.display_name() if cd != null else mvp, String(h.get("enemy", "")), int(h.get("seed", 0)), String(h.get("name", ""))]))
	return "\n".join(lines)

func card_stats_csv() -> String:
	var lines: PackedStringArray = [_csv_line(["id", "card", "damage", "plays", "runs", "wins", "win_rate"])]
	var all := card_stats()
	var ids: Array = all.keys()
	ids.sort_custom(func(a, b): return int(all[a].get("dmg", 0)) > int(all[b].get("dmg", 0)))
	for id in ids:
		var e: Dictionary = all[id]
		var cd := CardDB.get_card(String(id))
		var runs := int(e.get("runs", 0))
		lines.append(_csv_line([String(id), cd.display_name() if cd != null else String(id), int(e.get("dmg", 0)),
			int(e.get("plays", 0)), runs, int(e.get("wins", 0)), ("%d%%" % roundi(100.0 * int(e.get("wins", 0)) / runs)) if runs > 0 else ""]))
	return "\n".join(lines)

# --- Revanche (0.12.0): a mesma run outra vez (modo, baralho, Selo), com outra semente ---

## O que é preciso para repetir a run que acabou ({} se não houver como).
func rematch_info() -> Dictionary:
	if puzzle_id != "":
		return {}
	return {"mode": mode, "deck_id": String(deck_def.get("id", "")), "stake": stake, "challenge": challenge_id,
		"saga": saga_id, "free": free_mode, "name": run_name, "variant": run_variant}

## Começa a revanche no espaço atual (que ficou livre no fim da run). Devolve a cena para onde ir.
func start_rematch(info: Dictionary) -> String:
	Stats.add("rematches")
	var m := String(info.get("mode", "campaign"))
	if m == "draft":
		return "draft"   # um draft novo (o baralho monta-se outra vez)
	claim_slot_for_new_run()
	var deck_id := String(info.get("deck_id", "deck01"))
	var st := int(info.get("stake", 1))
	if m in ["tower", "rush"]:   # 0.17.0: Torre do Arquimago e Corrida de Bosses (sem mapa)
		if m == "tower":
			new_tower_run(deck_id)
		else:
			new_rush_run(deck_id)
		apply_deck_variant(String(info.get("variant", "classic")))
		run_name = String(info.get("name", ""))
		save_run({}, "tower")
		return "tower"
	match m:
		"challenge":
			new_challenge_run(String(info.get("challenge", "")))
		"saga":
			new_saga_run(String(info.get("saga", "")))
		"quick":
			new_quick_run(deck_id, st)
			apply_deck_variant(String(info.get("variant", "classic")))
		_:
			free_mode = bool(info.get("free", m == "free"))
			new_run(deck_id, 0, st)
			apply_talents()
			apply_deck_variant(String(info.get("variant", "classic")))
	if m in ["campaign", "free", "quick"]:
		Economy.set_card_rewards(card_rewards_pref())   # 0.19.0 (75)
	run_name = String(info.get("name", ""))
	map_options(1)
	save_run({}, "map")
	return "map"

## Progresso vindo de um código importado (Configurações → Importar).
func load_progress_from(p: Dictionary) -> void:
	progress = p
	if not (progress.get("best_ante") is Dictionary):
		progress["best_ante"] = {}
	if not (progress.get("wins") is Dictionary):
		progress["wins"] = {}
	difficulty = String(progress.get("difficulty", "normal"))

func save_progress() -> void:
	SaveIO.write_json(progress_path(), progress)   # 0.19.0 (225): atómico

func best_ante(deck_id: String) -> int:
	return int(progress["best_ante"].get(deck_id, 0))

func wins(deck_id: String) -> int:
	return int(progress["wins"].get(deck_id, 0))

## Selo Planar mais alto vencido com este baralho (0 = nenhum).
func stake_won(deck_id: String) -> int:
	if not (progress.get("stakes") is Dictionary):
		return 0
	return int(progress["stakes"].get(deck_id, 0))

## Selo máximo que podes escolher para um baralho: o seguinte ao último vencido.
## 0.13.0: a Run Rápida (quick) tem a sua escada — o seguinte ao mais alto vencido na campanha ou na
## Run Rápida — e cada espaço do Construtor ("custom_N") também.
func max_stake(deck_id: String, quick: bool = false) -> int:
	if quick:
		return clampi(maxi(stake_won(deck_id), quick_stake_won(deck_id)) + 1, 1, STAKES.size())
	if deck_id.begins_with("custom_"):
		return clampi(custom_stake_won(deck_id) + 1, 1, STAKES.size())
	if free_mode:
		return STAKES.size()
	return clampi(stake_won(deck_id) + 1, 1, STAKES.size())

## 0.13.0: Selo Planar mais alto vencido numa Run Rápida com este baralho (0 = nenhum).
func quick_stake_won(deck_id: String) -> int:
	var d = progress.get("quick_stakes")
	return int((d as Dictionary).get(deck_id, 0)) if d is Dictionary else 0

## 0.13.0: Selo Planar mais alto vencido com um baralho do Construtor (por espaço, "custom_N").
func custom_stake_won(slot_id: String) -> int:
	var d = progress.get("custom_stakes")
	return int((d as Dictionary).get(slot_id, 0)) if d is Dictionary else 0

func _raise_stake_record(key: String, id: String) -> void:
	if id == "":
		return
	if not (progress.get(key) is Dictionary):
		progress[key] = {}
	var before := int((progress[key] as Dictionary).get(id, 0))
	if stake <= before:
		return
	progress[key][id] = stake
	if stake < STAKES.size():
		last_unlocks.append(tr("Selo Planar %d aberto") % (stake + 1))

## Regista o fim de uma run (ante atingido; vitória = passou o último ante). Devolve os desbloqueios novos.
func record_run_end(reached_ante: int, victory: bool) -> Array[String]:
	last_unlocks.clear()
	SceneRouter.session_runs += 1   # 0.19.0 (195): o limite de runs por sessão
	if victory and puzzle_id == "" and run_secs() > 0:   # 0.19.0 (190): o recorde de tempo por modo
		if not (progress.get("speed_best") is Dictionary):
			progress["speed_best"] = {}
		var sb: Dictionary = progress["speed_best"]
		if int(sb.get(mode, 0)) <= 0 or run_secs() < int(sb.get(mode, 0)):
			sb[mode] = run_secs()
	Stats.on_run_end(victory)
	if victory and mode == "quick":
		Stats.add("quick_wins")
	_record_history(reached_ante, victory)
	_record_card_stats(victory)
	last_first_bonus = 0
	last_fragments = Economy.fragments_for_run(reached_ante, victory)   # 0.19.0 (90)
	Economy.add_fragments(last_fragments)
	if mode in ["tower", "rush"]:   # 0.17.0: recordes próprios; nem talentos nem XP do baralho
		last_talent_points = 0
		_record_side_mode_end(victory)
		save_progress()
		return last_unlocks
	_add_deck_xp(reached_ante, victory)
	# Talentos: 1 ponto por ante vencido (+2 se venceres a run). No fim do Infinito só contam os antes
	# para lá do último (a vitória já foi paga); abandonar no ante 1 não dá nada.
	if victory:
		last_talent_points = reached_ante + 2
	elif endless:
		last_talent_points = maxi(0, reached_ante - 1 - max_ante)
	else:
		last_talent_points = maxi(0, reached_ante - 1)
	# 0.19.0 (89): prémio da 1.ª vez — a 1.ª vitória com um baralho e cada Selo Planar novo vencido (na campanha).
	if victory and not free_mode and challenge_id == "" and saga_id == "":
		last_first_bonus = Economy.first_win_bonus(String(deck_def.get("id", "")), stake)
		last_talent_points += last_first_bonus
	progress["talent_points"] = talent_points() + last_talent_points
	if victory and challenge_id != "":
		if not (progress.get("challenges") is Dictionary):
			progress["challenges"] = {}
		progress["challenges"][challenge_id] = true
		Stats.set_at_least("challenges_won", (progress["challenges"] as Dictionary).size())
		# 0.13.0: estrelas — ★ vencer · ★ acabar com metade da vida ou mais · ★ vencer o boss final sem ele despertar.
		last_stars = challenge_stars_for_run()
		if not (progress.get("challenge_stars") is Dictionary):
			progress["challenge_stars"] = {}
		progress["challenge_stars"][challenge_id] = maxi(challenge_stars(challenge_id), last_stars)
		Stats.set_at_least("challenge_stars", total_challenge_stars())
	if victory and saga_id != "":
		if not (progress.get("saga") is Dictionary):
			progress["saga"] = {}
		var first_time := not saga_done(saga_id)
		progress["saga"][saga_id] = true
		Stats.set_at_least("saga_chapters", (progress["saga"] as Dictionary).size())
		var rw: Dictionary = CardDB.get_saga_chapter(saga_id).get("reward", {})
		if first_time and not rw.is_empty() and Stats.grant_unlock(String(rw.get("type", "")), String(rw.get("id", ""))):
			last_unlocks.append(Stats.unlock_label(rw, "%s: %s"))
		if String(CardDB.get_saga_chapter(saga_id).get("epilogue", "")) != "":
			Stats.set_at_least("saga_book3", 1)   # 0.13.0: o fim do Livro III
	# 0.13.0: Selos Planares na Run Rápida e nos baralhos do Construtor (recordes próprios).
	if victory and challenge_id == "" and saga_id == "" and puzzle_id == "":
		var sid := String(deck_def.get("id", ""))
		if mode == "quick":
			_raise_stake_record("quick_stakes", sid)
			Stats.set_at_least("quick_stake", stake)
		elif sid.begins_with("custom_"):
			_raise_stake_record("custom_stakes", sid)
			Stats.set_at_least("custom_stake", stake)
	if free_mode:
		save_progress()
		return last_unlocks
	var id := String(deck_def.get("id", ""))
	var before := _unlocked_deck_ids()
	var reached := reached_ante + (1 if victory else 0)
	progress["best_ante"][id] = max(best_ante(id), reached)
	if victory:
		progress["wins"][id] = wins(id) + 1
		if not (progress.get("stakes") is Dictionary):
			progress["stakes"] = {}
		progress["stakes"][id] = max(stake_won(id), stake)
	save_progress()
	for did in _unlocked_deck_ids():
		if not (did in before):
			last_unlocks.append(String(CardDB.get_deck(did).get("name", did)))
	return last_unlocks

## Desbloqueio: o 1.º capítulo de cada livro aberto está livre; cada capítulo desbloqueia o seguinte
## ao chegar ao ante 4; um livro abre quando algum capítulo do livro anterior chega ao ante 6.
func is_act_unlocked(act_index: int) -> bool:
	if act_index == 0:
		return true
	# 0.13.0: um livro cujos capítulos se abrem por conquistas está sempre aberto (cada capítulo decide).
	if bool(CardDB.campaign[act_index].get("by_achievement", false)):
		return true
	var prev: Dictionary = CardDB.campaign[act_index - 1]
	for ch in prev.get("chapters", []):
		if best_ante(String(ch["deck_id"])) >= 6:
			return true
	return false

func is_deck_unlocked(deck_id: String) -> bool:
	for act_index in CardDB.campaign.size():
		var act: Dictionary = CardDB.campaign[act_index]
		var chapters: Array = act.get("chapters", [])
		for i in chapters.size():
			if String(chapters[i]["deck_id"]) != deck_id:
				continue
			# 0.13.0: capítulos que se abrem com uma conquista (Livro IV: baralhos iniciais novos).
			if chapters[i].get("unlock") is Dictionary:
				return Stats.is_content_unlocked("deck", deck_id)
			if not is_act_unlocked(act_index):
				return false
			if i == 0:
				return true
			return best_ante(String(chapters[i - 1]["deck_id"])) >= 4
	return false

func _unlocked_deck_ids() -> Array[String]:
	var out: Array[String] = []
	for act in CardDB.campaign:
		for ch in act.get("chapters", []):
			if is_deck_unlocked(String(ch["deck_id"])):
				out.append(String(ch["deck_id"]))
	return out


# ---------------------------------------------------------------------------
# 0.19.0 (secção 6): respeito pelo tempo e pela sessão
# ---------------------------------------------------------------------------

## 170: tempo de jogo — conta o tempo com o jogo aberto (SceneRouter chama isto a cada frame); o da run vai para
## run_log.secs (e, no fim, para o tempo por modo e por baralho).
var _time_acc := 0.0

func tick_time(delta: float, in_run: bool) -> void:
	if delta <= 0.0 or delta > 1.0:
		return
	progress["play_secs"] = float(progress.get("play_secs", 0.0)) + delta
	if in_run and not deck.is_empty():
		run_log["secs"] = float(run_log.get("secs", 0.0)) + delta

func speed_best(m: String) -> int:
	var sb = progress.get("speed_best", {})
	return int((sb as Dictionary).get(m, 0)) if sb is Dictionary else 0

func play_secs() -> int:
	return int(float(progress.get("play_secs", 0.0)))

func run_secs() -> int:
	return int(float(run_log.get("secs", 0.0)))

## «1 h 05 min», «12 min», «45 s».
static func fmt_duration(secs: int) -> String:
	var t := func(x: String) -> String: return TranslationServer.translate(x)
	if secs < 60:
		return t.call("%d s") % maxi(0, secs)
	var m := secs / 60
	if m < 60:
		return t.call("%d min") % m
	return t.call("%d h %02d min") % [m / 60, m % 60]

## 169: a duração média das runs acabadas de um modo (0 se ainda não há).
func avg_run_secs(m: String) -> int:
	var n := 0
	var tot := 0
	for e in run_history():
		if e is Dictionary and String(e.get("mode", "")) == m and int(e.get("secs", 0)) > 30 and not bool(e.get("abandoned", false)):
			n += 1
			tot += int(e["secs"])
	return tot / n if n > 0 else 0

## 169: quanto falta para acabar esta run (pela média por ante das tuas runs do mesmo modo; "" se não se sabe).
func run_time_left_text() -> String:
	if deck.is_empty() or mode in ["tower", "rush"] or endless:
		return ""
	var per_ante := 0.0
	var n := 0
	for e in run_history():
		if e is Dictionary and String(e.get("mode", "")) == mode and int(e.get("secs", 0)) > 30 and int(e.get("ante", 0)) > 0:
			per_ante += float(e["secs"]) / float(e["ante"])
			n += 1
	if n == 0 and run_secs() > 60 and ante > 1:
		per_ante = float(run_secs()) / float(ante - 1)
		n = 1
	if n == 0:
		return ""
	var left := int(per_ante / n * float(maxi(0, max_ante - ante + 1)))
	return TranslationServer.translate("Faltam ~%s para acabar a run") % fmt_duration(maxi(60, left))

## 179: as últimas escolhas do ecrã de começar (baralho, Selo, variante e livro), guardadas entre sessões.
func remember_choice(kind: String, deck_id: String, p_stake: int, variant: String, act: int) -> void:
	if not (progress.get("last_choice") is Dictionary):
		progress["last_choice"] = {}
	(progress["last_choice"] as Dictionary)[kind] = {"deck": deck_id, "stake": p_stake, "variant": variant, "act": act}
	(progress["last_choice"] as Dictionary)["_last"] = {"deck": deck_id, "stake": p_stake, "variant": variant, "act": act, "kind": kind}
	save_progress()

func last_choice(kind: String) -> Dictionary:
	var lc = progress.get("last_choice", {})
	if not (lc is Dictionary):
		return {}
	var d = (lc as Dictionary).get(kind, {})
	return d if d is Dictionary else {}

## 199: desfazer a escolha do nó — o estado antes de a batalha começar (só em memória; o mapa guarda-o ao escolher).
var node_undo: Dictionary = {}

func remember_node_choice() -> void:
	node_undo = {"snap": shop_snapshot(), "bosses_seen": bosses_seen.duplicate(), "map_choice": map_choice.duplicate(),
		"phase": map_phase, "weaken": next_enemy_weaken, "slot": current_slot, "ante": ante}

func can_undo_node() -> bool:
	return not node_undo.is_empty() and int(node_undo.get("ante", -1)) == ante and int(node_undo.get("slot", -1)) == current_slot

func undo_node_choice() -> bool:
	if not can_undo_node():
		return false
	restore_shop_snapshot(node_undo["snap"])
	bosses_seen.assign(node_undo.get("bosses_seen", []))
	map_choice = (node_undo.get("map_choice", {}) as Dictionary).duplicate()
	map_choice.erase("battle")
	map_phase = String(node_undo.get("phase", "battle"))
	next_enemy_weaken = int(node_undo.get("weaken", 0))
	pending_battle = {}
	node_undo = {}
	save_run({}, "map")
	return true

## 75: cartas depois das batalhas — a opção «card_reward» das Configurações (Ritmo); a escolha antiga, guardada
## no progresso, passa para lá uma vez.
func card_rewards_pref() -> bool:
	if progress.has("card_rewards_pref"):
		Settings.set_opt("card_reward", bool(progress["card_rewards_pref"]))
		progress.erase("card_rewards_pref")
		save_progress()
	return bool(Settings.opt("card_reward"))

## 194: a conquista mais perto de abrir ({"name", "have", "need"}; {} se não há nenhuma a meio).
func closest_achievement() -> Dictionary:
	var best := {}
	var best_ratio := -1.0
	var done: Array = progress.get("achievements", []) if progress.get("achievements") is Array else []
	for a in CardDB.achievements:
		var id := String(a.get("id", ""))
		if id == "" or id in done or bool(a.get("hidden", false)):
			continue
		var cond: Dictionary = a.get("cond", {}) if a.get("cond") is Dictionary else {}
		var stat := String(cond.get("stat", ""))
		var need := int(cond.get("min", 0))
		if stat == "" or need <= 1:
			continue
		var have := Stats.achievement_value(stat)
		var ratio := float(have) / float(need)
		if have > 0 and ratio < 1.0 and ratio > best_ratio:
			best_ratio = ratio
			best = {"name": String(a.get("name", id)), "have": have, "need": need, "text": String(a.get("text", ""))}
	return best

## 193: um quebra-cabeças por resolver, ao acaso ("" se já estão todos).
func random_unsolved_puzzle() -> String:
	var open: Array[String] = []
	for pz in CardDB.puzzles:
		var id := String((pz as Dictionary).get("id", "")) if pz is Dictionary else ""
		if id != "" and not Stats.is_puzzle_solved(id):
			open.append(id)
	return open[randi() % open.size()] if not open.is_empty() else ""
