extends Node
## Estado da run atual (o "save" em memória). Persistente entre cenas.
## Não contém lógica de batalha — isso vive em BattleManager.

var rng := RandomNumberGenerator.new()
var seed_value: int = 0

# --- Run ---
var ante: int = 1
var max_ante: int = 8
var gold: int = 4
var player_max_hp: int = 20
var player_hp: int = 20

# --- Baralho persistente: uma entrada por carta, com bónus permanentes ---
var deck: Array[Dictionary] = []     # {"id": "c001", "power_bonus": 0, "mult_bonus": 0.0}
var deck_def: Dictionary = {}        # definição do baralho escolhido (decks.json)
var relic_ids: Array[String] = []

func new_run(deck_id: String = "deck01", seed_override: int = 0) -> void:
	seed_value = seed_override if seed_override != 0 else randi()
	rng.seed = seed_value
	ante = 1
	gold = 4
	player_hp = player_max_hp
	relic_ids.clear()
	deck_def = CardDB.get_deck(deck_id)
	deck.clear()
	for id in deck_def.get("cards", []):
		deck.append({"id": String(id), "power_bonus": 0, "mult_bonus": 0.0})
	EventBus.run_started.emit()
	EventBus.gold_changed.emit(gold)

## Cores do baralho atual (para a loja).
func deck_colors() -> Array:
	return deck_def.get("colors", [])

func deck_ids() -> Array[String]:
	var out: Array[String] = []
	for e in deck:
		out.append(String(e["id"]))
	return out

func add_gold(amount: int) -> void:
	gold = max(0, gold + amount)
	EventBus.gold_changed.emit(gold)

func spend_gold(amount: int) -> bool:
	if gold < amount:
		return false
	gold -= amount
	EventBus.gold_changed.emit(gold)
	return true

func add_card(id: String) -> void:
	deck.append({"id": id, "power_bonus": 0, "mult_bonus": 0.0})

## Remove UMA cópia da carta. Devolve false se não existir.
func remove_card(id: String) -> bool:
	for i in deck.size():
		if deck[i]["id"] == id:
			deck.remove_at(i)
			return true
	return false

## Custo de remover uma carta na loja: sobe com o ante para não ser trivial afinar o deck.
func removal_price() -> int:
	return 2 + int(ante / 3)

## Contagem por id, para listar o deck sem repetições.
func deck_counts() -> Dictionary:
	var counts := {}
	for e in deck:
		counts[e["id"]] = counts.get(e["id"], 0) + 1
	return counts

func add_relic(id: String) -> void:
	if id in relic_ids:
		return
	relic_ids.append(id)
	EventBus.relic_gained.emit(id)

func next_ante() -> void:
	ante += 1
	EventBus.ante_started.emit(ante)

## Alvo de "vida" do inimigo por ante — tabela afinada por simulação (tests/Balance.gd).
const ANTE_HP := [3000, 7000, 15000, 28000, 70000, 120000, 200000, 330000]

func enemy_hp_for_ante(a: int) -> int:
	if a <= ANTE_HP.size():
		return ANTE_HP[a - 1]
	return int(round(ANTE_HP[-1] * pow(1.6, a - ANTE_HP.size())))

func turns_for_ante(_a: int) -> int:
	return 5
