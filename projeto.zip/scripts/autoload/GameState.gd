extends Node
## Estado da run atual (o "save" em memória), progresso da campanha e gravação em disco.
## Não contém lógica de batalha — isso vive em BattleManager.
##
## Uma run são 8 antes em 5 atos (I: 1–2, II: 3–4 com boss, III: 5–6, IV: 7–8 com o boss final,
## V: modo infinito). Em cada ante o mapa oferece uma batalha (Batedor ou Guarda; boss nos antes
## múltiplos de 4) e depois uma paragem (Loja ou outra: evento, acampamento, Fonte de Mana,
## Altar de Phyrexia, Mercador Cego). Os Selos Planares (1–8) são a dificuldade progressiva por
## baralho; Fácil/Normal/Difícil continua a ser o modificador global.

const RUN_SAVE := "user://run.json"
const PROGRESS_SAVE := "user://progress.json"

const DIFFICULTIES := ["facil", "normal", "dificil"]
const DIFFICULTY_NAMES := {"facil": "Fácil", "normal": "Normal", "dificil": "Difícil"}
const DIFFICULTY_HP := {"facil": 0.7, "normal": 1.0, "dificil": 1.4}
const DIFFICULTY_DISCARDS := {"facil": 4, "normal": 3, "dificil": 2}
const MAX_RELICS := 5
const BOSS_EVERY := 4                 # antes 4, 8, 12… têm boss; o 8 é o boss final
const GUARD_HP_MULT := 1.25
const GUARD_GOLD := 4
const ACT_NAMES := ["I", "II", "III", "IV", "V"]
const STAKES := [
	{"name": "Iniciado", "text": "Dificuldade padrão."},
	{"name": "Taxa do Senado", "text": "As batalhas contra Batedores não dão ouro base."},
	{"name": "Fome de Mana", "text": "A vida dos bosses sobe 35% a partir do ante 3."},
	{"name": "Decreto de Silêncio", "text": "Máximo de 2 canalizações por batalha."},
	{"name": "Marca Eterna", "text": "As relíquias compradas na loja não podem ser vendidas."},
	{"name": "Infeção de Óleo", "text": "As cartas dos boosters podem vir infetadas: Poder a dobrar, mas exilam-se ao fim de 3 utilizações."},
	{"name": "Eclipse da Mente", "text": "A mão passa a 5 cartas."},
	{"name": "Ascensão Mítica", "text": "Abaixo de metade da vida, os bosses ativam uma 2.ª regra."},
]
const STOP_NODES := ["shop", "event", "rest", "spring", "altar", "merchant"]

var rng := RandomNumberGenerator.new()
var seed_value: int = 0

# --- Run ---
var ante: int = 1
var max_ante: int = 8
var gold: int = 4
var player_max_hp: int = 20
var player_hp: int = 20
var difficulty: String = "normal"
var free_mode: bool = false          # Modo Livre: não conta para a campanha
var mode: String = "campaign"        # "campaign" | "free" | "draft"
var stake: int = 1                   # Selo Planar (1–8)
var last_victory: bool = false       # a última run terminou em vitória (para o ecrã final)
var interest_ante: int = 0           # último ante em que a loja pagou juros
var seen_events: Array[String] = []  # eventos já mostrados nesta run
var pending_event: String = ""       # evento gravado a meio (para retomar)
var current_enemy_id: String = ""    # inimigo da batalha atual (para o ecrã final)
var endless: bool = false            # modo infinito: continuar depois do ante 8
var planeswalker: Dictionary = {}    # {"id", "loyalty"} ou vazio
var formation_levels: Dictionary = {} # id da formação → nível (Selo da Sabedoria)
var relic_locked: Array[String] = [] # relíquias compradas na loja com o Selo Planar 5 (não se vendem)
var map_plan: Dictionary = {}        # ante (String) → {"battle": [...], "stop": [...]}
var map_choice: Dictionary = {}      # escolhas do ante atual: {"battle": "scout"|"guard"|"boss", "stop": "..."}
var map_history: Dictionary = {}     # ante (String) → escolhas feitas (para o mapa mostrar o caminho)
var map_phase: String = "battle"     # o que o mapa pede a seguir: "battle" ou "stop"
var puzzle_id: String = ""           # quebra-cabeças em curso ("" = nenhum)

# --- Baralho persistente: uma entrada por carta, com bónus permanentes ---
var deck: Array[Dictionary] = []     # {"id": "c001", "power_bonus": 0, "mult_bonus": 0.0, "seal": "", ...}
var deck_def: Dictionary = {}        # definição do baralho escolhido (decks.json)
var relic_ids: Array[String] = []

# --- Progresso da campanha (persistente) ---
var progress: Dictionary = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
var last_unlocks: Array[String] = []   # nomes desbloqueados na última run (para o ecrã final)

# --- Retoma ---
var pending_battle: Dictionary = {}    # batalha gravada a meio (BattleManager.to_dict), consumida pela cena Battle
var saved_scene: String = "battle"     # onde a run gravada estava: "battle", "shop", "event" ou "map"

func _ready() -> void:
	load_progress()

func new_run(deck_id: String = "deck01", seed_override: int = 0, p_stake: int = 1) -> void:
	seed_value = seed_override if seed_override != 0 else randi()
	rng.seed = seed_value
	ante = 1
	max_ante = 8
	gold = 4
	player_max_hp = 20
	player_hp = player_max_hp
	mode = "free" if free_mode else "campaign"
	stake = clampi(p_stake, 1, STAKES.size())
	relic_ids.clear()
	relic_locked.clear()
	last_unlocks.clear()
	last_victory = false
	interest_ante = 0
	seen_events.clear()
	pending_event = ""
	current_enemy_id = ""
	endless = false
	planeswalker = {}
	formation_levels = {}
	map_plan = {}
	map_choice = {}
	map_history = {}
	map_phase = "battle"
	puzzle_id = ""
	deck_def = CardDB.get_deck(deck_id)
	deck.clear()
	for id in deck_def.get("cards", []):
		deck.append(_new_entry(String(id)))
	EventBus.run_started.emit()
	EventBus.gold_changed.emit(gold)

## Arena Draft: baralho montado na hora, run curta (4 antes), não conta para a campanha.
func new_draft_run(card_ids: Array, colors: Array, seed_override: int = 0) -> void:
	free_mode = true
	new_run("deck01", seed_override, 1)
	mode = "draft"
	max_ante = 4
	deck_def = {"id": "draft", "num": 0, "name": "Arena Draft", "colors": colors, "color_code": "", "size": card_ids.size(),
		"mechanic": "Baralho de draft", "difficulty": 3, "cards": card_ids, "custom": true}
	deck.clear()
	for id in card_ids:
		deck.append(_new_entry(String(id)))
	EventBus.run_started.emit()

static func _new_entry(id: String) -> Dictionary:
	return {"id": id, "power_bonus": 0, "mult_bonus": 0.0}

## Cores do baralho atual (para a loja).
func deck_colors() -> Array:
	return deck_def.get("colors", [])

## Cor principal do baralho (a primeira; "" se for incolor) — Fonte de Mana.
func main_color() -> String:
	var cols := deck_colors()
	return String(cols[0]) if not cols.is_empty() else ""

func deck_ids() -> Array[String]:
	var out: Array[String] = []
	for e in deck:
		out.append(String(e["id"]))
	return out

func add_gold(amount: int) -> void:
	gold = max(0, gold + amount)
	EventBus.gold_changed.emit(gold)

func spend_gold(amount: int) -> bool:
	if gold < amount:
		return false
	gold -= amount
	EventBus.gold_changed.emit(gold)
	return true

func add_card(id: String, infected: bool = false) -> void:
	var e := _new_entry(id)
	if infected:
		e["infected"] = true
	deck.append(e)
	Stats.mark_seen("cards", id, false)

## Remove UMA cópia da carta. Devolve false se não existir.
func remove_card(id: String) -> bool:
	for i in deck.size():
		if deck[i]["id"] == id:
			deck.remove_at(i)
			return true
	return false

## Apaga do baralho as entradas exiladas durante a batalha (Selo Phyrexiano a 0, infeção).
func purge_exiled() -> void:
	for i in range(deck.size() - 1, -1, -1):
		if deck[i].get("exiled_run", false):
			deck.remove_at(i)

## Custo de remover uma carta na loja: sobe com o ante para não ser trivial afinar o deck.
func removal_price() -> int:
	return 2 + int(ante / 3)

## Contagem por id, para listar o deck sem repetições.
func deck_counts() -> Dictionary:
	var counts := {}
	for e in deck:
		counts[e["id"]] = counts.get(e["id"], 0) + 1
	return counts

## Devolve false se já a tiveres ou se não houver espaço (MAX_RELICS).
func add_relic(id: String) -> bool:
	if id in relic_ids or relic_ids.size() >= MAX_RELICS:
		return false
	relic_ids.append(id)
	EventBus.relic_gained.emit(id)
	return true

func remove_relic(id: String) -> void:
	relic_ids.erase(id)
	relic_locked.erase(id)
	EventBus.relics_changed.emit()

func move_relic(id: String, index: int) -> void:
	if not (id in relic_ids):
		return
	relic_ids.erase(id)
	relic_ids.insert(clampi(index, 0, relic_ids.size()), id)
	EventBus.relics_changed.emit()

func relic_sell_price(id: String) -> int:
	return max(1, int(CardDB.relics.get(id, {}).get("price", 4)) / 2)

func has_relic(id: String) -> bool:
	return id in relic_ids

## Relíquia ao acaso que ainda não tenhas (para eventos; nunca lendárias). "" se não houver.
func random_new_relic() -> String:
	var pool: Array = CardDB.relics.keys().filter(func(r): return not (r in relic_ids) and not bool(CardDB.relics[r].get("legendary", false)))
	if pool.is_empty():
		return ""
	return String(pool[rng.randi_range(0, pool.size() - 1)])

# --- Vida (persistente ao longo da run) ---

func heal(amount: int) -> void:
	player_hp = clampi(player_hp + amount, 0, player_max_hp)
	EventBus.player_hp_changed.emit(player_hp, player_max_hp)

func change_max_hp(amount: int) -> void:
	player_max_hp = max(5, player_max_hp + amount)
	player_hp = clampi(player_hp, 1, player_max_hp)
	EventBus.player_hp_changed.emit(player_hp, player_max_hp)

func damage_player(amount: int) -> void:
	player_hp = max(0, player_hp - amount)
	EventBus.player_hp_changed.emit(player_hp, player_max_hp)

## Juros da loja: +1 ouro por cada 5 guardados (máx. 5; a dobrar com o Dízimo Dobrado), uma vez por ante.
func interest_due() -> int:
	if interest_ante == ante:
		return 0
	var due := mini(5, int(gold / 5))
	if has_relic("relic_double_tithe"):
		due = mini(10, due * 2)
	return due

func pay_interest() -> int:
	var due := interest_due()
	interest_ante = ante
	if due > 0:
		add_gold(due)
	return due

# --- Planeswalker (um por run; lealdade atravessa as batalhas) ---

func planeswalker_def() -> Dictionary:
	return CardDB.get_planeswalker(String(planeswalker.get("id", ""))) if not planeswalker.is_empty() else {}

func planeswalker_color() -> String:
	return String(planeswalker_def().get("color", ""))

func planeswalker_loyalty() -> int:
	return int(planeswalker.get("loyalty", 0))

func set_planeswalker(id: String) -> void:
	var def := CardDB.get_planeswalker(id)
	if def.is_empty():
		return
	planeswalker = {"id": id, "loyalty": int(def.get("loyalty", 2))}
	Stats.mark_seen("planeswalkers", id, false)
	EventBus.planeswalker_changed.emit()

func change_loyalty(amount: int) -> void:
	if planeswalker.is_empty():
		return
	var max_l := int(planeswalker_def().get("max_loyalty", 6))
	planeswalker["loyalty"] = clampi(planeswalker_loyalty() + amount, 0, max_l)
	EventBus.planeswalker_changed.emit()

# --- Formações com nível (Selo da Sabedoria) ---

func formation_level(id: String) -> int:
	return int(formation_levels.get(id, 0))

func level_up_random_formation() -> String:
	if CardDB.formations.is_empty():
		return ""
	var f: Dictionary = CardDB.formations[rng.randi_range(0, CardDB.formations.size() - 1)]
	var id := String(f.get("id", ""))
	formation_levels[id] = formation_level(id) + 1
	EventBus.formation_leveled.emit(id, formation_levels[id])
	return id

# --- Selos Planares ---

func stake_name(n: int = -1) -> String:
	var i := clampi((stake if n < 0 else n) - 1, 0, STAKES.size() - 1)
	return String(STAKES[i].get("name", ""))

func hand_size_for_battle() -> int:
	return 5 if stake >= 7 else BattleManager.HAND_SIZE

func discards_for_battle() -> int:
	var n := int(DIFFICULTY_DISCARDS.get(difficulty, 3))
	return mini(n, 2) if stake >= 4 else n

## Ouro por vencer uma batalha: 4 base + ante + turnos que sobraram (+4 nos Guardas; sem base nos
## Batedores com o Selo Planar 2).
func battle_reward(turns_left: int) -> int:
	var variant := String(map_choice.get("battle", "scout"))
	var base := 4
	if stake >= 2 and variant == "scout":
		base = 0
	var bonus := GUARD_GOLD if variant == "guard" else 0
	return base + ante + turns_left + bonus

# --- Inimigos e bosses ---

## Livro (1-3) do baralho atual, pela campanha; 1 se não constar.
func act_of_deck() -> int:
	var id := String(deck_def.get("id", ""))
	for i in CardDB.campaign.size():
		for ch in CardDB.campaign[i].get("chapters", []):
			if String(ch.get("deck_id", "")) == id:
				return i + 1
	return 1

## Ato da run (1–5) de um ante: dois antes por ato; o infinito é o ato V.
func act_of_ante(a: int) -> int:
	if a > max_ante:
		return 5
	return clampi(int((a - 1) / 2) + 1, 1, 5)

func act_name(a: int = -1) -> String:
	return ACT_NAMES[act_of_ante(ante if a < 0 else a) - 1]

func is_boss_ante(a: int) -> bool:
	return a % BOSS_EVERY == 0

func current_enemy_is_boss() -> bool:
	for e in CardDB.enemies:
		if String(e.get("id", "")) == current_enemy_id:
			return bool(e.get("boss", false))
	return false

## Escolhe o inimigo de um ante: boss nos antes múltiplos de 4 (final no último), senão um do
## conjunto do livro do baralho com min_ante <= ante. Devolve a definição pronta para BattleManager.start.
## O Guarda (mapa) tem +25 % de vida; o Selo Planar 3 dá +35 % aos bosses a partir do ante 3.
func pick_enemy(a: int) -> Dictionary:
	var act := act_of_deck()
	var def: Dictionary = {}
	if is_boss_ante(a):
		var bosses: Array = CardDB.enemies.filter(func(e): return bool(e.get("boss", false)) and (bool(e.get("final", false)) == (a == max_ante) or a > max_ante))
		if bosses.is_empty():
			bosses = CardDB.enemies.filter(func(e): return bool(e.get("boss", false)))
		def = bosses[rng.randi_range(0, bosses.size() - 1)]
	else:
		var pool: Array = CardDB.enemies.filter(func(e):
			if bool(e.get("boss", false)) or int(e.get("min_ante", 1)) > a:
				return false
			return _act_in(act, e.get("acts", [1, 2, 3])) or a > max_ante)
		if pool.is_empty():
			pool = CardDB.enemies.filter(func(e): return not bool(e.get("boss", false)))
		def = pool[rng.randi_range(0, pool.size() - 1)]
	var mult := float(def.get("hp_mult", 1.0))
	var variant := String(map_choice.get("battle", "scout"))
	if variant == "guard" and not bool(def.get("boss", false)):
		mult *= GUARD_HP_MULT
	if bool(def.get("boss", false)) and stake >= 3 and a >= 3:
		mult *= 1.35
	var hp := int(round(enemy_hp_for_ante(a) * mult))
	current_enemy_id = String(def.get("id", ""))
	return {
		"id": def.get("id", ""),
		"name": def.get("name", "?"),
		"hp": hp, "max_hp": hp,
		"attack": int(def.get("attack", 0)),
		"text": def.get("text", ""),
		"abilities": def.get("abilities", []),
		"boss": bool(def.get("boss", false)),
		"rule": def.get("rule", {}),
		"rule2": def.get("rule2", {}),
		"rule2_text": def.get("rule2_text", ""),
		"variant": variant,
	}

## Os números do JSON chegam como float: `1 in [1.0]` é falso no Godot, por isso compara-se a int.
static func _act_in(act: int, acts: Array) -> bool:
	for a in acts:
		if int(a) == act:
			return true
	return false

## Evento para o nó "evento" (ou "" se não houver). Não repete na mesma run.
func pick_event() -> String:
	var act := act_of_deck()
	var pool: Array = CardDB.events.filter(func(e):
		return _act_in(act, e.get("acts", [1, 2, 3])) and not (String(e.get("id", "")) in seen_events))
	if pool.is_empty():
		seen_events.clear()   # quando esgotam (ou no infinito) voltam a poder repetir-se
		pool = CardDB.events.filter(func(e): return _act_in(act, e.get("acts", [1, 2, 3])))
	if pool.is_empty():
		return ""
	var ev: Dictionary = pool[rng.randi_range(0, pool.size() - 1)]
	seen_events.append(String(ev.get("id", "")))
	return String(ev.get("id", ""))

func next_ante() -> void:
	map_history[str(ante)] = map_choice.duplicate()
	ante += 1
	map_choice = {}
	map_phase = "battle"
	EventBus.ante_started.emit(ante)

## Nó escolhido num ante já passado ("" se não se sabe).
func map_chosen(a: int, phase: String) -> String:
	if a == ante:
		return String(map_choice.get(phase, ""))
	return String((map_history.get(str(a), {}) as Dictionary).get(phase, ""))

# --- Mapa da run (nós por ante) ---

## Opções deste ante: {"battle": ["scout","guard"] ou ["boss"], "stop": ["shop", X]}. Determinístico
## por run (semente própria, para não mexer no RNG das batalhas).
func map_options(a: int) -> Dictionary:
	var key := str(a)
	if map_plan.has(key):
		return map_plan[key]
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 31 + a * 7919
	var battle: Array = ["boss"] if is_boss_ante(a) else ["scout", "guard"]
	var stop: Array = ["shop"]
	if is_boss_ante(a):
		stop.append("merchant")
	else:
		var weights := {"event": 3.0, "rest": 2.0}
		if a >= 2:
			weights["spring"] = 1.0
		if a >= 3:
			weights["altar"] = 1.0
			weights["merchant"] = 1.0
		var total := 0.0
		for k in weights:
			total += weights[k]
		var roll := r.randf() * total
		var picked := "event"
		for k in weights:
			roll -= weights[k]
			if roll <= 0.0:
				picked = k
				break
		stop.append(picked)
	var opts := {"battle": battle, "stop": stop}
	map_plan[key] = opts
	return opts

## Regista a escolha de um nó do mapa.
func choose_battle(kind: String) -> void:
	map_choice["battle"] = kind
	map_phase = "battle"

func choose_stop(kind: String) -> void:
	map_choice["stop"] = kind
	map_phase = "stop"

## Cena para a paragem escolhida (e prepara o evento, se for o caso).
func stop_scene(kind: String) -> String:
	match kind:
		"shop", "merchant":
			return "shop"
		"event":
			pending_event = pick_event()
			return "event" if pending_event != "" else "shop"
		"rest", "spring", "altar":
			pending_event = "node_" + kind
			return "event"
	return "shop"

## Alvo de "vida" do inimigo por ante — tabela afinada por simulação (tests/Balance.gd),
## multiplicada pela dificuldade. Para lá do 8: ×1,6 por ante (Eternidade Cega).
const ANTE_HP := [3000, 7000, 14000, 24000, 46000, 78000, 125000, 190000]

func enemy_hp_for_ante(a: int) -> int:
	var base: float
	if a <= ANTE_HP.size():
		base = ANTE_HP[a - 1]
	else:
		base = ANTE_HP[-1] * pow(1.6, a - ANTE_HP.size())
	return int(round(base * DIFFICULTY_HP.get(difficulty, 1.0)))

func turns_for_ante(_a: int) -> int:
	return 5

func difficulty_name() -> String:
	return DIFFICULTY_NAMES.get(difficulty, difficulty)

func cycle_difficulty() -> void:
	var i := DIFFICULTIES.find(difficulty)
	difficulty = DIFFICULTIES[(i + 1) % DIFFICULTIES.size()]
	progress["difficulty"] = difficulty
	save_progress()

# ---------------------------------------------------------------------------
# Gravação da run (para "Continuar"). Grava-se no início de cada turno (com o estado da
# batalha), no mapa e ao entrar/sair da loja; retomar coloca o jogador exatamente nesse ponto.
# ---------------------------------------------------------------------------

func save_run(battle_state: Dictionary = {}, scene: String = "battle") -> void:
	if puzzle_id != "":
		return   # os quebra-cabeças não se gravam
	var data := {
		"version": 3,
		"deck_id": deck_def.get("id", "deck01"),
		"deck_def": deck_def if deck_def.get("custom", false) else {},
		"deck": deck,
		"relic_ids": relic_ids,
		"relic_locked": relic_locked,
		"ante": ante,
		"max_ante": max_ante,
		"gold": gold,
		"seed": seed_value,
		"rng_state": rng.state,
		"difficulty": difficulty,
		"free_mode": free_mode,
		"mode": mode,
		"stake": stake,
		"scene": scene,
		"battle": battle_state,
		"player_hp": player_hp,
		"player_max_hp": player_max_hp,
		"interest_ante": interest_ante,
		"seen_events": seen_events,
		"pending_event": pending_event,
		"current_enemy_id": current_enemy_id,
		"endless": endless,
		"planeswalker": planeswalker,
		"formation_levels": formation_levels,
		"map_plan": map_plan,
		"map_choice": map_choice,
		"map_history": map_history,
		"map_phase": map_phase,
		"run_channels": Stats.run_channels,
	}
	var f := FileAccess.open(RUN_SAVE, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))

func has_saved_run() -> bool:
	return FileAccess.file_exists(RUN_SAVE)

func load_run() -> bool:
	if not has_saved_run():
		return false
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(RUN_SAVE))
	if not (parsed is Dictionary):
		return false
	var saved_def: Dictionary = parsed.get("deck_def", {}) if parsed.get("deck_def") is Dictionary else {}
	deck_def = saved_def if not saved_def.is_empty() else CardDB.get_deck(String(parsed.get("deck_id", "deck01")))
	deck.clear()
	for e in parsed.get("deck", []):
		if not (e is Dictionary):
			continue
		var entry := _new_entry(String(e.get("id", "")))
		for k in e:
			entry[k] = e[k]
		entry["power_bonus"] = int(e.get("power_bonus", 0))
		entry["mult_bonus"] = float(e.get("mult_bonus", 0.0))
		deck.append(entry)
	relic_ids.clear()
	for r in parsed.get("relic_ids", []):
		relic_ids.append(String(r))
	relic_locked.clear()
	for r in parsed.get("relic_locked", []):
		relic_locked.append(String(r))
	ante = int(parsed.get("ante", 1))
	max_ante = int(parsed.get("max_ante", 8))
	gold = int(parsed.get("gold", 4))
	seed_value = int(parsed.get("seed", 0))
	rng.seed = seed_value
	rng.state = int(parsed.get("rng_state", rng.state))
	difficulty = String(parsed.get("difficulty", "normal"))
	free_mode = bool(parsed.get("free_mode", false))
	mode = String(parsed.get("mode", "free" if free_mode else "campaign"))
	stake = int(parsed.get("stake", 1))
	player_max_hp = int(parsed.get("player_max_hp", 20))
	player_hp = clampi(int(parsed.get("player_hp", player_max_hp)), 1, player_max_hp)
	interest_ante = int(parsed.get("interest_ante", 0))
	seen_events.clear()
	for e in parsed.get("seen_events", []):
		seen_events.append(String(e))
	pending_event = String(parsed.get("pending_event", ""))
	current_enemy_id = String(parsed.get("current_enemy_id", ""))
	endless = bool(parsed.get("endless", false))
	planeswalker = parsed.get("planeswalker", {}) if parsed.get("planeswalker") is Dictionary else {}
	if not planeswalker.is_empty():
		planeswalker["loyalty"] = int(planeswalker.get("loyalty", 2))
	formation_levels = {}
	var fl = parsed.get("formation_levels", {})
	if fl is Dictionary:
		for k in fl:
			formation_levels[String(k)] = int(fl[k])
	map_plan = {}
	var mp = parsed.get("map_plan", {})
	if mp is Dictionary:
		for k in mp:
			map_plan[String(k)] = mp[k]
	map_choice = parsed.get("map_choice", {}) if parsed.get("map_choice") is Dictionary else {}
	map_history = {}
	var mh = parsed.get("map_history", {})
	if mh is Dictionary:
		for k in mh:
			map_history[String(k)] = mh[k]
	map_phase = String(parsed.get("map_phase", "battle"))
	puzzle_id = ""
	Stats.run_channels = int(parsed.get("run_channels", 0))
	last_unlocks.clear()
	last_victory = false
	saved_scene = String(parsed.get("scene", "battle"))
	pending_battle = {}
	if int(parsed.get("version", 1)) >= 2 and parsed.get("battle") is Dictionary:
		pending_battle = parsed["battle"]
	EventBus.gold_changed.emit(gold)
	return true

func clear_saved_run() -> void:
	pending_battle = {}
	if has_saved_run():
		DirAccess.remove_absolute(ProjectSettings.globalize_path(RUN_SAVE))

## Abandonar a run a meio: conta como derrota no ante atual (na campanha) e apaga a gravação.
func abandon_run() -> void:
	record_run_end(ante, false)
	clear_saved_run()
	last_victory = false
	EventBus.run_ended.emit(false)

## Apaga todo o progresso da campanha (Configurações → Apagar progresso).
func reset_progress() -> void:
	progress = {"best_ante": {}, "wins": {}, "difficulty": difficulty}
	Stats._ensure()
	save_progress()
	clear_saved_run()

# ---------------------------------------------------------------------------
# Progresso da campanha: melhor ante por baralho, vitórias, selos vencidos, desbloqueios.
# ---------------------------------------------------------------------------

func load_progress() -> void:
	if not FileAccess.file_exists(PROGRESS_SAVE):
		return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(PROGRESS_SAVE))
	if parsed is Dictionary:
		progress = parsed
		if not progress.has("best_ante"):
			progress["best_ante"] = {}
		if not progress.has("wins"):
			progress["wins"] = {}
		difficulty = String(progress.get("difficulty", "normal"))

func save_progress() -> void:
	var f := FileAccess.open(PROGRESS_SAVE, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(progress))

func best_ante(deck_id: String) -> int:
	return int(progress["best_ante"].get(deck_id, 0))

func wins(deck_id: String) -> int:
	return int(progress["wins"].get(deck_id, 0))

## Selo Planar mais alto vencido com este baralho (0 = nenhum).
func stake_won(deck_id: String) -> int:
	if not (progress.get("stakes") is Dictionary):
		return 0
	return int(progress["stakes"].get(deck_id, 0))

## Selo máximo que podes escolher para um baralho: o seguinte ao último vencido.
func max_stake(deck_id: String) -> int:
	if free_mode:
		return STAKES.size()
	return clampi(stake_won(deck_id) + 1, 1, STAKES.size())

## Regista o fim de uma run (ante atingido; vitória = passou o último ante). Devolve os desbloqueios novos.
func record_run_end(reached_ante: int, victory: bool) -> Array[String]:
	last_unlocks.clear()
	Stats.on_run_end(victory)
	if free_mode:
		save_progress()
		return last_unlocks
	var id := String(deck_def.get("id", ""))
	var before := _unlocked_deck_ids()
	var reached := reached_ante + (1 if victory else 0)
	progress["best_ante"][id] = max(best_ante(id), reached)
	if victory:
		progress["wins"][id] = wins(id) + 1
		if not (progress.get("stakes") is Dictionary):
			progress["stakes"] = {}
		progress["stakes"][id] = max(stake_won(id), stake)
	save_progress()
	for did in _unlocked_deck_ids():
		if not (did in before):
			last_unlocks.append(String(CardDB.get_deck(did).get("name", did)))
	return last_unlocks

## Desbloqueio: o 1.º capítulo de cada livro aberto está livre; cada capítulo desbloqueia o seguinte
## ao chegar ao ante 4; um livro abre quando algum capítulo do livro anterior chega ao ante 6.
func is_act_unlocked(act_index: int) -> bool:
	if act_index == 0:
		return true
	var prev: Dictionary = CardDB.campaign[act_index - 1]
	for ch in prev.get("chapters", []):
		if best_ante(String(ch["deck_id"])) >= 6:
			return true
	return false

func is_deck_unlocked(deck_id: String) -> bool:
	for act_index in CardDB.campaign.size():
		var act: Dictionary = CardDB.campaign[act_index]
		var chapters: Array = act.get("chapters", [])
		for i in chapters.size():
			if String(chapters[i]["deck_id"]) != deck_id:
				continue
			if not is_act_unlocked(act_index):
				return false
			if i == 0:
				return true
			return best_ante(String(chapters[i - 1]["deck_id"])) >= 4
	return false

func _unlocked_deck_ids() -> Array[String]:
	var out: Array[String] = []
	for act in CardDB.campaign:
		for ch in act.get("chapters", []):
			if is_deck_unlocked(String(ch["deck_id"])):
				out.append(String(ch["deck_id"]))
	return out
