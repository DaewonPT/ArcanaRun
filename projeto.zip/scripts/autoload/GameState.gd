extends Node
## Estado da run atual (o "save" em memória), progresso da campanha e gravação em disco.
## Não contém lógica de batalha — isso vive em BattleManager.
##
## Uma run são 8 antes em 5 atos (I: 1–2, II: 3–4 com boss, III: 5–6, IV: 7–8 com o boss final,
## V: modo infinito). Em cada ante o mapa oferece uma batalha (Batedor ou Guarda; boss nos antes
## múltiplos de 4) e depois uma paragem (Loja ou outra: evento, acampamento, Fonte de Mana,
## Altar de Phyrexia, Mercador Cego, Quadro de Contratos, Tribunal dos Deuses). Os Selos Planares
## (1–8) são a dificuldade progressiva por baralho; Fácil/Normal/Difícil é o modificador global.
## 0.9.0: cada ato tem um Clima Planar (data/climates.json); depois de um boss que não acaba a run
## há um Baú de Espólio com relíquias de boss (espaço à parte, `boss_relics`); um contrato ativo
## (data/contracts.json) é avaliado no fim da batalha seguinte.
## 0.10.0: Vales comprados na loja (`vouchers`), Némesis (rival que aparece nos antes 3, 5 e 7 no lugar
## da Elite, cada vez mais forte), Desafios (mode "challenge", regras fixas em challenges.json),
## História (mode "saga", capítulos de saga.json), resumo da run (`run_log`) e Modo Treino.

const RUN_SAVE := "user://run.json"
const PROGRESS_SAVE := "user://progress.json"

const DIFFICULTIES := ["facil", "normal", "dificil"]
const DIFFICULTY_NAMES := {"facil": "Fácil", "normal": "Normal", "dificil": "Difícil"}
const DIFFICULTY_HP := {"facil": 0.7, "normal": 1.0, "dificil": 1.4}
const DIFFICULTY_DISCARDS := {"facil": 4, "normal": 3, "dificil": 2}
const MAX_RELICS := 5
const BOSS_EVERY := 4                 # antes 4, 8, 12… têm boss; o 8 é o boss final
const GUARD_HP_MULT := 1.25
const GUARD_GOLD := 4
const ELITE_HP_MULT := 1.6          # Elite: +60 % de vida, +2 de ataque, +6 ouro e uma relíquia garantida
const ELITE_ATTACK := 2
const ELITE_GOLD := 6
const ELITE_CHANCE := 0.6           # probabilidade de haver nó de Elite num ante (a partir do 2.º, fora dos bosses)
const ACT_NAMES := ["I", "II", "III", "IV", "V"]
const STAKES := [
	{"name": "Iniciado", "text": "Dificuldade padrão."},
	{"name": "Taxa do Senado", "text": "As batalhas contra Batedores não dão ouro base."},
	{"name": "Fome de Mana", "text": "A vida dos bosses sobe 35% a partir do ante 3."},
	{"name": "Decreto de Silêncio", "text": "Máximo de 2 canalizações por batalha."},
	{"name": "Marca Eterna", "text": "As relíquias compradas na loja não podem ser vendidas."},
	{"name": "Infeção de Óleo", "text": "As cartas dos boosters podem vir infetadas: Poder a dobrar, mas exilam-se ao fim de 3 utilizações."},
	{"name": "Eclipse da Mente", "text": "A mão passa a 5 cartas."},
	{"name": "Ascensão Mítica", "text": "Abaixo de metade da vida, os bosses ativam uma 2.ª regra."},
]
const STOP_NODES := ["shop", "event", "rest", "spring", "altar", "merchant", "contracts", "tribunal"]
const LOOT_CHOICES := 3
const INTEREST_CAP := 5
const NEMESIS_ANTES := {3: 1, 5: 2, 7: 3}   # ante → nível da Némesis
const MEDALS := ["", "bronze", "bronze", "bronze", "silver", "silver", "silver", "gold", "gold"]

var rng := RandomNumberGenerator.new()
var seed_value: int = 0

# --- Run ---
var ante: int = 1
var max_ante: int = 8
var gold: int = 4
var player_max_hp: int = 20
var player_hp: int = 20
var difficulty: String = "normal"
var free_mode: bool = false          # Modo Livre: não conta para a campanha
var mode: String = "campaign"        # "campaign" | "free" | "draft"
var stake: int = 1                   # Selo Planar (1–8)
var last_victory: bool = false       # a última run terminou em vitória (para o ecrã final)
var interest_ante: int = 0           # último ante em que a loja pagou juros
var seen_events: Array[String] = []  # eventos já mostrados nesta run
var pending_event: String = ""       # evento gravado a meio (para retomar)
var current_enemy_id: String = ""    # inimigo da batalha atual (para o ecrã final)
var endless: bool = false            # modo infinito: continuar depois do ante 8
var planeswalker: Dictionary = {}    # {"id", "loyalty"} ou vazio
var formation_levels: Dictionary = {} # id da formação → nível (Selo da Sabedoria)
var relic_locked: Array[String] = [] # relíquias compradas na loja com o Selo Planar 5 (não se vendem)
var map_plan: Dictionary = {}        # ante (String) → {"battle": [...], "stop": [...]}
var map_choice: Dictionary = {}      # escolhas do ante atual: {"battle": "scout"|"guard"|"boss", "stop": "..."}
var map_history: Dictionary = {}     # ante (String) → escolhas feitas (para o mapa mostrar o caminho)
var map_phase: String = "battle"     # o que o mapa pede a seguir: "battle" ou "stop"
var puzzle_id: String = ""           # quebra-cabeças em curso ("" = nenhum)
var boss_relics: Array[String] = []  # relíquias de boss (Baú de Espólio), fora do limite de 5
var loot_offer: Array[String] = []   # ofertas do Baú de Espólio pendente (para retomar)
var climates: Dictionary = {}        # chave do ato ("1".."4", "E<n>" no infinito) → id do clima
var contract: Dictionary = {}        # contrato ativo (definição de contracts.json) ou vazio
var death_save_used: bool = false    # Coração de Vidro já salvou nesta run
var relic_counters: Dictionary = {}  # relíquias que escalam: id → contador desde que a tens
var interlude_key: String = ""       # último ato (chave do clima) cujo interlúdio já se mostrou
# 0.10.0
var vouchers: Array[String] = []     # Vales comprados nesta run
var nemesis_id: String = ""          # rival desta run ("" = ainda não escolhido)
var nemesis_beaten: Array[int] = []  # níveis da Némesis já vencidos nesta run
var challenge_id: String = ""        # Desafio em curso ("" = nenhum)
var saga_id: String = ""             # capítulo da História em curso ("" = nenhum)
var run_log: Dictionary = {}         # resumo: {"damage_by_ante": {ante: dano}, "card_dmg": {id: dano}, "relic_dmg": {id: dano}, "best_hit": n}
var training: Dictionary = {}        # Modo Treino: {"hand": [ids], "relics": [ids], "mana": n}
var last_reward_text: String = ""    # recompensa especial da última batalha (Némesis), para a UI

# --- Baralho persistente: uma entrada por carta, com bónus permanentes ---
var deck: Array[Dictionary] = []     # {"id": "c001", "power_bonus": 0, "mult_bonus": 0.0, "seal": "", ...}
var deck_def: Dictionary = {}        # definição do baralho escolhido (decks.json)
var relic_ids: Array[String] = []

# --- Progresso da campanha (persistente) ---
var progress: Dictionary = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
var last_unlocks: Array[String] = []   # nomes desbloqueados na última run (para o ecrã final)

# --- Retoma ---
var pending_battle: Dictionary = {}    # batalha gravada a meio (BattleManager.to_dict), consumida pela cena Battle
var saved_scene: String = "battle"     # onde a run gravada estava: "battle", "shop", "event" ou "map"

func _ready() -> void:
	load_progress()

func new_run(deck_id: String = "deck01", seed_override: int = 0, p_stake: int = 1) -> void:
	seed_value = seed_override if seed_override != 0 else randi()
	rng.seed = seed_value
	ante = 1
	max_ante = 8
	gold = 4
	player_max_hp = 20
	player_hp = player_max_hp
	mode = "free" if free_mode else "campaign"
	stake = clampi(p_stake, 1, STAKES.size())
	relic_ids.clear()
	relic_locked.clear()
	last_unlocks.clear()
	last_victory = false
	interest_ante = 0
	seen_events.clear()
	pending_event = ""
	current_enemy_id = ""
	endless = false
	planeswalker = {}
	formation_levels = {}
	map_plan = {}
	map_choice = {}
	map_history = {}
	map_phase = "battle"
	puzzle_id = ""
	boss_relics.clear()
	loot_offer.clear()
	climates = {}
	contract = {}
	death_save_used = false
	relic_counters = {}
	interlude_key = ""
	vouchers.clear()
	nemesis_beaten.clear()
	challenge_id = ""
	saga_id = ""
	run_log = {}
	last_reward_text = ""
	nemesis_id = ""
	deck_def = CardDB.get_deck(deck_id)
	deck.clear()
	for id in deck_def.get("cards", []):
		deck.append(_new_entry(String(id)))
	if mode == "campaign" or mode == "free":
		nemesis_id = _pick_nemesis()
	EventBus.run_started.emit()
	EventBus.gold_changed.emit(gold)

## Desafio: baralho e regras fixos (challenges.json); não conta para a campanha.
func new_challenge_run(id: String, seed_override: int = 0) -> void:
	var ch := CardDB.get_challenge(id)
	free_mode = true
	new_run(String(ch.get("deck_id", "deck01")), seed_override, 1)
	mode = "challenge"
	challenge_id = id
	nemesis_id = ""
	_apply_start_rules()

## História: capítulo de 4 antes com regra própria, cartas extra e boss do capítulo.
func new_saga_run(id: String, seed_override: int = 0) -> void:
	var ch := CardDB.get_saga_chapter(id)
	free_mode = true
	new_run(String(ch.get("deck_id", "deck01")), seed_override, 1)
	mode = "saga"
	saga_id = id
	nemesis_id = ""
	max_ante = int(ch.get("antes", 4))
	for cid in ch.get("add_cards", []):
		if CardDB.get_card(String(cid)) != null:
			deck.append(_new_entry(String(cid)))
	_apply_start_rules()

## Regras que mexem no início da run (vida máxima).
func _apply_start_rules() -> void:
	var hp := int(run_rule("max_hp", 0))
	if hp > 0:
		player_max_hp = hp
		player_hp = hp
		EventBus.player_hp_changed.emit(player_hp, player_max_hp)

## Valor de uma regra da run (Desafio ou capítulo da História); `default` se não houver.
func run_rule(key: String, fallback = null):
	if challenge_id != "":
		var r: Dictionary = CardDB.get_challenge(challenge_id).get("rules", {})
		if r.has(key):
			return r[key]
	if saga_id != "":
		var r2: Dictionary = CardDB.get_saga_chapter(saga_id).get("rule", {})
		if r2.has(key):
			return r2[key]
	return fallback

## Regras que o BattleManager junta às do boss.
func battle_rules() -> Dictionary:
	var out := {}
	if puzzle_id != "":
		return out
	for key in ["cost_max", "start_tokens", "first_spell_free", "spell_mult", "enemy_attack_plus"]:
		var v = run_rule(key)
		if v != null:
			out[key] = v
	if out.has("spell_mult") and saga_id != "":
		out["rule_name"] = String(CardDB.get_saga_chapter(saga_id).get("name", ""))
	return out

## Nome do modo para os ecrãs ("" na campanha normal).
func mode_title() -> String:
	if challenge_id != "":
		return TranslationServer.translate("Desafio") + ": " + TranslationServer.translate(String(CardDB.get_challenge(challenge_id).get("name", "")))
	if saga_id != "":
		return TranslationServer.translate(String(CardDB.get_saga_chapter(saga_id).get("name", "")))
	return ""

## Arena Draft: baralho montado na hora, run curta (4 antes), não conta para a campanha.
func new_draft_run(card_ids: Array, colors: Array, seed_override: int = 0) -> void:
	free_mode = true
	new_run("deck01", seed_override, 1)
	mode = "draft"
	max_ante = 4
	deck_def = {"id": "draft", "num": 0, "name": "Arena Draft", "colors": colors, "color_code": "", "size": card_ids.size(),
		"mechanic": "Baralho de draft", "difficulty": 3, "cards": card_ids, "custom": true}
	deck.clear()
	for id in card_ids:
		deck.append(_new_entry(String(id)))
	EventBus.run_started.emit()

static func _new_entry(id: String) -> Dictionary:
	return {"id": id, "power_bonus": 0, "mult_bonus": 0.0}

## Cores do baralho atual (para a loja).
func deck_colors() -> Array:
	return deck_def.get("colors", [])

## Cor principal do baralho (a primeira; "" se for incolor) — Fonte de Mana.
func main_color() -> String:
	var cols := deck_colors()
	return String(cols[0]) if not cols.is_empty() else ""

func deck_ids() -> Array[String]:
	var out: Array[String] = []
	for e in deck:
		out.append(String(e["id"]))
	return out

func add_gold(amount: int) -> void:
	gold = max(0, gold + amount)
	EventBus.gold_changed.emit(gold)

func spend_gold(amount: int) -> bool:
	if gold < amount:
		return false
	gold -= amount
	EventBus.gold_changed.emit(gold)
	return true

func add_card(id: String, infected: bool = false) -> void:
	var e := _new_entry(id)
	if infected:
		e["infected"] = true
	deck.append(e)
	Stats.mark_seen("cards", id, false)
	bump_relic_counters("card_added")

## Acampamento → Forjar: a carta passa à versão "+" (efeitos ×1,5).
func forge_plus(entry_index: int) -> bool:
	if entry_index < 0 or entry_index >= deck.size() or bool(deck[entry_index].get("plus", false)):
		return false
	deck[entry_index]["plus"] = true
	Stats.on_plus_card()
	return true

## Remove UMA cópia da carta. Devolve false se não existir.
func remove_card(id: String) -> bool:
	for i in deck.size():
		if deck[i]["id"] == id:
			deck.remove_at(i)
			return true
	return false

## Apaga do baralho as entradas exiladas durante a batalha (Selo Phyrexiano a 0, infeção).
func purge_exiled() -> void:
	for i in range(deck.size() - 1, -1, -1):
		if deck[i].get("exiled_run", false):
			deck.remove_at(i)

## Custo de remover uma carta na loja: sobe com o ante para não ser trivial afinar o deck.
func removal_price() -> int:
	return 2 + int(ante / 3)

## Contagem por id, para listar o deck sem repetições.
func deck_counts() -> Dictionary:
	var counts := {}
	for e in deck:
		counts[e["id"]] = counts.get(e["id"], 0) + 1
	return counts

## Lugares para relíquias (5; +1 com o Vale da Prateleira).
func max_relics() -> int:
	return MAX_RELICS + int(voucher_value("relic_slots"))

## Desafio "Mãos Vazias": nenhuma relíquia.
func relics_allowed() -> bool:
	return not bool(run_rule("no_relics", false))

## Devolve false se já a tiveres ou se não houver espaço (max_relics()).
func add_relic(id: String) -> bool:
	if id in relic_ids or relic_ids.size() >= max_relics() or not relics_allowed():
		return false
	relic_ids.append(id)
	if CardDB.relics.get(id, {}).has("scaling"):
		relic_counters[id] = 0   # as relíquias que escalam começam do zero quando as ganhas
	EventBus.relic_gained.emit(id)
	return true

func remove_relic(id: String) -> void:
	relic_ids.erase(id)
	relic_locked.erase(id)
	relic_counters.erase(id)
	EventBus.relics_changed.emit()

func move_relic(id: String, index: int) -> void:
	if not (id in relic_ids):
		return
	relic_ids.erase(id)
	relic_ids.insert(clampi(index, 0, relic_ids.size()), id)
	EventBus.relics_changed.emit()

func relic_sell_price(id: String) -> int:
	return max(1, int(CardDB.relics.get(id, {}).get("price", 4)) / 2)

func has_relic(id: String) -> bool:
	return id in relic_ids or id in boss_relics

## Relíquias que disparam: as da prateleira e as de boss.
func active_relic_ids() -> Array[String]:
	var out: Array[String] = relic_ids.duplicate()
	out.append_array(boss_relics)
	return out

## Soma dos valores dos efeitos "passive" com esta ação em todas as relíquias ativas.
func relic_passive(action: String) -> float:
	var total := 0.0
	for id in active_relic_ids():
		for e in CardDB.relics.get(id, {}).get("effects", []):
			if String(e.get("trigger", "")) == "passive" and String(e.get("action", "")) == action:
				total += float(e.get("value", 1))
	return total

# --- Relíquias que escalam (contador desde que a relíquia é tua) ---

func relic_counter(id: String) -> int:
	return int(relic_counters.get(id, 0))

## Avança os contadores das relíquias que escalam com este acontecimento:
## "battle_won" · "channel" · "life_lost" (quantidade = vida) · "card_added".
func bump_relic_counters(event: String, amount: int = 1) -> void:
	if amount <= 0:
		return
	for id in active_relic_ids():
		var sc: Dictionary = CardDB.relics.get(id, {}).get("scaling", {})
		if String(sc.get("event", "")) == event:
			relic_counters[id] = relic_counter(id) + amount

## "Agora: +3 Mult" — o valor atual de uma relíquia que escala ("" nas outras).
func relic_scaling_text(id: String) -> String:
	var r: Dictionary = CardDB.relics.get(id, {})
	if not r.has("scaling"):
		return ""
	var n := relic_counter(id)
	for e in r.get("effects", []):
		if String(e.get("per", "")) != "relic_counter":
			continue
		var count := n
		if e.has("per_div"):
			count = int(n / maxi(1, int(e["per_div"])))
		var v := float(e.get("value", 0))
		match String(e.get("action", "")):
			"mult_add":
				return TranslationServer.translate("Agora: +%s Mult") % Cascade.fmt_mult(v * count)
			"power_add":
				return TranslationServer.translate("Agora: +%d Poder") % int(v * count)
			"mult_mul":
				return TranslationServer.translate("Agora: ×%s Mult") % Cascade.fmt_mult(1.0 + v * count)
	return ""

## Elite vencido: uma relíquia ao acaso (se houver lugar; senão 10 ouro). Devolve o id ou "".
func grant_elite_relic() -> String:
	var id := random_new_relic()
	if id != "" and add_relic(id):
		return id
	add_gold(10)
	return ""

## Baú de Espólio: 3 relíquias de boss que ainda não tenhas (sorteio próprio, determinístico por ante).
func prepare_loot() -> Array[String]:
	loot_offer.clear()
	if not relics_allowed():
		return loot_offer   # Desafio "Mãos Vazias": sem Baú de Espólio
	var pool: Array = CardDB.relics.values().filter(func(r): return bool(r.get("boss", false)) and not (String(r.get("id", "")) in boss_relics))
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 17 + ante * 104729
	for i in LOOT_CHOICES:
		if pool.is_empty():
			break
		var pick: Dictionary = pool[r.randi_range(0, pool.size() - 1)]
		pool.erase(pick)
		loot_offer.append(String(pick.get("id", "")))
	return loot_offer

func add_boss_relic(id: String) -> bool:
	if id == "" or id in boss_relics or not CardDB.relics.has(id) or not relics_allowed():
		return false
	boss_relics.append(id)
	loot_offer.clear()
	for e in CardDB.relics[id].get("effects", []):
		if String(e.get("trigger", "")) == "on_gain" and String(e.get("action", "")) == "max_hp":
			change_max_hp(int(e.get("value", 0)))
	Stats.mark_seen("relics", id, false)
	Stats.on_boss_relic()
	EventBus.relics_changed.emit()
	return true

## Coração de Vidro: uma vez por run, um golpe mortal deixa-te com 1 de vida.
func can_death_save() -> bool:
	return not death_save_used and relic_passive("death_save") > 0

func use_death_save() -> void:
	death_save_used = true

## Preço na loja (o Cálice do Abismo cobra +2 em tudo).
func shop_price(base: int) -> int:
	return base + int(relic_passive("shop_tax"))

## Relíquia ao acaso que ainda não tenhas (para eventos; nunca lendárias). "" se não houver.
func random_new_relic() -> String:
	var pool: Array = CardDB.relics.keys().filter(func(r): return not (r in relic_ids) and not bool(CardDB.relics[r].get("legendary", false)) and not bool(CardDB.relics[r].get("boss", false)) and CardDB.is_relic_available(CardDB.relics[r]))
	if pool.is_empty():
		return ""
	return String(pool[rng.randi_range(0, pool.size() - 1)])

# --- Vida (persistente ao longo da run) ---

func heal(amount: int) -> void:
	player_hp = clampi(player_hp + amount, 0, player_max_hp)
	EventBus.player_hp_changed.emit(player_hp, player_max_hp)

func change_max_hp(amount: int) -> void:
	player_max_hp = max(5, player_max_hp + amount)
	player_hp = clampi(player_hp, 1, player_max_hp)
	EventBus.player_hp_changed.emit(player_hp, player_max_hp)

func damage_player(amount: int) -> void:
	player_hp = max(0, player_hp - amount)
	EventBus.player_hp_changed.emit(player_hp, player_max_hp)

## Juros da loja: +1 ouro por cada 5 guardados (máx. 5; a dobrar com o Dízimo Dobrado), uma vez por ante.
func interest_due() -> int:
	if interest_ante == ante:
		return 0
	var cap := interest_cap()
	var due := mini(cap, int(gold / 5))
	if "relic_double_tithe" in relic_ids:
		due = mini(cap * 2, due * 2)
	return due

## Máximo de juros por loja (5; 8 com o Vale do Cofre).
func interest_cap() -> int:
	return INTEREST_CAP + int(voucher_value("interest_cap"))

func pay_interest() -> int:
	var due := interest_due()
	interest_ante = ante
	if due > 0:
		add_gold(due)
	return due

# --- Planeswalker (um por run; lealdade atravessa as batalhas) ---

func planeswalker_def() -> Dictionary:
	return CardDB.get_planeswalker(String(planeswalker.get("id", ""))) if not planeswalker.is_empty() else {}

func planeswalker_color() -> String:
	return String(planeswalker_def().get("color", ""))

func planeswalker_loyalty() -> int:
	return int(planeswalker.get("loyalty", 0))

func set_planeswalker(id: String) -> void:
	var def := CardDB.get_planeswalker(id)
	if def.is_empty():
		return
	planeswalker = {"id": id, "loyalty": int(def.get("loyalty", 2))}
	Stats.mark_seen("planeswalkers", id, false)
	EventBus.planeswalker_changed.emit()

func change_loyalty(amount: int) -> void:
	if planeswalker.is_empty():
		return
	var max_l := int(planeswalker_def().get("max_loyalty", 6))
	planeswalker["loyalty"] = clampi(planeswalker_loyalty() + amount, 0, max_l)
	EventBus.planeswalker_changed.emit()

# --- Formações com nível (Selo da Sabedoria) ---

func formation_level(id: String) -> int:
	return int(formation_levels.get(id, 0))

func level_up_random_formation() -> String:
	if CardDB.formations.is_empty():
		return ""
	var f: Dictionary = CardDB.formations[rng.randi_range(0, CardDB.formations.size() - 1)]
	var id := String(f.get("id", ""))
	formation_levels[id] = formation_level(id) + 1
	EventBus.formation_leveled.emit(id, formation_levels[id])
	return id

# --- Selos Planares ---

func stake_name(n: int = -1) -> String:
	var i := clampi((stake if n < 0 else n) - 1, 0, STAKES.size() - 1)
	return String(STAKES[i].get("name", ""))

func hand_size_for_battle() -> int:
	var base := 5 if stake >= 7 else BattleManager.HAND_SIZE
	base = mini(base, int(run_rule("hand_size", base)))
	return base + int(relic_passive("hand_plus")) + int(voucher_value("hand_plus"))

func discards_for_battle() -> int:
	if bool(run_rule("no_channel", false)):
		return 0
	var n := int(DIFFICULTY_DISCARDS.get(difficulty, 3))
	if stake >= 4:
		n = mini(n, 2)
	return n - int(relic_passive("discards_minus")) + int(voucher_value("discards_plus"))

## Ouro por vencer uma batalha: 4 base + ante + turnos que sobraram (+4 nos Guardas; sem base nos
## Batedores com o Selo Planar 2). Relógio de Bolso: até ao turno 3, cada turno que sobra vale +3.
## Ampulheta de Areia Negra: −3.
func battle_reward(turns_left: int, won_on_turn: int = 99) -> int:
	if bool(run_rule("no_battle_gold", false)):
		return 0
	var variant := String(map_choice.get("battle", "scout"))
	var base := 4
	if stake >= 2 and variant == "scout":
		base = 0
	var bonus := GUARD_GOLD if variant == "guard" else (ELITE_GOLD if variant == "elite" else 0)
	var per_turn := 1
	var early := int(relic_passive("early_bonus"))
	if early > 0 and won_on_turn <= 3:
		per_turn = early
	return max(0, base + ante + turns_left * per_turn + bonus - int(relic_passive("reward_minus")) + int(voucher_value("reward_plus")))

# --- Inimigos e bosses ---

## Livro (1-3) do baralho atual, pela campanha; 1 se não constar.
func act_of_deck() -> int:
	var id := String(deck_def.get("id", ""))
	for i in CardDB.campaign.size():
		for ch in CardDB.campaign[i].get("chapters", []):
			if String(ch.get("deck_id", "")) == id:
				return i + 1
	return 1

## Ato da run (1–5) de um ante: dois antes por ato; o infinito é o ato V.
func act_of_ante(a: int) -> int:
	if a > max_ante:
		return 5
	return clampi(int((a - 1) / 2) + 1, 1, 5)

func act_name(a: int = -1) -> String:
	return ACT_NAMES[act_of_ante(ante if a < 0 else a) - 1]

## Bosses de N em N antes (4; 2 no Desafio "Maratona de Bosses").
func boss_every() -> int:
	return maxi(1, int(run_rule("boss_every", BOSS_EVERY)))

func is_boss_ante(a: int) -> bool:
	return a % boss_every() == 0 or (mode == "saga" and a == max_ante)

func current_enemy_is_boss() -> bool:
	for e in CardDB.enemies:
		if String(e.get("id", "")) == current_enemy_id:
			return bool(e.get("boss", false))
	return false

## Escolhe o inimigo de um ante: boss nos antes múltiplos de 4 (final no último), senão um do
## conjunto do livro do baralho com min_ante <= ante. Devolve a definição pronta para BattleManager.start.
## O Guarda (mapa) tem +25 % de vida; o Selo Planar 3 dá +35 % aos bosses a partir do ante 3.
func pick_enemy(a: int) -> Dictionary:
	var act := act_of_deck()
	var def: Dictionary = {}
	var variant0 := String(map_choice.get("battle", "scout"))
	if variant0 == "nemesis" and nemesis_def().size() > 0:
		return _nemesis_enemy(a)
	if is_boss_ante(a):
		var saga_boss := String(CardDB.get_saga_chapter(saga_id).get("boss", "")) if saga_id != "" else ""
		if saga_boss != "" and a == max_ante and not CardDB.enemy_def(saga_boss).is_empty():
			def = CardDB.enemy_def(saga_boss)
		else:
			var bosses: Array = CardDB.enemies.filter(func(e): return bool(e.get("boss", false)) and not bool(e.get("saga", false)) and (bool(e.get("final", false)) == (a == max_ante) or a > max_ante))
			if bosses.is_empty():
				bosses = CardDB.enemies.filter(func(e): return bool(e.get("boss", false)) and not bool(e.get("saga", false)))
			def = bosses[rng.randi_range(0, bosses.size() - 1)]
	else:
		var pool: Array = CardDB.enemies.filter(func(e):
			if bool(e.get("boss", false)) or bool(e.get("saga", false)) or int(e.get("min_ante", 1)) > a:
				return false
			return _act_in(act, e.get("acts", [1, 2, 3])) or a > max_ante)
		if pool.is_empty():
			pool = CardDB.enemies.filter(func(e): return not bool(e.get("boss", false)))
		def = pool[rng.randi_range(0, pool.size() - 1)]
	var mult := float(def.get("hp_mult", 1.0))
	var variant := String(map_choice.get("battle", "scout"))
	if variant == "guard" and not bool(def.get("boss", false)):
		mult *= GUARD_HP_MULT
	if variant == "elite" and not bool(def.get("boss", false)):
		mult *= ELITE_HP_MULT
	if bool(def.get("boss", false)) and stake >= 3 and a >= 3:
		mult *= 1.35
	mult *= 1.0 + relic_passive("enemy_hp_pct") / 100.0
	if climate_for_ante(a) == "temporal_echo":
		mult *= 1.15
	var hp := int(round(enemy_hp_for_ante(a) * mult))
	current_enemy_id = String(def.get("id", ""))
	return {
		"id": def.get("id", ""),
		"name": def.get("name", "?"),
		"hp": hp, "max_hp": hp,
		"attack": int(def.get("attack", 0)) + (ELITE_ATTACK if variant == "elite" and not bool(def.get("boss", false)) else 0),
		"text": def.get("text", ""),
		"abilities": def.get("abilities", []),
		"boss": bool(def.get("boss", false)),
		"rule": def.get("rule", {}),
		"rule2": def.get("rule2", {}),
		"rule2_text": def.get("rule2_text", ""),
		"lines": def.get("lines", {}),
		"variant": variant,
		"portrait": String(def.get("portrait", "")),
		"shield_pct": float(def.get("shield_pct", 0)),
		"minions": int(def.get("minions", 0)),
		"minion_hits": int(def.get("minion_hits", BattleManager.MINION_HITS)),
	}

# --- Némesis ---

## Rival da run: um dos de nemesis.json cuja cor o baralho não tenha (sorteio próprio, pela semente).
func _pick_nemesis() -> String:
	if CardDB.nemeses.is_empty():
		return ""
	var cols := deck_colors()
	var pool: Array = CardDB.nemeses.filter(func(n): return not (String(n.get("color", "")) in cols))
	if pool.is_empty():
		pool = CardDB.nemeses.duplicate()
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 53 + 7
	return String(pool[r.randi_range(0, pool.size() - 1)].get("id", ""))

func nemesis_def() -> Dictionary:
	if nemesis_id == "" and (mode == "campaign" or mode == "free"):
		nemesis_id = _pick_nemesis()
	return CardDB.get_nemesis(nemesis_id) if nemesis_id != "" else {}

## Nível da Némesis num ante (1–3; 0 se não aparece lá).
func nemesis_level(a: int) -> int:
	if mode != "campaign" and mode != "free":
		return 0
	return int(NEMESIS_ANTES.get(a, 0))

func _nemesis_enemy(a: int) -> Dictionary:
	var n := nemesis_def()
	var levels: Array = n.get("levels", [])
	var lv := clampi(nemesis_level(a), 1, maxi(1, levels.size()))
	var L: Dictionary = levels[lv - 1] if not levels.is_empty() else {}
	var hp := int(round(enemy_hp_for_ante(a) * float(L.get("hp_mult", 1.3)) * (1.0 + relic_passive("enemy_hp_pct") / 100.0)))
	current_enemy_id = String(n.get("id", ""))
	return {
		"id": n.get("id", ""), "name": n.get("name", "?"), "hp": hp, "max_hp": hp,
		"attack": int(L.get("attack", 3)),
		"text": String(n.get("text", "")),
		"abilities": n.get("abilities", []),
		"boss": false, "rule": {}, "rule2": {}, "rule2_text": "",
		"lines": {"intro": String(L.get("line", "")), "defeat": String(L.get("defeat", ""))},
		"variant": "nemesis", "nemesis_level": lv,
		"portrait": String(n.get("portrait", "knight")),
		"shield_pct": float(L.get("shield_pct", 0)),
		"minions": int(L.get("minions", 0)),
		"minion_hits": BattleManager.MINION_HITS,
	}

## Recompensa por vencer a Némesis neste nível; devolve o texto do que foi dado.
func grant_nemesis_reward(level: int) -> String:
	var n := nemesis_def()
	var rewards: Array = n.get("rewards", [])
	if rewards.is_empty():
		return ""
	var parts := apply_reward(rewards[clampi(level - 1, 0, rewards.size() - 1)])
	if not (level in nemesis_beaten):
		nemesis_beaten.append(level)
	Stats.on_nemesis_win()
	return ", ".join(PackedStringArray(parts))

# --- Depois de cada batalha (regras da História, Némesis) ---

func after_battle(bm: BattleManager, victory: bool) -> void:
	last_reward_text = ""
	if not victory:
		return
	var heal_win := int(run_rule("heal_on_win", 0))
	if heal_win > 0:
		heal(heal_win)
	var grow_win := int(run_rule("grow_on_win", 0))
	if grow_win > 0:
		var creatures: Array = []
		for i in deck.size():
			var cd := CardDB.get_card(String(deck[i].get("id", "")))
			if cd != null and cd.is_creature():
				creatures.append(i)
		if not creatures.is_empty():
			var i: int = creatures[rng.randi_range(0, creatures.size() - 1)]
			deck[i]["power_bonus"] = int(deck[i].get("power_bonus", 0)) + grow_win
	if String(bm.enemy.get("variant", "")) == "nemesis":
		last_reward_text = grant_nemesis_reward(int(bm.enemy.get("nemesis_level", 1)))

# --- Resumo da run (carta MVP, relíquia que mais deu, dano por ante) ---

## Reparte o dano de um ataque pelos passos da cascata: cada passo fica com o que fez crescer
## Poder × Mult quando disparou (os ×Mult no fim pesam muito — é mesmo assim que a cascata funciona).
func log_cascade(c: Cascade, dealt: int) -> void:
	if dealt <= 0 or c.steps.is_empty():
		return
	if run_log.is_empty():
		run_log = {"damage_by_ante": {}, "card_dmg": {}, "relic_dmg": {}, "best_hit": 0}
	var key := str(ante)
	run_log["damage_by_ante"][key] = int(run_log["damage_by_ante"].get(key, 0)) + dealt
	run_log["best_hit"] = maxi(int(run_log.get("best_hit", 0)), dealt)
	var full := float(c.power) * c.mult
	if full <= 0.0:
		return
	var scale := float(dealt) / full
	var prev := 0.0
	for st in c.steps:
		var now := float(st.power_after) * st.mult_after
		var gain := (now - prev) * scale
		prev = now
		if gain <= 0.0:
			continue
		if st.source_kind == "relic" and st.source_id != "":
			run_log["relic_dmg"][st.source_id] = int(run_log["relic_dmg"].get(st.source_id, 0)) + int(gain)
		elif st.source_card != null and not st.source_card.data.token:
			var id := st.source_card.front.id
			run_log["card_dmg"][id] = int(run_log["card_dmg"].get(id, 0)) + int(gain)

## {"id", "damage"} do maior valor de um dicionário id → dano (vazio se não houver).
static func top_of(d: Dictionary) -> Dictionary:
	var best := ""
	var best_v := 0
	for k in d:
		if int(d[k]) > best_v:
			best_v = int(d[k])
			best = String(k)
	return {"id": best, "damage": best_v} if best != "" else {}

# --- Vales (melhorias da run compradas na loja) ---

func voucher_value(key: String) -> float:
	var total := 0.0
	for id in vouchers:
		total += float((CardDB.get_voucher(id).get("effect", {}) as Dictionary).get(key, 0))
	return total

## Vale à venda nesta loja (um por visita, sorteio próprio por ante; "" se já os tiveres todos).
func shop_voucher_offer() -> String:
	var pool: Array = CardDB.vouchers.filter(func(v): return not (String(v.get("id", "")) in vouchers))
	if pool.is_empty():
		return ""
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 97 + ante * 1013
	return String(pool[r.randi_range(0, pool.size() - 1)].get("id", ""))

func buy_voucher(id: String) -> bool:
	var v := CardDB.get_voucher(id)
	if v.is_empty() or id in vouchers:
		return false
	if not spend_gold(shop_price(int(v.get("price", 10)))):
		return false
	vouchers.append(id)
	if (v.get("effect", {}) as Dictionary).has("relic_slots"):
		EventBus.relics_changed.emit()
	return true

# --- Modo Treino ---

const TRAINING_HP := 999999999

## Estado neutro para uma batalha fora da run (enigmas e Treino): nada da run gravada em disco muda.
func reset_for_side_battle(id: String) -> void:
	puzzle_id = id
	free_mode = true
	challenge_id = ""
	saga_id = ""
	vouchers.clear()
	relic_ids.clear()
	boss_relics.clear()
	planeswalker = {}
	formation_levels = {}
	stake = 1
	ante = 1
	map_choice = {}
	player_hp = 20
	player_max_hp = 20
	pending_battle = {}
	contract = {}

func start_training() -> void:
	reset_for_side_battle("training")
	for id in training.get("relics", []):
		if CardDB.relics.has(String(id)) and not (String(id) in relic_ids):
			relic_ids.append(String(id))

## Definição da batalha de Treino (no formato dos quebra-cabeças: 1 turno, mão fixa, mana dada).
func training_def() -> Dictionary:
	return {"id": "training", "name": "Treino", "enemy_name": "Boneco de Treino",
		"enemy_text": "Vida infinita. Não ataca: só quer ver o teu melhor golpe.",
		"hp": TRAINING_HP, "mana": int(training.get("mana", 5)),
		"hand": training.get("hand", []), "board": [], "graveyard": []}

# --- Medalhas, Desafios e História (progresso) ---

## Medalha de um baralho pelo Selo Planar mais alto vencido: bronze (1–3), prata (4–6), ouro (7–8).
func medal_for(deck_id: String) -> String:
	return MEDALS[clampi(stake_won(deck_id), 0, MEDALS.size() - 1)]

func challenge_done(id: String) -> bool:
	return progress.get("challenges") is Dictionary and (progress["challenges"] as Dictionary).has(id)

func saga_done(id: String) -> bool:
	return progress.get("saga") is Dictionary and (progress["saga"] as Dictionary).has(id)

## Capítulo da História disponível: o 1.º sempre; os outros depois do anterior.
func saga_unlocked(index: int) -> bool:
	if index <= 0:
		return true
	if index >= CardDB.saga.size():
		return false
	return saga_done(String(CardDB.saga[index - 1].get("id", "")))

## Os números do JSON chegam como float: `1 in [1.0]` é falso no Godot, por isso compara-se a int.
static func _act_in(act: int, acts: Array) -> bool:
	for a in acts:
		if int(a) == act:
			return true
	return false

## Evento para o nó "evento" (ou "" se não houver). Não repete na mesma run.
func pick_event() -> String:
	var act := act_of_deck()
	var pool: Array = CardDB.events.filter(func(e):
		return _act_in(act, e.get("acts", [1, 2, 3])) and not (String(e.get("id", "")) in seen_events))
	if pool.is_empty():
		seen_events.clear()   # quando esgotam (ou no infinito) voltam a poder repetir-se
		pool = CardDB.events.filter(func(e): return _act_in(act, e.get("acts", [1, 2, 3])))
	if pool.is_empty():
		return ""
	var ev: Dictionary = pool[rng.randi_range(0, pool.size() - 1)]
	seen_events.append(String(ev.get("id", "")))
	return String(ev.get("id", ""))

# --- Clima Planar (uma regra global por ato; no infinito muda de 2 em 2 antes) ---

func climate_key(a: int) -> String:
	if a > max_ante:
		return "E%d" % int((a - max_ante - 1) / 2)
	return str(act_of_ante(a))

## Id do clima de um ante (sorteado por run, guardado; o ato I só tira climas com min_act 1).
func climate_for_ante(a: int) -> String:
	if CardDB.climates.is_empty():
		return ""
	var key := climate_key(a)
	if climates.has(key):
		return String(climates[key])
	var act := act_of_ante(a)
	var used: Array = climates.values()
	var pool: Array = CardDB.climates.filter(func(c): return int(c.get("min_act", 1)) <= act and not (String(c.get("id", "")) in used))
	if pool.is_empty():
		pool = CardDB.climates.filter(func(c): return int(c.get("min_act", 1)) <= act)
	if pool.is_empty():
		return ""
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 131 + key.hash()
	var id := String(pool[r.randi_range(0, pool.size() - 1)].get("id", ""))
	climates[key] = id
	return id

## Clima da batalha atual ("" nos quebra-cabeças).
func current_climate_id() -> String:
	if puzzle_id != "":
		return ""
	return climate_for_ante(ante)

# --- Contratos ---

func set_contract(id: String) -> void:
	contract = CardDB.get_contract(id).duplicate(true)

## Avalia o contrato ativo no fim da batalha (vitória obrigatória) e entrega a recompensa.
## Devolve {"success": bool, "text": String}; o contrato sai sempre (cumprido ou não).
func resolve_contract(bm: BattleManager, victory: bool) -> Dictionary:
	if contract.is_empty():
		return {}
	var c: Dictionary = contract
	contract = {}
	var cond: Dictionary = c.get("cond", {})
	var ok := victory
	if ok and cond.has("win_by_turn"):
		ok = bm.turn <= int(cond["win_by_turn"])
	if ok and cond.get("no_channel", false):
		ok = bm.discards_used == 0
	if ok and cond.get("no_damage", false):
		ok = bm.life_lost == 0
	if ok and cond.has("big_hit_pct"):
		ok = bm.best_hit_pct >= float(cond["big_hit_pct"])
	if ok and cond.has("formations"):
		ok = bm.max_formations >= int(cond["formations"])
	if ok and cond.has("attackers"):
		ok = bm.max_attackers >= int(cond["attackers"])
	if ok and cond.has("flashbacks"):
		ok = bm.flashbacks_used >= int(cond["flashbacks"])
	if ok and cond.get("no_lands", false):
		ok = bm.lands_played == 0
	var name := TranslationServer.translate(String(c.get("name", "")))
	var result := {"success": ok, "text": ""}
	if ok:
		var parts := apply_reward(c.get("reward", {}))
		Stats.on_contract_done()
		result["text"] = TranslationServer.translate("Contrato cumprido: %s") % name + ("  ·  " + ", ".join(PackedStringArray(parts)) if not parts.is_empty() else "")
	else:
		result["text"] = TranslationServer.translate("Contrato falhado: %s") % name
	EventBus.contract_resolved.emit(ok, String(result["text"]))
	return result

## Recompensas simples (contratos): gold, heal, max_hp, relic "random", card "rare"/"random".
## Devolve as linhas de texto do que foi dado.
func apply_reward(reward: Dictionary) -> Array[String]:
	var parts: Array[String] = []
	if int(reward.get("gold", 0)) != 0:
		add_gold(int(reward["gold"]))
		parts.append(TranslationServer.translate("+%d ouro") % int(reward["gold"]))
	if int(reward.get("heal", 0)) > 0:
		heal(int(reward["heal"]))
		parts.append(TranslationServer.translate("Curas %d.") % int(reward["heal"]))
	if int(reward.get("max_hp", 0)) != 0:
		change_max_hp(int(reward["max_hp"]))
		parts.append(TranslationServer.translate("Vida máxima +%d.") % int(reward["max_hp"]))
	if String(reward.get("relic", "")) != "":
		var id := random_new_relic()
		if id != "" and add_relic(id):
			parts.append(TranslationServer.translate("Recebes a relíquia %s.") % TranslationServer.translate(String(CardDB.relics[id].get("name", id))))
		else:
			add_gold(8)
			parts.append(TranslationServer.translate("+%d ouro") % 8)
	if String(reward.get("card", "")) != "":
		var cd := CardDB.random_card_for_deck(rng, "rare" if String(reward["card"]) == "rare" else "")
		if cd != null:
			add_card(cd.id)
			parts.append(TranslationServer.translate("%s juntou-se ao baralho.") % TranslationServer.translate(cd.name))
	return parts

## Texto curto da recompensa de um contrato (para a lista de escolha).
static func reward_text(reward: Dictionary) -> String:
	var parts: Array[String] = []
	if int(reward.get("gold", 0)) > 0:
		parts.append(TranslationServer.translate("+%d ouro") % int(reward["gold"]))
	if int(reward.get("heal", 0)) > 0:
		parts.append(TranslationServer.translate("cura %d") % int(reward["heal"]))
	if String(reward.get("relic", "")) != "":
		parts.append(TranslationServer.translate("uma relíquia"))
	if String(reward.get("card", "")) == "rare":
		parts.append(TranslationServer.translate("uma carta rara"))
	return ", ".join(PackedStringArray(parts))

func next_ante() -> void:
	map_history[str(ante)] = map_choice.duplicate()
	ante += 1
	map_choice = {}
	map_phase = "battle"
	EventBus.ante_started.emit(ante)

## Nó escolhido num ante já passado ("" se não se sabe).
func map_chosen(a: int, phase: String) -> String:
	if a == ante:
		return String(map_choice.get(phase, ""))
	return String((map_history.get(str(a), {}) as Dictionary).get(phase, ""))

# --- Mapa da run (nós por ante) ---

## Opções deste ante: {"battle": ["scout","guard"] ou ["boss"], "stop": ["shop", X]}. Determinístico
## por run (semente própria, para não mexer no RNG das batalhas).
func map_options(a: int) -> Dictionary:
	var key := str(a)
	if map_plan.has(key):
		return map_plan[key]
	var r := RandomNumberGenerator.new()
	r.seed = seed_value * 31 + a * 7919
	var battle: Array = ["boss"] if is_boss_ante(a) else ["scout", "guard"]
	if not is_boss_ante(a) and nemesis_level(a) > 0 and not nemesis_def().is_empty():
		battle.append("nemesis")   # a Némesis ocupa o lugar da Elite
		r.randf()
	elif not is_boss_ante(a) and a >= 2 and r.randf() < ELITE_CHANCE:
		battle.append("elite")
	var stop: Array = ["shop"]
	if is_boss_ante(a):
		stop.append("merchant")
	else:
		var weights := {"event": 3.0, "rest": 2.0, "contracts": 1.5}
		if a >= 2:
			weights["spring"] = 1.0
			weights["tribunal"] = 1.0
		if a >= 3:
			weights["altar"] = 1.0
			weights["merchant"] = 1.0
		var total := 0.0
		for k in weights:
			total += weights[k]
		var roll := r.randf() * total
		var picked := "event"
		for k in weights:
			roll -= weights[k]
			if roll <= 0.0:
				picked = k
				break
		stop.append(picked)
	var opts := {"battle": battle, "stop": stop}
	map_plan[key] = opts
	return opts

## Regista a escolha de um nó do mapa.
func choose_battle(kind: String) -> void:
	map_choice["battle"] = kind
	map_phase = "battle"

func choose_stop(kind: String) -> void:
	map_choice["stop"] = kind
	map_phase = "stop"

## Cena para a paragem escolhida (e prepara o evento, se for o caso).
func stop_scene(kind: String) -> String:
	match kind:
		"shop", "merchant":
			return "shop"
		"event":
			pending_event = pick_event()
			return "event" if pending_event != "" else "shop"
		"rest", "spring", "altar", "contracts", "tribunal":
			pending_event = "node_" + kind
			return "event"
	return "shop"

## Alvo de "vida" do inimigo por ante — tabela afinada por simulação (tests/Balance.gd),
## multiplicada pela dificuldade. Para lá do 8: ×1,6 por ante (Eternidade Cega).
const ANTE_HP := [3000, 7000, 14000, 24000, 46000, 78000, 125000, 190000]

func enemy_hp_for_ante(a: int) -> int:
	var base: float
	if a <= ANTE_HP.size():
		base = ANTE_HP[a - 1]
	else:
		base = ANTE_HP[-1] * pow(1.6, a - ANTE_HP.size())
	return int(round(base * DIFFICULTY_HP.get(difficulty, 1.0)))

func turns_for_ante(_a: int) -> int:
	return int(run_rule("turns", 5))

func difficulty_name() -> String:
	return DIFFICULTY_NAMES.get(difficulty, difficulty)

## O que a dificuldade muda, numa linha (ecrã da campanha e Configurações).
func difficulty_text() -> String:
	return tr("%s: inimigos com %d%% da vida e %d canalizações por batalha.") % [tr(difficulty_name()), int(round(float(DIFFICULTY_HP.get(difficulty, 1.0)) * 100.0)), int(DIFFICULTY_DISCARDS.get(difficulty, 3))]

func cycle_difficulty() -> void:
	var i := DIFFICULTIES.find(difficulty)
	difficulty = DIFFICULTIES[(i + 1) % DIFFICULTIES.size()]
	progress["difficulty"] = difficulty
	save_progress()

# ---------------------------------------------------------------------------
# Gravação da run (para "Continuar"). Grava-se no início de cada turno (com o estado da
# batalha), no mapa e ao entrar/sair da loja; retomar coloca o jogador exatamente nesse ponto.
# ---------------------------------------------------------------------------

func save_run(battle_state: Dictionary = {}, scene: String = "battle") -> void:
	if puzzle_id != "":
		return   # os quebra-cabeças não se gravam
	var data := {
		"version": 4,
		"deck_id": deck_def.get("id", "deck01"),
		"deck_def": deck_def if deck_def.get("custom", false) else {},
		"deck": deck,
		"relic_ids": relic_ids,
		"relic_locked": relic_locked,
		"ante": ante,
		"max_ante": max_ante,
		"gold": gold,
		"seed": seed_value,
		"rng_state": rng.state,
		"difficulty": difficulty,
		"free_mode": free_mode,
		"mode": mode,
		"stake": stake,
		"scene": scene,
		"battle": battle_state,
		"player_hp": player_hp,
		"player_max_hp": player_max_hp,
		"interest_ante": interest_ante,
		"seen_events": seen_events,
		"pending_event": pending_event,
		"current_enemy_id": current_enemy_id,
		"endless": endless,
		"planeswalker": planeswalker,
		"formation_levels": formation_levels,
		"map_plan": map_plan,
		"map_choice": map_choice,
		"map_history": map_history,
		"map_phase": map_phase,
		"boss_relics": boss_relics,
		"loot_offer": loot_offer,
		"climates": climates,
		"contract": contract,
		"death_save_used": death_save_used,
		"relic_counters": relic_counters,
		"interlude_key": interlude_key,
		"run_channels": Stats.run_channels,
		"vouchers": vouchers,
		"nemesis_id": nemesis_id,
		"nemesis_beaten": nemesis_beaten,
		"challenge_id": challenge_id,
		"saga_id": saga_id,
		"run_log": run_log,
	}
	var f := FileAccess.open(RUN_SAVE, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))

func has_saved_run() -> bool:
	return FileAccess.file_exists(RUN_SAVE)

## Resumo da run gravada para o botão CONTINUAR do menu ("Falange Solar · Ante 3"); "" se não houver.
func saved_run_summary() -> String:
	if not has_saved_run():
		return ""
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(RUN_SAVE))
	if not (parsed is Dictionary):
		return ""
	var what := ""
	var ch_id := String(parsed.get("challenge_id", ""))
	var saga := String(parsed.get("saga_id", ""))
	if ch_id != "":
		what = tr("Desafio") + ": " + tr(String(CardDB.get_challenge(ch_id).get("name", "")))
	elif saga != "":
		what = tr(String(CardDB.get_saga_chapter(saga).get("name", "")))
	else:
		var def: Dictionary = parsed.get("deck_def", {}) if parsed.get("deck_def") is Dictionary else {}
		if def.is_empty():
			def = CardDB.get_deck(String(parsed.get("deck_id", "")))
		what = tr(String(def.get("name", "")))
	var ante_txt := tr("Ante %d") % int(parsed.get("ante", 1))
	return ante_txt if what == "" else what + "  ·  " + ante_txt

func load_run() -> bool:
	if not has_saved_run():
		return false
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(RUN_SAVE))
	if not (parsed is Dictionary):
		return false
	var saved_def: Dictionary = parsed.get("deck_def", {}) if parsed.get("deck_def") is Dictionary else {}
	deck_def = saved_def if not saved_def.is_empty() else CardDB.get_deck(String(parsed.get("deck_id", "deck01")))
	deck.clear()
	for e in parsed.get("deck", []):
		if not (e is Dictionary):
			continue
		var entry := _new_entry(String(e.get("id", "")))
		for k in e:
			entry[k] = e[k]
		entry["power_bonus"] = int(e.get("power_bonus", 0))
		entry["mult_bonus"] = float(e.get("mult_bonus", 0.0))
		deck.append(entry)
	relic_ids.clear()
	for r in parsed.get("relic_ids", []):
		relic_ids.append(String(r))
	relic_locked.clear()
	for r in parsed.get("relic_locked", []):
		relic_locked.append(String(r))
	ante = int(parsed.get("ante", 1))
	max_ante = int(parsed.get("max_ante", 8))
	gold = int(parsed.get("gold", 4))
	seed_value = int(parsed.get("seed", 0))
	rng.seed = seed_value
	rng.state = int(parsed.get("rng_state", rng.state))
	difficulty = String(parsed.get("difficulty", "normal"))
	free_mode = bool(parsed.get("free_mode", false))
	mode = String(parsed.get("mode", "free" if free_mode else "campaign"))
	stake = int(parsed.get("stake", 1))
	player_max_hp = int(parsed.get("player_max_hp", 20))
	player_hp = clampi(int(parsed.get("player_hp", player_max_hp)), 1, player_max_hp)
	interest_ante = int(parsed.get("interest_ante", 0))
	seen_events.clear()
	for e in parsed.get("seen_events", []):
		seen_events.append(String(e))
	pending_event = String(parsed.get("pending_event", ""))
	current_enemy_id = String(parsed.get("current_enemy_id", ""))
	endless = bool(parsed.get("endless", false))
	planeswalker = parsed.get("planeswalker", {}) if parsed.get("planeswalker") is Dictionary else {}
	if not planeswalker.is_empty():
		planeswalker["loyalty"] = int(planeswalker.get("loyalty", 2))
	formation_levels = {}
	var fl = parsed.get("formation_levels", {})
	if fl is Dictionary:
		for k in fl:
			formation_levels[String(k)] = int(fl[k])
	map_plan = {}
	var mp = parsed.get("map_plan", {})
	if mp is Dictionary:
		for k in mp:
			map_plan[String(k)] = mp[k]
	map_choice = parsed.get("map_choice", {}) if parsed.get("map_choice") is Dictionary else {}
	map_history = {}
	var mh = parsed.get("map_history", {})
	if mh is Dictionary:
		for k in mh:
			map_history[String(k)] = mh[k]
	map_phase = String(parsed.get("map_phase", "battle"))
	boss_relics.clear()
	for r in parsed.get("boss_relics", []):
		boss_relics.append(String(r))
	loot_offer.clear()
	for r in parsed.get("loot_offer", []):
		loot_offer.append(String(r))
	climates = {}
	var cl = parsed.get("climates", {})
	if cl is Dictionary:
		for k in cl:
			climates[String(k)] = String(cl[k])
	contract = parsed.get("contract", {}) if parsed.get("contract") is Dictionary else {}
	death_save_used = bool(parsed.get("death_save_used", false))
	relic_counters = {}
	var rc = parsed.get("relic_counters", {})
	if rc is Dictionary:
		for k in rc:
			relic_counters[String(k)] = int(rc[k])
	interlude_key = String(parsed.get("interlude_key", ""))
	vouchers.clear()
	for v in parsed.get("vouchers", []):
		vouchers.append(String(v))
	nemesis_id = String(parsed.get("nemesis_id", ""))
	nemesis_beaten.clear()
	for lv in parsed.get("nemesis_beaten", []):
		nemesis_beaten.append(int(lv))
	challenge_id = String(parsed.get("challenge_id", ""))
	saga_id = String(parsed.get("saga_id", ""))
	run_log = {}
	var rl = parsed.get("run_log", {})
	if rl is Dictionary and not rl.is_empty():
		run_log = {"damage_by_ante": {}, "card_dmg": {}, "relic_dmg": {}, "best_hit": int(rl.get("best_hit", 0))}
		for k in ["damage_by_ante", "card_dmg", "relic_dmg"]:
			if rl.get(k) is Dictionary:
				for kk in rl[k]:
					run_log[k][String(kk)] = int(rl[k][kk])
	training = {}
	last_reward_text = ""
	puzzle_id = ""
	Stats.run_channels = int(parsed.get("run_channels", 0))
	last_unlocks.clear()
	last_victory = false
	saved_scene = String(parsed.get("scene", "battle"))
	pending_battle = {}
	if int(parsed.get("version", 1)) >= 2 and parsed.get("battle") is Dictionary:
		pending_battle = parsed["battle"]
	EventBus.gold_changed.emit(gold)
	return true

func clear_saved_run() -> void:
	pending_battle = {}
	if has_saved_run():
		DirAccess.remove_absolute(ProjectSettings.globalize_path(RUN_SAVE))

## Abandonar a run a meio: conta como derrota no ante atual (na campanha) e apaga a gravação.
func abandon_run() -> void:
	record_run_end(ante, false)
	clear_saved_run()
	last_victory = false
	EventBus.run_ended.emit(false)

## Apaga todo o progresso da campanha (Configurações → Apagar progresso).
func reset_progress() -> void:
	progress = {"best_ante": {}, "wins": {}, "difficulty": difficulty}
	Stats._ensure()
	save_progress()
	clear_saved_run()

# ---------------------------------------------------------------------------
# Progresso da campanha: melhor ante por baralho, vitórias, selos vencidos, desbloqueios.
# ---------------------------------------------------------------------------

func load_progress() -> void:
	if not FileAccess.file_exists(PROGRESS_SAVE):
		return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(PROGRESS_SAVE))
	if parsed is Dictionary:
		progress = parsed
		if not progress.has("best_ante"):
			progress["best_ante"] = {}
		if not progress.has("wins"):
			progress["wins"] = {}
		difficulty = String(progress.get("difficulty", "normal"))

## Progresso vindo de um código importado (Configurações → Importar).
func load_progress_from(p: Dictionary) -> void:
	progress = p
	if not (progress.get("best_ante") is Dictionary):
		progress["best_ante"] = {}
	if not (progress.get("wins") is Dictionary):
		progress["wins"] = {}
	difficulty = String(progress.get("difficulty", "normal"))

func save_progress() -> void:
	var f := FileAccess.open(PROGRESS_SAVE, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(progress))

func best_ante(deck_id: String) -> int:
	return int(progress["best_ante"].get(deck_id, 0))

func wins(deck_id: String) -> int:
	return int(progress["wins"].get(deck_id, 0))

## Selo Planar mais alto vencido com este baralho (0 = nenhum).
func stake_won(deck_id: String) -> int:
	if not (progress.get("stakes") is Dictionary):
		return 0
	return int(progress["stakes"].get(deck_id, 0))

## Selo máximo que podes escolher para um baralho: o seguinte ao último vencido.
func max_stake(deck_id: String) -> int:
	if free_mode:
		return STAKES.size()
	return clampi(stake_won(deck_id) + 1, 1, STAKES.size())

## Regista o fim de uma run (ante atingido; vitória = passou o último ante). Devolve os desbloqueios novos.
func record_run_end(reached_ante: int, victory: bool) -> Array[String]:
	last_unlocks.clear()
	Stats.on_run_end(victory)
	if victory and challenge_id != "":
		if not (progress.get("challenges") is Dictionary):
			progress["challenges"] = {}
		progress["challenges"][challenge_id] = true
		Stats.set_at_least("challenges_won", (progress["challenges"] as Dictionary).size())
	if victory and saga_id != "":
		if not (progress.get("saga") is Dictionary):
			progress["saga"] = {}
		var first_time := not saga_done(saga_id)
		progress["saga"][saga_id] = true
		Stats.set_at_least("saga_chapters", (progress["saga"] as Dictionary).size())
		var rw: Dictionary = CardDB.get_saga_chapter(saga_id).get("reward", {})
		if first_time and not rw.is_empty() and Stats.grant_unlock(String(rw.get("type", "")), String(rw.get("id", ""))):
			last_unlocks.append(Stats.unlock_label(rw, "%s: %s"))
	if free_mode:
		save_progress()
		return last_unlocks
	var id := String(deck_def.get("id", ""))
	var before := _unlocked_deck_ids()
	var reached := reached_ante + (1 if victory else 0)
	progress["best_ante"][id] = max(best_ante(id), reached)
	if victory:
		progress["wins"][id] = wins(id) + 1
		if not (progress.get("stakes") is Dictionary):
			progress["stakes"] = {}
		progress["stakes"][id] = max(stake_won(id), stake)
	save_progress()
	for did in _unlocked_deck_ids():
		if not (did in before):
			last_unlocks.append(String(CardDB.get_deck(did).get("name", did)))
	return last_unlocks

## Desbloqueio: o 1.º capítulo de cada livro aberto está livre; cada capítulo desbloqueia o seguinte
## ao chegar ao ante 4; um livro abre quando algum capítulo do livro anterior chega ao ante 6.
func is_act_unlocked(act_index: int) -> bool:
	if act_index == 0:
		return true
	var prev: Dictionary = CardDB.campaign[act_index - 1]
	for ch in prev.get("chapters", []):
		if best_ante(String(ch["deck_id"])) >= 6:
			return true
	return false

func is_deck_unlocked(deck_id: String) -> bool:
	for act_index in CardDB.campaign.size():
		var act: Dictionary = CardDB.campaign[act_index]
		var chapters: Array = act.get("chapters", [])
		for i in chapters.size():
			if String(chapters[i]["deck_id"]) != deck_id:
				continue
			if not is_act_unlocked(act_index):
				return false
			if i == 0:
				return true
			return best_ante(String(chapters[i - 1]["deck_id"])) >= 4
	return false

func _unlocked_deck_ids() -> Array[String]:
	var out: Array[String] = []
	for act in CardDB.campaign:
		for ch in act.get("chapters", []):
			if is_deck_unlocked(String(ch["deck_id"])):
				out.append(String(ch["deck_id"]))
	return out
