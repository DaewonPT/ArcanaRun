extends Node
## Estado da run atual (o "save" em memória), progresso da campanha e gravação em disco.
## Não contém lógica de batalha — isso vive em BattleManager.

const RUN_SAVE := "user://run.json"
const PROGRESS_SAVE := "user://progress.json"

const DIFFICULTIES := ["facil", "normal", "dificil"]
const DIFFICULTY_NAMES := {"facil": "Fácil", "normal": "Normal", "dificil": "Difícil"}
const DIFFICULTY_HP := {"facil": 0.7, "normal": 1.0, "dificil": 1.4}
const DIFFICULTY_DISCARDS := {"facil": 4, "normal": 3, "dificil": 2}

var rng := RandomNumberGenerator.new()
var seed_value: int = 0

# --- Run ---
var ante: int = 1
var max_ante: int = 8
var gold: int = 4
var player_max_hp: int = 20
var player_hp: int = 20
var difficulty: String = "normal"
var free_mode: bool = false          # Modo Livre: não conta para a campanha
var last_victory: bool = false       # a última run terminou em vitória (para o ecrã final)

# --- Baralho persistente: uma entrada por carta, com bónus permanentes ---
var deck: Array[Dictionary] = []     # {"id": "c001", "power_bonus": 0, "mult_bonus": 0.0}
var deck_def: Dictionary = {}        # definição do baralho escolhido (decks.json)
var relic_ids: Array[String] = []

# --- Progresso da campanha (persistente) ---
var progress: Dictionary = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
var last_unlocks: Array[String] = []   # nomes desbloqueados na última run (para o ecrã final)

func _ready() -> void:
	load_progress()

func new_run(deck_id: String = "deck01", seed_override: int = 0) -> void:
	seed_value = seed_override if seed_override != 0 else randi()
	rng.seed = seed_value
	ante = 1
	gold = 4
	player_hp = player_max_hp
	relic_ids.clear()
	last_unlocks.clear()
	last_victory = false
	deck_def = CardDB.get_deck(deck_id)
	deck.clear()
	for id in deck_def.get("cards", []):
		deck.append({"id": String(id), "power_bonus": 0, "mult_bonus": 0.0})
	EventBus.run_started.emit()
	EventBus.gold_changed.emit(gold)

## Cores do baralho atual (para a loja).
func deck_colors() -> Array:
	return deck_def.get("colors", [])

func deck_ids() -> Array[String]:
	var out: Array[String] = []
	for e in deck:
		out.append(String(e["id"]))
	return out

func add_gold(amount: int) -> void:
	gold = max(0, gold + amount)
	EventBus.gold_changed.emit(gold)

func spend_gold(amount: int) -> bool:
	if gold < amount:
		return false
	gold -= amount
	EventBus.gold_changed.emit(gold)
	return true

func add_card(id: String) -> void:
	deck.append({"id": id, "power_bonus": 0, "mult_bonus": 0.0})

## Remove UMA cópia da carta. Devolve false se não existir.
func remove_card(id: String) -> bool:
	for i in deck.size():
		if deck[i]["id"] == id:
			deck.remove_at(i)
			return true
	return false

## Custo de remover uma carta na loja: sobe com o ante para não ser trivial afinar o deck.
func removal_price() -> int:
	return 2 + int(ante / 3)

## Contagem por id, para listar o deck sem repetições.
func deck_counts() -> Dictionary:
	var counts := {}
	for e in deck:
		counts[e["id"]] = counts.get(e["id"], 0) + 1
	return counts

func add_relic(id: String) -> void:
	if id in relic_ids:
		return
	relic_ids.append(id)
	EventBus.relic_gained.emit(id)

func next_ante() -> void:
	ante += 1
	EventBus.ante_started.emit(ante)

## Alvo de "vida" do inimigo por ante — tabela afinada por simulação (tests/Balance.gd),
## multiplicada pela dificuldade.
const ANTE_HP := [3000, 7000, 15000, 28000, 70000, 120000, 200000, 330000]

func enemy_hp_for_ante(a: int) -> int:
	var base: float
	if a <= ANTE_HP.size():
		base = ANTE_HP[a - 1]
	else:
		base = ANTE_HP[-1] * pow(1.6, a - ANTE_HP.size())
	return int(round(base * DIFFICULTY_HP.get(difficulty, 1.0)))

func turns_for_ante(_a: int) -> int:
	return 5

func discards_for_battle() -> int:
	return int(DIFFICULTY_DISCARDS.get(difficulty, 3))

func difficulty_name() -> String:
	return DIFFICULTY_NAMES.get(difficulty, difficulty)

func cycle_difficulty() -> void:
	var i := DIFFICULTIES.find(difficulty)
	difficulty = DIFFICULTIES[(i + 1) % DIFFICULTIES.size()]
	progress["difficulty"] = difficulty
	save_progress()

# ---------------------------------------------------------------------------
# Gravação da run (para "Continuar"). Guarda-se no início de cada batalha e ao sair da loja;
# retomar coloca o jogador no início da batalha do ante atual.
# ---------------------------------------------------------------------------

func save_run() -> void:
	var data := {
		"version": 1,
		"deck_id": deck_def.get("id", "deck01"),
		"deck": deck,
		"relic_ids": relic_ids,
		"ante": ante,
		"gold": gold,
		"seed": seed_value,
		"rng_state": rng.state,
		"difficulty": difficulty,
		"free_mode": free_mode,
	}
	var f := FileAccess.open(RUN_SAVE, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))

func has_saved_run() -> bool:
	return FileAccess.file_exists(RUN_SAVE)

func load_run() -> bool:
	if not has_saved_run():
		return false
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(RUN_SAVE))
	if not (parsed is Dictionary):
		return false
	deck_def = CardDB.get_deck(String(parsed.get("deck_id", "deck01")))
	deck.clear()
	for e in parsed.get("deck", []):
		deck.append({"id": String(e.get("id", "")), "power_bonus": int(e.get("power_bonus", 0)), "mult_bonus": float(e.get("mult_bonus", 0.0))})
	relic_ids.clear()
	for r in parsed.get("relic_ids", []):
		relic_ids.append(String(r))
	ante = int(parsed.get("ante", 1))
	gold = int(parsed.get("gold", 4))
	seed_value = int(parsed.get("seed", 0))
	rng.seed = seed_value
	rng.state = int(parsed.get("rng_state", rng.state))
	difficulty = String(parsed.get("difficulty", "normal"))
	free_mode = bool(parsed.get("free_mode", false))
	player_hp = player_max_hp
	last_unlocks.clear()
	last_victory = false
	EventBus.gold_changed.emit(gold)
	return true

func clear_saved_run() -> void:
	if has_saved_run():
		DirAccess.remove_absolute(ProjectSettings.globalize_path(RUN_SAVE))

# ---------------------------------------------------------------------------
# Progresso da campanha: melhor ante por baralho, vitórias, desbloqueios.
# ---------------------------------------------------------------------------

func load_progress() -> void:
	if not FileAccess.file_exists(PROGRESS_SAVE):
		return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(PROGRESS_SAVE))
	if parsed is Dictionary:
		progress = parsed
		if not progress.has("best_ante"):
			progress["best_ante"] = {}
		if not progress.has("wins"):
			progress["wins"] = {}
		difficulty = String(progress.get("difficulty", "normal"))

func save_progress() -> void:
	var f := FileAccess.open(PROGRESS_SAVE, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(progress))

func best_ante(deck_id: String) -> int:
	return int(progress["best_ante"].get(deck_id, 0))

func wins(deck_id: String) -> int:
	return int(progress["wins"].get(deck_id, 0))

## Regista o fim de uma run (ante atingido; vitória = passou o ante 8). Devolve os desbloqueios novos.
func record_run_end(reached_ante: int, victory: bool) -> Array[String]:
	last_unlocks.clear()
	if free_mode:
		return last_unlocks
	var id := String(deck_def.get("id", ""))
	var before := _unlocked_deck_ids()
	var reached := reached_ante + (1 if victory else 0)
	progress["best_ante"][id] = max(best_ante(id), reached)
	if victory:
		progress["wins"][id] = wins(id) + 1
	save_progress()
	for did in _unlocked_deck_ids():
		if not (did in before):
			last_unlocks.append(String(CardDB.get_deck(did).get("name", did)))
	return last_unlocks

## Desbloqueio: o 1.º capítulo de cada ato aberto está livre; cada capítulo desbloqueia o seguinte
## ao chegar ao ante 4; um ato abre quando algum capítulo do ato anterior chega ao ante 6.
func is_act_unlocked(act_index: int) -> bool:
	if act_index == 0:
		return true
	var prev: Dictionary = CardDB.campaign[act_index - 1]
	for ch in prev.get("chapters", []):
		if best_ante(String(ch["deck_id"])) >= 6:
			return true
	return false

func is_deck_unlocked(deck_id: String) -> bool:
	for act_index in CardDB.campaign.size():
		var act: Dictionary = CardDB.campaign[act_index]
		var chapters: Array = act.get("chapters", [])
		for i in chapters.size():
			if String(chapters[i]["deck_id"]) != deck_id:
				continue
			if not is_act_unlocked(act_index):
				return false
			if i == 0:
				return true
			return best_ante(String(chapters[i - 1]["deck_id"])) >= 4
	return false

func _unlocked_deck_ids() -> Array[String]:
	var out: Array[String] = []
	for act in CardDB.campaign:
		for ch in act.get("chapters", []):
			if is_deck_unlocked(String(ch["deck_id"])):
				out.append(String(ch["deck_id"]))
	return out
