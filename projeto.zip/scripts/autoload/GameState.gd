extends Node
## Estado da run atual (o "save" em memória), progresso da campanha e gravação em disco.
## Não contém lógica de batalha — isso vive em BattleManager.

const RUN_SAVE := "user://run.json"
const PROGRESS_SAVE := "user://progress.json"

const DIFFICULTIES := ["facil", "normal", "dificil"]
const DIFFICULTY_NAMES := {"facil": "Fácil", "normal": "Normal", "dificil": "Difícil"}
const DIFFICULTY_HP := {"facil": 0.7, "normal": 1.0, "dificil": 1.4}
const DIFFICULTY_DISCARDS := {"facil": 4, "normal": 3, "dificil": 2}
const MAX_RELICS := 5
const EVENT_ANTES := [2, 5, 7]        # depois de vencer estes antes há um evento antes da loja
const BOSS_EVERY := 4                 # antes 4, 8, 12… têm boss; o 8 é o boss final

var rng := RandomNumberGenerator.new()
var seed_value: int = 0

# --- Run ---
var ante: int = 1
var max_ante: int = 8
var gold: int = 4
var player_max_hp: int = 20
var player_hp: int = 20
var difficulty: String = "normal"
var free_mode: bool = false          # Modo Livre: não conta para a campanha
var last_victory: bool = false       # a última run terminou em vitória (para o ecrã final)
var interest_ante: int = 0           # último ante em que a loja pagou juros
var seen_events: Array[String] = []  # eventos já mostrados nesta run
var pending_event: String = ""       # evento gravado a meio (para retomar)
var current_enemy_id: String = ""    # inimigo da batalha atual (para o ecrã final)
var endless: bool = false            # modo infinito: continuar depois do ante 8

# --- Baralho persistente: uma entrada por carta, com bónus permanentes ---
var deck: Array[Dictionary] = []     # {"id": "c001", "power_bonus": 0, "mult_bonus": 0.0}
var deck_def: Dictionary = {}        # definição do baralho escolhido (decks.json)
var relic_ids: Array[String] = []

# --- Progresso da campanha (persistente) ---
var progress: Dictionary = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
var last_unlocks: Array[String] = []   # nomes desbloqueados na última run (para o ecrã final)

# --- Retoma ---
var pending_battle: Dictionary = {}    # batalha gravada a meio (BattleManager.to_dict), consumida pela cena Battle
var saved_scene: String = "battle"     # onde a run gravada estava: "battle" ou "shop"

func _ready() -> void:
	load_progress()

func new_run(deck_id: String = "deck01", seed_override: int = 0) -> void:
	seed_value = seed_override if seed_override != 0 else randi()
	rng.seed = seed_value
	ante = 1
	gold = 4
	player_max_hp = 20
	player_hp = player_max_hp
	relic_ids.clear()
	last_unlocks.clear()
	last_victory = false
	interest_ante = 0
	seen_events.clear()
	pending_event = ""
	current_enemy_id = ""
	endless = false
	deck_def = CardDB.get_deck(deck_id)
	deck.clear()
	for id in deck_def.get("cards", []):
		deck.append({"id": String(id), "power_bonus": 0, "mult_bonus": 0.0})
	EventBus.run_started.emit()
	EventBus.gold_changed.emit(gold)

## Cores do baralho atual (para a loja).
func deck_colors() -> Array:
	return deck_def.get("colors", [])

func deck_ids() -> Array[String]:
	var out: Array[String] = []
	for e in deck:
		out.append(String(e["id"]))
	return out

func add_gold(amount: int) -> void:
	gold = max(0, gold + amount)
	EventBus.gold_changed.emit(gold)

func spend_gold(amount: int) -> bool:
	if gold < amount:
		return false
	gold -= amount
	EventBus.gold_changed.emit(gold)
	return true

func add_card(id: String) -> void:
	deck.append({"id": id, "power_bonus": 0, "mult_bonus": 0.0})
	Stats.mark_seen("cards", id, false)

## Remove UMA cópia da carta. Devolve false se não existir.
func remove_card(id: String) -> bool:
	for i in deck.size():
		if deck[i]["id"] == id:
			deck.remove_at(i)
			return true
	return false

## Custo de remover uma carta na loja: sobe com o ante para não ser trivial afinar o deck.
func removal_price() -> int:
	return 2 + int(ante / 3)

## Contagem por id, para listar o deck sem repetições.
func deck_counts() -> Dictionary:
	var counts := {}
	for e in deck:
		counts[e["id"]] = counts.get(e["id"], 0) + 1
	return counts

## Devolve false se já a tiveres ou se não houver espaço (MAX_RELICS).
func add_relic(id: String) -> bool:
	if id in relic_ids or relic_ids.size() >= MAX_RELICS:
		return false
	relic_ids.append(id)
	EventBus.relic_gained.emit(id)
	return true

func remove_relic(id: String) -> void:
	relic_ids.erase(id)
	EventBus.relics_changed.emit()

func move_relic(id: String, index: int) -> void:
	if not (id in relic_ids):
		return
	relic_ids.erase(id)
	relic_ids.insert(clampi(index, 0, relic_ids.size()), id)
	EventBus.relics_changed.emit()

func relic_sell_price(id: String) -> int:
	return max(1, int(CardDB.relics.get(id, {}).get("price", 4)) / 2)

## Relíquia ao acaso que ainda não tenhas (para eventos). "" se não houver.
func random_new_relic() -> String:
	var pool: Array = CardDB.relics.keys().filter(func(r): return not (r in relic_ids))
	if pool.is_empty():
		return ""
	return String(pool[rng.randi_range(0, pool.size() - 1)])

# --- Vida (persistente ao longo da run) ---

func heal(amount: int) -> void:
	player_hp = clampi(player_hp + amount, 0, player_max_hp)
	EventBus.player_hp_changed.emit(player_hp, player_max_hp)

func change_max_hp(amount: int) -> void:
	player_max_hp = max(5, player_max_hp + amount)
	player_hp = clampi(player_hp, 1, player_max_hp)
	EventBus.player_hp_changed.emit(player_hp, player_max_hp)

func damage_player(amount: int) -> void:
	player_hp = max(0, player_hp - amount)
	EventBus.player_hp_changed.emit(player_hp, player_max_hp)

## Juros da loja: +1 ouro por cada 5 guardados (máx. 5), uma vez por ante.
func interest_due() -> int:
	if interest_ante == ante:
		return 0
	return mini(5, int(gold / 5))

func pay_interest() -> int:
	var due := interest_due()
	interest_ante = ante
	if due > 0:
		add_gold(due)
	return due

# --- Inimigos e bosses ---

## Ato (1-3) do baralho atual, pela campanha; 1 se não constar.
func act_of_deck() -> int:
	var id := String(deck_def.get("id", ""))
	for i in CardDB.campaign.size():
		for ch in CardDB.campaign[i].get("chapters", []):
			if String(ch.get("deck_id", "")) == id:
				return i + 1
	return 1

func is_boss_ante(a: int) -> bool:
	return a % BOSS_EVERY == 0

func current_enemy_is_boss() -> bool:
	for e in CardDB.enemies:
		if String(e.get("id", "")) == current_enemy_id:
			return bool(e.get("boss", false))
	return false

## Há evento depois deste ante? (2, 5, 7 e, no infinito, de 3 em 3 a partir do 10)
func has_event_after(a: int) -> bool:
	if a in EVENT_ANTES:
		return true
	return a > max_ante and (a - 7) % 3 == 0

## Escolhe o inimigo de um ante: boss nos antes múltiplos de 4 (final no 8), senão um do
## conjunto do ato do baralho com min_ante <= ante. Devolve a definição pronta para BattleManager.start.
func pick_enemy(a: int) -> Dictionary:
	var act := act_of_deck()
	var def: Dictionary = {}
	if is_boss_ante(a):
		var bosses: Array = CardDB.enemies.filter(func(e): return bool(e.get("boss", false)) and (bool(e.get("final", false)) == (a == max_ante) or a > max_ante))
		if bosses.is_empty():
			bosses = CardDB.enemies.filter(func(e): return bool(e.get("boss", false)))
		def = bosses[rng.randi_range(0, bosses.size() - 1)]
	else:
		var pool: Array = CardDB.enemies.filter(func(e):
			if bool(e.get("boss", false)) or int(e.get("min_ante", 1)) > a:
				return false
			return _act_in(act, e.get("acts", [1, 2, 3])) or a > max_ante)
		if pool.is_empty():
			pool = CardDB.enemies.filter(func(e): return not bool(e.get("boss", false)))
		def = pool[rng.randi_range(0, pool.size() - 1)]
	var hp := int(round(enemy_hp_for_ante(a) * float(def.get("hp_mult", 1.0))))
	current_enemy_id = String(def.get("id", ""))
	return {
		"id": def.get("id", ""),
		"name": def.get("name", "?"),
		"hp": hp, "max_hp": hp,
		"attack": int(def.get("attack", 0)),
		"text": def.get("text", ""),
		"abilities": def.get("abilities", []),
		"boss": bool(def.get("boss", false)),
		"rule": def.get("rule", {}),
	}

## Os números do JSON chegam como float: `1 in [1.0]` é falso no Godot, por isso compara-se a int.
static func _act_in(act: int, acts: Array) -> bool:
	for a in acts:
		if int(a) == act:
			return true
	return false

## Evento para depois do ante atual (ou "" se não houver). Não repete na mesma run.
func pick_event() -> String:
	var act := act_of_deck()
	var pool: Array = CardDB.events.filter(func(e):
		return _act_in(act, e.get("acts", [1, 2, 3])) and not (String(e.get("id", "")) in seen_events))
	if pool.is_empty() and endless:
		seen_events.clear()   # no infinito os eventos podem repetir-se
		pool = CardDB.events.filter(func(e): return _act_in(act, e.get("acts", [1, 2, 3])))
	if pool.is_empty():
		return ""
	var ev: Dictionary = pool[rng.randi_range(0, pool.size() - 1)]
	seen_events.append(String(ev.get("id", "")))
	return String(ev.get("id", ""))

func next_ante() -> void:
	ante += 1
	EventBus.ante_started.emit(ante)

## Alvo de "vida" do inimigo por ante — tabela afinada por simulação (tests/Balance.gd),
## multiplicada pela dificuldade.
const ANTE_HP := [3000, 7000, 14000, 24000, 46000, 78000, 125000, 190000]

func enemy_hp_for_ante(a: int) -> int:
	var base: float
	if a <= ANTE_HP.size():
		base = ANTE_HP[a - 1]
	else:
		base = ANTE_HP[-1] * pow(1.6, a - ANTE_HP.size())
	return int(round(base * DIFFICULTY_HP.get(difficulty, 1.0)))

func turns_for_ante(_a: int) -> int:
	return 5

func discards_for_battle() -> int:
	return int(DIFFICULTY_DISCARDS.get(difficulty, 3))

func difficulty_name() -> String:
	return DIFFICULTY_NAMES.get(difficulty, difficulty)

func cycle_difficulty() -> void:
	var i := DIFFICULTIES.find(difficulty)
	difficulty = DIFFICULTIES[(i + 1) % DIFFICULTIES.size()]
	progress["difficulty"] = difficulty
	save_progress()

# ---------------------------------------------------------------------------
# Gravação da run (para "Continuar"). Grava-se no início de cada turno (com o estado da
# batalha) e ao entrar/sair da loja; retomar coloca o jogador exatamente nesse turno.
# ---------------------------------------------------------------------------

func save_run(battle_state: Dictionary = {}, scene: String = "battle") -> void:
	var data := {
		"version": 2,
		"deck_id": deck_def.get("id", "deck01"),
		"deck": deck,
		"relic_ids": relic_ids,
		"ante": ante,
		"gold": gold,
		"seed": seed_value,
		"rng_state": rng.state,
		"difficulty": difficulty,
		"free_mode": free_mode,
		"scene": scene,
		"battle": battle_state,
		"player_hp": player_hp,
		"player_max_hp": player_max_hp,
		"interest_ante": interest_ante,
		"seen_events": seen_events,
		"pending_event": pending_event,
		"current_enemy_id": current_enemy_id,
		"endless": endless,
		"run_channels": Stats.run_channels,
	}
	var f := FileAccess.open(RUN_SAVE, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))

func has_saved_run() -> bool:
	return FileAccess.file_exists(RUN_SAVE)

func load_run() -> bool:
	if not has_saved_run():
		return false
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(RUN_SAVE))
	if not (parsed is Dictionary):
		return false
	deck_def = CardDB.get_deck(String(parsed.get("deck_id", "deck01")))
	deck.clear()
	for e in parsed.get("deck", []):
		deck.append({"id": String(e.get("id", "")), "power_bonus": int(e.get("power_bonus", 0)), "mult_bonus": float(e.get("mult_bonus", 0.0))})
	relic_ids.clear()
	for r in parsed.get("relic_ids", []):
		relic_ids.append(String(r))
	ante = int(parsed.get("ante", 1))
	gold = int(parsed.get("gold", 4))
	seed_value = int(parsed.get("seed", 0))
	rng.seed = seed_value
	rng.state = int(parsed.get("rng_state", rng.state))
	difficulty = String(parsed.get("difficulty", "normal"))
	free_mode = bool(parsed.get("free_mode", false))
	player_max_hp = int(parsed.get("player_max_hp", 20))
	player_hp = clampi(int(parsed.get("player_hp", player_max_hp)), 1, player_max_hp)
	interest_ante = int(parsed.get("interest_ante", 0))
	seen_events.clear()
	for e in parsed.get("seen_events", []):
		seen_events.append(String(e))
	pending_event = String(parsed.get("pending_event", ""))
	current_enemy_id = String(parsed.get("current_enemy_id", ""))
	endless = bool(parsed.get("endless", false))
	Stats.run_channels = int(parsed.get("run_channels", 0))
	last_unlocks.clear()
	last_victory = false
	saved_scene = String(parsed.get("scene", "battle"))
	pending_battle = {}
	if int(parsed.get("version", 1)) >= 2 and parsed.get("battle") is Dictionary:
		pending_battle = parsed["battle"]
	EventBus.gold_changed.emit(gold)
	return true

func clear_saved_run() -> void:
	pending_battle = {}
	if has_saved_run():
		DirAccess.remove_absolute(ProjectSettings.globalize_path(RUN_SAVE))

## Abandonar a run a meio: conta como derrota no ante atual (na campanha) e apaga a gravação.
func abandon_run() -> void:
	record_run_end(ante, false)
	clear_saved_run()
	last_victory = false
	EventBus.run_ended.emit(false)

## Apaga todo o progresso da campanha (Configurações → Apagar progresso).
func reset_progress() -> void:
	progress = {"best_ante": {}, "wins": {}, "difficulty": difficulty}
	Stats._ensure()
	save_progress()
	clear_saved_run()

# ---------------------------------------------------------------------------
# Progresso da campanha: melhor ante por baralho, vitórias, desbloqueios.
# ---------------------------------------------------------------------------

func load_progress() -> void:
	if not FileAccess.file_exists(PROGRESS_SAVE):
		return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(PROGRESS_SAVE))
	if parsed is Dictionary:
		progress = parsed
		if not progress.has("best_ante"):
			progress["best_ante"] = {}
		if not progress.has("wins"):
			progress["wins"] = {}
		difficulty = String(progress.get("difficulty", "normal"))

func save_progress() -> void:
	var f := FileAccess.open(PROGRESS_SAVE, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(progress))

func best_ante(deck_id: String) -> int:
	return int(progress["best_ante"].get(deck_id, 0))

func wins(deck_id: String) -> int:
	return int(progress["wins"].get(deck_id, 0))

## Regista o fim de uma run (ante atingido; vitória = passou o ante 8). Devolve os desbloqueios novos.
func record_run_end(reached_ante: int, victory: bool) -> Array[String]:
	last_unlocks.clear()
	Stats.on_run_end(victory)
	if free_mode:
		save_progress()
		return last_unlocks
	var id := String(deck_def.get("id", ""))
	var before := _unlocked_deck_ids()
	var reached := reached_ante + (1 if victory else 0)
	progress["best_ante"][id] = max(best_ante(id), reached)
	if victory:
		progress["wins"][id] = wins(id) + 1
	save_progress()
	for did in _unlocked_deck_ids():
		if not (did in before):
			last_unlocks.append(String(CardDB.get_deck(did).get("name", did)))
	return last_unlocks

## Desbloqueio: o 1.º capítulo de cada ato aberto está livre; cada capítulo desbloqueia o seguinte
## ao chegar ao ante 4; um ato abre quando algum capítulo do ato anterior chega ao ante 6.
func is_act_unlocked(act_index: int) -> bool:
	if act_index == 0:
		return true
	var prev: Dictionary = CardDB.campaign[act_index - 1]
	for ch in prev.get("chapters", []):
		if best_ante(String(ch["deck_id"])) >= 6:
			return true
	return false

func is_deck_unlocked(deck_id: String) -> bool:
	for act_index in CardDB.campaign.size():
		var act: Dictionary = CardDB.campaign[act_index]
		var chapters: Array = act.get("chapters", [])
		for i in chapters.size():
			if String(chapters[i]["deck_id"]) != deck_id:
				continue
			if not is_act_unlocked(act_index):
				return false
			if i == 0:
				return true
			return best_ante(String(chapters[i - 1]["deck_id"])) >= 4
	return false

func _unlocked_deck_ids() -> Array[String]:
	var out: Array[String] = []
	for act in CardDB.campaign:
		for ch in act.get("chapters", []):
			if is_deck_unlocked(String(ch["deck_id"])):
				out.append(String(ch["deck_id"]))
	return out
