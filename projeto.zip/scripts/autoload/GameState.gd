extends Node
## Estado da run atual (o "save" em memória). Persistente entre cenas.
## Não contém lógica de batalha — isso vive em BattleManager.

var rng := RandomNumberGenerator.new()
var seed_value: int = 0

# --- Run ---
var ante: int = 1
var max_ante: int = 8
var gold: int = 4
var player_max_hp: int = 20
var player_hp: int = 20

# --- Deck persistente (ids). Instâncias são criadas no início de cada batalha ---
var deck_ids: Array[String] = []
var relic_ids: Array[String] = []

func new_run(start_color: String = "white", seed_override: int = 0) -> void:
	seed_value = seed_override if seed_override != 0 else randi()
	rng.seed = seed_value
	ante = 1
	gold = 4
	player_hp = player_max_hp
	relic_ids.clear()
	deck_ids = _starter_deck(start_color)
	EventBus.run_started.emit()
	EventBus.gold_changed.emit(gold)

## Deck inicial: 8 terrenos + 12 criaturas "starter" da cor escolhida (batalhas curtas pedem menos terrenos).
func _starter_deck(color: String) -> Array[String]:
	var out: Array[String] = []
	var land_id := "land_%s" % color
	for i in 8:
		out.append(land_id)
	var starters := CardDB.cards_by_color(color).filter(func(c): return c.rarity == "starter" and c.type != "land")
	var i := 0
	while out.size() < 20 and not starters.is_empty():
		out.append(starters[i % starters.size()].id)
		i += 1
	return out

func add_gold(amount: int) -> void:
	gold += amount
	EventBus.gold_changed.emit(gold)

func spend_gold(amount: int) -> bool:
	if gold < amount:
		return false
	gold -= amount
	EventBus.gold_changed.emit(gold)
	return true

func add_card(id: String) -> void:
	deck_ids.append(id)

## Remove UMA cópia da carta. Devolve false se não existir.
func remove_card(id: String) -> bool:
	var idx := deck_ids.find(id)
	if idx == -1:
		return false
	deck_ids.remove_at(idx)
	return true

## Custo de remover uma carta na loja: sobe com o ante para não ser trivial afinar o deck.
func removal_price() -> int:
	return 2 + int(ante / 3)

## Contagem por id, para listar o deck sem repetições.
func deck_counts() -> Dictionary:
	var counts := {}
	for id in deck_ids:
		counts[id] = counts.get(id, 0) + 1
	return counts

func add_relic(id: String) -> void:
	if id in relic_ids:
		return
	relic_ids.append(id)
	EventBus.relic_gained.emit(id)

func next_ante() -> void:
	ante += 1
	EventBus.ante_started.emit(ante)

## Alvo de "vida" do inimigo por ante — tabela afinada por simulação (tests/Balance.gd):
## o baralho inicial sem loja morre no ante 3–4; com relíquias o ante 8 é alcançável.
const ANTE_HP := [50, 110, 230, 400, 650, 1050, 1700, 2750]

func enemy_hp_for_ante(a: int) -> int:
	if a <= ANTE_HP.size():
		return ANTE_HP[a - 1]
	return int(round(ANTE_HP[-1] * pow(1.6, a - ANTE_HP.size())))

func turns_for_ante(_a: int) -> int:
	return 5
