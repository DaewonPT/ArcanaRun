extends Node
## Configurações do jogador (user://settings.json): volumes, idioma, velocidade das animações, vibração.
## 0.10.0: escala da interface (90–120 %), modo compacto, reduzir movimento (sem abanões, flashes,
## hit-stop nem partículas), limite de FPS (30/60), ecrã sempre ligado na batalha, avisos opcionais,
## costas de carta e moldura (cosméticos), e exportar/importar o progresso por um código.
## Também cria os buses de áudio "Sfx" e "Music" e carrega a tradução da interface.
##
## Tradução: as chaves são o próprio texto em português (o que está nas cenas e nos scripts);
## i18n/en.json mapeia cada texto para inglês. Texto sem entrada fica em português.
## Os Labels/Buttons traduzem-se sozinhos (auto translate); texto construído com % traduz-se
## primeiro o molde: tr("Turno %d/%d") % [a, b].

signal changed

const PATH := "user://settings.json"
const LANGUAGES := ["auto", "pt", "en"]
const SPEEDS := ["normal", "fast", "instant"]
const SPEED_SCALE := {"normal": 1.0, "fast": 0.45, "instant": 0.0}
const MUSIC_PATH := "res://assets/audio/music.ogg"   # quando existir, o controlo de música aparece

var sfx_volume: float = 1.0      # 0..1
var music_volume: float = 0.7    # 0..1
var language: String = "auto"    # auto | pt | en
var anim_speed: String = "normal"
var vibration: bool = true
var large_text: bool = false     # fontes maiores nas cartas
var left_handed: bool = false    # botões de ação à direita
var colorblind: bool = false     # modo daltónico: símbolo em cada pip de cor
# 0.10.0
var ui_scale: float = 1.0        # 0.9..1.2 (escala da interface)
var compact: bool = false        # cartas mais pequenas (telemóveis pequenos)
var reduce_motion: bool = false  # sem abanões, flashes, hit-stop, partículas nem viragens
var fps_cap: int = 60            # 30 ou 60 (bateria)
var keep_screen_on: bool = true  # ecrã sempre ligado durante a batalha
var warn_mana: bool = true       # "Atacar sem gastar a mana?"
var warn_rare: bool = true       # "Canalizar uma rara?"
var tips_enabled: bool = true    # 0.11.0: dica de uma linha na 1.ª vez de cada mecânica
var card_back: String = "classic"
var card_frame: String = "classic"
const UI_SCALES := [0.9, 0.95, 1.0, 1.05, 1.1, 1.15, 1.2]
const BASE_SIZE := Vector2(1280, 720)

var _en: Translation

func _ready() -> void:
	_make_bus("Sfx")
	_make_bus("Music")
	_load_translations()
	load_settings()
	apply()

# --- Áudio ---

func _make_bus(bus_name: String) -> void:
	if AudioServer.get_bus_index(bus_name) >= 0:
		return
	var idx := AudioServer.bus_count
	AudioServer.add_bus(idx)
	AudioServer.set_bus_name(idx, bus_name)
	AudioServer.set_bus_send(idx, "Master")

func _set_bus_volume(bus_name: String, v: float) -> void:
	var idx := AudioServer.get_bus_index(bus_name)
	if idx < 0:
		return
	AudioServer.set_bus_mute(idx, v <= 0.001)
	AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(v, 0.001)))

func has_music() -> bool:
	return ResourceLoader.exists(MUSIC_PATH)

# --- Idioma ---

func _load_translations() -> void:
	_en = Translation.new()
	_en.locale = "en"
	var path := ContentUpdate.resolve("res://i18n/en.json")
	if FileAccess.file_exists(path):
		var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
		if parsed is Dictionary:
			for k in parsed:
				_en.add_message(String(k), String(parsed[k]))
	# Cartas (data/cards_en.json): nome → nome EN, texto → texto EN. Mesmo mecanismo das chaves PT.
	var cards_path := ContentUpdate.resolve("res://data/cards_en.json")
	if FileAccess.file_exists(cards_path):
		var cards_en = JSON.parse_string(FileAccess.get_file_as_string(cards_path))
		var cards_pt = JSON.parse_string(FileAccess.get_file_as_string(ContentUpdate.resolve("res://data/cards.json")))
		if cards_en is Dictionary and cards_pt is Array:
			for c in cards_pt:
				var tr_entry: Dictionary = cards_en.get(String(c.get("id", "")), {})
				if tr_entry.is_empty():
					continue
				_en.add_message(String(c.get("name", "")), String(tr_entry.get("name", c.get("name", ""))))
				var txt := String(c.get("text", ""))
				if txt != "":
					_en.add_message(txt, String(tr_entry.get("text", txt)))
				# Face de trás das cartas de dupla face.
				var back: Dictionary = c.get("transformed", {})
				if not back.is_empty() and tr_entry.has("back_name"):
					_en.add_message(String(back.get("name", "")), String(tr_entry.get("back_name", "")))
					if String(back.get("text", "")) != "":
						_en.add_message(String(back.get("text", "")), String(tr_entry.get("back_text", back.get("text", ""))))
	TranslationServer.add_translation(_en)

## Idioma em vigor ("pt" ou "en"); "auto" segue o telemóvel.
func effective_language() -> String:
	if language == "auto":
		return "en" if OS.get_locale_language() == "en" else "pt"
	return language

func language_label() -> String:
	match language:
		"pt":
			return "Português"
		"en":
			return "English"
	return tr("Automático") + " (" + ("English" if effective_language() == "en" else "Português") + ")"

func cycle_language() -> void:
	language = LANGUAGES[(LANGUAGES.find(language) + 1) % LANGUAGES.size()]
	apply()

# --- Animações ---

func anim_scale() -> float:
	return float(SPEED_SCALE.get(anim_speed, 1.0))

## Duração de uma animação depois de aplicar a velocidade escolhida (0 = instantâneo).
func dur(seconds: float) -> float:
	return seconds * anim_scale()

func speed_label() -> String:
	match anim_speed:
		"fast":
			return tr("Rápida")
		"instant":
			return tr("Instantânea")
	return tr("Normal")

func cycle_speed() -> void:
	anim_speed = SPEEDS[(SPEEDS.find(anim_speed) + 1) % SPEEDS.size()]
	changed.emit()

# --- Vibração ---

func vibrate(ms: int = 30) -> void:
	if vibration and OS.has_feature("mobile"):
		Input.vibrate_handheld(ms)

# --- Aplicar / disco ---

func apply() -> void:
	_set_bus_volume("Sfx", sfx_volume)
	_set_bus_volume("Music", music_volume)
	TranslationServer.set_locale("en" if effective_language() == "en" else "pt_PT")
	Engine.max_fps = fps_cap if fps_cap > 0 else 0
	_apply_scale()
	changed.emit()

## Escala da interface: 90–120 %. O layout é pensado para 720 de altura (660 no modo compacto):
## acima de 100 % só cresce até onde o ecrã tem altura de sobra (tablets, ecrãs 4:3); num telemóvel
## comprido os 100 % já usam a altura toda — aí o que ajuda é o modo compacto e o texto grande.
func _apply_scale() -> void:
	var tree := get_tree()
	if tree == null or tree.root == null:
		return
	tree.root.content_scale_factor = effective_scale()

## Escala que vale mesmo neste ecrã (a pedida, limitada pela altura disponível).
func effective_scale() -> float:
	var want := clampf(ui_scale, 0.9, 1.2)
	if want <= 1.0:
		return want
	var win := Vector2(DisplayServer.window_get_size())
	if win.x <= 0 or win.y <= 0:
		return 1.0
	var base := minf(win.x / BASE_SIZE.x, win.y / BASE_SIZE.y)
	var need_h := 660.0 if compact else BASE_SIZE.y
	var room := win.y / (base * need_h)
	return clampf(want, 1.0, maxf(1.0, room))

## Movimento reduzido ou animações instantâneas: nada de abanões nem flashes.
func motion_ok() -> bool:
	return not reduce_motion and anim_scale() > 0.0

func scale_label() -> String:
	var txt := "%d%%" % int(round(ui_scale * 100.0))
	var eff := effective_scale()
	if absf(eff - ui_scale) > 0.01:
		txt += "  (" + tr("neste ecrã: %d%%") % int(round(eff * 100.0)) + ")"
	return txt

func cycle_scale(step: int = 1) -> void:
	var i := UI_SCALES.find(snappedf(ui_scale, 0.05))
	if i < 0:
		i = 2
	ui_scale = UI_SCALES[clampi(i + step, 0, UI_SCALES.size() - 1)]
	apply()

## Ecrã sempre ligado (só durante a batalha, se a opção estiver ligada).
func set_battle_screen_on(on: bool) -> void:
	if DisplayServer.get_name() == "headless":
		return
	DisplayServer.screen_set_keep_on(on and keep_screen_on)

## Cosméticos desbloqueados de um tipo ("back" / "frame"): a clássica e os ganhos.
func unlocked_cosmetics(kind: String) -> Array:
	var out: Array = []
	for c in CardDB.cosmetics.get(kind + "s", []):
		var id := String(c.get("id", ""))
		if id == "classic" or Stats.is_content_unlocked(kind, id):
			out.append(id)
	return out

func cycle_cosmetic(kind: String) -> void:
	var list := unlocked_cosmetics(kind)
	if list.is_empty():
		return
	var cur := card_back if kind == "back" else card_frame
	var i := list.find(cur)
	var nxt := String(list[(i + 1) % list.size()])
	if kind == "back":
		card_back = nxt
	else:
		card_frame = nxt
	changed.emit()

# --- Exportar / importar o progresso (mudar de telemóvel sem contas) ---

const EXPORT_PREFIX := "ZS1:"

## Código com o progresso, as configurações, os baralhos do Construtor e a run gravada.
## Formato: "ZS1:" + base64(gzip(json)) + ":" + os primeiros 8 carateres do sha256 do json.
func export_code() -> String:
	var data := {
		"v": 1,
		"progress": GameState.progress,
		"settings": _settings_dict(),
		"custom_decks": CardDB.custom_decks,
		"run": JSON.parse_string(FileAccess.get_file_as_string(GameState.RUN_SAVE)) if GameState.has_saved_run() else null,
	}
	var json := JSON.stringify(data)
	var raw := json.to_utf8_buffer()
	var packed := raw.compress(FileAccess.COMPRESSION_GZIP)
	return EXPORT_PREFIX + Marshalls.raw_to_base64(packed) + ":" + json.sha256_text().substr(0, 8)

## Lê um código. Devolve {} se não for válido; senão o dicionário com o progresso.
func parse_code(code: String) -> Dictionary:
	var c := code.strip_edges().replace("\n", "").replace(" ", "")
	if not c.begins_with(EXPORT_PREFIX):
		return {}
	var parts := c.substr(EXPORT_PREFIX.length()).split(":")
	if parts.size() != 2:
		return {}
	var packed := Marshalls.base64_to_raw(parts[0])
	if packed.is_empty():
		return {}
	var raw := packed.decompress_dynamic(8 * 1024 * 1024, FileAccess.COMPRESSION_GZIP)
	if raw.is_empty():
		return {}
	var json := raw.get_string_from_utf8()
	if json.sha256_text().substr(0, 8) != parts[1]:
		return {}
	var parsed = JSON.parse_string(json)
	if not (parsed is Dictionary) or not (parsed.get("progress") is Dictionary):
		return {}
	return parsed

## Aplica um código já validado: substitui o progresso deste telemóvel.
func import_code(code: String) -> bool:
	var d := parse_code(code)
	if d.is_empty():
		return false
	GameState.progress = d["progress"]
	GameState.load_progress_from(GameState.progress)
	GameState.save_progress()
	if d.get("settings") is Dictionary:
		_load_from(d["settings"])
		save_settings()
	if d.get("custom_decks") is Dictionary:
		CardDB.custom_decks = d["custom_decks"]
		CardDB.save_custom_decks()
	GameState.clear_saved_run()
	if d.get("run") is Dictionary:
		var f := FileAccess.open(GameState.RUN_SAVE, FileAccess.WRITE)
		if f:
			f.store_string(JSON.stringify(d["run"]))
	Stats._ensure()
	apply()
	return true

func load_settings() -> void:
	if not FileAccess.file_exists(PATH):
		return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(PATH))
	if not (parsed is Dictionary):
		return
	_load_from(parsed)

func _load_from(parsed: Dictionary) -> void:
	sfx_volume = clampf(float(parsed.get("sfx_volume", sfx_volume)), 0.0, 1.0)
	music_volume = clampf(float(parsed.get("music_volume", music_volume)), 0.0, 1.0)
	language = String(parsed.get("language", language))
	if not (language in LANGUAGES):
		language = "auto"
	anim_speed = String(parsed.get("anim_speed", anim_speed))
	if not (anim_speed in SPEEDS):
		anim_speed = "normal"
	vibration = bool(parsed.get("vibration", vibration))
	large_text = bool(parsed.get("large_text", large_text))
	left_handed = bool(parsed.get("left_handed", left_handed))
	colorblind = bool(parsed.get("colorblind", colorblind))
	ui_scale = clampf(float(parsed.get("ui_scale", ui_scale)), 0.9, 1.2)
	compact = bool(parsed.get("compact", compact))
	reduce_motion = bool(parsed.get("reduce_motion", reduce_motion))
	fps_cap = 30 if int(parsed.get("fps_cap", fps_cap)) == 30 else 60
	keep_screen_on = bool(parsed.get("keep_screen_on", keep_screen_on))
	warn_mana = bool(parsed.get("warn_mana", warn_mana))
	warn_rare = bool(parsed.get("warn_rare", warn_rare))
	tips_enabled = bool(parsed.get("tips_enabled", tips_enabled))
	card_back = String(parsed.get("card_back", card_back))
	card_frame = String(parsed.get("card_frame", card_frame))

func _settings_dict() -> Dictionary:
	return {
		"sfx_volume": sfx_volume,
		"music_volume": music_volume,
		"language": language,
		"anim_speed": anim_speed,
		"vibration": vibration,
		"large_text": large_text,
		"left_handed": left_handed,
		"colorblind": colorblind,
		"ui_scale": ui_scale,
		"compact": compact,
		"reduce_motion": reduce_motion,
		"fps_cap": fps_cap,
		"keep_screen_on": keep_screen_on,
		"warn_mana": warn_mana,
		"warn_rare": warn_rare,
		"tips_enabled": tips_enabled,
		"card_back": card_back,
		"card_frame": card_frame,
	}

func save_settings() -> void:
	var f := FileAccess.open(PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(_settings_dict()))
