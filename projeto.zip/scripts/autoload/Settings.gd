extends Node
## Configurações do jogador (user://settings.json): volumes, idioma, velocidade das animações, vibração.
## Também cria os buses de áudio "Sfx" e "Music" e carrega a tradução da interface.
##
## Tradução: as chaves são o próprio texto em português (o que está nas cenas e nos scripts);
## i18n/en.json mapeia cada texto para inglês. Texto sem entrada fica em português.
## Os Labels/Buttons traduzem-se sozinhos (auto translate); texto construído com % traduz-se
## primeiro o molde: tr("Turno %d/%d") % [a, b].

signal changed

const PATH := "user://settings.json"
const LANGUAGES := ["auto", "pt", "en"]
const SPEEDS := ["normal", "fast", "instant"]
const SPEED_SCALE := {"normal": 1.0, "fast": 0.45, "instant": 0.0}
const MUSIC_PATH := "res://assets/audio/music.ogg"   # quando existir, o controlo de música aparece

var sfx_volume: float = 1.0      # 0..1
var music_volume: float = 0.7    # 0..1
var language: String = "auto"    # auto | pt | en
var anim_speed: String = "normal"
var vibration: bool = true
var large_text: bool = false     # fontes maiores nas cartas
var left_handed: bool = false    # botões de ação à direita
var colorblind: bool = false     # modo daltónico: símbolo em cada pip de cor

var _en: Translation

func _ready() -> void:
	_make_bus("Sfx")
	_make_bus("Music")
	_load_translations()
	load_settings()
	apply()

# --- Áudio ---

func _make_bus(bus_name: String) -> void:
	if AudioServer.get_bus_index(bus_name) >= 0:
		return
	var idx := AudioServer.bus_count
	AudioServer.add_bus(idx)
	AudioServer.set_bus_name(idx, bus_name)
	AudioServer.set_bus_send(idx, "Master")

func _set_bus_volume(bus_name: String, v: float) -> void:
	var idx := AudioServer.get_bus_index(bus_name)
	if idx < 0:
		return
	AudioServer.set_bus_mute(idx, v <= 0.001)
	AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(v, 0.001)))

func has_music() -> bool:
	return ResourceLoader.exists(MUSIC_PATH)

# --- Idioma ---

func _load_translations() -> void:
	_en = Translation.new()
	_en.locale = "en"
	var path := ContentUpdate.resolve("res://i18n/en.json")
	if FileAccess.file_exists(path):
		var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
		if parsed is Dictionary:
			for k in parsed:
				_en.add_message(String(k), String(parsed[k]))
	# Cartas (data/cards_en.json): nome → nome EN, texto → texto EN. Mesmo mecanismo das chaves PT.
	var cards_path := ContentUpdate.resolve("res://data/cards_en.json")
	if FileAccess.file_exists(cards_path):
		var cards_en = JSON.parse_string(FileAccess.get_file_as_string(cards_path))
		var cards_pt = JSON.parse_string(FileAccess.get_file_as_string(ContentUpdate.resolve("res://data/cards.json")))
		if cards_en is Dictionary and cards_pt is Array:
			for c in cards_pt:
				var tr_entry: Dictionary = cards_en.get(String(c.get("id", "")), {})
				if tr_entry.is_empty():
					continue
				_en.add_message(String(c.get("name", "")), String(tr_entry.get("name", c.get("name", ""))))
				var txt := String(c.get("text", ""))
				if txt != "":
					_en.add_message(txt, String(tr_entry.get("text", txt)))
				# Face de trás das cartas de dupla face.
				var back: Dictionary = c.get("transformed", {})
				if not back.is_empty() and tr_entry.has("back_name"):
					_en.add_message(String(back.get("name", "")), String(tr_entry.get("back_name", "")))
					if String(back.get("text", "")) != "":
						_en.add_message(String(back.get("text", "")), String(tr_entry.get("back_text", back.get("text", ""))))
	TranslationServer.add_translation(_en)

## Idioma em vigor ("pt" ou "en"); "auto" segue o telemóvel.
func effective_language() -> String:
	if language == "auto":
		return "en" if OS.get_locale_language() == "en" else "pt"
	return language

func language_label() -> String:
	match language:
		"pt":
			return "Português"
		"en":
			return "English"
	return tr("Automático") + " (" + ("English" if effective_language() == "en" else "Português") + ")"

func cycle_language() -> void:
	language = LANGUAGES[(LANGUAGES.find(language) + 1) % LANGUAGES.size()]
	apply()

# --- Animações ---

func anim_scale() -> float:
	return float(SPEED_SCALE.get(anim_speed, 1.0))

## Duração de uma animação depois de aplicar a velocidade escolhida (0 = instantâneo).
func dur(seconds: float) -> float:
	return seconds * anim_scale()

func speed_label() -> String:
	match anim_speed:
		"fast":
			return tr("Rápida")
		"instant":
			return tr("Instantânea")
	return tr("Normal")

func cycle_speed() -> void:
	anim_speed = SPEEDS[(SPEEDS.find(anim_speed) + 1) % SPEEDS.size()]
	changed.emit()

# --- Vibração ---

func vibrate(ms: int = 30) -> void:
	if vibration and OS.has_feature("mobile"):
		Input.vibrate_handheld(ms)

# --- Aplicar / disco ---

func apply() -> void:
	_set_bus_volume("Sfx", sfx_volume)
	_set_bus_volume("Music", music_volume)
	TranslationServer.set_locale("en" if effective_language() == "en" else "pt_PT")
	changed.emit()

func load_settings() -> void:
	if not FileAccess.file_exists(PATH):
		return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(PATH))
	if not (parsed is Dictionary):
		return
	sfx_volume = clampf(float(parsed.get("sfx_volume", sfx_volume)), 0.0, 1.0)
	music_volume = clampf(float(parsed.get("music_volume", music_volume)), 0.0, 1.0)
	language = String(parsed.get("language", language))
	if not (language in LANGUAGES):
		language = "auto"
	anim_speed = String(parsed.get("anim_speed", anim_speed))
	if not (anim_speed in SPEEDS):
		anim_speed = "normal"
	vibration = bool(parsed.get("vibration", vibration))
	large_text = bool(parsed.get("large_text", large_text))
	left_handed = bool(parsed.get("left_handed", left_handed))
	colorblind = bool(parsed.get("colorblind", colorblind))

func save_settings() -> void:
	var f := FileAccess.open(PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify({
			"sfx_volume": sfx_volume,
			"music_volume": music_volume,
			"language": language,
			"anim_speed": anim_speed,
			"vibration": vibration,
			"large_text": large_text,
			"left_handed": left_handed,
			"colorblind": colorblind,
		}))
