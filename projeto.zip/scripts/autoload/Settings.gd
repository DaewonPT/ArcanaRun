extends Node
## Configurações do jogador (user://settings.json): volumes, idioma, velocidade das animações, vibração.
## 0.10.0: escala da interface (90–120 %), modo compacto, reduzir movimento (sem abanões, flashes,
## hit-stop nem partículas), limite de FPS (30/60), ecrã sempre ligado na batalha, avisos opcionais,
## costas de carta e moldura (cosméticos), e exportar/importar o progresso por um código.
## Também cria os buses de áudio "Sfx" e "Music" e carrega a tradução da interface.
##
## Tradução: as chaves são o próprio texto em português (o que está nas cenas e nos scripts);
## i18n/en.json mapeia cada texto para inglês. Texto sem entrada fica em português.
## Os Labels/Buttons traduzem-se sozinhos (auto translate); texto construído com % traduz-se
## primeiro o molde: tr("Turno %d/%d") % [a, b].

signal changed

const PATH := "user://settings.json"   # perfil 1; os outros perfis usam path() (0.19.0)
const LANGUAGES := ["auto", "pt", "en"]
const SPEEDS := ["normal", "fast", "instant"]
const SPEED_SCALE := {"normal": 1.0, "fast": 0.45, "instant": 0.0}
const MUSIC_PATH := "res://assets/audio/music_menu.ogg"   # 0.12.0: música gerada (tools/make_audio.py)

var sfx_volume: float = 1.0      # 0..1
var music_volume: float = 0.6    # 0..1
var language: String = "auto"    # auto | pt | en
var anim_speed: String = "normal"
var vibration: bool = true
var large_text: bool = false     # fontes maiores nas cartas
var left_handed: bool = false    # botões de ação à direita
var colorblind: bool = false     # modo daltónico: símbolo em cada pip de cor
# 0.10.0
var ui_scale: float = 1.0        # 0.9..1.2 (escala da interface)
var compact: bool = false        # cartas mais pequenas (telemóveis pequenos)
var reduce_motion: bool = false  # sem abanões, flashes, hit-stop, partículas nem viragens
var fps_cap: int = 60            # 30 ou 60 (bateria)
var keep_screen_on: bool = true  # ecrã sempre ligado durante a batalha
var warn_mana: bool = true       # "Atacar sem gastar a mana?"
var warn_rare: bool = true       # "Canalizar uma rara?"
var tips_enabled: bool = true    # 0.11.0: dica de uma linha na 1.ª vez de cada mecânica
# 0.12.0
var hand_sort: String = ""       # ordem da mão na batalha: "" (como vieram), "cost" ou "type"
var arena_mat: String = "classic"   # tapete da Arena (cosmético)
var attack_fx: String = "classic"   # efeito do golpe final (cosmético)
var play_hints: bool = true      # botão DICA na batalha (só no Fácil)
var play_taps: int = 2           # 0.12.1: jogar uma carta da mão com 2 toques (escolher e jogar) ou com 1
var performance_mode: bool = false   # menos efeitos e 30 fps (telemóveis fracos, bateria)
var high_contrast: bool = false      # texto e contornos mais fortes, fundos mais escuros
var show_art: bool = true            # ilustrações das cartas, retratos e fundos (quando existem)
var card_back: String = "classic"
var card_frame: String = "classic"
# 0.13.0
var show_threats: bool = true        # setas e etiquetas do que o inimigo vai fazer às tuas criaturas
var hand_scale: float = 1.0          # tamanho das cartas da mão (0.85–1.3)
var one_hand: bool = false           # modo de uma mão: botões principais em baixo, do lado da mão dominante
var confirm_buy: bool = true         # confirmar compras caras na loja (10+ ouro, ou 5+ e metade do que tens)
var tilt_3d: bool = true             # a carta em grande inclina com o telemóvel
# 0.16.0
var perf_offer_done: bool = false    # já se mediu a velocidade (1.ª cascata) e, se era lenta, já se ofereceu o modo de desempenho
const HAND_SCALES := [0.85, 1.0, 1.15, 1.3]
const UI_SCALES := [0.9, 0.95, 1.0, 1.05, 1.1, 1.15, 1.2, 1.3, 1.4, 1.5]   # 0.19.0 (260): até 150 %
const UI_SCALE_MAX := 1.5

# 0.19.0: as opções novas (as 300 do documento) vivem num dicionário — `opt("chave")` / `set_opt()`.
# O valor por omissão diz o tipo; as de texto só aceitam os valores de OPT_CHOICES.
const OPT_DEFAULTS := {
	# Controlos (1–32)
	"long_press": "normal", "drag_threshold": "normal", "hold_attack": false, "two_finger": true,
	"buttons_big": 0, "hand_offset": 0, "edge_guard": true, "palm_guard": false, "vibration_strength": 2,
	"battle_buttons": "hand",
	# Texto e HUD (135–168)
	"menu_text": 1.0, "toast_time": "normal", "boss_wait": false, "clock": false, "icon_labels": false,
	"numbers": "auto", "light_cards": false, "kw_reminders": false, "cascade_big": false, "cascade_bg": true,
	"ach_corner": true, "typewriter": "normal", "zoom_text": false,
	"hud_climate": true, "hud_contract": true, "hud_patron": true, "hud_chain": true, "hud_objective": true,
	# Visual (101–134, 211, 216, 262, 292, 295–297)
	"focus_cascade": false, "calm_bg": false, "art_brightness": 1.0, "foil_zoom_only": false,
	"theme": "classic", "accent": "gold", "menu_bg": "act", "colorblind_filter": "none", "tablet": "auto",
	# Ritmo (169–202)
	"enemy_speed": "normal", "intro_once": false, "short_banners": false, "short_celebrations": true,
	"auto_end": false, "booster_fast": false, "wheel_fast": false, "rewards_toast": false, "speedrun": false,
	"defer_notices": false, "news_auto": true, "break_reminder": 0, "self_limit": "off",
	"merchant_lines": "always", "interludes": "always", "rules_refresher": true, "card_reward": false,
	# Som (267–274)
	"master_volume": 1.0, "ui_volume": 1.0, "mono": false, "soft_sounds": false, "attack_music": true,
	"captions": false, "cues": false, "muted": false, "menu_track": "",
	# Acessibilidade (255–290)
	"tts_auto": false, "reader": false, "dyslexic": false, "spacing": false,
	"fx_shake": true, "fx_flash": true, "fx_particles": true, "fx_flips": true, "fx_living_art": true,
	"shake_strength": 1.0, "assist_turn": false, "assist_channel": false, "assist_hp": false,
	"assist_rewind": false, "assist_retry": false, "hint_all": false, "simple_text": false,
	"move_buttons": false, "no_longpress": false, "touch_circle": false,
	# Desempenho e calor (203–254)
	"auto_perf": true, "dim_idle": true, "screen_limit": true, "saver_extra": false, "dev_mode": false, "auto_perf_on": false,
	# Perfil e global (293–300)
	"cards_language": "same", "number_format": "auto", "random_cosmetics": false,
}
const OPT_CHOICES := {
	"long_press": ["short", "normal", "long"], "drag_threshold": ["low", "normal", "high"],
	"battle_buttons": ["hand", "left", "right", "bottom"], "toast_time": ["normal", "long", "longer", "tap"],
	"numbers": ["auto", "full", "short"], "typewriter": ["slow", "normal", "fast", "instant"],
	"theme": ["classic", "light", "black"], "accent": ["gold", "blue", "green", "red"],
	"menu_bg": ["act", "faction", "plain"], "colorblind_filter": ["none", "protan", "deutan", "tritan"],
	"tablet": ["auto", "on", "off"], "enemy_speed": ["normal", "fast", "instant"],
	"self_limit": ["off", "runs1", "runs3", "min30", "min45", "min60"],
	"merchant_lines": ["always", "sometimes", "never"], "interludes": ["always", "first"],
	"cards_language": ["same", "pt", "en"], "number_format": ["auto", "pt", "en", "space"],
	"buttons_big": [0, 1, 2], "hand_offset": [-16, 0, 16, 32], "vibration_strength": [1, 2, 3],
	"menu_text": [1.0, 1.15, 1.3], "art_brightness": [1.0, 1.15, 1.3], "break_reminder": [0, 30, 60, 90],
}
# Valores por omissão das opções antigas (vars), para «Repor as predefinições» (290).
const LEGACY_DEFAULTS := {
	"sfx_volume": 1.0, "music_volume": 0.6, "language": "auto", "anim_speed": "normal", "vibration": true,
	"large_text": false, "left_handed": false, "colorblind": false, "ui_scale": 1.0, "compact": false,
	"reduce_motion": false, "fps_cap": 60, "keep_screen_on": true, "warn_mana": true, "warn_rare": true,
	"tips_enabled": true, "play_hints": true, "play_taps": 2, "performance_mode": false, "high_contrast": false,
	"show_art": true, "show_threats": true, "hand_scale": 1.0, "one_hand": false, "confirm_buy": true, "tilt_3d": true,
}
# 0.19.0 (287): predefinições que ligam de uma vez as opções certas.
const PRESETS := {
	"vision": {"large_text": true, "high_contrast": true, "menu_text": 1.3, "kw_reminders": true, "cascade_big": true,
		"cascade_bg": true, "toast_time": "long", "typewriter": "slow", "icon_labels": true, "spacing": true,
		"art_brightness": 1.15, "boss_wait": true},
	"motor": {"play_taps": 1, "long_press": "long", "drag_threshold": "high", "buttons_big": 2, "move_buttons": true,
		"no_longpress": true, "edge_guard": true, "palm_guard": true, "hold_attack": false, "two_finger": false},
	"focus": {"fx_shake": false, "fx_flash": false, "fx_particles": false, "calm_bg": true, "focus_cascade": true,
		"defer_notices": true, "short_banners": true, "merchant_lines": "sometimes", "toast_time": "long"},
}
var opts: Dictionary = {}
const HAND_SORTS := ["", "cost", "type"]
const HAND_SORT_NAMES := {"": "A tua ordem", "cost": "Por custo", "type": "Por tipo"}   # "": como vieram, ou como as arrastaste
const BASE_SIZE := Vector2(1280, 720)

var _en: Translation

func _ready() -> void:
	_make_bus("Sfx")
	_make_bus("Music")
	_make_bus("UI")   # 0.19.0 (270): os cliques da interface têm volume próprio
	_load_translations()
	load_settings()
	apply()

# --- Áudio ---

func _make_bus(bus_name: String) -> void:
	if AudioServer.get_bus_index(bus_name) >= 0:
		return
	var idx := AudioServer.bus_count
	AudioServer.add_bus(idx)
	AudioServer.set_bus_name(idx, bus_name)
	AudioServer.set_bus_send(idx, "Master")

func _set_bus_volume(bus_name: String, v: float) -> void:
	var idx := AudioServer.get_bus_index(bus_name)
	if idx < 0:
		return
	AudioServer.set_bus_mute(idx, v <= 0.001)
	AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(v, 0.001)))

## 0.19.0: volume geral e silêncio (270, 271), som mono (269) e sons suaves (272).
func _apply_master_audio() -> void:
	var m := AudioServer.get_bus_index("Master")
	AudioServer.set_bus_mute(m, bool(opt("muted")) or float(opt("master_volume")) <= 0.001)
	AudioServer.set_bus_volume_db(m, linear_to_db(maxf(float(opt("master_volume")), 0.001)))
	_set_bus_effect(m, "AudioEffectStereoEnhance", bool(opt("mono")), func():
		var e := AudioEffectStereoEnhance.new()
		e.pan_pullout = 0.0   # 0 = as duas colunas com o mesmo som
		return e)
	for bus_name in ["Sfx", "UI"]:
		var i := AudioServer.get_bus_index(bus_name)
		if i < 0:
			continue
		_set_bus_effect(i, "AudioEffectLowPassFilter", bool(opt("soft_sounds")), func():
			var lp := AudioEffectLowPassFilter.new()
			lp.cutoff_hz = 3200.0
			return lp)
	if bool(opt("soft_sounds")):
		var sfx := AudioServer.get_bus_index("Sfx")
		AudioServer.set_bus_volume_db(sfx, AudioServer.get_bus_volume_db(sfx) - 5.0)

## Liga ou desliga um efeito de áudio (pela classe) num bus.
func _set_bus_effect(bus: int, cls: String, on: bool, make: Callable) -> void:
	var at := -1
	for i in AudioServer.get_bus_effect_count(bus):
		if AudioServer.get_bus_effect(bus, i).get_class() == cls:
			at = i
			break
	if on and at < 0:
		AudioServer.add_bus_effect(bus, make.call())
	elif not on and at >= 0:
		AudioServer.remove_bus_effect(bus, at)

func toggle_mute() -> void:
	set_opt("muted", not bool(opt("muted")))
	apply()

func has_music() -> bool:
	return ResourceLoader.exists(MUSIC_PATH)

# --- Idioma ---

func _load_translations() -> void:
	# 0.19.0 (244): as traduções juntas (textos + cartas) guardam-se prontas; só se juntam outra vez quando um
	# dos ficheiros muda (ler a guardada: ~0,2 ms; juntar: ~40 ms no computador).
	var t0 := Time.get_ticks_usec()
	var key := DataCache.key_for([ContentUpdate.resolve("res://i18n/en.json"), ContentUpdate.resolve("res://data/cards_en.json"), ContentUpdate.resolve("res://data/cards.json")])
	var cached := DataCache.load_translation("en_tr", key)
	if cached != null:
		_en = cached
		TranslationServer.add_translation(_en)
		ErrorReport.boot["tr_ms"] = (Time.get_ticks_usec() - t0) / 1000.0
		return
	_build_translations()
	_en = DataCache.save_translation("en_tr", key, _en)
	TranslationServer.add_translation(_en)
	ErrorReport.boot["tr_ms"] = (Time.get_ticks_usec() - t0) / 1000.0

func _build_translations() -> void:
	_en = Translation.new()
	_en.locale = "en"
	var path := ContentUpdate.resolve("res://i18n/en.json")
	if FileAccess.file_exists(path):
		var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
		if parsed is Dictionary:
			for k in parsed:
				_en.add_message(String(k), String(parsed[k]))
	# Cartas (data/cards_en.json): nome → nome EN, texto → texto EN. Mesmo mecanismo das chaves PT.
	var cards_path := ContentUpdate.resolve("res://data/cards_en.json")
	if FileAccess.file_exists(cards_path):
		var cards_en = JSON.parse_string(FileAccess.get_file_as_string(cards_path))
		var cards_pt = JSON.parse_string(FileAccess.get_file_as_string(ContentUpdate.resolve("res://data/cards.json")))
		if cards_en is Dictionary and cards_pt is Array:
			for c in cards_pt:
				var tr_entry: Dictionary = cards_en.get(String(c.get("id", "")), {})
				if tr_entry.is_empty():
					continue
				_en.add_message(String(c.get("name", "")), String(tr_entry.get("name", c.get("name", ""))))
				var txt := String(c.get("text", ""))
				if txt != "":
					_en.add_message(txt, String(tr_entry.get("text", txt)))
				# Face de trás das cartas de dupla face.
				var back: Dictionary = c.get("transformed", {})
				if not back.is_empty() and tr_entry.has("back_name"):
					_en.add_message(String(back.get("name", "")), String(tr_entry.get("back_name", "")))
					if String(back.get("text", "")) != "":
						_en.add_message(String(back.get("text", "")), String(tr_entry.get("back_text", back.get("text", ""))))

## Idioma em vigor ("pt" ou "en"); "auto" segue o telemóvel.
func effective_language() -> String:
	if language == "auto":
		return "en" if OS.get_locale_language() == "en" else "pt"
	return language

func language_label() -> String:
	match language:
		"pt":
			return "Português"
		"en":
			return "English"
	return tr("Automático") + " (" + ("English" if effective_language() == "en" else "Português") + ")"

func cycle_language() -> void:
	language = LANGUAGES[(LANGUAGES.find(language) + 1) % LANGUAGES.size()]
	apply()

# --- Animações ---

func anim_scale() -> float:
	return float(SPEED_SCALE.get(anim_speed, 1.0))

## Duração de uma animação depois de aplicar a velocidade escolhida (0 = instantâneo).
func dur(seconds: float) -> float:
	return seconds * anim_scale()

func speed_label() -> String:
	match anim_speed:
		"fast":
			return tr("Rápida")
		"instant":
			return tr("Instantânea")
	return tr("Normal")

func cycle_speed() -> void:
	anim_speed = SPEEDS[(SPEEDS.find(anim_speed) + 1) % SPEEDS.size()]
	changed.emit()

## 0.12.0: ordem da mão na batalha (botão ORDENAR): como vieram → por custo → por tipo.
func cycle_hand_sort() -> void:
	hand_sort = HAND_SORTS[(HAND_SORTS.find(hand_sort) + 1) % HAND_SORTS.size()]
	save_settings()

# --- Vibração ---

const VIBRATION_AMP := {1: 0.35, 2: 0.7, 3: 1.0}

## 0.19.0 (3, 4): quanto tempo é um toque longo e quanto o dedo anda até virar arrasto, à escolha.
const LONG_PRESS_TIMES := {"short": 0.3, "normal": 0.42, "long": 0.65}
const DRAG_PX := {"low": 10.0, "normal": 16.0, "high": 26.0}

func long_press_time() -> float:
	return float(LONG_PRESS_TIMES.get(String(opt("long_press")), 0.42))

func drag_px() -> float:
	return float(DRAG_PX.get(String(opt("drag_threshold")), 16.0))

# --- 0.19.0 (secção 5): legibilidade e HUD ---

## 138: quanto tempo fica um aviso (0 = até lhe tocares).
func toast_seconds(base: float) -> float:
	match String(opt("toast_time")):
		"long":
			return maxf(base, 5.0)
		"longer":
			return maxf(base, 8.0)
		"tap":
			return 0.0
	return base

## 136: o texto das janelas, avisos e listas (1,0 · 1,15 · 1,3), à parte da escala da interface.
func menu_text_scale() -> float:
	return clampf(float(opt("menu_text")), 1.0, 1.5)

## 163: letras por segundo da máquina de escrever (0 = o texto aparece logo).
func typewriter_cps() -> float:
	match String(opt("typewriter")):
		"slow":
			return 20.0
		"fast":
			return 90.0
		"instant":
			return 0.0
	return 40.0

## 180: o turno do inimigo mais rápido (só o que ele faz; as tuas animações não mudam).
func enemy_speed_factor() -> float:
	match String(opt("enemy_speed")):
		"fast":
			return 0.45
		"instant":
			return 0.05
	return 1.0

## 146: números abreviados (1,2 M) ou completos; «auto» abrevia só no Infinito.
func short_numbers(endless: bool) -> bool:
	match String(opt("numbers")):
		"full":
			return false
		"short":
			return true
	return endless

func vibrate(ms: int = 30) -> void:
	if vibration and OS.has_feature("mobile"):
		var strength := int(opt("vibration_strength"))
		var amp: float = VIBRATION_AMP.get(strength, 0.7)
		Input.vibrate_handheld(int(ms * (0.75 if strength == 1 else 1.0)), amp)

## 0.19.0 (30): vibrações diferentes por momento — leve ao escolher, média ao jogar, forte no golpe final e
## dupla quando levas dano.
const HAPTICS := {"select": [12], "play": [26], "hit": [55], "lethal": [110], "damage": [40, 90, 40], "reward": [20, 60, 20]}

func haptic(kind: String) -> void:
	var pattern: Array = HAPTICS.get(kind, [20])
	vibrate(int(pattern[0]))
	if pattern.size() >= 3:
		var tree := get_tree()
		if tree != null:
			await tree.create_timer(float(pattern[1]) / 1000.0).timeout
			vibrate(int(pattern[2]))

# --- Aplicar / disco ---

func apply() -> void:
	_set_bus_volume("Sfx", sfx_volume)
	_set_bus_volume("Music", music_volume)
	_set_bus_volume("UI", sfx_volume * float(opt("ui_volume")))
	_apply_master_audio()
	TranslationServer.set_locale("en" if effective_language() == "en" else "pt_PT")
	Engine.max_fps = 30 if performance_mode else (fps_cap if fps_cap > 0 else 0)
	_apply_scale()
	_apply_contrast()
	changed.emit()

var _hc_theme: Theme

## 0.12.0: alto contraste — tema por cima do do projeto (textos brancos com contorno escuro, botões e
## painéis com contorno claro). Os textos feitos em código (UiKit) tratam do resto ao serem criados.
## 0.19.0 (258, 259): o mesmo tema da raiz leva também a letra para dislexia (OpenDyslexic) e mais espaço entre
## letras e linhas. Faz-se de novo quando uma destas opções muda.
var _root_sig := ""
var _root_theme: Theme
const DYS_REGULAR := "res://assets/fonts/OpenDyslexic-Regular.woff2"
const DYS_BOLD := "res://assets/fonts/OpenDyslexic-Bold.woff2"

func _apply_contrast() -> void:
	var tree := get_tree()
	if tree == null or tree.root == null:
		return
	var dys := bool(opt("dyslexic"))
	var sp := bool(opt("spacing"))
	var sig := "%s|%s|%s" % [high_contrast, dys, sp]
	if sig == _root_sig and (tree.root.theme == _root_theme or (_root_theme == null and tree.root.theme == null)):
		return
	_root_sig = sig
	if not high_contrast and not dys and not sp:
		_root_theme = null
		tree.root.theme = null
		return
	var t: Theme
	if high_contrast:
		if _hc_theme == null:
			_hc_theme = _make_hc_theme()
		t = _hc_theme.duplicate(true) if (dys or sp) else _hc_theme
	else:
		var base: Theme = ThemeDB.get_project_theme()
		t = base.duplicate(true) if base != null else Theme.new()
	if dys or sp:
		var body: Font = load(DYS_REGULAR) as Font if dys else (t.default_font if t.default_font != null else ThemeDB.fallback_font)
		var title: Font = load(DYS_BOLD) as Font if dys else t.get_font("font", "TitleLabel")
		if sp:
			body = _spaced(body)
			if title != null:
				title = _spaced(title)
			for type in ["Label", "RichTextLabel"]:
				t.set_constant("line_spacing", type, 5)
		t.default_font = body
		for type in ["Label", "Button", "LineEdit", "RichTextLabel", "TextEdit", "OptionButton"]:
			t.set_font("font" if type != "RichTextLabel" else "normal_font", type, body)
		if title != null:
			t.set_font("font", "TitleLabel", title)
	_root_theme = t
	tree.root.theme = t

static func _spaced(f: Font) -> Font:
	var v := FontVariation.new()
	v.base_font = f
	v.spacing_glyph = 1
	v.spacing_space = 3
	return v

## 258: o tipo de letra em uso no texto (para os testes).
func root_font() -> Font:
	var tree := get_tree()
	return tree.root.theme.default_font if tree != null and tree.root.theme != null else null

func _make_hc_theme() -> Theme:
	var base: Theme = ThemeDB.get_project_theme()
	var t: Theme = base.duplicate(true) if base != null else Theme.new()
	for type in ["Label", "Button", "LineEdit", "OptionButton", "CheckBox"]:
		t.set_color("font_color", type, Color.WHITE)
		t.set_color("font_outline_color", type, Color(0, 0, 0, 0.92))
		t.set_constant("outline_size", type, 3)
	for st in ["normal", "hover", "pressed", "disabled"]:
		var sb = t.get_stylebox(st, "Button")
		if sb is StyleBoxFlat:
			var f := (sb as StyleBoxFlat).duplicate() as StyleBoxFlat
			f.set_border_width_all(2)
			f.border_color = Color(0.92, 0.9, 1.0, 0.85)
			t.set_stylebox(st, "Button", f)
	var panel = t.get_stylebox("panel", "PanelContainer")
	if panel is StyleBoxFlat:
		var pf := (panel as StyleBoxFlat).duplicate() as StyleBoxFlat
		pf.set_border_width_all(2)
		pf.border_color = Color(0.85, 0.82, 0.95, 0.7)
		t.set_stylebox("panel", "PanelContainer", pf)
	return t

## Escala da interface: 90–120 %. O layout é pensado para 720 de altura (660 no modo compacto):
## acima de 100 % só cresce até onde o ecrã tem altura de sobra (tablets, ecrãs 4:3); num telemóvel
## comprido os 100 % já usam a altura toda — aí o que ajuda é o modo compacto e o texto grande.
func _apply_scale() -> void:
	var tree := get_tree()
	if tree == null or tree.root == null:
		return
	tree.root.content_scale_factor = effective_scale()

## Escala que vale mesmo neste ecrã (a pedida, limitada pela altura disponível).
func effective_scale() -> float:
	var want := clampf(ui_scale, 0.9, UI_SCALE_MAX)
	if want <= 1.0:
		return want
	var win := Vector2(DisplayServer.window_get_size())
	if win.x <= 0 or win.y <= 0:
		return 1.0
	var base := minf(win.x / BASE_SIZE.x, win.y / BASE_SIZE.y)
	var need_h := 660.0 if compact else BASE_SIZE.y
	var room := win.y / (base * need_h)
	return clampf(want, 1.0, maxf(1.0, room))

## Movimento reduzido ou animações instantâneas: nada de abanões nem flashes.
func motion_ok() -> bool:
	return not reduce_motion and anim_scale() > 0.0

func scale_label() -> String:
	var txt := "%d%%" % int(round(ui_scale * 100.0))
	var eff := effective_scale()
	if absf(eff - ui_scale) > 0.01:
		txt += "  (" + tr("neste ecrã: %d%%") % int(round(eff * 100.0)) + ")"
	return txt

func cycle_scale(step: int = 1) -> void:
	var i := UI_SCALES.find(snappedf(ui_scale, 0.05))
	if i < 0:
		i = 2
	ui_scale = UI_SCALES[clampi(i + step, 0, UI_SCALES.size() - 1)]
	apply()

## Ecrã sempre ligado (só durante a batalha, se a opção estiver ligada).
## 0.19.0 (214, 215): `screen_on_wanted` diz à vigia do calor (Thermal) que a batalha o pediu.
var screen_on_wanted := false

func set_battle_screen_on(on: bool) -> void:
	screen_on_wanted = on
	if DisplayServer.get_name() == "headless":
		return
	DisplayServer.screen_set_keep_on(on and keep_screen_on)

## Cosméticos desbloqueados de um tipo ("back" / "frame"): a clássica e os ganhos.
func unlocked_cosmetics(kind: String) -> Array:
	var out: Array = []
	for c in CardDB.cosmetics.get(kind + "s", []):
		var id := String(c.get("id", ""))
		if id == "classic" or Stats.is_content_unlocked(kind, id):
			out.append(id)
	return out

## Cosmético escolhido de um tipo ("back", "frame", "mat", "effect").
func cosmetic(kind: String) -> String:
	match kind:
		"back":
			return card_back
		"frame":
			return card_frame
		"mat":
			return arena_mat
		"effect":
			return attack_fx
	return "classic"

## 0.16.1: escolhe um cosmético (separador COSMÉTICOS da Coleção). Só os desbloqueados; grava logo.
func set_cosmetic(kind: String, id: String) -> bool:
	if not (id in unlocked_cosmetics(kind)):
		return false
	match kind:
		"back":
			card_back = id
		"frame":
			card_frame = id
		"mat":
			arena_mat = id
		"effect":
			attack_fx = id
		_:
			return false
	changed.emit()
	save_settings()
	return true

func cycle_cosmetic(kind: String) -> void:
	var list := unlocked_cosmetics(kind)
	if list.is_empty():
		return
	var i := list.find(cosmetic(kind))
	var nxt := String(list[(i + 1) % list.size()])
	match kind:
		"back":
			card_back = nxt
		"frame":
			card_frame = nxt
		"mat":
			arena_mat = nxt
		"effect":
			attack_fx = nxt
	changed.emit()

# --- Exportar / importar o progresso (mudar de telemóvel sem contas) ---

const EXPORT_PREFIX := "ZS1:"

## Código com o progresso, as configurações, os baralhos do Construtor e as runs gravadas (6 espaços).
## Formato: "ZS1:" + base64(gzip(json)) + ":" + os primeiros 8 carateres do sha256 do json.
func export_code() -> String:
	var data := {
		"v": 1,
		"progress": GameState.progress,
		"settings": _settings_dict(),
		"custom_decks": CardDB.custom_decks,
		"runs": _saved_runs(),
	}
	var json := JSON.stringify(data)
	var raw := json.to_utf8_buffer()
	var packed := raw.compress(FileAccess.COMPRESSION_GZIP)
	return EXPORT_PREFIX + Marshalls.raw_to_base64(packed) + ":" + json.sha256_text().substr(0, 8)

## As runs gravadas nos 6 espaços ({"1": run, ...}), para irem no código.
func _saved_runs() -> Dictionary:
	var out := {}
	for i in range(1, GameState.SLOT_COUNT + 1):
		if GameState.has_saved_run(i):
			var parsed = JSON.parse_string(FileAccess.get_file_as_string(GameState.slot_path(i)))
			if parsed is Dictionary:
				out[str(i)] = parsed
	return out

## Lê um código. Devolve {} se não for válido; senão o dicionário com o progresso.
func parse_code(code: String) -> Dictionary:
	var c := code.strip_edges().replace("\n", "").replace(" ", "")
	if not c.begins_with(EXPORT_PREFIX):
		return {}
	var parts := c.substr(EXPORT_PREFIX.length()).split(":")
	if parts.size() != 2:
		return {}
	var packed := Marshalls.base64_to_raw(parts[0])
	if packed.is_empty():
		return {}
	var raw := packed.decompress_dynamic(8 * 1024 * 1024, FileAccess.COMPRESSION_GZIP)
	if raw.is_empty():
		return {}
	var json := raw.get_string_from_utf8()
	if json.sha256_text().substr(0, 8) != parts[1]:
		return {}
	var parsed = JSON.parse_string(json)
	if not (parsed is Dictionary) or not (parsed.get("progress") is Dictionary):
		return {}
	return parsed

## Aplica um código já validado: substitui o progresso deste telemóvel.
func import_code(code: String) -> bool:
	var d := parse_code(code)
	if d.is_empty():
		return false
	GameState.progress = d["progress"]
	GameState.load_progress_from(GameState.progress)
	GameState.save_progress()
	if d.get("settings") is Dictionary:
		_load_from(d["settings"])
		save_settings()
	if d.get("custom_decks") is Dictionary:
		CardDB.custom_decks = d["custom_decks"]
		CardDB.save_custom_decks()
	GameState.clear_all_saved_runs()
	var runs := {}
	if d.get("runs") is Dictionary:
		runs = d["runs"]
	elif d.get("run") is Dictionary:   # códigos de antes da 0.12.0: uma só run
		runs = {"1": d["run"]}
	for k in runs:
		var slot := int(k)
		if slot < 1 or slot > GameState.SLOT_COUNT or not (runs[k] is Dictionary):
			continue
		var f := FileAccess.open(GameState.slot_path(slot), FileAccess.WRITE)
		if f:
			f.store_string(JSON.stringify(runs[k]))
			f.close()
	Stats._ensure()
	apply()
	return true

## 0.19.0 (291): o ficheiro das configurações do perfil em uso.
func path() -> String:
	return Profiles.path("settings.json")

func load_settings() -> void:
	var parsed = SaveIO.read_json(path())
	if not (parsed is Dictionary):
		return
	_load_from(parsed)

## 0.19.0 (291): ao mudar de perfil — tudo volta ao normal e lê-se o ficheiro do perfil novo.
func reload_profile() -> void:
	reset_options([], false)
	card_back = "classic"
	card_frame = "classic"
	arena_mat = "classic"
	attack_fx = "classic"
	hand_sort = ""
	perf_offer_done = false
	load_settings()
	apply()

# --- 0.19.0: opções novas ---

## 0.19.0 (276): a força dos abanões (0 a 1).
func shake_scale() -> float:
	return clampf(float(opt("shake_strength")), 0.0, 1.0)

## 0.19.0 (292): modo tablet — «auto» liga-se nos ecrãs com 7 polegadas ou mais; as cartas da mão ficam maiores.
const TABLET_HAND := 1.15

func is_tablet() -> bool:
	match String(opt("tablet")):
		"on":
			return true
		"off":
			return false
	if DisplayServer.get_name() == "headless":
		return false
	var dpi := maxf(1.0, float(DisplayServer.screen_get_dpi()))
	var px := Vector2(DisplayServer.screen_get_size())
	return px.length() / dpi >= 7.0

func hand_scale_eff() -> float:
	return hand_scale * (TABLET_HAND if is_tablet() else 1.0)

## 271: silenciar num toque (o som todo; a música, os efeitos e os cliques voltam como estavam).
func is_muted() -> bool:
	return bool(opt("muted"))

## 296: o tema claro — as janelas (Configurações, Como Jogar, avisos, escolhas…) em pergaminho claro com letra
## escura, e as cartas claras. As ilustrações e os fundos ficam como estão.
func light_theme() -> bool:
	return String(opt("theme")) == "light"

func light_cards_on() -> bool:
	return bool(opt("light_cards")) or light_theme()

## 216: o tema preto — fundos pretos a sério (gastam menos nos ecrãs OLED).
func black_theme() -> bool:
	return String(opt("theme")) == "black"

## Valor de uma opção nova (ou de uma antiga, pelo nome da var).
func opt(key: String):
	if LEGACY_DEFAULTS.has(key):
		return get(key)
	return opts.get(key, OPT_DEFAULTS.get(key))

func set_opt(key: String, value, save: bool = true) -> void:
	if LEGACY_DEFAULTS.has(key):
		set(key, value)
	else:
		opts[key] = _coerce(key, value)
	if save:
		save_settings()
	changed.emit()

func opt_default(key: String):
	if LEGACY_DEFAULTS.has(key):
		return LEGACY_DEFAULTS[key]
	return OPT_DEFAULTS.get(key)

## Põe um valor no tipo da opção (o JSON traz os números como float) e confirma que é um dos permitidos.
func _coerce(key: String, value):
	var def = OPT_DEFAULTS.get(key)
	var v = value
	match typeof(def):
		TYPE_BOOL:
			v = bool(value) if (value is bool or value is int or value is float) else def
		TYPE_INT:
			v = int(value) if (value is int or value is float) else def
		TYPE_FLOAT:
			v = float(value) if (value is int or value is float) else def
		TYPE_STRING:
			v = String(value) if value is String else def
	if OPT_CHOICES.has(key):
		var choices: Array = OPT_CHOICES[key]
		var found := false
		for c in choices:
			if typeof(c) == typeof(v) and c == v or ((c is float or c is int) and (v is float or v is int) and absf(float(c) - float(v)) < 0.001):
				v = c
				found = true
				break
		if not found:
			v = def
	return v

## Roda uma opção de escolha para o valor seguinte.
func cycle_opt(key: String, step: int = 1) -> void:
	var choices: Array = OPT_CHOICES.get(key, [])
	if choices.is_empty():
		set_opt(key, not bool(opt(key)))
		return
	var i := choices.find(opt(key))
	set_opt(key, choices[(i + step + choices.size()) % choices.size()])

## 0.19.0 (290): volta às predefinições — só estas chaves, ou todas ([]).
func reset_options(keys: Array = [], save: bool = true) -> void:
	var all_keys: Array = keys if not keys.is_empty() else (OPT_DEFAULTS.keys() + LEGACY_DEFAULTS.keys())
	for k in all_keys:
		if LEGACY_DEFAULTS.has(k):
			set(k, LEGACY_DEFAULTS[k])
		elif OPT_DEFAULTS.has(k):
			opts.erase(k)
	if save:
		save_settings()
		apply()

## 0.19.0 (287): aplica uma predefinição; devolve as chaves que mudaram.
func apply_preset(id: String) -> Array:
	var changed_keys: Array = []
	var p: Dictionary = PRESETS.get(id, {})
	for k in p:
		if opt(k) != p[k]:
			changed_keys.append(k)
		set_opt(k, p[k], false)
	save_settings()
	apply()
	return changed_keys

## Um efeito de movimento pode correr? (275) — o «Reduzir movimento» desliga todos.
func fx_ok(part: String) -> bool:
	if reduce_motion or anim_scale() <= 0.0:
		return false
	return bool(opt("fx_" + part))

func _load_from(parsed: Dictionary) -> void:
	sfx_volume = clampf(float(parsed.get("sfx_volume", sfx_volume)), 0.0, 1.0)
	music_volume = clampf(float(parsed.get("music_volume", music_volume)), 0.0, 1.0)
	language = String(parsed.get("language", language))
	if not (language in LANGUAGES):
		language = "auto"
	anim_speed = String(parsed.get("anim_speed", anim_speed))
	if not (anim_speed in SPEEDS):
		anim_speed = "normal"
	vibration = bool(parsed.get("vibration", vibration))
	large_text = bool(parsed.get("large_text", large_text))
	left_handed = bool(parsed.get("left_handed", left_handed))
	colorblind = bool(parsed.get("colorblind", colorblind))
	ui_scale = clampf(float(parsed.get("ui_scale", ui_scale)), 0.9, 1.2)
	compact = bool(parsed.get("compact", compact))
	reduce_motion = bool(parsed.get("reduce_motion", reduce_motion))
	fps_cap = 30 if int(parsed.get("fps_cap", fps_cap)) == 30 else 60
	keep_screen_on = bool(parsed.get("keep_screen_on", keep_screen_on))
	warn_mana = bool(parsed.get("warn_mana", warn_mana))
	warn_rare = bool(parsed.get("warn_rare", warn_rare))
	tips_enabled = bool(parsed.get("tips_enabled", tips_enabled))
	card_back = String(parsed.get("card_back", card_back))
	card_frame = String(parsed.get("card_frame", card_frame))
	arena_mat = String(parsed.get("arena_mat", arena_mat))
	attack_fx = String(parsed.get("attack_fx", attack_fx))
	hand_sort = String(parsed.get("hand_sort", hand_sort))
	if not (hand_sort in HAND_SORTS):
		hand_sort = ""
	play_hints = bool(parsed.get("play_hints", play_hints))
	play_taps = 1 if int(parsed.get("play_taps", play_taps)) == 1 else 2
	performance_mode = bool(parsed.get("performance_mode", performance_mode))
	high_contrast = bool(parsed.get("high_contrast", high_contrast))
	show_art = bool(parsed.get("show_art", show_art))
	show_threats = bool(parsed.get("show_threats", show_threats))
	hand_scale = clampf(float(parsed.get("hand_scale", hand_scale)), 0.85, 1.3)
	one_hand = bool(parsed.get("one_hand", one_hand))
	confirm_buy = bool(parsed.get("confirm_buy", confirm_buy))
	tilt_3d = bool(parsed.get("tilt_3d", tilt_3d))
	perf_offer_done = bool(parsed.get("perf_offer_done", perf_offer_done))
	ui_scale = clampf(float(parsed.get("ui_scale", ui_scale)), 0.9, UI_SCALE_MAX)
	# 0.19.0: opções novas.
	opts.clear()
	var o = parsed.get("opts", {})
	if o is Dictionary:
		for k in o:
			if OPT_DEFAULTS.has(k):
				opts[k] = _coerce(k, o[k])

func _settings_dict() -> Dictionary:
	return {
		"sfx_volume": sfx_volume,
		"music_volume": music_volume,
		"language": language,
		"anim_speed": anim_speed,
		"vibration": vibration,
		"large_text": large_text,
		"left_handed": left_handed,
		"colorblind": colorblind,
		"ui_scale": ui_scale,
		"compact": compact,
		"reduce_motion": reduce_motion,
		"fps_cap": fps_cap,
		"keep_screen_on": keep_screen_on,
		"warn_mana": warn_mana,
		"warn_rare": warn_rare,
		"tips_enabled": tips_enabled,
		"card_back": card_back,
		"card_frame": card_frame,
		"hand_sort": hand_sort,
		"play_hints": play_hints,
		"play_taps": play_taps,
		"performance_mode": performance_mode,
		"high_contrast": high_contrast,
		"show_art": show_art,
		"arena_mat": arena_mat,
		"attack_fx": attack_fx,
		"show_threats": show_threats,
		"hand_scale": hand_scale,
		"one_hand": one_hand,
		"confirm_buy": confirm_buy,
		"tilt_3d": tilt_3d,
		"perf_offer_done": perf_offer_done,
		"opts": opts.duplicate(),
	}

## 0.13.0: tamanho das cartas da mão (Configurações → Visual): 85 % → 100 % → 115 % → 130 %.
func cycle_hand_scale() -> void:
	var i := HAND_SCALES.find(hand_scale)
	hand_scale = HAND_SCALES[(i + 1) % HAND_SCALES.size()] if i >= 0 else 1.0

func hand_scale_label() -> String:
	return "%d %%" % int(round(hand_scale * 100.0))

func save_settings() -> void:
	SaveIO.write_json(path(), _settings_dict())   # 0.19.0: atómico e no ficheiro do perfil
