extends Node
## Estatísticas, conquistas e descobertas (coleção), guardadas dentro de GameState.progress:
##   progress.stats        contadores globais (runs, vitórias, melhor ataque, …)
##   progress.achievements ids desbloqueados
##   progress.seen         {cards: {id: true}, relics: {...}, enemies: {...}} — o que já viste
##   progress.tutorial_done
## Ouve o EventBus; as conquistas (data/achievements.json) são {stat, min} verificadas a cada mudança.

const STAT_KEYS := ["runs", "wins", "best_ante", "best_attack", "total_damage", "enemies", "bosses",
	"cards_played", "channels", "turns", "wins_hard", "wins_no_channel", "wins_full_life", "wins_5star", "events"]

var achievements: Array = []       # definições (achievements.json)
var run_channels: int = 0          # canalizações nesta run (para "Mãos Limpas")
var _decks_played: Dictionary = {} # id → true (persistido em stats.decks_played)

func _ready() -> void:
	achievements = CardDB.achievements
	_ensure()
	EventBus.run_started.connect(_on_run_started)
	EventBus.battle_started.connect(_on_battle_started)
	EventBus.battle_ended.connect(_on_battle_ended)
	EventBus.turn_started.connect(func(_t): _add("turns", 1))
	EventBus.card_played.connect(func(_c): _add("cards_played", 1))
	EventBus.card_discarded.connect(func(_c): run_channels += 1; _add("channels", 1))
	EventBus.damage_dealt.connect(_on_damage)
	EventBus.relic_gained.connect(func(id): mark_seen("relics", id))
	_check_achievements.call_deferred()

# --- Estrutura ---

func _ensure() -> void:
	var p := GameState.progress
	if not (p.get("stats") is Dictionary):
		p["stats"] = {}
	for k in STAT_KEYS:
		if not p["stats"].has(k):
			p["stats"][k] = 0
	if not (p["stats"].get("decks_played") is Dictionary):
		p["stats"]["decks_played"] = {}
	if not (p.get("achievements") is Array):
		p["achievements"] = []
	if not (p.get("seen") is Dictionary):
		p["seen"] = {}
	for zone in ["cards", "relics", "enemies"]:
		if not (p["seen"].get(zone) is Dictionary):
			p["seen"][zone] = {}
	if not p.has("tutorial_done"):
		p["tutorial_done"] = false
	# Progresso de versões antigas (só registos por baralho): aproveita-o para os contadores globais.
	var legacy_best: Dictionary = p.get("best_ante", {}) if p.get("best_ante") is Dictionary else {}
	for id in legacy_best:
		if int(legacy_best[id]) > 0:
			p["stats"]["decks_played"][id] = true
			p["stats"]["best_ante"] = max(int(p["stats"]["best_ante"]), int(legacy_best[id]))
	var legacy_wins: Dictionary = p.get("wins", {}) if p.get("wins") is Dictionary else {}
	if int(p["stats"]["wins"]) == 0:
		for id in legacy_wins:
			p["stats"]["wins"] = int(p["stats"]["wins"]) + int(legacy_wins[id])
	if int(p["stats"]["runs"]) < int(p["stats"]["wins"]):
		p["stats"]["runs"] = int(p["stats"]["wins"])

func stats() -> Dictionary:
	_ensure()
	return GameState.progress["stats"]

func get_stat(key: String) -> int:
	return int(stats().get(key, 0))

func _add(key: String, amount: int) -> void:
	stats()[key] = int(stats().get(key, 0)) + amount
	_check_achievements()

func _max(key: String, value: int) -> void:
	if value > int(stats().get(key, 0)):
		stats()[key] = value
		_check_achievements()

func decks_played() -> int:
	var n := 0
	for id in (stats()["decks_played"] as Dictionary):
		if String(id).begins_with("deck"):
			n += 1
	return n

# --- Sinais ---

func _on_run_started() -> void:
	run_channels = 0
	_add("runs", 1)
	var id := String(GameState.deck_def.get("id", ""))
	if id != "":
		stats()["decks_played"][id] = true
	for e in GameState.deck:
		mark_seen("cards", String(e.get("id", "")), false)
	_check_achievements()
	GameState.save_progress()

func _on_battle_started(enemy: Dictionary) -> void:
	mark_seen("enemies", String(enemy.get("id", "")))

func _on_battle_ended(victory: bool) -> void:
	if not victory:
		return
	_add("enemies", 1)
	if GameState.current_enemy_is_boss():
		_add("bosses", 1)
	_max("best_ante", GameState.ante)
	GameState.save_progress()

func _on_damage(target: String, amount: int) -> void:
	if target != "enemy":
		return
	_add("total_damage", amount)
	_max("best_attack", amount)

## Chamado pelo GameState.record_run_end: vitória = passou o ante 8.
func on_run_end(victory: bool) -> void:
	if victory:
		_add("wins", 1)
		if GameState.difficulty == "dificil":
			_add("wins_hard", 1)
		if run_channels == 0:
			_add("wins_no_channel", 1)
		if GameState.player_hp >= GameState.player_max_hp:
			_add("wins_full_life", 1)
		if int(GameState.deck_def.get("difficulty", 0)) >= 5:
			_add("wins_5star", 1)
	_max("best_ante", GameState.ante + (1 if victory else 0))
	_check_achievements()

func on_event_seen() -> void:
	_add("events", 1)

# --- Descobertas ---

func mark_seen(zone: String, id: String, save: bool = true) -> void:
	if id == "":
		return
	var seen: Dictionary = GameState.progress["seen"][zone]
	if seen.has(id):
		return
	seen[id] = true
	if save:
		GameState.save_progress()

func is_seen(zone: String, id: String) -> bool:
	_ensure()
	return (GameState.progress["seen"][zone] as Dictionary).has(id)

func seen_count(zone: String) -> int:
	_ensure()
	return (GameState.progress["seen"][zone] as Dictionary).size()

# --- Conquistas ---

func is_unlocked(id: String) -> bool:
	_ensure()
	return id in (GameState.progress["achievements"] as Array)

func unlocked_count() -> int:
	_ensure()
	return (GameState.progress["achievements"] as Array).size()

func _check_achievements() -> void:
	_ensure()
	var list: Array = GameState.progress["achievements"]
	for a in achievements:
		var id := String(a.get("id", ""))
		if id == "" or id in list:
			continue
		var cond: Dictionary = a.get("cond", {})
		var stat := String(cond.get("stat", ""))
		var value := decks_played() if stat == "decks_played" else get_stat(stat)
		if value >= int(cond.get("min", 1)):
			list.append(id)
			GameState.save_progress()
			EventBus.achievement_unlocked.emit(id)

func tutorial_done() -> bool:
	_ensure()
	return bool(GameState.progress.get("tutorial_done", false))

func set_tutorial_done(done: bool) -> void:
	_ensure()
	GameState.progress["tutorial_done"] = done
	GameState.save_progress()
