extends Node
## Estatísticas, conquistas e descobertas (coleção), guardadas dentro de GameState.progress:
##   progress.stats        contadores globais (runs, vitórias, melhor ataque, …)
##   progress.achievements ids desbloqueados
##   progress.seen         {cards: {id: true}, relics: {...}, enemies: {...}} — o que já viste
##   progress.tutorial_done
## Ouve o EventBus; as conquistas (data/achievements.json) são {stat, min} verificadas a cada mudança.
## 0.10.0: uma conquista pode trazer "unlock": {"type": card|relic|planeswalker|back|frame, "id"} — esse
## conteúdo (marcado "locked" nos dados) só entra no jogo depois. Recompensas da História e dos
## Desafios ficam em progress.unlocks ("tipo:id").

const STAT_KEYS := ["runs", "wins", "best_ante", "best_attack", "total_damage", "enemies", "bosses",
	"cards_played", "channels", "turns", "wins_hard", "wins_no_channel", "wins_full_life", "wins_5star", "events",
	"mulligans", "transforms", "flashbacks", "pw_ultimates", "best_stake", "puzzles_solved", "draft_wins",
	"contracts_done", "boss_relics", "tribunal_spins", "bosses_no_phase2", "elites",
	"tokens_created", "chains", "tribe_bonuses", "enchantments_played", "kicks", "reactions", "nemesis_wins",
	"challenges_won", "saga_chapters", "plus_cards",
	"lessons", "talents_bought",
	"endless_milestones", "landfalls", "keywords_granted", "quick_wins", "rematches", "best_order_used", "hints_used",
	"jails_survived", "history_viewed"]

var achievements: Array = []       # definições (achievements.json)
var run_channels: int = 0          # canalizações nesta run (para "Mãos Limpas")
var _decks_played: Dictionary = {} # id → true (persistido em stats.decks_played)
var _jailed_this_battle := false   # 0.12.0: o inimigo prendeu uma criatura nesta batalha

func _ready() -> void:
	achievements = CardDB.achievements
	_ensure()
	EventBus.run_started.connect(_on_run_started)
	EventBus.battle_started.connect(_on_battle_started)
	EventBus.battle_ended.connect(_on_battle_ended)
	EventBus.turn_started.connect(func(_t): _add("turns", 1))
	EventBus.card_played.connect(_on_card_played)
	EventBus.creature_jailed.connect(func(_c): _jailed_this_battle = true)
	EventBus.card_discarded.connect(func(_c): run_channels += 1; _add("channels", 1))
	EventBus.damage_dealt.connect(_on_damage)
	EventBus.relic_gained.connect(func(id): mark_seen("relics", id))
	_check_achievements.call_deferred()

# --- Estrutura ---

func _ensure() -> void:
	var p := GameState.progress
	if not (p.get("stats") is Dictionary):
		p["stats"] = {}
	for k in STAT_KEYS:
		if not p["stats"].has(k):
			p["stats"][k] = 0
	if not (p["stats"].get("decks_played") is Dictionary):
		p["stats"]["decks_played"] = {}
	if not (p.get("achievements") is Array):
		p["achievements"] = []
	if not (p.get("seen") is Dictionary):
		p["seen"] = {}
	for zone in ["cards", "relics", "enemies", "planeswalkers"]:
		if not (p["seen"].get(zone) is Dictionary):
			p["seen"][zone] = {}
	if not p.has("tutorial_done"):
		p["tutorial_done"] = false
	if not (p.get("puzzles") is Dictionary):
		p["puzzles"] = {}
	if not (p.get("unlocks") is Dictionary):
		p["unlocks"] = {}
	# Progresso de versões antigas (só registos por baralho): aproveita-o para os contadores globais.
	var legacy_best: Dictionary = p.get("best_ante", {}) if p.get("best_ante") is Dictionary else {}
	for id in legacy_best:
		if int(legacy_best[id]) > 0:
			p["stats"]["decks_played"][id] = true
			p["stats"]["best_ante"] = max(int(p["stats"]["best_ante"]), int(legacy_best[id]))
	var legacy_wins: Dictionary = p.get("wins", {}) if p.get("wins") is Dictionary else {}
	if int(p["stats"]["wins"]) == 0:
		for id in legacy_wins:
			p["stats"]["wins"] = int(p["stats"]["wins"]) + int(legacy_wins[id])
	if int(p["stats"]["runs"]) < int(p["stats"]["wins"]):
		p["stats"]["runs"] = int(p["stats"]["wins"])

## Vezes que venceste um inimigo (Bestiário).
func defeated_count(enemy_id: String) -> int:
	var d = GameState.progress.get("defeated", {})
	return int((d as Dictionary).get(enemy_id, 0)) if d is Dictionary else 0

func stats() -> Dictionary:
	_ensure()
	return GameState.progress["stats"]

func get_stat(key: String) -> int:
	return int(stats().get(key, 0))

func _add(key: String, amount: int) -> void:
	stats()[key] = int(stats().get(key, 0)) + amount
	_check_achievements()

func _max(key: String, value: int) -> void:
	if value > int(stats().get(key, 0)):
		stats()[key] = value
		_check_achievements()

func decks_played() -> int:
	var n := 0
	for id in (stats()["decks_played"] as Dictionary):
		if String(id).begins_with("deck"):
			n += 1
	return n

# --- Sinais ---

func _on_run_started() -> void:
	run_channels = 0
	_add("runs", 1)
	var id := String(GameState.deck_def.get("id", ""))
	if id != "":
		stats()["decks_played"][id] = true
	for e in GameState.deck:
		mark_seen("cards", String(e.get("id", "")), false)
	_check_achievements()
	GameState.save_progress()

func _on_battle_started(enemy: Dictionary) -> void:
	_jailed_this_battle = false
	mark_seen("enemies", String(enemy.get("id", "")))

func _on_card_played(card) -> void:
	_add("cards_played", 1)
	GameState.log_card_play(card)

func _on_battle_ended(victory: bool) -> void:
	var jailed := _jailed_this_battle
	_jailed_this_battle = false
	if not victory or GameState.puzzle_id != "":
		return
	if jailed:
		_add("jails_survived", 1)
	# 0.12.0 Bestiário: vezes que venceste cada inimigo.
	var eid := GameState.current_enemy_id
	if eid != "":
		if not (GameState.progress.get("defeated") is Dictionary):
			GameState.progress["defeated"] = {}
		GameState.progress["defeated"][eid] = int(GameState.progress["defeated"].get(eid, 0)) + 1
	_add("enemies", 1)
	if GameState.current_enemy_is_boss():
		_add("bosses", 1)
	_max("best_ante", GameState.ante)
	GameState.save_progress()

func _on_damage(target: String, amount: int) -> void:
	if target != "enemy":
		return
	_add("total_damage", amount)
	_max("best_attack", amount)

## Chamado pelo GameState.record_run_end: vitória = passou o último ante (8; 4 no draft).
func on_run_end(victory: bool) -> void:
	if victory and GameState.mode == "draft":
		_add("draft_wins", 1)
		_check_achievements()
		return
	if GameState.mode == "saga":
		_check_achievements()
		return   # os capítulos da História (4 antes) não contam como runs vencidas
	if victory:
		_add("wins", 1)
		if not GameState.free_mode:
			_max("best_stake", GameState.stake)
		if GameState.difficulty == "dificil":
			_add("wins_hard", 1)
		if run_channels == 0:
			_add("wins_no_channel", 1)
		if GameState.player_hp >= GameState.player_max_hp:
			_add("wins_full_life", 1)
		if int(GameState.deck_def.get("difficulty", 0)) >= 5:
			_add("wins_5star", 1)
	_max("best_ante", GameState.ante + (1 if victory else 0))
	_check_achievements()

func on_event_seen() -> void:
	_add("events", 1)

func on_mulligan() -> void:
	_add("mulligans", 1)

func on_transform() -> void:
	_add("transforms", 1)

func on_flashback() -> void:
	_add("flashbacks", 1)

func on_pw_ultimate() -> void:
	_add("pw_ultimates", 1)

func on_contract_done() -> void:
	_add("contracts_done", 1)

func on_boss_relic() -> void:
	_add("boss_relics", 1)

func on_tribunal_spin() -> void:
	_add("tribunal_spins", 1)

func on_boss_no_phase2() -> void:
	_add("bosses_no_phase2", 1)

func on_elite() -> void:
	_add("elites", 1)

# --- 0.10.0 ---

func on_tokens(n: int) -> void:
	_add("tokens_created", n)

func on_chain() -> void:
	_add("chains", 1)

func on_tribe_bonus(n: int) -> void:
	_add("tribe_bonuses", n)

func on_enchantment() -> void:
	_add("enchantments_played", 1)

func on_kick() -> void:
	_add("kicks", 1)

func on_reaction() -> void:
	_add("reactions", 1)

func on_nemesis_win() -> void:
	_add("nemesis_wins", 1)

func on_plus_card() -> void:
	_add("plus_cards", 1)

## Contadores que são "quantos já fizeste" (desafios e capítulos da História): só sobem.
func set_at_least(key: String, value: int) -> void:
	_max(key, value)

## Soma a um contador (0.12.0: Chegadas de Terreno, palavras-chave dadas, dicas, melhor ordem…).
func add(key: String, amount: int = 1) -> void:
	_add(key, amount)

# --- Desbloqueios (conquistas e recompensas) ---

## Este conteúdo "locked" já está disponível? (conquista com "unlock" ou recompensa guardada)
func is_content_unlocked(kind: String, id: String) -> bool:
	_ensure()
	if (GameState.progress["unlocks"] as Dictionary).has(kind + ":" + id):
		return true
	for a in achievements:
		var u: Dictionary = a.get("unlock", {}) if a.get("unlock") is Dictionary else {}
		if String(u.get("type", "")) == kind and String(u.get("id", "")) == id and is_unlocked(String(a.get("id", ""))):
			return true
	return false

## Guarda uma recompensa (História, Desafios) como desbloqueada.
func grant_unlock(kind: String, id: String) -> bool:
	_ensure()
	var key := kind + ":" + id
	var u: Dictionary = GameState.progress["unlocks"]
	if u.has(key) or is_content_unlocked(kind, id):
		return false
	u[key] = true
	GameState.save_progress()
	EventBus.content_unlocked.emit(kind, id)
	return true

## Texto "Desbloqueia: X" de uma conquista ("" se não desbloquear nada).
static func unlock_label(u: Dictionary, template: String = "Desbloqueia %s: %s") -> String:
	if u.is_empty():
		return ""
	var kind := String(u.get("type", ""))
	var id := String(u.get("id", ""))
	var name := id
	match kind:
		"card":
			var cd := CardDB.get_card(id)
			name = cd.display_name() if cd != null else id
		"relic":
			name = TranslationServer.translate(String(CardDB.relics.get(id, {}).get("name", id)))
		"planeswalker":
			name = TranslationServer.translate(String(CardDB.get_planeswalker(id).get("name", id)))
		"back", "frame", "mat", "effect":
			name = TranslationServer.translate(String(CardDB.get_cosmetic(kind, id).get("name", id)))
	var kinds := {"card": "carta", "relic": "relíquia", "planeswalker": "planeswalker", "back": "costas de carta", "frame": "moldura",
		"mat": "tapete da Arena", "effect": "efeito do golpe"}
	return TranslationServer.translate(template) % [TranslationServer.translate(String(kinds.get(kind, kind))), name]

## Quebra-cabeças resolvido (cada um conta uma vez).
func on_puzzle_solved(id: String) -> void:
	_ensure()
	var solved: Dictionary = GameState.progress["puzzles"]
	if solved.has(id):
		return
	solved[id] = true
	_add("puzzles_solved", 1)
	GameState.save_progress()

func is_puzzle_solved(id: String) -> bool:
	_ensure()
	return (GameState.progress["puzzles"] as Dictionary).has(id)

# --- Descobertas ---

func mark_seen(zone: String, id: String, save: bool = true) -> void:
	if id == "":
		return
	var seen: Dictionary = GameState.progress["seen"][zone]
	if seen.has(id):
		return
	seen[id] = true
	if save:
		GameState.save_progress()

func is_seen(zone: String, id: String) -> bool:
	_ensure()
	return (GameState.progress["seen"][zone] as Dictionary).has(id)

func seen_count(zone: String) -> int:
	_ensure()
	return (GameState.progress["seen"][zone] as Dictionary).size()

# --- Conquistas ---

func is_unlocked(id: String) -> bool:
	_ensure()
	return id in (GameState.progress["achievements"] as Array)

func unlocked_count() -> int:
	_ensure()
	return (GameState.progress["achievements"] as Array).size()

func _check_achievements() -> void:
	_ensure()
	var list: Array = GameState.progress["achievements"]
	for a in achievements:
		var id := String(a.get("id", ""))
		if id == "" or id in list:
			continue
		var cond: Dictionary = a.get("cond", {})
		var stat := String(cond.get("stat", ""))
		var value := decks_played() if stat == "decks_played" else get_stat(stat)
		if value >= int(cond.get("min", 1)):
			list.append(id)
			GameState.save_progress()
			EventBus.achievement_unlocked.emit(id)
			var u: Dictionary = a.get("unlock", {}) if a.get("unlock") is Dictionary else {}
			if not u.is_empty():
				EventBus.content_unlocked.emit(String(u.get("type", "")), String(u.get("id", "")))

func tutorial_done() -> bool:
	_ensure()
	return bool(GameState.progress.get("tutorial_done", false))

func set_tutorial_done(done: bool) -> void:
	_ensure()
	GameState.progress["tutorial_done"] = done
	GameState.save_progress()
