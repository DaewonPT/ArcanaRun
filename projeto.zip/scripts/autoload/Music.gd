extends Node
## Música de fundo (0.12.0). As faixas são compostas e sintetizadas por código (tools/make_audio.py, sem
## samples de ninguém) e ficam em assets/audio/music_<faixa>.ogg:
##   menu     menus, Escola, enigmas e Treino
##   act1–4   uma por ato da run (dois antes cada), no mapa, na loja, nos eventos e nas batalhas
##   endless  o Infinito (ato V)
##   boss     batalhas contra bosses e Némesis
## Troca com um fundido suave quando a cena muda (EventBus.scene_changed) ou quando a batalha começa
## contra um boss. No fim da run fica em silêncio (toca o jingle de vitória ou derrota).
## O volume é o do bus "Music" (Configurações → Som).

const TRACKS := ["menu", "act1", "act2", "act3", "act4", "endless", "boss"]
const FADE_IN := 1.1
const FADE_OUT := 1.4
const SILENT_DB := -60.0
const MENU_SCENES := ["main", "stats", "collection", "builder", "howto", "puzzles", "saga", "challenges",
	"training", "school", "talents", "campaign"]

var current := ""             # faixa a tocar ("" = silêncio)
var _players: Array[AudioStreamPlayer] = []
var _active := 0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in 2:
		var p := AudioStreamPlayer.new()
		p.bus = "Music"
		p.volume_db = SILENT_DB
		add_child(p)
		_players.append(p)
	EventBus.scene_changed.connect(_on_scene_changed)
	EventBus.battle_started.connect(_on_battle_started)
	# A primeira cena (o menu) não passa pelo SceneRouter.go().
	_start_menu.call_deferred()

func _start_menu() -> void:
	if current == "":
		play("menu")

static func path_for(track: String) -> String:
	return "res://assets/audio/music_%s.ogg" % track

static func has_track(track: String) -> bool:
	return track != "" and ResourceLoader.exists(path_for(track))

## Faixa do ato do ante atual (o Infinito é o ato V).
static func act_track() -> String:
	var a := GameState.act_of_ante(GameState.ante)
	return "endless" if a >= 5 else "act%d" % clampi(a, 1, 4)

## Que faixa deve tocar numa cena (a batalha decide-se no battle_started: boss ou não).
func track_for_scene(key: String) -> String:
	if key in MENU_SCENES:
		return "menu"
	if key == "run_over":
		return ""
	if GameState.puzzle_id != "":
		return "menu"
	if key == "battle":
		return current if current in ["act1", "act2", "act3", "act4", "endless", "boss"] else act_track()
	return act_track()

func _on_scene_changed(key: String) -> void:
	play(track_for_scene(key))

func _on_battle_started(enemy: Dictionary) -> void:
	if GameState.puzzle_id != "":
		play("menu")
	elif bool(enemy.get("boss", false)) or String(enemy.get("variant", "")) == "nemesis":
		play("boss")
	else:
		play(act_track())

## Muda de faixa com fundido (a mesma faixa continua sem recomeçar).
func play(track: String) -> void:
	if track == current:
		return
	current = track
	var old := _players[_active]
	_fade(old, SILENT_DB, FADE_OUT, true)
	if not has_track(track):
		return
	_active = 1 - _active
	var p := _players[_active]
	var stream = load(path_for(track))
	if stream is AudioStreamOggVorbis:
		(stream as AudioStreamOggVorbis).loop = true
	p.stream = stream
	p.volume_db = SILENT_DB
	p.play()
	_fade(p, 0.0, FADE_IN, false)

func stop() -> void:
	play("")

func _fade(p: AudioStreamPlayer, to_db: float, seconds: float, stop_after: bool) -> void:
	if p.has_meta("fade_tw"):
		var old_tw = p.get_meta("fade_tw")
		if old_tw is Tween and (old_tw as Tween).is_valid():
			(old_tw as Tween).kill()
	if not p.playing:
		p.volume_db = to_db
		return
	var tw := create_tween()
	tw.tween_property(p, "volume_db", to_db, seconds).set_trans(Tween.TRANS_SINE)
	if stop_after:
		tw.tween_callback(p.stop)
	p.set_meta("fade_tw", tw)

## No Android, ao sair para o ecrã inicial a música para (e volta onde estava).
func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED:
		for p in _players:
			p.stream_paused = true
	elif what == NOTIFICATION_APPLICATION_RESUMED:
		for p in _players:
			p.stream_paused = false
