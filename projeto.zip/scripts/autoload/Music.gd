extends Node
## Música de fundo (0.12.0). As faixas são compostas e sintetizadas por código (tools/make_audio.py, sem
## samples de ninguém) e ficam em assets/audio/music_<faixa>.ogg:
##   menu     menus, Escola, enigmas e Treino
##   act1–4   uma por ato da run (dois antes cada), no mapa, na loja, nos eventos e nas batalhas
##   endless  o Infinito (ato V)
##   boss     batalhas contra bosses e Némesis
##   guild_*  0.13.0: tema de cada guilda nos capítulos do Livro II da História
## 0.13.0: durante o ataque entra por cima uma camada de percussão do mesmo andamento (music_drive_<bpm>),
## alinhada ao compasso, que cresce até ao fim da cascata e sai devagar.
## Troca com um fundido suave quando a cena muda (EventBus.scene_changed) ou quando a batalha começa
## contra um boss. No fim da run fica em silêncio (toca o jingle de vitória ou derrota).
## O volume é o do bus "Music" (Configurações → Som).

const TRACKS := ["menu", "act1", "act2", "act3", "act4", "endless", "boss"]
## 0.13.0: andamento de cada faixa (para a camada de ataque alinhada ao compasso) — inclui os temas das guildas.
const TRACK_BPM := {"menu": 86, "act1": 100, "act2": 108, "act3": 116, "act4": 124, "endless": 84, "boss": 138,
	"guild_azorius": 100, "guild_dimir": 84, "guild_rakdos": 138, "guild_gruul": 116, "guild_selesnya": 100,
	"guild_orzhov": 84, "guild_izzet": 124, "guild_golgari": 108, "guild_boros": 124, "guild_simic": 108}
const DRIVE_BARS := 4           # a camada de ataque tem 4 compassos
const DRIVE_START_DB := -18.0
const DRIVE_PEAK_DB := -1.5
const FADE_IN := 1.1
const FADE_OUT := 1.4
const SILENT_DB := -60.0
const MENU_SCENES := ["main", "stats", "collection", "builder", "howto", "puzzles", "saga", "challenges",
	"training", "school", "talents", "campaign"]

var current := ""             # faixa a tocar ("" = silêncio)
var _players: Array[AudioStreamPlayer] = []
var _active := 0
var _drive: AudioStreamPlayer   # 0.13.0: percussão por cima durante o ataque (a música cresce na cascata)
var _drive_tw: Tween

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in 2:
		var p := AudioStreamPlayer.new()
		p.bus = "Music"
		p.volume_db = SILENT_DB
		add_child(p)
		_players.append(p)
	_drive = AudioStreamPlayer.new()
	_drive.name = "Drive"
	_drive.bus = "Music"
	_drive.volume_db = SILENT_DB
	add_child(_drive)
	EventBus.scene_changed.connect(_on_scene_changed)
	EventBus.battle_started.connect(_on_battle_started)
	EventBus.cascade_presented.connect(_on_cascade_started)   # nunca cascade_started (ver EventBus)
	EventBus.cascade_finished.connect(_on_cascade_finished)
	# A primeira cena (o menu) não passa pelo SceneRouter.go().
	_start_menu.call_deferred()

func _start_menu() -> void:
	if current == "":
		play("menu")

static func path_for(track: String) -> String:
	return "res://assets/audio/music_%s.ogg" % track

static func has_track(track: String) -> bool:
	return track != "" and ResourceLoader.exists(path_for(track))

## Faixa do ato do ante atual (o Infinito é o ato V). 0.13.0: na História, o capítulo pode ter o seu tema
## ("music" em data/saga.json — os temas das guildas do Livro II).
static func act_track() -> String:
	if GameState.saga_id != "":
		var theme := String(CardDB.get_saga_chapter(GameState.saga_id).get("music", ""))
		if has_track(theme):
			return theme
	var a := GameState.act_of_ante(GameState.ante)
	return "endless" if a >= 5 else "act%d" % clampi(a, 1, 4)

## Que faixa deve tocar numa cena (a batalha decide-se no battle_started: boss ou não).
func track_for_scene(key: String) -> String:
	if key in MENU_SCENES:
		return "menu"
	if key == "run_over":
		return ""
	if GameState.puzzle_id != "":
		return "menu"
	if key == "battle":
		return current if (current in ["act1", "act2", "act3", "act4", "endless", "boss"] or current.begins_with("guild_")) else act_track()
	return act_track()

func _on_scene_changed(key: String) -> void:
	play(track_for_scene(key))

func _on_battle_started(enemy: Dictionary) -> void:
	if GameState.puzzle_id != "":
		play("menu")
	elif bool(enemy.get("boss", false)) or String(enemy.get("variant", "")) == "nemesis":
		play("boss")
	else:
		play(act_track())

## Muda de faixa com fundido (a mesma faixa continua sem recomeçar).
func play(track: String) -> void:
	if track == current:
		return
	current = track
	_drive_to(SILENT_DB, 0.6, true)
	var old := _players[_active]
	_fade(old, SILENT_DB, FADE_OUT, true)
	if not has_track(track):
		return
	_active = 1 - _active
	var p := _players[_active]
	var stream = load(path_for(track))
	if stream is AudioStreamOggVorbis:
		(stream as AudioStreamOggVorbis).loop = true
	p.stream = stream
	p.volume_db = SILENT_DB
	p.play()
	_fade(p, 0.0, FADE_IN, false)

func stop() -> void:
	play("")

# --- 0.13.0: a música cresce durante o ataque ---

static func drive_path(bpm: int) -> String:
	return "res://assets/audio/music_drive_%d.ogg" % bpm

## Camada de percussão do andamento da faixa atual ("" se não houver).
func drive_for_current() -> String:
	if not TRACK_BPM.has(current):
		return ""
	var path := drive_path(int(TRACK_BPM[current]))
	return path if ResourceLoader.exists(path) else ""

## A cascata começou: a percussão entra alinhada ao compasso e cresce até ao fim da contagem.
func _on_cascade_started(c: Cascade) -> void:
	var path := drive_for_current()
	var main := _players[_active]
	if path == "" or not main.playing:
		return
	var stream = load(path)
	if stream is AudioStreamOggVorbis:
		(stream as AudioStreamOggVorbis).loop = true
	var loop_len := float(DRIVE_BARS * 4) * 60.0 / float(TRACK_BPM[current])
	if _drive.stream != stream:
		_drive.stream = stream
		_drive.stop()
	if not _drive.playing:
		_drive.volume_db = DRIVE_START_DB
		_drive.play(fposmod(main.get_playback_position(), loop_len))
	var steps := c.steps.size() if c != null else 6
	_drive_to(DRIVE_PEAK_DB, clampf(float(steps) * 0.22 * maxf(0.2, Settings.anim_scale()), 0.6, 4.0), false)

func _on_cascade_finished() -> void:
	if _drive.playing:
		_drive_to(SILENT_DB, 1.6, true)

func _drive_to(db: float, seconds: float, stop_after: bool) -> void:
	if _drive == null:
		return
	if _drive_tw != null and _drive_tw.is_valid():
		_drive_tw.kill()
	if not _drive.playing:
		_drive.volume_db = db
		return
	_drive_tw = create_tween()
	_drive_tw.tween_property(_drive, "volume_db", db, seconds).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN if db > _drive.volume_db else Tween.EASE_OUT)
	if stop_after:
		_drive_tw.tween_callback(_drive.stop)

func drive_playing() -> bool:
	return _drive != null and _drive.playing

func _fade(p: AudioStreamPlayer, to_db: float, seconds: float, stop_after: bool) -> void:
	if p.has_meta("fade_tw"):
		var old_tw = p.get_meta("fade_tw")
		if old_tw is Tween and (old_tw as Tween).is_valid():
			(old_tw as Tween).kill()
	if not p.playing:
		p.volume_db = to_db
		return
	var tw := create_tween()
	tw.tween_property(p, "volume_db", to_db, seconds).set_trans(Tween.TRANS_SINE)
	if stop_after:
		tw.tween_callback(p.stop)
	p.set_meta("fade_tw", tw)

## No Android, ao sair para o ecrã inicial a música para (e volta onde estava).
func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED:
		for p in _players:
			p.stream_paused = true
		if _drive != null:
			_drive.stream_paused = true
	elif what == NOTIFICATION_APPLICATION_RESUMED:
		for p in _players:
			p.stream_paused = false
		if _drive != null:
			_drive.stream_paused = false
