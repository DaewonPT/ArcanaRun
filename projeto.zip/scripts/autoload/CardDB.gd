extends Node
## Carrega os JSON de data/ uma vez e serve definições (dados imutáveis).
## Instâncias em jogo são CardInstance (scripts/core/CardInstance.gd).

const CARDS_PATH := "res://data/cards.json"
const DECKS_PATH := "res://data/decks.json"
const RELICS_PATH := "res://data/relics.json"
const FORMATIONS_PATH := "res://data/formations.json"
const ENEMIES_PATH := "res://data/enemies.json"
const CAMPAIGN_PATH := "res://data/campaign.json"
const EVENTS_PATH := "res://data/events.json"
const ACHIEVEMENTS_PATH := "res://data/achievements.json"

var cards: Dictionary = {}       # id -> CardData
var decks: Array = []            # lista de Dictionary (decks.json), pela ordem
var relics: Dictionary = {}      # id -> Dictionary (definição crua)
var formations: Array = []       # lista de Dictionary, pela ordem do ficheiro
var enemies: Array = []          # lista de Dictionary
var campaign: Array = []         # atos da campanha (campaign.json)
var events: Array = []           # eventos entre antes (events.json)
var achievements: Array = []     # conquistas (achievements.json)
var custom_decks: Dictionary = {} # id → definição (user://custom_decks.json, Construtor)
const CUSTOM_DECKS_PATH := "user://custom_decks.json"

func _ready() -> void:
	reload()

## (Re)carrega tudo — também depois de uma atualização de conteúdo (ContentUpdate).
func reload() -> void:
	cards.clear()
	relics.clear()
	for entry in _load_json(CARDS_PATH):
		var data := CardData.from_dict(entry)
		cards[data.id] = data
	decks = _load_json(DECKS_PATH)
	for entry in _load_json(RELICS_PATH):
		relics[entry["id"]] = entry
	formations = _load_json(FORMATIONS_PATH)
	enemies = _load_json(ENEMIES_PATH)
	campaign = _load_json(CAMPAIGN_PATH)
	events = _load_json(EVENTS_PATH)
	achievements = _load_json(ACHIEVEMENTS_PATH)
	load_custom_decks()
	print("CardDB: %d cartas, %d baralhos, %d relíquias, %d formações, %d inimigos, %d atos, %d eventos (conteúdo v%d)" % [cards.size(), decks.size(), relics.size(), formations.size(), enemies.size(), campaign.size(), events.size(), ContentUpdate.installed_version()])

func _load_json(res_path: String) -> Array:
	var path := ContentUpdate.resolve(res_path)
	if not FileAccess.file_exists(path):
		push_error("CardDB: ficheiro em falta: " + path)
		return []
	var text := FileAccess.get_file_as_string(path)
	var parsed = JSON.parse_string(text)
	if parsed == null or not (parsed is Array):
		push_error("CardDB: JSON inválido em " + path)
		return []
	return parsed

func get_card(id: String) -> CardData:
	return cards.get(id)

func load_custom_decks() -> void:
	custom_decks.clear()
	if not FileAccess.file_exists(CUSTOM_DECKS_PATH):
		return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(CUSTOM_DECKS_PATH))
	if parsed is Dictionary:
		for k in parsed:
			if parsed[k] is Dictionary:
				custom_decks[String(k)] = parsed[k]

func save_custom_decks() -> void:
	var f := FileAccess.open(CUSTOM_DECKS_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(custom_decks))

func get_deck(deck_id: String) -> Dictionary:
	if custom_decks.has(deck_id):
		return custom_decks[deck_id]
	for d in decks:
		if d.get("id", "") == deck_id:
			return d
	push_error("CardDB: baralho desconhecido: " + deck_id)
	return decks[0] if not decks.is_empty() else {}

func get_formation(id: String) -> Dictionary:
	for f in formations:
		if f.get("id", "") == id:
			return f
	return {}

func new_instance(id: String, entry: Dictionary = {}) -> CardInstance:
	var data := get_card(id)
	if data == null:
		push_error("CardDB: carta desconhecida: " + id)
		return null
	return CardInstance.new(data, entry)

## Cartas que cabem num baralho com estas cores (incolores entram sempre).
func cards_for_colors(colors: Array) -> Array[CardData]:
	var out: Array[CardData] = []
	for c in cards.values():
		if c.is_land():
			continue
		var fits := true
		for col in c.colors:
			if not (col in colors):
				fits = false
				break
		if fits:
			out.append(c)
	return out

## Ofertas da loja: cartas das cores do baralho atual, sem repetir na mesma visita.
func random_shop_offers(count: int, rng: RandomNumberGenerator) -> Array[CardData]:
	var pool := cards_for_colors(GameState.deck_colors())
	# Baralhos incolores (Urza) só veem incolores; os outros também as veem.
	var out: Array[CardData] = []
	for i in count:
		if pool.is_empty():
			break
		var pick := pool[rng.randi_range(0, pool.size() - 1)]
		out.append(pick)
		pool.erase(pick)
	return out

func get_event(id: String) -> Dictionary:
	for e in events:
		if String(e.get("id", "")) == id:
			return e
	return {}

## Relíquia ao acaso para a loja, ponderada pela raridade (common 60 %, uncommon 30 %, rare 10 %).
func random_relic_offer(rng: RandomNumberGenerator, exclude: Array) -> Dictionary:
	var weights := {"common": 60.0, "uncommon": 30.0, "rare": 10.0}
	var pool: Array = relics.values().filter(func(r): return not (String(r.get("id", "")) in exclude))
	if pool.is_empty():
		return {}
	var total := 0.0
	for r in pool:
		total += float(weights.get(String(r.get("rarity", "common")), 30.0))
	var roll := rng.randf() * total
	for r in pool:
		roll -= float(weights.get(String(r.get("rarity", "common")), 30.0))
		if roll <= 0.0:
			return r
	return pool[pool.size() - 1]

## Carta ao acaso das cores do baralho, opcionalmente só de uma raridade.
func random_card_for_deck(rng: RandomNumberGenerator, rarity: String = "") -> CardData:
	var pool := cards_for_colors(GameState.deck_colors())
	if rarity != "":
		var filtered := pool.filter(func(c): return c.rarity == rarity)
		if not filtered.is_empty():
			pool = filtered
	if pool.is_empty():
		return null
	return pool[rng.randi_range(0, pool.size() - 1)]

func chapter_for_deck(deck_id: String) -> Dictionary:
	for act in campaign:
		for ch in act.get("chapters", []):
			if String(ch.get("deck_id", "")) == deck_id:
				return ch
	return {}
