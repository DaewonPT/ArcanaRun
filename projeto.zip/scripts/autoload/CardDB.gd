extends Node
## Carrega os JSON de data/ uma vez e serve definições (dados imutáveis).
## Instâncias em jogo são CardInstance (scripts/core/CardInstance.gd).

const CARDS_PATH := "res://data/cards.json"
const DECKS_PATH := "res://data/decks.json"
const RELICS_PATH := "res://data/relics.json"
const FORMATIONS_PATH := "res://data/formations.json"
const ENEMIES_PATH := "res://data/enemies.json"
const CAMPAIGN_PATH := "res://data/campaign.json"
const EVENTS_PATH := "res://data/events.json"
const ACHIEVEMENTS_PATH := "res://data/achievements.json"
const SEALS_PATH := "res://data/seals.json"
const PLANESWALKERS_PATH := "res://data/planeswalkers.json"
const PUZZLES_PATH := "res://data/puzzles.json"
const CLIMATES_PATH := "res://data/climates.json"
const CONTRACTS_PATH := "res://data/contracts.json"
const ACTS_PATH := "res://data/acts.json"
# 0.10.0
const TRIBES_PATH := "res://data/tribes.json"
const VOUCHERS_PATH := "res://data/vouchers.json"
const CHALLENGES_PATH := "res://data/challenges.json"
const NEMESIS_PATH := "res://data/nemesis.json"
const SAGA_PATH := "res://data/saga.json"
const COSMETICS_PATH := "res://data/cosmetics.json"
const GLOSSARY_PATH := "res://data/glossary.json"
const NEWS_PATH := "res://data/news.json"
## Peso de cada raridade nas ofertas da loja (as Míticas são raras de ver).
const SHOP_WEIGHTS := {"common": 1.0, "uncommon": 1.0, "rare": 1.0, "mythic": 0.2}

var cards: Dictionary = {}       # id -> CardData
var decks: Array = []            # lista de Dictionary (decks.json), pela ordem
var relics: Dictionary = {}      # id -> Dictionary (definição crua)
var formations: Array = []       # lista de Dictionary, pela ordem do ficheiro
var enemies: Array = []          # lista de Dictionary
var campaign: Array = []         # atos da campanha (campaign.json)
var events: Array = []           # eventos entre antes (events.json)
var achievements: Array = []     # conquistas (achievements.json)
var seals: Array = []            # selos de guilda (seals.json)
var planeswalkers: Array = []    # planeswalkers (planeswalkers.json)
var puzzles: Array = []          # quebra-cabeças (puzzles.json)
var climates: Array = []         # climas planares (climates.json)
var contracts: Array = []        # contratos (contracts.json)
var acts: Array = []             # interlúdios dos atos (acts.json)
var tribes: Array = []           # bónus de tribo por escalão (tribes.json)
var vouchers: Array = []         # Vales da loja (vouchers.json)
var challenges: Array = []       # Desafios fixos (challenges.json)
var nemeses: Array = []          # rivais Némesis (nemesis.json)
var saga: Array = []             # capítulos da História (saga.json)
var cosmetics: Dictionary = {}   # {"backs": [...], "frames": [...]} (cosmetics.json)
var glossary: Array = []         # termos sublinhados nas cartas (glossary.json)
var news: Array = []             # notas "Novidades" por versão (news.json)
var custom_decks: Dictionary = {} # id → definição (user://custom_decks.json, Construtor)
const CUSTOM_DECKS_PATH := "user://custom_decks.json"

func _ready() -> void:
	reload()

## (Re)carrega tudo — também depois de uma atualização de conteúdo (ContentUpdate).
func reload() -> void:
	cards.clear()
	relics.clear()
	for entry in _load_json(CARDS_PATH):
		var data := CardData.from_dict(entry)
		cards[data.id] = data
	decks = _load_json(DECKS_PATH)
	for entry in _load_json(RELICS_PATH):
		relics[entry["id"]] = entry
	formations = _load_json(FORMATIONS_PATH)
	enemies = _load_json(ENEMIES_PATH)
	campaign = _load_json(CAMPAIGN_PATH)
	events = _load_json(EVENTS_PATH)
	achievements = _load_json(ACHIEVEMENTS_PATH)
	seals = _load_json(SEALS_PATH)
	planeswalkers = _load_json(PLANESWALKERS_PATH)
	puzzles = _load_json(PUZZLES_PATH)
	climates = _load_json(CLIMATES_PATH)
	contracts = _load_json(CONTRACTS_PATH)
	acts = _load_json(ACTS_PATH)
	tribes = _load_json(TRIBES_PATH)
	vouchers = _load_json(VOUCHERS_PATH)
	challenges = _load_json(CHALLENGES_PATH)
	nemeses = _load_json(NEMESIS_PATH)
	saga = _load_json(SAGA_PATH)
	var cos := _load_json(COSMETICS_PATH)
	cosmetics = cos[0] if not cos.is_empty() and cos[0] is Dictionary else {}
	glossary = _load_json(GLOSSARY_PATH)
	news = _load_json(NEWS_PATH)
	load_custom_decks()
	print("CardDB: %d cartas, %d baralhos, %d relíquias, %d formações, %d inimigos, %d livros, %d eventos, %d selos, %d planeswalkers, %d puzzles (conteúdo v%d)" % [cards.size(), decks.size(), relics.size(), formations.size(), enemies.size(), campaign.size(), events.size(), seals.size(), planeswalkers.size(), puzzles.size(), ContentUpdate.installed_version()])

func _load_json(res_path: String) -> Array:
	var path := ContentUpdate.resolve(res_path)
	if not FileAccess.file_exists(path):
		push_error("CardDB: ficheiro em falta: " + path)
		return []
	var text := FileAccess.get_file_as_string(path)
	var parsed = JSON.parse_string(text)
	if parsed == null or not (parsed is Array):
		push_error("CardDB: JSON inválido em " + path)
		return []
	return parsed

func get_card(id: String) -> CardData:
	return cards.get(id)

func load_custom_decks() -> void:
	custom_decks.clear()
	if not FileAccess.file_exists(CUSTOM_DECKS_PATH):
		return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(CUSTOM_DECKS_PATH))
	if parsed is Dictionary:
		for k in parsed:
			if parsed[k] is Dictionary:
				custom_decks[String(k)] = parsed[k]

func save_custom_decks() -> void:
	var f := FileAccess.open(CUSTOM_DECKS_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(custom_decks))

func get_deck(deck_id: String) -> Dictionary:
	if custom_decks.has(deck_id):
		return custom_decks[deck_id]
	for d in decks:
		if d.get("id", "") == deck_id:
			return d
	push_error("CardDB: baralho desconhecido: " + deck_id)
	return decks[0] if not decks.is_empty() else {}

func get_formation(id: String) -> Dictionary:
	for f in formations:
		if f.get("id", "") == id:
			return f
	return {}

func new_instance(id: String, entry: Dictionary = {}) -> CardInstance:
	var data := get_card(id)
	if data == null:
		push_error("CardDB: carta desconhecida: " + id)
		return null
	return CardInstance.new(data.with_entry(entry), entry)

func get_seal(id: String) -> Dictionary:
	for s in seals:
		if String(s.get("id", "")) == id:
			return s
	return {}

func get_planeswalker(id: String) -> Dictionary:
	for p in planeswalkers:
		if String(p.get("id", "")) == id:
			return p
	return {}

func get_climate(id: String) -> Dictionary:
	for c in climates:
		if String(c.get("id", "")) == id:
			return c
	return {}

## Interlúdio de um ato: chave "1".."4" ou "E" (infinito).
func get_act(key: String) -> Dictionary:
	for a in acts:
		if String(a.get("key", "")) == key:
			return a
	return {}

func get_contract(id: String) -> Dictionary:
	for c in contracts:
		if String(c.get("id", "")) == id:
			return c
	return {}

func get_puzzle(id: String) -> Dictionary:
	for p in puzzles:
		if String(p.get("id", "")) == id:
			return p
	return {}

## Relíquias lendárias (só no Mercador Cego) que ainda não tenhas.
func legendary_relics(exclude: Array) -> Array:
	return relics.values().filter(func(r): return bool(r.get("legendary", false)) and not (String(r.get("id", "")) in exclude))

## A carta pode sair nos sorteios? (não é Ficha, e se for "locked" já foi desbloqueada)
func is_available(c: CardData) -> bool:
	if c == null or c.token:
		return false
	return not c.locked or Stats.is_content_unlocked("card", c.id)

func is_relic_available(r: Dictionary) -> bool:
	return not bool(r.get("locked", false)) or Stats.is_content_unlocked("relic", String(r.get("id", "")))

func is_planeswalker_available(p: Dictionary) -> bool:
	return not bool(p.get("locked", false)) or Stats.is_content_unlocked("planeswalker", String(p.get("id", "")))

## Cartas "a sério" (sem Fichas) — Coleção, Construtor, Draft.
func collectible_cards() -> Array:
	return cards.values().filter(func(c: CardData): return not c.token)

## Cartas que cabem num baralho com estas cores (incolores entram sempre).
func cards_for_colors(colors: Array) -> Array[CardData]:
	var out: Array[CardData] = []
	for c in cards.values():
		if c.is_land() or c.is_curse() or not is_available(c):
			continue
		var fits := true
		for col in c.colors:
			if not (col in colors):
				fits = false
				break
		if fits:
			out.append(c)
	return out

## Ofertas da loja: cartas das cores do baralho atual, sem repetir na mesma visita.
func random_shop_offers(count: int, rng: RandomNumberGenerator) -> Array[CardData]:
	var pool := shop_pool()
	# Baralhos incolores (Urza) só veem incolores; os outros também as veem.
	var out: Array[CardData] = []
	for i in count:
		if pool.is_empty():
			break
		var pick := _weighted_pick(pool, rng)
		out.append(pick)
		pool.erase(pick)
	return out

## Cartas que a loja e as recompensas podem oferecer nesta run (cores do baralho; regras do Desafio).
func shop_pool() -> Array[CardData]:
	var pool := cards_for_colors(GameState.deck_colors())
	var cmax := int(GameState.run_rule("cost_max", 99))
	if cmax < 99:
		var cheap: Array[CardData] = []
		for c in pool:
			if c.cost <= cmax:
				cheap.append(c)
		pool = cheap
	return pool

func _weighted_pick(pool: Array[CardData], rng: RandomNumberGenerator) -> CardData:
	var total := 0.0
	for c in pool:
		total += float(SHOP_WEIGHTS.get(c.rarity, 1.0))
	var roll := rng.randf() * total
	for c in pool:
		roll -= float(SHOP_WEIGHTS.get(c.rarity, 1.0))
		if roll <= 0.0:
			return c
	return pool[pool.size() - 1]

func get_event(id: String) -> Dictionary:
	for e in events:
		if String(e.get("id", "")) == id:
			return e
	return {}

## Relíquia ao acaso para a loja, ponderada pela raridade (common 60 %, uncommon 30 %, rare 10 %).
func random_relic_offer(rng: RandomNumberGenerator, exclude: Array) -> Dictionary:
	var weights := {"common": 60.0, "uncommon": 30.0, "rare": 10.0}
	var pool: Array = relics.values().filter(func(r): return not (String(r.get("id", "")) in exclude) and not bool(r.get("legendary", false)) and not bool(r.get("boss", false)) and is_relic_available(r))
	if pool.is_empty():
		return {}
	var total := 0.0
	for r in pool:
		total += float(weights.get(String(r.get("rarity", "common")), 30.0))
	var roll := rng.randf() * total
	for r in pool:
		roll -= float(weights.get(String(r.get("rarity", "common")), 30.0))
		if roll <= 0.0:
			return r
	return pool[pool.size() - 1]

## Carta ao acaso das cores do baralho, opcionalmente só de uma raridade.
func random_card_for_deck(rng: RandomNumberGenerator, rarity: String = "") -> CardData:
	var pool := shop_pool()
	if rarity != "":
		var filtered := pool.filter(func(c): return c.rarity == rarity)
		if not filtered.is_empty():
			pool = filtered
	if pool.is_empty():
		return null
	return pool[rng.randi_range(0, pool.size() - 1)]

func chapter_for_deck(deck_id: String) -> Dictionary:
	for act in campaign:
		for ch in act.get("chapters", []):
			if String(ch.get("deck_id", "")) == deck_id:
				return ch
	return {}

# ---------------------------------------------------------------------------
# 0.10.0
# ---------------------------------------------------------------------------

func get_tribe(id: String) -> Dictionary:
	for t in tribes:
		if String(t.get("id", "")) == id:
			return t
	return {}

func get_voucher(id: String) -> Dictionary:
	for v in vouchers:
		if String(v.get("id", "")) == id:
			return v
	return {}

func get_challenge(id: String) -> Dictionary:
	for c in challenges:
		if String(c.get("id", "")) == id:
			return c
	return {}

func get_nemesis(id: String) -> Dictionary:
	for n in nemeses:
		if String(n.get("id", "")) == id:
			return n
	return {}

func get_saga_chapter(id: String) -> Dictionary:
	for ch in saga:
		if String(ch.get("id", "")) == id:
			return ch
	return {}

## Cosmético: kind "back" ou "frame".
func get_cosmetic(kind: String, id: String) -> Dictionary:
	for c in cosmetics.get(kind + "s", []):
		if String(c.get("id", "")) == id:
			return c
	return {}

func enemy_def(id: String) -> Dictionary:
	for e in enemies:
		if String(e.get("id", "")) == id:
			return e
	return {}

## Porque é que esta carta combina com o baralho da run ("" se não houver razão forte).
## Mostrado como um ícone de corrente na loja e no draft.
func synergy_reason(card: CardData, deck_ids: Array = []) -> String:
	if card == null or card.is_land() or card.is_curse():
		return ""
	var ids: Array = deck_ids if not deck_ids.is_empty() else GameState.deck_ids()
	var same_tribe := 0
	var same_cost := 0
	var spells := 0
	var spell_payoffs := 0
	var token_makers := 0
	var token_payoffs := 0
	var graveyard_payoffs := 0
	for id in ids:
		var d := get_card(String(id))
		if d == null:
			continue
		if card.tribe != "" and d.tribe == card.tribe:
			same_tribe += 1
		if not d.is_land() and d.cost == card.cost:
			same_cost += 1
		if d.is_spell():
			spells += 1
		for e in d.effects:
			var per := String(e.get("per", ""))
			if per == "spell":
				spell_payoffs += 1
			elif per == "tokens" or (e.get("filter", {}) as Dictionary).has("token"):
				token_payoffs += 1
			elif per == "graveyard":
				graveyard_payoffs += 1
			if String(e.get("action", "")) == "create_token":
				token_makers += 1
	if card.tribe != "" and same_tribe >= 2:
		return TranslationServer.translate("Tribo: %s (%d no baralho)") % [TranslationServer.translate(String(get_tribe(card.tribe).get("name", card.tribe))), same_tribe]
	var makes_tokens := false
	var pays_tokens := false
	var pays_spells := false
	var pays_graveyard := false
	for e in card.effects + (card.kicker.get("effects", []) as Array):
		var per := String(e.get("per", ""))
		if String(e.get("action", "")) == "create_token":
			makes_tokens = true
		if per == "tokens" or (e.get("filter", {}) as Dictionary).has("token"):
			pays_tokens = true
		if per == "spell":
			pays_spells = true
		if per == "graveyard":
			pays_graveyard = true
	if (makes_tokens and token_payoffs > 0) or (pays_tokens and token_makers > 0):
		return TranslationServer.translate("Fichas")
	if pays_spells and spells >= 6:
		return TranslationServer.translate("Feitiços (%d no baralho)") % spells
	if card.is_spell() and spell_payoffs >= 2:
		return TranslationServer.translate("Feitiços")
	if pays_graveyard and graveyard_payoffs >= 2:
		return TranslationServer.translate("Cemitério")
	if card.is_creature() and same_cost >= 3:
		return TranslationServer.translate("Custo %d (pactos)") % card.cost
	return ""
