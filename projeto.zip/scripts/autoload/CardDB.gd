extends Node
## Carrega cards.json e relics.json uma vez e serve definições (dados imutáveis).
## Instâncias em jogo são CardInstance (scripts/core/CardInstance.gd).

const CARDS_PATH := "res://data/cards.json"
const RELICS_PATH := "res://data/relics.json"

var cards: Dictionary = {}    # id -> CardData
var relics: Dictionary = {}   # id -> Dictionary (definição crua, por agora)

func _ready() -> void:
	_load_cards()
	_load_relics()
	print("CardDB: %d cartas, %d relíquias" % [cards.size(), relics.size()])

func _load_cards() -> void:
	var raw: Array = _load_json(CARDS_PATH)
	for entry in raw:
		var data := CardData.from_dict(entry)
		cards[data.id] = data

func _load_relics() -> void:
	var raw: Array = _load_json(RELICS_PATH)
	for entry in raw:
		relics[entry["id"]] = entry

func _load_json(path: String) -> Array:
	if not FileAccess.file_exists(path):
		push_error("CardDB: ficheiro em falta: " + path)
		return []
	var text := FileAccess.get_file_as_string(path)
	var parsed = JSON.parse_string(text)
	if parsed == null or not (parsed is Array):
		push_error("CardDB: JSON inválido em " + path)
		return []
	return parsed

func get_card(id: String) -> CardData:
	return cards.get(id)

func new_instance(id: String) -> CardInstance:
	var data := get_card(id)
	if data == null:
		push_error("CardDB: carta desconhecida: " + id)
		return null
	return CardInstance.new(data)

func cards_by_color(color: String) -> Array[CardData]:
	var out: Array[CardData] = []
	for c in cards.values():
		if c.color == color:
			out.append(c)
	return out

func random_shop_offers(count: int, rng: RandomNumberGenerator) -> Array[CardData]:
	var pool: Array = cards.values().filter(func(c): return c.type != "land" and c.rarity != "starter")
	var out: Array[CardData] = []
	for i in count:
		if pool.is_empty():
			break
		out.append(pool[rng.randi_range(0, pool.size() - 1)])
	return out
