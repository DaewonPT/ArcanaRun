extends Node
## Troca de cenas num único sítio, com uma carta a virar no meio do ecrã (0.10.0; com "reduzir
## movimento" volta ao fundido a preto simples).
## Também guarda os "overlays" (pausa, configurações, carta em grande, grimório): painéis que
## ficam por cima da cena atual numa CanvasLayer própria, sem a destruir.

const SCENES := {
	"main": "res://scenes/main/Main.tscn",
	"campaign": "res://scenes/campaign/Campaign.tscn",
	"howto": "res://scenes/ui/HowToPlay.tscn",
	"battle": "res://scenes/battle/Battle.tscn",
	"shop": "res://scenes/shop/Shop.tscn",
	"event": "res://scenes/event/Event.tscn",
	"run_over": "res://scenes/ui/RunOver.tscn",
	"stats": "res://scenes/ui/StatsScreen.tscn",
	"collection": "res://scenes/ui/Collection.tscn",
	"builder": "res://scenes/builder/DeckBuilder.tscn",
	"map": "res://scenes/map/Map.tscn",
	"draft": "res://scenes/draft/Draft.tscn",
	"puzzles": "res://scenes/puzzles/Puzzles.tscn",
	"loot": "res://scenes/loot/Loot.tscn",
	"saga": "res://scenes/saga/Saga.tscn",
	"challenges": "res://scenes/challenges/Challenges.tscn",
	"training": "res://scenes/training/Training.tscn",
	"school": "res://scenes/school/School.tscn",
	"talents": "res://scenes/talents/Talents.tscn",
	"tower": "res://scenes/tower/Tower.tscn",   # 0.17.0: Torre do Arquimago e Corrida de Bosses (entre batalhas)
}
const FLIP_CARD := Vector2(220, 316)
## As cenas de dentro de uma run (a troca de ecrã para elas usa as costas do baralho).
const RUN_SCENES := ["battle", "map", "shop", "event", "loot", "run_over", "tower"]
const FADE := 0.22

var overlay_layer: CanvasLayer
var _layer: CanvasLayer
var _fade: ColorRect
var _busy := false
var _tilt := Vector2.ZERO
var _hitstop_id := 0

func _ready() -> void:
	overlay_layer = CanvasLayer.new()
	overlay_layer.layer = 50
	add_child(overlay_layer)
	_layer = CanvasLayer.new()
	_layer.layer = 100
	add_child(_layer)
	_fade = ColorRect.new()
	_fade.color = Color(0.03, 0.02, 0.05, 1)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	_fade.modulate.a = 0.0
	_layer.add_child(_fade)
	EventBus.achievement_unlocked.connect(_on_achievement)
	EventBus.content_unlocked.connect(_on_content_unlocked)
	EventBus.run_saved.connect(_on_run_saved)
	get_tree().node_added.connect(_on_node_added)
	_make_clock()   # 0.19.0 (140)
	thermal = Thermal.new()   # 0.19.0 (secção 7): FPS da sessão, calor, ecrã parado
	add_child(thermal)
	Storage.session_start()   # 0.19.0 (230): o cadeado da sessão (fica se o jogo se fechar de repente)
	_make_spinner()           # 0.19.0 (247)
	refresh_dev_overlay.call_deferred()   # 0.19.0 (250)
	refresh_cvd.call_deferred()           # 0.19.0 (262)
	Settings.changed.connect(func(): refresh_cvd())

## Listas com scroll no telemóvel: um painel, botão ou carta com MOUSE_FILTER_STOP "agarra" o dedo e a
## lista não desliza (no telemóvel o ScrollContainer só desliza se o arrastar lhe chegar). Tudo o que entra
## dentro de um ScrollContainer passa a MOUSE_FILTER_PASS: o toque chega ao botão/carta e o arrastar chega
## à lista, que avisa os filhos (NOTIFICATION_SCROLL_BEGIN) para cancelarem o toque. Ficam de fora os
## campos de texto, barras e cursores, as relíquias, e as listas marcadas com a meta "keep_child_input"
## (a Arena da batalha, onde arrastar uma criatura muda a ordem).
func _on_node_added(n: Node) -> void:
	if n is BaseButton and not n.has_meta("no_press_fx"):
		_hook_press_fx(n as BaseButton)
	if n is BaseButton:
		if int(Settings.opt("buttons_big")) > 0:
			_enlarge_button.call_deferred(n)   # 0.19.0 (26): depois de quem o criou lhe dar o tamanho
		if pad_mode:
			_make_focusable.call_deferred(n)   # 0.19.0 (17, 20)
	elif n is ScrollContainer and not DisplayServer.is_touchscreen_available():
		ScrollFling.attach.call_deferred(n)   # 0.19.0 (21): com rato, arrastar a lista e ela continua a deslizar
	if n is Control and n.get_parent() == get_tree().root:
		_apply_safe_area.call_deferred(n)    # 0.19.0 (28): a cena nova fora dos entalhes do ecrã
		if not (String(n.name) in HOLD_SCENE_NAMES):
			release_held_notices.call_deferred()   # 0.20.0 (C11): o ecrã seguinte mostra os avisos retidos
	if (n is Label or n is RichTextLabel) and Settings.light_theme():
		_light_text.call_deferred(n)         # 0.19.0 (296): letra escura no pergaminho do tema claro
	if (n is Label or n is Button or n is RichTextLabel) and Settings.menu_text_scale() > 1.001:
		_menu_text.call_deferred(n)          # 0.19.0 (136): o texto das janelas e das listas maior
	if not (n is Control) or (n as Control).mouse_filter != Control.MOUSE_FILTER_STOP:
		return
	if n is ScrollContainer or n is LineEdit or n is TextEdit or n is Range or n is RelicView:
		return
	var p := n.get_parent()
	var depth := 0
	while p != null and depth < 14:
		if p is ScrollContainer:
			if not p.has_meta("keep_child_input"):
				(n as Control).mouse_filter = Control.MOUSE_FILTER_PASS
			return
		p = p.get_parent()
		depth += 1

## 0.16.0 (V60): os botões encolhem um pouco ao toque e voltam com um ressalto; os marcados com a meta "haptic"
## (os mais importantes da loja, do mapa e dos menus) vibram um instante. Sem movimento reduzido.
func _hook_press_fx(b: BaseButton) -> void:
	if b.button_down.is_connected(_on_btn_down):
		return
	b.button_down.connect(_on_btn_down.bind(b))
	b.button_up.connect(_on_btn_up.bind(b))

func _on_btn_down(b: BaseButton) -> void:
	if not is_instance_valid(b) or b.disabled:
		return
	if b.has_meta("haptic"):
		Settings.vibrate(14)
	if not Settings.motion_ok() or b.size.x > 700.0:
		return
	_kill_press(b)
	b.pivot_offset = b.size / 2.0
	var tw := b.create_tween()
	tw.tween_property(b, "scale", Vector2(0.94, 0.94), 0.06).set_ease(Tween.EASE_OUT)
	b.set_meta("press_tw", tw)

func _on_btn_up(b: BaseButton) -> void:
	if not is_instance_valid(b) or not b.is_inside_tree():
		return
	if b.scale.is_equal_approx(Vector2.ONE) and not b.has_meta("press_tw"):
		return
	_kill_press(b)
	b.pivot_offset = b.size / 2.0
	var tw := b.create_tween()
	tw.tween_property(b, "scale", Vector2.ONE, 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tw.tween_callback(func(): if is_instance_valid(b): b.remove_meta("press_tw"))
	b.set_meta("press_tw", tw)

func _kill_press(b: BaseButton) -> void:
	var old = b.get_meta("press_tw") if b.has_meta("press_tw") else null
	if old is Tween and (old as Tween).is_valid():
		(old as Tween).kill()

## Inclinação do telemóvel suavizada (−1 a 1 em cada eixo; zero sem acelerómetro). 0.13.0: a carta em grande usa-a.
func tilt() -> Vector2:
	return _tilt

# --- 0.19.0 (secção 7): gestão térmica ---
const SAVER_FPS := 20
const REST_AFTER := 60.0
var thermal: Thermal
var app_focused := true
var _last_touch := 0.0
var _scene_key := ""
var _resting := false

func scene_key() -> String:
	return _scene_key

## Segundos desde o último toque (ou tecla).
func idle_secs() -> float:
	return Time.get_ticks_msec() / 1000.0 - maxf(_last_touch, _awake_until - IDLE_AFTER)

## 207: fora da batalha, ao fim de 1 minuto sem toques, o que só enfeita para.
func resting() -> bool:
	return DisplayServer.get_name() != "headless" and _scene_key != "battle" and idle_secs() > REST_AFTER

## 208, 224: a decoração (fundos, runas, faíscas, brilhos) fica parada — com uma janela aberta, sem foco ou a descansar.
func decor_still() -> bool:
	return has_overlay() or not app_focused or resting()

## 203: o acelerómetro só se lê com o brilho 3D ligado e alguma carta holográfica à vista (ou a carta em grande).
func tilt_needed() -> bool:
	return Settings.tilt_3d and app_focused and (CardView.foil_live > 0 or has_overlay())

## 207: o menu a descansar redesenha só quando algo muda (como os ecrãs sem animação).
func _rest_tick() -> void:
	var r := resting()
	if r == _resting:
		return
	_resting = r
	if DisplayServer.get_name() != "headless":
		OS.low_processor_usage_mode = r or _scene_key in LOW_POWER_SCENES

# --- 0.16.0: desempenho ---
## 72: FPS conforme o momento — nas cenas de jogo (batalha, mapa, loja, eventos) fica a 60 enquanto há toques,
## animações ou arrastos; parado à espera da jogada (1,5 s sem nada) desce para 30. As cenas pedem 60 com
## keep_awake() enquanto animam. Com o limite de 30 FPS (Configurações) ou o modo de desempenho fica sempre a 30.
const IDLE_FPS := 30
const IDLE_AFTER := 1.5
const IDLE_SCENES := ["battle", "map", "shop", "event"]
## 73: os ecrãs sem animação só redesenham quando algo muda (como o editor do Godot).
## 0.16.1 (V57): também os Talentos; o fundo do menu nestes ecrãs só se mexe logo a seguir a um toque.
const LOW_POWER_SCENES := ["collection", "stats", "builder", "talents"]
var _awake_until := 0.0
var _idle_fps_on := false
## Este ecrã está em baixo consumo (LOW_POWER_SCENES): as animações decorativas param sem toques.
var low_power := false

func keep_awake(seconds: float = IDLE_AFTER) -> void:
	_awake_until = maxf(_awake_until, Time.get_ticks_msec() / 1000.0 + seconds)

## 0.16.1 (V57): tocaram no ecrã há pouco (os fundos sossegados só se mexem nesses segundos).
func is_awake() -> bool:
	return Time.get_ticks_msec() / 1000.0 <= _awake_until

# 0.16.1: o «retroceder» do Android fecha só a janela de cima. Antes, a janela fechava-se e, no mesmo
# instante, o ecrã por baixo (que só via "nenhuma janela aberta") também reagia — saía da Coleção, por
# exemplo. O SceneRouter recebe o aviso antes das janelas e do ecrã: se havia uma janela aberta, até ao
# fim deste frame has_overlay() continua a dizer que sim.
var _back_frame := -1

func _exit_tree() -> void:
	Storage.lock(false)   # 0.19.0 (230): fechou-se como deve ser

func _notification(what: int) -> void:
	# 0.19.0 (230): em segundo plano o Android pode fechar a app sem aviso — isso não é um erro.
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		Storage.lock(false)
	elif what == NOTIFICATION_APPLICATION_RESUMED:
		Storage.lock(true)
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT:   # 0.19.0 (224): ecrã dividido / outra app à frente
		app_focused = false
	elif what == NOTIFICATION_APPLICATION_FOCUS_IN:
		app_focused = true
		keep_awake()
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_last_back_ms = Time.get_ticks_msec()
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and overlay_layer != null and _open_overlays() > 0:
		_back_frame = Engine.get_process_frames()

func _open_overlays() -> int:
	var n := 0
	for c in overlay_layer.get_children():
		if not c.is_queued_for_deletion() and not c.has_meta("closing"):
			n += 1
	return n

func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton or event is InputEventScreenTouch or event is InputEventScreenDrag \
			or (event is InputEventMouseMotion and (event as InputEventMouseMotion).button_mask != 0) or event is InputEventKey or event is InputEventJoypadButton:
		keep_awake()
		_last_touch = Time.get_ticks_msec() / 1000.0
		_touch_ring(event)   # 0.19.0 (285)
		if thermal != null and thermal.wake():   # 0.19.0 (214): o 1.º toque só acende o ecrã escurecido
			get_viewport().set_input_as_handled()
			return
	if _palm_filter(event):
		get_viewport().set_input_as_handled()
		return
	if event is InputEventMouseMotion and event.device != InputEvent.DEVICE_ID_EMULATION and event.device != SYNTH_DEVICE:
		real_mouse = true
	if _explain_input(event):   # 0.19.0 (143, 144)
		get_viewport().set_input_as_handled()
		return
	if _reader_input(event):   # 0.19.0 (256)
		get_viewport().set_input_as_handled()
		return
	if event is InputEventKey and event.pressed and not event.echo and (event as InputEventKey).keycode == KEY_F1:
		open_help()   # 0.19.0 (145)
	_pad_input(event)

## O limite de FPS que se quer agora (0 = sem limite).
## 0.19.0 (219): com a poupança extra, 20 FPS fora da batalha; (224) sem foco, no máximo 30.
func wanted_fps() -> int:
	var base := 30 if Settings.performance_mode else (Settings.fps_cap if Settings.fps_cap > 0 else 0)
	if saver_applies(_scene_key) and DisplayServer.get_name() != "headless":
		return SAVER_FPS
	if not app_focused and (base == 0 or base > 30):
		base = 30
	if base == 30 or not _idle_fps_on or DisplayServer.get_name() == "headless":
		return base
	return IDLE_FPS if Time.get_ticks_msec() / 1000.0 > _awake_until else base

## 219: a poupança extra vale fora da batalha.
func saver_applies(key: String) -> bool:
	return bool(Settings.opt("saver_extra")) and key != "battle"

func _apply_scene_power(scene_key: String) -> void:
	_scene_key = scene_key
	_idle_fps_on = scene_key in IDLE_SCENES
	low_power = scene_key in LOW_POWER_SCENES
	keep_awake(2.0)
	OS.low_processor_usage_mode = scene_key in LOW_POWER_SCENES and DisplayServer.get_name() != "headless"

## Inclinação do telemóvel para o brilho holográfico das cartas (suavizada).
func _process(delta: float) -> void:
	_tick_session(delta)   # 0.19.0 (secção 6): tempo de jogo, pausas, cronómetro
	var fps := wanted_fps()
	if Engine.max_fps != fps:
		Engine.max_fps = fps
	ArtLib.pump(delta)   # 0.19.0 (218): as ilustrações pedidas, uma de cada vez
	_dev_tick(delta)
	_rest_tick()
	if Settings.performance_mode or not tilt_needed():
		return   # 0.12.0: sem brilho holográfico a seguir o telemóvel; 0.19.0 (203): nem sem nada que o use
	var a := Input.get_accelerometer()
	var target := Vector2.ZERO
	if a != Vector3.ZERO:
		target = Vector2(clampf(a.x / 9.8, -1.0, 1.0), clampf(a.y / 9.8, -1.0, 1.0))
	_tilt = _tilt.lerp(target, clampf(delta * 4.0, 0.0, 1.0))
	CardView.set_foil_tilt(_tilt)

## Hit-stop: congela o jogo por instantes num golpe grande (não corre no modo instantâneo).
## Vive aqui (autoload) para o time_scale voltar sempre a 1, mesmo que a cena mude a meio.
func hit_stop(seconds: float = 0.08, scale: float = 0.05) -> void:
	if not Settings.motion_ok():
		return
	_hitstop_id += 1
	var id := _hitstop_id
	Engine.time_scale = scale
	await get_tree().create_timer(seconds, true, false, true).timeout
	if id == _hitstop_id:
		Engine.time_scale = 1.0

func _on_achievement(id: String) -> void:
	for a in CardDB.achievements:
		if String(a.get("id", "")) == id:
			# 0.19.0 (161): no canto de cima à direita, para não tapar o tabuleiro nem a mão.
			# 0.19.0 (183): depois da primeira, as conquistas passam mais depressa.
			var secs := 1.8 if bool(Settings.opt("short_celebrations")) and Stats.unlocked_count() > 1 else 2.8
			progress_toast("★ " + tr("Conquista: %s") % tr(String(a.get("name", id))), secs)
			return

## Conteúdo novo desbloqueado (carta mítica, relíquia, planeswalker, costas, moldura): segundo aviso.
## 0.16.1 (V62): um cosmético novo traz a pré-visualização no aviso e o som próprio (Sfx.reward).
const UNLOCK_TITLES := {"back": "Novas costas de carta!", "frame": "Nova moldura!", "mat": "Novo tapete da Arena!", "effect": "Novo efeito do golpe!"}

func _on_content_unlocked(kind: String, id: String) -> void:
	if UNLOCK_TITLES.has(kind):
		progress_toast(tr(String(CardDB.get_cosmetic(kind, id).get("name", id))), 3.4, false, {"kind": kind, "id": id})
		return
	progress_toast("✦ " + Stats.unlock_label({"type": kind, "id": id}, "Desbloqueaste %s: %s"), 3.0)

## Aviso curto no topo do ecrã (conquistas, conteúdo novo), por cima de tudo.
## 0.12.0: vários avisos ao mesmo tempo (o fim de uma run pode trazer 3 ou 4 conquistas) ficam em fila,
## uns por baixo dos outros (no máximo TOAST_MAX de cada vez), em vez de se taparem.
const TOAST_MAX := 3
var _toast_queue: Array = []        # [texto, segundos] à espera
var _toast_slots: Array = [null, null, null]
var toast_log: Array = []           # 0.19.0 (137): os últimos 20 avisos [{"text", "time"}], para o sino
const TOAST_LOG_MAX := 20
## 0.20.0 (C11): avisos de progresso (conquista, cosmético, desbloqueio, página do Diário). Enquanto um nó deste grupo
## estiver na árvore (a batalha, do _ready até sair), ficam em held_notices; saem em «Também ganhaste:» (BattleRewards,
## RunOver) ou no ecrã seguinte, no canto.
const HOLD_GROUP := "hold_progress_notices"
## Cenas que tratam elas próprias dos avisos retidos: a batalha continua a retê-los e o RunOver mostra-os.
const HOLD_SCENE_NAMES := ["Battle", "RunOver"]
var held_notices: Array = []   # [texto, segundos, som, cosmético, true], como na _toast_queue

## `cosmetic` ({kind, id}): aviso de cosmético novo, com a pré-visualização e o som próprio (V62).
## `corner` (0.19.0, 161): no canto de cima à direita, mais pequeno (conquistas).
func toast(text: String, seconds: float = 2.8, sound: bool = true, cosmetic: Dictionary = {}, corner: bool = false) -> void:
	_log_notice(text)
	_toast_queue.append([text, seconds, sound, cosmetic, corner])
	_pump_toasts()

func _log_notice(text: String) -> void:
	toast_log.append({"text": text, "time": Time.get_time_string_from_system().substr(0, 5)})
	while toast_log.size() > TOAST_LOG_MAX:
		toast_log.pop_front()

## Avisos à espera e no ecrã (para os testes).
func toast_count() -> int:
	var n := _toast_queue.size()
	for p in _toast_slots:
		if p != null and is_instance_valid(p):
			n += 1
	return n

## 0.20.0 (C11): aviso de progresso. Fora da batalha vai para o canto (um de cada vez); com a batalha aberta entra
## logo no sino e fica retido.
func progress_toast(text: String, seconds: float = 2.8, sound: bool = false, cosmetic: Dictionary = {}) -> void:
	if not holding_notices():
		toast(text, seconds, sound, cosmetic, true)
		return
	_log_notice(text)
	held_notices.append([text, seconds, sound, cosmetic, true])

## Há um nó do HOLD_GROUP na árvore (sem contar os que estão a ser libertados)?
func holding_notices() -> bool:
	if not is_inside_tree():
		return false
	for n in get_tree().get_nodes_in_group(HOLD_GROUP):
		if not n.is_queued_for_deletion():
			return true
	return false

## As linhas de «Também ganhaste:», sem as de `skip`, cortadas pelo notice_lines (max_lines < 0: todas), e esvazia a lista.
## O cosmético aparece como desbloqueio, porque o nome sozinho não se percebe.
func take_held_notices(max_lines: int = 3, skip: Array[String] = []) -> Array[String]:
	var all: Array[String] = []
	for h in held_notices:
		var c: Dictionary = h[3]
		var s: String = String(h[0]) if c.is_empty() else "✦ " + Stats.unlock_label({"type": String(c.get("kind", "")), "id": String(c.get("id", ""))}, "Desbloqueaste %s: %s")
		if not (s in skip):
			all.append(s)
	held_notices.clear()
	return notice_lines(all, max_lines)

## No máximo `max_lines` linhas (max_lines < 0: todas); com mais, a última passa a «… e mais N nos AVISOS (o sino).».
## Com uma linha só, essa diz quantos avisos há no sino (o «… e mais» sozinho não se percebe); com 0, nenhuma.
func notice_lines(lines: Array[String], max_lines: int) -> Array[String]:
	if max_lines < 0 or lines.size() <= max_lines:
		return lines
	var out: Array[String] = []
	if max_lines == 1:
		out.append(tr("%d avisos no sino (AVISOS).") % lines.size())
	if max_lines <= 1:
		return out
	out.assign(lines.slice(0, max_lines - 1))
	out.append(tr("… e mais %d nos AVISOS (o sino).") % (lines.size() - max_lines + 1))
	return out

## Os avisos retidos vão para a fila do canto (já estão no sino), quando já nada os retém.
func release_held_notices() -> void:
	if held_notices.is_empty() or holding_notices():
		return
	_toast_queue.append_array(held_notices)
	held_notices.clear()
	_pump_toasts()

func _pump_toasts() -> void:
	while not _toast_queue.is_empty():
		var slot := -1
		var corner_on := false   # 0.20.0 (C11): os avisos do canto (os de progresso) saem um de cada vez
		for i in TOAST_MAX:
			var p = _toast_slots[i]
			if p == null or not is_instance_valid(p):
				if slot < 0:
					slot = i
			elif bool((p as Node).get_meta("corner", false)):
				corner_on = true
		if slot < 0:
			return
		var pick := -1
		for j in _toast_queue.size():
			var q: Array = _toast_queue[j]
			if not (corner_on and q.size() > 4 and bool(q[4])):
				pick = j
				break
		if pick < 0:
			return
		var t: Array = _toast_queue.pop_at(pick)
		_show_toast(String(t[0]), float(t[1]), slot, bool(t[2]), t[3] if t.size() > 3 else {}, bool(t[4]) if t.size() > 4 else false)

func _show_toast(text: String, seconds: float, slot: int, sound: bool = true, cosmetic: Dictionary = {}, corner: bool = false) -> void:
	var panel := PanelContainer.new()
	panel.name = "Toast"
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.13, 0.11, 0.19, 0.96), 12, UiKit.GOLD, 2, 12 if not corner else 8))
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.set_meta("corner", corner)
	# 0.19.0 (138): o tempo à escolha (ou até tocar); (136) o texto dos avisos com o tamanho dos menus.
	var hold := Settings.toast_seconds(seconds)
	if hold <= 0.0:
		hold = 600.0
		panel.mouse_filter = Control.MOUSE_FILTER_STOP
		panel.gui_input.connect(_on_toast_tap.bind(panel))
	seconds = hold
	var label := UiKit.label(text, roundi((16 if corner else 20) * Settings.menu_text_scale()), UiKit.GOLD)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	if cosmetic.is_empty():
		panel.add_child(label)
	else:
		# V62: a pré-visualização à esquerda; o título e o nome à direita.
		panel.name = "UnlockToast"
		var kind := String(cosmetic.get("kind", ""))
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 14)
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		panel.add_child(row)
		var prev := CosmeticPreview.make(kind, String(cosmetic.get("id", "")), Vector2(84, 52) if kind == "mat" else (Vector2(44, 62) if kind != "effect" else Vector2(56, 56)))
		prev.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		row.add_child(prev)
		var col := VBoxContainer.new()
		col.alignment = BoxContainer.ALIGNMENT_CENTER
		col.add_theme_constant_override("separation", 0)
		col.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(col)
		col.add_child(UiKit.label(tr(String(UNLOCK_TITLES.get(kind, ""))), 15, Color(0.85, 0.82, 0.95)))
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		if not corner:   # 0.20.0 (C11): no canto, o nome fica do tamanho dos outros avisos do canto
			label.add_theme_font_size_override("font_size", 22)
		col.add_child(label)
		col.add_child(UiKit.label(tr("Escolhe-o na Coleção → Cosméticos."), 13, UiKit.TEXT_DIM))
	_layer.add_child(panel)
	_toast_slots[slot] = panel
	# 0.13.0: um aviso comprido (as dicas das edições e dos Vales) parte-se em linhas, em vez de sair do ecrã.
	var max_label_w := minf(get_viewport().get_visible_rect().size.x - 96.0, 1040.0) - 24.0
	var wrapped := label.get_minimum_size().x > max_label_w
	if wrapped:
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		label.custom_minimum_size.x = max_label_w
	panel.modulate.a = 0.0
	await get_tree().process_frame
	if wrapped and is_instance_valid(panel):
		await get_tree().process_frame   # o texto partido só tem a altura certa um frame depois
	if not is_instance_valid(panel):
		_free_toast_slot(slot, panel)
		return
	panel.modulate.a = 1.0
	var vp := get_viewport().get_visible_rect().size
	# Cada aviso fica por baixo dos que já estão no ecrã (a altura de cada um conta: um aviso de 2 linhas empurra os outros).
	var target_y := 70.0
	for i in slot:
		var above = _toast_slots[i]
		target_y += (above.size.y if above != null and is_instance_valid(above) else panel.size.y) + 8.0
	panel.global_position = Vector2((vp.x - panel.size.x) / 2.0 if not corner else vp.x - panel.size.x - 14.0, 12.0 - panel.size.y)
	# 0.16.1: o tween é do próprio aviso — se o aviso for libertado antes (testes), o tween acaba com ele.
	var tw := panel.create_tween()
	tw.tween_property(panel, "global_position:y", target_y, Settings.dur(0.3)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tw.tween_interval(seconds)
	tw.tween_property(panel, "modulate:a", 0.0, Settings.dur(0.4))
	tw.tween_callback(func():
		panel.queue_free()
		_free_toast_slot(slot, panel))
	if not cosmetic.is_empty():
		Sfx.reward()
	elif sound:
		Sfx.select()

func _on_toast_tap(ev: InputEvent, panel: Control) -> void:
	if ev is InputEventMouseButton and (ev as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT and not ev.pressed and is_instance_valid(panel):
		var slot := _toast_slots.find(panel)
		panel.queue_free()
		if slot >= 0:
			_free_toast_slot(slot, panel)

func _free_toast_slot(slot: int, panel: Control) -> void:
	if _toast_slots[slot] == panel:
		_toast_slots[slot] = null
	_pump_toasts()

## Põe um painel por cima de tudo (fica até ele próprio se libertar com queue_free).
func show_overlay(node: Control) -> void:
	overlay_layer.add_child(node)
	if pad_mode:
		_focus_in.call_deferred(node)   # 0.19.0 (17): com comando, o foco passa para a janela nova

## 0.16.0: um overlay a fechar com animação (UiKit.close_animated) já não conta como aberto.
func has_overlay() -> bool:
	if _back_frame == Engine.get_process_frames():
		return true   # este «retroceder» já fechou uma janela: o ecrã por baixo não reage
	return _open_overlays() > 0

## O painel mais acima (o único que deve reagir ao botão "retroceder" do Android).
func top_overlay() -> Control:
	var top: Control = null
	for c in overlay_layer.get_children():
		if not c.is_queued_for_deletion() and not c.has_meta("closing"):
			top = c
	return top

func close_overlays() -> void:
	for c in overlay_layer.get_children():
		c.queue_free()

## Há uma troca de cena a decorrer (go() ignora pedidos até acabar).
func is_busy() -> bool:
	return _busy

func go(scene_key: String) -> void:
	var path: String = SCENES.get(scene_key, "")
	if path == "":
		push_error("SceneRouter: cena desconhecida: " + scene_key)
		return
	if _busy:
		return
	_busy = true
	_hitstop_id += 1
	Engine.time_scale = 1.0
	close_overlays()
	_apply_scene_power(scene_key)
	EventBus.scene_changed.emit(scene_key)
	ArtLib.trim()       # 0.19.0 (248): solta as ilustrações feitas no jogo que já não são precisas
	get_tree().create_timer(1.2).timeout.connect(_check_session)   # 0.19.0 (172, 195)
	# Sem ecrã (testes headless) não há nada para fundir: muda logo.
	var fade := Settings.dur(FADE)
	if DisplayServer.get_name() == "headless" or fade <= 0.0:
		get_tree().change_scene_to_file(path)
		_busy = false
		return
	_fade.mouse_filter = Control.MOUSE_FILTER_STOP
	_scene_t0 = Time.get_ticks_msec() / 1000.0
	if ResourceLoader.load_threaded_get_status(path) == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
		ResourceLoader.load_threaded_request(path, "PackedScene")   # 0.19.0 (247): vai carregando durante o escurecer
	var style := transition_style(scene_key)
	if style in ["fog", "iris"]:
		await _transition_cover(style, path, fade)
	else:
		await _transition_classic(style, path, fade, scene_key)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_busy = false

## 0.19.0 (267): a legenda de um som (no lado direito, a meio; as iguais seguidas não se repetem).
var _captions: VBoxContainer
var _last_caption := ""
var _last_caption_t := 0.0

func caption(text: String) -> void:
	var now := Time.get_ticks_msec() / 1000.0
	if text == _last_caption and now - _last_caption_t < 0.8:
		return
	_last_caption = text
	_last_caption_t = now
	if _captions == null:
		# Do lado direito, a meio (na batalha, a coluna da esquerda tem o inimigo e os botões).
		_captions = VBoxContainer.new()
		_captions.name = "Captions"
		_captions.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_captions.add_theme_constant_override("separation", 4)
		_captions.alignment = BoxContainer.ALIGNMENT_END
		_captions.anchor_left = 1.0
		_captions.anchor_right = 1.0
		_captions.anchor_top = 0.5
		_captions.anchor_bottom = 0.5
		_captions.offset_left = -320.0
		_captions.offset_right = -14.0
		_captions.offset_top = -10.0
		_captions.offset_bottom = 100.0
		_layer.add_child(_captions)
	while _captions.get_child_count() >= 3:
		var old := _captions.get_child(0)
		_captions.remove_child(old)
		old.queue_free()
	var p := PanelContainer.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.size_flags_horizontal = Control.SIZE_SHRINK_END
	p.add_theme_stylebox_override("panel", UiKit.flat(Color(0, 0, 0, 0.72), 8, Color(1, 1, 1, 0.25), 1, 6))
	p.add_child(UiKit.label("♪ " + text, 15, Color.WHITE))
	_captions.add_child(p)
	var tw := p.create_tween()
	tw.tween_interval(1.6)
	tw.tween_property(p, "modulate:a", 0.0, 0.35)
	tw.tween_callback(p.queue_free)

func captions_shown() -> int:
	return _captions.get_child_count() if _captions != null else 0

## 268: um aviso que só se ouvia também se vê (um brilho nas bordas do ecrã) e vibra.
var _cue: ColorRect
var cues_shown := 0

func cue(color: Color) -> void:
	cues_shown += 1
	Settings.vibrate(25)
	if _cue == null:
		_cue = ColorRect.new()
		_cue.name = "CueGlow"
		_cue.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_cue.set_anchors_preset(Control.PRESET_FULL_RECT)
		var m := ShaderMaterial.new()
		m.shader = CUE_SHADER
		_cue.material = m
		_layer.add_child(_cue)
	(_cue.material as ShaderMaterial).set_shader_parameter("tint", color)
	_cue.modulate.a = 1.0
	_cue.visible = true
	var tw := _cue.create_tween()
	tw.tween_property(_cue, "modulate:a", 0.0, 0.6 if Settings.motion_ok() else 0.9)
	tw.tween_callback(func(): _cue.visible = false)

const CUE_SHADER := preload("res://assets/shaders/edge_glow.gdshader")

## 262: o filtro de daltonismo, por cima de tudo (um ColorRect que lê o ecrã).
var _cvd_layer: CanvasLayer
var _cvd: ColorRect

func refresh_cvd() -> void:
	var mode := {"protan": 1, "deutan": 2, "tritan": 3}.get(String(Settings.opt("colorblind_filter")), 0) as int
	if mode == 0:
		if _cvd_layer != null:
			_cvd_layer.visible = false
		return
	if _cvd_layer == null:
		_cvd_layer = CanvasLayer.new()
		_cvd_layer.name = "CvdFilter"
		_cvd_layer.layer = 127
		add_child(_cvd_layer)
		_cvd = ColorRect.new()
		_cvd.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_cvd.set_anchors_preset(Control.PRESET_FULL_RECT)
		var m := ShaderMaterial.new()
		m.shader = preload("res://assets/shaders/cvd.gdshader")
		_cvd.material = m
		_cvd_layer.add_child(_cvd)
	(_cvd.material as ShaderMaterial).set_shader_parameter("mode", mode)
	_cvd_layer.visible = true

func cvd_mode() -> int:
	return int((_cvd.material as ShaderMaterial).get_shader_parameter("mode")) if _cvd != null and _cvd_layer.visible else 0

## 0.19.0 (256): modo leitor — o 1.º toque num botão diz o que ele faz (com a voz) e o 2.º toque (no mesmo, em 3 s)
## carrega. Os textos sem botão também se leem.
var _reader_btn: BaseButton
var _reader_t := 0.0
var _reader_swallow := false

func _reader_input(event: InputEvent) -> bool:
	if not bool(Settings.opt("reader")) or not (event is InputEventMouseButton):
		return false
	var mb := event as InputEventMouseButton
	if mb.button_index != MOUSE_BUTTON_LEFT:
		return false
	if not mb.pressed:
		if _reader_swallow:
			_reader_swallow = false
			return true
		return false
	var b := button_at(mb.position)
	var now := Time.get_ticks_msec() / 1000.0
	if b == null:
		var tip := tip_at(mb.position)
		if not tip.is_empty():
			Speech.say(String(tip["text"]))
		return false
	if b == _reader_btn and now - _reader_t < 3.0:
		_reader_btn = null
		return false   # 2.º toque: carrega como de costume
	_reader_btn = b
	_reader_t = now
	Speech.say(button_speech(b))
	_reader_swallow = true
	return true

## O botão (ligado e à vista) por baixo do dedo.
func button_at(pos: Vector2) -> BaseButton:
	var roots: Array = []
	var ov := overlay_layer.get_children().filter(func(c): return c is Control and (c as Control).visible and not c.is_queued_for_deletion())
	if not ov.is_empty():
		roots.append(ov[ov.size() - 1])
	elif get_tree().current_scene != null:
		roots.append(get_tree().current_scene)
	for r in roots:
		var b := _button_in(r, pos)
		if b != null:
			return b
	return null

func _button_in(n: Node, pos: Vector2) -> BaseButton:
	if n is CanvasItem and not (n as CanvasItem).visible:
		return null
	var kids := n.get_children()
	for i in range(kids.size() - 1, -1, -1):
		var r := _button_in(kids[i], pos)
		if r != null:
			return r
	if n is BaseButton and not (n as BaseButton).disabled and (n as Control).get_global_rect().has_point(pos):
		return n as BaseButton
	return null

## O que se diz de um botão: o texto dele (ou das letras lá dentro) e a explicação, se houver.
func button_speech(b: BaseButton) -> String:
	var parts: Array[String] = []
	if b is Button and (b as Button).text.strip_edges() != "":
		parts.append((b as Button).text)
	else:
		for l in b.find_children("*", "Label", true, false):
			if (l as Label).visible and (l as Label).text.strip_edges() != "":
				parts.append((l as Label).text)
	if b.tooltip_text.strip_edges() != "":
		parts.append(b.tooltip_text)
	if parts.is_empty():
		parts.append(tr("Botão"))
	return ". ".join(PackedStringArray(parts)) + ". " + tr("Toca outra vez para carregar.")

## 0.19.0 (285): um círculo no sítio do toque (ajuda quem treme e quem grava vídeos do jogo).
func _touch_ring(event: InputEvent) -> void:
	if not bool(Settings.opt("touch_circle")):
		return
	var pos := Vector2.ZERO
	if event is InputEventScreenTouch and (event as InputEventScreenTouch).pressed:
		pos = (event as InputEventScreenTouch).position
	elif event is InputEventMouseButton and (event as InputEventMouseButton).pressed and event.device != InputEvent.DEVICE_ID_EMULATION:
		pos = (event as InputEventMouseButton).position
	else:
		return
	var r := TouchRing.new()
	r.position = pos
	_layer.add_child(r)

class TouchRing extends Node2D:
	var _t := 0.0
	const LIFE := 0.45

	func _process(delta: float) -> void:
		_t += delta
		if _t >= LIFE:
			queue_free()
			return
		queue_redraw()

	func _draw() -> void:
		var k := _t / LIFE
		draw_arc(Vector2.ZERO, 14.0 + 22.0 * k, 0.0, TAU, 32, Color(1.0, 0.86, 0.45, 0.85 * (1.0 - k)), 3.0, true)
		draw_circle(Vector2.ZERO, 6.0 * (1.0 - k), Color(1.0, 0.86, 0.45, 0.6 * (1.0 - k)))

## 0.19.0 (250): modo programador — no canto de baixo à direita, FPS, comandos de desenho, nós e memória.
var _dev: Label
var _dev_acc := 0.0

func refresh_dev_overlay() -> void:
	var on := bool(Settings.opt("dev_mode"))
	if on and _dev == null:
		_dev = UiKit.label("", 12, Color(0.6, 1.0, 0.7))
		_dev.name = "DevOverlay"
		_dev.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_dev.add_theme_constant_override("outline_size", 4)
		_dev.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
		_dev.position = Vector2(8, 4)
		_layer.add_child(_dev)
	if _dev != null:
		_dev.visible = on
		_dev.text = dev_text()

func _dev_tick(delta: float) -> void:
	if _dev == null or not _dev.visible:
		return
	_dev_acc += delta
	if _dev_acc >= 0.5:
		_dev_acc = 0.0
		_dev.text = dev_text()

func dev_text() -> String:
	var mb := func(b: float) -> String: return "%.0f MB" % (b / 1048576.0)
	return "%d FPS (alvo %s) · %d desenhos · %d nós · %d objetos · RAM %s · texturas %s%s" % [int(Performance.get_monitor(Performance.TIME_FPS)),
		str(Engine.max_fps) if Engine.max_fps > 0 else "∞", int(Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME)),
		int(Performance.get_monitor(Performance.OBJECT_NODE_COUNT)), int(Performance.get_monitor(Performance.OBJECT_COUNT)),
		mb.call(Performance.get_monitor(Performance.MEMORY_STATIC)), mb.call(Performance.get_monitor(Performance.RENDER_TEXTURE_MEM_USED)),
		"  ·  " + thermal.report_line() if thermal != null and thermal.windows > 0 else ""]

## 0.19.0 (247): a cena carregada noutro fio; se demorar mais de meio segundo, aparece a roda de espera (em vez
## de o ecrã parecer encravado).
const WAIT_SPINNER := 0.5
var _scene_t0 := 0.0
var _spinner: Control

func _change_scene(path: String) -> void:
	var st := ResourceLoader.load_threaded_get_status(path)
	while st == ResourceLoader.THREAD_LOAD_IN_PROGRESS:
		if Time.get_ticks_msec() / 1000.0 - _scene_t0 > WAIT_SPINNER:
			show_spinner(true)
		await get_tree().process_frame
		st = ResourceLoader.load_threaded_get_status(path)
	show_spinner(false)
	var ps: PackedScene = null
	if st == ResourceLoader.THREAD_LOAD_LOADED:
		ps = ResourceLoader.load_threaded_get(path) as PackedScene
	if ps != null:
		get_tree().change_scene_to_packed(ps)
	else:
		get_tree().change_scene_to_file(path)

func _make_spinner() -> void:
	_spinner = Spinner.new()
	_spinner.name = "WaitSpinner"
	_spinner.visible = false
	_layer.add_child(_spinner)

func show_spinner(on: bool) -> void:
	if _spinner == null:
		return
	if on and not _spinner.visible:
		var vp := get_viewport().get_visible_rect().size
		_spinner.position = vp - Vector2(84, 84)
	_spinner.visible = on

func spinner_visible() -> bool:
	return _spinner != null and _spinner.visible

## Um arco dourado a girar (dois comandos de desenho).
class Spinner extends Control:
	var _a := 0.0

	func _init() -> void:
		size = Vector2(48, 48)
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _process(delta: float) -> void:
		if visible:
			_a = fmod(_a + delta * 6.0, TAU)
			queue_redraw()

	func _draw() -> void:
		var c := size / 2.0
		draw_circle(c, 23.0, Color(0, 0, 0, 0.45))
		draw_arc(c, 15.0, _a, _a + TAU * 0.7, 28, UiKit.GOLD, 4.0, true)

## 0.16.1 (V63): a troca de ecrã depende do destino —
##   batalha          a carta (com as costas do baralho) vira no centro, como até aqui;
##   mapa             uma faixa de névoa varre o ecrã da esquerda para a direita;
##   loja             uma moeda gira no centro;
##   evento, espólio  um círculo de luz fecha-se no centro e volta a abrir;
##   o resto (menus)  só escurece, mais depressa.
static func transition_style(scene_key: String) -> String:
	match scene_key:
		"battle":
			return "card"
		"map":
			return "fog"
		"shop":
			return "coin"
		"event", "loot", "tower":
			return "iris"
	return "fade"

## Escurecer com uma peça no centro: a carta a virar ("card"), a moeda a girar ("coin") ou nada ("fade").
func _transition_classic(style: String, path: String, fade: float, scene_key: String) -> void:
	var piece: Control = null
	var vp := get_viewport().get_visible_rect().size
	if Settings.motion_ok() and style == "card":
		var card := CardBack.new()
		# 0.16.1: nas cenas da run, as costas do baralho (V12), com o brilho a passar (V9).
		card.back_id = GameState.run_back() if scene_key in RUN_SCENES else Settings.card_back
		card.shimmer = true
		card.size = FLIP_CARD
		piece = card
		piece.scale = Vector2(0.0, 0.92)
		piece.rotation = -0.08
	elif Settings.motion_ok() and style == "coin":
		piece = CardIcon.new("coin", UiKit.COIN, 150.0)
		piece.size = Vector2(150, 150)
		piece.modulate.a = 0.0
	if piece != null:
		piece.mouse_filter = Control.MOUSE_FILTER_IGNORE
		piece.position = (vp - piece.size) / 2.0
		piece.pivot_offset = piece.size / 2.0
		_layer.add_child(piece)
	if style == "fade":
		fade *= 0.8
	var spin := func(v: float):
		if is_instance_valid(piece):
			piece.scale = Vector2(maxf(0.06, absf(cos(v))), 1.0)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(_fade, "modulate:a", 1.0, fade)
	if piece != null and style == "card":
		tw.tween_property(piece, "scale", Vector2.ONE, fade * 1.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
		tw.tween_property(piece, "rotation", 0.0, fade * 1.2)
	elif piece != null:
		tw.tween_property(piece, "modulate:a", 1.0, fade * 0.6)
		tw.tween_method(spin, 0.0, PI * 3.0, fade * 1.2)
	await tw.finished
	await _change_scene(path)
	await get_tree().process_frame
	await get_tree().process_frame
	var tw2 := create_tween().set_parallel(true)
	tw2.tween_property(_fade, "modulate:a", 0.0, fade)
	if piece != null and style == "card":
		tw2.tween_property(piece, "scale", Vector2(0.0, 0.92), fade).set_ease(Tween.EASE_IN)
		tw2.tween_property(piece, "rotation", 0.08, fade)
	elif piece != null:
		tw2.tween_property(piece, "modulate:a", 0.0, fade)
		tw2.tween_method(spin, PI * 3.0, PI * 5.0, fade)
	await tw2.finished
	if piece != null and is_instance_valid(piece):
		piece.queue_free()

## Cobrir o ecrã com névoa (da esquerda para a direita) ou com um círculo a fechar; trocar; destapar.
func _transition_cover(style: String, path: String, fade: float) -> void:
	var fx := CoverFx.new()
	fx.style = style
	fx.color = _fade.color
	_layer.add_child(fx)
	var d := fade * 1.5
	var tw := create_tween()
	tw.tween_property(fx, "progress", 1.0, d).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_SINE)
	await tw.finished
	await _change_scene(path)
	await get_tree().process_frame
	await get_tree().process_frame
	fx.leaving = true
	var tw2 := create_tween()
	tw2.tween_property(fx, "progress", 0.0, d).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_SINE)
	await tw2.finished
	if is_instance_valid(fx):
		fx.queue_free()

## A cortina das trocas de ecrã "fog" e "iris": progress 0 (destapado) → 1 (tapado).
class CoverFx extends Control:
	var style := "fog"
	var color := Color(0.03, 0.02, 0.05)
	var leaving := false   # a destapar: a névoa continua para a direita (em vez de voltar para trás)
	var progress := 0.0:
		set(v):
			progress = v
			queue_redraw()

	func _init() -> void:
		mouse_filter = Control.MOUSE_FILTER_STOP
		set_anchors_preset(Control.PRESET_FULL_RECT)

	func _draw() -> void:
		var s := size
		if s.x < 2.0:
			return
		if style == "iris":
			var c := s * 0.5
			var far := s.length()
			var r := far * 0.6 * (1.0 - progress)
			if r <= 1.0:
				draw_rect(Rect2(Vector2.ZERO, s), color)
				return
			for i in 48:
				var a0 := TAU * i / 48.0
				var a1 := TAU * (i + 1) / 48.0
				var d0 := Vector2(cos(a0), sin(a0))
				var d1 := Vector2(cos(a1), sin(a1))
				draw_colored_polygon(PackedVector2Array([c + d0 * r, c + d1 * r, c + d1 * far, c + d0 * far]), color)
			draw_arc(c, r, 0.0, TAU, 64, Color(UiKit.GOLD, 0.45 * progress), 3.0, true)
			return
		# Névoa: a cortina escura com a orla suave, a entrar pela esquerda (ou a sair pela direita).
		var band := s.x * 0.25
		var tex := MenuBackdrop.glow_texture()
		if not leaving:
			var edge := lerpf(-band, s.x + band, progress)
			draw_rect(Rect2(Vector2.ZERO, Vector2(maxf(0.0, edge - band * 0.5), s.y)), color)
			_soft_edge(edge - band * 0.5, edge + band * 0.5, true)
			for i in 5:
				var y := s.y * (0.1 + 0.2 * i)
				draw_texture_rect(tex, Rect2(Vector2(edge - band * 0.4, y - band * 0.5), Vector2(band, band)), false, Color(0.55, 0.5, 0.7, 0.18))
		else:
			var edge2 := lerpf(s.x + band, -band, progress)
			draw_rect(Rect2(Vector2(edge2 + band * 0.5, 0), Vector2(maxf(0.0, s.x - edge2 - band * 0.5), s.y)), color)
			_soft_edge(edge2 - band * 0.5, edge2 + band * 0.5, false)
			for i in 5:
				var y := s.y * (0.1 + 0.2 * i)
				draw_texture_rect(tex, Rect2(Vector2(edge2 - band * 0.6, y - band * 0.5), Vector2(band, band)), false, Color(0.55, 0.5, 0.7, 0.18))

	## Faixa em degradê entre x0 e x1 (opaca do lado tapado).
	func _soft_edge(x0: float, x1: float, dark_left: bool) -> void:
		var a := Color(color, 1.0)
		var b := Color(color, 0.0)
		var l := a if dark_left else b
		var r := b if dark_left else a
		draw_polygon(PackedVector2Array([Vector2(x0, 0), Vector2(x1, 0), Vector2(x1, size.y), Vector2(x0, size.y)]), PackedColorArray([l, r, r, l]))

# --- 0.13.0: aviso discreto quando a run é gravada ("✓ Guardado em Jogo 1"), em cima à direita ---

const SAVE_BADGE_GAP_MS := 20000   # no máximo um aviso a cada 20 s (a batalha grava em cada turno)
var _save_badge: Control
var _last_save_badge_ms := -SAVE_BADGE_GAP_MS

func _on_run_saved(slot: int) -> void:
	var now := Time.get_ticks_msec()
	if now - _last_save_badge_ms < SAVE_BADGE_GAP_MS or not is_inside_tree():
		return
	_last_save_badge_ms = now
	if _save_badge != null and is_instance_valid(_save_badge):
		_save_badge.queue_free()
	var panel := PanelContainer.new()
	panel.name = "SaveBadge"
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.1, 0.09, 0.15, 0.88), 10, Color(0.45, 0.85, 0.55, 0.8), 1, 6))
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(row)
	var icon := CardIcon.new("check", Color(0.5, 0.9, 0.6), 16.0)
	icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(icon)
	row.add_child(UiKit.label(tr("Guardado em «%s»") % GameState.slot_name(slot), 14, Color(0.85, 0.95, 0.88)))
	_layer.add_child(panel)
	_save_badge = panel
	panel.modulate.a = 0.0
	await get_tree().process_frame
	if not is_instance_valid(panel):
		return
	var vp := get_viewport().get_visible_rect().size
	panel.global_position = Vector2(vp.x - panel.size.x - 14.0, 62.0)   # por baixo do ouro, longe da mão
	var tw := create_tween()
	tw.tween_property(panel, "modulate:a", 1.0, 0.25)
	tw.tween_interval(1.6)
	tw.tween_property(panel, "modulate:a", 0.0, 0.5)
	tw.tween_callback(func():
		if is_instance_valid(panel):
			panel.queue_free())

# --- 0.19.0: controlos (17–21, 26, 28, 29) ---

## Rato a sério (não o que o Android faz a partir do dedo): as explicações ao passar por cima só aparecem com ele (19).
var real_mouse := false
## Comando ou teclado em uso (17, 20): os botões aceitam o foco e o escolhido tem uma moldura dourada.
var pad_mode := false
signal pad_mode_changed(on: bool)
var _focus_box: StyleBoxFlat
var _last_back_ms := -10000

## Muda para o modo comando/teclado (os botões ganham foco) ou volta ao toque.
func set_pad_mode(on: bool) -> void:
	if pad_mode == on:
		return
	pad_mode = on
	if on:
		_walk_buttons(get_tree().root, true)
		_grab_first_focus.call_deferred()
	else:
		var f := get_viewport().gui_get_focus_owner()
		if f != null and not (f is LineEdit or f is TextEdit):
			f.release_focus()
		_walk_buttons(get_tree().root, false)
	pad_mode_changed.emit(on)

func _pad_input(event: InputEvent) -> void:
	if event is InputEventJoypadButton and (event as InputEventJoypadButton).pressed:
		set_pad_mode(true)
	elif event is InputEventJoypadMotion and absf((event as InputEventJoypadMotion).axis_value) > 0.6:
		set_pad_mode(true)
	elif event is InputEventKey and (event as InputEventKey).pressed and (event as InputEventKey).keycode in [KEY_UP, KEY_DOWN, KEY_LEFT, KEY_RIGHT, KEY_TAB]:
		if not _typing():
			set_pad_mode(true)
	elif (event is InputEventMouseButton and (event as InputEventMouseButton).pressed) or (event is InputEventScreenTouch and (event as InputEventScreenTouch).pressed):
		set_pad_mode(false)
		return
	if pad_mode and (event is InputEventJoypadButton or event is InputEventKey) and get_viewport().gui_get_focus_owner() == null:
		_grab_first_focus()
	# Esc e o botão B do comando fazem o mesmo que o «retroceder» do Android.
	if event.is_action_pressed("ui_cancel") and not _typing() and Time.get_ticks_msec() - _last_back_ms > 250:
		get_viewport().set_input_as_handled()
		get_tree().root.propagate_notification(NOTIFICATION_WM_GO_BACK_REQUEST)

func _typing() -> bool:
	var f := get_viewport().gui_get_focus_owner()
	return f is LineEdit or f is TextEdit

func _walk_buttons(n: Node, on: bool) -> void:
	if n is BaseButton:
		if on:
			_make_focusable(n)
		elif n.has_meta("pad_was_none"):
			(n as Control).focus_mode = Control.FOCUS_NONE
			n.remove_meta("pad_was_none")
	elif n is ScrollContainer and on:
		(n as ScrollContainer).follow_focus = true
	for c in n.get_children():
		_walk_buttons(c, on)

func _make_focusable(b) -> void:
	if not is_instance_valid(b) or not pad_mode or not (b is BaseButton):
		return
	var btn := b as BaseButton
	if btn.focus_mode == Control.FOCUS_NONE:
		btn.set_meta("pad_was_none", true)
		btn.focus_mode = Control.FOCUS_ALL
	btn.add_theme_stylebox_override("focus", focus_style())

## A moldura do botão escolhido com o comando ou o teclado (20).
func focus_style() -> StyleBoxFlat:
	if _focus_box == null:
		_focus_box = StyleBoxFlat.new()
		_focus_box.draw_center = false
		_focus_box.set_border_width_all(4)
		_focus_box.border_color = Color(1.0, 0.88, 0.4)
		_focus_box.set_corner_radius_all(14)
		_focus_box.set_expand_margin_all(4)
		_focus_box.shadow_color = Color(1.0, 0.78, 0.3, 0.5)
		_focus_box.shadow_size = 10
	return _focus_box

## O primeiro botão à vista da janela de cima (ou do ecrã, se não houver janelas) fica com o foco.
## A batalha (meta "pad_custom") trata do comando ela própria.
func _grab_first_focus() -> void:
	if not pad_mode or get_viewport().gui_get_focus_owner() != null:
		return
	var top := top_overlay()
	if top != null:
		_focus_in(top)
		return
	var scene := get_tree().current_scene
	if scene != null and not scene.has_meta("pad_custom"):
		_focus_in(scene)

func _focus_in(root: Node) -> void:
	if not pad_mode or root == null or not is_instance_valid(root):
		return
	_walk_buttons(root, true)
	var b := _first_button(root)
	if b != null:
		b.grab_focus()

func _first_button(n: Node) -> BaseButton:
	if n is CanvasItem and not (n as CanvasItem).visible:
		return null
	if n is BaseButton and not (n as BaseButton).disabled and (n as Control).is_visible_in_tree():
		return n as BaseButton
	for c in n.get_children():
		var r := _first_button(c)
		if r != null:
			return r
	return null

## 26: botões maiores (56 ou 64 px) sem mexer no resto; só nos botões a sério (≥ 44 px), não nas etiquetas.
func _enlarge_button(b) -> void:
	if not is_instance_valid(b) or not (b is BaseButton) or b.has_meta("no_big"):
		return
	var lvl := int(Settings.opt("buttons_big"))
	var c := b as Control
	if not b.has_meta("orig_min_h"):
		if lvl <= 0:
			return
		b.set_meta("orig_min_h", c.custom_minimum_size.y)
	var orig := float(b.get_meta("orig_min_h"))
	if lvl <= 0 or orig < 44.0:
		c.custom_minimum_size.y = orig
		return
	c.custom_minimum_size.y = maxf(orig, 56.0 if lvl == 1 else 64.0)

## Volta a medir os botões que estão no ecrã (a opção mudou).
func refresh_buttons(n: Node = null) -> void:
	if n == null:
		n = get_tree().root
	if n is BaseButton:
		_enlarge_button(n)
	for c in n.get_children():
		refresh_buttons(c)

# 28: a área segura do ecrã (entalhes, cantos) e as margens dos gestos do Android.
## Quanto a área segura tira a cada lado, em px do jogo (0 sem entalhes ou nos testes).
func safe_insets() -> Dictionary:
	var out := {"left": 0.0, "top": 0.0, "right": 0.0, "bottom": 0.0}
	if DisplayServer.get_name() == "headless" or not bool(Settings.opt("edge_guard")):
		return out
	var win := DisplayServer.window_get_size()
	var screen := DisplayServer.screen_get_size()
	if win.x <= 0 or win.y <= 0 or screen.x <= 0 or screen.y <= 0:
		return out
	var safe := DisplayServer.get_display_safe_area()
	if safe.size.x <= 0 or safe.size.y <= 0:
		return out
	var k := get_viewport().get_visible_rect().size / Vector2(win)
	out["left"] = maxf(0.0, float(safe.position.x)) * k.x
	out["top"] = maxf(0.0, float(safe.position.y)) * k.y
	out["right"] = maxf(0.0, float(screen.x - safe.end.x)) * k.x
	out["bottom"] = maxf(0.0, float(screen.y - safe.end.y)) * k.y
	return out

func _apply_safe_area(n) -> void:
	if not is_instance_valid(n) or not (n is Control) or n.get_parent() != get_tree().root:
		return
	var c := n as Control
	var ins := safe_insets()
	c.offset_left = float(ins["left"])
	c.offset_top = float(ins["top"])
	c.offset_right = -float(ins["right"])
	c.offset_bottom = -float(ins["bottom"])

## Volta a pôr a cena de agora dentro da área segura (quando muda a opção).
func refresh_safe_area() -> void:
	var cur := get_tree().current_scene
	if cur != null:
		_apply_safe_area(cur)

## Perto de mais da borda (o gesto de voltar do Android e as bordas curvas apanham estes toques).
const EDGE_PX := 24.0
func near_edge(global_pos: Vector2, px: float = EDGE_PX) -> bool:
	var vp := get_viewport().get_visible_rect().size
	return global_pos.x < px or global_pos.x > vp.x - px

# 29: ignorar a palma nas bordas curvas. Um toque que começa colado à borda (a 12 px) não conta. Como o Godot só
# faz «rato» do 1.º dedo, enquanto a palma está pousada o dedo seguinte passa a fazer de rato (eventos feitos aqui).
const PALM_PX := 12.0
const SYNTH_DEVICE := 77
var _palm_mouse := false     # o rato que o Godot fez a partir da palma está a ser ignorado
var _palm_index := -1        # o toque da palma
var _proxy_index := -1       # o dedo que faz de rato enquanto a palma está pousada

func _at_palm_edge(p: Vector2) -> bool:
	var vp := get_viewport().get_visible_rect().size
	return p.x < PALM_PX or p.y < PALM_PX or p.x > vp.x - PALM_PX or p.y > vp.y - PALM_PX

## true: o evento é da palma (engolido). Os eventos feitos aqui (SYNTH_DEVICE) passam sempre.
func _palm_filter(event: InputEvent) -> bool:
	if event.device == SYNTH_DEVICE:
		return false
	if not bool(Settings.opt("palm_guard")):
		_palm_mouse = false
		_palm_index = -1
		_proxy_index = -1
		return false
	if event is InputEventMouseButton and event.device == InputEvent.DEVICE_ID_EMULATION:
		var mb := event as InputEventMouseButton
		if mb.pressed and _at_palm_edge(mb.position):
			_palm_mouse = true
			return true
		if not mb.pressed and _palm_mouse:
			_palm_mouse = false
			return true
		return _palm_mouse
	if event is InputEventMouseMotion and event.device == InputEvent.DEVICE_ID_EMULATION:
		return _palm_mouse
	if event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed:
			if _palm_index < 0 and _at_palm_edge(st.position):
				_palm_index = st.index
				return true
			if _palm_index >= 0 and _proxy_index < 0 and st.index != _palm_index:
				_proxy_index = st.index
				_synth_button(st.position, true)
			return false
		if st.index == _palm_index:
			_palm_index = -1
			return true
		if st.index == _proxy_index:
			_proxy_index = -1
			_synth_button(st.position, false)
		return false
	if event is InputEventScreenDrag:
		var sd := event as InputEventScreenDrag
		if sd.index == _palm_index:
			return true
		if sd.index == _proxy_index:
			var mm := InputEventMouseMotion.new()
			mm.device = SYNTH_DEVICE
			mm.position = sd.position
			mm.global_position = sd.position
			mm.relative = sd.relative
			mm.button_mask = MOUSE_BUTTON_MASK_LEFT
			Input.parse_input_event(mm)
	return false

func _synth_button(pos: Vector2, pressed: bool) -> void:
	var mb := InputEventMouseButton.new()
	mb.device = SYNTH_DEVICE
	mb.button_index = MOUSE_BUTTON_LEFT
	mb.pressed = pressed
	mb.position = pos
	mb.global_position = pos
	mb.button_mask = MOUSE_BUTTON_MASK_LEFT if pressed else 0
	Input.parse_input_event(mb)


# --- 0.19.0 (secção 5): texto dos menus, relógio, explicar, ajuda do ecrã ---

const MENU_TEXT_SCENES := ["Collection", "Stats", "Achievements", "HowToPlay", "Talents", "Campaign", "Map", "Shop", "Event", "Loot"]
## 0.20.0 (D13): teto do «Texto dos menus» por ecrã. Na loja as três colunas já enchem os 720 de altura: acima de 115 %
## os serviços com 2 linhas («Melhorar uma carta») saem das filas e o Vale deixa de caber por baixo das relíquias.
const MENU_TEXT_CAP := {"Shop": 1.15}

## 136: aumenta a letra de um texto que esteja numa janela (UiKit.window) ou num ecrã de listas (Coleção,
## Estatísticas…), fora das cartas.
## 296: uma letra dentro de uma janela de pergaminho (e não dentro de um botão ou de um painel escuro) fica escura.
func _light_text(n: Node) -> void:
	if not is_instance_valid(n) or not n.is_inside_tree() or n.has_meta("lt_done"):
		return
	var p := n.get_parent()
	var depth := 0
	var ok := false
	while p != null and depth < 24:
		if p is BaseButton or p is CardView or p is CardFace or p is RelicView:
			return
		if p.has_meta("light_surface"):
			ok = true
			break
		if p is PanelContainer:
			var sb := (p as PanelContainer).get_theme_stylebox("panel")
			if sb is StyleBoxFlat and (sb as StyleBoxFlat).bg_color.a > 0.5 and (sb as StyleBoxFlat).bg_color.get_luminance() < 0.4:
				return
		p = p.get_parent()
		depth += 1
	if not ok:
		return
	n.set_meta("lt_done", true)
	if n is Label:
		var l := n as Label
		l.add_theme_color_override("font_color", UiKit.ink_for(l.get_theme_color("font_color")))
		if l.get_theme_constant("outline_size") > 0:
			l.add_theme_color_override("font_outline_color", Color(1, 1, 1, 0.5))
	elif n is RichTextLabel:
		var r := n as RichTextLabel
		r.add_theme_color_override("default_color", UiKit.ink_for(r.get_theme_color("default_color")))

func _menu_text(n: Node) -> void:
	if not is_instance_valid(n) or not n.is_inside_tree() or n.has_meta("mt_done"):
		return
	var f := Settings.menu_text_scale()
	if f <= 1.001:
		return
	var ok := false
	var p := n.get_parent()
	var depth := 0
	while p != null and depth < 24:
		if p is CardView or p is CardFace or p is RelicView:
			return
		if p.has_meta("menu_text"):
			ok = true
			break
		if p == get_tree().current_scene:
			ok = String(p.name) in MENU_TEXT_SCENES
			f = minf(f, float(MENU_TEXT_CAP.get(String(p.name), f)))
			break
		p = p.get_parent()
		depth += 1
	if not ok:
		return
	n.set_meta("mt_done", true)
	var key := "normal_font_size" if n is RichTextLabel else "font_size"
	var c := n as Control
	c.add_theme_font_size_override(key, roundi(c.get_theme_font_size(key) * f))

# 140: o relógio no canto (o modo imersivo esconde a barra do Android).
var _clock: Label
var _clock_timer: Timer

func _make_clock() -> void:
	_clock = Label.new()
	_clock.name = "Clock"
	_clock.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_clock.add_theme_font_size_override("font_size", 13)
	_clock.add_theme_color_override("font_color", Color(1, 1, 1, 0.62))
	_clock.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	_clock.add_theme_constant_override("outline_size", 4)
	_clock.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_layer.add_child(_clock)
	_clock.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	_clock.offset_left = -90.0
	_clock.offset_top = -20.0
	_clock.offset_right = -10.0
	_clock.offset_bottom = -2.0
	_clock_timer = Timer.new()
	_clock_timer.wait_time = 15.0
	_clock_timer.timeout.connect(refresh_clock)
	add_child(_clock_timer)
	Settings.changed.connect(refresh_clock)
	refresh_clock()

func refresh_clock() -> void:
	if _clock == null:
		return
	var on := bool(Settings.opt("clock"))
	_clock.visible = on
	if on:
		_clock.text = Time.get_time_string_from_system().substr(0, 5)
		if _clock_timer.is_stopped():
			_clock_timer.start()
	elif not _clock_timer.is_stopped():
		_clock_timer.stop()

func clock_text() -> String:
	return _clock.text if _clock != null and _clock.visible else ""

# 143, 144: o toque longo explica qualquer ícone e o «modo explicar» faz cada toque explicar em vez de agir.
var explain_mode := false
var _explain_pill: Control
var _explain_swallow := false
var _lp_id := 0
var _lp_pos := Vector2.ZERO
var _lp_overlays := 0
var _balloon: Control

func set_explain_mode(on: bool) -> void:
	explain_mode = on
	if _alive(_explain_pill):
		_explain_pill.queue_free()
	_explain_pill = null
	if not on:
		return
	var pill := PanelContainer.new()
	pill.name = "ExplainPill"
	pill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pill.add_theme_stylebox_override("panel", UiKit.flat(Color(0.2, 0.14, 0.32, 0.96), 16, UiKit.GOLD, 2, 8))
	var l := UiKit.label(tr("? MODO EXPLICAR · toca aqui para sair"), 16, UiKit.GOLD)
	pill.add_child(l)
	_layer.add_child(pill)
	_explain_pill = pill
	await get_tree().process_frame
	if _alive(pill):
		pill.reset_size()
		var vp := get_viewport().get_visible_rect().size
		pill.position = Vector2((vp.x - pill.size.x) / 2.0, vp.y - pill.size.y - 40.0)

func _alive(n) -> bool:
	return n != null and is_instance_valid(n) and not n.is_queued_for_deletion()

## true = o toque foi para a explicação (não chega ao jogo).
func _explain_input(event: InputEvent) -> bool:
	if not (event is InputEventMouseButton or event is InputEventMouseMotion):
		return false
	if event is InputEventMouseMotion:
		if _lp_id > 0 and (event as InputEventMouseMotion).position.distance_to(_lp_pos) > Settings.drag_px():
			_lp_id += 1   # mexeu: deixa de ser um toque longo
		return false
	var mb := event as InputEventMouseButton
	if mb.button_index != MOUSE_BUTTON_LEFT:
		return false
	if mb.pressed:
		if _alive(_balloon):
			_balloon.queue_free()
		if explain_mode:
			if _alive(_explain_pill) and _explain_pill.get_global_rect().grow(8.0).has_point(mb.position):
				set_explain_mode(false)
				_explain_swallow = true
				return true
			var tip := tip_at(mb.position)
			show_balloon(String(tip.get("text", "")) if not tip.is_empty() else tr("Aqui não há nada para explicar."), mb.position)
			_explain_swallow = true
			return true
		_lp_id += 1
		_lp_pos = mb.position
		_lp_overlays = _open_overlays()
		get_tree().create_timer(maxf(0.5, Settings.long_press_time() + 0.12)).timeout.connect(_long_explain.bind(_lp_id))
		return false
	if _explain_swallow:
		_explain_swallow = false
		return true
	_lp_id += 1
	return false

func _long_explain(id: int) -> void:
	if id != _lp_id or _open_overlays() != _lp_overlays or explain_mode:
		return
	var tip := tip_at(_lp_pos)
	if tip.is_empty() or tip.get("node") is CardView or bool((tip.get("node") as Node).has_meta("own_long_press")):
		return
	# 0.20.0 (A1): segurar para ler não carrega no botão. O largar não se engole (o GUI ficava com o botão preso e o
	# toque seguinte ia ter a ele): cancela-se o toque, como a lista faz quando começa a deslizar.
	var b := button_at(_lp_pos)
	if b != null:
		b.notification(Control.NOTIFICATION_SCROLL_BEGIN)
	show_balloon(String(tip["text"]), _lp_pos)

## O controlo por baixo do dedo que tem explicação (tooltip) e o texto dela ({} se não houver).
func tip_at(pos: Vector2) -> Dictionary:
	var roots: Array = []
	var ov := overlay_layer.get_children().filter(func(c): return c is Control and (c as Control).visible and not c.is_queued_for_deletion())
	if not ov.is_empty():
		roots.append(ov[ov.size() - 1])
	elif get_tree().current_scene != null:
		roots.append(get_tree().current_scene)
	var was := real_mouse
	real_mouse = true   # as cartas e as relíquias só se explicam com «rato»
	var out := {}
	for r in roots:
		out = _tip_in(r, pos)
		if not out.is_empty():
			break
	real_mouse = was
	return out

func _tip_in(n: Node, pos: Vector2) -> Dictionary:
	if n is CanvasItem and not (n as CanvasItem).visible:
		return {}
	var kids := n.get_children()
	for i in range(kids.size() - 1, -1, -1):
		var r := _tip_in(kids[i], pos)
		if not r.is_empty():
			return r
	if n is Control:
		var c := n as Control
		if c.mouse_filter != Control.MOUSE_FILTER_IGNORE and c.get_global_rect().has_point(pos):
			var t := c.get_tooltip(c.get_global_transform().affine_inverse() * pos)
			if t.strip_edges() != "":
				return {"node": c, "text": t}
	return {}

## Um balão com a explicação, junto ao dedo (fecha ao tocar outra vez ou em 3 s).
func show_balloon(text: String, pos: Vector2) -> void:
	if text.strip_edges() == "":
		return
	if _alive(_balloon):
		_balloon.queue_free()
	var b := PanelContainer.new()
	b.name = "ExplainBalloon"
	b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_theme_stylebox_override("panel", UiKit.flat(Color(0.97, 0.94, 0.88, 0.98), 12, Color(0.3, 0.2, 0.38), 2, 10))
	var l := UiKit.label(text, roundi(16 * Settings.menu_text_scale()), Color(0.12, 0.08, 0.16), true)
	l.custom_minimum_size.x = 260
	b.add_child(l)
	_layer.add_child(b)
	_balloon = b
	Sfx.select()
	await get_tree().process_frame
	if not _alive(b):
		return
	l.custom_minimum_size.x = minf(420.0, maxf(160.0, l.get_minimum_size().x))
	b.reset_size()
	var vp := get_viewport().get_visible_rect().size
	b.position = Vector2(clampf(pos.x - b.size.x / 2.0, 8.0, vp.x - b.size.x - 8.0), clampf(pos.y - b.size.y - 28.0, 8.0, vp.y - b.size.y - 8.0))
	var tw := b.create_tween()
	tw.tween_interval(maxf(3.0, Settings.toast_seconds(3.0)) if Settings.toast_seconds(3.0) > 0.0 else 30.0)
	tw.tween_property(b, "modulate:a", 0.0, 0.25)
	tw.tween_callback(b.queue_free)

## 145: a página do Como Jogar que fala do ecrã onde estás.
const HELP_FOR := {"Battle": "A CASCATA", "Map": "O MAPA", "Shop": "LOJA", "Collection": "TIPOS DE CARTA", "Builder": "NÍVEIS DE BARALHO",
	"Campaign": "CAMPANHA", "Tower": "MODOS", "Event": "O MAPA", "Loot": "BOSSES", "Draft": "TIPOS DE CARTA", "Talents": "ESCOLA, DICAS E TALENTOS",
	"Stats": "ESTATÍSTICAS, CÓDIGOS E PARTILHA", "Main": "OBJETIVO", "Saga": "CAMPANHA"}

func help_title() -> String:
	var sc := get_tree().current_scene
	return String(HELP_FOR.get(String(sc.name) if sc != null else "", "OBJETIVO"))

func open_help() -> void:
	if top_overlay() is HowToPlay:
		return
	Sfx.select()
	HowToPlay.open_at(help_title())


# --- 0.19.0 (secção 6): tempo de jogo, lembrete de pausa, limite, cronómetro ---

const RUN_SCENE_NAMES := ["Battle", "Map", "Shop", "Event", "Loot", "Tower"]
var session_secs := 0.0
var session_runs := 0
var _break_shown_at := 0.0
var _limit_shown := false
var _speed_label: Label
var _speed_acc := 0.0

## 0.19.0 (299): está numa cena da run (batalha, mapa, loja, evento…)?
func in_run() -> bool:
	return is_inside_tree() and _in_run_scene()

func _in_run_scene() -> bool:
	var sc := get_tree().current_scene
	return sc != null and String(sc.name) in RUN_SCENE_NAMES and GameState.puzzle_id == ""

func _tick_session(delta: float) -> void:
	var d := delta / maxf(0.01, Engine.time_scale)
	session_secs += d
	var in_run := _in_run_scene()
	GameState.tick_time(d, in_run)
	_speed_acc += d
	if _speed_acc >= 0.5:
		_speed_acc = 0.0
		_refresh_speedrun(in_run)

## 190: o cronómetro da run (opção), no canto de baixo à esquerda.
func _refresh_speedrun(in_run: bool) -> void:
	var on := bool(Settings.opt("speedrun")) and in_run and not GameState.deck.is_empty()
	if not on:
		if _speed_label != null:
			_speed_label.visible = false
		return
	if _speed_label == null:
		_speed_label = Label.new()
		_speed_label.name = "Speedrun"
		_speed_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_speed_label.add_theme_font_size_override("font_size", 14)
		_speed_label.add_theme_color_override("font_color", Color(1.0, 0.86, 0.5, 0.85))
		_speed_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
		_speed_label.add_theme_constant_override("outline_size", 4)
		_layer.add_child(_speed_label)
		_speed_label.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
		_speed_label.offset_left = 10.0
		_speed_label.offset_top = -20.0
		_speed_label.offset_right = 200.0
		_speed_label.offset_bottom = -2.0
	_speed_label.visible = true
	var t := GameState.run_secs()
	var best := GameState.speed_best(GameState.mode)
	_speed_label.text = "⏱ %02d:%02d" % [t / 60, t % 60] + (("   " + tr("recorde %s") % ("%02d:%02d" % [best / 60, best % 60])) if best > 0 else "")

func speedrun_text() -> String:
	return _speed_label.text if _speed_label != null and _speed_label.visible else ""

## 172, 195: o lembrete de pausa e o limite que escolheste (quando o ecrã muda, nunca a meio de uma jogada).
func _check_session() -> void:
	if has_overlay() or not is_inside_tree():
		return
	var limit := String(Settings.opt("self_limit"))
	var why := ""
	if limit != "off" and not _limit_shown:
		if limit.begins_with("runs") and session_runs >= int(limit.substr(4)):
			why = tr("Chegaste ao limite que escolheste: %d run(s) nesta sessão.") % int(limit.substr(4))
		elif limit.begins_with("min") and session_secs >= float(limit.substr(3)) * 60.0:
			why = tr("Chegaste ao limite que escolheste: %d minutos de jogo.") % int(limit.substr(3))
		if why != "":
			_limit_shown = true
	var every := int(Settings.opt("break_reminder"))
	if why == "" and every > 0 and session_secs - _break_shown_at >= every * 60.0:
		_break_shown_at = session_secs
		why = tr("Já jogas há %s. Que tal uma pausa?") % GameState.fmt_duration(int(session_secs))
	if why != "":
		break_reminder(why)

func break_reminder(text: String) -> Control:
	var o := Control.new()
	o.name = "BreakReminder"
	o.set_anchors_preset(Control.PRESET_FULL_RECT)
	o.mouse_filter = Control.MOUSE_FILTER_STOP
	o.add_child(UiKit.dim(0.8))
	show_overlay(o)
	var body := UiKit.window(o, 640, tr("UMA PAUSA?"), Color(0.55, 0.8, 1.0), func(): UiKit.close_animated(o))
	var l := UiKit.label(text + " " + tr("Está tudo gravado."), 19, Color.WHITE, true)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	body.add_child(l)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 14)
	body.add_child(row)
	var go_on := UiKit.button(tr("CONTINUAR"), 54, 20)
	go_on.custom_minimum_size.x = 220
	go_on.pressed.connect(func(): Sfx.select(); UiKit.close_animated(o))
	row.add_child(go_on)
	var quit := UiKit.button(tr("GUARDAR E SAIR"), 54, 20, UiKit.PRIMARY)
	quit.name = "SaveQuit"
	quit.custom_minimum_size.x = 240
	quit.pressed.connect(func():
		Sfx.select()
		GameState.save_progress()
		get_tree().quit())
	row.add_child(quit)
	UiKit.pop_in(body.get_meta("panel"))
	return o
