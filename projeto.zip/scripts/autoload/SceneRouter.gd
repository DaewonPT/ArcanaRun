extends Node
## Troca de cenas num único sítio, com fundido a preto entre elas.
## Também guarda os "overlays" (pausa, configurações, carta em grande, grimório): painéis que
## ficam por cima da cena atual numa CanvasLayer própria, sem a destruir.

const SCENES := {
	"main": "res://scenes/main/Main.tscn",
	"campaign": "res://scenes/campaign/Campaign.tscn",
	"howto": "res://scenes/ui/HowToPlay.tscn",
	"battle": "res://scenes/battle/Battle.tscn",
	"shop": "res://scenes/shop/Shop.tscn",
	"event": "res://scenes/event/Event.tscn",
	"run_over": "res://scenes/ui/RunOver.tscn",
}
const FADE := 0.22

var overlay_layer: CanvasLayer
var _layer: CanvasLayer
var _fade: ColorRect
var _busy := false

func _ready() -> void:
	overlay_layer = CanvasLayer.new()
	overlay_layer.layer = 50
	add_child(overlay_layer)
	_layer = CanvasLayer.new()
	_layer.layer = 100
	add_child(_layer)
	_fade = ColorRect.new()
	_fade.color = Color(0.03, 0.02, 0.05, 1)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	_fade.modulate.a = 0.0
	_layer.add_child(_fade)

## Põe um painel por cima de tudo (fica até ele próprio se libertar com queue_free).
func show_overlay(node: Control) -> void:
	overlay_layer.add_child(node)

func has_overlay() -> bool:
	for c in overlay_layer.get_children():
		if not c.is_queued_for_deletion():
			return true
	return false

## O painel mais acima (o único que deve reagir ao botão "retroceder" do Android).
func top_overlay() -> Control:
	var top: Control = null
	for c in overlay_layer.get_children():
		if not c.is_queued_for_deletion():
			top = c
	return top

func close_overlays() -> void:
	for c in overlay_layer.get_children():
		c.queue_free()

func go(scene_key: String) -> void:
	var path: String = SCENES.get(scene_key, "")
	if path == "":
		push_error("SceneRouter: cena desconhecida: " + scene_key)
		return
	if _busy:
		return
	_busy = true
	close_overlays()
	# Sem ecrã (testes headless) não há nada para fundir: muda logo.
	var fade := Settings.dur(FADE)
	if DisplayServer.get_name() == "headless" or fade <= 0.0:
		get_tree().change_scene_to_file(path)
		_busy = false
		return
	_fade.mouse_filter = Control.MOUSE_FILTER_STOP
	var tw := create_tween()
	tw.tween_property(_fade, "modulate:a", 1.0, fade)
	await tw.finished
	get_tree().change_scene_to_file(path)
	await get_tree().process_frame
	await get_tree().process_frame
	var tw2 := create_tween()
	tw2.tween_property(_fade, "modulate:a", 0.0, fade)
	await tw2.finished
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_busy = false
