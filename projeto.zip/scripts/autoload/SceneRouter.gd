extends Node
## Troca de cenas num único sítio, com fundido a preto entre elas.
## Também guarda os "overlays" (pausa, configurações, carta em grande, grimório): painéis que
## ficam por cima da cena atual numa CanvasLayer própria, sem a destruir.

const SCENES := {
	"main": "res://scenes/main/Main.tscn",
	"campaign": "res://scenes/campaign/Campaign.tscn",
	"howto": "res://scenes/ui/HowToPlay.tscn",
	"battle": "res://scenes/battle/Battle.tscn",
	"shop": "res://scenes/shop/Shop.tscn",
	"event": "res://scenes/event/Event.tscn",
	"run_over": "res://scenes/ui/RunOver.tscn",
	"stats": "res://scenes/ui/StatsScreen.tscn",
	"collection": "res://scenes/ui/Collection.tscn",
	"builder": "res://scenes/builder/DeckBuilder.tscn",
	"map": "res://scenes/map/Map.tscn",
	"draft": "res://scenes/draft/Draft.tscn",
	"puzzles": "res://scenes/puzzles/Puzzles.tscn",
	"loot": "res://scenes/loot/Loot.tscn",
}
const FADE := 0.22

var overlay_layer: CanvasLayer
var _layer: CanvasLayer
var _fade: ColorRect
var _busy := false
var _tilt := Vector2.ZERO
var _hitstop_id := 0

func _ready() -> void:
	overlay_layer = CanvasLayer.new()
	overlay_layer.layer = 50
	add_child(overlay_layer)
	_layer = CanvasLayer.new()
	_layer.layer = 100
	add_child(_layer)
	_fade = ColorRect.new()
	_fade.color = Color(0.03, 0.02, 0.05, 1)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	_fade.modulate.a = 0.0
	_layer.add_child(_fade)
	EventBus.achievement_unlocked.connect(_on_achievement)

## Inclinação do telemóvel para o brilho holográfico das cartas (suavizada).
func _process(delta: float) -> void:
	var a := Input.get_accelerometer()
	var target := Vector2.ZERO
	if a != Vector3.ZERO:
		target = Vector2(clampf(a.x / 9.8, -1.0, 1.0), clampf(a.y / 9.8, -1.0, 1.0))
	_tilt = _tilt.lerp(target, clampf(delta * 4.0, 0.0, 1.0))
	CardView.set_foil_tilt(_tilt)

## Hit-stop: congela o jogo por instantes num golpe grande (não corre no modo instantâneo).
## Vive aqui (autoload) para o time_scale voltar sempre a 1, mesmo que a cena mude a meio.
func hit_stop(seconds: float = 0.08, scale: float = 0.05) -> void:
	if Settings.anim_scale() <= 0.0:
		return
	_hitstop_id += 1
	var id := _hitstop_id
	Engine.time_scale = scale
	await get_tree().create_timer(seconds, true, false, true).timeout
	if id == _hitstop_id:
		Engine.time_scale = 1.0

func _on_achievement(id: String) -> void:
	for a in CardDB.achievements:
		if String(a.get("id", "")) == id:
			toast("★ " + tr("Conquista: %s") % tr(String(a.get("name", id))))
			return

## Aviso curto no topo do ecrã (conquistas, conteúdo novo), por cima de tudo.
func toast(text: String, seconds: float = 2.8) -> void:
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.13, 0.11, 0.19, 0.96), 12, UiKit.GOLD, 2, 12))
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var label := UiKit.label(text, 20, UiKit.GOLD)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	panel.add_child(label)
	_layer.add_child(panel)
	await get_tree().process_frame
	if not is_instance_valid(panel):
		return
	var vp := get_viewport().get_visible_rect().size
	panel.global_position = Vector2((vp.x - panel.size.x) / 2.0, 12.0 - panel.size.y)
	var tw := create_tween()
	tw.tween_property(panel, "global_position:y", 70.0, Settings.dur(0.3)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tw.tween_interval(seconds)
	tw.tween_property(panel, "modulate:a", 0.0, Settings.dur(0.4))
	tw.tween_callback(panel.queue_free)
	Sfx.select()

## Põe um painel por cima de tudo (fica até ele próprio se libertar com queue_free).
func show_overlay(node: Control) -> void:
	overlay_layer.add_child(node)

func has_overlay() -> bool:
	for c in overlay_layer.get_children():
		if not c.is_queued_for_deletion():
			return true
	return false

## O painel mais acima (o único que deve reagir ao botão "retroceder" do Android).
func top_overlay() -> Control:
	var top: Control = null
	for c in overlay_layer.get_children():
		if not c.is_queued_for_deletion():
			top = c
	return top

func close_overlays() -> void:
	for c in overlay_layer.get_children():
		c.queue_free()

## Há uma troca de cena a decorrer (go() ignora pedidos até acabar).
func is_busy() -> bool:
	return _busy

func go(scene_key: String) -> void:
	var path: String = SCENES.get(scene_key, "")
	if path == "":
		push_error("SceneRouter: cena desconhecida: " + scene_key)
		return
	if _busy:
		return
	_busy = true
	_hitstop_id += 1
	Engine.time_scale = 1.0
	close_overlays()
	# Sem ecrã (testes headless) não há nada para fundir: muda logo.
	var fade := Settings.dur(FADE)
	if DisplayServer.get_name() == "headless" or fade <= 0.0:
		get_tree().change_scene_to_file(path)
		_busy = false
		return
	_fade.mouse_filter = Control.MOUSE_FILTER_STOP
	var tw := create_tween()
	tw.tween_property(_fade, "modulate:a", 1.0, fade)
	await tw.finished
	get_tree().change_scene_to_file(path)
	await get_tree().process_frame
	await get_tree().process_frame
	var tw2 := create_tween()
	tw2.tween_property(_fade, "modulate:a", 0.0, fade)
	await tw2.finished
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_busy = false
