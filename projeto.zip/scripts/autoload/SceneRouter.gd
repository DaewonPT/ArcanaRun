extends Node
## Troca de cenas num único sítio, com uma carta a virar no meio do ecrã (0.10.0; com "reduzir
## movimento" volta ao fundido a preto simples).
## Também guarda os "overlays" (pausa, configurações, carta em grande, grimório): painéis que
## ficam por cima da cena atual numa CanvasLayer própria, sem a destruir.

const SCENES := {
	"main": "res://scenes/main/Main.tscn",
	"campaign": "res://scenes/campaign/Campaign.tscn",
	"howto": "res://scenes/ui/HowToPlay.tscn",
	"battle": "res://scenes/battle/Battle.tscn",
	"shop": "res://scenes/shop/Shop.tscn",
	"event": "res://scenes/event/Event.tscn",
	"run_over": "res://scenes/ui/RunOver.tscn",
	"stats": "res://scenes/ui/StatsScreen.tscn",
	"collection": "res://scenes/ui/Collection.tscn",
	"builder": "res://scenes/builder/DeckBuilder.tscn",
	"map": "res://scenes/map/Map.tscn",
	"draft": "res://scenes/draft/Draft.tscn",
	"puzzles": "res://scenes/puzzles/Puzzles.tscn",
	"loot": "res://scenes/loot/Loot.tscn",
	"saga": "res://scenes/saga/Saga.tscn",
	"challenges": "res://scenes/challenges/Challenges.tscn",
	"training": "res://scenes/training/Training.tscn",
	"school": "res://scenes/school/School.tscn",
	"talents": "res://scenes/talents/Talents.tscn",
}
const FLIP_CARD := Vector2(220, 316)
const FADE := 0.22

var overlay_layer: CanvasLayer
var _layer: CanvasLayer
var _fade: ColorRect
var _busy := false
var _tilt := Vector2.ZERO
var _hitstop_id := 0

func _ready() -> void:
	overlay_layer = CanvasLayer.new()
	overlay_layer.layer = 50
	add_child(overlay_layer)
	_layer = CanvasLayer.new()
	_layer.layer = 100
	add_child(_layer)
	_fade = ColorRect.new()
	_fade.color = Color(0.03, 0.02, 0.05, 1)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	_fade.modulate.a = 0.0
	_layer.add_child(_fade)
	EventBus.achievement_unlocked.connect(_on_achievement)
	EventBus.content_unlocked.connect(_on_content_unlocked)
	EventBus.run_saved.connect(_on_run_saved)
	get_tree().node_added.connect(_on_node_added)

## Listas com scroll no telemóvel: um painel, botão ou carta com MOUSE_FILTER_STOP "agarra" o dedo e a
## lista não desliza (no telemóvel o ScrollContainer só desliza se o arrastar lhe chegar). Tudo o que entra
## dentro de um ScrollContainer passa a MOUSE_FILTER_PASS: o toque chega ao botão/carta e o arrastar chega
## à lista, que avisa os filhos (NOTIFICATION_SCROLL_BEGIN) para cancelarem o toque. Ficam de fora os
## campos de texto, barras e cursores, as relíquias, e as listas marcadas com a meta "keep_child_input"
## (a Arena da batalha, onde arrastar uma criatura muda a ordem).
func _on_node_added(n: Node) -> void:
	if n is BaseButton and not n.has_meta("no_press_fx"):
		_hook_press_fx(n as BaseButton)
	if not (n is Control) or (n as Control).mouse_filter != Control.MOUSE_FILTER_STOP:
		return
	if n is ScrollContainer or n is LineEdit or n is TextEdit or n is Range or n is RelicView:
		return
	var p := n.get_parent()
	var depth := 0
	while p != null and depth < 14:
		if p is ScrollContainer:
			if not p.has_meta("keep_child_input"):
				(n as Control).mouse_filter = Control.MOUSE_FILTER_PASS
			return
		p = p.get_parent()
		depth += 1

## 0.16.0 (V60): os botões encolhem um pouco ao toque e voltam com um ressalto; os marcados com a meta "haptic"
## (os mais importantes da loja, do mapa e dos menus) vibram um instante. Sem movimento reduzido.
func _hook_press_fx(b: BaseButton) -> void:
	if b.button_down.is_connected(_on_btn_down):
		return
	b.button_down.connect(_on_btn_down.bind(b))
	b.button_up.connect(_on_btn_up.bind(b))

func _on_btn_down(b: BaseButton) -> void:
	if not is_instance_valid(b) or b.disabled:
		return
	if b.has_meta("haptic"):
		Settings.vibrate(14)
	if not Settings.motion_ok() or b.size.x > 700.0:
		return
	_kill_press(b)
	b.pivot_offset = b.size / 2.0
	var tw := b.create_tween()
	tw.tween_property(b, "scale", Vector2(0.94, 0.94), 0.06).set_ease(Tween.EASE_OUT)
	b.set_meta("press_tw", tw)

func _on_btn_up(b: BaseButton) -> void:
	if not is_instance_valid(b) or not b.is_inside_tree():
		return
	if b.scale.is_equal_approx(Vector2.ONE) and not b.has_meta("press_tw"):
		return
	_kill_press(b)
	b.pivot_offset = b.size / 2.0
	var tw := b.create_tween()
	tw.tween_property(b, "scale", Vector2.ONE, 0.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tw.tween_callback(func(): if is_instance_valid(b): b.remove_meta("press_tw"))
	b.set_meta("press_tw", tw)

func _kill_press(b: BaseButton) -> void:
	var old = b.get_meta("press_tw", null)
	if old is Tween and (old as Tween).is_valid():
		(old as Tween).kill()

## Inclinação do telemóvel suavizada (−1 a 1 em cada eixo; zero sem acelerómetro). 0.13.0: a carta em grande usa-a.
func tilt() -> Vector2:
	return _tilt

# --- 0.16.0: desempenho ---
## 72: FPS conforme o momento — nas cenas de jogo (batalha, mapa, loja, eventos) fica a 60 enquanto há toques,
## animações ou arrastos; parado à espera da jogada (1,5 s sem nada) desce para 30. As cenas pedem 60 com
## keep_awake() enquanto animam. Com o limite de 30 FPS (Configurações) ou o modo de desempenho fica sempre a 30.
const IDLE_FPS := 30
const IDLE_AFTER := 1.5
const IDLE_SCENES := ["battle", "map", "shop", "event"]
## 73: os ecrãs sem animação só redesenham quando algo muda (como o editor do Godot).
const LOW_POWER_SCENES := ["collection", "stats", "builder"]
var _awake_until := 0.0
var _idle_fps_on := false

func keep_awake(seconds: float = IDLE_AFTER) -> void:
	_awake_until = maxf(_awake_until, Time.get_ticks_msec() / 1000.0 + seconds)

func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton or event is InputEventScreenTouch or event is InputEventScreenDrag \
			or (event is InputEventMouseMotion and (event as InputEventMouseMotion).button_mask != 0):
		keep_awake()

## O limite de FPS que se quer agora (0 = sem limite).
func wanted_fps() -> int:
	var base := 30 if Settings.performance_mode else (Settings.fps_cap if Settings.fps_cap > 0 else 0)
	if base == 30 or not _idle_fps_on or DisplayServer.get_name() == "headless":
		return base
	return IDLE_FPS if Time.get_ticks_msec() / 1000.0 > _awake_until else base

func _apply_scene_power(scene_key: String) -> void:
	_idle_fps_on = scene_key in IDLE_SCENES
	keep_awake(2.0)
	OS.low_processor_usage_mode = scene_key in LOW_POWER_SCENES and DisplayServer.get_name() != "headless"

## Inclinação do telemóvel para o brilho holográfico das cartas (suavizada).
func _process(delta: float) -> void:
	var fps := wanted_fps()
	if Engine.max_fps != fps:
		Engine.max_fps = fps
	if Settings.performance_mode:
		return   # 0.12.0: sem brilho holográfico a seguir o telemóvel
	var a := Input.get_accelerometer()
	var target := Vector2.ZERO
	if a != Vector3.ZERO:
		target = Vector2(clampf(a.x / 9.8, -1.0, 1.0), clampf(a.y / 9.8, -1.0, 1.0))
	_tilt = _tilt.lerp(target, clampf(delta * 4.0, 0.0, 1.0))
	CardView.set_foil_tilt(_tilt)

## Hit-stop: congela o jogo por instantes num golpe grande (não corre no modo instantâneo).
## Vive aqui (autoload) para o time_scale voltar sempre a 1, mesmo que a cena mude a meio.
func hit_stop(seconds: float = 0.08, scale: float = 0.05) -> void:
	if not Settings.motion_ok():
		return
	_hitstop_id += 1
	var id := _hitstop_id
	Engine.time_scale = scale
	await get_tree().create_timer(seconds, true, false, true).timeout
	if id == _hitstop_id:
		Engine.time_scale = 1.0

func _on_achievement(id: String) -> void:
	for a in CardDB.achievements:
		if String(a.get("id", "")) == id:
			toast("★ " + tr("Conquista: %s") % tr(String(a.get("name", id))), 2.8, false)
			return

## Conteúdo novo desbloqueado (carta mítica, relíquia, planeswalker, costas, moldura): segundo aviso.
func _on_content_unlocked(kind: String, id: String) -> void:
	await get_tree().create_timer(1.6).timeout
	toast("✦ " + Stats.unlock_label({"type": kind, "id": id}, "Desbloqueaste %s: %s"), 3.0, false)

## Aviso curto no topo do ecrã (conquistas, conteúdo novo), por cima de tudo.
## 0.12.0: vários avisos ao mesmo tempo (o fim de uma run pode trazer 3 ou 4 conquistas) ficam em fila,
## uns por baixo dos outros (no máximo TOAST_MAX de cada vez), em vez de se taparem.
const TOAST_MAX := 3
var _toast_queue: Array = []        # [texto, segundos] à espera
var _toast_slots: Array = [null, null, null]

func toast(text: String, seconds: float = 2.8, sound: bool = true) -> void:
	_toast_queue.append([text, seconds, sound])
	_pump_toasts()

## Avisos à espera e no ecrã (para os testes).
func toast_count() -> int:
	var n := _toast_queue.size()
	for p in _toast_slots:
		if p != null and is_instance_valid(p):
			n += 1
	return n

func _pump_toasts() -> void:
	while not _toast_queue.is_empty():
		var slot := -1
		for i in TOAST_MAX:
			if _toast_slots[i] == null or not is_instance_valid(_toast_slots[i]):
				slot = i
				break
		if slot < 0:
			return
		var t: Array = _toast_queue.pop_front()
		_show_toast(String(t[0]), float(t[1]), slot, bool(t[2]))

func _show_toast(text: String, seconds: float, slot: int, sound: bool = true) -> void:
	var panel := PanelContainer.new()
	panel.name = "Toast"
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.13, 0.11, 0.19, 0.96), 12, UiKit.GOLD, 2, 12))
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var label := UiKit.label(text, 20, UiKit.GOLD)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	panel.add_child(label)
	_layer.add_child(panel)
	_toast_slots[slot] = panel
	# 0.13.0: um aviso comprido (as dicas das edições e dos Vales) parte-se em linhas, em vez de sair do ecrã.
	var max_label_w := minf(get_viewport().get_visible_rect().size.x - 96.0, 1040.0) - 24.0
	var wrapped := label.get_minimum_size().x > max_label_w
	if wrapped:
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		label.custom_minimum_size.x = max_label_w
	panel.modulate.a = 0.0
	await get_tree().process_frame
	if wrapped and is_instance_valid(panel):
		await get_tree().process_frame   # o texto partido só tem a altura certa um frame depois
	if not is_instance_valid(panel):
		_free_toast_slot(slot, panel)
		return
	panel.modulate.a = 1.0
	var vp := get_viewport().get_visible_rect().size
	# Cada aviso fica por baixo dos que já estão no ecrã (a altura de cada um conta: um aviso de 2 linhas empurra os outros).
	var target_y := 70.0
	for i in slot:
		var above = _toast_slots[i]
		target_y += (above.size.y if above != null and is_instance_valid(above) else panel.size.y) + 8.0
	panel.global_position = Vector2((vp.x - panel.size.x) / 2.0, 12.0 - panel.size.y)
	var tw := create_tween()
	tw.tween_property(panel, "global_position:y", target_y, Settings.dur(0.3)).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
	tw.tween_interval(seconds)
	tw.tween_property(panel, "modulate:a", 0.0, Settings.dur(0.4))
	tw.tween_callback(func():
		panel.queue_free()
		_free_toast_slot(slot, panel))
	if sound:
		Sfx.select()

func _free_toast_slot(slot: int, panel: Control) -> void:
	if _toast_slots[slot] == panel:
		_toast_slots[slot] = null
	_pump_toasts()

## Põe um painel por cima de tudo (fica até ele próprio se libertar com queue_free).
func show_overlay(node: Control) -> void:
	overlay_layer.add_child(node)

## 0.16.0: um overlay a fechar com animação (UiKit.close_animated) já não conta como aberto.
func has_overlay() -> bool:
	for c in overlay_layer.get_children():
		if not c.is_queued_for_deletion() and not c.has_meta("closing"):
			return true
	return false

## O painel mais acima (o único que deve reagir ao botão "retroceder" do Android).
func top_overlay() -> Control:
	var top: Control = null
	for c in overlay_layer.get_children():
		if not c.is_queued_for_deletion() and not c.has_meta("closing"):
			top = c
	return top

func close_overlays() -> void:
	for c in overlay_layer.get_children():
		c.queue_free()

## Há uma troca de cena a decorrer (go() ignora pedidos até acabar).
func is_busy() -> bool:
	return _busy

func go(scene_key: String) -> void:
	var path: String = SCENES.get(scene_key, "")
	if path == "":
		push_error("SceneRouter: cena desconhecida: " + scene_key)
		return
	if _busy:
		return
	_busy = true
	_hitstop_id += 1
	Engine.time_scale = 1.0
	close_overlays()
	_apply_scene_power(scene_key)
	EventBus.scene_changed.emit(scene_key)
	# Sem ecrã (testes headless) não há nada para fundir: muda logo.
	var fade := Settings.dur(FADE)
	if DisplayServer.get_name() == "headless" or fade <= 0.0:
		get_tree().change_scene_to_file(path)
		_busy = false
		return
	_fade.mouse_filter = Control.MOUSE_FILTER_STOP
	# Uma carta (com as costas escolhidas) vira no centro enquanto o ecrã escurece.
	var card: CardBack = null
	if Settings.motion_ok():
		card = CardBack.new()
		card.back_id = Settings.card_back
		card.mouse_filter = Control.MOUSE_FILTER_IGNORE
		card.size = FLIP_CARD
		var vp := get_viewport().get_visible_rect().size
		card.position = (vp - FLIP_CARD) / 2.0
		card.pivot_offset = FLIP_CARD / 2.0
		card.scale = Vector2(0.0, 0.92)
		card.rotation = -0.08
		_layer.add_child(card)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(_fade, "modulate:a", 1.0, fade)
	if card != null:
		tw.tween_property(card, "scale", Vector2.ONE, fade * 1.2).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
		tw.tween_property(card, "rotation", 0.0, fade * 1.2)
	await tw.finished
	get_tree().change_scene_to_file(path)
	await get_tree().process_frame
	await get_tree().process_frame
	var tw2 := create_tween().set_parallel(true)
	tw2.tween_property(_fade, "modulate:a", 0.0, fade)
	if card != null:
		tw2.tween_property(card, "scale", Vector2(0.0, 0.92), fade).set_ease(Tween.EASE_IN)
		tw2.tween_property(card, "rotation", 0.08, fade)
	await tw2.finished
	if card != null and is_instance_valid(card):
		card.queue_free()
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_busy = false

# --- 0.13.0: aviso discreto quando a run é gravada ("✓ Guardado em Jogo 1"), em cima à direita ---

const SAVE_BADGE_GAP_MS := 20000   # no máximo um aviso a cada 20 s (a batalha grava em cada turno)
var _save_badge: Control
var _last_save_badge_ms := -SAVE_BADGE_GAP_MS

func _on_run_saved(slot: int) -> void:
	var now := Time.get_ticks_msec()
	if now - _last_save_badge_ms < SAVE_BADGE_GAP_MS or not is_inside_tree():
		return
	_last_save_badge_ms = now
	if _save_badge != null and is_instance_valid(_save_badge):
		_save_badge.queue_free()
	var panel := PanelContainer.new()
	panel.name = "SaveBadge"
	panel.add_theme_stylebox_override("panel", UiKit.flat(Color(0.1, 0.09, 0.15, 0.88), 10, Color(0.45, 0.85, 0.55, 0.8), 1, 6))
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(row)
	var icon := CardIcon.new("check", Color(0.5, 0.9, 0.6), 16.0)
	icon.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(icon)
	row.add_child(UiKit.label(tr("Guardado em «%s»") % GameState.slot_name(slot), 14, Color(0.85, 0.95, 0.88)))
	_layer.add_child(panel)
	_save_badge = panel
	panel.modulate.a = 0.0
	await get_tree().process_frame
	if not is_instance_valid(panel):
		return
	var vp := get_viewport().get_visible_rect().size
	panel.global_position = Vector2(vp.x - panel.size.x - 14.0, 62.0)   # por baixo do ouro, longe da mão
	var tw := create_tween()
	tw.tween_property(panel, "modulate:a", 1.0, 0.25)
	tw.tween_interval(1.6)
	tw.tween_property(panel, "modulate:a", 0.0, 0.5)
	tw.tween_callback(func():
		if is_instance_valid(panel):
			panel.queue_free())
