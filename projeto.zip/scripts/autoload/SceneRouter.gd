extends Node
## Troca de cenas num único sítio, para que nenhuma cena precise de saber o caminho das outras.

const SCENES := {
	"main": "res://scenes/main/Main.tscn",
	"battle": "res://scenes/battle/Battle.tscn",
	"shop": "res://scenes/shop/Shop.tscn",
	"run_over": "res://scenes/ui/RunOver.tscn",
}

func go(scene_key: String) -> void:
	var path: String = SCENES.get(scene_key, "")
	if path == "":
		push_error("SceneRouter: cena desconhecida: " + scene_key)
		return
	get_tree().change_scene_to_file(path)
