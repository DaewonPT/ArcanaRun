# Zero-Sum — instruções para o Claude Code

Jogo mobile de cartas do Paulo (Magic: The Gathering × Balatro), em **Godot 4.3** (GDScript), para **Android**, sempre na **horizontal** (1280×720 de base, `stretch mode = canvas_items`, `aspect = expand`). Pacote Android `pt.zerosum.game`. O nome antigo era "Arcana Run" (o repositório do GitHub ainda se chama `DaewonPT/ArcanaRun`).

O `README.md` explica o jogo e o código em pormenor (DSL de efeitos, cascata, equilíbrio, tradução, atualizações). Ler antes de mexer.

## Como falar com o Paulo
- Português de Portugal, a tratar por "tu". Respostas curtas, com passos exatos. Ele não é técnico.
- Patch notes no formato de WhatsApp (ver "Nota para o WhatsApp"), só da versão nova.

## Regras fixas (do Paulo)
- **Commits no GitHub** (ArcanaRun e zerosum-updates): título e descrição em inglês, baseados na nota da versão, **sem identificar nem associar o assistente**: sem "Co-Authored-By", sem menção a IA, sem links de sessões.
- **Downloads** (APK, artefactos do Actions, Godot, tipos de letra…): só depois de o Paulo autorizar, dizendo o nome, a origem e o tamanho.
- **Chave privada** `zerosum-atualizacoes-privada.pem`: nunca no projeto, nos zips nem no GitHub. Está em `..\Atualizações de Conteúdo\Chave Privada\`.
- **Envio para o GitHub**: pelo navegador (página de upload), como até agora. Se quiseres usar git, pergunta primeiro ao Paulo.
- **Publicar** uma versão no GitHub: só depois de o Paulo dizer que sim.
- Apagar repositórios, Releases ou ficheiros no GitHub é com o Paulo. Nunca escrever palavras-passe ou tokens em campos.
- O repositório fica com o nome `ArcanaRun`: as apps instaladas só aceitam atualizações com links desse nome (`AppUpdate.APK_PREFIX`).
- A Play Store é a última coisa a fazer: não a sugerir por agora. Sem ranking online nem semente diária.
- Línguas: só português e inglês.
- Arte: designs originais, nunca personagens de Magic. Prompts para o Gemini: no formato de folhas (como no SCAM Operator), um prompt por parte, no máximo 10 imagens por prompt.

## Pastas do Paulo (`C:\Users\PC\Desktop\PROJETOS\Zero-Sum\`)
```
Zero-Sum/
├── Código/                   este projeto (abrir aqui o Claude Code)
├── Projeto/                  Versão Atual/projeto_vX.Y.Z.zip · Versões Anteriores/
├── Ficheiro APK/             Versão Atual/ZeroSum_vX.Y.Z.apk · Versões Anteriores/
├── Atualizações de Conteúdo/ zerosum-updates-conteudo-vN.zip · Chave Privada/
├── Arte/                     prompts e imagens do Gemini, por parte
└── Documentos/
```
- Em "Versão Atual" fica só a versão nova; a anterior passa para "Versões Anteriores" (sem escrever por cima de nada).
- O `projeto_vX.Y.Z.zip` é sempre o projeto completo (com as ilustrações).

## Modelo de jogo (não mudar sem o Paulo pedir)
- Tabuleiro com criaturas, mana e bloqueio (Magic) + dano de ataque numa **cascata Poder × Mult**, com relíquias a disparar uma a uma (Balatro).
- Escala: **Poder 10–100 por carta**. Cartas em `data/cards.json` (300 do "Mana Cascade" em 18 baralhos, mais extras a partir de c301).
- Prioridades: conteúdo e progressão, apresentação, distribuição, jogabilidade. O combinado para as próximas versões está no README ("Próximos passos sugeridos").

## Mapa do código
- `scripts/autoload/` (por esta ordem): EventBus → ContentUpdate → CardDB → Settings → GameState → Stats → SceneRouter → Sfx → Music → AppUpdate.
- `scripts/core/`: `EffectResolver.gd` (DSL de efeitos, formações e toda a cascata), `Cascade.gd`, `BattleManager.gd`, `EnemyAbilities.gd`.
- `scenes/` (battle, map, shop, loot, draft, builder, campaign, event, puzzles, main, ui, saga, school, …), `scripts/ui/` (CardIcon, CardGlass, CardArt, TriBatch, UiKit, ArtLib, MenuBackdrop, PlaqueDeco…), `assets/` (fonts, shaders, icons, audio, art, `theme.tres`).
- `data/*.json`: cartas, baralhos, relíquias, formações, inimigos, campanha, eventos, conquistas, etc. Traduções em `i18n/en.json` e `i18n/howto.json`.
- `tools/`:
  - `convert_cards.py` gera `cards.json`/`decks.json` a partir de `mana_cascade_300.txt` (cartas mudam-se aqui, nunca à mão no JSON); depois `make_cards_en.py`.
  - `make_en_json.py` gera `en.json` e diz o que falta traduzir (`tools/en_0120.py`, `tools/en_0130.py`, `tools/en_0140.py` têm os textos das versões recentes).
  - `import_art.py` / `make_art_prompts.py` / `art_sheets.json`: ilustrações do Gemini.
  - `make_icons.py`: ícone e splash a partir de `tools/brand/` (precisa do Playwright).
  - `make_manifest.py`: pacote de conteúdo assinado.
  - `make_audio.py`: música e efeitos.

## Como trabalhar
1. Ler o README e os ficheiros envolvidos; seguir a organização que já existe.
2. **Conteúdo em dados** (JSON), nunca escrito à mão no GDScript. Cartas novas: Poder 10–100 e baralho atribuído.
3. **Cascata num único sítio** (`EffectResolver.build_attack_cascade` → `Cascade`). Ordem fixa: criaturas pela ordem do tabuleiro → feitiços do turno → formações → cartas [Na Mão] → relíquias da esquerda para a direita → planeswalker → clima.
4. **UI para o dedo, na horizontal**: botões ≥ 48 px; nada interativo junto à margem de baixo; títulos com `theme_type_variation = TitleLabel` (Lora), o resto em Inter.
5. **GDScript**: tipagem estática, sinais (EventBus) em vez de polling, `@onready` com `%Nome`.
6. **Tradução**: as chaves são o próprio texto em português; `tr("molde %d") % valor`. Cada texto novo (também nos JSON) precisa da entrada em inglês; correr `python3 tools/make_en_json.py` (não pode ficar nada "SEM TRADUÇÃO").
7. Sinal `EventBus.cascade_started`: só a UI da batalha o pode ouvir (o BattleManager espera pela UI quando há ouvintes). A música usa `cascade_presented`.

## Testar
Precisa do Godot 4.3 (para Windows: `Godot_v4.3-stable_win64.exe.zip` das Releases do `godotengine/godot` no GitHub — pedir autorização antes de descarregar). Usar o executável `_console.exe` para ver a saída. Na raiz do projeto:
- Importar (duas vezes na 1.ª vez; os erros de tema da 1.ª são normais): `godot --headless --path . --import --quit`
- **SmokeTest** (demora ~6 min): `godot --headless --path . res://tests/SmokeTest.tscn` — tem de acabar com "SMOKE TEST: OK" e código 0. Cada versão acrescenta os seus `_test_…()` e chama-os no `_ready()`.
- **Balance** (bot com loja): `godot --headless --path . res://tests/Balance.tscn` — comparar com os números do README (0.13.0: 142/160 vitórias no Normal, 89 %).
- **Capturas**: `godot --rendering-method gl_compatibility --path . res://tests/Screenshots.tscn -- --out=<pasta>` (sem `--only` saem as antigas; `--only=0130`, `--only=0130b` para as da 0.13; `--only=0140` para as cartas e o menu da 0.14). Olhar mesmo para as imagens.

Armadilhas do Godot 4.3 já vistas:
- Nós libertados com `queue_free` ainda se desenham mais um frame: ao refazer contentores, `remove_child` antes do `queue_free`.
- `ScrollContainer` com `horizontal_scroll_mode = 0` empurra o layout: usar 3.
- Os números do JSON chegam como float (`1 in [1.0]` é falso): comparar com `int()`.
- Cada `draw_polyline`/`draw_arc` suave (antialiased) são vários comandos de desenho no telemóvel: enfeites com muitas peças vão num `TriBatch` (um comando) e desenham-se uma vez, não a cada frame.
- Arrays `Packed*` passam por cópia: uma função que lhes faz `append` não muda o array de quem a chamou.
- Só ficheiros-recurso entram no APK; `.txt`/`.md` precisam do `include_filter` do `export_presets.cfg`. Pastas com `.gdignore` não são importadas.

## Lançar uma versão (APK)
O repositório público `DaewonPT/ArcanaRun` tem na raiz o `projeto.zip`, o `arte_cartas.zip` e `.github/workflows/build-apk.yml`. Cada commit no main (sem `[skip ci]`) corre o Actions (imagem `barichello/godot-ci:4.3`): descompacta os `arte_*.zip` e depois o `projeto.zip` por cima, exporta o `ZeroSum.apk` (debug, sempre com a mesma keystore da imagem) e publica uma **Release** `v<versão>-b<build>` com `code=<versionCode>` + `notas_versao.txt`. No arranque, a app lê a última Release (`AppUpdate.gd`) e mostra "NOVA VERSÃO" se o `code` for maior.

1. **Subir a versão** (tudo tem de bater certo; o SmokeTest confirma):
   - `export_presets.cfg` (nos dois presets): `version/code` = code da última Release + 1, `version/name`.
   - `scripts/autoload/ContentUpdate.gd`: `APP_VERSION_CODE` = esse code; `BUNDLED_CONTENT_VERSION` = o maior entre o atual e o `c` publicado no zerosum-updates, + 1.
   - `tools/make_manifest.py`: `--min-app` por defeito = o novo code.
   - `scenes/main/Main.tscn` ("Versão X.Y.Z" no menu; muda só o número) e a mesma entrada em `tools/make_en_json.py` ("Versão X.Y.Z" → "Version X.Y.Z").
   - `notas_versao.txt` (1.ª linha `Zero-Sum X.Y.Z`, depois Novo / Alterado / Corrigido), `data/news.json` (Novidades no jogo, com inglês), `README.md`.
2. **Testar** (SmokeTest, Balance, capturas).
3. **Zips** (sem `.godot/`, `__pycache__/` nem `*.pem`):
   - `projeto_full.zip`: tudo → vai para `..\Projeto\Versão Atual\projeto_vX.Y.Z.zip`;
   - `projeto.zip`: tudo menos `assets/art/cards/`; `arte_cartas.zip`: só `assets/art/cards/`.
   - Cada um dos dois do GitHub com menos de 10 MB (o upload pelo navegador do Claude aceita até 10 MB por ficheiro). Se passar, partir em mais pacotes `arte_<nome>.zip` (o workflow descompacta todos).
   - Confirmar que os pacotes juntos dão o projeto completo.
4. **Pedir ao Paulo para publicar.** Depois enviar os dois zips no mesmo commit em `https://github.com/DaewonPT/ArcanaRun/upload/main` (título `Zero-Sum X.Y.Z: <resumo em inglês>`, descrição New / Changed / Fixed em inglês, "Commit directly to the main branch"). Se for preciso mudar o workflow, enviá-lo antes para `…/upload/main/.github/workflows` com `[skip ci]` no título.
5. **Esperar o build** em `https://github.com/DaewonPT/ArcanaRun/actions` (~4 min) até "Success". Confirmar a Release em `https://api.github.com/repos/DaewonPT/ArcanaRun/releases/latest?t=<hora>`: `code=<novo code>` no `body` e o `ZeroSum.apk` nos `assets`.
6. **APK**: perguntar se o Paulo o quer descarregar (nome, origem, tamanho; ~41 MB). Se sim, para `..\Ficheiro APK\Versão Atual\ZeroSum_vX.Y.Z.apk` (o anterior para "Versões Anteriores").
7. **Mensagem final**: o que mudou, a nota para o WhatsApp, onde ficaram os ficheiros, e que quem tem a 0.9.0 ou mais recente vê "NOVA VERSÃO" no menu (as mais antigas instalam o APK à mão).

## Atualizações de conteúdo sem APK
Só JSON de `data/` e `i18n/`, quando a app instalada já os sabe usar. Repositório público `DaewonPT/zerosum-updates` (GitHub Pages): manifesto `versao.txt` ("ZSUPD 1", assinado com ECDSA P-256) e ficheiros `f/<sha256>`. Gerar com `python3 tools/make_manifest.py --key <chave> --version N --min-app M --out <pasta> --note-pt "…" --note-en "…"` (N = o maior entre o `BUNDLED_CONTENT_VERSION` do APK lançado e o `c` publicado, + 1; M = o code da versão lançada). Enviar primeiro os `f/`, depois o `versao.txt`. Guardar o zip em `..\Atualizações de Conteúdo\` e o projeto com a alteração em `..\Projeto\Versão Atual\projeto_vX.Y.Z_cN.zip`. O conteúdo descarregado só conta se for mais novo do que o embutido no APK (`ContentUpdate.clear_if_stale`).

## Nota para o WhatsApp
Só a versão nova, em português, a partir do `notas_versao.txt`, dentro de um bloco de código:
```
🎴 *Zero-Sum X.Y.Z*

✨ *Novo*
• …

🔄 *Alterado*
• …

🛠️ *Corrigido*
• …
```
Negrito só com `*texto*`; uma linha por ponto, começada por `• `; secções vazias não aparecem; nomes como no jogo, sem pormenores técnicos.

## Estado atual
- Versão **0.14.0** (code 19, conteúdo 13, `--min-app` 19). 659 ilustrações em `assets/art/` (importadas; `python3 tools/import_art.py --status`).
- 0.14.0: cartas com o visual "Vidro arcano" (`CardView` + `scripts/ui/CardGlass.gd`, `CardArt`, `CardZoom`) e as correções da revisão do código (círculo de runas desenhado uma vez, centrado no texto do título; Campanha, Run Rápida, espaços dos jogos guardados, créditos). Capturas: `--only=0140`.
- 0.13.1 e 0.13.2: menu com o visual "Grimório dourado" (título em New Rocker dourado, placas com medalhões) e o fundo "Arcano vivo" (ilustração, círculo de runas, faíscas); ícone "leque de cartas"; a Campanha abre no Livro I; frase nova por baixo do lema e «Versão X.Y.Z» no menu.
- Próximos passos: ver "Próximos passos sugeridos" no README.
