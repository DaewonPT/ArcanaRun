# Zero-Sum — instruções para o Claude Code

Jogo mobile de cartas do Paulo (Magic: The Gathering × Balatro), em **Godot 4.3** (GDScript), para **Android**, sempre na **horizontal** (1280×720 de base, `stretch mode = canvas_items`, `aspect = expand`). Pacote Android `pt.zerosum.game`. O nome antigo era "Arcana Run" (o repositório do GitHub ainda se chama `DaewonPT/ArcanaRun`).

O `README.md` explica o jogo e o código em pormenor (DSL de efeitos, cascata, equilíbrio, tradução, atualizações). Ler antes de mexer.

## Como falar com o Paulo
- Português de Portugal, a tratar por "tu". Respostas curtas, com passos exatos. Ele não é técnico.
- Patch notes no formato de WhatsApp (ver "Nota para o WhatsApp"), só da versão nova.

## Regras fixas (do Paulo)
- **Commits no GitHub** (ArcanaRun e zerosum-updates): título e descrição em inglês, baseados na nota da versão, **sem identificar nem associar o assistente**: sem "Co-Authored-By", sem menção a IA, sem links de sessões.
- **Downloads** (APK, artefactos do Actions, Godot, tipos de letra…): só depois de o Paulo autorizar, dizendo o nome, a origem e o tamanho.
- **Chave privada** `zerosum-atualizacoes-privada.pem`: nunca no projeto, nos zips nem no GitHub. Está em `..\Atualizações de Conteúdo\Chave Privada\`.
- **Envio para o GitHub**: pelo navegador (página de upload), como até agora. Se quiseres usar git, pergunta primeiro ao Paulo.
- **Publicar** uma versão no GitHub: só depois de o Paulo dizer que sim.
- Apagar repositórios, Releases ou ficheiros no GitHub é com o Paulo. Nunca escrever palavras-passe ou tokens em campos.
- O repositório fica com o nome `ArcanaRun`: as apps instaladas só aceitam atualizações com links desse nome (`AppUpdate.APK_PREFIX`).
- A Play Store é a última coisa a fazer: não a sugerir por agora. Sem ranking online nem semente diária.
- Línguas: só português e inglês.
- Arte: designs originais, nunca personagens de Magic. Prompts para o Gemini: no formato de folhas (como no SCAM Operator), um prompt por parte, no máximo 10 imagens por prompt.
- **Nomes**: nada do Magic: The Gathering nos textos do jogo — cartas, baralhos (são fações, não guildas), personagens, lugares e termos (planeswalker → Patrono, Phyrexia → Sangue/Corrupção, WUBRG → Prismática, Mox → Gemas…). Inventar nomes originais. Os ids internos antigos (`saga_azorius`, `relic_bolas_eye`, `planeswalkers.json`, campo `phyrexian`) ficam, para não estragar as gravações. O SmokeTest procura os nomes antigos (`_check_no_mtg_names`).

## Pastas do Paulo (`C:\Users\PC\Desktop\PROJETOS\Zero-Sum\`)
```
Zero-Sum/
├── Código/                   este projeto (abrir aqui o Claude Code)
├── Projeto/                  Versão Atual/projeto_vX.Y.Z.zip · Versões Anteriores/
├── Ficheiro APK/             Versão Atual/ZeroSum_vX.Y.Z.apk · Versões Anteriores/
├── Atualizações de Conteúdo/ zerosum-updates-conteudo-vN.zip · Chave Privada/
├── Arte/                     prompts e imagens do Gemini, por parte
└── Documentos/
```
- Em "Versão Atual" fica só a versão nova; a anterior passa para "Versões Anteriores" (sem escrever por cima de nada).
- O `projeto_vX.Y.Z.zip` é sempre o projeto completo (com as ilustrações).

## Modelo de jogo (não mudar sem o Paulo pedir)
- Tabuleiro com criaturas, mana e bloqueio (Magic) + dano de ataque numa **cascata Poder × Mult**, com relíquias a disparar uma a uma (Balatro).
- Escala: **Poder 10–100 por carta**. Cartas em `data/cards.json` (300 do "Mana Cascade" em 18 baralhos, mais extras a partir de c301).
- Prioridades: conteúdo e progressão, apresentação, distribuição, jogabilidade. O combinado para as próximas versões está no README ("Próximos passos sugeridos").

## Mapa do código
- `scripts/autoload/` (por esta ordem): EventBus → ContentUpdate → CardDB → Settings → GameState → Stats → SceneRouter → Sfx → Music → AppUpdate.
- `scripts/core/`: `EffectResolver.gd` (DSL de efeitos, formações e toda a cascata), `Cascade.gd`, `BattleManager.gd`, `EnemyAbilities.gd`.
- `scenes/` (battle, map, shop, loot, draft, builder, campaign, event, puzzles, main, ui, saga, school, tower, training, …), `scripts/ui/` (CardIcon, CardFace, TriBatch, UiKit, ArtLib, MenuBackdrop, PlaqueDeco…), `assets/` (fonts, shaders, icons, audio, art, `theme.tres`).
- `data/*.json`: cartas, baralhos, relíquias, formações, inimigos, campanha, eventos, conquistas, etc. Traduções em `i18n/en.json` e `i18n/howto.json`.
- `tools/`:
  - `convert_cards.py` gera `cards.json`/`decks.json` a partir de `mana_cascade_300.txt` (cartas mudam-se aqui, nunca à mão no JSON); depois `make_cards_en.py`.
  - `make_en_json.py` gera `en.json` e diz o que falta traduzir (`tools/en_0120.py`, `tools/en_0130.py`, `tools/en_0140.py`, `tools/en_0141.py`, `tools/en_0142.py`, `tools/en_0150.py`, `tools/en_0160.py`, `tools/en_0161.py` e `tools/en_0170.py` têm os textos das versões recentes).
  - `import_art.py` / `make_art_prompts.py` / `art_sheets.json`: ilustrações do Gemini. Depois de importar, o `import_art.py` chama o `make_thumbs.py` (miniaturas com mipmaps: cartas a 256 px em `assets/art/cards_256/`, fundos e eventos a 320 px em `assets/art/places_320/`).
  - `make_icons.py`: ícone e splash a partir de `tools/brand/` (precisa do Playwright).
  - `make_manifest.py`: pacote de conteúdo assinado.
  - `make_audio.py`: música e efeitos.

## Como trabalhar
1. Ler o README e os ficheiros envolvidos; seguir a organização que já existe.
2. **Conteúdo em dados** (JSON), nunca escrito à mão no GDScript. Cartas novas: Poder 10–100 e baralho atribuído.
3. **Cascata num único sítio** (`EffectResolver.build_attack_cascade` → `Cascade`). Ordem fixa: criaturas pela ordem do tabuleiro → feitiços do turno → formações → cartas [Na Mão] → relíquias da esquerda para a direita → patrono → clima.
4. **UI para o dedo, na horizontal**: botões ≥ 48 px; nada interativo junto à margem de baixo; títulos com `theme_type_variation = TitleLabel` (Lora), o resto em Inter.
5. **GDScript**: tipagem estática, sinais (EventBus) em vez de polling, `@onready` com `%Nome`.
6. **Tradução**: as chaves são o próprio texto em português; `tr("molde %d") % valor`. Cada texto novo (também nos JSON) precisa da entrada em inglês; correr `python3 tools/make_en_json.py` (não pode ficar nada "SEM TRADUÇÃO").
7. Sinal `EventBus.cascade_started`: só a UI da batalha o pode ouvir (o BattleManager espera pela UI quando há ouvintes). A música usa `cascade_presented`.

## Testar
Precisa do Godot 4.3 (para Windows: `Godot_v4.3-stable_win64.exe.zip` das Releases do `godotengine/godot` no GitHub — pedir autorização antes de descarregar). Usar o executável `_console.exe` para ver a saída. Na raiz do projeto:
- Importar (duas vezes na 1.ª vez; os erros de tema da 1.ª são normais): `godot --headless --path . --import --quit`
- **SmokeTest** (demora ~6 min): `godot --headless --path . res://tests/SmokeTest.tscn` — tem de acabar com "SMOKE TEST: OK" e código 0. Cada versão acrescenta os seus `_test_…()` e chama-os no `_ready()`.
- **Balance** (bot com loja): `godot --headless --path . res://tests/Balance.tscn` — comparar com os números do README (0.17.0: 147/160 vitórias no Normal, 92 %; 0.15.0: 151/160; 0.13.0: 142/160). Torre e Corrida: `-- --mode=tower --seeds=4` (andar médio 19) e `-- --mode=rush --seeds=3` (48/60 acabadas, 3,0 turnos por boss).
- **Capturas**: `godot --rendering-method gl_compatibility --path . res://tests/Screenshots.tscn -- --out=<pasta>` (sem `--only` saem as antigas; `--only=0130`, `--only=0130b` para as da 0.13; `--only=0140` para o menu da 0.14; `--only=0141` para as cartas com o visual «Arte em destaque»; `--only=0150` para as mecânicas, a loja, o PORQUE PERDI? e as costas da 0.15.0; `--only=0151` para as cartas e relíquias novas com ilustração; `--only=0160` para a batalha, os letreiros, as recompensas e os eventos da 0.16.0; `--only=0160b` para a loja nova, o booster, o Mercador Cego, as janelas, a pausa e os separadores; `--only=0161` para a Coleção, a Galeria, os cosméticos, os Talentos, as Estatísticas, o Construtor, o mapa, o interlúdio, a abertura e as trocas de ecrã da 0.16.1; `--only=0170` para a Torre, a Corrida, o Treino contra bosses, o Diário, a História no mapa e o Pacto da 0.17.0). Olhar mesmo para as imagens.

Armadilhas do Godot 4.3 já vistas:
- Nós libertados com `queue_free` ainda se desenham mais um frame: ao refazer contentores, `remove_child` antes do `queue_free`.
- Uma textura carregada dentro do `_draw()` sem ficar guardada numa variável é libertada logo: o desenho sai branco. Guardá-la num membro.
- Nós `top_level` desenham-se por cima da cena toda: não servem para ficar «entre» outros nós.
- Em nós que já estão na árvore, usar `set_anchors_and_offsets_preset` (o `set_anchors_preset` mantém o retângulo antigo).
- `remove_child` apaga o `owner` (e os `%Nomes`) da subárvore toda: ao mudar um nó de pai, repor `owner` depois de o novo pai estar na árvore (`Battle._move_to`).
- Lambdas que guardam nós libertados dão «Lambda capture at index N was freed»: usar métodos com `bind`, `weakref` ou tweens do próprio nó.
- `ScrollContainer` com `horizontal_scroll_mode = 0` empurra o layout: usar 3.
- Os números do JSON chegam como float (`1 in [1.0]` é falso): comparar com `int()`.
- Label com autowrap e 2 linhas de 13 px precisa de 40 px de altura (com 34 só se vê a primeira); com `text_overrun_behavior` e autowrap fica com 1 px — usar `max_lines_visible` + `clip_text` e uma altura mínima.
- `pressed.emit()` (testes) não liga um botão `toggle_mode`: quem trata o toque faz `set_pressed_no_signal(true)` (`UiKit.chip_row`).
- O «retroceder» do Android chega primeiro ao SceneRouter e às janelas e só depois ao ecrã: `SceneRouter.has_overlay()` continua a dizer que sim no frame em que uma janela fechou com ele.
- `int()` de um Dictionary rebenta («Nonexistent 'int' constructor»): `Stats.get_stat` só converte números (`decks_played` é um Dictionary; `Stats.achievement_value`).
- Testes que mexem nos cosméticos (`Settings.set_cosmetic` grava logo) têm de repor e gravar no fim, senão a próxima corrida começa com eles.
- Cada `draw_polyline`/`draw_arc` suave (antialiased) são vários comandos de desenho no telemóvel: enfeites com muitas peças vão num `TriBatch` (um comando) e desenham-se uma vez, não a cada frame.
- Arrays `Packed*` passam por cópia: uma função que lhes faz `append` não muda o array de quem a chamou.
- Sombra de letra com contorno (`shadow_outline_size` > 0) parte o lote das letras: ~15 comandos de desenho por Label no telemóvel. Usar a sombra simples (só deslocada) ou `outline_size`.
- Só ficheiros-recurso entram no APK; `.txt`/`.md` precisam do `include_filter` do `export_presets.cfg`. Pastas com `.gdignore` não são importadas.

## Lançar uma versão (APK)
O repositório público `DaewonPT/ArcanaRun` tem na raiz o `projeto.zip`, os pacotes `arte_*.zip` e `.github/workflows/build-apk.yml`. Cada commit no main (sem `[skip ci]`) corre o Actions (imagem `barichello/godot-ci:4.3`): descompacta os `arte_*.zip` e depois o `projeto.zip` por cima, exporta o `ZeroSum.apk` (debug, sempre com a mesma keystore da imagem) e publica uma **Release** `v<versão>-b<build>` com `code=<versionCode>` + `notas_versao.txt`. No arranque, a app lê a última Release (`AppUpdate.gd`) e mostra "NOVA VERSÃO" se o `code` for maior.

1. **Subir a versão** (tudo tem de bater certo; o SmokeTest confirma):
   - `export_presets.cfg` (nos dois presets): `version/code` = code da última Release + 1, `version/name`.
   - `scripts/autoload/ContentUpdate.gd`: `APP_VERSION_CODE` = esse code; `BUNDLED_CONTENT_VERSION` = o maior entre o atual e o `c` publicado no zerosum-updates, + 1.
   - `tools/make_manifest.py`: `--min-app` por defeito = o novo code.
   - `scenes/main/Main.tscn` ("Versão X.Y.Z" no menu; muda só o número) e a mesma entrada em `tools/make_en_json.py` ("Versão X.Y.Z" → "Version X.Y.Z").
   - `notas_versao.txt` (1.ª linha `Zero-Sum X.Y.Z`, depois Novo / Alterado / Corrigido), `data/news.json` (Novidades no jogo, com inglês), `README.md`.
2. **Testar** (SmokeTest, Balance, capturas).
3. **Zips** (sem `.godot/`, `__pycache__/` nem `*.pem`):
   - `projeto_full.zip`: tudo → vai para `..\Projeto\Versão Atual\projeto_vX.Y.Z.zip`;
   - `projeto.zip`: tudo menos as ilustrações que vão nos pacotes: `arte_cartas.zip` (`assets/art/cards/`), `arte_fundos.zip` (`assets/art/backgrounds/` e `assets/art/events/`), `arte_retratos.zip` (`assets/art/portraits/`) e, desde a 0.16.1, `arte_miniaturas.zip` (`assets/art/cards_256/` e `assets/art/places_320/`).
   - Os pacotes ficam no repositório: só se voltam a enviar quando o que têm muda.
   - Cada zip do GitHub com menos de 10 MB (o upload pelo navegador do Claude aceita até 10 MB por ficheiro). Se passar, partir em mais pacotes `arte_<nome>.zip` (o workflow descompacta todos).
   - Confirmar que os pacotes juntos dão o projeto completo.
4. **Pedir ao Paulo para publicar.** Depois enviar os dois zips no mesmo commit em `https://github.com/DaewonPT/ArcanaRun/upload/main` (título `Zero-Sum X.Y.Z: <resumo em inglês>`, descrição New / Changed / Fixed em inglês, "Commit directly to the main branch"). Se for preciso mudar o workflow, enviá-lo antes para `…/upload/main/.github/workflows` com `[skip ci]` no título. A cópia do workflow que deve estar no GitHub é `tools/ci/build-apk.yml`. **Na 0.17.0, enviar primeiro esse ficheiro** (pedido do Paulo: o APK da Release passa a chamar-se `ZeroSum_vX.Y.Z.apk`, como no SCAM Operator, para se distinguirem as transferências no telemóvel; as apps instaladas desde a 0.9.0 aceitam qualquer `.apk` do repositório).
5. **Esperar o build** em `https://github.com/DaewonPT/ArcanaRun/actions` (~4 min) até "Success". Confirmar a Release em `https://api.github.com/repos/DaewonPT/ArcanaRun/releases/latest?t=<hora>`: `code=<novo code>` no `body` e o `ZeroSum_vX.Y.Z.apk` nos `assets` (até à 0.16.1 era `ZeroSum.apk`).
6. **APK**: perguntar se o Paulo o quer descarregar (nome, origem, tamanho; ~52 MB). Se sim, para `..\Ficheiro APK\Versão Atual\ZeroSum_vX.Y.Z.apk` (o anterior para "Versões Anteriores").
7. **Mensagem final**: o que mudou, a nota para o WhatsApp, onde ficaram os ficheiros, e que quem tem a 0.9.0 ou mais recente vê "NOVA VERSÃO" no menu (as mais antigas instalam o APK à mão).

## Atualizações de conteúdo sem APK
Só JSON de `data/` e `i18n/`, quando a app instalada já os sabe usar. Repositório público `DaewonPT/zerosum-updates` (GitHub Pages): manifesto `versao.txt` ("ZSUPD 1", assinado com ECDSA P-256) e ficheiros `f/<sha256>`. Gerar com `python3 tools/make_manifest.py --key <chave> --version N --min-app M --out <pasta> --note-pt "…" --note-en "…"` (N = o maior entre o `BUNDLED_CONTENT_VERSION` do APK lançado e o `c` publicado, + 1; M = o code da versão lançada). Enviar primeiro os `f/`, depois o `versao.txt`. Guardar o zip em `..\Atualizações de Conteúdo\` e o projeto com a alteração em `..\Projeto\Versão Atual\projeto_vX.Y.Z_cN.zip`. O conteúdo descarregado só conta se for mais novo do que o embutido no APK (`ContentUpdate.clear_if_stale`).

## Nota para o WhatsApp
Só a versão nova, em português, a partir do `notas_versao.txt`, dentro de um bloco de código:
```
🎴 *Zero-Sum X.Y.Z*

✨ *Novo*
• …

🔄 *Alterado*
• …

🛠️ *Corrigido*
• …
```
Negrito só com `*texto*`; uma linha por ponto, começada por `• `; secções vazias não aparecem; nomes como no jogo, sem pormenores técnicos.

## Estado atual
- Versão **0.17.0** (code 25, conteúdo 19, `--min-app` 25). Ilustrações em `assets/art/`: todas as cartas e relíquias, os bosses com 3 expressões (`_hurt`, `_angry`), os eventos e paragens (`events/`) e a loja (`python3 tools/import_art.py --status`). Faltam as da parte 14 (os 8 inimigos novos e os fundos da Torre e da Corrida; prompts já em `art_sheets.json`).
- 0.17.0 (modos): Torre do Arquimago (`mode = "tower"`, `GameState.new_tower_run`, `tower_*`) e Corrida de Bosses (`mode = "rush"`, `new_rush_run`, `rush_*`) num ecrã próprio sem mapa (`scenes/tower/Tower.tscn`; `scenes/ui/RelicSwap.gd` quando as relíquias estão cheias; a run grava-se com `save_run({}, "tower")`), Treino contra bosses (`start_boss_training`, `puzzle_id = "training_boss"`), Pactos do Infinito (`pact_offer`, `accept_pact`, `pact_gold`), 8 inimigos novos (2 bosses), histórias em cadeia (`chain`/`part` em `events.json`, `chain_due`/`chain_marked`) e Diário do Mago (`data/diary.json`, `Stats.check_diary`, separador DIÁRIO da Coleção). Os rituais dos bosses passaram a chegar à batalha (`build_enemy`). Capturas: `--only=0170`; Balance também com `--mode=tower` e `--mode=rush`.
- 0.16.1 (visual, 2.ª parte): Coleção com 5 separadores em «grelha + painel» (`VirtualCardGrid` — só cria as cartas à vista —, `TileGrid` — grelha desenhada para as relíquias e a Galeria —, `ArtViewer` para «SÓ A ARTE», `CosmeticPreview`), descobertas novas (`Stats.SEEN_ZONES`: eventos, climas e lugares), `Stats.cosmetic_source`, costas por baralho (`pattern: "deck"` no `CardBack`, nível 4; `GameState.deck_back/run_back`, `BackPicker` na Campanha e no Construtor), costas holográficas (conquista `nightmare_seal8`), aviso de cosmético com imagem e som (`Sfx.reward`), Talentos em árvore (`icon` em `talents.json`), Estatísticas com gráfico e histórico (`DeckDisc`) e medalhas, fundo do menu sossegado nos ecrãs de menu (`MenuBackdrop.quiet`), céu pela hora (`MenuBackdrop.sky`), abertura (`Opening`), arte viva das míticas, interlúdios com a ilustração e a máquina de escrever, mapa que se desenha com névoa no fim do ato, trocas de ecrã pelo destino (`SceneRouter.transition_style`). Capturas: `--only=0161`.
- 0.16.0 (visual, 1.ª parte): loja nova (`ShopCardTile`, `BoosterOpen`, `SoldStamp`, frases em `data/shop_lines.json`, a loja grava-se a cada compra), batalha (`LightBand` — letreiros em «Faixa de luz» —, `PileView`, `ArenaSlots`, `HpSegments`, `ShatterFx`, `SynergyLines`, `SkillGem`, `BattleRewards`, Cadeia em elos), janelas com `UiKit.window` e desempenho (FPS conforme o momento e baixo consumo em `SceneRouter`, `ArtLib.preload_async`, `ShaderWarmup`, oferta do modo de desempenho num telemóvel lento). Capturas: `--only=0160` e `--only=0160b`.
- 0.15.1: só as ilustrações da parte 11 (as 33 cartas e as 12 relíquias da 0.15.0). Capturas: `--only=0151`.
- 0.15.0: 12 mecânicas (Destreza, Delírio, Domínio, Persistir, Veteranos, Energia, Coroa, Mana de Sangue, Excesso vira ouro, Ponto fraco, Rituais, Constelações), 33 cartas, 12 relíquias, 3 selos, 7 costas, PORQUE PERDI?, DESFAZER na loja, gravar a cada jogada, SAIR PARA O MENU, números abreviados no Infinito e todos os nomes do Magic trocados por nomes originais. Capturas: `--only=0150`.
- 0.14.1: cartas com o visual «Arte em destaque» (o B; o Paulo preferiu-o ao "Vidro arcano"): `CardView` (letras postas à mão em `_layout()`) + duas camadas `scripts/ui/CardFace.gd` (ilustração por trás; o resto à frente, num só comando de desenho cada) + `CardZoom`. Capturas: `--only=0141`.
- Na 0.17.0 também: `tools/ci/build-apk.yml` (APK `ZeroSum_vX.Y.Z.apk`; na 0.17.0 enviar antes do projeto, ver «Lançar uma versão»), o aviso de atualização diz o nome do ficheiro (`AppUpdate.file_name_of`) e a Campanha conta os baralhos (eram «18» à mão; `Main._campaign_desc`). Textos em `tools/en_0170.py`.
- Próximos passos: ver "Próximos passos sugeridos" no README (0.18.0: 19, 24 e 25 das 100 sugestões).
