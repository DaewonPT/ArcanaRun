class_name PuzzleSolver
extends RefCounted
## Procura exaustiva da melhor linha de um quebra-cabeças (1 turno): todas as ordens de jogar
## cartas da mão (e Recapitular do cemitério) que cabem na mana. Usado pelos testes para fixar a
## vida do inimigo exatamente no melhor ataque possível.

static func solve(def: Dictionary) -> Dictionary:
	var bm := BattleManager.new()
	bm.start_puzzle(def)
	var best := {"total": 0, "line": []}
	_dfs(bm, [], best)
	return best

static func _dfs(bm: BattleManager, line: Array, best: Dictionary) -> void:
	var total := bm.preview_attack().total()
	if total > int(best["total"]):
		best["total"] = total
		best["line"] = line.duplicate()
	var options: Array = []   # [{"id", "grave"}], sem repetir ids iguais na mesma zona
	var seen := {}
	for c in bm.deck.hand:
		if bm.can_play(c) and not seen.has("h" + c.data.id):
			seen["h" + c.data.id] = true
			options.append({"id": c.data.id, "grave": false})
	for c in bm.flashback_cards():
		if bm.can_flashback(c) and not seen.has("g" + c.data.id):
			seen["g" + c.data.id] = true
			options.append({"id": c.data.id, "grave": true})
	if options.is_empty():
		return
	var snap := bm.to_dict()
	var gold := GameState.gold
	for opt in options:
		var inst: CardInstance = null
		var pool: Array[CardInstance] = bm.flashback_cards() if bool(opt["grave"]) else bm.deck.hand
		for c in pool:
			if c.data.id == String(opt["id"]):
				inst = c
				break
		if inst == null:
			continue
		if bool(opt["grave"]):
			bm.play_flashback(inst)
		else:
			bm.play(inst)
		line.append(("↺" if bool(opt["grave"]) else "") + String(opt["id"]))
		_dfs(bm, line, best)
		line.pop_back()
		bm.restore(snap)
		bm.puzzle = true
		GameState.gold = gold
