extends Node
## Tira capturas de ecrã das cenas (precisa de ecrã, p.ex. xvfb):
##   xvfb-run -s "-screen 0 1280x720x24" godot --rendering-method gl_compatibility --path . res://tests/Screenshots.tscn -- --out=/tmp/shots

var out_dir := "/tmp/shots"
var only := ""   # --only=0120: só as capturas dessa versão

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.substr(6)
		if arg.begins_with("--only="):
			only = arg.substr(7)
	DirAccess.make_dir_recursive_absolute(out_dir)
	await get_tree().process_frame
	GameState.progress = {"best_ante": {"deck01": 4, "deck02": 6}, "wins": {}, "difficulty": "normal"}
	Stats._ensure()
	Stats.set_tutorial_done(true)
	GameState.free_mode = false
	Settings.language = "pt"
	Settings.anim_speed = "normal"
	Settings.left_handed = false
	Settings.large_text = false
	Settings.warn_mana = false
	Settings.warn_rare = false
	Settings.compact = false
	Settings.ui_scale = 1.0
	GameState.progress["news_seen"] = String(NewsOverlay.current().get("version", ""))
	Settings.apply()
	if only == "0120":
		await _shots_0120()
		_finish()
		return
	if only == "0121":
		await _shots_0121()
		_finish()
		return
	if only == "0130":
		await _shots_0130()
		await _shots_0130b()
		_finish()
		return
	if only == "0130b":
		await _shots_0130b()
		_finish()
		return

	await _shoot_scene("res://scenes/main/Main.tscn", "01_menu", 0.9)
	# Configurações por cima do menu, e o menu em inglês.
	var menu: Node = load("res://scenes/main/Main.tscn").instantiate()
	add_child(menu)
	await _wait(0.3)
	var sm := SettingsMenu.open()
	await _wait(0.5)
	await _shoot("01b_configuracoes")
	Settings.language = "en"
	Settings.apply()
	await _wait(0.3)
	await _shoot("01c_configuracoes_en")
	sm.close()
	await _wait(0.3)
	await _shoot("01d_menu_en")
	Settings.language = "pt"
	Settings.apply()
	await _wait(0.2)
	menu._show_page("modes", false)
	await _wait(0.3)
	await _shoot("01e_menu_modos")
	menu._show_page("collection", false)
	await _wait(0.3)
	await _shoot("01f_menu_colecao")
	menu.queue_free()
	# Com uma run gravada: CONTINUAR em primeiro, com o baralho e o ante.
	GameState.new_run("deck05", 808)
	GameState.ante = 3
	GameState.save_run({}, "map")
	await _shoot_scene("res://scenes/main/Main.tscn", "01g_menu_continuar", 0.9)
	GameState.clear_saved_run()
	await get_tree().process_frame
	await _shoot_scene("res://scenes/campaign/Campaign.tscn", "02_campanha", 0.5)
	await _shoot_scene("res://scenes/ui/HowToPlay.tscn", "03_como_jogar", 0.3)
	# Estatísticas (com algumas conquistas), coleção e construtor.
	GameState.new_run("deck05", 2)
	EventBus.damage_dealt.emit("enemy", 120000)
	await _shoot_scene("res://scenes/ui/StatsScreen.tscn", "03b_estatisticas", 0.4)
	await _shoot_scene("res://scenes/ui/Collection.tscn", "03c_colecao", 0.6)
	var builder: Node = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	add_child(builder)
	await _wait(0.4)
	for id in ["c001", "c001", "c002", "c003", "c009", "c018", "c019", "c021", "c028", "c039", "c040", "c050"]:
		builder.call("_add_card", id)
	await _wait(0.3)
	await _shoot("03d_construtor")
	builder.queue_free()
	await get_tree().process_frame
	# Tutorial na primeira batalha.
	Stats.set_tutorial_done(false)
	GameState.new_run("deck01", 9)
	var tut_battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(tut_battle)
	EventBus.battle_ended.disconnect(tut_battle._on_battle_ended)
	await _wait(1.6)
	await _shoot("03e_tutorial")
	tut_battle.queue_free()
	await get_tree().process_frame
	Stats.set_tutorial_done(true)
	# Cartas em inglês + canhoto.
	Settings.language = "en"
	Settings.left_handed = true
	Settings.apply()
	GameState.new_run("deck16", 4)
	var en_battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(en_battle)
	EventBus.battle_ended.disconnect(en_battle._on_battle_ended)
	await _wait(1.6)
	await _shoot("03f_batalha_en_canhoto")
	en_battle.queue_free()
	await get_tree().process_frame
	Settings.language = "pt"
	Settings.left_handed = false
	Settings.apply()

	# Batalha: turno 1 (com Mulligan disponível, planeswalker, selos e uma carta de dupla face),
	# depois com cartas jogadas, depois a meio da cascata.
	GameState.new_run("deck05", 7)
	GameState.add_relic("relic_seal")
	GameState.add_relic("relic_banner")
	GameState.set_planeswalker("pw_white")
	GameState.planeswalker["loyalty"] = 4
	GameState.deck[0]["seal"] = "tithe"
	GameState.deck[1]["seal"] = "fury"
	GameState.add_card("c304")
	GameState.choose_battle("guard")
	var battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(battle)
	EventBus.battle_ended.disconnect(battle._on_battle_ended)
	var bm: BattleManager = battle.get_node("BattleManager")
	bm.enemy.hp = 400000
	bm.enemy.max_hp = 400000
	EventBus.enemy_hp_changed.emit(bm.enemy.hp, bm.enemy.max_hp)
	await _wait(2.0)
	await _shoot("04_batalha_turno1")
	var hand_box: Container = battle.get_node("%Hand")
	# Carta em grande (toque longo), grimório e pausa.
	for view in hand_box.get_children():
		if view is CardView:
			view.long_pressed.emit(view.card)
			break
	await _wait(0.5)
	await _shoot("04b_carta_grande")
	SceneRouter.close_overlays()
	await _wait(0.2)
	(battle.get_node("%LibraryBtn") as Button).pressed.emit()
	await _wait(0.5)
	await _shoot("04c_grimorio")
	SceneRouter.close_overlays()
	await _wait(0.2)
	(battle.get_node("%PauseBtn") as Button).pressed.emit()
	await _wait(0.5)
	await _shoot("04d_pausa")
	SceneRouter.close_overlays()
	await _wait(0.3)
	for i in 3:
		for view in hand_box.get_children():
			if view is CardView and bm.can_play(view.card):
				_tap_play(view)
				break
		await _wait(0.45)
	(battle.get_node("%DiscardBtn") as Button).button_pressed = true
	await _wait(0.3)
	await _shoot("05_batalha_canalizar")
	(battle.get_node("%DiscardBtn") as Button).button_pressed = false
	await _wait(0.2)
	# Avança dois turnos para ter tabuleiro cheio, depois dispara a cascata e captura a meio.
	for t in 2:
		(battle.get_node("%EndTurn") as Button).pressed.emit()
		var t0 := Time.get_ticks_msec()
		var turn_before := bm.turn
		while bm.turn == turn_before and Time.get_ticks_msec() - t0 < 15000 and not bm.finished:
			await get_tree().process_frame
		await _wait(0.9)
		for i in 4:
			for view in hand_box.get_children():
				if view is CardView and bm.can_play(view.card):
					_tap_play(view)
					break
			await _wait(0.35)
	await _shoot("06_batalha_tabuleiro")
	(battle.get_node("%EndTurn") as Button).pressed.emit()
	await _wait(1.2)
	await _shoot("07_batalha_cascata")
	await _wait(2.2)
	await _shoot("08_batalha_impacto")
	await _wait(1.5)
	await _shoot("08b_batalha_turno_seguinte")
	battle.queue_free()
	await get_tree().process_frame

	# Boss (ante 4) e evento.
	GameState.ante = 4
	GameState.damage_player(6)
	var boss_battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(boss_battle)
	EventBus.battle_ended.disconnect(boss_battle._on_battle_ended)
	await _wait(2.2)
	await _shoot("08c_boss")
	boss_battle.queue_free()
	await get_tree().process_frame
	GameState.ante = 2
	GameState.pending_event = "altar"
	await _shoot_scene("res://scenes/event/Event.tscn", "08d_evento", 0.6)
	GameState.pending_event = ""
	GameState.add_gold(30)
	GameState.add_relic("relic_crown")
	GameState.choose_stop("shop")
	await _shoot_scene("res://scenes/shop/Shop.tscn", "09_loja", 0.4)
	GameState.last_victory = false
	await _shoot_scene("res://scenes/ui/RunOver.tscn", "10_fim", 0.8)
	# 0.8.0: mapa (fase de paragem do ante 1), Mercador Cego, acampamento, draft, enigmas, cemitério com recapitular.
	GameState.new_run("deck03", 21)
	GameState.add_gold(30)
	GameState.map_options(1)
	GameState.choose_battle("guard")
	GameState.map_phase = "stop"
	await _shoot_scene("res://scenes/map/Map.tscn", "11_mapa", 0.5)
	GameState.ante = 4
	GameState.map_options(4)
	GameState.choose_stop("merchant")
	await _shoot_scene("res://scenes/shop/Shop.tscn", "12_mercador_cego", 0.5)
	GameState.ante = 1
	GameState.pending_event = "node_altar"
	await _shoot_scene("res://scenes/event/Event.tscn", "13_altar", 0.5)
	GameState.pending_event = ""
	var draft: Node = load("res://scenes/draft/Draft.tscn").instantiate()
	add_child(draft)
	await _wait(0.5)
	await _shoot("14_draft")
	draft.queue_free()
	await get_tree().process_frame
	await _shoot_scene("res://scenes/puzzles/Puzzles.tscn", "15_enigmas", 0.5)
	GameState.new_run("deck03", 22)
	var fb_battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(fb_battle)
	EventBus.battle_ended.disconnect(fb_battle._on_battle_ended)
	var fbm: BattleManager = fb_battle.get_node("BattleManager")
	await _wait(1.2)
	var ritual := CardDB.new_instance("c018")
	ritual.exiled = true
	fbm.deck.to_graveyard(ritual)
	var exiled := CardDB.new_instance("c021")
	fbm.deck.to_exile(exiled)
	fb_battle.call("_refresh_all")
	(fb_battle.get_node("%GraveyardBtn") as Button).pressed.emit()
	await _wait(0.5)
	await _shoot("16_cemiterio_recapitular")
	SceneRouter.close_overlays()
	fb_battle.queue_free()
	await get_tree().process_frame
	# 0.9.0: mapa com clima, contrato, Elite e Tribunal; interlúdio; Baú de Espólio; Tribunal com a roda;
	# boss com fala e marca de metade; fogo nas pílulas; detalhe da cascata; despertar; modo daltónico.
	GameState.new_run("deck05", 127)
	GameState.add_gold(18)
	GameState.map_options(1)
	GameState.map_options(2)
	GameState.choose_battle("scout")
	GameState.map_phase = "stop"
	GameState.set_contract("swift")
	GameState.interlude_key = "1"
	await _shoot_scene("res://scenes/map/Map.tscn", "17_mapa_clima_contrato", 0.7)
	GameState.ante = 3
	GameState.map_phase = "battle"
	GameState.interlude_key = "1"
	var imap: Node = load("res://scenes/map/Map.tscn").instantiate()
	add_child(imap)
	await _wait(1.2)
	await _shoot("17b_interludio_ato")
	SceneRouter.close_overlays()
	imap.queue_free()
	await get_tree().process_frame
	GameState.ante = 4
	GameState.map_phase = "stop"
	GameState.prepare_loot()
	await _shoot_scene("res://scenes/loot/Loot.tscn", "18_bau_espolio", 0.9)
	GameState.ante = 2
	GameState.pending_event = "node_tribunal"
	var trib = load("res://scenes/event/Event.tscn").instantiate()
	add_child(trib)
	await _wait(0.6)
	await _shoot("19_tribunal")
	var gamble_lines: Array[String] = []
	trib._gamble({"gamble": "gold", "cost": 8}, gamble_lines)
	await _wait(1.7)
	await _shoot("19b_tribunal_roda")
	await _wait(3.5)
	trib.queue_free()
	SceneRouter.close_overlays()
	await get_tree().process_frame
	# Boss: fala de entrada, marca de metade, intenção em ícones, chips de clima e contrato.
	GameState.new_run("deck05", 128)
	GameState.ante = 4
	GameState.climates["2"] = "blood_moon"
	GameState.add_relic("relic_seal")
	GameState.add_relic("relic_hungry_grimoire")
	GameState.relic_counters["relic_hungry_grimoire"] = 3
	GameState.add_boss_relic("relic_abyss_chalice")
	GameState.set_contract("army")
	GameState.choose_battle("boss")
	var bb = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(bb)
	EventBus.battle_ended.disconnect(bb._on_battle_ended)
	var bbm: BattleManager = bb.get_node("BattleManager")
	await _wait(1.6)
	# 0.12.1: a entrada do boss fica até ser lida (ou tocada): fecha-a para a fala aparecer.
	for c in bb.get_children():
		if c is BossIntro:
			c.close()
	await _wait(1.2)
	await _shoot("20_boss_fala")
	var bhand: Container = bb.get_node("%Hand")
	for i in 4:
		for view in bhand.get_children():
			if view is CardView and bbm.can_play(view.card):
				_tap_play(view)
				break
		await _wait(0.4)
	var total := bbm.preview_attack().total()
	bbm.enemy.hp = int(total * 1.08)
	EventBus.enemy_hp_changed.emit(bbm.enemy.hp, bbm.enemy.max_hp)
	bb._refresh_preview()
	await _wait(1.4)
	await _shoot("21_fogo_pilulas")
	bb._open_breakdown()
	await _wait(0.6)
	await _shoot("22_detalhe_cascata")
	SceneRouter.close_overlays()
	await _wait(0.3)
	bbm.enemy.max_hp = total * 10
	bbm.enemy.hp = int(total * 5.5)
	EventBus.enemy_hp_changed.emit(bbm.enemy.hp, bbm.enemy.max_hp)
	bb._refresh_preview()
	(bb.get_node("%EndTurn") as Button).pressed.emit()
	var t_start := Time.get_ticks_msec()
	while not bbm.phase2 and Time.get_ticks_msec() - t_start < 20000:
		await get_tree().process_frame
	await _wait(0.45)
	await _shoot("23_boss_desperta")
	await _wait(2.5)
	bb.queue_free()
	await get_tree().process_frame
	# Modo daltónico (símbolos nos pips de cor).
	Settings.colorblind = true
	Settings.apply()
	GameState.new_run("deck13", 31)
	var cbb = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(cbb)
	EventBus.battle_ended.disconnect(cbb._on_battle_ended)
	await _wait(2.0)
	await _shoot("24_modo_daltonico")
	cbb.queue_free()
	await get_tree().process_frame
	Settings.colorblind = false
	Settings.apply()
	await _shots_0100()
	await _shots_0110()
	await _shots_0120()
	await _shots_0121()
	_finish()

func _finish() -> void:
	GameState.reset_progress()
	Stats.set_tutorial_done(true)
	GameState.clear_all_saved_runs()
	Settings.language = "auto"
	Settings.save_settings()
	get_tree().quit()

func _shoot_scene(path: String, name: String, settle: float) -> void:
	var s: Node = load(path).instantiate()
	add_child(s)
	await _wait(settle)
	await _shoot(name)
	s.queue_free()
	await get_tree().process_frame

func _wait(seconds: float) -> void:
	await get_tree().create_timer(seconds).timeout

func _shoot(name: String) -> void:
	await RenderingServer.frame_post_draw
	var img := get_viewport().get_texture().get_image()
	var path := out_dir.path_join(name + ".png")
	img.save_png(path)
	print("captura: ", path)

## 0.10.0: novidades, História, Desafios, Treino, Némesis, Reação, Reforço, avisos, encantamentos e
## Fichas, configurações (Visual), resumo do fim da run, carta mítica e escala de 120 %.
func _shots_0100() -> void:
	var menu: Node = load("res://scenes/main/Main.tscn").instantiate()
	add_child(menu)
	await _wait(0.4)
	NewsOverlay.open()
	await _wait(0.5)
	await _shoot("25_novidades")
	SceneRouter.close_overlays()
	var sm := SettingsMenu.open()
	await _wait(0.3)
	sm._show_tab(1)
	await _wait(0.3)
	await _shoot("26_configuracoes_visual")
	sm._show_tab(3)
	await _wait(0.3)
	await _shoot("26b_configuracoes_acessibilidade")
	sm.close()
	menu.queue_free()
	await get_tree().process_frame
	GameState.progress["saga"] = {"saga_white": true}
	await _shoot_scene("res://scenes/saga/Saga.tscn", "27_historia", 0.6)
	GameState.progress["challenges"] = {"ch_glass": true}
	await _shoot_scene("res://scenes/challenges/Challenges.tscn", "28_desafios", 0.5)
	GameState.training = {"hand": ["c315", "c316", "c331", "c339", "c318", "c345"], "relics": ["relic_drum", "relic_seal"], "mana": 8}
	await _shoot_scene("res://scenes/training/Training.tscn", "29_treino", 0.6)
	# Treino: o boneco, um ataque e o resultado.
	GameState.start_training()
	var tb: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(tb)
	await _wait(1.2)
	var tbm: BattleManager = tb.get_node("BattleManager")
	for id in ["c315", "c316", "c331", "c318"]:
		for c in tbm.deck.hand:
			if c.data.id == id and tbm.can_play(c):
				tb.call("_on_hand_card_pressed", c)
				break
		await _wait(0.3)
	await _shoot("30_treino_fichas_encantamento")
	(tb.get_node("%EndTurn") as Button).pressed.emit()
	var t0 := Time.get_ticks_msec()
	while not tbm.finished and Time.get_ticks_msec() - t0 < 15000:
		await get_tree().process_frame
	await _wait(1.4)
	await _shoot("31_treino_resultado")
	tb.queue_free()
	await get_tree().process_frame
	GameState.puzzle_id = ""
	# Reforço (escolha) e Reação (janela antes do contra-ataque).
	GameState.free_mode = false
	GameState.new_run("deck01", 77)
	GameState.relic_ids.clear()
	GameState.choose_battle("scout")
	var rb: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(rb)
	EventBus.battle_ended.disconnect(rb._on_battle_ended)
	await _wait(1.6)
	var rbm: BattleManager = rb.get_node("BattleManager")
	rbm.enemy["attack"] = 3
	rbm.mana_total = 6
	rbm.mana_available = 6
	for id in ["c339", "c347"]:
		var inst := CardDB.new_instance(id)
		inst.zone = CardInstance.Zone.HAND
		rbm.deck.hand.append(inst)
	EventBus.hand_changed.emit()
	await _wait(0.4)
	var fire: CardInstance = null
	for c in rbm.deck.hand:
		if c.data.id == "c339":
			fire = c
	rb.call("_on_hand_card_pressed", fire)
	await _wait(0.5)
	await _shoot("32_reforco")
	rb.call("_close_modal", "kick")
	await _wait(0.6)
	(rb.get_node("%EndTurn") as Button).pressed.emit()
	t0 = Time.get_ticks_msec()
	while not rb.call("_alive", rb._modal) and Time.get_ticks_msec() - t0 < 12000:
		await get_tree().process_frame
	await _wait(0.5)
	await _shoot("33_reacao")
	rb.queue_free()
	await get_tree().process_frame
	# Aviso "Atacar sem gastar a mana?".
	Settings.warn_mana = true
	GameState.new_run("deck05", 5)
	GameState.relic_ids.clear()
	var wb: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(wb)
	EventBus.battle_ended.disconnect(wb._on_battle_ended)
	await _wait(1.6)
	wb.call("_on_end_turn")
	await _wait(0.5)
	await _shoot("34_aviso_mana")
	wb.queue_free()
	await get_tree().process_frame
	Settings.warn_mana = false
	# Némesis no mapa e na batalha (com escudo).
	GameState.new_run("deck01", 4242)
	GameState.ante = 3
	GameState.map_phase = "battle"
	await _shoot_scene("res://scenes/map/Map.tscn", "35_mapa_nemesis", 0.6)
	GameState.ante = 5
	GameState.choose_battle("nemesis")
	var nb: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(nb)
	EventBus.battle_ended.disconnect(nb._on_battle_ended)
	await _wait(2.4)
	await _shoot("36_nemesis")
	nb.queue_free()
	await get_tree().process_frame
	# Carta mítica em grande (glossário sublinhado) e uma carta com termos do glossário.
	CardZoom.show_data(CardDB.get_card("c354"))
	await _wait(0.5)
	await _shoot("37_mitica_zoom")
	SceneRouter.close_overlays()
	CardZoom.show_data(CardDB.get_card("c316").plus_version())
	await _wait(0.5)
	await _shoot("37b_carta_mais_zoom")
	SceneRouter.close_overlays()
	# Resumo do fim da run.
	GameState.new_run("deck05", 9)
	GameState.ante = 6
	GameState.run_log = {"damage_by_ante": {"1": 4200, "2": 9100, "3": 21000, "4": 38000, "5": 77000, "6": 61000}, "card_dmg": {"c047": 98000, "c039": 41000}, "relic_dmg": {"relic_drum": 52000}, "best_hit": 54000}
	GameState.last_victory = false
	await _shoot_scene("res://scenes/ui/RunOver.tscn", "38_fim_resumo", 0.9)
	# Escala 120 % e modo compacto na batalha.
	Settings.ui_scale = 1.2
	Settings.compact = true
	Settings.apply()
	GameState.new_run("deck05", 12)
	GameState.relic_ids.clear()
	var sb: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(sb)
	EventBus.battle_ended.disconnect(sb._on_battle_ended)
	await _wait(1.8)
	await _shoot("39_escala120_compacto")
	sb.queue_free()
	await get_tree().process_frame
	Settings.ui_scale = 1.0
	Settings.compact = false
	Settings.apply()

## Batalha gravada contra um inimigo à escolha, com a mão e a Arena dadas (para as capturas).
func _battle_state(enemy_id: String, hand: Array, board: Array, mana: int = 6) -> Dictionary:
	var e: Dictionary = CardDB.enemy_def(enemy_id).duplicate(true)
	e["hp"] = 60000
	e["max_hp"] = 60000
	var st := {"enemy": e, "turn": 2, "max_turns": 5, "mana_total": mana, "mana_available": mana, "discards_left": 3,
		"player_hp": GameState.player_hp, "library": [], "hand": [], "graveyard": [], "board": [], "exile": []}
	for id in hand:
		st["hand"].append({"id": String(id), "entry": -1})
	for id in board:
		st["board"].append({"id": String(id), "entry": -1})
	return st

func _open_battle(state: Dictionary) -> Node:
	GameState.pending_battle = state
	var b: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(b)
	EventBus.battle_ended.disconnect(b._on_battle_ended)
	return b

## 0.11.0: tipos de carta (faixas, Terrenos à parte, palavras-chave), dica, Escola do Mago e lição,
## Talentos, bosses novos (Espelho e Nevoeiro), zoom de Terreno e palavras-chave e Rever o maior golpe.
func _shots_0110() -> void:
	GameState.free_mode = false
	GameState.new_run("deck05", 1110)
	GameState.relic_ids.clear()
	GameState.ante = 2
	var normal_id := ""
	for e in CardDB.enemies:
		if not bool(e.get("boss", false)) and not bool(e.get("saga", false)) and normal_id == "":
			normal_id = String(e.get("id", ""))
	# Mão com todos os tipos e Arena com as palavras-chave.
	Settings.tips_enabled = false
	var tb := _open_battle(_battle_state(normal_id, ["c339", "c345", "c331", "c040", "c050", "c008"], ["c043", "c020", "c031", "c046"]))
	await _wait(1.8)
	await _shoot("40_tipos_e_palavras_chave")
	# A dica da primeira vez.
	Settings.tips_enabled = true
	GameState.reset_tips()
	tb.call("_refresh_all")
	await _wait(0.6)
	await _shoot("41_dica")
	tb.queue_free()
	await get_tree().process_frame
	# Bosses novos: o Espelho Vivo (criatura copiada) e a Bruxa do Nevoeiro (texto escondido).
	GameState.progress["tips_seen"] = (CardDB.tips.keys() as Array).duplicate()
	GameState.ante = 4
	var mb := _open_battle(_battle_state("boss_mirror", ["c339", "c040", "c050"], ["c047", "c043", "c039"]))
	await _wait(1.4)
	var mbm: BattleManager = mb.get_node("BattleManager")
	var copied := mbm.mirror_best_creature()
	if copied != null:
		EventBus.creature_mirrored.emit(copied)
	await _wait(0.5)
	await _shoot("42_boss_espelho")
	mb.queue_free()
	await get_tree().process_frame
	var fb := _open_battle(_battle_state("boss_fog", ["c339", "c345", "c040", "c050", "c044"], ["c047"]))
	await _wait(1.6)
	await _shoot("43_boss_nevoeiro")
	fb.queue_free()
	await get_tree().process_frame
	# Zoom: Terreno e palavras-chave explicados.
	CardZoom.show_data(CardDB.get_card("c050"))
	await _wait(0.5)
	await _shoot("44_zoom_terreno")
	SceneRouter.close_overlays()
	CardZoom.show_data(CardDB.get_card("c046"))
	await _wait(0.5)
	await _shoot("44b_zoom_palavras_chave")
	SceneRouter.close_overlays()
	# Escola do Mago e uma lição (com a explicação e o resultado).
	GameState.progress["lessons"] = {"lesson_land": true, "lesson_formation": true}
	await _shoot_scene("res://scenes/school/School.tscn", "45_escola", 0.5)
	GameState.start_lesson("lesson_tokens")
	var lb: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(lb)
	await _wait(1.6)
	await _shoot("46_licao")
	var lbm: BattleManager = lb.get_node("BattleManager")
	for id in ["c315", "c316"]:
		for c in lbm.deck.hand:
			if c.data.id == id and lbm.can_play(c):
				lb.call("_on_hand_card_pressed", c)
				break
		await _wait(0.4)
	(lb.get_node("%EndTurn") as Button).pressed.emit()
	var t0 := Time.get_ticks_msec()
	while not lb.call("_alive", lb._modal) and Time.get_ticks_msec() - t0 < 15000:
		await get_tree().process_frame
	await _wait(0.6)
	await _shoot("47_licao_concluida")
	lb.queue_free()
	await get_tree().process_frame
	GameState.puzzle_id = ""
	# Talentos.
	GameState.progress["talent_points"] = 12
	GameState.progress["talents"] = {"t_gold": 2, "t_life": 1, "t_relic": 1}
	await _shoot_scene("res://scenes/talents/Talents.tscn", "48_talentos", 0.5)
	# Fim da run: Rever o maior golpe.
	GameState.free_mode = false
	GameState.new_run("deck01", 1111)
	GameState.relic_ids.clear()
	GameState.add_relic("relic_drum")
	GameState.ante = 5
	GameState.run_log = {}
	var gb := BattleManager.new()
	gb.restore(_battle_state(normal_id, [], ["c001", "c003", "c321", "c002"]))
	gb._apply_cascade(gb.preview_attack())
	gb.free()
	GameState.last_victory = false
	var ro: Node = load("res://scenes/ui/RunOver.tscn").instantiate()
	add_child(ro)
	await _wait(0.8)
	for n in ro.find_children("Replay", "Button", true, false):
		(n as Button).pressed.emit()
	await _wait(3.5)
	await _shoot("49_rever_maior_golpe")
	SceneRouter.close_overlays()
	ro.queue_free()
	await get_tree().process_frame
	Settings.tips_enabled = true

## 0.12.0: frase do ecrã inicial, NOVO JOGO (modos), escolha do espaço, JOGOS GUARDADOS e mudar o nome.
func _shots_0120() -> void:
	GameState.clear_all_saved_runs()
	MainMenu.return_page = "main"
	# Duas runs gravadas (espaços 1 e 3), uma com nome.
	GameState.current_slot = 1
	GameState.new_run("deck05", 808)
	GameState.ante = 3
	GameState.save_run({}, "map")
	GameState.current_slot = 3
	GameState.free_mode = true
	GameState.new_quick_run("deck02", 1, 909)
	GameState.ante = 2
	GameState.run_name = "Corrida do almoço"
	GameState.save_run({}, "map")
	GameState.free_mode = false
	var menu: Node = load("res://scenes/main/Main.tscn").instantiate()
	add_child(menu)
	await _wait(0.9)
	await _shoot("50_menu_inicio_slots")
	menu._show_page("new", false)
	await _wait(0.4)
	await _shoot("51_novo_jogo_modos")
	menu.get_node("%QuickRun").pressed.emit()
	await _wait(0.5)
	await _shoot("52_escolher_espaco")
	var picker := SceneRouter.top_overlay()
	if picker != null:
		var b3: Button = picker.find_child("Slot3", true, false)
		if b3 != null:
			b3.pressed.emit()
		await _wait(0.3)
		await _shoot("53_substituir_espaco")
		picker.queue_free()
	await get_tree().process_frame
	menu._show_page("saves", false)
	await _wait(0.4)
	await _shoot("54_jogos_guardados")
	menu.get_node("%Rename3").pressed.emit()
	await _wait(0.5)
	await _shoot("55_mudar_nome")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	menu.queue_free()
	await get_tree().process_frame
	GameState.clear_all_saved_runs()
	GameState.current_slot = 1
	# Batalha no Fácil: ▶▶, ORDENAR, MELHOR ORDEM e DICA; depois o grimório com probabilidades.
	GameState.free_mode = false
	GameState.new_run("deck01", 1201)
	GameState.difficulty = "facil"
	Settings.hand_sort = "cost"
	var lib: Array = []
	for id in ["c001", "c002", "c003", "c004", "c008", "c008", "c005", "c006", "c007", "c009"]:
		lib.append({"id": id, "entry": -1})
	var st := _battle_state("bandit", ["c005", "c002", "c008", "c004", "c009"], ["c003", "c001", "c006"], 5)
	st["library"] = lib
	var b := _open_battle(st)
	await _wait(1.6)
	b._on_hint()
	await _wait(0.3)
	await _shoot("56_batalha_dica_ordem")
	b._open_library()
	await _wait(0.5)
	await _shoot("57_grimorio_probabilidades")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	b._celebrate_record(123456, 98765)
	await _wait(0.5)
	await _shoot("58_novo_recorde")
	b.queue_free()
	await get_tree().process_frame
	GameState.difficulty = "normal"
	Settings.hand_sort = ""
	# Estatísticas: Histórico e Cartas (com dados de exemplo); Construtor com código colado.
	var saved_p: Dictionary = GameState.progress.duplicate(true)
	GameState.progress["history"] = []
	GameState.progress["card_stats"] = {}
	var decks := ["deck01", "deck05", "deck09", "deck12"]
	for i in 6:
		GameState.free_mode = i == 2
		GameState.new_run(String(decks[i % decks.size()]), 3000 + i)
		GameState.run_log = {"damage_by_ante": {"1": 1200 * (i + 1), "2": 5400 * (i + 1)}, "card_dmg": {}, "relic_dmg": {}, "card_plays": {}, "best_hit": 4200 * (i + 1)}
		var k := 0
		for e in GameState.deck:
			if k < 5:
				GameState.run_log["card_dmg"][String(e["id"])] = 900 * (5 - k) * (i + 1)
				GameState.run_log["card_plays"][String(e["id"])] = 3 + k
			k += 1
		GameState.run_name = "Corrida do almoço" if i == 1 else ""
		GameState.record_run_end(8 if i % 3 == 0 else 3 + i, i % 3 == 0)
	GameState.free_mode = false
	var stats: Node = load("res://scenes/ui/StatsScreen.tscn").instantiate()
	add_child(stats)
	await _wait(0.4)
	stats.select_tab("history")
	await _wait(0.3)
	await _shoot("59_estatisticas_historico")
	stats.select_tab("cards")
	await _wait(0.3)
	await _shoot("60_estatisticas_cartas")
	stats.select_tab("summary")
	await _wait(0.3)
	await _shoot("61_estatisticas_resumo")
	stats.queue_free()
	await get_tree().process_frame
	var db: Node = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	add_child(db)
	await _wait(0.4)
	db.apply_code(DeckCode.encode("Fúria Vermelha", ["c041", "c041", "c042", "c043", "c044", "c045", "c046", "c047", "c048", "c049", "c050", "c050"]))
	await _wait(0.3)
	await _shoot("62_construtor_codigo")
	db.queue_free()
	await get_tree().process_frame
	GameState.progress = saved_p
	Stats._ensure()
	# Entrada do boss, cometas do golpe final e dano recebido (vinheta e garras).
	GameState.free_mode = false
	GameState.new_run("deck05", 4040)
	GameState.ante = 4
	var bb := _open_battle(_battle_state("boss_zero", ["c005", "c002"], ["c003", "c001", "c006", "c007"]))
	await _wait(1.4)
	bb._boss_intro("")
	await _wait(1.0)
	await _shoot("63_entrada_do_boss")
	for c in bb.get_children():
		if c is BossIntro:
			c.queue_free()
	await _wait(0.3)
	bb._attack_trails()
	await _wait(0.16)
	await _shoot("64_cometas_do_golpe")
	await _wait(0.5)
	DamageVignette.flash(bb, 0.9)
	await _wait(0.1)
	await _shoot("65_dano_recebido")
	bb.queue_free()
	await get_tree().process_frame
	# Imagem de PARTILHAR (o que vai para o WhatsApp).
	GameState.new_run("deck12", 6060)
	GameState.ante = 8
	GameState.run_log = {"damage_by_ante": {"1": 2400, "2": 7100, "3": 15800, "4": 41000, "5": 88000, "6": 160000, "7": 290000, "8": 512000}, "card_dmg": {"c041": 98000}, "relic_dmg": {}, "card_plays": {}, "best_hit": 233000}
	GameState.run_name = "Corrida do almoço"
	var share_img: Image = await RunShare.render(self, RunShare.summary_from_state(true, false))
	if share_img != null:
		share_img.save_png(out_dir.path_join("68_partilhar.png"))
	# Ilustrações (só se houver imagens em assets/art).
	ArtLib.clear_cache()
	if ArtLib.total() > 0:
		GameState.ante = 1
		var ab := _open_battle(_battle_state("boss_gag", ["c001", "c002", "c003", "c004", "c008"], ["c005", "c007", "c010"]))
		await _wait(1.6)
		await _shoot("66_ilustracoes_batalha")
		CardZoom.show_card(CardDB.new_instance("c002"))
		await _wait(0.5)
		await _shoot("67_ilustracao_em_grande")
		SceneRouter.close_overlays()
		ab.queue_free()
		await get_tree().process_frame

## 0.12.1: mão com 2 toques (carta escolhida com JOGAR), carta a flutuar ao arrastar (na mão e por cima
## da Arena), chamas novas e a entrada do boss a 2× (com tempo para ler).
func _shots_0121() -> void:
	GameState.free_mode = false
	GameState.new_run("deck05", 1213)
	GameState.difficulty = "normal"
	Settings.hand_sort = ""
	Settings.play_taps = 2
	var b := _open_battle(_battle_state("bandit", ["c041", "c043", "c044", "c045", "c050"], ["c047", "c046"], 6))
	await _wait(1.6)
	var views: Array = b._hand_views.values()
	if views.size() >= 3:
		var sel: CardView = views[1]
		sel.pressed.emit(sel.card)
		await _wait(0.5)
		await _shoot("69_mao_escolhida")
		b._set_selection(-1)
		await _wait(0.3)
		var drag: CardView = views[0]
		var start: Vector2 = drag.get_global_rect().get_center()
		b._on_hand_drag_started(drag.card, start)
		var hb: Rect2 = b.hand_box.get_global_rect()
		for k in 6:
			b._on_hand_drag_moved(drag.card, start.lerp(Vector2(hb.end.x - 120.0, start.y), (k + 1) / 6.0))
			await _wait(0.05)
		await _wait(0.3)
		await _shoot("70_mao_arrastar")
		b._on_hand_drag_moved(drag.card, Vector2(hb.get_center().x, hb.position.y - 170.0))
		await _wait(0.3)
		await _shoot("71_arrastar_para_jogar")
		b._on_hand_drag_ended(drag.card, Vector2(hb.end.x - 120.0, start.y))
		await _wait(0.4)
	b._fire_target = 0.95
	b._fire_level = 0.95
	await _wait(0.8)
	await _shoot("72_chamas")
	b.queue_free()
	await get_tree().process_frame
	# Entrada do boss a 2×: o texto fica no ecrã o tempo de o ler.
	Settings.anim_speed = "fast"
	GameState.new_run("deck05", 4141)
	GameState.ante = 4
	var bb := _open_battle(_battle_state("boss_zero", ["c005", "c002"], ["c003", "c001"]))
	await _wait(0.6)
	bb._boss_intro("")
	await _wait(2.2)
	await _shoot("73_boss_a_2x")
	bb.queue_free()
	await get_tree().process_frame
	Settings.anim_speed = "normal"

## 0.12.1: jogar uma carta da mão pela UI — dois toques (escolher e jogar), ou um com a opção "1 toque".
func _tap_play(v: CardView) -> void:
	v.pressed.emit(v.card)
	if is_instance_valid(v) and Settings.play_taps == 2:
		v.pressed.emit(v.card)

## 0.13.0: números de ordem e setas do inimigo, escolher quem bloqueia, palavra-chave explicada, total ao
## vivo ao arrastar, sem jogadas, dica no topo, golpe carregado, morte em pó, rever o ataque e vitória.
func _shots_0130() -> void:
	GameState.free_mode = false
	GameState.new_run("deck05", 1301)
	GameState.difficulty = "normal"
	Settings.hand_sort = ""
	Settings.play_taps = 2
	Settings.show_threats = true
	var st := _battle_state("jailer", ["c041", "c043", "c044", "c045", "c050"], ["c047", "c039", "c046", "c015"], 6)
	st["enemy"]["attack"] = 3
	var b := _open_battle(st)
	await _wait(1.6)
	b._refresh_preview()
	await _wait(0.4)
	await _shoot("74_ordem_e_setas")
	b._open_intent()
	await _wait(0.5)
	await _shoot("75_escolher_bloqueio")
	b._close_modal(null)
	await _wait(0.3)
	var bm: BattleManager = b.get_node("BattleManager")
	var flyer: CardInstance = null
	for c in bm.board:
		if c.has_keyword("flying"):
			flyer = c
	if flyer != null:
		var fv: CardView = b._board_views.get(flyer.uid)
		if fv != null and fv._kw_box != null and fv._kw_box.get_child_count() > 0:
			var ic: Control = fv._kw_box.get_child(0)
			b._on_keyword_tapped(flyer, "flying", ic.get_global_rect())
			await _wait(0.4)
			await _shoot("76_palavra_chave")
	var views: Array = b._hand_views.values()
	if views.size() >= 2:
		var drag: CardView = views[1]
		var start: Vector2 = drag.get_global_rect().get_center()
		b._on_hand_drag_started(drag.card, start)
		var hb: Rect2 = b.hand_box.get_global_rect()
		b._on_hand_drag_moved(drag.card, Vector2(hb.get_center().x + 60.0, hb.position.y - 150.0))
		await _wait(0.4)
		await _shoot("77_total_ao_vivo")
		b._on_hand_drag_ended(drag.card, Vector2(hb.end.x - 80.0, start.y))
		await _wait(0.4)
	b.queue_free()
	await get_tree().process_frame
	# Sem jogadas (ATACAR a brilhar) e uma dica no topo.
	GameState.new_run("deck05", 1302)
	var st2 := _battle_state("bandit", ["c045", "c050"], ["c047", "c046"], 0)
	st2["land_played_this_turn"] = true
	st2["actions_this_turn"] = 1
	var b2 := _open_battle(st2)
	await _wait(1.6)
	b2._no_plays_turn = 0
	b2._refresh_preview()
	await _wait(0.5)
	await _shoot("78_sem_jogadas")
	GameState.reset_tips()
	b2._tip_queue.clear()
	b2._tip("block")
	await _wait(0.6)
	await _shoot("79_dica_no_topo")
	b2.queue_free()
	await get_tree().process_frame
	# Golpe carregado: o Berserker Gruul ataca com ×2 neste turno.
	GameState.new_run("deck05", 1303)
	var st3 := _battle_state("berserker", ["c041", "c045"], ["c047", "c044"], 6)
	st3["charge_mult"] = 2.0
	var b3 := _open_battle(st3)
	await _wait(1.8)
	await _shoot("80_golpe_carregado")
	# Morte em pó (a meio da animação) e rever o último ataque.
	var bm3: BattleManager = b3.get_node("BattleManager")
	var victim: CardView = b3._board_views.values()[0]
	b3._animate_death(victim)
	victim.modulate.a = 0.0
	await _wait(0.25)
	await _shoot("81_morte_em_po")
	b3._last_cascade = bm3.preview_attack()
	b3._last_attack_turn = 2
	b3._replay_last_attack()
	await _wait(1.6)
	await _shoot("82_rever_ataque")
	SceneRouter.close_overlays()
	await _wait(0.2)
	# Vitória: o retrato racha e há confetes.
	b3._portrait.defeat()
	CelebrationFx.play(b3, b3.get_viewport_rect(), "confetti")
	b3._show_banner(tr("ANTE %d VENCIDO") % 2, 1.0)
	await _wait(0.7)
	await _shoot("83_vitoria")
	b3.queue_free()
	await get_tree().process_frame
	# Edições: cartas Brilhante, Holográfica e Policromática na mão e na Arena, a carta em grande e a loja.
	GameState.new_run("deck19", 1304)
	var eds := [["c394", "shiny"], ["c399", "holo"], ["c405", "poly"], ["c402", "poly"], ["c408", "shiny"]]
	var st4 := _battle_state("golem", [], [], 6)
	for i in eds.size():
		GameState.add_card(String(eds[i][0]), false, String(eds[i][1]))
		var item := {"id": String(eds[i][0]), "entry": GameState.deck.size() - 1}
		if i < 3:
			st4["board"].append(item)
		else:
			st4["hand"].append(item)
	st4["hand"].append({"id": "c393", "entry": -1})
	var b4 := _open_battle(st4)
	await _wait(1.6)
	await _shoot("84_edicoes_batalha")
	var poly_card: CardInstance = null
	for c in (b4.get_node("BattleManager") as BattleManager).board:
		if c.edition() == "poly":
			poly_card = c
	if poly_card != null:
		CardZoom.show_card(poly_card)
		await _wait(0.6)
		await _shoot("85_edicao_zoom")
		SceneRouter.close_overlays()
		await _wait(0.2)
	b4.queue_free()
	await get_tree().process_frame
	GameState.new_run("deck19", 1305)
	GameState.add_gold(40)
	GameState.map_options(1)
	GameState.choose_stop("shop")
	var shop: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	add_child(shop)
	await _wait(0.5)
	var eds_offer: Array = shop.get("_offer_editions")
	if eds_offer.size() >= 2:
		eds_offer[0] = "holo"
		eds_offer[1] = "poly"
		shop.call("_build_offers")
	await _wait(0.5)
	await _shoot("86_edicoes_loja")
	shop.queue_free()
	await get_tree().process_frame

## 0.13.0 (2.ª parte): poções e afixos, a Hidra, o mapa vivo com paragens novas, a História e os Desafios,
## o Perfil, a Coleção por cor, o Construtor (Selo e curva), a Run Rápida, a mão grande/uma mão, a carta
## em 3D e o baralho com a curva de mana.
func _shots_0130b() -> void:
	GameState.progress["tips_seen"] = (CardDB.tips.keys() as Array).duplicate()
	Settings.show_threats = true
	# Elite com afixos e a barra das poções.
	GameState.free_mode = false
	GameState.new_run("deck05", 1310)
	GameState.ante = 3
	GameState.consumables.clear()
	GameState.add_consumable("potion_heal")
	GameState.add_consumable("scroll_fire")
	var st := _battle_state("bandit", ["c041", "c045", "c050", "c044"], ["c047", "c039"], 6)
	st["enemy"]["affixes"] = ["armored", "vampiric"]
	st["enemy"]["elite"] = true
	var b := _open_battle(st)
	await _wait(1.6)
	await _shoot("87_elite_afixos_pocoes")
	b.queue_free()
	await get_tree().process_frame
	# A Hidra Tricéfala: marcas das fases na barra de vida.
	GameState.ante = 4
	var b2 := _open_battle(_battle_state("boss_hydra3", ["c041", "c045", "c050"], ["c047", "c039", "c046"], 6))
	await _wait(1.8)
	await _shoot("88_boss_hidra_fases")
	b2.queue_free()
	await get_tree().process_frame
	# Mapa vivo: ato II, a seguir à Elite — Loja ou Forja; o Cofre no ante 4; uma poção para usar.
	GameState.new_run("deck05", 1311)
	GameState.ante = 3
	GameState.map_plan = {"3": {"battle": ["scout", "guard", "elite"], "stop": ["shop", "forge"]}, "4": {"battle": ["boss"], "stop": ["shop", "vault"]}}
	GameState.map_choice = {"battle": "elite"}
	GameState.map_phase = "stop"
	GameState.consumables.clear()
	GameState.add_consumable("potion_heal")
	var mp: Node = load("res://scenes/map/Map.tscn").instantiate()
	add_child(mp)
	await _wait(1.2)
	await _shoot("89_mapa_vivo")
	mp.queue_free()
	await get_tree().process_frame
	# O mapa no início de um ato (fase de batalha) e no Infinito.
	GameState.new_run("deck05", 1313)
	GameState.ante = 1
	GameState.map_phase = "battle"
	GameState.progress["interludes_seen"] = ["1", "2", "3", "4", "5"]
	GameState.interlude_key = "1"
	var mp_a: Node = load("res://scenes/map/Map.tscn").instantiate()
	add_child(mp_a)
	await _wait(1.0)
	SceneRouter.close_overlays()
	await _wait(0.3)
	await _shoot("89b_mapa_ato1")
	mp_a.queue_free()
	await get_tree().process_frame
	mp = load("res://scenes/map/Map.tscn").instantiate()
	GameState.new_run("deck05", 1311)
	GameState.ante = 3
	GameState.map_plan = {"3": {"battle": ["scout", "guard", "elite"], "stop": ["shop", "forge"]}, "4": {"battle": ["boss"], "stop": ["shop", "vault"]}}
	GameState.map_choice = {"battle": "elite"}
	GameState.map_phase = "stop"
	GameState.consumables.clear()
	GameState.add_consumable("potion_heal")
	add_child(mp)
	await _wait(0.6)
	mp.call("_on_item", 0)
	await _wait(0.5)
	await _shoot("90_dialogo_pocao")
	SceneRouter.close_overlays()
	await _wait(0.2)
	(mp.find_child("DeckBtn", true, false) as Button).pressed.emit()
	await _wait(0.6)
	await _shoot("91_baralho_curva")
	SceneRouter.close_overlays()
	mp.queue_free()
	await get_tree().process_frame
	# História (Livro III) e Desafios com estrelas.
	GameState.progress["saga"] = {}
	for ch in CardDB.saga:
		if int((ch as Dictionary).get("book", 1)) < 3:
			GameState.progress["saga"][String(ch["id"])] = true
	GameState.progress["challenge_stars"] = {}
	var k := 0
	for c in CardDB.challenges:
		GameState.progress["challenge_stars"][String(c["id"])] = [3, 2, 1, 0][k % 4]
		k += 1
	var saga: Node = load("res://scenes/saga/Saga.tscn").instantiate()
	add_child(saga)
	await _wait(0.4)
	saga.call("_show_book", 3)
	await _wait(0.4)
	await _shoot("92_historia_livro3")
	saga.queue_free()
	await get_tree().process_frame
	await _shoot_scene("res://scenes/challenges/Challenges.tscn", "93_desafios_estrelas", 0.5)
	# Perfil (Estatísticas) e a Coleção por cor.
	GameState.progress["card_stats"] = {"c045": {"plays": 64, "dmg": 18000, "runs": 9, "wins": 3}, "c041": {"plays": 130, "dmg": 9000, "runs": 12, "wins": 5}, "c039": {"plays": 18, "dmg": 26000, "runs": 4, "wins": 1}}
	GameState.progress["deck_xp"] = {"deck05": 26, "deck01": 9}
	for id in Stats.color_set_ids("white"):
		Stats.mark_seen("cards", id, false)
	for id in Stats.color_set_ids("red").slice(0, 40):
		Stats.mark_seen("cards", id, false)
	Stats.set_at_least("wins", 4)
	Stats.set_at_least("best_attack", 1250000)
	await _shoot_scene("res://scenes/ui/StatsScreen.tscn", "94_perfil", 0.6)
	await _shoot_scene("res://scenes/ui/Collection.tscn", "95_colecao_por_cor", 0.8)
	# Construtor: Selo Planar e curva de mana.
	CardDB.custom_decks["custom_1"] = {"id": "custom_1", "num": 0, "name": "Muralha", "custom": true, "cards": ["c039", "c039", "c041", "c043", "c044", "c045", "c045", "c046", "c047", "c050", "c050", "c040"], "colors": ["white"], "size": 12, "difficulty": 0, "mechanic": "x"}
	GameState.progress["custom_stakes"] = {"custom_1": 2}
	var db: Node = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	add_child(db)
	await _wait(0.5)
	(db.find_child("Stake", true, false) as Button).pressed.emit()
	await _wait(0.3)
	await _shoot("96_construtor_selo_curva")
	db.queue_free()
	CardDB.custom_decks.erase("custom_1")
	await get_tree().process_frame
	# Run Rápida: a escada de Selos própria.
	GameState.progress["quick_stakes"] = {"deck05": 2}
	GameState.launch_mode = "quick"
	var camp: Node = load("res://scenes/campaign/Campaign.tscn").instantiate()
	add_child(camp)
	await _wait(0.5)
	camp.call("_select_chapter", "deck05")
	await _wait(0.4)
	await _shoot("97_run_rapida_selos")
	camp.queue_free()
	GameState.free_mode = false
	await get_tree().process_frame
	# Mão a 130 % e modo de uma mão.
	Settings.hand_scale = 1.3
	Settings.one_hand = true
	GameState.new_run("deck05", 1312)
	var b3 := _open_battle(_battle_state("bandit", ["c041", "c045", "c050", "c044", "c043"], ["c047", "c039"], 6))
	await _wait(1.6)
	await _shoot("98_mao_grande_uma_mao")
	b3.queue_free()
	Settings.hand_scale = 1.0
	Settings.one_hand = false
	await get_tree().process_frame
	# Carta em grande em 3D (inclinada).
	Settings.tilt_3d = true
	CardZoom.show_data(CardDB.get_card("c045"))
	await _wait(0.5)
	var z := SceneRouter.top_overlay() as CardZoom
	if z != null:
		z.set_tilt(Vector2(0.75, -0.45))
	await _wait(0.2)
	await _shoot("99_carta_3d")
	SceneRouter.close_overlays()
	await _wait(0.2)
