extends Node
## Tira capturas de ecrã das cenas (precisa de ecrã, p.ex. xvfb):
##   xvfb-run -s "-screen 0 1280x720x24" godot --rendering-method gl_compatibility --path . res://tests/Screenshots.tscn -- --out=/tmp/shots

var out_dir := "/tmp/shots"
var only := ""   # --only=0120: só as capturas dessa versão

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.substr(6)
		if arg.begins_with("--only="):
			only = arg.substr(7)
	DirAccess.make_dir_recursive_absolute(out_dir)
	Opening.played = true   # 0.16.1: sem a abertura animada por cima das capturas do menu
	await get_tree().process_frame
	GameState.progress = {"best_ante": {"deck01": 4, "deck02": 6}, "wins": {}, "difficulty": "normal"}
	Stats._ensure()
	Stats.set_tutorial_done(true)
	GameState.free_mode = false
	Settings.language = "pt"
	Settings.anim_speed = "normal"
	Settings.left_handed = false
	Settings.large_text = false
	Settings.warn_mana = false
	Settings.warn_rare = false
	Settings.compact = false
	Settings.ui_scale = 1.0
	GameState.progress["news_seen"] = String(NewsOverlay.current().get("version", ""))
	Settings.apply()
	if only == "0120":
		await _shots_0120()
		_finish()
		return
	if only == "0121":
		await _shots_0121()
		_finish()
		return
	if only == "0130":
		await _shots_0130()
		await _shots_0130b()
		_finish()
		return
	if only == "0130b":
		await _shots_0130b()
		_finish()
		return
	if only == "0140":
		await _shots_0140()
		_finish()
		return
	if only == "0141":
		await _shots_0141()
		_finish()
		return
	if only == "0150":
		await _shots_0150()
		_finish()
		return
	if only == "0151":
		await _shots_0151()
		_finish()
		return
	if only == "0160":
		await _shots_0160()
		_finish()
		return
	if only == "0160b":
		await _shots_0160b()
		_finish()
		return
	if only == "0161":
		await _shots_0161()
		_finish()
		return
	if only == "0170":
		await _shots_0170()
		_finish()
		return

	await _shoot_scene("res://scenes/main/Main.tscn", "01_menu", 0.9)
	# Configurações por cima do menu, e o menu em inglês.
	var menu: Node = load("res://scenes/main/Main.tscn").instantiate()
	add_child(menu)
	await _wait(0.3)
	var sm := SettingsMenu.open()
	await _wait(0.5)
	await _shoot("01b_configuracoes")
	Settings.language = "en"
	Settings.apply()
	await _wait(0.3)
	await _shoot("01c_configuracoes_en")
	sm.close()
	await _wait(0.3)
	await _shoot("01d_menu_en")
	Settings.language = "pt"
	Settings.apply()
	await _wait(0.2)
	menu._show_page("modes", false)
	await _wait(0.3)
	await _shoot("01e_menu_modos")
	menu._show_page("collection", false)
	await _wait(0.3)
	await _shoot("01f_menu_colecao")
	menu.queue_free()
	# Com uma run gravada: CONTINUAR em primeiro, com o baralho e o ante.
	GameState.new_run("deck05", 808)
	GameState.ante = 3
	GameState.save_run({}, "map")
	await _shoot_scene("res://scenes/main/Main.tscn", "01g_menu_continuar", 0.9)
	GameState.clear_saved_run()
	await get_tree().process_frame
	await _shoot_scene("res://scenes/campaign/Campaign.tscn", "02_campanha", 0.5)
	await _shoot_scene("res://scenes/ui/HowToPlay.tscn", "03_como_jogar", 0.3)
	# Estatísticas (com algumas conquistas), coleção e construtor.
	GameState.new_run("deck05", 2)
	EventBus.damage_dealt.emit("enemy", 120000)
	await _shoot_scene("res://scenes/ui/StatsScreen.tscn", "03b_estatisticas", 0.4)
	await _shoot_scene("res://scenes/ui/Collection.tscn", "03c_colecao", 0.6)
	var builder: Node = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	add_child(builder)
	await _wait(0.4)
	for id in ["c001", "c001", "c002", "c003", "c009", "c018", "c019", "c021", "c028", "c039", "c040", "c050"]:
		builder.call("_add_card", id)
	await _wait(0.3)
	await _shoot("03d_construtor")
	builder.queue_free()
	await get_tree().process_frame
	# Tutorial na primeira batalha.
	Stats.set_tutorial_done(false)
	GameState.new_run("deck01", 9)
	var tut_battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(tut_battle)
	EventBus.battle_ended.disconnect(tut_battle._on_battle_ended)
	await _wait(1.6)
	await _shoot("03e_tutorial")
	tut_battle.queue_free()
	await get_tree().process_frame
	Stats.set_tutorial_done(true)
	# Cartas em inglês + canhoto.
	Settings.language = "en"
	Settings.left_handed = true
	Settings.apply()
	GameState.new_run("deck16", 4)
	var en_battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(en_battle)
	EventBus.battle_ended.disconnect(en_battle._on_battle_ended)
	await _wait(1.6)
	await _shoot("03f_batalha_en_canhoto")
	en_battle.queue_free()
	await get_tree().process_frame
	Settings.language = "pt"
	Settings.left_handed = false
	Settings.apply()

	# Batalha: turno 1 (com Mulligan disponível, planeswalker, selos e uma carta de dupla face),
	# depois com cartas jogadas, depois a meio da cascata.
	GameState.new_run("deck05", 7)
	GameState.add_relic("relic_seal")
	GameState.add_relic("relic_banner")
	GameState.set_planeswalker("pw_white")
	GameState.planeswalker["loyalty"] = 4
	GameState.deck[0]["seal"] = "tithe"
	GameState.deck[1]["seal"] = "fury"
	GameState.add_card("c304")
	GameState.choose_battle("guard")
	var battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(battle)
	EventBus.battle_ended.disconnect(battle._on_battle_ended)
	var bm: BattleManager = battle.get_node("BattleManager")
	bm.enemy.hp = 400000
	bm.enemy.max_hp = 400000
	EventBus.enemy_hp_changed.emit(bm.enemy.hp, bm.enemy.max_hp)
	await _wait(2.0)
	await _shoot("04_batalha_turno1")
	var hand_box: Container = battle.get_node("%Hand")
	# Carta em grande (toque longo), grimório e pausa.
	for view in hand_box.get_children():
		if view is CardView:
			view.long_pressed.emit(view.card)
			break
	await _wait(0.5)
	await _shoot("04b_carta_grande")
	SceneRouter.close_overlays()
	await _wait(0.2)
	(battle.get_node("%LibraryBtn") as Button).pressed.emit()
	await _wait(0.5)
	await _shoot("04c_grimorio")
	SceneRouter.close_overlays()
	await _wait(0.2)
	(battle.get_node("%PauseBtn") as Button).pressed.emit()
	await _wait(0.5)
	await _shoot("04d_pausa")
	SceneRouter.close_overlays()
	await _wait(0.3)
	for i in 3:
		for view in hand_box.get_children():
			if view is CardView and bm.can_play(view.card):
				_tap_play(view)
				break
		await _wait(0.45)
	(battle.get_node("%DiscardBtn") as Button).button_pressed = true
	await _wait(0.3)
	await _shoot("05_batalha_canalizar")
	(battle.get_node("%DiscardBtn") as Button).button_pressed = false
	await _wait(0.2)
	# Avança dois turnos para ter tabuleiro cheio, depois dispara a cascata e captura a meio.
	for t in 2:
		(battle.get_node("%EndTurn") as Button).pressed.emit()
		var t0 := Time.get_ticks_msec()
		var turn_before := bm.turn
		while bm.turn == turn_before and Time.get_ticks_msec() - t0 < 15000 and not bm.finished:
			await get_tree().process_frame
		await _wait(0.9)
		for i in 4:
			for view in hand_box.get_children():
				if view is CardView and bm.can_play(view.card):
					_tap_play(view)
					break
			await _wait(0.35)
	await _shoot("06_batalha_tabuleiro")
	(battle.get_node("%EndTurn") as Button).pressed.emit()
	await _wait(1.2)
	await _shoot("07_batalha_cascata")
	await _wait(2.2)
	await _shoot("08_batalha_impacto")
	await _wait(1.5)
	await _shoot("08b_batalha_turno_seguinte")
	battle.queue_free()
	await get_tree().process_frame

	# Boss (ante 4) e evento.
	GameState.ante = 4
	GameState.damage_player(6)
	var boss_battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(boss_battle)
	EventBus.battle_ended.disconnect(boss_battle._on_battle_ended)
	await _wait(2.2)
	await _shoot("08c_boss")
	boss_battle.queue_free()
	await get_tree().process_frame
	GameState.ante = 2
	GameState.pending_event = "altar"
	await _shoot_scene("res://scenes/event/Event.tscn", "08d_evento", 0.6)
	GameState.pending_event = ""
	GameState.add_gold(30)
	GameState.add_relic("relic_crown")
	GameState.choose_stop("shop")
	await _shoot_scene("res://scenes/shop/Shop.tscn", "09_loja", 0.4)
	GameState.last_victory = false
	await _shoot_scene("res://scenes/ui/RunOver.tscn", "10_fim", 0.8)
	# 0.8.0: mapa (fase de paragem do ante 1), Mercador Cego, acampamento, draft, enigmas, cemitério com recapitular.
	GameState.new_run("deck03", 21)
	GameState.add_gold(30)
	GameState.map_options(1)
	GameState.choose_battle("guard")
	GameState.map_phase = "stop"
	await _shoot_scene("res://scenes/map/Map.tscn", "11_mapa", 0.5)
	GameState.ante = 4
	GameState.map_options(4)
	GameState.choose_stop("merchant")
	await _shoot_scene("res://scenes/shop/Shop.tscn", "12_mercador_cego", 0.5)
	GameState.ante = 1
	GameState.pending_event = "node_altar"
	await _shoot_scene("res://scenes/event/Event.tscn", "13_altar", 0.5)
	GameState.pending_event = ""
	var draft: Node = load("res://scenes/draft/Draft.tscn").instantiate()
	add_child(draft)
	await _wait(0.5)
	await _shoot("14_draft")
	draft.queue_free()
	await get_tree().process_frame
	await _shoot_scene("res://scenes/puzzles/Puzzles.tscn", "15_enigmas", 0.5)
	GameState.new_run("deck03", 22)
	var fb_battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(fb_battle)
	EventBus.battle_ended.disconnect(fb_battle._on_battle_ended)
	var fbm: BattleManager = fb_battle.get_node("BattleManager")
	await _wait(1.2)
	var ritual := CardDB.new_instance("c018")
	ritual.exiled = true
	fbm.deck.to_graveyard(ritual)
	var exiled := CardDB.new_instance("c021")
	fbm.deck.to_exile(exiled)
	fb_battle.call("_refresh_all")
	(fb_battle.get_node("%GraveyardBtn") as Button).pressed.emit()
	await _wait(0.5)
	await _shoot("16_cemiterio_recapitular")
	SceneRouter.close_overlays()
	fb_battle.queue_free()
	await get_tree().process_frame
	# 0.9.0: mapa com clima, contrato, Elite e Tribunal; interlúdio; Baú de Espólio; Tribunal com a roda;
	# boss com fala e marca de metade; fogo nas pílulas; detalhe da cascata; despertar; modo daltónico.
	GameState.new_run("deck05", 127)
	GameState.add_gold(18)
	GameState.map_options(1)
	GameState.map_options(2)
	GameState.choose_battle("scout")
	GameState.map_phase = "stop"
	GameState.set_contract("swift")
	GameState.interlude_key = "1"
	await _shoot_scene("res://scenes/map/Map.tscn", "17_mapa_clima_contrato", 0.7)
	GameState.ante = 3
	GameState.map_phase = "battle"
	GameState.interlude_key = "1"
	var imap: Node = load("res://scenes/map/Map.tscn").instantiate()
	add_child(imap)
	await _wait(1.2)
	await _shoot("17b_interludio_ato")
	SceneRouter.close_overlays()
	imap.queue_free()
	await get_tree().process_frame
	GameState.ante = 4
	GameState.map_phase = "stop"
	GameState.prepare_loot()
	await _shoot_scene("res://scenes/loot/Loot.tscn", "18_bau_espolio", 0.9)
	GameState.ante = 2
	GameState.pending_event = "node_tribunal"
	var trib = load("res://scenes/event/Event.tscn").instantiate()
	add_child(trib)
	await _wait(0.6)
	await _shoot("19_tribunal")
	var gamble_lines: Array[String] = []
	trib._gamble({"gamble": "gold", "cost": 8}, gamble_lines)
	await _wait(1.7)
	await _shoot("19b_tribunal_roda")
	await _wait(3.5)
	trib.queue_free()
	SceneRouter.close_overlays()
	await get_tree().process_frame
	# Boss: fala de entrada, marca de metade, intenção em ícones, chips de clima e contrato.
	GameState.new_run("deck05", 128)
	GameState.ante = 4
	GameState.climates["2"] = "blood_moon"
	GameState.add_relic("relic_seal")
	GameState.add_relic("relic_hungry_grimoire")
	GameState.relic_counters["relic_hungry_grimoire"] = 3
	GameState.add_boss_relic("relic_abyss_chalice")
	GameState.set_contract("army")
	GameState.choose_battle("boss")
	var bb = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(bb)
	EventBus.battle_ended.disconnect(bb._on_battle_ended)
	var bbm: BattleManager = bb.get_node("BattleManager")
	await _wait(1.6)
	# 0.12.1: a entrada do boss fica até ser lida (ou tocada): fecha-a para a fala aparecer.
	for c in bb.get_children():
		if c is BossIntro:
			c.close()
	await _wait(1.2)
	await _shoot("20_boss_fala")
	var bhand: Container = bb.get_node("%Hand")
	for i in 4:
		for view in bhand.get_children():
			if view is CardView and bbm.can_play(view.card):
				_tap_play(view)
				break
		await _wait(0.4)
	var total := bbm.preview_attack().total()
	bbm.enemy.hp = int(total * 1.08)
	EventBus.enemy_hp_changed.emit(bbm.enemy.hp, bbm.enemy.max_hp)
	bb._refresh_preview()
	await _wait(1.4)
	await _shoot("21_fogo_pilulas")
	bb._open_breakdown()
	await _wait(0.6)
	await _shoot("22_detalhe_cascata")
	SceneRouter.close_overlays()
	await _wait(0.3)
	bbm.enemy.max_hp = total * 10
	bbm.enemy.hp = int(total * 5.5)
	EventBus.enemy_hp_changed.emit(bbm.enemy.hp, bbm.enemy.max_hp)
	bb._refresh_preview()
	(bb.get_node("%EndTurn") as Button).pressed.emit()
	var t_start := Time.get_ticks_msec()
	while not bbm.phase2 and Time.get_ticks_msec() - t_start < 20000:
		await get_tree().process_frame
	await _wait(0.45)
	await _shoot("23_boss_desperta")
	await _wait(2.5)
	bb.queue_free()
	await get_tree().process_frame
	# Modo daltónico (símbolos nos pips de cor).
	Settings.colorblind = true
	Settings.apply()
	GameState.new_run("deck13", 31)
	var cbb = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(cbb)
	EventBus.battle_ended.disconnect(cbb._on_battle_ended)
	await _wait(2.0)
	await _shoot("24_modo_daltonico")
	cbb.queue_free()
	await get_tree().process_frame
	Settings.colorblind = false
	Settings.apply()
	await _shots_0100()
	await _shots_0110()
	await _shots_0120()
	await _shots_0121()
	_finish()

## 0.14.0: cartas com o visual "Vidro arcano" (mão, escolhida, em grande, compactas, texto grande, Coleção
## sem ilustrações, draft com cartas maiores) e o menu (círculo de runas com e sem movimento).
func _shots_0140() -> void:
	GameState.new_run("deck06", 11)
	GameState.choose_battle("guard")
	var battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(battle)
	EventBus.battle_ended.disconnect(battle._on_battle_ended)
	await _wait(2.0)
	await _shoot("140a_batalha_mao")
	var hand_box: Container = battle.get_node("%Hand")
	var views := hand_box.get_children().filter(func(v): return v is CardView)
	if not views.is_empty():
		(views[views.size() - 1] as CardView).set_selected(true)
	await _wait(0.3)
	await _shoot("140b_mao_escolhida")
	battle.queue_free()
	await get_tree().process_frame
	for pair in [["c055", "140c_zoom_revelacao"], ["c096", "140d_zoom_dragao"], ["c356", "140e_zoom_lich_mitica"], ["c008", "140f_zoom_terreno"], ["c309", "140g_zoom_missao"]]:
		CardZoom.show_data(CardDB.get_card(String(pair[0])))
		await _wait(0.5)
		await _shoot(String(pair[1]))
		SceneRouter.close_overlays()
		await get_tree().process_frame
	# Mão com cartas de várias cores, raridades e uma missão comprida.
	GameState.new_run("deck05", 3)
	GameState.choose_battle("guard")
	var b2: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(b2)
	EventBus.battle_ended.disconnect(b2._on_battle_ended)
	var bm2: BattleManager = b2.get_node("BattleManager")
	await _wait(0.6)
	while bm2.deck.hand.size() > 2:
		bm2.deck.hand.pop_back()
	for id in ["c096", "c356", "c031", "c309", "c454"]:
		var inst := CardDB.new_instance(id)
		inst.zone = CardInstance.Zone.HAND
		bm2.deck.hand.append(inst)
	EventBus.hand_changed.emit()
	await _wait(1.6)
	await _shoot("140h_mao_varias_cores")
	b2.queue_free()
	await get_tree().process_frame
	Settings.compact = true
	Settings.apply()
	GameState.new_run("deck06", 11)
	GameState.choose_battle("guard")
	var b3: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(b3)
	EventBus.battle_ended.disconnect(b3._on_battle_ended)
	await _wait(1.6)
	await _shoot("140i_compacto")
	b3.queue_free()
	await get_tree().process_frame
	Settings.compact = false
	Settings.large_text = true
	Settings.apply()
	var b4: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(b4)
	EventBus.battle_ended.disconnect(b4._on_battle_ended)
	await _wait(1.6)
	await _shoot("140j_texto_grande")
	b4.queue_free()
	await get_tree().process_frame
	Settings.large_text = false
	Settings.apply()
	await _shoot_scene("res://scenes/ui/Collection.tscn", "140k_colecao", 0.6)
	var draft: Node = load("res://scenes/draft/Draft.tscn").instantiate()
	add_child(draft)
	await _wait(0.5)
	await _shoot("140l_draft")
	draft.queue_free()
	await get_tree().process_frame
	await _shoot_scene("res://scenes/main/Main.tscn", "140m_menu", 0.9)
	Settings.reduce_motion = true
	Settings.apply()
	await _shoot_scene("res://scenes/main/Main.tscn", "140n_menu_sem_movimento", 0.6)
	Settings.reduce_motion = false
	Settings.apply()

## 0.14.1: cartas com o visual "Arte em destaque" — mão, carta escolhida, cartas em grande (duas cores, rara,
## mítica, Terreno, missão), mão variada, Arena com palavras-chave, compacto, texto grande, daltónico,
## Coleção (sem ilustrações), draft (cartas maiores), loja e cartas em grande sem ilustração.
func _shots_0141() -> void:
	Settings.tips_enabled = false
	GameState.new_run("deck06", 11)
	GameState.choose_battle("guard")
	var battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(battle)
	EventBus.battle_ended.disconnect(battle._on_battle_ended)
	await _wait(2.0)
	await _shoot("141a_batalha_mao")
	var hand_box: Container = battle.get_node("%Hand")
	var views := hand_box.get_children().filter(func(v): return v is CardView)
	if not views.is_empty():
		(views[views.size() - 1] as CardView).set_selected(true)
	await _wait(0.3)
	await _shoot("141b_mao_escolhida")
	battle.queue_free()
	await get_tree().process_frame
	for pair in [["c055", "141c_zoom_revelacao"], ["c096", "141d_zoom_dragao"], ["c356", "141e_zoom_lich_mitica"], ["c008", "141f_zoom_terreno"], ["c309", "141g_zoom_missao"]]:
		CardZoom.show_data(CardDB.get_card(String(pair[0])))
		await _wait(0.5)
		await _shoot(String(pair[1]))
		SceneRouter.close_overlays()
		await get_tree().process_frame
	# Mão com cartas de várias cores, raridades e uma missão comprida.
	GameState.new_run("deck05", 3)
	GameState.choose_battle("guard")
	var b2: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(b2)
	EventBus.battle_ended.disconnect(b2._on_battle_ended)
	var bm2: BattleManager = b2.get_node("BattleManager")
	await _wait(0.6)
	while bm2.deck.hand.size() > 2:
		bm2.deck.hand.pop_back()
	for id in ["c096", "c356", "c031", "c309", "c454"]:
		var inst := CardDB.new_instance(id)
		inst.zone = CardInstance.Zone.HAND
		bm2.deck.hand.append(inst)
	EventBus.hand_changed.emit()
	await _wait(1.6)
	await _shoot("141h_mao_varias_cores")
	b2.queue_free()
	await get_tree().process_frame
	# Arena com criaturas e palavras-chave; na mão, todos os tipos.
	GameState.new_run("deck05", 1110)
	GameState.relic_ids.clear()
	GameState.ante = 2
	var normal_id := ""
	for e in CardDB.enemies:
		if not bool(e.get("boss", false)) and not bool(e.get("saga", false)) and normal_id == "":
			normal_id = String(e.get("id", ""))
	var tb := _open_battle(_battle_state(normal_id, ["c339", "c345", "c331", "c040", "c050", "c008"], ["c043", "c020", "c031", "c046"]))
	await _wait(1.8)
	await _shoot("141i_arena_tipos")
	tb.queue_free()
	await get_tree().process_frame
	for mode in ["compact", "large", "colorblind"]:
		Settings.compact = mode == "compact"
		Settings.large_text = mode == "large"
		Settings.colorblind = mode == "colorblind"
		Settings.apply()
		GameState.new_run("deck06", 11)
		GameState.choose_battle("guard")
		var bx: Node = load("res://scenes/battle/Battle.tscn").instantiate()
		add_child(bx)
		EventBus.battle_ended.disconnect(bx._on_battle_ended)
		await _wait(1.6)
		await _shoot({"compact": "141j_compacto", "large": "141k_texto_grande", "colorblind": "141l_daltonico"}[mode])
		bx.queue_free()
		await get_tree().process_frame
	Settings.compact = false
	Settings.large_text = false
	Settings.colorblind = false
	Settings.apply()
	# Coleção: sem ilustrações (fica o sigilo da carta); algumas cartas já vistas.
	for c in CardDB.collectible_cards():
		var cd := c as CardData
		if cd.num <= 40:
			Stats.mark_seen("cards", cd.id, false)
	await _shoot_scene("res://scenes/ui/Collection.tscn", "141m_colecao", 0.6)
	var draft: Node = load("res://scenes/draft/Draft.tscn").instantiate()
	add_child(draft)
	await _wait(0.5)
	await _shoot("141n_draft")
	draft.queue_free()
	await get_tree().process_frame
	GameState.new_run("deck19", 1305)
	GameState.add_gold(40)
	GameState.map_options(1)
	GameState.choose_stop("shop")
	await _shoot_scene("res://scenes/shop/Shop.tscn", "141o_loja", 0.6)
	# Cartas em grande sem ilustração (sigilo e paisagem do Terreno).
	var show0 := Settings.show_art
	Settings.show_art = false
	for pair in [["c096", "141p_zoom_sem_arte"], ["c008", "141q_zoom_terreno_sem_arte"]]:
		CardZoom.show_data(CardDB.get_card(String(pair[0])))
		await _wait(0.5)
		await _shoot(String(pair[1]))
		SceneRouter.close_overlays()
		await get_tree().process_frame
	Settings.show_art = show0

## 0.15.0: mecânicas novas na batalha (Ponto fraco, ritual, Coroa, Energia, Mana de Sangue, Veterano), cartas
## em grande, loja com Constelação e DESFAZER, escolha da formação, 8 selos, PORQUE PERDI?, costas novas,
## números grandes do Infinito e o Livro II da História (nomes novos).
func _shots_0150() -> void:
	Settings.tips_enabled = false
	GameState.new_run("deck07", 1501)
	GameState.relic_ids.clear()
	GameState.ante = 4
	var st := _battle_state("boss_toll", ["c476", "c474", "c479", "c481", "c477"], ["c466", "c464", "c480"])
	st["weak_color"] = "blue"
	var b := _open_battle(st)
	var bm: BattleManager = b.get_node("BattleManager")
	await _wait(0.8)
	bm.enemy["ritual"] = CardDB.enemy_def("boss_toll").get("ritual", {})
	bm._ritual_turn_start()
	bm.gain_crown()
	bm.gain_energy(3)
	if not bm.board.is_empty():
		bm.board[0].deck_entry = {"id": bm.board[0].data.id, "vet_stars": 2, "vet_attacks": 12}
	b._refresh_all()
	await _wait(1.4)
	await _shoot("150a_batalha_mecanicas")
	if not bm.board.is_empty():
		CardZoom.show_card(bm.board[0])
		await _wait(0.5)
		await _shoot("150b_zoom_veterano")
		SceneRouter.close_overlays()
		await get_tree().process_frame
	b.queue_free()
	await get_tree().process_frame
	CardZoom.show_data(CardDB.get_card("c477"))
	await _wait(0.5)
	await _shoot("150c_zoom_mana_de_sangue")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	# Loja: Constelação (e a escolha da formação) e DESFAZER depois de uma compra.
	GameState.new_run("deck06", 1502)
	GameState.add_gold(40)
	GameState.map_options(1)
	GameState.choose_stop("shop")
	GameState.player_hp = 12
	var shop: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	add_child(shop)
	await _wait(0.6)
	(shop.get_node("%HealBtn") as Button).pressed.emit()
	await _wait(0.3)
	await _shoot("150d_loja_constelacao_desfazer")
	var star: Button = shop.get_node("%CardOffers").find_child("ConstellationOffer", false, false)
	if star != null:
		star.pressed.emit()
		await _wait(0.5)
		await _shoot("150e_constelacao_formacoes")
		SceneRouter.close_overlays()
		await get_tree().process_frame
	SealPicker.open(func(_id): pass)
	await _wait(0.5)
	await _shoot("150f_selos")
	SceneRouter.close_overlays()
	shop.queue_free()
	await get_tree().process_frame
	# Fim da run com derrota: PORQUE PERDI?
	GameState.new_run("deck01", 1503)
	GameState.ante = 3
	GameState.player_hp = 0
	GameState.last_victory = false
	GameState.last_loss = {"cause": "turns", "enemy": "Guarda de Ferro", "boss": false, "hp_left_pct": 32, "unspent_mana": 6, "unspent_turns": 2,
		"discards_left": 2, "shield": true, "shield_absorbed": 4200, "trample_attacks": 0, "creatures_died": 1, "life_lost": 8, "rituals_resolved": 0, "turns": 5}
	var ro: Node = load("res://scenes/ui/RunOver.tscn").instantiate()
	add_child(ro)
	await _wait(0.8)
	var why = ro.find_child("WhyLost", true, false)
	if why is Button:
		(why as Button).pressed.emit()
		await _wait(0.5)
	await _shoot("150g_porque_perdi")
	SceneRouter.close_overlays()
	ro.queue_free()
	await get_tree().process_frame
	GameState.last_loss = {}
	# As 7 costas novas.
	var bg := ColorRect.new()
	bg.color = Color(0.08, 0.07, 0.12)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var row := HBoxContainer.new()
	row.position = Vector2(40, 250)
	row.add_theme_constant_override("separation", 26)
	bg.add_child(row)
	for id in ["x_glass", "x_gears", "x_stars", "x_runes", "x_scales", "x_pumpkin", "x_snow"]:
		var cb := CardBack.new()
		cb.custom_minimum_size = Vector2(150, 214)
		cb.back_id = id
		row.add_child(cb)
	await _wait(0.4)
	await _shoot("150h_costas_novas")
	bg.queue_free()
	await get_tree().process_frame
	# Infinito: números grandes abreviados.
	GameState.new_run("deck01", 1504)
	GameState.endless = true
	GameState.ante = 14
	var st2 := _battle_state("boss_gag", ["c001", "c002"], ["c031", "c043"])
	st2["enemy"]["hp"] = 1234567890
	st2["enemy"]["max_hp"] = 1500000000
	var b2 := _open_battle(st2)
	await _wait(1.6)
	await _shoot("150i_infinito_numeros")
	b2.queue_free()
	await get_tree().process_frame
	GameState.endless = false
	# História, Livro II: as fações (nomes novos).
	var sg: Node = load("res://scenes/saga/Saga.tscn").instantiate()
	add_child(sg)
	await _wait(0.5)
	if sg.has_method("_show_book"):
		sg.call("_show_book", 2)
	await _wait(0.4)
	await _shoot("150j_historia_livro2")
	sg.queue_free()
	await get_tree().process_frame

## 0.15.1: as cartas e as relíquias da 0.15.0 com ilustração.
func _shots_0151() -> void:
	Settings.tips_enabled = false
	Settings.show_art = true
	GameState.new_run("deck07", 1511)
	GameState.relic_ids.clear()
	for id in ["relic_thorn_crown", "relic_aether_battery", "relic_aether_coil", "relic_torn_grimoire", "relic_five_realms",
			"relic_bronze_phoenix", "relic_duelist", "relic_veteran_medal", "relic_hunter_lens", "relic_broken_hourglass",
			"relic_phyrexian_flask", "relic_butcher_purse"]:
		GameState.add_relic(id)
	GameState.ante = 4
	var b := _open_battle(_battle_state("boss_toll", ["c482", "c483", "c484", "c485", "c486"], ["c455", "c462", "c467", "c474"]))
	await _wait(1.6)
	await _shoot("151a_batalha_cartas_novas")
	b.queue_free()
	await get_tree().process_frame
	var b2 := _open_battle(_battle_state("boss_toll", ["c470", "c471", "c475", "c477", "c469"], ["c457", "c461", "c466", "c481"]))
	await _wait(1.6)
	await _shoot("151b_batalha_feiticos_novos")
	b2.queue_free()
	await get_tree().process_frame
	for id in ["c487", "c470"]:
		CardZoom.show_data(CardDB.get_card(id))
		await _wait(0.5)
		await _shoot("151c_zoom_" + id)
		SceneRouter.close_overlays()
		await get_tree().process_frame
	GameState.relic_ids.clear()

## 0.16.0: a batalha, a loja e as janelas com o visual novo.
func _shots_0160() -> void:
	Settings.tips_enabled = false
	Settings.show_art = true
	GameState.new_run("deck07", 1601)
	GameState.relic_ids.clear()
	for id in ["relic_thorn_crown", "relic_aether_battery", "relic_duelist", "relic_veteran_medal"]:
		GameState.add_relic(id)
	GameState.ante = 4
	GameState.planeswalker = {"id": "pw_red", "loyalty": 4}
	var st := _battle_state("boss_toll", ["c482", "c470", "c475", "c477", "c469"], ["c455", "c462", "c040"])
	for id in ["c001", "c002", "c003", "c004", "c005", "c006"]:
		st["library"].append({"id": id, "entry": -1})
	for id in ["c464", "c466"]:
		st["graveyard"].append({"id": id, "entry": -1})
	var b := _open_battle(st)
	await _wait(0.45)
	await _shoot("160a_letreiro_faixa_de_luz")
	await _wait(2.2)
	await _shoot("160b_batalha")
	# Feitiços em miniatura, a carta letal e as setas de sinergia.
	var bm: BattleManager = b.get_node("BattleManager")
	for c in bm.deck.hand.duplicate():
		if c.data.id == "c475":
			bm.deck.hand.erase(c)
			bm.spells_this_turn.append(c)
	bm.enemy["hp"] = 2600
	EventBus.enemy_hp_changed.emit(2600, 60000)
	b._refresh_all()
	for c in bm.deck.hand:
		if c.data.id == "c470":
			b._set_selection(c.uid)
	await _wait(0.6)
	await _shoot("160c_feiticos_letal_sinergia")
	b._set_selection(-1)
	# 2.ª fase do boss: expressão furiosa, fundo vermelho, tapete rachado e a barra estalada.
	bm.enemy["hp"] = 20000
	bm.phase2 = true
	EventBus.enemy_hp_changed.emit(20000, 60000)
	b._on_boss_phase2("")
	await _wait(1.8)
	await _shoot("160d_boss_furioso")
	CardZoom.show_relic("relic_thorn_crown")
	await _wait(0.6)
	await _shoot("160e_reliquia_em_grande")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	b.queue_free()
	await get_tree().process_frame
	# Arena vazia: os lugares numerados (e o que acende ao arrastar).
	GameState.planeswalker = {}
	var b2 := _open_battle(_battle_state("bandit", ["c001", "c043", "c031"], []))
	await _wait(2.4)
	var bm2: BattleManager = b2.get_node("BattleManager")
	b2._hand_drag_card = bm2.deck.hand[0]
	b2._play_zone = true
	b2._sync_arena_floor()
	await _wait(0.3)
	await _shoot("160f_arena_vazia_lugares")
	b2._hand_drag_card = null
	b2._play_zone = false
	b2.queue_free()
	await get_tree().process_frame
	# 52: eventos e paragens com a ilustração (3 e 4 opções).
	for ev in [["well", "160h_evento_com_imagem"], ["node_rest", "160i_paragem_com_imagem"]]:
		GameState.pending_event = String(ev[0])
		await _shoot_scene("res://scenes/event/Event.tscn", String(ev[1]), 0.7)
	GameState.pending_event = ""
	# Recompensas.
	var rw := BattleRewards.open(self, "ANTE 4 VENCIDO", [["overkill", 2], ["victory", 8], ["turns", 3, 3], ["perfect", 3]], [["relic", "relic_duelist"], ["item", "potion_heal"]], 21, 37)
	await _wait(4.2)
	await _shoot("160g_recompensas")
	rw.queue_free()
	await get_tree().process_frame

## 0.16.0 (parte 2): a loja nova (cartas a sério, relíquias com imagem, VENDIDO, ranhuras, Vale), o booster a
## abrir, o Mercador Cego, as janelas (relíquia com VENDER, patrono, clima), a pausa e o grimório com separadores.
func _shots_0160b() -> void:
	Settings.tips_enabled = false
	Settings.show_art = true
	GameState.new_run("deck07", 1602)
	GameState.relic_ids.clear()
	for id in ["relic_aether_battery", "relic_veteran_medal", "relic_ruby"]:
		GameState.add_relic(id)
	GameState.add_relic("relic_sapphire")
	GameState.ante = 2
	GameState.gold = 24
	GameState.map_options(2)
	GameState.choose_stop("shop")
	var shop: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	add_child(shop)
	await _wait(1.6)
	var tiles: Array = shop.get("_tiles")
	if tiles.size() > 1:
		shop.call("_on_tile_tapped", tiles[1])
	var relic_btn: Button = null
	for b in (shop.get_node("%RelicOffers") as VBoxContainer).get_children():
		if String(b.get_meta("kind", "")) == "relic":
			relic_btn = b
			break
	if relic_btn != null:
		GameState.gold += 20
		relic_btn.pressed.emit()
	await _wait(0.9)
	await _shoot("160j_loja_nova")
	shop.call("_open_owned", "relic_ruby")
	await _wait(0.6)
	await _shoot("160k_reliquia_com_vender")
	SceneRouter.close_overlays()
	await _wait(0.3)
	shop.call("_on_booster")
	await _wait(3.6)
	await _shoot("160l_booster_aberto")
	SceneRouter.close_overlays()
	await _wait(0.3)
	shop.queue_free()
	await get_tree().process_frame
	GameState.ante = 4
	GameState.map_options(4)
	GameState.choose_stop("merchant")
	await _shoot_scene("res://scenes/shop/Shop.tscn", "160m_mercador_cego", 1.2)
	# Janelas.
	CardZoom.show_planeswalker("pw_red")
	await _wait(0.5)
	await _shoot("160n_janela_patrono")
	SceneRouter.close_overlays()
	await _wait(0.2)
	CardZoom.show_climate("meteor_rain")
	await _wait(0.5)
	await _shoot("160o_janela_clima")
	SceneRouter.close_overlays()
	await _wait(0.2)
	# Pausa e grimório numa batalha.
	GameState.climates["1"] = "tailwind"
	var st := _battle_state("bandit", ["c001", "c043", "c031"], [])
	for id in ["c001", "c002", "c003", "c004", "c005", "c040", "c050"]:
		st["library"].append({"id": id, "entry": -1})
	var b := _open_battle(st)
	await _wait(1.6)
	(b.get_node("%PauseBtn") as Button).pressed.emit()
	await _wait(0.5)
	await _shoot("160p_pausa_resumo")
	SceneRouter.close_overlays()
	await _wait(0.3)
	(b.get_node("%LibraryBtn") as Button).pressed.emit()
	await _wait(0.6)
	await _shoot("160q_grimorio_separadores")
	SceneRouter.close_overlays()
	b.queue_free()
	await get_tree().process_frame

## 0.16.1: a Coleção em grelha + painel (cartas com ilustrações, relíquias, Bestiário, Galeria, cosméticos),
## «SÓ A ARTE» e a carta em grande com o botão.
func _shots_0161() -> void:
	Settings.show_art = true
	_seed_collection_0161()
	var col: Node = load("res://scenes/ui/Collection.tscn").instantiate()
	add_child(col)
	await _wait(0.9)
	await _shoot("161a_colecao_cartas")
	col.call("_select_tab", "relics")
	col.call("_select_item", "relic_ruby")
	await _wait(0.8)
	await _shoot("161b_colecao_reliquias")
	col.call("_select_item", "relic_thorn_crown")
	await _wait(0.3)
	await _shoot("161b2_reliquia_por_descobrir")
	col.call("_select_tab", "enemies")
	col.call("_select_item", "boss_hydra")
	await _wait(0.8)
	await _shoot("161c_colecao_bestiario")
	col.call("_select_tab", "gallery")
	await _wait(1.2)
	await _shoot("161d_colecao_galeria")
	(col.find_child("Chip_places", true, false) as Button).pressed.emit()
	await _wait(1.2)
	await _shoot("161e_galeria_lugares")
	(col.find_child("ArtOnly", true, false) as Button).pressed.emit()
	await _wait(0.6)
	await _shoot("161f_so_a_arte")
	SceneRouter.close_overlays()
	col.call("_select_tab", "cosmetics")
	await _wait(0.8)
	await _shoot("161g_colecao_cosmeticos")
	(col.find_child("Chip_mat", true, false) as Button).pressed.emit()
	await _wait(0.6)
	await _shoot("161h_cosmeticos_tapetes")
	(col.find_child("Chip_frame", true, false) as Button).pressed.emit()
	await _wait(0.6)
	await _shoot("161h2_cosmeticos_molduras")
	(col.find_child("Chip_effect", true, false) as Button).pressed.emit()
	await _wait(0.6)
	await _shoot("161h3_cosmeticos_efeitos")
	col.call("_select_tab", "cards")
	await _wait(0.5)
	CardZoom.show_card(CardDB.new_instance("c043"))
	await _wait(0.6)
	await _shoot("161i_carta_so_a_arte")
	SceneRouter.close_overlays()
	col.queue_free()
	await get_tree().process_frame
	# Talentos em árvore (V53).
	GameState.progress["talent_points"] = 12
	GameState.progress["talents"] = {"t_gold": 2, "t_bounty": 1, "t_interest": 1, "t_gems": 1, "t_relic": 1, "t_life": 1, "t_block": 1}
	await _shoot_scene("res://scenes/talents/Talents.tscn", "161j_talentos_arvore", 0.8)
	# Estatísticas: resumo por baralho com o histórico (V55/V56) e as medalhas (V54).
	_seed_history_0161()
	var st: Node = load("res://scenes/ui/StatsScreen.tscn").instantiate()
	add_child(st)
	await _wait(0.4)
	st.call("select_tab", "summary")
	await _wait(0.6)
	await _shoot("161k_estatisticas_resumo")
	st.call("select_tab", "history")
	await _wait(0.6)
	await _shoot("161l_estatisticas_historico")
	st.call("select_tab", "achievements")
	await _wait(0.6)
	await _shoot("161m_estatisticas_conquistas")
	st.queue_free()
	await get_tree().process_frame
	# Construtor (V52).
	CardDB.custom_decks["custom_1"] = {"id": "custom_1", "name": "Fogo Rápido", "cards": ["c001", "c001", "c002", "c003", "c004", "c004", "c005", "c006", "c007", "c008", "c041", "c043"], "custom": true}
	var db: Node = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	add_child(db)
	await _wait(1.0)
	await _shoot("161n_construtor")
	db.queue_free()
	CardDB.custom_decks.erase("custom_1")
	await get_tree().process_frame
	# Mapa: o estado com ícones, a poção com a ilustração e a névoa no fim do ato (68, V58).
	GameState.new_run("deck05", 16102)
	GameState.consumables = ["potion_heal", "scroll_fire"]
	GameState.interlude_key = GameState.climate_key(GameState.ante)
	GameState.map_options(1)
	await _shoot_scene("res://scenes/map/Map.tscn", "161o_mapa", 1.6)
	# Interlúdio com a ilustração a aproximar-se e a história a escrever-se (67).
	var il := ActInterlude.new()
	SceneRouter.show_overlay(il)
	il._build("2")
	await _wait(1.4)
	await _shoot("161p_interludio")
	SceneRouter.close_overlays()
	await _wait(0.2)
	# Abertura (66) a meio.
	var op := Opening.new()
	add_child(op)
	await _wait(0.85)
	await _shoot("161q_abertura")
	op.queue_free()
	# Aviso de cosmético novo (V62).
	SceneRouter._toast_queue.append(["Aurora", 3.0, false, {"kind": "back", "id": "dawn"}])
	SceneRouter._pump_toasts()
	await _wait(0.7)
	await _shoot_scene("res://scenes/ui/Collection.tscn", "161r_aviso_cosmetico", 0.1)
	# Trocas de ecrã (V63): a névoa e o círculo a meio.
	var router_script: GDScript = load("res://scripts/autoload/SceneRouter.gd")
	for style in ["fog", "iris"]:
		var fx = router_script.CoverFx.new()
		fx.style = style
		add_child(fx)
		fx.progress = 0.55
		await _wait(0.2)
		await _shoot("161s_troca_" + style)
		fx.queue_free()
	await get_tree().process_frame

## 0.17.0: Torre do Arquimago, Corrida de Bosses, Treino contra bosses, Diário do Mago, histórias em cadeia,
## Pactos do Infinito e os inimigos novos.
func _shots_0170() -> void:
	Settings.show_art = true
	var defeated := {}
	for id in ["boss_gag", "boss_toll", "boss_hydra", "boss_ash_titan", "boss_ritual_king", "boss_thousand_hands", "slime", "bandit", "weaver"]:
		defeated[id] = 1
		Stats.mark_seen("enemies", id, false)
	GameState.progress["defeated"] = defeated
	GameState.progress["tower_best"] = 14
	GameState.progress["wins"] = {"deck01": 1}
	# Páginas e conquistas abertas em silêncio: os avisos tapavam as capturas.
	Stats.check_diary(false)
	Stats._check_achievements()
	await _wait(0.3)
	_clear_toasts()
	# Menu: NOVO JOGO com a Torre e a Corrida; APRENDER E TREINAR.
	var menu: Node = load("res://scenes/main/Main.tscn").instantiate()
	add_child(menu)
	await _wait(0.4)
	menu._show_page("new", false)
	await _wait(0.4)
	await _shoot("170a_novo_jogo")
	menu._show_page("modes", false)
	await _wait(0.3)
	await _shoot("170a2_aprender_treinar")
	menu.queue_free()
	await get_tree().process_frame
	# Escolha do baralho: a Campanha (o texto da variante por baixo) e a Torre e a Corrida.
	await _shoot_scene("res://scenes/campaign/Campaign.tscn", "170b0_campanha", 0.8)
	GameState.launch_mode = "tower"
	GameState.free_mode = true
	await _shoot_scene("res://scenes/campaign/Campaign.tscn", "170b_torre_baralho", 0.8)
	GameState.launch_mode = "rush"
	await _shoot_scene("res://scenes/campaign/Campaign.tscn", "170b2_corrida_baralho", 0.8)
	# Torre: a caminho do andar 3, o prémio de um andar de boss e de um andar normal; a Corrida.
	GameState.new_tower_run("deck01", 17001)
	GameState.ante = 3
	GameState.player_hp = 14
	GameState.relic_ids = ["relic_ruby", "relic_banner"]
	GameState.map_choice = {"battle": "scout"}
	await _shoot_scene("res://scenes/tower/Tower.tscn", "170c_torre_andar", 0.9)
	GameState.ante = 5
	GameState.tower_prepare_offer()
	await _shoot_scene("res://scenes/tower/Tower.tscn", "170d_torre_premio_boss", 0.9)
	GameState.ante = 7
	GameState.tower_prepare_offer()
	await _shoot_scene("res://scenes/tower/Tower.tscn", "170d2_torre_premio", 0.9)
	GameState.new_rush_run("deck02", 17002)
	GameState.rush_boss_won(3)
	GameState.rush_next()
	GameState.rush_boss_won(2)
	GameState.rush_next()
	await _shoot_scene("res://scenes/tower/Tower.tscn", "170e_corrida", 0.9)
	# Batalhas: na Torre (andar), a Tecelã de Espelhos, o Colosso de Bronze e o Rei dos Rituais com o ritual.
	GameState.new_tower_run("deck05", 17003)
	GameState.ante = 6
	GameState.relic_ids = ["relic_ruby", "relic_banner"]
	var b := _open_battle(_battle_state("weaver", ["c039", "c040", "c041"], ["c043"]))
	await _wait(1.8)
	await _shoot("170f_batalha_torre")
	b.queue_free()
	await get_tree().process_frame
	GameState.free_mode = false
	GameState.new_run("deck05", 17004)
	GameState.ante = 4
	var st := _battle_state("boss_ritual_king", ["c039", "c040", "c041"], ["c043"])
	st["enemy"]["boss"] = true
	st["ritual"] = {"turns": 2, "action": "drain_mana", "value": 2, "text": "Tira-te 2 de mana no turno seguinte"}
	var b2 := _open_battle(st)
	await _wait(1.8)
	await _shoot("170g_rei_dos_rituais")
	b2.queue_free()
	await get_tree().process_frame
	var b3 := _open_battle(_battle_state("bronze_colossus", ["c039", "c040"], ["c043", "c041"]))
	await _wait(1.8)
	await _shoot("170g2_colosso_bronze")
	b3.queue_free()
	await get_tree().process_frame
	# Treino: o modo Boss.
	GameState.training = {"target": "boss", "boss": "boss_ritual_king", "deck": "deck03", "relics": ["relic_ruby"]}
	await _shoot_scene("res://scenes/training/Training.tscn", "170h_treino_boss", 0.6)
	# Fim da Torre e fim da Corrida.
	GameState.new_tower_run("deck04", 17005)
	GameState.ante = 17
	GameState.last_victory = false
	await _shoot_scene("res://scenes/ui/RunOver.tscn", "170i_fim_torre", 1.0)
	GameState.new_rush_run("deck02", 17006)
	for t in [2, 3, 2, 2, 3, 2]:
		GameState.rush_boss_won(t)
		if GameState.ante < GameState.max_ante:
			GameState.rush_next()
	GameState.last_victory = true
	await _shoot_scene("res://scenes/ui/RunOver.tscn", "170i2_fim_corrida", 1.0)
	# Diário do Mago.
	Stats.check_diary(false)
	var col: Node = load("res://scenes/ui/Collection.tscn").instantiate()
	add_child(col)
	await _wait(0.6)
	col.call("_select_tab", "diary")
	await _wait(0.6)
	await _shoot("170j_diario")
	col.call("_select_item", "d06")
	await _wait(0.5)
	await _shoot("170j2_diario_hidra")
	col.call("_select_item", "d20")
	await _wait(0.4)
	await _shoot("170k_diario_fechada")
	col.queue_free()
	await get_tree().process_frame
	# Mapa com a História por viver e o evento em cadeia.
	GameState.free_mode = false
	GameState.new_run("deck05", 17007)
	GameState.interlude_key = GameState.climate_key(GameState.ante)
	GameState.map_phase = "stop"
	GameState.map_choice = {"battle": "scout"}
	GameState.map_options(1)
	await _shoot_scene("res://scenes/map/Map.tscn", "170l_mapa_historia", 1.6)
	GameState.pending_event = GameState.chain_next_event()
	await _shoot_scene("res://scenes/event/Event.tscn", "170m_evento_cadeia", 1.0)
	# Pacto do Infinito (por cima do mapa).
	GameState.new_run("deck05", 17008)
	GameState.endless = true
	GameState.ante = 12
	GameState.interlude_key = GameState.climate_key(GameState.ante)
	GameState.pact_offer = ["ec_vitality", "ec_greed", "ec_fury"]
	GameState.map_options(12)
	await _shoot_scene("res://scenes/map/Map.tscn", "170n_pacto", 1.8)
	SceneRouter.close_overlays()
	await _wait(0.2)

## Algumas runs no histórico e recordes por baralho, para as capturas das Estatísticas.
func _seed_history_0161() -> void:
	var now := int(Time.get_unix_time_from_system())
	var runs := [["deck20", 4, false, "dificil", 3], ["deck01", 8, true, "normal", 2], ["deck06", 2, false, "normal", 3], ["deck08", 5, false, "dificil", 1],
		["deck01", 7, false, "normal", 2], ["deck09", 3, false, "normal", 4], ["deck03", 3, false, "dificil", 4], ["deck05", 2, false, "normal", 1]]
	var h: Array = []
	var i := 0
	for r in runs:
		var d := CardDB.get_deck(String(r[0]))
		h.append({"t": now - 3600 * (i * 7 + 1), "mode": "campaign", "deck_id": String(r[0]), "deck": String(d.get("name", "")), "challenge": "", "saga": "",
			"ante": int(r[1]), "max_ante": 8, "won": bool(r[2]), "endless": false, "abandoned": false, "difficulty": String(r[3]), "stake": int(r[4]),
			"best_hit": 1200 * (i + 3), "damage": 40000 + i * 3000, "relics": 4, "cards": 22, "enemy": "", "mvp": "c00%d" % (i + 1), "seed": 1000 + i, "name": "", "free": false})
		i += 1
	GameState.progress["history"] = h
	GameState.progress["best_ante"] = {"deck01": 8, "deck02": 8, "deck03": 5, "deck04": 4, "deck05": 8, "deck06": 4, "deck07": 3, "deck08": 8, "deck09": 4, "deck10": 3, "deck11": 2}
	GameState.progress["wins"] = {"deck01": 6, "deck02": 3, "deck05": 5, "deck08": 2}

## Progresso de exemplo para as capturas da Coleção: metade das cartas, relíquias e inimigos vistos.
func _seed_collection_0161() -> void:
	var k := 0
	for d in CardDB.collectible_cards():
		if k % 3 != 2:
			Stats.mark_seen("cards", (d as CardData).id, false)
		k += 1
	k = 0
	for id in CardDB.relics:
		if k % 5 < 3 or String(id) in ["relic_ruby", "relic_sapphire"]:
			Stats.mark_seen("relics", String(id), false)
		k += 1
	var defeated := {}
	k = 0
	for e in CardDB.enemies:
		var id := String(e.get("id", ""))
		if k % 4 != 3 or id == "boss_hydra":
			Stats.mark_seen("enemies", id, false)
			defeated[id] = 1 + k % 6
		k += 1
	GameState.progress["defeated"] = defeated
	for id in ["act_1", "act_2", "shop_merchant"]:
		Stats.mark_seen("places", id, false)
	for id in ["meteor_rain", "tailwind", "blood_moon"]:
		Stats.mark_seen("climates", id, false)
	for ev in CardDB.events.slice(0, 14):
		Stats.mark_seen("events", String(ev.get("id", "")), false)
	for id in ["dawn", "tide", "x_glass", "deck_deck01", "deck_deck05"]:
		Stats.grant_unlock("back", id)
	Stats.grant_unlock("frame", "filigree")
	Stats.grant_unlock("mat", "mat_marble")
	Stats.grant_unlock("effect", "fx_sparks")
	Settings.card_back = "deck_deck01"

## Tira os avisos do ecrã (e os que estão à espera), para não taparem as capturas.
func _clear_toasts() -> void:
	SceneRouter._toast_queue.clear()
	for i in SceneRouter._toast_slots.size():
		var p = SceneRouter._toast_slots[i]
		if p != null and is_instance_valid(p):
			(p as Node).queue_free()
		SceneRouter._toast_slots[i] = null

func _finish() -> void:
	GameState.reset_progress()
	Stats.set_tutorial_done(true)
	GameState.clear_all_saved_runs()
	Settings.language = "auto"
	Settings.save_settings()
	get_tree().quit()

func _shoot_scene(path: String, name: String, settle: float) -> void:
	var s: Node = load(path).instantiate()
	add_child(s)
	await _wait(settle)
	await _shoot(name)
	s.queue_free()
	await get_tree().process_frame

func _wait(seconds: float) -> void:
	await get_tree().create_timer(seconds).timeout

func _shoot(name: String) -> void:
	await RenderingServer.frame_post_draw
	var img := get_viewport().get_texture().get_image()
	var path := out_dir.path_join(name + ".png")
	img.save_png(path)
	print("captura: ", path)

## 0.10.0: novidades, História, Desafios, Treino, Némesis, Reação, Reforço, avisos, encantamentos e
## Fichas, configurações (Visual), resumo do fim da run, carta mítica e escala de 120 %.
func _shots_0100() -> void:
	var menu: Node = load("res://scenes/main/Main.tscn").instantiate()
	add_child(menu)
	await _wait(0.4)
	NewsOverlay.open()
	await _wait(0.5)
	await _shoot("25_novidades")
	SceneRouter.close_overlays()
	var sm := SettingsMenu.open()
	await _wait(0.3)
	sm._show_tab(1)
	await _wait(0.3)
	await _shoot("26_configuracoes_visual")
	sm._show_tab(3)
	await _wait(0.3)
	await _shoot("26b_configuracoes_acessibilidade")
	sm.close()
	menu.queue_free()
	await get_tree().process_frame
	GameState.progress["saga"] = {"saga_white": true}
	await _shoot_scene("res://scenes/saga/Saga.tscn", "27_historia", 0.6)
	GameState.progress["challenges"] = {"ch_glass": true}
	await _shoot_scene("res://scenes/challenges/Challenges.tscn", "28_desafios", 0.5)
	GameState.training = {"hand": ["c315", "c316", "c331", "c339", "c318", "c345"], "relics": ["relic_drum", "relic_seal"], "mana": 8}
	await _shoot_scene("res://scenes/training/Training.tscn", "29_treino", 0.6)
	# Treino: o boneco, um ataque e o resultado.
	GameState.start_training()
	var tb: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(tb)
	await _wait(1.2)
	var tbm: BattleManager = tb.get_node("BattleManager")
	for id in ["c315", "c316", "c331", "c318"]:
		for c in tbm.deck.hand:
			if c.data.id == id and tbm.can_play(c):
				tb.call("_on_hand_card_pressed", c)
				break
		await _wait(0.3)
	await _shoot("30_treino_fichas_encantamento")
	(tb.get_node("%EndTurn") as Button).pressed.emit()
	var t0 := Time.get_ticks_msec()
	while not tbm.finished and Time.get_ticks_msec() - t0 < 15000:
		await get_tree().process_frame
	await _wait(1.4)
	await _shoot("31_treino_resultado")
	tb.queue_free()
	await get_tree().process_frame
	GameState.puzzle_id = ""
	# Reforço (escolha) e Reação (janela antes do contra-ataque).
	GameState.free_mode = false
	GameState.new_run("deck01", 77)
	GameState.relic_ids.clear()
	GameState.choose_battle("scout")
	var rb: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(rb)
	EventBus.battle_ended.disconnect(rb._on_battle_ended)
	await _wait(1.6)
	var rbm: BattleManager = rb.get_node("BattleManager")
	rbm.enemy["attack"] = 3
	rbm.mana_total = 6
	rbm.mana_available = 6
	for id in ["c339", "c347"]:
		var inst := CardDB.new_instance(id)
		inst.zone = CardInstance.Zone.HAND
		rbm.deck.hand.append(inst)
	EventBus.hand_changed.emit()
	await _wait(0.4)
	var fire: CardInstance = null
	for c in rbm.deck.hand:
		if c.data.id == "c339":
			fire = c
	rb.call("_on_hand_card_pressed", fire)
	await _wait(0.5)
	await _shoot("32_reforco")
	rb.call("_close_modal", "kick")
	await _wait(0.6)
	(rb.get_node("%EndTurn") as Button).pressed.emit()
	t0 = Time.get_ticks_msec()
	while not rb.call("_alive", rb._modal) and Time.get_ticks_msec() - t0 < 12000:
		await get_tree().process_frame
	await _wait(0.5)
	await _shoot("33_reacao")
	rb.queue_free()
	await get_tree().process_frame
	# Aviso "Atacar sem gastar a mana?".
	Settings.warn_mana = true
	GameState.new_run("deck05", 5)
	GameState.relic_ids.clear()
	var wb: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(wb)
	EventBus.battle_ended.disconnect(wb._on_battle_ended)
	await _wait(1.6)
	wb.call("_on_end_turn")
	await _wait(0.5)
	await _shoot("34_aviso_mana")
	wb.queue_free()
	await get_tree().process_frame
	Settings.warn_mana = false
	# Némesis no mapa e na batalha (com escudo).
	GameState.new_run("deck01", 4242)
	GameState.ante = 3
	GameState.map_phase = "battle"
	await _shoot_scene("res://scenes/map/Map.tscn", "35_mapa_nemesis", 0.6)
	GameState.ante = 5
	GameState.choose_battle("nemesis")
	var nb: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(nb)
	EventBus.battle_ended.disconnect(nb._on_battle_ended)
	await _wait(2.4)
	await _shoot("36_nemesis")
	nb.queue_free()
	await get_tree().process_frame
	# Carta mítica em grande (glossário sublinhado) e uma carta com termos do glossário.
	CardZoom.show_data(CardDB.get_card("c354"))
	await _wait(0.5)
	await _shoot("37_mitica_zoom")
	SceneRouter.close_overlays()
	CardZoom.show_data(CardDB.get_card("c316").plus_version())
	await _wait(0.5)
	await _shoot("37b_carta_mais_zoom")
	SceneRouter.close_overlays()
	# Resumo do fim da run.
	GameState.new_run("deck05", 9)
	GameState.ante = 6
	GameState.run_log = {"damage_by_ante": {"1": 4200, "2": 9100, "3": 21000, "4": 38000, "5": 77000, "6": 61000}, "card_dmg": {"c047": 98000, "c039": 41000}, "relic_dmg": {"relic_drum": 52000}, "best_hit": 54000}
	GameState.last_victory = false
	await _shoot_scene("res://scenes/ui/RunOver.tscn", "38_fim_resumo", 0.9)
	# Escala 120 % e modo compacto na batalha.
	Settings.ui_scale = 1.2
	Settings.compact = true
	Settings.apply()
	GameState.new_run("deck05", 12)
	GameState.relic_ids.clear()
	var sb: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(sb)
	EventBus.battle_ended.disconnect(sb._on_battle_ended)
	await _wait(1.8)
	await _shoot("39_escala120_compacto")
	sb.queue_free()
	await get_tree().process_frame
	Settings.ui_scale = 1.0
	Settings.compact = false
	Settings.apply()

## Batalha gravada contra um inimigo à escolha, com a mão e a Arena dadas (para as capturas).
func _battle_state(enemy_id: String, hand: Array, board: Array, mana: int = 6) -> Dictionary:
	var e: Dictionary = CardDB.enemy_def(enemy_id).duplicate(true)
	e["hp"] = 60000
	e["max_hp"] = 60000
	var st := {"enemy": e, "turn": 2, "max_turns": 5, "mana_total": mana, "mana_available": mana, "discards_left": 3,
		"player_hp": GameState.player_hp, "library": [], "hand": [], "graveyard": [], "board": [], "exile": []}
	for id in hand:
		st["hand"].append({"id": String(id), "entry": -1})
	for id in board:
		st["board"].append({"id": String(id), "entry": -1})
	return st

func _open_battle(state: Dictionary) -> Node:
	GameState.pending_battle = state
	var b: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(b)
	EventBus.battle_ended.disconnect(b._on_battle_ended)
	return b

## 0.11.0: tipos de carta (faixas, Terrenos à parte, palavras-chave), dica, Escola do Mago e lição,
## Talentos, bosses novos (Espelho e Nevoeiro), zoom de Terreno e palavras-chave e Rever o maior golpe.
func _shots_0110() -> void:
	GameState.free_mode = false
	GameState.new_run("deck05", 1110)
	GameState.relic_ids.clear()
	GameState.ante = 2
	var normal_id := ""
	for e in CardDB.enemies:
		if not bool(e.get("boss", false)) and not bool(e.get("saga", false)) and normal_id == "":
			normal_id = String(e.get("id", ""))
	# Mão com todos os tipos e Arena com as palavras-chave.
	Settings.tips_enabled = false
	var tb := _open_battle(_battle_state(normal_id, ["c339", "c345", "c331", "c040", "c050", "c008"], ["c043", "c020", "c031", "c046"]))
	await _wait(1.8)
	await _shoot("40_tipos_e_palavras_chave")
	# A dica da primeira vez.
	Settings.tips_enabled = true
	GameState.reset_tips()
	tb.call("_refresh_all")
	await _wait(0.6)
	await _shoot("41_dica")
	tb.queue_free()
	await get_tree().process_frame
	# Bosses novos: o Espelho Vivo (criatura copiada) e a Bruxa do Nevoeiro (texto escondido).
	GameState.progress["tips_seen"] = (CardDB.tips.keys() as Array).duplicate()
	GameState.ante = 4
	var mb := _open_battle(_battle_state("boss_mirror", ["c339", "c040", "c050"], ["c047", "c043", "c039"]))
	await _wait(1.4)
	var mbm: BattleManager = mb.get_node("BattleManager")
	var copied := mbm.mirror_best_creature()
	if copied != null:
		EventBus.creature_mirrored.emit(copied)
	await _wait(0.5)
	await _shoot("42_boss_espelho")
	mb.queue_free()
	await get_tree().process_frame
	var fb := _open_battle(_battle_state("boss_fog", ["c339", "c345", "c040", "c050", "c044"], ["c047"]))
	await _wait(1.6)
	await _shoot("43_boss_nevoeiro")
	fb.queue_free()
	await get_tree().process_frame
	# Zoom: Terreno e palavras-chave explicados.
	CardZoom.show_data(CardDB.get_card("c050"))
	await _wait(0.5)
	await _shoot("44_zoom_terreno")
	SceneRouter.close_overlays()
	CardZoom.show_data(CardDB.get_card("c046"))
	await _wait(0.5)
	await _shoot("44b_zoom_palavras_chave")
	SceneRouter.close_overlays()
	# Escola do Mago e uma lição (com a explicação e o resultado).
	GameState.progress["lessons"] = {"lesson_land": true, "lesson_formation": true}
	await _shoot_scene("res://scenes/school/School.tscn", "45_escola", 0.5)
	GameState.start_lesson("lesson_tokens")
	var lb: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(lb)
	await _wait(1.6)
	await _shoot("46_licao")
	var lbm: BattleManager = lb.get_node("BattleManager")
	for id in ["c315", "c316"]:
		for c in lbm.deck.hand:
			if c.data.id == id and lbm.can_play(c):
				lb.call("_on_hand_card_pressed", c)
				break
		await _wait(0.4)
	(lb.get_node("%EndTurn") as Button).pressed.emit()
	var t0 := Time.get_ticks_msec()
	while not lb.call("_alive", lb._modal) and Time.get_ticks_msec() - t0 < 15000:
		await get_tree().process_frame
	await _wait(0.6)
	await _shoot("47_licao_concluida")
	lb.queue_free()
	await get_tree().process_frame
	GameState.puzzle_id = ""
	# Talentos.
	GameState.progress["talent_points"] = 12
	GameState.progress["talents"] = {"t_gold": 2, "t_life": 1, "t_relic": 1}
	await _shoot_scene("res://scenes/talents/Talents.tscn", "48_talentos", 0.5)
	# Fim da run: Rever o maior golpe.
	GameState.free_mode = false
	GameState.new_run("deck01", 1111)
	GameState.relic_ids.clear()
	GameState.add_relic("relic_drum")
	GameState.ante = 5
	GameState.run_log = {}
	var gb := BattleManager.new()
	gb.restore(_battle_state(normal_id, [], ["c001", "c003", "c321", "c002"]))
	gb._apply_cascade(gb.preview_attack())
	gb.free()
	GameState.last_victory = false
	var ro: Node = load("res://scenes/ui/RunOver.tscn").instantiate()
	add_child(ro)
	await _wait(0.8)
	for n in ro.find_children("Replay", "Button", true, false):
		(n as Button).pressed.emit()
	await _wait(3.5)
	await _shoot("49_rever_maior_golpe")
	SceneRouter.close_overlays()
	ro.queue_free()
	await get_tree().process_frame
	Settings.tips_enabled = true

## 0.12.0: frase do ecrã inicial, NOVO JOGO (modos), escolha do espaço, JOGOS GUARDADOS e mudar o nome.
func _shots_0120() -> void:
	GameState.clear_all_saved_runs()
	MainMenu.return_page = "main"
	# Duas runs gravadas (espaços 1 e 3), uma com nome.
	GameState.current_slot = 1
	GameState.new_run("deck05", 808)
	GameState.ante = 3
	GameState.save_run({}, "map")
	GameState.current_slot = 3
	GameState.free_mode = true
	GameState.new_quick_run("deck02", 1, 909)
	GameState.ante = 2
	GameState.run_name = "Corrida do almoço"
	GameState.save_run({}, "map")
	GameState.free_mode = false
	var menu: Node = load("res://scenes/main/Main.tscn").instantiate()
	add_child(menu)
	await _wait(0.9)
	await _shoot("50_menu_inicio_slots")
	menu._show_page("new", false)
	await _wait(0.4)
	await _shoot("51_novo_jogo_modos")
	menu.get_node("%QuickRun").pressed.emit()
	await _wait(0.5)
	await _shoot("52_escolher_espaco")
	var picker := SceneRouter.top_overlay()
	if picker != null:
		var b3: Button = picker.find_child("Slot3", true, false)
		if b3 != null:
			b3.pressed.emit()
		await _wait(0.3)
		await _shoot("53_substituir_espaco")
		picker.queue_free()
	await get_tree().process_frame
	menu._show_page("saves", false)
	await _wait(0.4)
	await _shoot("54_jogos_guardados")
	menu.get_node("%Rename3").pressed.emit()
	await _wait(0.5)
	await _shoot("55_mudar_nome")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	menu.queue_free()
	await get_tree().process_frame
	GameState.clear_all_saved_runs()
	GameState.current_slot = 1
	# Batalha no Fácil: ▶▶, ORDENAR, MELHOR ORDEM e DICA; depois o grimório com probabilidades.
	GameState.free_mode = false
	GameState.new_run("deck01", 1201)
	GameState.difficulty = "facil"
	Settings.hand_sort = "cost"
	var lib: Array = []
	for id in ["c001", "c002", "c003", "c004", "c008", "c008", "c005", "c006", "c007", "c009"]:
		lib.append({"id": id, "entry": -1})
	var st := _battle_state("bandit", ["c005", "c002", "c008", "c004", "c009"], ["c003", "c001", "c006"], 5)
	st["library"] = lib
	var b := _open_battle(st)
	await _wait(1.6)
	b._on_hint()
	await _wait(0.3)
	await _shoot("56_batalha_dica_ordem")
	b._open_library()
	await _wait(0.5)
	await _shoot("57_grimorio_probabilidades")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	b._celebrate_record(123456, 98765)
	await _wait(0.5)
	await _shoot("58_novo_recorde")
	b.queue_free()
	await get_tree().process_frame
	GameState.difficulty = "normal"
	Settings.hand_sort = ""
	# Estatísticas: Histórico e Cartas (com dados de exemplo); Construtor com código colado.
	var saved_p: Dictionary = GameState.progress.duplicate(true)
	GameState.progress["history"] = []
	GameState.progress["card_stats"] = {}
	var decks := ["deck01", "deck05", "deck09", "deck12"]
	for i in 6:
		GameState.free_mode = i == 2
		GameState.new_run(String(decks[i % decks.size()]), 3000 + i)
		GameState.run_log = {"damage_by_ante": {"1": 1200 * (i + 1), "2": 5400 * (i + 1)}, "card_dmg": {}, "relic_dmg": {}, "card_plays": {}, "best_hit": 4200 * (i + 1)}
		var k := 0
		for e in GameState.deck:
			if k < 5:
				GameState.run_log["card_dmg"][String(e["id"])] = 900 * (5 - k) * (i + 1)
				GameState.run_log["card_plays"][String(e["id"])] = 3 + k
			k += 1
		GameState.run_name = "Corrida do almoço" if i == 1 else ""
		GameState.record_run_end(8 if i % 3 == 0 else 3 + i, i % 3 == 0)
	GameState.free_mode = false
	var stats: Node = load("res://scenes/ui/StatsScreen.tscn").instantiate()
	add_child(stats)
	await _wait(0.4)
	stats.select_tab("history")
	await _wait(0.3)
	await _shoot("59_estatisticas_historico")
	stats.select_tab("cards")
	await _wait(0.3)
	await _shoot("60_estatisticas_cartas")
	stats.select_tab("summary")
	await _wait(0.3)
	await _shoot("61_estatisticas_resumo")
	stats.queue_free()
	await get_tree().process_frame
	var db: Node = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	add_child(db)
	await _wait(0.4)
	db.apply_code(DeckCode.encode("Fúria Vermelha", ["c041", "c041", "c042", "c043", "c044", "c045", "c046", "c047", "c048", "c049", "c050", "c050"]))
	await _wait(0.3)
	await _shoot("62_construtor_codigo")
	db.queue_free()
	await get_tree().process_frame
	GameState.progress = saved_p
	Stats._ensure()
	# Entrada do boss, cometas do golpe final e dano recebido (vinheta e garras).
	GameState.free_mode = false
	GameState.new_run("deck05", 4040)
	GameState.ante = 4
	var bb := _open_battle(_battle_state("boss_zero", ["c005", "c002"], ["c003", "c001", "c006", "c007"]))
	await _wait(1.4)
	bb._boss_intro("")
	await _wait(1.0)
	await _shoot("63_entrada_do_boss")
	for c in bb.get_children():
		if c is BossIntro:
			c.queue_free()
	await _wait(0.3)
	bb._attack_trails()
	await _wait(0.16)
	await _shoot("64_cometas_do_golpe")
	await _wait(0.5)
	DamageVignette.flash(bb, 0.9)
	await _wait(0.1)
	await _shoot("65_dano_recebido")
	bb.queue_free()
	await get_tree().process_frame
	# Imagem de PARTILHAR (o que vai para o WhatsApp).
	GameState.new_run("deck12", 6060)
	GameState.ante = 8
	GameState.run_log = {"damage_by_ante": {"1": 2400, "2": 7100, "3": 15800, "4": 41000, "5": 88000, "6": 160000, "7": 290000, "8": 512000}, "card_dmg": {"c041": 98000}, "relic_dmg": {}, "card_plays": {}, "best_hit": 233000}
	GameState.run_name = "Corrida do almoço"
	var share_img: Image = await RunShare.render(self, RunShare.summary_from_state(true, false))
	if share_img != null:
		share_img.save_png(out_dir.path_join("68_partilhar.png"))
	# Ilustrações (só se houver imagens em assets/art).
	ArtLib.clear_cache()
	if ArtLib.total() > 0:
		GameState.ante = 1
		var ab := _open_battle(_battle_state("boss_gag", ["c001", "c002", "c003", "c004", "c008"], ["c005", "c007", "c010"]))
		await _wait(1.6)
		await _shoot("66_ilustracoes_batalha")
		CardZoom.show_card(CardDB.new_instance("c002"))
		await _wait(0.5)
		await _shoot("67_ilustracao_em_grande")
		SceneRouter.close_overlays()
		ab.queue_free()
		await get_tree().process_frame

## 0.12.1: mão com 2 toques (carta escolhida com JOGAR), carta a flutuar ao arrastar (na mão e por cima
## da Arena), chamas novas e a entrada do boss a 2× (com tempo para ler).
func _shots_0121() -> void:
	GameState.free_mode = false
	GameState.new_run("deck05", 1213)
	GameState.difficulty = "normal"
	Settings.hand_sort = ""
	Settings.play_taps = 2
	var b := _open_battle(_battle_state("bandit", ["c041", "c043", "c044", "c045", "c050"], ["c047", "c046"], 6))
	await _wait(1.6)
	var views: Array = b._hand_views.values()
	if views.size() >= 3:
		var sel: CardView = views[1]
		sel.pressed.emit(sel.card)
		await _wait(0.5)
		await _shoot("69_mao_escolhida")
		b._set_selection(-1)
		await _wait(0.3)
		var drag: CardView = views[0]
		var start: Vector2 = drag.get_global_rect().get_center()
		b._on_hand_drag_started(drag.card, start)
		var hb: Rect2 = b.hand_box.get_global_rect()
		for k in 6:
			b._on_hand_drag_moved(drag.card, start.lerp(Vector2(hb.end.x - 120.0, start.y), (k + 1) / 6.0))
			await _wait(0.05)
		await _wait(0.3)
		await _shoot("70_mao_arrastar")
		b._on_hand_drag_moved(drag.card, Vector2(hb.get_center().x, hb.position.y - 170.0))
		await _wait(0.3)
		await _shoot("71_arrastar_para_jogar")
		b._on_hand_drag_ended(drag.card, Vector2(hb.end.x - 120.0, start.y))
		await _wait(0.4)
	b._fire_target = 0.95
	b._fire_level = 0.95
	await _wait(0.8)
	await _shoot("72_chamas")
	b.queue_free()
	await get_tree().process_frame
	# Entrada do boss a 2×: o texto fica no ecrã o tempo de o ler.
	Settings.anim_speed = "fast"
	GameState.new_run("deck05", 4141)
	GameState.ante = 4
	var bb := _open_battle(_battle_state("boss_zero", ["c005", "c002"], ["c003", "c001"]))
	await _wait(0.6)
	bb._boss_intro("")
	await _wait(2.2)
	await _shoot("73_boss_a_2x")
	bb.queue_free()
	await get_tree().process_frame
	Settings.anim_speed = "normal"

## 0.12.1: jogar uma carta da mão pela UI — dois toques (escolher e jogar), ou um com a opção "1 toque".
func _tap_play(v: CardView) -> void:
	v.pressed.emit(v.card)
	if is_instance_valid(v) and Settings.play_taps == 2:
		v.pressed.emit(v.card)

## 0.13.0: números de ordem e setas do inimigo, escolher quem bloqueia, palavra-chave explicada, total ao
## vivo ao arrastar, sem jogadas, dica no topo, golpe carregado, morte em pó, rever o ataque e vitória.
func _shots_0130() -> void:
	GameState.free_mode = false
	GameState.new_run("deck05", 1301)
	GameState.difficulty = "normal"
	Settings.hand_sort = ""
	Settings.play_taps = 2
	Settings.show_threats = true
	var st := _battle_state("jailer", ["c041", "c043", "c044", "c045", "c050"], ["c047", "c039", "c046", "c015"], 6)
	st["enemy"]["attack"] = 3
	var b := _open_battle(st)
	await _wait(1.6)
	b._refresh_preview()
	await _wait(0.4)
	await _shoot("74_ordem_e_setas")
	b._open_intent()
	await _wait(0.5)
	await _shoot("75_escolher_bloqueio")
	b._close_modal(null)
	await _wait(0.3)
	var bm: BattleManager = b.get_node("BattleManager")
	var flyer: CardInstance = null
	for c in bm.board:
		if c.has_keyword("flying"):
			flyer = c
	if flyer != null:
		var fv: CardView = b._board_views.get(flyer.uid)
		if fv != null and fv._kw_box != null and fv._kw_box.get_child_count() > 0:
			var ic: Control = fv._kw_box.get_child(0)
			b._on_keyword_tapped(flyer, "flying", ic.get_global_rect())
			await _wait(0.4)
			await _shoot("76_palavra_chave")
	var views: Array = b._hand_views.values()
	if views.size() >= 2:
		var drag: CardView = views[1]
		var start: Vector2 = drag.get_global_rect().get_center()
		b._on_hand_drag_started(drag.card, start)
		var hb: Rect2 = b.hand_box.get_global_rect()
		b._on_hand_drag_moved(drag.card, Vector2(hb.get_center().x + 60.0, hb.position.y - 150.0))
		await _wait(0.4)
		await _shoot("77_total_ao_vivo")
		b._on_hand_drag_ended(drag.card, Vector2(hb.end.x - 80.0, start.y))
		await _wait(0.4)
	b.queue_free()
	await get_tree().process_frame
	# Sem jogadas (ATACAR a brilhar) e uma dica no topo.
	GameState.new_run("deck05", 1302)
	var st2 := _battle_state("bandit", ["c045", "c050"], ["c047", "c046"], 0)
	st2["land_played_this_turn"] = true
	st2["actions_this_turn"] = 1
	var b2 := _open_battle(st2)
	await _wait(1.6)
	b2._no_plays_turn = 0
	b2._refresh_preview()
	await _wait(0.5)
	await _shoot("78_sem_jogadas")
	GameState.reset_tips()
	b2._tip_queue.clear()
	b2._tip("block")
	await _wait(0.6)
	await _shoot("79_dica_no_topo")
	b2.queue_free()
	await get_tree().process_frame
	# Golpe carregado: o Berserker da Pedreira ataca com ×2 neste turno.
	GameState.new_run("deck05", 1303)
	var st3 := _battle_state("berserker", ["c041", "c045"], ["c047", "c044"], 6)
	st3["charge_mult"] = 2.0
	var b3 := _open_battle(st3)
	await _wait(1.8)
	await _shoot("80_golpe_carregado")
	# Morte em pó (a meio da animação) e rever o último ataque.
	var bm3: BattleManager = b3.get_node("BattleManager")
	var victim: CardView = b3._board_views.values()[0]
	b3._animate_death(victim)
	victim.modulate.a = 0.0
	await _wait(0.25)
	await _shoot("81_morte_em_po")
	b3._last_cascade = bm3.preview_attack()
	b3._last_attack_turn = 2
	b3._replay_last_attack()
	await _wait(1.6)
	await _shoot("82_rever_ataque")
	SceneRouter.close_overlays()
	await _wait(0.2)
	# Vitória: o retrato racha e há confetes.
	b3._portrait.defeat()
	CelebrationFx.play(b3, b3.get_viewport_rect(), "confetti")
	b3._show_banner(tr("ANTE %d VENCIDO") % 2, 1.0)
	await _wait(0.7)
	await _shoot("83_vitoria")
	b3.queue_free()
	await get_tree().process_frame
	# Edições: cartas Brilhante, Holográfica e Policromática na mão e na Arena, a carta em grande e a loja.
	GameState.new_run("deck19", 1304)
	var eds := [["c394", "shiny"], ["c399", "holo"], ["c405", "poly"], ["c402", "poly"], ["c408", "shiny"]]
	var st4 := _battle_state("golem", [], [], 6)
	for i in eds.size():
		GameState.add_card(String(eds[i][0]), false, String(eds[i][1]))
		var item := {"id": String(eds[i][0]), "entry": GameState.deck.size() - 1}
		if i < 3:
			st4["board"].append(item)
		else:
			st4["hand"].append(item)
	st4["hand"].append({"id": "c393", "entry": -1})
	var b4 := _open_battle(st4)
	await _wait(1.6)
	await _shoot("84_edicoes_batalha")
	var poly_card: CardInstance = null
	for c in (b4.get_node("BattleManager") as BattleManager).board:
		if c.edition() == "poly":
			poly_card = c
	if poly_card != null:
		CardZoom.show_card(poly_card)
		await _wait(0.6)
		await _shoot("85_edicao_zoom")
		SceneRouter.close_overlays()
		await _wait(0.2)
	b4.queue_free()
	await get_tree().process_frame
	GameState.new_run("deck19", 1305)
	GameState.add_gold(40)
	GameState.map_options(1)
	GameState.choose_stop("shop")
	var shop: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	add_child(shop)
	await _wait(0.5)
	var eds_offer: Array = shop.get("_offer_editions")
	if eds_offer.size() >= 2:
		eds_offer[0] = "holo"
		eds_offer[1] = "poly"
		shop.call("_build_offers")
	await _wait(0.5)
	await _shoot("86_edicoes_loja")
	shop.queue_free()
	await get_tree().process_frame

## 0.13.0 (2.ª parte): poções e afixos, a Hidra, o mapa vivo com paragens novas, a História e os Desafios,
## o Perfil, a Coleção por cor, o Construtor (Selo e curva), a Run Rápida, a mão grande/uma mão, a carta
## em 3D e o baralho com a curva de mana.
func _shots_0130b() -> void:
	GameState.progress["tips_seen"] = (CardDB.tips.keys() as Array).duplicate()
	Settings.show_threats = true
	# Elite com afixos e a barra das poções.
	GameState.free_mode = false
	GameState.new_run("deck05", 1310)
	GameState.ante = 3
	GameState.consumables.clear()
	GameState.add_consumable("potion_heal")
	GameState.add_consumable("scroll_fire")
	var st := _battle_state("bandit", ["c041", "c045", "c050", "c044"], ["c047", "c039"], 6)
	st["enemy"]["affixes"] = ["armored", "vampiric"]
	st["enemy"]["elite"] = true
	var b := _open_battle(st)
	await _wait(1.6)
	await _shoot("87_elite_afixos_pocoes")
	b.queue_free()
	await get_tree().process_frame
	# A Hidra Tricéfala: marcas das fases na barra de vida.
	GameState.ante = 4
	var b2 := _open_battle(_battle_state("boss_hydra3", ["c041", "c045", "c050"], ["c047", "c039", "c046"], 6))
	await _wait(1.8)
	await _shoot("88_boss_hidra_fases")
	b2.queue_free()
	await get_tree().process_frame
	# Mapa vivo: ato II, a seguir à Elite — Loja ou Forja; o Cofre no ante 4; uma poção para usar.
	GameState.new_run("deck05", 1311)
	GameState.ante = 3
	GameState.map_plan = {"3": {"battle": ["scout", "guard", "elite"], "stop": ["shop", "forge"]}, "4": {"battle": ["boss"], "stop": ["shop", "vault"]}}
	GameState.map_choice = {"battle": "elite"}
	GameState.map_phase = "stop"
	GameState.consumables.clear()
	GameState.add_consumable("potion_heal")
	var mp: Node = load("res://scenes/map/Map.tscn").instantiate()
	add_child(mp)
	await _wait(1.2)
	await _shoot("89_mapa_vivo")
	mp.queue_free()
	await get_tree().process_frame
	# O mapa no início de um ato (fase de batalha) e no Infinito.
	GameState.new_run("deck05", 1313)
	GameState.ante = 1
	GameState.map_phase = "battle"
	GameState.progress["interludes_seen"] = ["1", "2", "3", "4", "5"]
	GameState.interlude_key = "1"
	var mp_a: Node = load("res://scenes/map/Map.tscn").instantiate()
	add_child(mp_a)
	await _wait(1.0)
	SceneRouter.close_overlays()
	await _wait(0.3)
	await _shoot("89b_mapa_ato1")
	mp_a.queue_free()
	await get_tree().process_frame
	mp = load("res://scenes/map/Map.tscn").instantiate()
	GameState.new_run("deck05", 1311)
	GameState.ante = 3
	GameState.map_plan = {"3": {"battle": ["scout", "guard", "elite"], "stop": ["shop", "forge"]}, "4": {"battle": ["boss"], "stop": ["shop", "vault"]}}
	GameState.map_choice = {"battle": "elite"}
	GameState.map_phase = "stop"
	GameState.consumables.clear()
	GameState.add_consumable("potion_heal")
	add_child(mp)
	await _wait(0.6)
	mp.call("_on_item", 0)
	await _wait(0.5)
	await _shoot("90_dialogo_pocao")
	SceneRouter.close_overlays()
	await _wait(0.2)
	(mp.find_child("DeckBtn", true, false) as Button).pressed.emit()
	await _wait(0.6)
	await _shoot("91_baralho_curva")
	SceneRouter.close_overlays()
	mp.queue_free()
	await get_tree().process_frame
	# História (Livro III) e Desafios com estrelas.
	GameState.progress["saga"] = {}
	for ch in CardDB.saga:
		if int((ch as Dictionary).get("book", 1)) < 3:
			GameState.progress["saga"][String(ch["id"])] = true
	GameState.progress["challenge_stars"] = {}
	var k := 0
	for c in CardDB.challenges:
		GameState.progress["challenge_stars"][String(c["id"])] = [3, 2, 1, 0][k % 4]
		k += 1
	var saga: Node = load("res://scenes/saga/Saga.tscn").instantiate()
	add_child(saga)
	await _wait(0.4)
	saga.call("_show_book", 3)
	await _wait(0.4)
	await _shoot("92_historia_livro3")
	saga.queue_free()
	await get_tree().process_frame
	await _shoot_scene("res://scenes/challenges/Challenges.tscn", "93_desafios_estrelas", 0.5)
	# Perfil (Estatísticas) e a Coleção por cor.
	GameState.progress["card_stats"] = {"c045": {"plays": 64, "dmg": 18000, "runs": 9, "wins": 3}, "c041": {"plays": 130, "dmg": 9000, "runs": 12, "wins": 5}, "c039": {"plays": 18, "dmg": 26000, "runs": 4, "wins": 1}}
	GameState.progress["deck_xp"] = {"deck05": 26, "deck01": 9}
	for id in Stats.color_set_ids("white"):
		Stats.mark_seen("cards", id, false)
	for id in Stats.color_set_ids("red").slice(0, 40):
		Stats.mark_seen("cards", id, false)
	Stats.set_at_least("wins", 4)
	Stats.set_at_least("best_attack", 1250000)
	await _shoot_scene("res://scenes/ui/StatsScreen.tscn", "94_perfil", 0.6)
	await _shoot_scene("res://scenes/ui/Collection.tscn", "95_colecao_por_cor", 0.8)
	# Construtor: Selo Planar e curva de mana.
	CardDB.custom_decks["custom_1"] = {"id": "custom_1", "num": 0, "name": "Muralha", "custom": true, "cards": ["c039", "c039", "c041", "c043", "c044", "c045", "c045", "c046", "c047", "c050", "c050", "c040"], "colors": ["white"], "size": 12, "difficulty": 0, "mechanic": "x"}
	GameState.progress["custom_stakes"] = {"custom_1": 2}
	var db: Node = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	add_child(db)
	await _wait(0.5)
	(db.find_child("Stake", true, false) as Button).pressed.emit()
	await _wait(0.3)
	await _shoot("96_construtor_selo_curva")
	db.queue_free()
	CardDB.custom_decks.erase("custom_1")
	await get_tree().process_frame
	# Run Rápida: a escada de Selos própria.
	GameState.progress["quick_stakes"] = {"deck05": 2}
	GameState.launch_mode = "quick"
	var camp: Node = load("res://scenes/campaign/Campaign.tscn").instantiate()
	add_child(camp)
	await _wait(0.5)
	camp.call("_select_chapter", "deck05")
	await _wait(0.4)
	await _shoot("97_run_rapida_selos")
	camp.queue_free()
	GameState.free_mode = false
	await get_tree().process_frame
	# Mão a 130 % e modo de uma mão.
	Settings.hand_scale = 1.3
	Settings.one_hand = true
	GameState.new_run("deck05", 1312)
	var b3 := _open_battle(_battle_state("bandit", ["c041", "c045", "c050", "c044", "c043"], ["c047", "c039"], 6))
	await _wait(1.6)
	await _shoot("98_mao_grande_uma_mao")
	b3.queue_free()
	Settings.hand_scale = 1.0
	Settings.one_hand = false
	await get_tree().process_frame
	# Carta em grande em 3D (inclinada).
	Settings.tilt_3d = true
	CardZoom.show_data(CardDB.get_card("c045"))
	await _wait(0.5)
	var z := SceneRouter.top_overlay() as CardZoom
	if z != null:
		z.set_tilt(Vector2(0.75, -0.45))
	await _wait(0.2)
	await _shoot("99_carta_3d")
	SceneRouter.close_overlays()
	await _wait(0.2)
