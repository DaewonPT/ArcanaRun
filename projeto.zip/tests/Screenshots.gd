extends Node
## Tira capturas de ecrã das cenas (precisa de ecrã, p.ex. xvfb):
##   xvfb-run -s "-screen 0 1280x720x24" godot --rendering-method gl_compatibility --path . res://tests/Screenshots.tscn -- --out=/tmp/shots

var out_dir := "/tmp/shots"

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--out="):
			out_dir = arg.substr(6)
	DirAccess.make_dir_recursive_absolute(out_dir)
	await get_tree().process_frame
	GameState.progress = {"best_ante": {"deck01": 4, "deck02": 6}, "wins": {}, "difficulty": "normal"}
	Stats._ensure()
	Stats.set_tutorial_done(true)
	GameState.free_mode = false
	Settings.language = "pt"
	Settings.anim_speed = "normal"
	Settings.left_handed = false
	Settings.large_text = false
	Settings.apply()

	await _shoot_scene("res://scenes/main/Main.tscn", "01_menu", 0.9)
	# Configurações por cima do menu, e o menu em inglês.
	var menu: Node = load("res://scenes/main/Main.tscn").instantiate()
	add_child(menu)
	await _wait(0.3)
	var sm := SettingsMenu.open()
	await _wait(0.5)
	await _shoot("01b_configuracoes")
	Settings.language = "en"
	Settings.apply()
	await _wait(0.3)
	await _shoot("01c_configuracoes_en")
	sm.close()
	await _wait(0.3)
	await _shoot("01d_menu_en")
	Settings.language = "pt"
	Settings.apply()
	menu.queue_free()
	await get_tree().process_frame
	await _shoot_scene("res://scenes/campaign/Campaign.tscn", "02_campanha", 0.5)
	await _shoot_scene("res://scenes/ui/HowToPlay.tscn", "03_como_jogar", 0.3)
	# Estatísticas (com algumas conquistas), coleção e construtor.
	GameState.new_run("deck05", 2)
	EventBus.damage_dealt.emit("enemy", 120000)
	await _shoot_scene("res://scenes/ui/StatsScreen.tscn", "03b_estatisticas", 0.4)
	await _shoot_scene("res://scenes/ui/Collection.tscn", "03c_colecao", 0.6)
	var builder: Node = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	add_child(builder)
	await _wait(0.4)
	for id in ["c001", "c001", "c002", "c003", "c009", "c018", "c019", "c021", "c028", "c039", "c040", "c050"]:
		builder.call("_add_card", id)
	await _wait(0.3)
	await _shoot("03d_construtor")
	builder.queue_free()
	await get_tree().process_frame
	# Tutorial na primeira batalha.
	Stats.set_tutorial_done(false)
	GameState.new_run("deck01", 9)
	var tut_battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(tut_battle)
	EventBus.battle_ended.disconnect(tut_battle._on_battle_ended)
	await _wait(1.6)
	await _shoot("03e_tutorial")
	tut_battle.queue_free()
	await get_tree().process_frame
	Stats.set_tutorial_done(true)
	# Cartas em inglês + canhoto.
	Settings.language = "en"
	Settings.left_handed = true
	Settings.apply()
	GameState.new_run("deck16", 4)
	var en_battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(en_battle)
	EventBus.battle_ended.disconnect(en_battle._on_battle_ended)
	await _wait(1.6)
	await _shoot("03f_batalha_en_canhoto")
	en_battle.queue_free()
	await get_tree().process_frame
	Settings.language = "pt"
	Settings.left_handed = false
	Settings.apply()

	# Batalha: turno 1 (com Mulligan disponível, planeswalker, selos e uma carta de dupla face),
	# depois com cartas jogadas, depois a meio da cascata.
	GameState.new_run("deck05", 7)
	GameState.add_relic("relic_seal")
	GameState.add_relic("relic_banner")
	GameState.set_planeswalker("pw_white")
	GameState.planeswalker["loyalty"] = 4
	GameState.deck[0]["seal"] = "tithe"
	GameState.deck[1]["seal"] = "fury"
	GameState.add_card("c304")
	GameState.choose_battle("guard")
	var battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(battle)
	EventBus.battle_ended.disconnect(battle._on_battle_ended)
	var bm: BattleManager = battle.get_node("BattleManager")
	bm.enemy.hp = 400000
	bm.enemy.max_hp = 400000
	EventBus.enemy_hp_changed.emit(bm.enemy.hp, bm.enemy.max_hp)
	await _wait(2.0)
	await _shoot("04_batalha_turno1")
	var hand_box: HBoxContainer = battle.get_node("%Hand")
	# Carta em grande (toque longo), grimório e pausa.
	for view in hand_box.get_children():
		if view is CardView:
			view.long_pressed.emit(view.card)
			break
	await _wait(0.5)
	await _shoot("04b_carta_grande")
	SceneRouter.close_overlays()
	await _wait(0.2)
	(battle.get_node("%LibraryBtn") as Button).pressed.emit()
	await _wait(0.5)
	await _shoot("04c_grimorio")
	SceneRouter.close_overlays()
	await _wait(0.2)
	(battle.get_node("%PauseBtn") as Button).pressed.emit()
	await _wait(0.5)
	await _shoot("04d_pausa")
	SceneRouter.close_overlays()
	await _wait(0.3)
	for i in 3:
		for view in hand_box.get_children():
			if view is CardView and bm.can_play(view.card):
				view.pressed.emit(view.card)
				break
		await _wait(0.45)
	(battle.get_node("%DiscardBtn") as Button).button_pressed = true
	await _wait(0.3)
	await _shoot("05_batalha_canalizar")
	(battle.get_node("%DiscardBtn") as Button).button_pressed = false
	await _wait(0.2)
	# Avança dois turnos para ter tabuleiro cheio, depois dispara a cascata e captura a meio.
	for t in 2:
		(battle.get_node("%EndTurn") as Button).pressed.emit()
		var t0 := Time.get_ticks_msec()
		var turn_before := bm.turn
		while bm.turn == turn_before and Time.get_ticks_msec() - t0 < 15000 and not bm.finished:
			await get_tree().process_frame
		await _wait(0.9)
		for i in 4:
			for view in hand_box.get_children():
				if view is CardView and bm.can_play(view.card):
					view.pressed.emit(view.card)
					break
			await _wait(0.35)
	await _shoot("06_batalha_tabuleiro")
	(battle.get_node("%EndTurn") as Button).pressed.emit()
	await _wait(1.2)
	await _shoot("07_batalha_cascata")
	await _wait(2.2)
	await _shoot("08_batalha_impacto")
	await _wait(1.5)
	await _shoot("08b_batalha_turno_seguinte")
	battle.queue_free()
	await get_tree().process_frame

	# Boss (ante 4) e evento.
	GameState.ante = 4
	GameState.damage_player(6)
	var boss_battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(boss_battle)
	EventBus.battle_ended.disconnect(boss_battle._on_battle_ended)
	await _wait(2.2)
	await _shoot("08c_boss")
	boss_battle.queue_free()
	await get_tree().process_frame
	GameState.ante = 2
	GameState.pending_event = "altar"
	await _shoot_scene("res://scenes/event/Event.tscn", "08d_evento", 0.6)
	GameState.pending_event = ""
	GameState.add_gold(30)
	GameState.add_relic("relic_crown")
	GameState.choose_stop("shop")
	await _shoot_scene("res://scenes/shop/Shop.tscn", "09_loja", 0.4)
	GameState.last_victory = false
	await _shoot_scene("res://scenes/ui/RunOver.tscn", "10_fim", 0.8)
	# 0.8.0: mapa (fase de paragem do ante 1), Mercador Cego, acampamento, draft, enigmas, cemitério com recapitular.
	GameState.new_run("deck03", 21)
	GameState.add_gold(30)
	GameState.map_options(1)
	GameState.choose_battle("guard")
	GameState.map_phase = "stop"
	await _shoot_scene("res://scenes/map/Map.tscn", "11_mapa", 0.5)
	GameState.ante = 4
	GameState.map_options(4)
	GameState.choose_stop("merchant")
	await _shoot_scene("res://scenes/shop/Shop.tscn", "12_mercador_cego", 0.5)
	GameState.ante = 1
	GameState.pending_event = "node_altar"
	await _shoot_scene("res://scenes/event/Event.tscn", "13_altar", 0.5)
	GameState.pending_event = ""
	var draft: Node = load("res://scenes/draft/Draft.tscn").instantiate()
	add_child(draft)
	await _wait(0.5)
	await _shoot("14_draft")
	draft.queue_free()
	await get_tree().process_frame
	await _shoot_scene("res://scenes/puzzles/Puzzles.tscn", "15_enigmas", 0.5)
	GameState.new_run("deck03", 22)
	var fb_battle: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(fb_battle)
	EventBus.battle_ended.disconnect(fb_battle._on_battle_ended)
	var fbm: BattleManager = fb_battle.get_node("BattleManager")
	await _wait(1.2)
	var ritual := CardDB.new_instance("c018")
	ritual.exiled = true
	fbm.deck.to_graveyard(ritual)
	var exiled := CardDB.new_instance("c021")
	fbm.deck.to_exile(exiled)
	fb_battle.call("_refresh_all")
	(fb_battle.get_node("%GraveyardBtn") as Button).pressed.emit()
	await _wait(0.5)
	await _shoot("16_cemiterio_recapitular")
	SceneRouter.close_overlays()
	fb_battle.queue_free()
	await get_tree().process_frame
	# 0.9.0: mapa com clima, contrato, Elite e Tribunal; interlúdio; Baú de Espólio; Tribunal com a roda;
	# boss com fala e marca de metade; fogo nas pílulas; detalhe da cascata; despertar; modo daltónico.
	GameState.new_run("deck05", 127)
	GameState.add_gold(18)
	GameState.map_options(1)
	GameState.map_options(2)
	GameState.choose_battle("scout")
	GameState.map_phase = "stop"
	GameState.set_contract("swift")
	GameState.interlude_key = "1"
	await _shoot_scene("res://scenes/map/Map.tscn", "17_mapa_clima_contrato", 0.7)
	GameState.ante = 3
	GameState.map_phase = "battle"
	GameState.interlude_key = "1"
	var imap: Node = load("res://scenes/map/Map.tscn").instantiate()
	add_child(imap)
	await _wait(1.2)
	await _shoot("17b_interludio_ato")
	SceneRouter.close_overlays()
	imap.queue_free()
	await get_tree().process_frame
	GameState.ante = 4
	GameState.map_phase = "stop"
	GameState.prepare_loot()
	await _shoot_scene("res://scenes/loot/Loot.tscn", "18_bau_espolio", 0.9)
	GameState.ante = 2
	GameState.pending_event = "node_tribunal"
	var trib = load("res://scenes/event/Event.tscn").instantiate()
	add_child(trib)
	await _wait(0.6)
	await _shoot("19_tribunal")
	var gamble_lines: Array[String] = []
	trib._gamble({"gamble": "gold", "cost": 8}, gamble_lines)
	await _wait(1.7)
	await _shoot("19b_tribunal_roda")
	await _wait(3.5)
	trib.queue_free()
	SceneRouter.close_overlays()
	await get_tree().process_frame
	# Boss: fala de entrada, marca de metade, intenção em ícones, chips de clima e contrato.
	GameState.new_run("deck05", 128)
	GameState.ante = 4
	GameState.climates["2"] = "blood_moon"
	GameState.add_relic("relic_seal")
	GameState.add_relic("relic_hungry_grimoire")
	GameState.relic_counters["relic_hungry_grimoire"] = 3
	GameState.add_boss_relic("relic_abyss_chalice")
	GameState.set_contract("army")
	GameState.choose_battle("boss")
	var bb = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(bb)
	EventBus.battle_ended.disconnect(bb._on_battle_ended)
	var bbm: BattleManager = bb.get_node("BattleManager")
	await _wait(2.6)
	await _shoot("20_boss_fala")
	var bhand: HBoxContainer = bb.get_node("%Hand")
	for i in 4:
		for view in bhand.get_children():
			if view is CardView and bbm.can_play(view.card):
				view.pressed.emit(view.card)
				break
		await _wait(0.4)
	var total := bbm.preview_attack().total()
	bbm.enemy.hp = int(total * 1.08)
	EventBus.enemy_hp_changed.emit(bbm.enemy.hp, bbm.enemy.max_hp)
	bb._refresh_preview()
	await _wait(1.4)
	await _shoot("21_fogo_pilulas")
	bb._open_breakdown()
	await _wait(0.6)
	await _shoot("22_detalhe_cascata")
	SceneRouter.close_overlays()
	await _wait(0.3)
	bbm.enemy.max_hp = total * 10
	bbm.enemy.hp = int(total * 5.5)
	EventBus.enemy_hp_changed.emit(bbm.enemy.hp, bbm.enemy.max_hp)
	bb._refresh_preview()
	(bb.get_node("%EndTurn") as Button).pressed.emit()
	var t_start := Time.get_ticks_msec()
	while not bbm.phase2 and Time.get_ticks_msec() - t_start < 20000:
		await get_tree().process_frame
	await _wait(0.45)
	await _shoot("23_boss_desperta")
	await _wait(2.5)
	bb.queue_free()
	await get_tree().process_frame
	# Modo daltónico (símbolos nos pips de cor).
	Settings.colorblind = true
	Settings.apply()
	GameState.new_run("deck13", 31)
	var cbb = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(cbb)
	EventBus.battle_ended.disconnect(cbb._on_battle_ended)
	await _wait(2.0)
	await _shoot("24_modo_daltonico")
	cbb.queue_free()
	await get_tree().process_frame
	Settings.colorblind = false
	Settings.apply()
	GameState.reset_progress()
	Stats.set_tutorial_done(true)
	GameState.clear_saved_run()
	Settings.language = "auto"
	Settings.save_settings()
	get_tree().quit()

func _shoot_scene(path: String, name: String, settle: float) -> void:
	var s: Node = load(path).instantiate()
	add_child(s)
	await _wait(settle)
	await _shoot(name)
	s.queue_free()
	await get_tree().process_frame

func _wait(seconds: float) -> void:
	await get_tree().create_timer(seconds).timeout

func _shoot(name: String) -> void:
	await RenderingServer.frame_post_draw
	var img := get_viewport().get_texture().get_image()
	var path := out_dir.path_join(name + ".png")
	img.save_png(path)
	print("captura: ", path)
