extends Node
## Teste de fumo headless:  godot --headless --path . res://tests/SmokeTest.tscn
## 1) Batalhas só com lógica (sem UI) com os 18 baralhos, com relíquias e inimigo com todas as habilidades.
## 2) Uma batalha a correr na cena real Battle.tscn (cascata animada com timers), com Canalizar.
## 3) Carregar as outras cenas (Main, Shop, RunOver) sem erros.
## Sai com código 0 se tudo passou, 1 se algo falhou.

var failures: Array[String] = []

func _ready() -> void:
	await get_tree().process_frame
	_test_logic_battles()
	await _test_ui_battle()
	await _test_other_scenes()
	if failures.is_empty():
		print("SMOKE TEST: OK")
		get_tree().quit(0)
	else:
		for f in failures:
			printerr("SMOKE TEST FAIL: " + f)
		get_tree().quit(1)

func _check(cond: bool, msg: String) -> void:
	if not cond:
		failures.append(msg)

# ---------------------------------------------------------------------------

func _test_logic_battles() -> void:
	_check(CardDB.cards.size() == 300, "esperava 300 cartas, há %d" % CardDB.cards.size())
	_check(CardDB.decks.size() == 18, "esperava 18 baralhos")
	var total_wins := 0
	for deck in CardDB.decks:
		GameState.new_run(String(deck.id), 12345)
		_check(GameState.deck.size() == int(deck.size), "baralho %s tem %d cartas" % [deck.name, GameState.deck.size()])
		for relic_id in ["relic_drum", "relic_ruby", "relic_seed", "relic_seal", "relic_sapphire", "relic_jet", "relic_gear", "relic_banner", "relic_grimoire", "relic_lotus", "relic_lens", "relic_mirror", "relic_hourglass", "relic_tectonic"]:
			GameState.add_relic(relic_id)
		var wins := 0
		var max_total := 0
		for ante in range(1, 5):
			GameState.ante = ante
			var bm := BattleManager.new()
			var hp := GameState.enemy_hp_for_ante(ante)
			bm.start({"name": "Teste", "hp": hp, "max_hp": hp, "attack": 2, "text": "", "abilities": [
				{"trigger": "turn_end", "action": "steal_gold", "value": 1},
				{"trigger": "every_n_turns", "n": 3, "action": "destroy_strongest"},
				{"trigger": "turn_end", "action": "damage_all_creatures", "value": 1},
				{"trigger": "turn_end", "action": "discard_random", "value": 1},
				{"trigger": "turn_end", "action": "heal_self", "value": 1},
			]})
			var result := [null]
			var cb := func(v: bool): result[0] = v
			EventBus.battle_ended.connect(cb)
			var guard := 0
			while result[0] == null and guard < 50:
				guard += 1
				_play_everything(bm)
				var preview := bm.preview_attack()
				_check(preview.total() == int(round(preview.power * preview.mult * preview.damage_mult)), "total da cascata inconsistente")
				max_total = max(max_total, preview.total())
				# Canalizar uma carta por turno, para exercitar on_discard
				if not bm.deck.hand.is_empty() and bm.can_discard(bm.deck.hand[0]):
					bm.discard(bm.deck.hand[0])
				bm.end_turn()
			EventBus.battle_ended.disconnect(cb)
			_check(result[0] != null, "batalha %s ante %d não terminou" % [deck.name, ante])
			_check(bm.turn <= bm.max_turns + bm.extra_turns, "turnos a mais em %s" % deck.name)
			if result[0] == true:
				wins += 1
		print("  %-22s %d/4 vitórias, melhor ataque %d" % [deck.name, wins, max_total])
		_check(max_total > 0, "baralho %s nunca atacou" % deck.name)
		total_wins += wins
	_check(total_wins >= 18, "demasiado poucas vitórias com relíquias fortes: %d" % total_wins)

func _play_everything(bm: BattleManager) -> void:
	var played := true
	var guard := 0
	while played and guard < 40:
		guard += 1
		played = false
		for card in bm.deck.hand.duplicate():
			if bm.can_play(card):
				_check(bm.play(card), "play() falhou numa carta jogável")
				played = true
				break
	_check(bm.creatures().size() <= BattleManager.MAX_CREATURES, "mais criaturas do que o limite")

# ---------------------------------------------------------------------------

func _test_ui_battle() -> void:
	GameState.new_run("deck01", 777)
	GameState.add_relic("relic_ruby")
	GameState.add_relic("relic_banner")
	GameState.ante = 1
	var scene: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(scene)
	await get_tree().process_frame
	# A cena mudaria para a loja no fim; aqui queremos ficar no teste.
	EventBus.battle_ended.disconnect(scene._on_battle_ended)
	var bm: BattleManager = scene.get_node("BattleManager")
	var ended := [null]
	var cb := func(v: bool): ended[0] = v
	EventBus.battle_ended.connect(cb)
	var guard := 0
	var discarded_once := false
	while ended[0] == null and guard < 10:
		guard += 1
		var hand_box: HBoxContainer = scene.get_node("%Hand")
		# Canalizar através da vista (toque longo), uma vez.
		if not discarded_once:
			for view in hand_box.get_children():
				if view is CardView and bm.can_discard(view.card):
					var before := bm.deck.graveyard.size()
					view.held.emit(view.card)
					await get_tree().process_frame
					_check(bm.deck.graveyard.size() == before + 1, "Canalizar pela UI não descartou")
					discarded_once = true
					break
		var progressed := true
		while progressed:
			progressed = false
			hand_box = scene.get_node("%Hand")
			for view in hand_box.get_children():
				if view is CardView and bm.can_play(view.card):
					view.pressed.emit(view.card)
					await get_tree().process_frame
					progressed = true
					break
		var btn: Button = scene.get_node("%EndTurn")
		_check(not btn.disabled, "botão de atacar devia estar ativo no turno %d" % bm.turn)
		btn.pressed.emit()
		var t0 := Time.get_ticks_msec()
		var turn_before := bm.turn
		while ended[0] == null and bm.turn == turn_before and Time.get_ticks_msec() - t0 < 20000:
			await get_tree().process_frame
		_check(ended[0] != null or bm.turn > turn_before, "a cascata/turno não avançou (timeout)")
	EventBus.battle_ended.disconnect(cb)
	_check(ended[0] != null, "batalha com UI não terminou")
	print("  UI: batalha terminou (vitória=%s) no turno %d" % [str(ended[0]), bm.turn])
	scene.queue_free()
	await get_tree().process_frame

func _test_other_scenes() -> void:
	GameState.new_run("deck04", 42)
	GameState.add_gold(20)
	for path in ["res://scenes/main/Main.tscn", "res://scenes/shop/Shop.tscn", "res://scenes/ui/RunOver.tscn"]:
		var s: Node = load(path).instantiate()
		add_child(s)
		await get_tree().process_frame
		if path.ends_with("Main.tscn"):
			var grid: GridContainer = s.get_node("%DeckGrid")
			_check(grid.get_child_count() == 18, "menu devia listar 18 baralhos")
		if path.ends_with("Shop.tscn"):
			var offers: VBoxContainer = s.get_node("%CardOffers")
			_check(offers.get_child_count() == 3, "loja devia oferecer 3 cartas")
			for b in offers.get_children():
				_check(not (b as Button).text.is_empty(), "oferta sem texto")
			s.call("_open_remove_panel")
			await get_tree().process_frame
			var list: GridContainer = s.get_node("%DeckList")
			_check(list.get_child_count() > 0, "lista de remoção vazia")
			var before := GameState.deck.size()
			(list.get_child(0) as Button).pressed.emit()
			_check(GameState.deck.size() == before - 1, "remoção na loja não removeu uma carta")
		s.queue_free()
		await get_tree().process_frame
	print("  cenas Main/Shop/RunOver carregam")
