extends Node
## Teste de fumo headless:  godot --headless --path . res://tests/SmokeTest.tscn
## 1) Batalhas só com lógica (sem UI) com os 18 baralhos, com relíquias e inimigo com todas as habilidades.
## 2) Uma batalha a correr na cena real Battle.tscn (cascata animada com timers), com Canalizar.
## 3) Carregar as outras cenas (Main, Shop, RunOver) sem erros.
## Sai com código 0 se tudo passou, 1 se algo falhou.

var failures: Array[String] = []

func _ready() -> void:
	await get_tree().process_frame
	Settings.language = "pt"
	Settings.anim_speed = "normal"
	Settings.apply()
	Stats.set_tutorial_done(true)
	_test_settings()
	_test_rules()
	_test_mechanics_080()
	_test_content_update()
	_test_stats_and_custom()
	_test_logic_battles()
	await _test_ui_battle()
	await _test_other_scenes()
	await _test_new_scenes()
	await _test_scenes_080()
	if failures.is_empty():
		print("SMOKE TEST: OK")
		get_tree().quit(0)
	else:
		for f in failures:
			printerr("SMOKE TEST FAIL: " + f)
		get_tree().quit(1)

func _check(cond: bool, msg: String) -> void:
	if not cond:
		failures.append(msg)

# ---------------------------------------------------------------------------

func _test_settings() -> void:
	# Tradução: chaves em PT → EN; sem tradução fica o texto PT.
	Settings.language = "en"
	Settings.apply()
	_check(TranslationServer.translate("NOVO JOGO") == "NEW GAME", "tradução EN não funciona (TranslationServer)")
	_check(tr("ATACAR") == "ATTACK", "tr() não traduz para EN")
	_check(tr("Senado Azorius") == "Azorius Senate", "nomes dos baralhos não traduzem")
	_check(Cascade.label_for("power_add", 3) == "+3 Power", "etiquetas da cascata não traduzem")
	_check(tr("Goblin Guia") == "Goblin Guide", "nomes das cartas não traduzem (cards_en.json)")
	_check(tr(CardDB.get_card("c001").text).begins_with("+4 Mult; if it is the 1st"), "textos das cartas não traduzem")
	_check(tr("Texto sem tradução") == "Texto sem tradução", "texto sem entrada devia ficar igual")
	Settings.language = "pt"
	Settings.apply()
	_check(tr("NOVO JOGO") == "NOVO JOGO", "em PT o texto devia ficar igual")
	_check(TranslationServer.get_locale().begins_with("pt"), "locale devia ser pt_PT, é %s" % TranslationServer.get_locale())
	# Velocidade das animações e gravação das configurações.
	Settings.anim_speed = "instant"
	_check(Settings.dur(1.0) == 0.0, "instantâneo devia dar duração 0")
	Settings.anim_speed = "fast"
	_check(Settings.dur(1.0) < 1.0 and Settings.dur(1.0) > 0.0, "rápida devia encurtar")
	Settings.sfx_volume = 0.35
	Settings.vibration = false
	Settings.save_settings()
	Settings.sfx_volume = 1.0
	Settings.vibration = true
	Settings.anim_speed = "normal"
	Settings.load_settings()
	_check(is_equal_approx(Settings.sfx_volume, 0.35) and not Settings.vibration and Settings.anim_speed == "fast", "configurações não gravaram/carregaram")
	Settings.sfx_volume = 1.0
	Settings.vibration = true
	Settings.anim_speed = "normal"
	Settings.save_settings()
	Settings.apply()
	_check(AudioServer.get_bus_index("Sfx") >= 0 and AudioServer.get_bus_index("Music") >= 0, "buses de áudio em falta")
	print("  configurações/traduções OK")

func _test_rules() -> void:
	# Vida persistente, limite de relíquias, juros, inimigos por ato, bosses e regras.
	GameState.new_run("deck01", 11)
	_check(GameState.player_hp == 20 and GameState.player_max_hp == 20, "vida inicial devia ser 20/20")
	GameState.damage_player(7)
	var bm := BattleManager.new()
	bm.start(GameState.pick_enemy(1))
	_check(GameState.player_hp == 13, "a vida devia persistir entre batalhas (13), está %d" % GameState.player_hp)
	_check(bm.enemy.get("boss", false) == false and String(bm.enemy.get("id", "")) != "", "ante 1 devia ter um inimigo normal")
	GameState.heal(50)
	_check(GameState.player_hp == 20, "curar não devia passar da vida máxima")
	GameState.change_max_hp(5)
	_check(GameState.player_max_hp == 25, "vida máxima devia subir para 25")
	for i in 7:
		GameState.add_relic(String(CardDB.relics.keys()[i]))
	_check(GameState.relic_ids.size() == GameState.MAX_RELICS, "limite de relíquias devia ser %d" % GameState.MAX_RELICS)
	_check(not GameState.add_relic("relic_whetstone"), "add_relic devia recusar acima do limite")
	GameState.remove_relic(GameState.relic_ids[0])
	_check(GameState.relic_ids.size() == 4 and GameState.add_relic("relic_whetstone"), "vender devia abrir espaço")
	GameState.move_relic("relic_whetstone", 0)
	_check(GameState.relic_ids[0] == "relic_whetstone", "move_relic devia pôr a relíquia na frente")
	GameState.gold = 23
	GameState.interest_ante = 0
	_check(GameState.interest_due() == 4, "juros de 23 ouro deviam ser 4, são %d" % GameState.interest_due())
	GameState.pay_interest()
	_check(GameState.gold == 27 and GameState.interest_due() == 0, "juros deviam pagar uma vez por ante")
	# Bosses: ante 4 tem regra; ante 8 é o final.
	GameState.ante = 4
	var boss := GameState.pick_enemy(4)
	_check(bool(boss.get("boss", false)) and not (boss.get("rule", {}) as Dictionary).is_empty(), "ante 4 devia ter um boss com regra")
	GameState.ante = 8
	var final_boss := GameState.pick_enemy(8)
	_check(String(final_boss.get("id", "")) == "boss_zero", "ante 8 devia ser o boss final")
	# Regras de boss, uma a uma, sobre o mesmo baralho.
	GameState.new_run("deck05", 3)
	var tests := {
		"discards_minus": {"discards_minus": 1}, "hand_size": {"hand_size": 5},
		"creature_cost_plus": {"creature_cost_plus": 1}, "no_formations": {"no_formations": true},
		"relics_off": {"relics_off": true}, "color_silenced": {"color_silenced": "white"},
	}
	for key in tests:
		GameState.new_run("deck05", 3)
		GameState.relic_ids.append("relic_drum")
		GameState.ante = 4
		var b := BattleManager.new()
		b.start({"name": "Boss", "hp": 999999, "max_hp": 999999, "attack": 1, "text": "", "abilities": [], "boss": true, "rule": tests[key]})
		match key:
			"discards_minus":
				_check(b.discards_left == GameState.discards_for_battle() - 1, "Mordaça devia tirar 1 canalização")
			"hand_size":
				_check(b.deck.hand.size() == 5, "Peso devia dar mão de 5, deu %d" % b.deck.hand.size())
			"creature_cost_plus":
				var creature: CardInstance = null
				for c in b.deck.hand:
					if c.data.is_creature():
						creature = c
				if creature != null:
					_check(b.effects.cost_of(creature) == creature.data.cost + 1, "Tarifa devia custar +1")
			"no_formations", "relics_off", "color_silenced":
				_play_everything(b)
				var prev := b.preview_attack()
				if key == "no_formations":
					_check(prev.formations.is_empty(), "Caos devia anular as formações")
				elif key == "relics_off":
					var relic_steps := prev.steps.filter(func(st): return st.source_kind == "relic")
					_check(relic_steps.is_empty(), "relics_off devia calar as relíquias")
				else:
					var effect_steps := prev.steps.filter(func(st): return st.source_kind == "creature" and st.action != "power_add")
					_check(effect_steps.is_empty(), "cartas brancas silenciadas não deviam ter efeitos na cascata")
	# Pré-visualização por carta, contra-ataque e desfazer.
	GameState.new_run("deck05", 3)
	GameState.ante = 1
	var b2 := BattleManager.new()
	b2.start({"name": "Teste", "hp": 100000, "max_hp": 100000, "attack": 3, "text": "", "abilities": []})
	var playable: CardInstance = null
	for c in b2.deck.hand:
		if b2.can_play(c) and not c.data.is_land():
			playable = c
			break
	if playable != null:
		var hand_before := b2.deck.hand.duplicate()
		var delta := b2.preview_play(playable)
		_check(b2.deck.hand == hand_before and not (playable in b2.board), "preview_play não devia alterar o estado")
		var snap := b2.snapshot()
		b2.play(playable)
		var after := b2.preview_attack().total()
		_check(after == delta, "o delta previsto (%d) devia bater com o total depois de jogar (%d)" % [delta, after])
		var counter := b2.preview_enemy_phase()
		_check(int(counter["damage"]) == 3, "preview_enemy_phase devia ler o ataque do inimigo")
		_check(b2.restore_snapshot(snap), "restore_snapshot falhou")
		_check(b2.deck.hand.size() == hand_before.size() and b2.board.is_empty(), "desfazer devia repor a mão e o tabuleiro")
	# Eventos.
	GameState.new_run("deck01", 4)
	var ev := GameState.pick_event()
	_check(ev != "" and not CardDB.get_event(ev).is_empty(), "pick_event devia devolver um evento do ato I")
	_check(not GameState.seen_events.is_empty(), "o evento devia ficar registado como visto")
	print("  regras: vida persistente, relíquias, juros, bosses, previsões, desfazer, eventos OK")

# ---------------------------------------------------------------------------
# 0.8.0: mulligan, dupla face, selos, recapitular/exílio, planeswalker, selos planares, mapa.
# ---------------------------------------------------------------------------

## Batalha com mão/tabuleiro/grimório fixos (via restore), para testar mecânicas isoladas.
func _battle_with(hand: Array, board: Array = [], library: Array = [], discards: int = 3, mana: int = 6, attack: int = 0, max_turns: int = 5, graveyard: Array = []) -> BattleManager:
	var bm := BattleManager.new()
	var state := {
		"enemy": {"id": "test", "name": "Teste", "hp": 999999, "max_hp": 999999, "attack": attack, "text": "", "abilities": [], "boss": false, "rule": {}},
		"turn": 1, "max_turns": max_turns, "mana_total": mana, "mana_available": mana, "discards_left": discards,
		"player_hp": GameState.player_hp, "library": [], "hand": [], "graveyard": [], "board": [], "exile": [],
	}
	for i in GameState.deck.size():
		var id := String(GameState.deck[i]["id"])
		if id in hand:
			state["hand"].append({"id": id, "entry": i}); hand.erase(id)
		elif id in board:
			state["board"].append({"id": id, "entry": i}); board.erase(id)
		elif id in graveyard:
			state["graveyard"].append({"id": id, "entry": i, "exiled": true}); graveyard.erase(id)
		elif id in library:
			state["library"].append({"id": id, "entry": i}); library.erase(id)
	for id in hand:
		state["hand"].append({"id": id, "entry": -1})
	for id in board:
		state["board"].append({"id": id, "entry": -1})
	for id in graveyard:
		state["graveyard"].append({"id": id, "entry": -1, "exiled": true})
	for id in library:
		state["library"].append({"id": id, "entry": -1})
	bm.restore(state)
	return bm

func _find(cards: Array, id: String) -> CardInstance:
	for c in cards:
		if c.data.id == id:
			return c
	return null

func _test_mechanics_080() -> void:
	# --- Mulligan de Londres ---
	GameState.new_run("deck02", 21)
	var bm := BattleManager.new()
	bm.start(GameState.pick_enemy(1))
	_check(bm.can_mulligan(), "no turno 1 sem jogadas devia poder fazer mulligan")
	_check(bm.mulligan() and bm.deck.hand.size() == 6 and bm.pending_bottom == 1, "mulligan devia dar 6 cartas e pedir 1 para o fundo")
	_check(not bm.can_play(bm.deck.hand[0]) and not bm.can_mulligan(), "com cartas por pôr no fundo não se joga nem repete")
	var lib_before := bm.deck.library.size()
	_check(bm.bottom_card(bm.deck.hand[0]) and bm.pending_bottom == 0 and bm.deck.hand.size() == 5 and bm.deck.library.size() == lib_before + 1, "pôr no fundo devia tirar da mão e meter no grimório")
	_check(bm.mulligan() and bm.pending_bottom == 2, "o 2.º mulligan devia pedir 2 cartas para o fundo")
	bm.bottom_card(bm.deck.hand[0]); bm.bottom_card(bm.deck.hand[0])
	_check(bm.deck.hand.size() == 4 and bm.mulligan() and bm.pending_bottom == 3, "o 3.º mulligan devia ser permitido (fica com 3)")
	for i in 3:
		bm.bottom_card(bm.deck.hand[0])
	_check(bm.deck.hand.size() == 3 and not bm.can_mulligan(), "com 3 cartas já não há mulligan")
	_check(Stats.get_stat("mulligans") >= 3, "mulligans deviam contar nas estatísticas")
	var played_one := false
	for c in bm.deck.hand:
		if bm.can_play(c) and not c.data.is_land():
			played_one = bm.play(c)
			break
	if played_one:
		_check(bm.actions_this_turn == 1, "jogar devia contar como ação")
	# --- Dupla face: canalizar 3 com o Candidato na mão ---
	GameState.new_run("deck01", 5)
	GameState.add_card("c301")
	var b2 := _battle_with(["c301", "c001", "c002", "c003", "c004"], [], ["c005", "c006", "c007", "c008"], 3)
	var cand := _find(b2.deck.hand, "c301")
	_check(cand != null and cand.has_mission() and cand.mission_trigger() == "channel", "c301 devia ter missão de canalizar")
	for i in 3:
		var other: CardInstance = null
		for c in b2.deck.hand:
			if c != cand:
				other = c
				break
		b2.discard(other)
	_check(cand.transformed and cand.data.name == "Agente Duplo" and cand.power() == 50, "o Candidato devia virar Agente Duplo (50) depois de 3 canalizações")
	_check(Stats.get_stat("transforms") >= 1, "transformações deviam contar")
	b2.play(cand)
	var mul_steps := b2.preview_attack().steps.filter(func(st): return st.source_card == cand and st.action == "mult_mul")
	_check(mul_steps.size() == 1 and is_equal_approx(mul_steps[0].value, 3.0), "Agente Duplo devia dar ×3 Mult na cascata")
	# Dupla face: ouro (Relicário) e sobreviver a ataques (Noviço) — e gravar/retomar mantém a viragem.
	GameState.new_run("deck05", 5)
	GameState.gold = 4
	var b3 := _battle_with(["c306"], ["c304"], ["c041", "c042"], 3, 6, 0, 5)
	var rel := _find(b3.deck.hand, "c306")
	GameState.add_gold(8)
	b3.on_gold_changed()
	_check(rel.transformed and rel.data.name == "Relicário Aberto" and rel.data.power == 40, "o Relicário devia abrir com 10+ ouro")
	var nov := _find(b3.board, "c304")
	b3.end_turn()
	_check(not nov.transformed and nov.mission_count == 1, "o Noviço devia contar 1 ataque sobrevivido")
	b3.end_turn()
	_check(nov.transformed and nov.data.name == "Inquisidor Veterano", "o Noviço devia virar ao 2.º ataque")
	var saved := b3.to_dict()
	var b3b := BattleManager.new()
	b3b.restore(saved)
	var nov2 := _find(b3b.board, "c304")
	_check(nov2 != null and nov2.transformed and nov2.power() == 40, "a viragem devia sobreviver a gravar/retomar")
	# --- Selos de guilda ---
	GameState.new_run("deck05", 7)
	GameState.deck[0]["seal"] = "tithe"      # c039 Campeão
	GameState.deck[1]["seal"] = "vitality"   # c040 Tenente
	GameState.deck[2]["seal"] = "fury"       # c041 Falcão
	GameState.deck[3]["seal"] = "phyrexian"  # c042 Honra (feitiço)
	GameState.deck[4]["seal"] = "wisdom"     # c043 Marechal
	var b4 := _battle_with(["c039", "c040", "c041", "c042", "c043"], [], ["c044", "c045"], 3, 9)
	var gold_before := GameState.gold
	b4.play(_find(b4.deck.hand, "c039"))
	_check(GameState.gold == gold_before + 3, "Selo do Dízimo devia dar +3 ouro ao jogar")
	var champion := _find(b4.board, "c039")
	b4.play(_find(b4.deck.hand, "c040"))
	_check(champion.perm_power() == 15, "Selo da Vitalidade devia dar +15 permanente à criatura à esquerda")
	b4.play(_find(b4.deck.hand, "c041"))
	var hawk := _find(b4.board, "c041")
	b4.play(_find(b4.deck.hand, "c042"))
	var casc := b4.preview_attack()
	var fury_steps := casc.steps.filter(func(st): return st.source_card == hawk and st.retrigger)
	_check(fury_steps.size() >= 1, "Selo da Fúria devia reativar o Falcão")
	var phy := casc.steps.filter(func(st): return st.tag == "seal" and st.action == "mult_mul")
	_check(phy.size() == 1 and is_equal_approx(phy[0].value, 2.5), "Selo Phyrexiano devia dar ×2.5 Mult")
	var honra_entry: Dictionary = GameState.deck[3]
	b4.end_turn()
	_check(int(honra_entry.get("power_bonus", 0)) == -10 and bool(honra_entry.get("exiled_run", false)), "Selo Phyrexiano: Honra (10 Pod) devia perder 10 e ficar exilada da run")
	_check(not GameState.formation_levels.is_empty(), "Selo da Sabedoria devia subir uma formação ao fim do turno")
	var deck_size := GameState.deck.size()
	GameState.purge_exiled()
	_check(GameState.deck.size() == deck_size - 1, "a carta exilada devia sair do baralho (%d cartas), tem %d" % [deck_size - 1, GameState.deck.size()])
	# Nível de formação conta na cascata.
	GameState.formation_levels = {"pair": 2}
	var b5 := _battle_with([], ["c040", "c041"], [], 3, 9)   # dois custo 2: Pacto Dual
	var pair_steps := b5.preview_attack().steps.filter(func(st): return st.source_id == "pair")
	_check(pair_steps.size() == 1 and is_equal_approx(pair_steps[0].value, 3.0) and pair_steps[0].level == 2, "Pacto Dual nível 2 devia dar +3 Mult")
	# --- Recapitular e exílio ---
	GameState.new_run("deck03", 8)
	var b6 := _battle_with(["c019"], [], ["c020"], 3, 6, 0, 5, ["c018"])   # Ritual Sombrio no cemitério
	var ritual := _find(b6.deck.graveyard, "c018")
	_check(ritual != null and b6.flashback_cards().size() == 1 and b6.can_flashback(ritual), "Ritual Sombrio devia poder ser recapitulado")
	var mana_before := b6.mana_available
	_check(b6.play_flashback(ritual) and b6.mana_available == mana_before - 1, "recapitular devia custar o custo normal (1)")
	_check(ritual.zone == CardInstance.Zone.EXILE and ritual in b6.deck.exile and not (ritual in b6.deck.graveyard), "a carta recapitulada devia ir para o exílio")
	_check(b6.spells_this_turn.has(ritual) and b6.preview_attack().steps.any(func(st): return st.source_card == ritual), "o feitiço recapitulado devia entrar na cascata")
	_check(not b6.can_flashback(ritual), "não se recapitula duas vezes")
	var b6b := BattleManager.new()
	b6b.restore(b6.to_dict())
	_check(b6b.deck.exile.size() == 1, "o exílio devia sobreviver a gravar/retomar")
	_check(Stats.get_stat("flashbacks") >= 1, "recapitular devia contar")
	# --- Planeswalker ---
	GameState.new_run("deck01", 9)
	GameState.set_planeswalker("pw_red")
	_check(GameState.planeswalker_loyalty() == 2 and GameState.planeswalker_color() == "red", "planeswalker devia começar com 2 de lealdade")
	var b7 := _battle_with(["c001", "c002", "c003"], ["c007"], ["c004", "c005", "c006"], 3, 6)
	_check(b7.can_use_planeswalker(0) and not b7.can_use_planeswalker(2), "+1 disponível, −6 não (lealdade 2)")
	_check(b7.use_planeswalker(0) and GameState.planeswalker_loyalty() == 3, "+1 devia subir a lealdade para 3")
	_check(_find(b7.deck.hand, "c001").power_bonus == 10, "Ísaura +1 devia dar +10 Poder às cartas vermelhas na mão")
	_check(not b7.can_use_planeswalker(1), "só uma habilidade por turno")
	b7.play(_find(b7.deck.hand, "c001"))
	_check(GameState.planeswalker_loyalty() == 4, "jogar uma carta vermelha devia dar +1 lealdade")
	b7.end_turn()
	_check(b7.use_planeswalker(1) and GameState.planeswalker_loyalty() == 2 and is_equal_approx(b7.pw_mult_add, 10.0), "−2 devia custar 2 de lealdade e dar +10 Mult")
	var pw_steps := b7.preview_attack().steps.filter(func(st): return st.source_kind == "planeswalker")
	_check(pw_steps.size() == 1 and is_equal_approx(pw_steps[0].value, 10.0), "o planeswalker devia aparecer na cascata com +10 Mult")
	var b7b := BattleManager.new()
	b7b.restore(b7.to_dict())
	_check(is_equal_approx(b7b.pw_mult_add, 10.0) and b7b.pw_used_this_turn, "estado do planeswalker devia gravar")
	# Escudo do paladino: o inimigo não contra-ataca.
	GameState.set_planeswalker("pw_white")
	GameState.planeswalker["loyalty"] = 6
	var b8 := _battle_with(["c039"], [], ["c040"], 3, 6, 5)
	var hp_before := GameState.player_hp
	_check(b8.use_planeswalker(2) and b8.pw_shield and int(b8.preview_enemy_phase()["damage"]) == 0, "−6 do paladino devia bloquear o contra-ataque")
	b8.end_turn()
	_check(GameState.player_hp == hp_before, "com escudo o jogador não devia levar dano")
	_check(Stats.get_stat("pw_ultimates") >= 1, "a habilidade −6 devia contar")
	# --- Selos Planares ---
	GameState.new_run("deck01", 10, 8)
	_check(GameState.stake == 8 and GameState.hand_size_for_battle() == 5 and GameState.discards_for_battle() == 2, "Selo 8 devia dar mão 5 e 2 canalizações")
	GameState.map_choice = {"battle": "scout"}
	_check(GameState.battle_reward(0) == 1, "Selo 2+: Batedor sem ouro base (ante 1 → 1), deu %d" % GameState.battle_reward(0))
	GameState.map_choice = {"battle": "guard"}
	_check(GameState.battle_reward(0) == 4 + 1 + 4, "Guarda devia dar +4 ouro")
	GameState.ante = 4
	var boss := GameState.pick_enemy(4)
	var expected := int(round(GameState.enemy_hp_for_ante(4) * 0.85 * 1.35))
	_check(int(boss["hp"]) == expected, "Selo 3: boss do ante 4 devia ter %d de vida, tem %d" % [expected, int(boss["hp"])])
	var b9 := BattleManager.new()
	b9.start(boss)
	_check(b9.deck.hand.size() == 5 and b9.discards_left <= 2, "batalha com Selo 8 devia respeitar mão 5 e 2 canalizações")
	b9.damage_enemy(int(b9.enemy.hp * 0.6))
	b9.end_turn()
	_check(b9.ascended and not (b9.enemy.get("rule2", {}) as Dictionary).is_empty(), "abaixo de metade o boss devia ascender (2.ª regra)")
	GameState.map_choice = {"battle": "guard"}
	GameState.ante = 2
	var guard := GameState.pick_enemy(2)
	_check(int(guard["hp"]) == int(round(GameState.enemy_hp_for_ante(2) * 1.25)) and String(guard["variant"]) == "guard", "Guarda devia ter +25 % de vida")
	# --- Mapa ---
	GameState.new_run("deck01", 12)
	var o1 := GameState.map_options(1)
	_check(o1["battle"] == ["scout", "guard"] and o1["stop"][0] == "shop" and o1["stop"].size() == 2, "mapa do ante 1 devia oferecer Batedor/Guarda e Loja + outra")
	var o4 := GameState.map_options(4)
	_check(o4["battle"] == ["boss"] and o4["stop"] == ["shop", "merchant"], "ante 4 devia ser boss + Loja/Mercador Cego")
	var plan_a := GameState.map_options(3).duplicate(true)
	GameState.new_run("deck01", 12)
	_check(GameState.map_options(3) == plan_a, "o mapa devia ser determinístico por semente")
	_check(GameState.stop_scene("rest") == "event" and GameState.pending_event == "node_rest", "acampamento devia abrir a cena de evento")
	_check(GameState.stop_scene("merchant") == "shop" and GameState.stop_scene("event") == "event", "paragens deviam mapear para as cenas certas")
	GameState.choose_battle("guard")
	_check(GameState.map_choice["battle"] == "guard" and GameState.map_phase == "battle", "choose_battle devia registar a escolha")
	GameState.next_ante()
	_check(GameState.map_choice.is_empty() and GameState.act_of_ante(2) == 1 and GameState.act_of_ante(3) == 2 and GameState.act_of_ante(9) == 5, "atos da run: 1-2 → I, 3-4 → II, 9+ → V")
	# Relíquias lendárias: fora do sorteio normal; juros a dobrar.
	var saw_legendary := false
	for i in 60:
		var r := CardDB.random_relic_offer(GameState.rng, [])
		if bool(r.get("legendary", false)):
			saw_legendary = true
	_check(not saw_legendary and CardDB.legendary_relics([]).size() == 5, "as 5 relíquias lendárias não deviam sair na loja normal")
	GameState.relic_ids.append("relic_double_tithe")
	GameState.gold = 25
	GameState.interest_ante = 0
	_check(GameState.interest_due() == 10, "Dízimo Dobrado devia dobrar os juros (10), deu %d" % GameState.interest_due())
	# Gravar/retomar v3: planeswalker, níveis, mapa, selo planar, selos nas cartas.
	GameState.new_run("deck02", 13, 3)
	GameState.set_planeswalker("pw_blue")
	GameState.formation_levels = {"band": 1}
	GameState.deck[0]["seal"] = "fury"
	GameState.deck[1]["colors"] = ["blue"]
	GameState.map_options(1)
	GameState.choose_stop("rest")
	GameState.save_run({}, "map")
	GameState.new_run("deck01", 1)
	_check(GameState.load_run(), "load_run v3 falhou")
	_check(GameState.stake == 3 and GameState.planeswalker.get("id", "") == "pw_blue" and GameState.formation_level("band") == 1, "selo planar/planeswalker/níveis não gravaram")
	_check(String(GameState.deck[0].get("seal", "")) == "fury" and GameState.deck[1].get("colors", []) == ["blue"], "selos e cores das cartas não gravaram")
	_check(GameState.map_phase == "stop" and GameState.map_choice.get("stop", "") == "rest" and GameState.map_plan.has("1") and GameState.saved_scene == "map", "estado do mapa não gravou")
	var inst := CardDB.new_instance(String(GameState.deck[1]["id"]), GameState.deck[1])
	_check(inst.data.colors == ["blue"] and inst.data.has_color("blue"), "a cor alterada na Fonte devia aplicar-se à carta")
	GameState.clear_saved_run()
	print("  0.8.0: mulligan, dupla face, selos, recapitular, planeswalker, selos planares, mapa OK")

const TEST_MANIFEST := "ZSUPD 1\nc 2\nmin 7\nn pt teste de assinatura\nf 015abd7f5cc57a2dd94b7590f04ad8084273905ee33ec5cebeae62276a97f862 7 data/teste.json\nsig MEUCIQCyx0L5sEplwno3v9GYj3yCR4GUQ+/SYSQZttAG8MBlrQIgcv0b2d+Wu7N+Dy4/L5dvlm+26ydRW0UFbNWuyFfm0IM=\n"

func _test_content_update() -> void:
	var m := ContentUpdate.parse_manifest(TEST_MANIFEST)
	_check(not m.is_empty() and int(m["c"]) == 2 and (m["files"] as Array).size() == 1, "manifesto não foi lido")
	_check(ContentUpdate.verify(m), "assinatura válida devia passar")
	var tampered := ContentUpdate.parse_manifest(TEST_MANIFEST.replace("c 2", "c 3"))
	_check(not tampered.is_empty() and not ContentUpdate.verify(tampered), "manifesto adulterado devia falhar")
	var bad_path := ContentUpdate.parse_manifest(TEST_MANIFEST.replace("data/teste.json", "scripts/x.json"))
	_check(bad_path.is_empty(), "caminhos fora de data/ e i18n/ deviam ser recusados")
	_check(ContentUpdate.sha256_hex("{\"a\":1}".to_utf8_buffer()) == "015abd7f5cc57a2dd94b7590f04ad8084273905ee33ec5cebeae62276a97f862", "sha256 errado")
	_check(ContentUpdate.resolve("res://data/cards.json") == "res://data/cards.json", "sem conteúdo descarregado devia usar o APK")
	_check(ContentUpdate.installed_version() >= 1, "versão instalada devia ser pelo menos a do APK")
	print("  atualizações de conteúdo: manifesto e assinatura OK")

func _test_stats_and_custom() -> void:
	GameState.reset_progress()
	Stats.set_tutorial_done(true)
	GameState.new_run("deck01", 5)
	_check(Stats.get_stat("runs") == 1, "runs devia contar 1")
	_check(Stats.is_seen("cards", "c001"), "as cartas do baralho jogado deviam ficar descobertas")
	var unlocked := [""]
	var cb := func(id: String): unlocked[0] = id
	EventBus.achievement_unlocked.connect(cb)
	EventBus.damage_dealt.emit("enemy", 150000)
	EventBus.achievement_unlocked.disconnect(cb)
	_check(Stats.get_stat("best_attack") == 150000 and Stats.is_unlocked("attack_100k") and unlocked[0] == "attack_100k", "conquista Cem Mil não desbloqueou")
	_check(not Stats.is_unlocked("attack_1m"), "Um Milhão não devia estar desbloqueada")
	# Infinito.
	_check(GameState.map_options(10)["battle"] == ["scout", "guard"] and GameState.map_options(12)["battle"] == ["boss"], "mapa no infinito errado")
	GameState.endless = true
	_check(GameState.enemy_hp_for_ante(9) > GameState.enemy_hp_for_ante(8), "a vida devia continuar a subir no infinito")
	_check(bool(GameState.pick_enemy(12).get("boss", false)), "ante 12 devia ter boss no infinito")
	GameState.endless = false
	# Baralhos personalizados.
	var custom := {"id": "custom_1", "num": 0, "name": "Teste", "custom": true, "cards": ["c001", "c001", "c002", "c003", "c004", "c005", "c006", "c007", "c008", "c009"], "colors": ["red"], "size": 10, "difficulty": 0, "mechanic": "x"}
	CardDB.custom_decks["custom_1"] = custom
	CardDB.save_custom_decks()
	CardDB.load_custom_decks()
	_check(CardDB.get_deck("custom_1").get("name", "") == "Teste", "baralho personalizado não gravou/carregou")
	GameState.free_mode = true
	GameState.new_run("custom_1", 3)
	_check(GameState.deck.size() == 10 and GameState.deck_colors() == ["red"], "run com baralho personalizado errada")
	var bm := BattleManager.new()
	bm.start(GameState.pick_enemy(1))
	_check(bm.deck.hand.size() > 0, "batalha com baralho personalizado não começou")
	_check(Stats.decks_played() == 1, "baralhos personalizados não deviam contar para 'baralhos jogados' (%d)" % Stats.decks_played())
	CardDB.custom_decks.erase("custom_1")
	CardDB.save_custom_decks()
	GameState.free_mode = false
	# Progresso de uma versão antiga (só por baralho) alimenta os contadores globais.
	GameState.progress = {"best_ante": {"deck01": 6, "deck03": 9}, "wins": {"deck03": 2}, "difficulty": "normal"}
	Stats._ensure()
	_check(Stats.get_stat("best_ante") == 9 and Stats.decks_played() == 2 and Stats.get_stat("wins") == 2 and Stats.get_stat("runs") == 2, "migração do progresso antigo errada")
	Stats._ensure()
	_check(Stats.get_stat("wins") == 2, "a migração não devia repetir-se")
	GameState.reset_progress()
	Stats.set_tutorial_done(true)
	print("  estatísticas, conquistas, infinito e baralhos personalizados OK")

func _test_new_scenes() -> void:
	# Tutorial na primeira batalha + canhoto + texto grande.
	Stats.set_tutorial_done(false)
	Settings.left_handed = true
	Settings.large_text = true
	GameState.new_run("deck01", 8)
	GameState.ante = 1
	var scene: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(scene)
	await get_tree().process_frame
	EventBus.battle_ended.disconnect(scene._on_battle_ended)
	var tut: TutorialOverlay = null
	for c in scene.get_children():
		if c is TutorialOverlay:
			tut = c
	_check(tut != null, "o tutorial devia abrir na primeira batalha")
	var middle: HBoxContainer = scene.get_node("Layout/Middle")
	_check(middle.get_child(middle.get_child_count() - 1).name == "LeftCol", "modo canhoto devia pôr os botões à direita")
	var hand_box: HBoxContainer = scene.get_node("%Hand")
	if hand_box.get_child_count() > 0:
		var v: CardView = hand_box.get_child(0)
		_check(v.name_label.get_theme_font_size("font_size") == 16, "texto grande devia aumentar a fonte das cartas")
	if tut != null:
		tut.call("_finish")
		await get_tree().process_frame
		_check(Stats.tutorial_done(), "saltar o tutorial devia marcá-lo como feito")
	Settings.left_handed = false
	Settings.large_text = false
	scene.queue_free()
	await get_tree().process_frame
	# Ecrãs novos: estatísticas, coleção (3 separadores), construtor.
	for path in ["res://scenes/ui/StatsScreen.tscn", "res://scenes/ui/Collection.tscn", "res://scenes/builder/DeckBuilder.tscn"]:
		var s: Node = load(path).instantiate()
		add_child(s)
		await get_tree().process_frame
		if path.ends_with("Collection.tscn"):
			for tab in ["relics", "enemies", "cards"]:
				s.call("_select_tab", tab)
				await get_tree().process_frame
		if path.ends_with("DeckBuilder.tscn"):
			s.call("_add_card", "c001")
			s.call("_add_card", "c001")
			s.call("_add_card", "c001")
			_check((s.get("_cards") as Array).size() == 2, "o construtor devia limitar a 2 cópias")
			for i in range(2, 12):
				s.call("_add_card", "c%03d" % i)
			_check((s.get("_cards") as Array).size() == 12, "o construtor devia ter 12 cartas")
			s.call("_on_save")
			_check(CardDB.custom_decks.has("custom_1") and FileAccess.file_exists(CardDB.CUSTOM_DECKS_PATH), "guardar no construtor falhou")
			CardDB.custom_decks.erase("custom_1")
			CardDB.save_custom_decks()
		s.queue_free()
		await get_tree().process_frame
	GameState.reset_progress()
	Stats.set_tutorial_done(true)
	print("  tutorial, canhoto, texto grande, estatísticas, coleção e construtor OK")

# ---------------------------------------------------------------------------
# 0.8.0: mapa, Mercador Cego, nós (acampamento/fonte/altar), selar na loja, draft, quebra-cabeças.
# ---------------------------------------------------------------------------

func _test_scenes_080() -> void:
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	Stats.set_tutorial_done(true)
	# Mapa: fase de batalha do ante 1, escolher Guarda grava a escolha; fase de paragem.
	GameState.free_mode = false
	GameState.new_run("deck01", 77)
	GameState.map_options(1)
	var map_scene: Node = load("res://scenes/map/Map.tscn").instantiate()
	add_child(map_scene)
	await get_tree().process_frame
	_check(GameState.has_saved_run() and GameState.saved_scene == "battle" or GameState.has_saved_run(), "o mapa devia gravar a run")
	var cols: Array = map_scene.get("_columns")
	_check(cols.size() == 4, "o mapa do ato I devia ter 4 colunas (2 antes × batalha/paragem), tem %d" % cols.size())
	var guard_btn: Button = (cols[0]["buttons"] as Dictionary).get("guard")
	_check(guard_btn != null and not guard_btn.disabled, "o Guarda do ante 1 devia estar escolhível")
	var shop_btn: Button = (cols[1]["buttons"] as Dictionary).get("shop")
	_check(shop_btn != null and shop_btn.disabled, "a paragem do ante 1 ainda não devia estar escolhível")
	SceneRouter._busy = true   # go() não troca de cena durante o teste
	map_scene.call("_on_pick", 1, "battle", "guard")
	SceneRouter._busy = false
	_check(GameState.map_choice.get("battle", "") == "guard", "escolher Guarda no mapa não registou")
	map_scene.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# A batalha usa a escolha (Guarda = +25 % de vida) e no fim vai para o mapa em fase de paragem.
	GameState.map_phase = "stop"
	GameState.map_choice["stop"] = ""
	var map2: Node = load("res://scenes/map/Map.tscn").instantiate()
	add_child(map2)
	await get_tree().process_frame
	var cols2: Array = map2.get("_columns")
	var stop_buttons: Dictionary = cols2[1]["buttons"]
	_check(not (stop_buttons["shop"] as Button).disabled and (cols2[0]["buttons"]["guard"] as Button).disabled, "na fase de paragem só as paragens deviam estar ativas")
	SceneRouter._busy = true
	map2.call("_on_pick", 1, "stop", "rest")
	SceneRouter._busy = false
	_check(GameState.map_choice.get("stop", "") == "rest" and GameState.pending_event == "node_rest", "escolher o acampamento devia preparar o evento")
	map2.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Acampamento: curar 8.
	GameState.damage_player(10)
	var rest_scene: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(rest_scene)
	await get_tree().process_frame
	var hp0 := GameState.player_hp
	((rest_scene._options_box as VBoxContainer).get_child(0) as Button).pressed.emit()
	await get_tree().process_frame
	await get_tree().process_frame
	_check(GameState.player_hp == min(GameState.player_max_hp, hp0 + 8), "o acampamento devia curar 8")
	var ante_before := GameState.ante
	SceneRouter._busy = true
	rest_scene.call("_continue_run")
	SceneRouter._busy = false
	_check(GameState.ante == ante_before + 1 and GameState.map_phase == "battle" and GameState.saved_scene == "map" or GameState.ante == ante_before + 1, "continuar do evento devia avançar o ante e voltar ao mapa")
	rest_scene.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Fonte de Mana: recolorir 1 carta (o teste responde ao seletor com a 1.ª carta elegível).
	GameState.new_run("deck10", 5)   # Conclave Selesnya: verde/branco
	GameState.pending_event = "node_spring"
	var spring: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(spring)
	await get_tree().process_frame
	((spring._options_box as VBoxContainer).get_child(0) as Button).pressed.emit()
	for i in 3:
		for f in 3:
			await get_tree().process_frame
		var viewer := SceneRouter.top_overlay()
		if viewer is ZoneViewer:
			var fv := _first_card_view(viewer)
			viewer.call("_on_card_pressed", fv.card)
		else:
			break
	await get_tree().process_frame
	var recolored := 0
	for e in GameState.deck:
		if e.get("colors", []) == [GameState.main_color()]:
			recolored += 1
	_check(recolored >= 1, "a Fonte devia recolorir pelo menos 1 carta")
	spring.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Altar: fundir — sacrifica a 1.ª carta, a 2.ª herda os efeitos.
	GameState.new_run("deck05", 5)
	GameState.pending_event = "node_altar"
	var altar: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(altar)
	await get_tree().process_frame
	var size_before := GameState.deck.size()
	((altar._options_box as VBoxContainer).get_child(0) as Button).pressed.emit()
	for i in 2:
		for f in 3:
			await get_tree().process_frame
		var viewer := SceneRouter.top_overlay()
		if viewer is ZoneViewer:
			var fv := _first_card_view(viewer)
			viewer.call("_on_card_pressed", fv.card)
	await get_tree().process_frame
	await get_tree().process_frame
	var fused := 0
	for e in GameState.deck:
		if e.has("extra_effects"):
			fused += 1
	_check(GameState.deck.size() == size_before - 1 and fused == 1, "o Altar devia sacrificar 1 carta e fundir noutra (%d, %d)" % [GameState.deck.size(), fused])
	altar.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Mercador Cego: só relíquias lendárias e planeswalkers; comprar um planeswalker.
	GameState.new_run("deck01", 6)
	GameState.add_gold(40)
	GameState.map_options(4)
	GameState.ante = 4
	GameState.choose_stop("merchant")
	var merchant: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	add_child(merchant)
	await get_tree().process_frame
	_check(bool(merchant.get("merchant")), "a loja devia abrir em modo Mercador Cego")
	var pw_offers: VBoxContainer = merchant.get_node("%CardOffers")
	var relic_offers: VBoxContainer = merchant.get_node("%RelicOffers")
	_check(pw_offers.get_child_count() == 2 and relic_offers.get_child_count() == 2, "Mercador Cego devia oferecer 2 planeswalkers e 2 relíquias lendárias")
	(pw_offers.get_child(0) as Button).pressed.emit()
	await get_tree().process_frame
	_check(not GameState.planeswalker.is_empty() and GameState.planeswalker_loyalty() == 2, "comprar um planeswalker devia dar lealdade 2")
	var rb: Button = relic_offers.get_child(0)
	_check(bool(CardDB.relics[String((merchant.get("_offer_relics") as Array)[0]["id"])].get("legendary", false)), "as relíquias do Mercador Cego deviam ser lendárias")
	merchant.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Loja normal: selar uma carta (Selo da Fúria na 1.ª carta) e Marca Eterna (Selo Planar 5).
	GameState.new_run("deck01", 6, 5)
	GameState.add_gold(40)
	GameState.map_options(1)
	GameState.choose_stop("shop")
	var shop: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	add_child(shop)
	await get_tree().process_frame
	shop.call("_on_seal")
	await get_tree().process_frame
	var picker := SceneRouter.top_overlay()
	_check(picker is SealPicker, "selar devia abrir o seletor de selos")
	if picker is SealPicker:
		(picker.get("_on_pick") as Callable).call("fury")
		picker.queue_free()
		await get_tree().process_frame
		var viewer := SceneRouter.top_overlay()
		_check(viewer is ZoneViewer, "depois do selo devia abrir o baralho")
		if viewer is ZoneViewer:
			var fv := _first_card_view(viewer)
			var sealed_card: CardInstance = fv.card
			viewer.call("_on_card_pressed", sealed_card)
			await get_tree().process_frame
			_check(String(GameState.deck[sealed_card.entry_index].get("seal", "")) == "fury", "a carta devia ficar com o Selo da Fúria")
	var relic_btn: Button = (shop.get_node("%RelicOffers") as VBoxContainer).get_child(0)
	relic_btn.pressed.emit()
	await get_tree().process_frame
	_check(GameState.relic_ids.size() == 1 and GameState.relic_locked.size() == 1, "com o Selo Planar 5 a relíquia comprada devia ficar presa")
	var owned: VBoxContainer = shop.get_node("%OwnedRelics")
	_check(owned.get_child_count() == 1 and ((owned.get_child(0) as HBoxContainer).get_child(1) as Button).disabled, "a relíquia presa não devia ter botão de vender ativo")
	SceneRouter.close_overlays()
	shop.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Draft: 5 boosters × 2 escolhas + 3 terrenos → run de 4 antes.
	var draft: Node = load("res://scenes/draft/Draft.tscn").instantiate()
	add_child(draft)
	await get_tree().process_frame
	for pack in 5:
		for pick in 2:
			var current: Array = draft.get("_current")
			_check(current.size() == 5 - pick, "o booster devia ter %d cartas, tem %d" % [5 - pick, current.size()])
			draft.call("_on_pick", CardDB.new_instance((current[0] as CardData).id))
			await get_tree().process_frame
		await get_tree().create_timer(0.3).timeout
	_check(String(draft.get("_stage")) == "lands", "depois de 5 boosters devia vir a escolha de terrenos")
	for pick in 3:
		var current: Array = draft.get("_current")
		draft.call("_on_pick", CardDB.new_instance((current[0] as CardData).id))
		await get_tree().process_frame
	_check(String(draft.get("_stage")) == "done" and (draft.get("_picked") as Array).size() == 10 and (draft.get("_lands") as Array).size() == 3, "o draft devia acabar com 10 cartas + 3 terrenos")
	SceneRouter._busy = true
	draft.call("_on_start")
	SceneRouter._busy = false
	_check(GameState.mode == "draft" and GameState.max_ante == 4 and GameState.deck.size() == 13 and GameState.free_mode, "a run de draft devia ter 13 cartas e 4 antes")
	var dbm := BattleManager.new()
	dbm.start(GameState.pick_enemy(1))
	_check(dbm.deck.hand.size() > 0, "a batalha com o baralho de draft não começou")
	GameState.ante = 4
	_check(bool(GameState.pick_enemy(4).get("boss", false)), "o ante 4 do draft devia ser o boss final")
	draft.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Quebra-cabeças: a vida de cada um é exatamente o melhor ataque; a cena lista-os; a batalha resolve-se.
	for pz in CardDB.puzzles:
		var best := PuzzleSolver.solve(pz)
		_check(int(best["total"]) == int(pz.get("hp", 0)), "puzzle %s: melhor ataque %d devia ser igual à vida %d" % [pz.get("id", ""), int(best["total"]), int(pz.get("hp", 0))])
	var pscene: Node = load("res://scenes/puzzles/Puzzles.tscn").instantiate()
	add_child(pscene)
	await get_tree().process_frame
	pscene.queue_free()
	await get_tree().process_frame
	GameState.clear_saved_run()
	GameState.puzzle_id = "p1"
	GameState.free_mode = true
	GameState.relic_ids.clear()
	GameState.player_hp = 20
	var pb: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(pb)
	await get_tree().process_frame
	var pbm: BattleManager = pb.battle
	_check(pbm.puzzle and pbm.max_turns == 1 and pbm.discards_left == 0 and pbm.deck.hand.size() == 5, "a batalha do enigma devia ter 1 turno, 0 canalizações e 5 cartas")
	_check(not GameState.has_saved_run(), "os enigmas não deviam gravar a run")
	for id in ["c001", "c002", "c007"]:
		for c in pbm.deck.hand:
			if c.data.id == id:
				pb.call("_on_hand_card_pressed", c)
				break
	var result := [null]
	var cb := func(v: bool): result[0] = v
	EventBus.battle_ended.connect(cb)
	EventBus.battle_ended.disconnect(pb._on_battle_ended)
	pb.call("_on_end_turn")
	var guard := 0
	while result[0] == null and guard < 600:
		guard += 1
		await get_tree().process_frame
	EventBus.battle_ended.disconnect(cb)
	_check(result[0] == true, "a linha certa devia resolver o enigma 1")
	Stats.on_puzzle_solved("p1")
	_check(Stats.is_puzzle_solved("p1") and Stats.get_stat("puzzles_solved") == 1, "o enigma resolvido devia ficar registado")
	GameState.puzzle_id = ""
	pb.queue_free()
	await get_tree().process_frame
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	GameState.clear_saved_run()
	GameState.free_mode = false
	print("  mapa, acampamento, fonte, altar, Mercador Cego, selos na loja, draft e enigmas OK")

func _test_logic_battles() -> void:
	_check(CardDB.cards.size() == 308, "esperava 308 cartas, há %d" % CardDB.cards.size())
	_check(CardDB.decks.size() == 18, "esperava 18 baralhos")
	var total_wins := 0
	for deck in CardDB.decks:
		GameState.new_run(String(deck.id), 12345)
		_check(GameState.deck.size() == int(deck.size), "baralho %s tem %d cartas" % [deck.name, GameState.deck.size()])
		# Todas as relíquias (acima do limite de 5 — é um teste de regras, não de loja).
		for relic_id in CardDB.relics.keys():
			GameState.relic_ids.append(String(relic_id))
		GameState.player_hp = 60   # vida persistente: dá folga para 4 batalhas seguidas sem loja
		GameState.player_max_hp = 60
		var wins := 0
		var max_total := 0
		for ante in range(1, 5):
			GameState.ante = ante
			var bm := BattleManager.new()
			var hp := GameState.enemy_hp_for_ante(ante)
			bm.start({"name": "Teste", "hp": hp, "max_hp": hp, "attack": 2, "text": "", "abilities": [
				{"trigger": "turn_end", "action": "steal_gold", "value": 1},
				{"trigger": "every_n_turns", "n": 3, "action": "destroy_strongest"},
				{"trigger": "turn_end", "action": "damage_all_creatures", "value": 1},
				{"trigger": "turn_end", "action": "discard_random", "value": 1},
				{"trigger": "turn_end", "action": "heal_self", "value": 1},
			]})
			var result := [null]
			var cb := func(v: bool): result[0] = v
			EventBus.battle_ended.connect(cb)
			var guard := 0
			while result[0] == null and guard < 50:
				guard += 1
				_play_everything(bm)
				var preview := bm.preview_attack()
				_check(preview.total() == int(round(preview.power * preview.mult * preview.damage_mult)), "total da cascata inconsistente")
				max_total = max(max_total, preview.total())
				# Canalizar uma carta por turno, para exercitar on_discard
				if not bm.deck.hand.is_empty() and bm.can_discard(bm.deck.hand[0]):
					bm.discard(bm.deck.hand[0])
				bm.end_turn()
			EventBus.battle_ended.disconnect(cb)
			_check(result[0] != null, "batalha %s ante %d não terminou" % [deck.name, ante])
			_check(bm.turn <= bm.max_turns + bm.extra_turns, "turnos a mais em %s" % deck.name)
			if result[0] == true:
				wins += 1
		print("  %-22s %d/4 vitórias, melhor ataque %d" % [deck.name, wins, max_total])
		_check(max_total > 0, "baralho %s nunca atacou" % deck.name)
		total_wins += wins
	_check(total_wins >= 18, "demasiado poucas vitórias com relíquias fortes: %d" % total_wins)

func _play_everything(bm: BattleManager) -> void:
	var played := true
	var guard := 0
	while played and guard < 40:
		guard += 1
		played = false
		for card in bm.deck.hand.duplicate():
			if bm.can_play(card):
				_check(bm.play(card), "play() falhou numa carta jogável")
				played = true
				break
	_check(bm.creatures().size() <= BattleManager.MAX_CREATURES, "mais criaturas do que o limite")

# ---------------------------------------------------------------------------

func _test_ui_battle() -> void:
	GameState.new_run("deck01", 777)
	GameState.add_relic("relic_ruby")
	GameState.add_relic("relic_banner")
	GameState.ante = 1
	GameState.clear_saved_run()
	var scene: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(scene)
	await get_tree().process_frame
	# A cena mudaria para a loja no fim; aqui queremos ficar no teste.
	EventBus.battle_ended.disconnect(scene._on_battle_ended)
	var bm: BattleManager = scene.get_node("BattleManager")
	_check(GameState.has_saved_run(), "o início do turno 1 devia ter gravado a run")
	var ended := [null]
	var cb := func(v: bool): ended[0] = v
	EventBus.battle_ended.connect(cb)
	# Turno 1: Canalizar pela UI, jogar tudo, atacar.
	var hand_box: HBoxContainer = scene.get_node("%Hand")
	var dbtn: Button = scene.get_node("%DiscardBtn")
	dbtn.button_pressed = true
	await get_tree().process_frame
	for view in hand_box.get_children():
		if view is CardView and bm.can_discard(view.card):
			var before := bm.deck.graveyard.size()
			view.pressed.emit(view.card)
			await get_tree().process_frame
			_check(bm.deck.graveyard.size() == before + 1, "Canalizar pela UI não descartou")
			_check(not dbtn.button_pressed, "o modo Canalizar devia desligar-se depois de uma carta")
			break
	await _play_ui_turn(scene, bm, ended)
	_check(ended[0] != null or bm.turn == 2, "o turno 1 devia ter acabado (turno=%d)" % bm.turn)
	if ended[0] == null:
		# --- Overlays: pausa, carta em grande, grimório, configurações.
		(scene.get_node("%PauseBtn") as Button).pressed.emit()
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() is PauseMenu, "a pausa não abriu")
		if SceneRouter.top_overlay() is PauseMenu:
			(SceneRouter.top_overlay() as PauseMenu).close()
		await get_tree().process_frame
		await get_tree().process_frame
		_check(not SceneRouter.has_overlay(), "a pausa não fechou")
		for view in hand_box.get_children():
			if view is CardView:
				view.long_pressed.emit(view.card)
				break
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() is CardZoom, "o toque longo não abriu a carta em grande")
		SceneRouter.close_overlays()
		await get_tree().process_frame
		(scene.get_node("%LibraryBtn") as Button).pressed.emit()
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() is ZoneViewer, "o grimório não abriu")
		SceneRouter.close_overlays()
		await get_tree().process_frame
		var sm := SettingsMenu.open()
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() == sm, "as configurações não abriram")
		sm.close()
		await get_tree().process_frame
		await get_tree().process_frame
		# Desfazer pela UI: joga uma carta e anula.
		var hand_n := bm.deck.hand.size()
		for view in hand_box.get_children():
			if view is CardView and bm.can_play(view.card):
				view.pressed.emit(view.card)
				await get_tree().process_frame
				break
		var undo: Button = scene.get_node("%UndoBtn")
		if bm.deck.hand.size() == hand_n - 1:
			_check(not undo.disabled, "DESFAZER devia estar ativo depois de jogar")
			undo.pressed.emit()
			await get_tree().process_frame
			_check(bm.deck.hand.size() == hand_n, "DESFAZER não repôs a carta na mão")
		# Arrastar no tabuleiro: inverte a ordem das criaturas.
		if bm.board.size() >= 2:
			var first: CardInstance = bm.board[0]
			scene.call("_on_board_drag_started", first, Vector2(100, 100))
			scene.call("_on_board_drag_moved", first, Vector2(5000, 100))
			scene.call("_on_board_drag_ended", first, Vector2(5000, 100))
			_check(bm.board[bm.board.size() - 1] == first, "arrastar devia mover a criatura para o fim")
			var board_box: HBoxContainer = scene.get_node("%Board")
			_check(board_box.get_child(board_box.get_child_count() - 1) == scene._board_views[first.uid], "a vista devia acompanhar a nova ordem")
		# --- Gravação a meio: o início do turno 2 gravou a batalha; retoma-a numa cena nova.
		var saved := {"turn": bm.turn, "hand": bm.deck.hand.size(), "library": bm.deck.library.size(), "graveyard": bm.deck.graveyard.size(), "board": bm.board.size(), "hp": bm.enemy.hp, "mana": bm.mana_total, "discards": bm.discards_left}
		EventBus.battle_ended.disconnect(cb)
		scene.queue_free()
		await get_tree().process_frame
		GameState.new_run("deck05", 1)   # estado diferente: a retoma tem de vir do disco
		_check(GameState.load_run(), "load_run falhou com batalha a meio")
		_check(not GameState.pending_battle.is_empty(), "a gravação devia trazer a batalha")
		_check(String(GameState.deck_def.get("id", "")) == "deck01", "baralho errado na retoma")
		scene = load("res://scenes/battle/Battle.tscn").instantiate()
		add_child(scene)
		await get_tree().process_frame
		EventBus.battle_ended.disconnect(scene._on_battle_ended)
		bm = scene.get_node("BattleManager")
		EventBus.battle_ended.connect(cb)
		var same: bool = bm.turn == saved.turn and bm.deck.hand.size() == saved.hand and bm.deck.library.size() == saved.library \
			and bm.deck.graveyard.size() == saved.graveyard and bm.board.size() == saved.board and bm.enemy.hp == saved.hp \
			and bm.mana_total == saved.mana and bm.discards_left == saved.discards
		_check(same, "batalha retomada não bate certo: %s vs turno %d mão %d grimório %d cemitério %d tabuleiro %d" % [str(saved), bm.turn, bm.deck.hand.size(), bm.deck.library.size(), bm.deck.graveyard.size(), bm.board.size()])
		_check(GameState.pending_battle.is_empty(), "pending_battle devia ser consumida pela cena")
		for card in bm.board:
			_check(card.entry_index >= 0 and card.deck_entry == GameState.deck[card.entry_index], "criatura retomada perdeu a ligação ao baralho")
		print("  UI: batalha retomada no turno %d a partir do ficheiro" % bm.turn)
	# Continua até ao fim.
	var guard := 0
	while ended[0] == null and guard < 10:
		guard += 1
		await _play_ui_turn(scene, bm, ended)
	EventBus.battle_ended.disconnect(cb)
	_check(ended[0] != null, "batalha com UI não terminou")
	print("  UI: batalha terminou (vitória=%s) no turno %d" % [str(ended[0]), bm.turn])
	scene.queue_free()
	await get_tree().process_frame

## Joga tudo o que puder pela UI, carrega em ATACAR e espera que o turno avance (ou a batalha acabe).
func _play_ui_turn(scene: Node, bm: BattleManager, ended: Array) -> void:
	var progressed := true
	while progressed:
		progressed = false
		var hand_box: HBoxContainer = scene.get_node("%Hand")
		for view in hand_box.get_children():
			if view is CardView and bm.can_play(view.card):
				view.pressed.emit(view.card)
				await get_tree().process_frame
				progressed = true
				break
	var btn: Button = scene.get_node("%EndTurn")
	_check(not btn.disabled, "botão de atacar devia estar ativo no turno %d" % bm.turn)
	btn.pressed.emit()
	var t0 := Time.get_ticks_msec()
	var turn_before := bm.turn
	while ended[0] == null and bm.turn == turn_before and Time.get_ticks_msec() - t0 < 20000:
		await get_tree().process_frame
	_check(ended[0] != null or bm.turn > turn_before, "a cascata/turno não avançou (timeout)")

func _first_card_view(viewer: Node) -> CardView:
	var stack: Array = [viewer]
	var fallback: CardView = null
	while not stack.is_empty():
		var n: Node = stack.pop_back()
		if n is CardView and not n.is_queued_for_deletion():
			if (n as CardView).playable:
				return n
			if fallback == null:
				fallback = n
		for c in n.get_children():
			stack.append(c)
	return fallback

func _test_other_scenes() -> void:
	# Progresso limpo e determinístico.
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	GameState.clear_saved_run()
	GameState.free_mode = false
	_check(GameState.is_deck_unlocked("deck01"), "deck01 devia estar aberto")
	_check(not GameState.is_deck_unlocked("deck02"), "deck02 devia estar bloqueado no início")
	_check(not GameState.is_act_unlocked(1), "ato II devia estar bloqueado no início")
	# Gravação e retoma da run.
	GameState.new_run("deck04", 42)
	GameState.add_gold(20)
	GameState.add_relic("relic_drum")
	GameState.ante = 3
	GameState.deck[0]["power_bonus"] = 15
	GameState.save_run()
	_check(GameState.has_saved_run(), "run não ficou gravada")
	GameState.new_run("deck01", 1)
	_check(GameState.load_run(), "não conseguiu carregar a run")
	_check(GameState.deck_def.get("id") == "deck04" and GameState.ante == 3 and "relic_drum" in GameState.relic_ids and int(GameState.deck[0]["power_bonus"]) == 15, "run carregada não bate certo")
	# Abandonar a run: conta como derrota no ante atual e apaga a gravação.
	GameState.new_run("deck03", 9)
	GameState.ante = 3
	GameState.save_run({}, "shop")
	GameState.abandon_run()
	_check(not GameState.has_saved_run(), "abandonar devia apagar a gravação")
	_check(GameState.best_ante("deck03") == 3, "abandonar no ante 3 devia registar melhor ante 3")
	# Retoma na loja: a gravação lembra-se de onde estava.
	GameState.new_run("deck02", 3)
	GameState.ante = 2
	GameState.save_run({}, "shop")
	_check(GameState.load_run() and GameState.saved_scene == "shop" and GameState.pending_battle.is_empty(), "gravação na loja não retoma na loja")
	# Desbloqueios.
	GameState.new_run("deck01", 5)
	GameState.ante = 4
	var unl := GameState.record_run_end(4, false)
	_check(GameState.is_deck_unlocked("deck02"), "deck02 devia desbloquear ao chegar ao ante 4 com deck01")
	_check(unl.size() == 1, "esperava 1 desbloqueio, veio %d" % unl.size())
	GameState.record_run_end(6, false)
	_check(GameState.is_act_unlocked(1), "ato II devia abrir ao chegar ao ante 6")
	_check(GameState.is_deck_unlocked("deck06") and not GameState.is_deck_unlocked("deck07"), "no ato II só o 1.º capítulo devia estar aberto")
	# Cenas (progresso: só o deck01 chegou ao ante 4 → ato I com 2 capítulos abertos).
	GameState.progress = {"best_ante": {"deck01": 4}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	GameState.new_run("deck04", 42)
	GameState.add_gold(20)   # 24 ouro → 4 de juros na loja
	GameState.add_relic("relic_drum")
	GameState.damage_player(8)
	# Evento: escolhe a opção do ouro e confirma o resultado.
	GameState.ante = 2
	GameState.pending_event = "fountain"
	var ev_scene: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(ev_scene)
	await get_tree().process_frame
	_check(GameState.saved_scene == "battle" or GameState.has_saved_run(), "evento devia gravar ao entrar")
	var gold_ev := GameState.gold
	var opts: VBoxContainer = ev_scene._options_box
	_check(opts.get_child_count() == 3, "a Fonte devia ter 3 opções")
	(opts.get_child(1) as Button).pressed.emit()
	await get_tree().process_frame
	await get_tree().process_frame
	_check(GameState.gold == gold_ev + 6, "a opção do cantil devia dar +6 ouro")
	_check(ev_scene._continue.visible and GameState.pending_event == "", "depois da escolha devia aparecer CONTINUAR")
	ev_scene.queue_free()
	await get_tree().process_frame
	var gold_in := GameState.gold
	for path in ["res://scenes/main/Main.tscn", "res://scenes/campaign/Campaign.tscn", "res://scenes/ui/HowToPlay.tscn", "res://scenes/shop/Shop.tscn", "res://scenes/ui/RunOver.tscn"]:
		var s: Node = load(path).instantiate()
		add_child(s)
		await get_tree().process_frame
		if path.ends_with("Main.tscn"):
			_check(s.get_node("%NewGame") != null and s.get_node("%Difficulty") != null and s.get_node("%Settings") != null, "menu sem botões")
			_check((s.get_node("%Difficulty") as Button).text.contains("NORMAL"), "dificuldade devia ser Normal")
		if path.ends_with("Campaign.tscn"):
			var list: VBoxContainer = s.get_node("%ChapterList")
			_check(list.get_child_count() == 5, "ato I devia listar 5 capítulos, listou %d" % list.get_child_count())
			var enabled := 0
			for b in list.get_children():
				if not (b as Button).disabled:
					enabled += 1
			_check(enabled == 2, "no ato I deviam estar abertos 2 capítulos (01 e 02), estão %d" % enabled)
			_check(not (s.get_node("%Story") as Label).text.is_empty(), "história vazia")
		if path.ends_with("Shop.tscn"):
			var offers: VBoxContainer = s.get_node("%CardOffers")
			_check(offers.get_child_count() == 3, "loja devia oferecer 3 cartas")
			_check((s.get_node("%RelicOffers") as VBoxContainer).get_child_count() == 2, "loja devia oferecer 2 relíquias")
			_check(GameState.has_saved_run(), "a loja devia gravar a run ao entrar")
			_check(GameState.gold == gold_in + mini(5, int(gold_in / 5)), "juros: %d ouro deviam render %d (ouro=%d)" % [gold_in, mini(5, int(gold_in / 5)), GameState.gold])
			(s.get_node("%DeckButton") as Button).pressed.emit()
			await get_tree().process_frame
			_check(SceneRouter.top_overlay() is ZoneViewer, "ver baralho na loja não abriu")
			SceneRouter.close_overlays()
			await get_tree().process_frame
			# Curar e vida máxima.
			var hp_before := GameState.player_hp
			(s.get_node("%HealBtn") as Button).pressed.emit()
			_check(GameState.player_hp == min(GameState.player_max_hp, hp_before + 5), "curar na loja não curou")
			var max_before := GameState.player_max_hp
			(s.get_node("%MaxHpBtn") as Button).pressed.emit()
			_check(GameState.player_max_hp == max_before + 5, "vida máxima na loja não subiu")
			# Remover (escolhe a 1.ª carta do painel).
			var before := GameState.deck.size()
			s.call("_on_remove")
			await get_tree().process_frame
			var viewer := SceneRouter.top_overlay()
			_check(viewer is ZoneViewer, "remover devia abrir o baralho")
			if viewer is ZoneViewer:
				var first_view: CardView = _first_card_view(viewer)
				viewer.call("_on_card_pressed", first_view.card)
				await get_tree().process_frame
			_check(GameState.deck.size() == before - 1, "remoção na loja não removeu uma carta")
			# Melhorar (1.ª carta): bónus permanente.
			s.call("_on_upgrade")
			await get_tree().process_frame
			viewer = SceneRouter.top_overlay()
			if viewer is ZoneViewer:
				var fv: CardView = _first_card_view(viewer)
				var entry: Dictionary = GameState.deck[fv.card.entry_index]
				var pb := int(entry.get("power_bonus", 0))
				var mb := float(entry.get("mult_bonus", 0.0))
				viewer.call("_on_card_pressed", fv.card)
				await get_tree().process_frame
				_check(int(entry.get("power_bonus", 0)) > pb or float(entry.get("mult_bonus", 0.0)) > mb, "melhorar não deu bónus permanente")
			# Booster: escolhe 1 de 3.
			before = GameState.deck.size()
			s.call("_on_booster")
			await get_tree().process_frame
			viewer = SceneRouter.top_overlay()
			_check(viewer is ZoneViewer, "booster devia abrir 3 cartas")
			if viewer is ZoneViewer:
				var fv2: CardView = _first_card_view(viewer)
				viewer.call("_on_card_pressed", fv2.card)
				await get_tree().process_frame
			_check(GameState.deck.size() == before + 1, "booster não juntou uma carta")
			# Vender a relíquia que temos.
			var gold_before := GameState.gold
			var owned: VBoxContainer = s.get_node("%OwnedRelics")
			_check(owned.get_child_count() == GameState.relic_ids.size(), "lista das tuas relíquias errada")
			if owned.get_child_count() > 0:
				((owned.get_child(0) as HBoxContainer).get_child(1) as Button).pressed.emit()
				await get_tree().process_frame
				_check(GameState.relic_ids.is_empty() and GameState.gold > gold_before, "vender relíquia não funcionou")
			# Novas ofertas.
			var reroll: Button = s.get_node("%RerollBtn")
			if not reroll.disabled:
				reroll.pressed.emit()
				await get_tree().process_frame
				_check((s.get_node("%CardOffers") as VBoxContainer).get_child_count() == 3, "novas ofertas deviam voltar a dar 3 cartas")
			SceneRouter.close_overlays()
		if path.ends_with("RunOver.tscn"):
			_check((s.get_node("%Title") as Label).text == "DERROTA", "RunOver devia dizer DERROTA")
		s.queue_free()
		await get_tree().process_frame
	# Limpa o que o teste escreveu.
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	GameState.clear_saved_run()
	Settings.language = "auto"
	Settings.save_settings()
	print("  menu/campanha/como jogar/loja/fim carregam; gravação, abandono e desbloqueios OK")
