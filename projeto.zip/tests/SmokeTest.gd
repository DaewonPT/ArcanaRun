extends Node
## Teste de fumo headless:  godot --headless --path . res://tests/SmokeTest.tscn
## 1) Batalhas só com lógica (sem UI) com os 18 baralhos, com relíquias e inimigo com todas as habilidades.
## 2) Uma batalha a correr na cena real Battle.tscn (cascata animada com timers), com Canalizar.
## 3) Carregar as outras cenas (Main, Shop, RunOver) sem erros.
## Sai com código 0 se tudo passou, 1 se algo falhou.

var failures: Array[String] = []

func _ready() -> void:
	await get_tree().process_frame
	Settings.language = "pt"
	Settings.anim_speed = "normal"
	Settings.warn_mana = false   # os avisos opcionais têm o seu próprio teste
	Settings.warn_rare = false
	Settings.apply()
	Stats.set_tutorial_done(true)
	_test_settings()
	_test_rules()
	_test_mechanics_080()
	_test_090()
	await _test_0100()
	_test_content_update()
	_test_stats_and_custom()
	_test_logic_battles()
	await _test_ui_battle()
	await _test_other_scenes()
	await _test_new_scenes()
	await _test_scenes_080()
	await _test_scenes_090()
	await _test_scenes_0100()
	if failures.is_empty():
		print("SMOKE TEST: OK")
		get_tree().quit(0)
	else:
		for f in failures:
			printerr("SMOKE TEST FAIL: " + f)
		get_tree().quit(1)

func _check(cond: bool, msg: String) -> void:
	if not cond:
		failures.append(msg)

# ---------------------------------------------------------------------------

func _test_settings() -> void:
	# Tradução: chaves em PT → EN; sem tradução fica o texto PT.
	Settings.language = "en"
	Settings.apply()
	_check(TranslationServer.translate("NOVO JOGO") == "NEW GAME", "tradução EN não funciona (TranslationServer)")
	_check(tr("ATACAR") == "ATTACK", "tr() não traduz para EN")
	_check(tr("Senado Azorius") == "Azorius Senate", "nomes dos baralhos não traduzem")
	_check(Cascade.label_for("power_add", 3) == "+3 Power", "etiquetas da cascata não traduzem")
	_check(tr("Goblin Guia") == "Goblin Guide", "nomes das cartas não traduzem (cards_en.json)")
	_check(tr(CardDB.get_card("c001").text).begins_with("+4 Mult; if it is the 1st"), "textos das cartas não traduzem")
	_check(tr("Texto sem tradução") == "Texto sem tradução", "texto sem entrada devia ficar igual")
	Settings.language = "pt"
	Settings.apply()
	_check(tr("NOVO JOGO") == "NOVO JOGO", "em PT o texto devia ficar igual")
	_check(TranslationServer.get_locale().begins_with("pt"), "locale devia ser pt_PT, é %s" % TranslationServer.get_locale())
	# Velocidade das animações e gravação das configurações.
	Settings.anim_speed = "instant"
	_check(Settings.dur(1.0) == 0.0, "instantâneo devia dar duração 0")
	Settings.anim_speed = "fast"
	_check(Settings.dur(1.0) < 1.0 and Settings.dur(1.0) > 0.0, "rápida devia encurtar")
	Settings.sfx_volume = 0.35
	Settings.vibration = false
	Settings.save_settings()
	Settings.sfx_volume = 1.0
	Settings.vibration = true
	Settings.anim_speed = "normal"
	Settings.load_settings()
	_check(is_equal_approx(Settings.sfx_volume, 0.35) and not Settings.vibration and Settings.anim_speed == "fast", "configurações não gravaram/carregaram")
	Settings.sfx_volume = 1.0
	Settings.vibration = true
	Settings.anim_speed = "normal"
	Settings.save_settings()
	Settings.apply()
	_check(AudioServer.get_bus_index("Sfx") >= 0 and AudioServer.get_bus_index("Music") >= 0, "buses de áudio em falta")
	print("  configurações/traduções OK")

func _test_rules() -> void:
	# Vida persistente, limite de relíquias, juros, inimigos por ato, bosses e regras.
	GameState.new_run("deck01", 11)
	_check(GameState.player_hp == 20 and GameState.player_max_hp == 20, "vida inicial devia ser 20/20")
	GameState.damage_player(7)
	var bm := BattleManager.new()
	bm.start(GameState.pick_enemy(1))
	_check(GameState.player_hp == 13, "a vida devia persistir entre batalhas (13), está %d" % GameState.player_hp)
	_check(bm.enemy.get("boss", false) == false and String(bm.enemy.get("id", "")) != "", "ante 1 devia ter um inimigo normal")
	GameState.heal(50)
	_check(GameState.player_hp == 20, "curar não devia passar da vida máxima")
	GameState.change_max_hp(5)
	_check(GameState.player_max_hp == 25, "vida máxima devia subir para 25")
	for i in 7:
		GameState.add_relic(String(CardDB.relics.keys()[i]))
	_check(GameState.relic_ids.size() == GameState.MAX_RELICS, "limite de relíquias devia ser %d" % GameState.MAX_RELICS)
	_check(not GameState.add_relic("relic_whetstone"), "add_relic devia recusar acima do limite")
	GameState.remove_relic(GameState.relic_ids[0])
	_check(GameState.relic_ids.size() == 4 and GameState.add_relic("relic_whetstone"), "vender devia abrir espaço")
	GameState.move_relic("relic_whetstone", 0)
	_check(GameState.relic_ids[0] == "relic_whetstone", "move_relic devia pôr a relíquia na frente")
	GameState.gold = 23
	GameState.interest_ante = 0
	_check(GameState.interest_due() == 4, "juros de 23 ouro deviam ser 4, são %d" % GameState.interest_due())
	GameState.pay_interest()
	_check(GameState.gold == 27 and GameState.interest_due() == 0, "juros deviam pagar uma vez por ante")
	# Bosses: ante 4 tem regra; ante 8 é o final.
	GameState.ante = 4
	var boss := GameState.pick_enemy(4)
	_check(bool(boss.get("boss", false)) and not (boss.get("rule", {}) as Dictionary).is_empty(), "ante 4 devia ter um boss com regra")
	GameState.ante = 8
	var final_boss := GameState.pick_enemy(8)
	_check(String(final_boss.get("id", "")) == "boss_zero", "ante 8 devia ser o boss final")
	# Regras de boss, uma a uma, sobre o mesmo baralho.
	GameState.new_run("deck05", 3)
	var tests := {
		"discards_minus": {"discards_minus": 1}, "hand_size": {"hand_size": 5},
		"creature_cost_plus": {"creature_cost_plus": 1}, "no_formations": {"no_formations": true},
		"relics_off": {"relics_off": true}, "color_silenced": {"color_silenced": "white"},
	}
	for key in tests:
		GameState.new_run("deck05", 3)
		GameState.relic_ids.append("relic_drum")
		GameState.ante = 4
		var b := BattleManager.new()
		b.start({"name": "Boss", "hp": 999999, "max_hp": 999999, "attack": 1, "text": "", "abilities": [], "boss": true, "rule": tests[key]})
		match key:
			"discards_minus":
				_check(b.discards_left == GameState.discards_for_battle() - 1, "Mordaça devia tirar 1 canalização")
			"hand_size":
				_check(b.deck.hand.size() == 5, "Peso devia dar mão de 5, deu %d" % b.deck.hand.size())
			"creature_cost_plus":
				var creature: CardInstance = null
				for c in b.deck.hand:
					if c.data.is_creature():
						creature = c
				if creature != null:
					_check(b.effects.cost_of(creature) == creature.data.cost + 1, "Tarifa devia custar +1")
			"no_formations", "relics_off", "color_silenced":
				_play_everything(b)
				var prev := b.preview_attack()
				if key == "no_formations":
					_check(prev.formations.is_empty(), "Caos devia anular as formações")
				elif key == "relics_off":
					var relic_steps := prev.steps.filter(func(st): return st.source_kind == "relic")
					_check(relic_steps.is_empty(), "relics_off devia calar as relíquias")
				else:
					var effect_steps := prev.steps.filter(func(st): return st.source_kind == "creature" and st.action != "power_add")
					_check(effect_steps.is_empty(), "cartas brancas silenciadas não deviam ter efeitos na cascata")
	# Pré-visualização por carta, contra-ataque e desfazer.
	GameState.new_run("deck05", 3)
	GameState.ante = 1
	var b2 := BattleManager.new()
	b2.start({"name": "Teste", "hp": 100000, "max_hp": 100000, "attack": 3, "text": "", "abilities": []})
	var playable: CardInstance = null
	for c in b2.deck.hand:
		if b2.can_play(c) and not c.data.is_land():
			playable = c
			break
	if playable != null:
		var hand_before := b2.deck.hand.duplicate()
		var delta := b2.preview_play(playable)
		_check(b2.deck.hand == hand_before and not (playable in b2.board), "preview_play não devia alterar o estado")
		var snap := b2.snapshot()
		b2.play(playable)
		var after := b2.preview_attack().total()
		_check(after == delta, "o delta previsto (%d) devia bater com o total depois de jogar (%d)" % [delta, after])
		var counter := b2.preview_enemy_phase()
		_check(int(counter["damage"]) == 3, "preview_enemy_phase devia ler o ataque do inimigo")
		_check(b2.restore_snapshot(snap), "restore_snapshot falhou")
		_check(b2.deck.hand.size() == hand_before.size() and b2.board.is_empty(), "desfazer devia repor a mão e o tabuleiro")
	# Eventos.
	GameState.new_run("deck01", 4)
	var ev := GameState.pick_event()
	_check(ev != "" and not CardDB.get_event(ev).is_empty(), "pick_event devia devolver um evento do ato I")
	_check(not GameState.seen_events.is_empty(), "o evento devia ficar registado como visto")
	print("  regras: vida persistente, relíquias, juros, bosses, previsões, desfazer, eventos OK")

# ---------------------------------------------------------------------------
# 0.8.0: mulligan, dupla face, selos, recapitular/exílio, planeswalker, selos planares, mapa.
# ---------------------------------------------------------------------------

## Batalha com mão/tabuleiro/grimório fixos (via restore), para testar mecânicas isoladas.
func _battle_with(hand: Array, board: Array = [], library: Array = [], discards: int = 3, mana: int = 6, attack: int = 0, max_turns: int = 5, graveyard: Array = []) -> BattleManager:
	var bm := BattleManager.new()
	var state := {
		"enemy": {"id": "test", "name": "Teste", "hp": 999999, "max_hp": 999999, "attack": attack, "text": "", "abilities": [], "boss": false, "rule": {}},
		"turn": 1, "max_turns": max_turns, "mana_total": mana, "mana_available": mana, "discards_left": discards,
		"player_hp": GameState.player_hp, "library": [], "hand": [], "graveyard": [], "board": [], "exile": [],
	}
	for i in GameState.deck.size():
		var id := String(GameState.deck[i]["id"])
		if id in hand:
			state["hand"].append({"id": id, "entry": i}); hand.erase(id)
		elif id in board:
			state["board"].append({"id": id, "entry": i}); board.erase(id)
		elif id in graveyard:
			state["graveyard"].append({"id": id, "entry": i, "exiled": true}); graveyard.erase(id)
		elif id in library:
			state["library"].append({"id": id, "entry": i}); library.erase(id)
	for id in hand:
		state["hand"].append({"id": id, "entry": -1})
	for id in board:
		state["board"].append({"id": id, "entry": -1})
	for id in graveyard:
		state["graveyard"].append({"id": id, "entry": -1, "exiled": true})
	for id in library:
		state["library"].append({"id": id, "entry": -1})
	bm.restore(state)
	return bm

func _find(cards: Array, id: String) -> CardInstance:
	for c in cards:
		if c.data.id == id:
			return c
	return null

func _test_mechanics_080() -> void:
	# --- Mulligan de Londres ---
	GameState.new_run("deck02", 21)
	var bm := BattleManager.new()
	bm.start(GameState.pick_enemy(1))
	_check(bm.can_mulligan(), "no turno 1 sem jogadas devia poder fazer mulligan")
	_check(bm.mulligan() and bm.deck.hand.size() == 6 and bm.pending_bottom == 1, "mulligan devia dar 6 cartas e pedir 1 para o fundo")
	_check(not bm.can_play(bm.deck.hand[0]) and not bm.can_mulligan(), "com cartas por pôr no fundo não se joga nem repete")
	var lib_before := bm.deck.library.size()
	_check(bm.bottom_card(bm.deck.hand[0]) and bm.pending_bottom == 0 and bm.deck.hand.size() == 5 and bm.deck.library.size() == lib_before + 1, "pôr no fundo devia tirar da mão e meter no grimório")
	_check(bm.mulligan() and bm.pending_bottom == 2, "o 2.º mulligan devia pedir 2 cartas para o fundo")
	bm.bottom_card(bm.deck.hand[0]); bm.bottom_card(bm.deck.hand[0])
	_check(bm.deck.hand.size() == 4 and bm.mulligan() and bm.pending_bottom == 3, "o 3.º mulligan devia ser permitido (fica com 3)")
	for i in 3:
		bm.bottom_card(bm.deck.hand[0])
	_check(bm.deck.hand.size() == 3 and not bm.can_mulligan(), "com 3 cartas já não há mulligan")
	_check(Stats.get_stat("mulligans") >= 3, "mulligans deviam contar nas estatísticas")
	var played_one := false
	for c in bm.deck.hand:
		if bm.can_play(c) and not c.data.is_land():
			played_one = bm.play(c)
			break
	if played_one:
		_check(bm.actions_this_turn == 1, "jogar devia contar como ação")
	# --- Dupla face: canalizar 3 com o Candidato na mão ---
	GameState.new_run("deck01", 5)
	GameState.add_card("c301")
	var b2 := _battle_with(["c301", "c001", "c002", "c003", "c004"], [], ["c005", "c006", "c007", "c008"], 3)
	var cand := _find(b2.deck.hand, "c301")
	_check(cand != null and cand.has_mission() and cand.mission_trigger() == "channel", "c301 devia ter missão de canalizar")
	for i in 3:
		var other: CardInstance = null
		for c in b2.deck.hand:
			if c != cand:
				other = c
				break
		b2.discard(other)
	_check(cand.transformed and cand.data.name == "Agente Duplo" and cand.power() == 50, "o Candidato devia virar Agente Duplo (50) depois de 3 canalizações")
	_check(Stats.get_stat("transforms") >= 1, "transformações deviam contar")
	b2.play(cand)
	var mul_steps := b2.preview_attack().steps.filter(func(st): return st.source_card == cand and st.action == "mult_mul")
	_check(mul_steps.size() == 1 and is_equal_approx(mul_steps[0].value, 3.0), "Agente Duplo devia dar ×3 Mult na cascata")
	# Dupla face: ouro (Relicário) e sobreviver a ataques (Noviço) — e gravar/retomar mantém a viragem.
	GameState.new_run("deck05", 5)
	GameState.gold = 4
	var b3 := _battle_with(["c306"], ["c304"], ["c041", "c042"], 3, 6, 0, 5)
	var rel := _find(b3.deck.hand, "c306")
	GameState.add_gold(8)
	b3.on_gold_changed()
	_check(rel.transformed and rel.data.name == "Relicário Aberto" and rel.data.power == 40, "o Relicário devia abrir com 10+ ouro")
	var nov := _find(b3.board, "c304")
	b3.end_turn()
	_check(not nov.transformed and nov.mission_count == 1, "o Noviço devia contar 1 ataque sobrevivido")
	b3.end_turn()
	_check(nov.transformed and nov.data.name == "Inquisidor Veterano", "o Noviço devia virar ao 2.º ataque")
	var saved := b3.to_dict()
	var b3b := BattleManager.new()
	b3b.restore(saved)
	var nov2 := _find(b3b.board, "c304")
	_check(nov2 != null and nov2.transformed and nov2.power() == 40, "a viragem devia sobreviver a gravar/retomar")
	# --- Selos de guilda ---
	GameState.new_run("deck05", 7)
	GameState.deck[0]["seal"] = "tithe"      # c039 Campeão
	GameState.deck[1]["seal"] = "vitality"   # c040 Tenente
	GameState.deck[2]["seal"] = "fury"       # c041 Falcão
	GameState.deck[3]["seal"] = "phyrexian"  # c042 Honra (feitiço)
	GameState.deck[4]["seal"] = "wisdom"     # c043 Marechal
	var b4 := _battle_with(["c039", "c040", "c041", "c042", "c043"], [], ["c044", "c045"], 3, 9)
	var gold_before := GameState.gold
	b4.play(_find(b4.deck.hand, "c039"))
	_check(GameState.gold == gold_before + 3, "Selo do Dízimo devia dar +3 ouro ao jogar")
	var champion := _find(b4.board, "c039")
	b4.play(_find(b4.deck.hand, "c040"))
	_check(champion.perm_power() == 15, "Selo da Vitalidade devia dar +15 permanente à criatura à esquerda")
	b4.play(_find(b4.deck.hand, "c041"))
	var hawk := _find(b4.board, "c041")
	b4.play(_find(b4.deck.hand, "c042"))
	var casc := b4.preview_attack()
	var fury_steps := casc.steps.filter(func(st): return st.source_card == hawk and st.retrigger)
	_check(fury_steps.size() >= 1, "Selo da Fúria devia reativar o Falcão")
	var phy := casc.steps.filter(func(st): return st.tag == "seal" and st.action == "mult_mul")
	_check(phy.size() == 1 and is_equal_approx(phy[0].value, 2.5), "Selo Phyrexiano devia dar ×2.5 Mult")
	var honra_entry: Dictionary = GameState.deck[3]
	b4.end_turn()
	_check(int(honra_entry.get("power_bonus", 0)) == -10 and bool(honra_entry.get("exiled_run", false)), "Selo Phyrexiano: Honra (10 Pod) devia perder 10 e ficar exilada da run")
	_check(not GameState.formation_levels.is_empty(), "Selo da Sabedoria devia subir uma formação ao fim do turno")
	var deck_size := GameState.deck.size()
	GameState.purge_exiled()
	_check(GameState.deck.size() == deck_size - 1, "a carta exilada devia sair do baralho (%d cartas), tem %d" % [deck_size - 1, GameState.deck.size()])
	# Nível de formação conta na cascata.
	GameState.formation_levels = {"pair": 2}
	var b5 := _battle_with([], ["c040", "c041"], [], 3, 9)   # dois custo 2: Pacto Dual
	var pair_steps := b5.preview_attack().steps.filter(func(st): return st.source_id == "pair")
	_check(pair_steps.size() == 1 and is_equal_approx(pair_steps[0].value, 3.0) and pair_steps[0].level == 2, "Pacto Dual nível 2 devia dar +3 Mult")
	# --- Recapitular e exílio ---
	GameState.new_run("deck03", 8)
	var b6 := _battle_with(["c019"], [], ["c020"], 3, 6, 0, 5, ["c018"])   # Ritual Sombrio no cemitério
	var ritual := _find(b6.deck.graveyard, "c018")
	_check(ritual != null and b6.flashback_cards().size() == 1 and b6.can_flashback(ritual), "Ritual Sombrio devia poder ser recapitulado")
	var mana_before := b6.mana_available
	_check(b6.play_flashback(ritual) and b6.mana_available == mana_before - 1, "recapitular devia custar o custo normal (1)")
	_check(ritual.zone == CardInstance.Zone.EXILE and ritual in b6.deck.exile and not (ritual in b6.deck.graveyard), "a carta recapitulada devia ir para o exílio")
	_check(b6.spells_this_turn.has(ritual) and b6.preview_attack().steps.any(func(st): return st.source_card == ritual), "o feitiço recapitulado devia entrar na cascata")
	_check(not b6.can_flashback(ritual), "não se recapitula duas vezes")
	var b6b := BattleManager.new()
	b6b.restore(b6.to_dict())
	_check(b6b.deck.exile.size() == 1, "o exílio devia sobreviver a gravar/retomar")
	_check(Stats.get_stat("flashbacks") >= 1, "recapitular devia contar")
	# --- Planeswalker ---
	GameState.new_run("deck01", 9)
	GameState.set_planeswalker("pw_red")
	_check(GameState.planeswalker_loyalty() == 2 and GameState.planeswalker_color() == "red", "planeswalker devia começar com 2 de lealdade")
	var b7 := _battle_with(["c001", "c002", "c003"], ["c007"], ["c004", "c005", "c006"], 3, 6)
	_check(b7.can_use_planeswalker(0) and not b7.can_use_planeswalker(2), "+1 disponível, −6 não (lealdade 2)")
	_check(b7.use_planeswalker(0) and GameState.planeswalker_loyalty() == 3, "+1 devia subir a lealdade para 3")
	_check(_find(b7.deck.hand, "c001").power_bonus == 10, "Ísaura +1 devia dar +10 Poder às cartas vermelhas na mão")
	_check(not b7.can_use_planeswalker(1), "só uma habilidade por turno")
	b7.play(_find(b7.deck.hand, "c001"))
	_check(GameState.planeswalker_loyalty() == 4, "jogar uma carta vermelha devia dar +1 lealdade")
	b7.end_turn()
	_check(b7.use_planeswalker(1) and GameState.planeswalker_loyalty() == 2 and is_equal_approx(b7.pw_mult_add, 10.0), "−2 devia custar 2 de lealdade e dar +10 Mult")
	var pw_steps := b7.preview_attack().steps.filter(func(st): return st.source_kind == "planeswalker")
	_check(pw_steps.size() == 1 and is_equal_approx(pw_steps[0].value, 10.0), "o planeswalker devia aparecer na cascata com +10 Mult")
	var b7b := BattleManager.new()
	b7b.restore(b7.to_dict())
	_check(is_equal_approx(b7b.pw_mult_add, 10.0) and b7b.pw_used_this_turn, "estado do planeswalker devia gravar")
	# Escudo do paladino: o inimigo não contra-ataca.
	GameState.set_planeswalker("pw_white")
	GameState.planeswalker["loyalty"] = 6
	var b8 := _battle_with(["c039"], [], ["c040"], 3, 6, 5)
	var hp_before := GameState.player_hp
	_check(b8.use_planeswalker(2) and b8.pw_shield and int(b8.preview_enemy_phase()["damage"]) == 0, "−6 do paladino devia bloquear o contra-ataque")
	b8.end_turn()
	_check(GameState.player_hp == hp_before, "com escudo o jogador não devia levar dano")
	_check(Stats.get_stat("pw_ultimates") >= 1, "a habilidade −6 devia contar")
	# --- Selos Planares ---
	GameState.new_run("deck01", 10, 8)
	_check(GameState.stake == 8 and GameState.hand_size_for_battle() == 5 and GameState.discards_for_battle() == 2, "Selo 8 devia dar mão 5 e 2 canalizações")
	GameState.map_choice = {"battle": "scout"}
	_check(GameState.battle_reward(0) == 1, "Selo 2+: Batedor sem ouro base (ante 1 → 1), deu %d" % GameState.battle_reward(0))
	GameState.map_choice = {"battle": "guard"}
	_check(GameState.battle_reward(0) == 4 + 1 + 4, "Guarda devia dar +4 ouro")
	GameState.ante = 4
	GameState.climates["2"] = "mana_eclipse"   # clima que não mexe na vida do boss
	var boss := GameState.pick_enemy(4)
	var expected := int(round(GameState.enemy_hp_for_ante(4) * 0.85 * 1.35))
	_check(int(boss["hp"]) == expected, "Selo 3: boss do ante 4 devia ter %d de vida, tem %d" % [expected, int(boss["hp"])])
	var b9 := BattleManager.new()
	b9.start(boss)
	_check(b9.deck.hand.size() == 5 and b9.discards_left <= 2, "batalha com Selo 8 devia respeitar mão 5 e 2 canalizações")
	b9.damage_enemy(int(b9.enemy.hp * 0.6))
	b9.end_turn()
	_check(b9.ascended and not (b9.enemy.get("rule2", {}) as Dictionary).is_empty(), "abaixo de metade o boss devia ascender (2.ª regra)")
	GameState.map_choice = {"battle": "guard"}
	GameState.ante = 2
	GameState.climates["1"] = "guild_market"   # sem clima que mexa na vida
	var guard := GameState.pick_enemy(2)
	_check(int(guard["hp"]) == int(round(GameState.enemy_hp_for_ante(2) * 1.25)) and String(guard["variant"]) == "guard", "Guarda devia ter +25 % de vida")
	# --- Mapa ---
	GameState.new_run("deck01", 12)
	var o1 := GameState.map_options(1)
	_check(o1["battle"] == ["scout", "guard"] and o1["stop"][0] == "shop" and o1["stop"].size() == 2, "mapa do ante 1 devia oferecer Batedor/Guarda e Loja + outra")
	var o4 := GameState.map_options(4)
	_check(o4["battle"] == ["boss"] and o4["stop"] == ["shop", "merchant"], "ante 4 devia ser boss + Loja/Mercador Cego")
	var plan_a := GameState.map_options(3).duplicate(true)
	GameState.new_run("deck01", 12)
	_check(GameState.map_options(3) == plan_a, "o mapa devia ser determinístico por semente")
	_check(GameState.stop_scene("rest") == "event" and GameState.pending_event == "node_rest", "acampamento devia abrir a cena de evento")
	_check(GameState.stop_scene("merchant") == "shop" and GameState.stop_scene("event") == "event", "paragens deviam mapear para as cenas certas")
	GameState.choose_battle("guard")
	_check(GameState.map_choice["battle"] == "guard" and GameState.map_phase == "battle", "choose_battle devia registar a escolha")
	GameState.next_ante()
	_check(GameState.map_choice.is_empty() and GameState.act_of_ante(2) == 1 and GameState.act_of_ante(3) == 2 and GameState.act_of_ante(9) == 5, "atos da run: 1-2 → I, 3-4 → II, 9+ → V")
	# Relíquias lendárias: fora do sorteio normal; juros a dobrar.
	var saw_legendary := false
	for i in 60:
		var r := CardDB.random_relic_offer(GameState.rng, [])
		if bool(r.get("legendary", false)):
			saw_legendary = true
	_check(not saw_legendary and CardDB.legendary_relics([]).size() == 5, "as 5 relíquias lendárias não deviam sair na loja normal")
	GameState.relic_ids.append("relic_double_tithe")
	GameState.gold = 25
	GameState.interest_ante = 0
	_check(GameState.interest_due() == 10, "Dízimo Dobrado devia dobrar os juros (10), deu %d" % GameState.interest_due())
	# Gravar/retomar v3: planeswalker, níveis, mapa, selo planar, selos nas cartas.
	GameState.new_run("deck02", 13, 3)
	GameState.set_planeswalker("pw_blue")
	GameState.formation_levels = {"band": 1}
	GameState.deck[0]["seal"] = "fury"
	GameState.deck[1]["colors"] = ["blue"]
	GameState.map_options(1)
	GameState.choose_stop("rest")
	GameState.save_run({}, "map")
	GameState.new_run("deck01", 1)
	_check(GameState.load_run(), "load_run v3 falhou")
	_check(GameState.stake == 3 and GameState.planeswalker.get("id", "") == "pw_blue" and GameState.formation_level("band") == 1, "selo planar/planeswalker/níveis não gravaram")
	_check(String(GameState.deck[0].get("seal", "")) == "fury" and GameState.deck[1].get("colors", []) == ["blue"], "selos e cores das cartas não gravaram")
	_check(GameState.map_phase == "stop" and GameState.map_choice.get("stop", "") == "rest" and GameState.map_plan.has("1") and GameState.saved_scene == "map", "estado do mapa não gravou")
	var inst := CardDB.new_instance(String(GameState.deck[1]["id"]), GameState.deck[1])
	_check(inst.data.colors == ["blue"] and inst.data.has_color("blue"), "a cor alterada na Fonte devia aplicar-se à carta")
	GameState.clear_saved_run()
	print("  0.8.0: mulligan, dupla face, selos, recapitular, planeswalker, selos planares, mapa OK")

# ---------------------------------------------------------------------------
# 0.9.0: climas, bosses em 2 fases e regras novas, relíquias de boss, contratos, elites, maldições,
# missões novas, formações de póquer, relíquias que escalam, modo daltónico e gravação v4.
# ---------------------------------------------------------------------------

func _test_090() -> void:
	# --- Clima Planar: sorteio por ato (ato I só climas suaves), determinístico ---
	GameState.new_run("deck01", 41)
	var cl1 := GameState.climate_for_ante(1)
	_check(cl1 != "" and int(CardDB.get_climate(cl1).get("min_act", 1)) == 1, "o clima do ato I devia ser suave (min_act 1), saiu '%s'" % cl1)
	_check(GameState.climate_for_ante(2) == cl1, "os dois antes do mesmo ato partilham o clima")
	var cl2 := GameState.climate_for_ante(3)
	_check(cl2 != "" and cl2 != cl1, "o ato II devia ter outro clima")
	GameState.new_run("deck01", 41)
	_check(GameState.climate_for_ante(1) == cl1 and GameState.climate_for_ante(3) == cl2, "os climas deviam ser determinísticos por semente")
	# Mercado das Guildas: ataque com 2+ cores dá +2 ouro.
	GameState.new_run("deck01", 42)
	var bg := _battle_with([], ["c003", "c039"], [], 3, 6)
	bg.climate = "guild_market"
	var gsteps := bg.preview_attack().steps.filter(func(st): return st.source_kind == "climate" and st.action == "gold")
	_check(gsteps.size() == 1 and is_equal_approx(gsteps[0].value, 2.0), "Mercado das Guildas devia dar +2 ouro com 2 cores")
	# Eco Temporal: a 1.ª criatura ativa duas vezes; o inimigo tem +15 % de vida.
	var be := _battle_with([], ["c003", "c007"], [], 3, 6)
	be.climate = "temporal_echo"
	var first: CardInstance = be.board[0]
	_check(be.preview_attack().steps.any(func(st): return st.source_card == first and st.retrigger), "Eco Temporal devia reativar a 1.ª criatura")
	GameState.new_run("deck01", 43)
	GameState.map_choice = {"battle": "scout"}
	GameState.climates["1"] = "guild_market"
	var hp_plain := int(GameState.pick_enemy(1)["hp"])
	GameState.new_run("deck01", 43)
	GameState.map_choice = {"battle": "scout"}
	GameState.climates["1"] = "temporal_echo"
	var hp_echo := int(GameState.pick_enemy(1)["hp"])
	_check(absf(hp_echo - hp_plain * 1.15) <= 2.0, "Eco Temporal: inimigo com +15 %% de vida (%d → %d)" % [hp_plain, hp_echo])
	# Maré de Éter: feitiços a 0 no turno 1 e +1 nos turnos 4 e 5.
	var ba := _battle_with(["c042"], [], [], 3, 6)
	ba.climate = "aether_tide"
	var spell := _find(ba.deck.hand, "c042")
	_check(ba.effects.cost_of(spell) == 0, "Maré de Éter: feitiços a 0 no turno 1")
	ba.turn = 4
	_check(ba.effects.cost_of(spell) == 2, "Maré de Éter: feitiço de custo 1 devia custar 2 no turno 4, custa %d" % ba.effects.cost_of(spell))
	# Chuva de Meteoros: 3.ª criatura +20 Poder e 2 de dano no fim do turno.
	var bmr := _battle_with([], ["c003", "c007", "c186"], ["c001", "c005"], 3, 6)
	bmr.climate = "meteor_rain"
	var third: CardInstance = bmr.board[2]
	var met := bmr.preview_attack().steps.filter(func(st): return st.source_kind == "climate" and st.source_card == third and st.action == "power_add")
	_check(met.size() == 1 and is_equal_approx(met[0].value, 20.0), "Chuva de Meteoros devia dar +20 Poder à 3.ª criatura")
	bmr.end_turn()
	_check(third.damage == 2 or not (third in bmr.board), "Chuva de Meteoros devia ferir a 3.ª criatura no fim do turno")
	# Eclipse de Mana: mana máxima 5 e +2 Mult por formação.
	var bec := _battle_with([], ["c003", "c007"], [], 3, 6)
	bec.climate = "mana_eclipse"
	var ec := bec.preview_attack()
	var ecl := ec.steps.filter(func(st): return st.source_kind == "climate" and st.action == "mult_add")
	_check(bec.mana_cap() == 5 and ecl.size() == 1 and is_equal_approx(ecl[0].value, 2.0 * ec.formation_ids.size()), "Eclipse de Mana: mana máx. 5 e +2 Mult por formação")
	# Ferrugem de Óleo: relíquias de +Poder/+Mult ×1.5; cartas sem selo −5 Poder.
	GameState.new_run("deck01", 44)
	GameState.add_relic("relic_drum")
	var bo := _battle_with([], ["c003"], [], 3, 6)
	var plain := bo.preview_attack()
	bo.climate = "oil_rust"
	var rust := bo.preview_attack()
	var drum_a := plain.steps.filter(func(st): return st.source_id == "relic_drum")
	var drum_b := rust.steps.filter(func(st): return st.source_id == "relic_drum")
	_check(drum_a.size() == 1 and drum_b.size() == 1 and is_equal_approx(drum_b[0].value, drum_a[0].value * 1.5), "Ferrugem de Óleo: relíquias ×1.5")
	var pa := plain.steps.filter(func(st): return st.source_kind == "creature" and st.action == "power_add")
	var pb := rust.steps.filter(func(st): return st.source_kind == "creature" and st.action == "power_add")
	_check(not pa.is_empty() and not pb.is_empty() and int(pb[0].value) == int(pa[0].value) - 5, "Ferrugem de Óleo: −5 Poder nas cartas sem selo")
	# Lua de Sangue: dia (ímpar) +3 Mult por branca/verde; noite (par) por preta/vermelha; viragens à noite.
	var bb := _battle_with([], ["c003", "c039"], [], 3, 6)
	bb.climate = "blood_moon"
	var day := bb.preview_attack().steps.filter(func(st): return st.source_kind == "climate")
	_check(day.size() == 1 and is_equal_approx(day[0].value, 3.0), "Lua de Sangue (dia): +3 Mult pela carta branca")
	bb.turn = 2
	var night := bb.preview_attack().steps.filter(func(st): return st.source_kind == "climate")
	_check(night.size() == 1 and is_equal_approx(night[0].value, 3.0), "Lua de Sangue (noite): +3 Mult pela carta vermelha")
	GameState.new_run("deck05", 45)
	var bdf := _battle_with(["c304"], [], ["c041", "c042", "c043"], 3, 6)
	bdf.climate = "blood_moon"
	bdf.turn = 2
	bdf.end_turn()
	var flip := _find(bdf.deck.hand, "c304")
	_check(flip != null and flip.transformed, "Lua de Sangue: as cartas de dupla face viram no fim da noite")
	# Areias Escaldantes: a partir do turno 4, ×1.5 Mult.
	var bs := _battle_with([], ["c003"], [], 3, 6)
	bs.climate = "scorching_sands"
	_check(bs.preview_attack().steps.filter(func(st): return st.source_kind == "climate").is_empty(), "Areias Escaldantes: nada antes do turno 4")
	bs.turn = 4
	var sand := bs.preview_attack().steps.filter(func(st): return st.source_kind == "climate" and st.action == "mult_mul")
	_check(sand.size() == 1 and is_equal_approx(sand[0].value, 1.5), "Areias Escaldantes: ×1.5 Mult a partir do turno 4")

	# --- Bosses em 2 fases ---
	GameState.new_run("deck01", 46)
	GameState.ante = 4
	GameState.climates["2"] = "guild_market"
	GameState.map_choice = {"battle": "boss"}
	var bp := BattleManager.new()
	bp.start(GameState.pick_enemy(4))
	var atk0 := bp.enemy_attack()
	var heard := [""]
	var on_phase2 := func(line: String): heard[0] = line
	EventBus.boss_phase2.connect(on_phase2)
	bp.damage_enemy(int(bp.enemy.hp * 0.6))
	bp.end_turn()
	EventBus.boss_phase2.disconnect(on_phase2)
	_check(bp.phase2 and bp.enemy_attack() >= atk0 + BattleManager.PHASE2_ATTACK, "abaixo de metade o boss devia despertar com +2 de ataque")
	_check(heard[0] != "", "o boss devia dizer uma fala ao despertar")
	_check(not bp.ascended, "sem Selo 8 o boss não devia ativar a 2.ª regra")
	var bp2 := BattleManager.new()
	bp2.restore(bp.to_dict())
	_check(bp2.phase2, "o despertar devia gravar")
	# Regras dos bosses novos.
	GameState.new_run("deck01", 47)
	var bh := _battle_with([], [], [], 3, 6, 3, 5, ["c001", "c003", "c005", "c007", "c186", "c193"])
	bh.rule = {"attack_per_graveyard": 3}
	_check(bh.enemy_attack() == 5, "Hidra: +1 de ataque por cada 3 cartas no cemitério (devia ser 5, é %d)" % bh.enemy_attack())
	var bf := _battle_with(["c001", "c003", "c005"], [], ["c007", "c186"], 3, 6)
	bf.rule = {"gold_tax": 1}
	GameState.gold = 10
	bf.discard(bf.deck.hand[0])
	_check(GameState.gold == 9, "Falsário: canalizar devia custar 1 ouro")
	var bt := _battle_with(["c005"], ["c001", "c003", "c007"], [], 3, 9)
	bt.rule = {"max_creatures": 3}
	_check(bt.max_creatures() == 3 and not bt.can_play(_find(bt.deck.hand, "c005")), "Titã de Cinza: só 3 lugares na Arena")
	var bem := _battle_with(["c042", "c005"], [], [], 3, 9)
	bem.rule = {"spell_cost_plus": 1, "creature_cost_minus": 1}
	_check(bem.effects.cost_of(_find(bem.deck.hand, "c042")) == 2 and bem.effects.cost_of(_find(bem.deck.hand, "c005")) == 1, "Imperatriz: feitiços +1, criaturas −1")
	var bd := _battle_with([], ["c001", "c003"], ["c005", "c007"], 3, 6)
	bd.rule = {"exile_rightmost": true}
	var rightmost: CardInstance = bd.board[1]
	bd.end_turn()
	_check(not (rightmost in bd.board) and rightmost in bd.deck.exile, "Devorador: a criatura mais à direita devia ir para o exílio")

	# --- Relíquias de boss e Baú de Espólio ---
	GameState.new_run("deck01", 48)
	GameState.ante = 4
	var offer := GameState.prepare_loot().duplicate()
	_check(offer.size() == 3 and offer.all(func(id): return bool(CardDB.relics[id].get("boss", false))), "o Baú devia oferecer 3 relíquias de boss")
	_check(GameState.prepare_loot() == offer, "a oferta do Baú devia ser determinística")
	var max0 := GameState.player_max_hp
	_check(GameState.add_boss_relic("relic_zero_mask") and GameState.player_max_hp == max0 - 5, "Máscara do Zero devia tirar 5 de vida máxima")
	_check(GameState.relic_ids.is_empty() and "relic_zero_mask" in GameState.active_relic_ids(), "as relíquias de boss ficam à parte mas estão ativas")
	var disc0 := GameState.discards_for_battle()
	GameState.add_boss_relic("relic_usurper_crown")
	_check(GameState.discards_for_battle() == disc0 - 1 and is_equal_approx(GameState.relic_passive("mana_plus"), 1.0), "Coroa do Usurpador: +1 mana, −1 canalização")
	var hand0 := GameState.hand_size_for_battle()
	GameState.add_boss_relic("relic_thousand_lids")
	_check(GameState.hand_size_for_battle() == hand0 + 1, "Mil Pálpebras: +1 carta na mão")
	_check(GameState.shop_price(5) == 5, "sem o Cálice os preços são os normais")
	GameState.add_boss_relic("relic_abyss_chalice")
	_check(GameState.shop_price(5) == 7, "Cálice do Abismo: preços +2")
	GameState.add_boss_relic("relic_glass_heart")
	var bgh := _battle_with([], [], [], 3, 6)
	GameState.player_hp = 5
	bgh.lose_life(50)
	_check(GameState.player_hp == 1 and GameState.death_save_used, "Coração de Vidro devia deixar-te com 1 de vida")
	bgh.lose_life(50)
	_check(GameState.player_hp <= 0, "o Coração de Vidro só salva uma vez")
	GameState.player_hp = GameState.player_max_hp
	GameState.map_choice = {"battle": "guard"}
	var r0 := GameState.battle_reward(0)
	GameState.add_boss_relic("relic_black_sand")
	_check(GameState.battle_reward(0) == maxi(0, r0 - 3), "Areia Negra: −3 ouro por vitória")
	GameState.ante = 1
	GameState.map_choice = {"battle": "scout"}
	var bbs := BattleManager.new()
	bbs.start(GameState.pick_enemy(1))
	_check(bbs.extra_turns >= 1, "Areia Negra devia dar um turno extra")
	_check(Stats.get_stat("boss_relics") >= 6, "relíquias de boss deviam contar")

	# --- Contratos ---
	GameState.new_run("deck01", 49)
	GameState.set_contract("swift")
	var bc := _battle_with([], [], [], 3, 6)
	bc.turn = 2
	var g0 := GameState.gold
	var res := GameState.resolve_contract(bc, true)
	_check(bool(res.get("success", false)) and GameState.gold == g0 + 10 and GameState.contract.is_empty(), "Contrato: vencer até ao turno 3 devia dar +10 ouro")
	GameState.set_contract("clean_hands")
	bc.discards_used = 1
	_check(not bool(GameState.resolve_contract(bc, true).get("success", true)), "Mãos Limpas falha se canalizaste")
	GameState.set_contract("untouched")
	bc.life_lost = 0
	_check(not bool(GameState.resolve_contract(bc, false).get("success", true)), "um contrato falha sempre numa derrota")
	_check(Stats.get_stat("contracts_done") >= 1, "contratos cumpridos deviam contar")

	# --- Mapa: Elite, Quadro de Contratos e Tribunal ---
	var saw := {}
	for sd in range(100, 160):
		GameState.new_run("deck01", sd)
		for a in [2, 3, 5, 6, 7]:
			var o := GameState.map_options(a)
			for k in o["battle"] + o["stop"]:
				saw[String(k)] = true
	_check(saw.has("elite") and saw.has("contracts") and saw.has("tribunal"), "o mapa devia ter Elite, Quadro de Contratos e Tribunal (viu %s)" % str(saw.keys()))
	_check(GameState.stop_scene("contracts") == "event" and GameState.pending_event == "node_contracts", "o Quadro de Contratos devia abrir a cena de evento")
	_check(GameState.stop_scene("tribunal") == "event" and GameState.pending_event == "node_tribunal", "o Tribunal devia abrir a cena de evento")
	GameState.pending_event = ""
	# Elite: +60 % de vida, +2 de ataque, +6 ouro e relíquia garantida.
	GameState.new_run("deck01", 50)
	GameState.ante = 3
	GameState.climates["2"] = "guild_market"
	GameState.map_choice = {"battle": "scout"}
	var sc := GameState.pick_enemy(3)
	GameState.new_run("deck01", 50)
	GameState.ante = 3
	GameState.climates["2"] = "guild_market"
	GameState.map_choice = {"battle": "elite"}
	var el := GameState.pick_enemy(3)
	_check(absf(int(el["hp"]) - int(sc["hp"]) * 1.6) <= 2.0 and int(el["attack"]) == int(sc["attack"]) + 2 and String(el["variant"]) == "elite", "Elite: +60 %% de vida e +2 de ataque")
	_check(GameState.battle_reward(0) == 4 + 3 + 6, "Elite devia dar +6 ouro (deu %d)" % GameState.battle_reward(0))
	var bel := BattleManager.new()
	bel.start(el)
	var relics0 := GameState.relic_ids.size()
	bel.damage_enemy(int(bel.enemy.hp))
	bel.end_turn()
	_check(bel.finished and bel.elite_relic != "" and GameState.relic_ids.size() == relics0 + 1, "vencer uma Elite devia dar uma relíquia")
	_check(Stats.get_stat("elites") >= 1, "elites vencidas deviam contar")

	# --- Maldições e missões novas ---
	GameState.new_run("deck01", 51)
	GameState.add_card("c314")
	var bcu := _battle_with(["c314", "c001"], [], ["c003"], 3, 6)
	var curse := _find(bcu.deck.hand, "c314")
	_check(curse != null and curse.data.is_curse() and not bcu.can_play(curse) and bcu.can_discard(curse), "a Maldição não se joga, só se canaliza")
	_check(not CardDB.cards_for_colors(["red", "white", "blue", "black", "green"]).any(func(c): return c.is_curse()), "as maldições não deviam sair na loja")
	var b13 := _battle_with(["c313"], [], ["c001", "c003"], 3, 6)
	b13.lose_life(5)
	var pact := _find(b13.deck.hand, "c313")
	_check(pact != null and pact.transformed, "Sangue do Pacto devia virar ao perder 5 de vida")
	var b12 := _battle_with(["c312", "c041"], ["c039", "c040", "c043", "c044"], [], 3, 9)
	b12.play(_find(b12.deck.hand, "c041"))
	var oath := _find(b12.deck.hand, "c312")
	_check(oath != null and oath.transformed, "Juramento do Escudeiro devia virar com a Arena cheia")

	# --- Formações de póquer ---
	GameState.new_run("deck01", 52)
	var f1 := _battle_with([], ["c003", "c007", "c103", "c088"], [], 3, 9).preview_attack().formation_ids
	_check("two_pair" in f1 and not ("pair" in f1), "custos 1-1-3-3 deviam dar Pacto Duplo, deu %s" % str(f1))
	var f2 := _battle_with([], ["c005", "c193", "c235", "c155", "c197"], [], 3, 9).preview_attack().formation_ids
	_check("full_house" in f2 and not ("trips" in f2), "custos 2-2-2-4-4 deviam dar Casa Cheia, deu %s" % str(f2))
	var bq := _battle_with([], ["c001", "c003", "c007", "c186"], [], 3, 9)
	var f3 := bq.preview_attack().formation_ids
	_check("quads" in f3, "custos 1-1-1-1 deviam dar Quadra, deu %s" % str(f3))
	_check(bq.effects.has_formation("trips") and not bq.effects.has_formation("two_pair"), "a Quadra conta como Tríade nas condições das cartas")
	_check(EffectResolver._cost_formation([2, 2], 0) == "two_pair" and EffectResolver._cost_formation([3, 2], 0) == "full_house" and EffectResolver._cost_formation([2, 1], 1) == "trips" and EffectResolver._cost_formation([1, 1, 1], 0) == "", "hierarquia das formações de custo errada")

	# --- Relíquias que escalam ---
	GameState.new_run("deck01", 53)
	GameState.add_relic("relic_hungry_grimoire")
	var bgr := _battle_with(["c001", "c003", "c005"], ["c007"], ["c186", "c193", "c235"], 3, 6)
	bgr.discard(_find(bgr.deck.hand, "c001"))
	bgr.discard(_find(bgr.deck.hand, "c003"))
	_check(GameState.relic_counter("relic_hungry_grimoire") == 2, "Grimório Faminto devia contar 2 canalizações")
	var grs := bgr.preview_attack().steps.filter(func(st): return st.source_id == "relic_hungry_grimoire")
	_check(grs.size() == 1 and is_equal_approx(grs[0].value, 20.0), "Grimório Faminto devia dar +20 Poder com 2 canalizações")
	_check(GameState.relic_scaling_text("relic_hungry_grimoire").contains("20"), "a relíquia devia mostrar o valor atual")
	GameState.add_relic("relic_collector_prism")
	for i in 3:
		GameState.add_card("c001")
	var prs := bgr.preview_attack().steps.filter(func(st): return st.source_id == "relic_collector_prism")
	_check(prs.size() == 1 and is_equal_approx(prs[0].value, 1.3), "Prisma do Colecionador: ×1.3 com 3 cartas novas")
	GameState.add_relic("relic_scar_collection")
	bgr.lose_life(5)
	var scs := bgr.preview_attack().steps.filter(func(st): return st.source_id == "relic_scar_collection")
	_check(GameState.relic_counter("relic_scar_collection") == 5 and scs.size() == 1 and is_equal_approx(scs[0].value, 2.0), "Coleção de Cicatrizes: +2 Mult com 5 de vida perdida")
	GameState.add_relic("relic_victory_standard")
	GameState.bump_relic_counters("battle_won")
	_check(GameState.relic_counter("relic_victory_standard") == 1, "Estandarte das Vitórias devia contar a vitória")
	GameState.remove_relic("relic_victory_standard")
	_check(not GameState.relic_counters.has("relic_victory_standard"), "vender a relíquia devia apagar o contador")

	# --- Modo daltónico ---
	Settings.colorblind = true
	var pip := CardIcon.pip("red")
	_check(pip.mana_color == "red" and pip.custom_minimum_size.x >= 16.0, "modo daltónico: pip maior e com o símbolo da cor")
	pip.free()
	Settings.colorblind = false

	# --- Gravar/retomar v4 ---
	GameState.add_boss_relic("relic_glass_heart")
	GameState.set_contract("army")
	GameState.climates["1"] = "aether_tide"
	GameState.interlude_key = "1"
	GameState.death_save_used = true
	var counters := GameState.relic_counters.duplicate()
	GameState.save_run({}, "map")
	GameState.new_run("deck02", 1)
	_check(GameState.load_run(), "load_run v4 falhou")
	_check("relic_glass_heart" in GameState.boss_relics and String(GameState.contract.get("id", "")) == "army" and String(GameState.climates.get("1", "")) == "aether_tide", "relíquias de boss, contrato e climas deviam gravar")
	_check(GameState.interlude_key == "1" and GameState.death_save_used and GameState.relic_counters == counters, "interlúdio, Coração de Vidro e contadores das relíquias deviam gravar")
	GameState.clear_saved_run()
	# --- Atualização da app (Releases do GitHub) ---
	var rel := {"name": "Zero-Sum 0.10.0", "tag_name": "v0.10.0-b12", "body": "code=10\n\nZero-Sum 0.10.0\nNovo: coisas.",
		"assets": [{"name": "ZeroSum.apk", "browser_download_url": "https://github.com/DaewonPT/ArcanaRun/releases/download/v0.10.0-b12/ZeroSum.apk"}]}
	var up := AppUpdate.parse_release(rel)
	_check(int(up.get("code", 0)) == 10 and String(up.get("apk", "")).ends_with("ZeroSum.apk") and String(up.get("notes", "")).contains("Novo") and String(up.get("name", "")) == "Zero-Sum 0.10.0", "AppUpdate devia ler versionCode, APK, nome e notas da Release")
	rel["assets"][0]["browser_download_url"] = "https://example.com/ZeroSum.apk"
	_check(AppUpdate.parse_release(rel).is_empty(), "AppUpdate só aceita APKs do repositório do jogo")
	_check(AppUpdate.parse_release({"body": "sem código", "assets": []}).is_empty(), "sem code= não há atualização")
	print("  0.9.0: climas, bosses em 2 fases, relíquias de boss, contratos, elites, maldições, formações de póquer, relíquias que escalam, gravação v4 OK")

func _test_scenes_090() -> void:
	Settings.anim_speed = "instant"
	# Baú de Espólio: 3 relíquias de boss; escolher uma dá-a e segue para o mapa.
	GameState.new_run("deck01", 60)
	GameState.ante = 4
	GameState.map_phase = "stop"
	GameState.prepare_loot()
	var loot = load("res://scenes/loot/Loot.tscn").instantiate()
	add_child(loot)
	await get_tree().process_frame
	var cards_box: HBoxContainer = loot.get("_cards")
	_check(cards_box != null and cards_box.get_child_count() == 3, "o Baú devia mostrar 3 relíquias")
	var pick_id := GameState.loot_offer[0]
	SceneRouter._busy = true   # go() não troca de cena durante o teste
	loot._on_pick(pick_id)
	await get_tree().create_timer(0.2).timeout
	SceneRouter._busy = false
	_check(pick_id in GameState.boss_relics and GameState.loot_offer.is_empty(), "escolher no Baú devia dar a relíquia de boss")
	_check(GameState.load_run() and GameState.saved_scene == "map" and pick_id in GameState.boss_relics, "depois do Baú a run devia ficar gravada no mapa")
	loot.queue_free()
	await get_tree().process_frame
	# Tribunal dos Deuses: paga, gira a roda (instantânea) e aplica o resultado.
	GameState.new_run("deck01", 61)
	GameState.add_gold(20)
	GameState.pending_event = "node_tribunal"
	var trib = load("res://scenes/event/Event.tscn").instantiate()
	add_child(trib)
	await get_tree().process_frame
	var spins0 := Stats.get_stat("tribunal_spins")
	var lines: Array[String] = []
	await trib._gamble({"gamble": "gold", "cost": 8}, lines)
	_check(Stats.get_stat("tribunal_spins") == spins0 + 1 and lines.size() >= 3 and GameState.pending_event == "", "o Tribunal devia cobrar, girar a roda e aplicar o resultado")
	trib.queue_free()
	SceneRouter.close_overlays()
	await get_tree().process_frame
	# Batalha 0.9.0: chips de clima e contrato, relíquia de boss na barra, marca de metade, intenção em ícones,
	# detalhe da cascata e despertar do boss.
	GameState.new_run("deck05", 62)
	GameState.ante = 4
	GameState.climates["2"] = "blood_moon"
	GameState.set_contract("swift")
	GameState.add_boss_relic("relic_abyss_chalice")
	GameState.choose_battle("boss")
	var bs = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(bs)
	EventBus.battle_ended.disconnect(bs._on_battle_ended)
	await get_tree().process_frame
	await get_tree().process_frame
	var bmb: BattleManager = bs.get_node("BattleManager")
	_check(bmb.climate == "blood_moon" and bs._climate_chip != null and bs._contract_chip != null, "a batalha devia mostrar os chips de clima e de contrato")
	_check(bs._relic_views.has("relic_abyss_chalice"), "as relíquias de boss deviam aparecer na barra de cima")
	_check(bs._hp_marker != null and bs._intent_row.get_child_count() >= 1, "boss: marca de metade da vida e intenção em ícones")
	for i in 3:
		var hand_box: Container = bs.get_node("%Hand")
		for v in hand_box.get_children():
			if v is CardView and bmb.can_play(v.card) and not v.card.data.is_land():
				v.pressed.emit(v.card)
				break
		await get_tree().process_frame
	bs._open_breakdown()
	_check(SceneRouter.top_overlay() is CascadeBreakdown or bmb.preview_attack().is_empty(), "tocar no cálculo devia abrir o detalhe da cascata")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	bmb.damage_enemy(int(bmb.enemy.hp * 0.7))
	var t0 := bmb.turn
	bs._on_end_turn()
	var started := Time.get_ticks_msec()
	while bmb.turn == t0 and not bmb.finished and Time.get_ticks_msec() - started < 8000:
		await get_tree().process_frame
	_check(bmb.phase2 or bmb.finished, "o boss devia despertar abaixo de metade da vida")
	bs.queue_free()
	await get_tree().process_frame
	SceneRouter.close_overlays()
	GameState.clear_saved_run()
	Settings.anim_speed = "normal"
	print("  0.9.0: Baú de Espólio, Tribunal, chips, marca do boss, intenção, detalhe da cascata e despertar OK")

## Procura, na árvore de `root`, um nó que cumpra `pred` (para as cenas montadas em código).
func _find_node(root: Node, pred: Callable) -> Node:
	if root == null:
		return null
	if pred.call(root):
		return root
	for c in root.get_children():
		var hit := _find_node(c, pred)
		if hit != null:
			return hit
	return null

func _has_text(root: Node, prefix: String) -> bool:
	return _find_node(root, func(n: Node): return (n is Label or n is Button) and String(n.get("text")).begins_with(prefix)) != null

func _wait_until(cond: Callable, timeout_ms: int = 8000) -> bool:
	var t0 := Time.get_ticks_msec()
	while not cond.call() and Time.get_ticks_msec() - t0 < timeout_ms:
		await get_tree().process_frame
	return cond.call()

## 0.10.0 (cenas): Novidades, Configurações por separadores, exportar/importar, escala e bateria,
## História, Desafios, menu, Némesis no mapa, janela de Reação, Treino (Reforço, aviso e resultado)
## e resumo do fim da run.
func _test_scenes_0100() -> void:
	var old_lang := Settings.language
	Settings.language = "pt"   # os textos procurados abaixo estão em português
	Settings.anim_speed = "instant"
	Settings.apply()
	var saved_progress: Dictionary = GameState.progress.duplicate(true)
	# --- Novidades: abrem uma vez depois de atualizar ---
	GameState.progress["news_seen"] = ""
	NewsOverlay.maybe_show()
	await get_tree().process_frame
	var nv := String(NewsOverlay.current().get("version", ""))
	_check(nv == "0.10.0", "as Novidades deviam ser da 0.10.0 (são %s)" % nv)
	_check(SceneRouter.top_overlay() is NewsOverlay and String(GameState.progress.get("news_seen", "")) == nv, "as Novidades deviam abrir na 1.ª vez depois de atualizar")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	NewsOverlay.maybe_show()
	await get_tree().process_frame
	_check(not SceneRouter.has_overlay(), "as Novidades não deviam abrir outra vez")
	# --- Configurações: 4 separadores, exportar e importar ---
	var sm := SettingsMenu.open()
	await get_tree().process_frame
	for i in SettingsMenu.TABS.size():
		sm._show_tab(i)
		await get_tree().process_frame
		_check(sm._content.get_child_count() >= 2, "o separador %s devia ter opções" % SettingsMenu.TABS[i])
	GameState.progress["export_probe"] = 7
	var code := Settings.export_code()
	GameState.progress.erase("export_probe")
	_check(code.begins_with("ZS1:") and not Settings.parse_code(code).is_empty(), "o código exportado devia ler-se")
	var broken := code.substr(0, code.length() - 1) + ("1" if code.ends_with("0") else "0")
	_check(Settings.parse_code(broken).is_empty() and Settings.parse_code("ZS1:nada").is_empty(), "um código adulterado devia ser recusado")
	sm._on_import_open()
	var import_btn := Button.new()
	sm._import_edit.text = "ZS1:nada"
	sm._on_import(import_btn)
	_check(sm._import_note.text.begins_with("Código inválido"), "importar um código inválido devia avisar")
	sm._import_edit.text = code
	sm._on_import(import_btn)
	_check(sm._import_note.text.begins_with("Código válido") and not GameState.progress.has("export_probe"), "o 1.º toque em IMPORTAR devia só validar")
	SceneRouter._busy = true   # import → go("main") não troca de cena durante o teste
	sm._on_import(import_btn)
	SceneRouter._busy = false
	_check(int(GameState.progress.get("export_probe", 0)) == 7, "o 2.º toque devia importar o progresso")
	GameState.progress.erase("export_probe")
	import_btn.free()
	SceneRouter.close_overlays()
	await get_tree().process_frame
	# Escala, movimento reduzido e bateria.
	var old_fps := Settings.fps_cap
	var old_scale := Settings.ui_scale
	Settings.fps_cap = 30
	Settings.reduce_motion = true
	Settings.ui_scale = 1.2
	Settings.apply()
	_check(Engine.max_fps == 30 and not Settings.motion_ok(), "30 FPS e reduzir movimento deviam aplicar-se")
	_check(Settings.effective_scale() >= 1.0 and Settings.effective_scale() <= 1.2, "a escala efetiva devia ficar entre 100 e 120 %")
	Settings.fps_cap = old_fps
	Settings.reduce_motion = false
	Settings.ui_scale = old_scale
	Settings.apply()
	# --- História, Desafios e menu ---
	var saga = load("res://scenes/saga/Saga.tscn").instantiate()
	add_child(saga)
	await get_tree().process_frame
	_check(saga._detail.get_child_count() == 1 and _has_text(saga, "Regra: "), "a História devia mostrar o capítulo e a regra")
	saga.queue_free()
	var chs = load("res://scenes/challenges/Challenges.tscn").instantiate()
	add_child(chs)
	await get_tree().process_frame
	var grid := _find_node(chs, func(n: Node): return n is GridContainer) as GridContainer
	_check(grid != null and grid.get_child_count() == CardDB.challenges.size() and CardDB.challenges.size() == 8, "os Desafios deviam mostrar 8 desafios")
	chs.queue_free()
	# Menu em páginas: início (Continuar, Novo Jogo, Modos ›, Coleção ›), Modos de jogo e Coleção.
	GameState.new_run("deck05", 808)
	GameState.ante = 3
	GameState.save_run({}, "map")
	var menu = load("res://scenes/main/Main.tscn").instantiate()
	add_child(menu)
	await get_tree().process_frame
	_check(menu.current_page() == "main" and menu.get_node("%Continue").visible and _has_text(menu.get_node("%Continue"), "Falange Solar  ·  Ante 3"), "o início devia mostrar CONTINUAR com o baralho e o ante")
	_check(not menu.get_node("%Saga").is_visible_in_tree(), "os modos não deviam estar no início")
	menu.get_node("%Modes").pressed.emit()
	await get_tree().process_frame
	_check(menu.current_page() == "modes" and menu.get_node("%Saga").is_visible_in_tree() and menu.get_node("%Challenges").is_visible_in_tree() and menu.get_node("%Training").is_visible_in_tree() and menu.get_node("%FreeMode").is_visible_in_tree(), "MODOS DE JOGO devia mostrar História, Desafios, Livre e Treino")
	_check(_has_text(menu.get_node("%Saga"), "0/5") and _has_text(menu.get_node("%Challenges"), "0/8"), "os modos deviam mostrar o progresso (capítulos e medalhas)")
	menu._notification(NOTIFICATION_WM_GO_BACK_REQUEST)
	_check(menu.current_page() == "main", "o retroceder numa página devia voltar ao início")
	menu.get_node("%CollectionPage").pressed.emit()
	await get_tree().process_frame
	_check(menu.current_page() == "collection" and menu.get_node("%Builder").is_visible_in_tree() and menu.get_node("%Stats").is_visible_in_tree(), "COLEÇÃO devia mostrar as cartas, o construtor e as estatísticas")
	SceneRouter._busy = true   # go() não troca de cena durante o teste
	menu.get_node("%Stats").pressed.emit()
	SceneRouter._busy = false
	_check(MainMenu.return_page == "collection", "quem sai da Coleção devia voltar a essa página")
	menu.queue_free()
	await get_tree().process_frame
	menu = load("res://scenes/main/Main.tscn").instantiate()
	add_child(menu)
	await get_tree().process_frame
	_check(menu.current_page() == "collection" and MainMenu.return_page == "main", "o menu devia reabrir na página de onde se saiu")
	menu._show_page("main", false)
	GameState.clear_saved_run()
	var news_btn := _find_node(menu, func(n: Node): return n is Button and n.text == "NOVIDADES") as Button
	_check(news_btn != null and not SceneRouter.has_overlay(), "o menu devia ter o botão NOVIDADES (sem abrir sozinho)")
	if news_btn != null:
		news_btn.pressed.emit()
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() is NewsOverlay, "NOVIDADES devia abrir as notas da versão")
	SceneRouter.close_overlays()
	menu.queue_free()
	await get_tree().process_frame
	# --- Némesis no mapa (ante 3, no lugar da Elite) ---
	GameState.free_mode = false
	GameState.new_run("deck01", 31337)
	GameState.ante = 3
	GameState.map_phase = "battle"
	var mp = load("res://scenes/map/Map.tscn").instantiate()
	add_child(mp)
	await get_tree().process_frame
	_check(_has_text(mp, "Némesis · nível"), "o mapa devia mostrar o nó da Némesis no ante 3")
	mp.queue_free()
	await get_tree().process_frame
	# --- Janela de Reação na batalha ---
	GameState.new_run("deck01", 70)
	GameState.choose_battle("scout")
	var rb = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(rb)
	EventBus.battle_ended.disconnect(rb._on_battle_ended)
	await get_tree().process_frame
	await get_tree().process_frame
	var rbm: BattleManager = rb.get_node("BattleManager")
	var faith := CardDB.new_instance("c345")
	var guide := CardDB.new_instance("c001")
	for extra in [guide, faith]:
		extra.zone = CardInstance.Zone.HAND
		rbm.deck.hand.append(extra)
	rbm.mana_available = 1
	rb._refresh_all()
	var hp_r := GameState.player_hp
	var reactions0 := Stats.get_stat("reactions")
	# Aviso opcional: atacar com mana por gastar e uma carta que aumentava o ataque.
	Settings.warn_mana = true
	rb._on_end_turn()
	await get_tree().process_frame
	_check(rb._alive(rb._modal) and _has_text(rb._modal, "Atacar sem gastar a mana?"), "devia avisar antes de atacar com mana e cartas por jogar")
	rb._close_modal("never")
	_check(not Settings.warn_mana, "NÃO AVISAR MAIS devia desligar o aviso")
	var opened: bool = await _wait_until(func(): return rb._alive(rb._modal) and bool(rb._modal.get_meta("reaction", false)))
	_check(opened and _has_text(rb._modal, "NÃO REAGIR"), "devia abrir a janela de Reação antes do contra-ataque")
	if opened:
		rb._close_modal(faith)
		await _wait_until(func(): return rbm.turn >= 2 or rbm.finished)
	_check(GameState.player_hp == hp_r and Stats.get_stat("reactions") == reactions0 + 1, "reagir com o Escudo da Fé devia anular o contra-ataque")
	rb.queue_free()
	await get_tree().process_frame
	SceneRouter.close_overlays()
	# --- Treino: escolher a mão, Reforço, aviso de mana e resultado ---
	GameState.training = {}
	var trn = load("res://scenes/training/Training.tscn").instantiate()
	add_child(trn)
	await get_tree().process_frame
	_check(trn._grid.get_child_count() > 100, "o Treino devia listar as cartas")
	trn._hand.append_array(["c001", "c003", "c339"])
	trn._relics.append("relic_drum")
	trn._mana = 7
	trn._refresh_top()
	_check(trn._hand_row.get_child_count() == 3, "a mão do Treino devia mostrar 3 cartas")
	trn._relic_mode = true
	trn._refresh_list()
	_check(trn._grid.get_child_count() >= 20, "o Treino devia listar as relíquias")
	SceneRouter._busy = true
	trn._start()
	SceneRouter._busy = false
	_check(GameState.puzzle_id == "training" and "relic_drum" in GameState.relic_ids, "TREINAR devia preparar a batalha de treino")
	trn.queue_free()
	await get_tree().process_frame
	var runs0 := Stats.get_stat("runs")
	var tb = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(tb)
	await get_tree().process_frame
	await get_tree().process_frame
	var tbm: BattleManager = tb.get_node("BattleManager")
	_check(tbm.puzzle and int(tbm.enemy.hp) == GameState.TRAINING_HP and tb.enemy_hp_label.text == "∞", "o boneco de treino devia ter vida infinita")
	var hand_box: Container = tb.get_node("%Hand")
	for v in hand_box.get_children():
		if v is CardView and v.card.data.id == "c001":
			v.pressed.emit(v.card)
	await get_tree().process_frame
	var fire: CardInstance = null
	for v in hand_box.get_children():
		if v is CardView and v.card.data.id == "c339":
			fire = v.card
			v.pressed.emit(v.card)
	await get_tree().process_frame
	_check(fire != null and tb._alive(tb._modal) and _has_text(tb._modal, "COM REFORÇO"), "a Bola de Fogo devia perguntar se vai com Reforço")
	tb._close_modal("kick")
	await get_tree().process_frame
	_check(fire != null and fire.kicked and fire in tbm.spells_this_turn and tbm.mana_available == 3, "escolher COM REFORÇO devia jogar a carta com Reforço: 7 − 1 − (1 + 2) = 3 de mana (há %d)" % tbm.mana_available)
	tb._on_end_turn()   # no Treino (e nos enigmas) não há aviso de mana por gastar
	var result_open: bool = await _wait_until(func(): return tb._alive(tb._modal) and _has_text(tb._modal, "REPETIR"))
	_check(result_open and tbm.best_hit > 0 and _has_text(tb._modal, "Dano do ataque: "), "o Treino devia acabar com o dano e REPETIR / EDITAR / SAIR")
	_check(Stats.get_stat("runs") == runs0, "o Treino não devia contar como run")
	tb.queue_free()
	await get_tree().process_frame
	GameState.puzzle_id = ""
	Settings.warn_mana = false
	# --- Resumo do fim da run (capítulo da História vencido) ---
	GameState.new_saga_run("saga_white", 21)
	GameState.ante = GameState.max_ante
	GameState.last_victory = true
	GameState.run_log = {"damage_by_ante": {"1": 4000, "2": 9000, "3": 30000, "4": 120000}, "card_dmg": {"c001": 50000, "c315": 20000}, "relic_dmg": {"relic_drum": 8000}, "best_hit": 90000}
	var ro = load("res://scenes/ui/RunOver.tscn").instantiate()
	add_child(ro)
	await get_tree().process_frame
	_check(_find_node(ro, func(n: Node): return n is CardView and n.card != null and n.card.data.id == "c001") != null, "o resumo devia mostrar a carta MVP")
	_check(_find_node(ro, func(n: Node): return n is DamageChart) != null and _has_text(ro, "Maior golpe: "), "o resumo devia ter o maior golpe e o gráfico por ante")
	_check((ro.get_node("%Campaign") as Button).text == "HISTÓRIA" and GameState.saga_done("saga_white"), "vencer o capítulo devia voltar à História e marcá-lo como feito")
	ro.queue_free()
	await get_tree().process_frame
	GameState.progress = saved_progress
	Stats._ensure()
	GameState.save_progress()
	GameState.clear_saved_run()
	Settings.anim_speed = "normal"
	Settings.language = old_lang
	Settings.apply()
	Settings.save_settings()
	print("  0.10.0: Novidades, separadores, exportar/importar, História, Desafios, menu, Némesis no mapa, Reação, Treino, Reforço, aviso e resumo OK")

const TEST_MANIFEST := "ZSUPD 1\nc 2\nmin 7\nn pt teste de assinatura\nf 015abd7f5cc57a2dd94b7590f04ad8084273905ee33ec5cebeae62276a97f862 7 data/teste.json\nsig MEUCIQCyx0L5sEplwno3v9GYj3yCR4GUQ+/SYSQZttAG8MBlrQIgcv0b2d+Wu7N+Dy4/L5dvlm+26ydRW0UFbNWuyFfm0IM=\n"

## 0.10.0: Fichas, tribos, Cadeias, conjuntos de selos, encantamentos, Reforço, Reação, lacaios,
## escudo, Míticas, cartas "+", Vales, Desafios, História, Némesis, desbloqueios e resumo da run.
func _test_0100() -> void:
	var saved_progress: Dictionary = GameState.progress.duplicate(true)
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	Stats._ensure()
	GameState.new_run("deck05", 4242)
	GameState.relic_ids.clear()
	GameState.player_max_hp = 20
	GameState.player_hp = 20
	# --- Fichas ---
	var bt := _battle_with(["c315", "c316"], [], [], 3, 8)
	_check(bt.play(_find(bt.deck.hand, "c315")), "Chamada da Milícia devia jogar-se")
	_check(bt.board.size() == 2 and bt.board[0].data.token and bt.board[0].power() == 10, "devia criar 2 Fichas de 10 Poder")
	bt.play(_find(bt.deck.hand, "c316"))
	_check(bt.board.size() == 4, "Capitã + 1 Ficha: 4 na Arena (há %d)" % bt.board.size())
	var ct := bt.preview_attack()
	_check(ct.steps.any(func(st): return st.source_kind == "tribe"), "3 Fichas e a Capitã deviam ativar o bónus de Soldados")
	_check(not ("pair" in ct.formation_ids) and not ("trips" in ct.formation_ids), "as Fichas (custo 0) não deviam fazer pactos")
	_check("band" in ct.formation_ids, "as Fichas deviam contar para o Bando")
	var tok: CardInstance = bt.board[0]
	bt.kill_creature(tok)
	_check(not (tok in bt.deck.graveyard) and bt.board.size() == 3, "a Ficha devia desaparecer ao morrer")
	var bt2 := BattleManager.new()
	bt2.restore(bt.to_dict())
	_check(bt2.board.size() == 3 and bt2.board[0].data.token, "as Fichas deviam sobreviver a gravar e retomar")
	bt.free()
	bt2.free()
	# --- Cadeia de cor (3 vermelhas seguidas: ×1.5) ---
	GameState.new_run("deck01", 77)
	GameState.relic_ids.clear()
	var reds: Array = []
	for e in GameState.deck:
		var cd := CardDB.get_card(String(e["id"]))
		if cd.is_creature() and cd.has_color("red") and not (cd.id in reds):
			reds.append(cd.id)
	var bc := _battle_with([], reds.slice(0, 3), [], 3, 6)
	var cc := bc.preview_attack()
	var chain: Array = cc.steps.filter(func(st): return st.source_kind == "chain")
	_check(chain.size() == 1 and is_equal_approx(chain[0].value, 1.5) and cc.chain_len == 3, "3 vermelhas seguidas deviam dar ×1.5 (cadeia %d)" % cc.chain_len)
	bc.free()
	# --- Conjunto de selos (3× Dízimo: +8 ouro) ---
	var sealed: Array = []
	for i in GameState.deck.size():
		var cd := CardDB.get_card(String(GameState.deck[i]["id"]))
		if cd.is_creature() and sealed.size() < 3 and not (cd.id in sealed):
			GameState.deck[i]["seal"] = "tithe"
			sealed.append(cd.id)
	var bs := _battle_with([], sealed.duplicate(), [], 3, 6)
	var cs := bs.preview_attack()
	_check(cs.steps.any(func(st): return st.source_kind == "seal_set") and cs.gold >= 8, "3 cartas com o Selo do Dízimo deviam dar +8 ouro")
	bs.free()
	for e in GameState.deck:
		e.erase("seal")
	# --- Reforço ---
	var bk := _battle_with(["c339"], [], [], 3, 6)
	var fb := _find(bk.deck.hand, "c339")
	_check(bk.can_kick(fb) and bk.preview_play(fb, true) > bk.preview_play(fb), "Bola de Fogo com Reforço devia prever mais dano")
	_check(bk.play(fb, true) and fb.kicked and bk.mana_available == 3, "o Reforço devia custar 1 + 2 de mana (sobram %d)" % bk.mana_available)
	var ck := bk.preview_attack()
	var mult_steps: Array = ck.steps.filter(func(st): return st.action == "mult_add" and st.source_card == fb)
	_check(mult_steps.size() == 2, "com Reforço a Bola de Fogo devia dar +4 e +4 Mult (%d passos)" % mult_steps.size())
	bk.free()
	# --- Encantamentos (máx. 2; entram na cascata; turn_start) ---
	var be := _battle_with(["c331", "c335", "c332"], ["c001"], [], 3, 10)
	_check(be.play(_find(be.deck.hand, "c331")) and be.play(_find(be.deck.hand, "c335")), "2 encantamentos deviam jogar-se")
	_check(be.enchantments.size() == 2 and not be.can_play(_find(be.deck.hand, "c332")), "máximo de 2 encantamentos em jogo")
	_check(be.preview_attack().steps.any(func(st): return st.source_kind == "enchantment"), "os encantamentos deviam entrar na cascata")
	var weak: CardInstance = be.board[0]
	var p0 := weak.power()
	be.next_turn()
	_check(weak.power() == p0 + 8, "o Bosque Ancestral devia fazer crescer a criatura mais fraca (+8)")
	var be2 := BattleManager.new()
	be2.restore(be.to_dict())
	_check(be2.enchantments.size() == 2, "os encantamentos deviam sobreviver a gravar e retomar")
	be.free()
	be2.free()
	# --- Reação (janela antes do contra-ataque) ---
	var br := _battle_with(["c345"], ["c001"], [], 3, 6, 3)
	var hp0 := GameState.player_hp
	var shield := _find(br.deck.hand, "c345")
	_check(br.can_react(shield), "Escudo da Fé devia poder reagir")
	var react := func(opts: Array): EventBus.reaction_done.emit.call_deferred(opts[0])
	EventBus.reaction_window.connect(react)
	br.end_turn()
	for i in 4:
		await get_tree().process_frame
	EventBus.reaction_window.disconnect(react)
	_check(br.turn == 2 and GameState.player_hp == hp0 and br.board[0].damage == 0, "a Reação devia anular o contra-ataque")
	_check(Stats.get_stat("reactions") >= 1, "a Reação devia contar nas estatísticas")
	br.free()
	# --- Lacaios e escudo ---
	var bl := _battle_with([], ["c001", "c003"], [], 3, 6)
	bl.minions.append(2)
	var cl := bl.preview_attack()
	_check(cl.steps[0].tag == "minion" and is_zero_approx(cl.steps[0].value), "o lacaio devia travar o Poder da 1.ª criatura")
	bl.enemy["shield_pct"] = 10.0
	var csh := bl.preview_attack()
	_check(csh.shield == 100000, "escudo de 10%% devia travar 100 000 (travou %d)" % csh.shield)
	_check(csh.net_total() == maxi(0, csh.total() - csh.shield), "o dano líquido devia descontar o escudo")
	bl.enemy["shield_pct"] = 0.0
	bl._apply_cascade(bl.preview_attack())
	_check(bl.minions.size() == 1 and bl.minions[0] == 1, "o lacaio devia gastar um golpe")
	_check(not GameState.run_log.is_empty() and int(GameState.run_log["damage_by_ante"].get(str(GameState.ante), 0)) > 0, "o resumo da run devia registar o dano")
	bl.free()
	# --- Míticas ---
	var bmy := _battle_with([], ["c350", "c001", "c003"], [], 3, 6)
	var cmy := bmy.preview_attack()
	var fsteps: Array = cmy.steps.filter(func(st): return st.source_kind == "formation")
	_check(fsteps.size() == cmy.formation_ids.size() * 2 and fsteps.size() > 0, "o Avatar da Convergência devia ativar as formações duas vezes")
	bmy.free()
	var bmm := _battle_with([], ["c355", "c001"], [], 3, 6)
	var cmm := bmm.preview_attack()
	_check(cmm.steps[cmm.steps.size() - 1].source_kind == "rule" and is_equal_approx(cmm.steps[cmm.steps.size() - 1].value, 1.5), "o Motor do Infinito devia fechar a cascata com ×1.5")
	bmm.free()
	_check(not CardDB.is_available(CardDB.get_card("c350")), "as Míticas deviam estar bloqueadas no início")
	# --- Cartas "+" ---
	var fplus := CardDB.get_card("c339").plus_version()
	_check(fplus.plus and is_equal_approx(float(fplus.effects[0]["value"]), 6.0), "Bola de Fogo+ devia dar +6 Mult")
	_check(fplus.display_text().begins_with("+6 Mult"), "o texto da versão + devia mostrar os números novos (%s)" % fplus.display_text())
	_check(GameState.forge_plus(0) and CardDB.new_instance(String(GameState.deck[0]["id"]), GameState.deck[0]).data.plus, "Forjar devia criar a versão + da carta")
	# --- Vales ---
	GameState.gold = 60
	var vid := GameState.shop_voucher_offer()
	_check(vid != "" and GameState.buy_voucher(vid) and vid in GameState.vouchers, "devia comprar o Vale à venda")
	GameState.vouchers.clear()
	GameState.vouchers.append_array(["v_hand", "v_relic", "v_channel", "v_reward"])
	_check(GameState.hand_size_for_battle() == 7 and GameState.max_relics() == 6 and GameState.discards_for_battle() == 4, "os Vales deviam dar +1 mão, +1 relíquia e +1 canalização")
	GameState.vouchers.clear()
	# --- Desafios ---
	GameState.new_challenge_run("ch_glass", 9)
	_check(GameState.mode == "challenge" and GameState.player_max_hp == 8, "Vidro devia começar com 8 de vida")
	GameState.new_challenge_run("ch_clock", 9)
	_check(GameState.turns_for_ante(1) == 4, "Contra o Relógio devia ter 4 turnos")
	GameState.new_challenge_run("ch_boss_rush", 9)
	_check(GameState.is_boss_ante(2) and GameState.is_boss_ante(6) and not GameState.is_boss_ante(3), "Maratona de Bosses: boss de 2 em 2")
	GameState.new_challenge_run("ch_no_relics", 9)
	_check(not GameState.add_relic("relic_drum"), "Mãos Vazias: não devia aceitar relíquias")
	GameState.new_challenge_run("ch_no_channel", 9)
	_check(GameState.discards_for_battle() == 0, "Mãos Atadas: 0 canalizações")
	GameState.new_challenge_run("ch_poverty", 9)
	_check(GameState.battle_reward(3) == 0, "Voto de Pobreza: as batalhas não dão ouro")
	GameState.new_challenge_run("ch_small", 9)
	_check(CardDB.shop_pool().all(func(cd): return cd.cost <= 2), "Só Miúdos: a loja só devia ter custo 2 ou menos")
	var bsm := BattleManager.new()
	GameState.ante = 1
	GameState.map_choice = {"battle": "scout"}
	bsm.start(GameState.pick_enemy(1))
	var big: CardInstance = null
	for cc2 in bsm.deck.library + bsm.deck.hand:
		if cc2.data.cost >= 3 and not cc2.data.is_land():
			big = cc2
	if big != null:
		bsm.deck.library.erase(big)
		bsm.deck.hand.erase(big)
		big.zone = CardInstance.Zone.HAND
		bsm.deck.hand.append(big)
		bsm.mana_available = 10
		_check(not bsm.can_play(big), "Só Miúdos: cartas de custo 3+ não deviam jogar-se")
	bsm.free()
	GameState.record_run_end(9, true)
	_check(GameState.challenge_done("ch_small") and Stats.get_stat("challenges_won") == 1 and Stats.is_content_unlocked("frame", "neon"), "vencer um Desafio devia dar medalha e a moldura Néon")
	# --- História ---
	GameState.new_saga_run("saga_white", 11)
	_check(GameState.mode == "saga" and GameState.max_ante == 4 and "c315" in GameState.deck_ids(), "o capítulo branco devia ter 4 antes e as cartas extra")
	GameState.ante = 4
	GameState.map_choice = {"battle": "boss"}
	var sb := GameState.pick_enemy(4)
	_check(String(sb.get("id", "")) == "saga_boss_white", "o boss do capítulo devia ser o Lorde Cinzento (veio %s)" % sb.get("id", ""))
	var bsg := BattleManager.new()
	bsg.start(sb)
	_check(bsg.board.size() == 2 and bsg.board[0].data.token, "a regra do capítulo branco devia pôr 2 Fichas na Arena")
	_check(bsg.max_creatures() == 4, "a regra do boss do capítulo devia deixar só 4 lugares")
	bsg.free()
	_check(not GameState.saga_unlocked(1), "o 2.º capítulo devia estar fechado")
	var wins_before := Stats.get_stat("wins")
	GameState.record_run_end(4, true)
	_check(GameState.saga_done("saga_white") and GameState.saga_unlocked(1) and Stats.is_content_unlocked("back", "dawn"), "acabar o capítulo devia abrir o seguinte e dar as costas Aurora")
	_check(Stats.get_stat("wins") == wins_before, "os capítulos da História não deviam contar como runs vencidas")
	GameState.new_saga_run("saga_blue", 12)
	var bfree := _battle_with(["c340", "c339"], [], [], 3, 3)
	bfree.rule["first_spell_free"] = true
	_check(bfree.effects.cost_of(_find(bfree.deck.hand, "c340")) == 0, "capítulo azul: o 1.º feitiço do turno devia ser grátis")
	bfree.free()
	# --- Némesis ---
	GameState.free_mode = false
	GameState.new_run("deck01", 31337)
	_check(GameState.nemesis_id != "" and GameState.nemesis_def().get("color", "") != "red", "a Némesis devia ser de uma cor fora do baralho")
	_check("nemesis" in GameState.map_options(3)["battle"] and not ("nemesis" in GameState.map_options(4)["battle"]), "a Némesis devia aparecer no ante 3 (no lugar da Elite)")
	GameState.ante = 5
	GameState.map_choice = {"battle": "nemesis"}
	var nd := GameState.pick_enemy(5)
	_check(String(nd.get("variant", "")) == "nemesis" and int(nd.get("nemesis_level", 0)) == 2 and float(nd.get("shield_pct", 0)) > 0.0, "a Némesis do ante 5 devia ser nível 2 com escudo")
	var bn := BattleManager.new()
	bn.start(nd)
	var g0 := GameState.gold
	GameState.after_battle(bn, true)
	_check(GameState.gold >= g0 + 12 and Stats.get_stat("nemesis_wins") == 1 and CardDB.is_available(CardDB.get_card("c356")), "vencer a Némesis devia dar ouro e desbloquear o Lich da Eternidade")
	bn.free()
	# --- Medalhas e sinergias ---
	GameState.progress["stakes"] = {"deck01": 5, "deck02": 8}
	_check(GameState.medal_for("deck01") == "silver" and GameState.medal_for("deck02") == "gold" and GameState.medal_for("deck03") == "", "medalhas por Selo Planar vencido")
	GameState.new_run("deck05", 3)
	_check(CardDB.synergy_reason(CardDB.get_card("c318")).begins_with("Tribo"), "o Estandarte da Legião devia combinar com os Soldados do baralho")
	_check(CardDB.collectible_cards().all(func(cd): return not cd.token), "a Ficha não devia aparecer na coleção")
	GameState.progress = saved_progress
	Stats._ensure()
	GameState.save_progress()
	GameState.free_mode = false
	GameState.clear_saved_run()
	print("  0.10.0: Fichas, tribos, cadeias, selos, encantamentos, reforço, reação, lacaios, escudo, míticas, +, vales, desafios, história e némesis OK")

func _test_content_update() -> void:
	var m := ContentUpdate.parse_manifest(TEST_MANIFEST)
	_check(not m.is_empty() and int(m["c"]) == 2 and (m["files"] as Array).size() == 1, "manifesto não foi lido")
	_check(ContentUpdate.verify(m), "assinatura válida devia passar")
	var tampered := ContentUpdate.parse_manifest(TEST_MANIFEST.replace("c 2", "c 3"))
	_check(not tampered.is_empty() and not ContentUpdate.verify(tampered), "manifesto adulterado devia falhar")
	var bad_path := ContentUpdate.parse_manifest(TEST_MANIFEST.replace("data/teste.json", "scripts/x.json"))
	_check(bad_path.is_empty(), "caminhos fora de data/ e i18n/ deviam ser recusados")
	_check(ContentUpdate.sha256_hex("{\"a\":1}".to_utf8_buffer()) == "015abd7f5cc57a2dd94b7590f04ad8084273905ee33ec5cebeae62276a97f862", "sha256 errado")
	_check(ContentUpdate.resolve("res://data/cards.json") == "res://data/cards.json", "sem conteúdo descarregado devia usar o APK")
	_check(ContentUpdate.installed_version() >= 1, "versão instalada devia ser pelo menos a do APK")
	# Conteúdo descarregado para uma versão anterior (ex.: o v2 da 0.8.0 num telemóvel que instalou a
	# 0.9.x) não pode passar à frente do que vem no APK.
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("user://content/data"))
	_write_text("user://content/data/formations.json", "[]")
	_write_text(ContentUpdate.VERSION_FILE, str(ContentUpdate.BUNDLED_CONTENT_VERSION - 1))
	_check(ContentUpdate.resolve("res://data/formations.json") == "res://data/formations.json", "conteúdo descarregado mais antigo do que o do APK devia ser ignorado")
	ContentUpdate.clear_if_stale()
	_check(not FileAccess.file_exists("user://content/data/formations.json") and not FileAccess.file_exists(ContentUpdate.VERSION_FILE), "conteúdo antigo devia ser apagado ao arrancar")
	_write_text("user://content/data/formations.json", "[]")
	_write_text(ContentUpdate.VERSION_FILE, str(ContentUpdate.BUNDLED_CONTENT_VERSION + 1))
	_check(ContentUpdate.resolve("res://data/formations.json") == "user://content/data/formations.json", "conteúdo descarregado mais novo do que o do APK devia ser usado")
	ContentUpdate.clear_if_stale()
	_check(FileAccess.file_exists("user://content/data/formations.json"), "conteúdo mais novo não devia ser apagado")
	ContentUpdate.clear_downloaded()
	_check(ContentUpdate.resolve("res://data/formations.json") == "res://data/formations.json", "depois de limpar devia voltar ao APK")
	print("  atualizações de conteúdo: manifesto, assinatura e conteúdo antigo ignorado OK")
	_test_release_metadata()

## A versão tem de bater certo em todo o lado: export_presets.cfg (o que o Android vê e o que a
## Release do GitHub anuncia), APP_VERSION_CODE (com que o jogo compara a Release — se ficar atrás,
## a app oferece-se a si própria como atualização), o menu, a tradução e notas_versao.txt.
func _test_release_metadata() -> void:
	var presets := FileAccess.get_file_as_string("res://export_presets.cfg")
	var code_m := RegEx.create_from_string("version/code=(\\d+)").search(presets)
	var name_m := RegEx.create_from_string("version/name=\"([^\"]+)\"").search(presets)
	_check(code_m != null and int(code_m.get_string(1)) == ContentUpdate.APP_VERSION_CODE, "version/code do export_presets.cfg tem de ser igual a ContentUpdate.APP_VERSION_CODE")
	if name_m == null:
		_check(false, "export_presets.cfg sem version/name")
		return
	var version := name_m.get_string(1)
	var label := "protótipo " + version
	_check(FileAccess.get_file_as_string("res://scenes/main/Main.tscn").contains("\"%s\"" % label), "o menu (Main.tscn) devia mostrar \"%s\"" % label)
	_check(FileAccess.get_file_as_string("res://i18n/en.json").contains("\"%s\"" % label), "falta a tradução de \"%s\" (tools/make_en_json.py)" % label)
	_check(FileAccess.get_file_as_string("res://notas_versao.txt").begins_with("Zero-Sum " + version), "notas_versao.txt devia começar por \"Zero-Sum %s\"" % version)
	print("  versão %s (code %d) igual em export_presets, ContentUpdate, menu, tradução e notas OK" % [version, ContentUpdate.APP_VERSION_CODE])

func _write_text(path: String, text: String) -> void:
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f:
		f.store_string(text)
		f.close()

func _test_stats_and_custom() -> void:
	GameState.reset_progress()
	Stats.set_tutorial_done(true)
	GameState.new_run("deck01", 5)
	_check(Stats.get_stat("runs") == 1, "runs devia contar 1")
	_check(Stats.is_seen("cards", "c001"), "as cartas do baralho jogado deviam ficar descobertas")
	var unlocked := [""]
	var cb := func(id: String): unlocked[0] = id
	EventBus.achievement_unlocked.connect(cb)
	EventBus.damage_dealt.emit("enemy", 150000)
	EventBus.achievement_unlocked.disconnect(cb)
	_check(Stats.get_stat("best_attack") == 150000 and Stats.is_unlocked("attack_100k") and unlocked[0] == "attack_100k", "conquista Cem Mil não desbloqueou")
	_check(not Stats.is_unlocked("attack_1m"), "Um Milhão não devia estar desbloqueada")
	# Infinito.
	_check(GameState.map_options(10)["battle"] == ["scout", "guard"] and GameState.map_options(12)["battle"] == ["boss"], "mapa no infinito errado")
	GameState.endless = true
	_check(GameState.enemy_hp_for_ante(9) > GameState.enemy_hp_for_ante(8), "a vida devia continuar a subir no infinito")
	_check(bool(GameState.pick_enemy(12).get("boss", false)), "ante 12 devia ter boss no infinito")
	GameState.endless = false
	# Baralhos personalizados.
	var custom := {"id": "custom_1", "num": 0, "name": "Teste", "custom": true, "cards": ["c001", "c001", "c002", "c003", "c004", "c005", "c006", "c007", "c008", "c009"], "colors": ["red"], "size": 10, "difficulty": 0, "mechanic": "x"}
	CardDB.custom_decks["custom_1"] = custom
	CardDB.save_custom_decks()
	CardDB.load_custom_decks()
	_check(CardDB.get_deck("custom_1").get("name", "") == "Teste", "baralho personalizado não gravou/carregou")
	GameState.free_mode = true
	GameState.new_run("custom_1", 3)
	_check(GameState.deck.size() == 10 and GameState.deck_colors() == ["red"], "run com baralho personalizado errada")
	var bm := BattleManager.new()
	bm.start(GameState.pick_enemy(1))
	_check(bm.deck.hand.size() > 0, "batalha com baralho personalizado não começou")
	_check(Stats.decks_played() == 1, "baralhos personalizados não deviam contar para 'baralhos jogados' (%d)" % Stats.decks_played())
	CardDB.custom_decks.erase("custom_1")
	CardDB.save_custom_decks()
	GameState.free_mode = false
	# Progresso de uma versão antiga (só por baralho) alimenta os contadores globais.
	GameState.progress = {"best_ante": {"deck01": 6, "deck03": 9}, "wins": {"deck03": 2}, "difficulty": "normal"}
	Stats._ensure()
	_check(Stats.get_stat("best_ante") == 9 and Stats.decks_played() == 2 and Stats.get_stat("wins") == 2 and Stats.get_stat("runs") == 2, "migração do progresso antigo errada")
	Stats._ensure()
	_check(Stats.get_stat("wins") == 2, "a migração não devia repetir-se")
	GameState.reset_progress()
	Stats.set_tutorial_done(true)
	print("  estatísticas, conquistas, infinito e baralhos personalizados OK")

func _test_new_scenes() -> void:
	# Tutorial na primeira batalha + canhoto + texto grande.
	Stats.set_tutorial_done(false)
	Settings.left_handed = true
	Settings.large_text = true
	GameState.new_run("deck01", 8)
	GameState.ante = 1
	var scene: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(scene)
	await get_tree().process_frame
	EventBus.battle_ended.disconnect(scene._on_battle_ended)
	var tut: TutorialOverlay = null
	for c in scene.get_children():
		if c is TutorialOverlay:
			tut = c
	_check(tut != null, "o tutorial devia abrir na primeira batalha")
	var middle: HBoxContainer = scene.get_node("Layout/Middle")
	_check(middle.get_child(middle.get_child_count() - 1).name == "LeftCol", "modo canhoto devia pôr os botões à direita")
	var hand_box: Container = scene.get_node("%Hand")
	if hand_box.get_child_count() > 0:
		var v: CardView = hand_box.get_child(0)
		_check(v.name_label.get_theme_font_size("font_size") == 16, "texto grande devia aumentar a fonte das cartas")
	if tut != null:
		tut.call("_finish")
		await get_tree().process_frame
		_check(Stats.tutorial_done(), "saltar o tutorial devia marcá-lo como feito")
	Settings.left_handed = false
	Settings.large_text = false
	scene.queue_free()
	await get_tree().process_frame
	# Ecrãs novos: estatísticas, coleção (3 separadores), construtor.
	for path in ["res://scenes/ui/StatsScreen.tscn", "res://scenes/ui/Collection.tscn", "res://scenes/builder/DeckBuilder.tscn"]:
		var s: Node = load(path).instantiate()
		add_child(s)
		await get_tree().process_frame
		if path.ends_with("Collection.tscn"):
			for tab in ["relics", "enemies", "cards"]:
				s.call("_select_tab", tab)
				await get_tree().process_frame
		if path.ends_with("DeckBuilder.tscn"):
			s.call("_add_card", "c001")
			s.call("_add_card", "c001")
			s.call("_add_card", "c001")
			_check((s.get("_cards") as Array).size() == 2, "o construtor devia limitar a 2 cópias")
			for i in range(2, 12):
				s.call("_add_card", "c%03d" % i)
			_check((s.get("_cards") as Array).size() == 12, "o construtor devia ter 12 cartas")
			s.call("_on_save")
			_check(CardDB.custom_decks.has("custom_1") and FileAccess.file_exists(CardDB.CUSTOM_DECKS_PATH), "guardar no construtor falhou")
			CardDB.custom_decks.erase("custom_1")
			CardDB.save_custom_decks()
		s.queue_free()
		await get_tree().process_frame
	GameState.reset_progress()
	Stats.set_tutorial_done(true)
	print("  tutorial, canhoto, texto grande, estatísticas, coleção e construtor OK")

# ---------------------------------------------------------------------------
# 0.8.0: mapa, Mercador Cego, nós (acampamento/fonte/altar), selar na loja, draft, quebra-cabeças.
# ---------------------------------------------------------------------------

func _test_scenes_080() -> void:
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	Stats.set_tutorial_done(true)
	# Mapa: fase de batalha do ante 1, escolher Guarda grava a escolha; fase de paragem.
	GameState.free_mode = false
	GameState.new_run("deck01", 77)
	GameState.map_options(1)
	var map_scene: Node = load("res://scenes/map/Map.tscn").instantiate()
	add_child(map_scene)
	await get_tree().process_frame
	_check(GameState.has_saved_run() and GameState.saved_scene == "battle" or GameState.has_saved_run(), "o mapa devia gravar a run")
	var cols: Array = map_scene.get("_columns")
	_check(cols.size() == 4, "o mapa do ato I devia ter 4 colunas (2 antes × batalha/paragem), tem %d" % cols.size())
	var guard_btn: Button = (cols[0]["buttons"] as Dictionary).get("guard")
	_check(guard_btn != null and not guard_btn.disabled, "o Guarda do ante 1 devia estar escolhível")
	var shop_btn: Button = (cols[1]["buttons"] as Dictionary).get("shop")
	_check(shop_btn != null and shop_btn.disabled, "a paragem do ante 1 ainda não devia estar escolhível")
	# 0.9.0: interlúdio do Ato I por cima do mapa (uma vez por ato).
	await get_tree().process_frame
	_check(SceneRouter.top_overlay() is ActInterlude and GameState.interlude_key == "1", "o mapa do ante 1 devia abrir o interlúdio do Ato I")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	_check(ActInterlude.open_if_new() == null, "o interlúdio do mesmo ato não devia repetir")
	SceneRouter._busy = true   # go() não troca de cena durante o teste
	map_scene.call("_on_pick", 1, "battle", "guard")
	SceneRouter._busy = false
	_check(GameState.map_choice.get("battle", "") == "guard", "escolher Guarda no mapa não registou")
	map_scene.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# A batalha usa a escolha (Guarda = +25 % de vida) e no fim vai para o mapa em fase de paragem.
	GameState.map_phase = "stop"
	GameState.map_choice["stop"] = ""
	var map2: Node = load("res://scenes/map/Map.tscn").instantiate()
	add_child(map2)
	await get_tree().process_frame
	var cols2: Array = map2.get("_columns")
	var stop_buttons: Dictionary = cols2[1]["buttons"]
	_check(not (stop_buttons["shop"] as Button).disabled and (cols2[0]["buttons"]["guard"] as Button).disabled, "na fase de paragem só as paragens deviam estar ativas")
	SceneRouter._busy = true
	map2.call("_on_pick", 1, "stop", "rest")
	SceneRouter._busy = false
	_check(GameState.map_choice.get("stop", "") == "rest" and GameState.pending_event == "node_rest", "escolher o acampamento devia preparar o evento")
	map2.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Acampamento: curar 8.
	GameState.damage_player(10)
	var rest_scene: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(rest_scene)
	await get_tree().process_frame
	var hp0 := GameState.player_hp
	((rest_scene._options_box as VBoxContainer).get_child(0) as Button).pressed.emit()
	await get_tree().process_frame
	await get_tree().process_frame
	_check(GameState.player_hp == min(GameState.player_max_hp, hp0 + 8), "o acampamento devia curar 8")
	var ante_before := GameState.ante
	SceneRouter._busy = true
	rest_scene.call("_continue_run")
	SceneRouter._busy = false
	_check(GameState.ante == ante_before + 1 and GameState.map_phase == "battle" and GameState.saved_scene == "map" or GameState.ante == ante_before + 1, "continuar do evento devia avançar o ante e voltar ao mapa")
	rest_scene.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Fonte de Mana: recolorir 1 carta (o teste responde ao seletor com a 1.ª carta elegível).
	GameState.new_run("deck10", 5)   # Conclave Selesnya: verde/branco
	GameState.pending_event = "node_spring"
	var spring: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(spring)
	await get_tree().process_frame
	((spring._options_box as VBoxContainer).get_child(0) as Button).pressed.emit()
	for i in 3:
		for f in 3:
			await get_tree().process_frame
		var viewer := SceneRouter.top_overlay()
		if viewer is ZoneViewer:
			var fv := _first_card_view(viewer)
			viewer.call("_on_card_pressed", fv.card)
		else:
			break
	await get_tree().process_frame
	var recolored := 0
	for e in GameState.deck:
		if e.get("colors", []) == [GameState.main_color()]:
			recolored += 1
	_check(recolored >= 1, "a Fonte devia recolorir pelo menos 1 carta")
	spring.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Altar: fundir — sacrifica a 1.ª carta, a 2.ª herda os efeitos.
	GameState.new_run("deck05", 5)
	GameState.pending_event = "node_altar"
	var altar: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(altar)
	await get_tree().process_frame
	var size_before := GameState.deck.size()
	((altar._options_box as VBoxContainer).get_child(0) as Button).pressed.emit()
	for i in 2:
		for f in 3:
			await get_tree().process_frame
		var viewer := SceneRouter.top_overlay()
		if viewer is ZoneViewer:
			var fv := _first_card_view(viewer)
			viewer.call("_on_card_pressed", fv.card)
	await get_tree().process_frame
	await get_tree().process_frame
	var fused := 0
	for e in GameState.deck:
		if e.has("extra_effects"):
			fused += 1
	_check(GameState.deck.size() == size_before - 1 and fused == 1, "o Altar devia sacrificar 1 carta e fundir noutra (%d, %d)" % [GameState.deck.size(), fused])
	altar.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Mercador Cego: só relíquias lendárias e planeswalkers; comprar um planeswalker.
	GameState.new_run("deck01", 6)
	GameState.add_gold(40)
	GameState.map_options(4)
	GameState.ante = 4
	GameState.choose_stop("merchant")
	var merchant: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	add_child(merchant)
	await get_tree().process_frame
	_check(bool(merchant.get("merchant")), "a loja devia abrir em modo Mercador Cego")
	var pw_offers: VBoxContainer = merchant.get_node("%CardOffers")
	var relic_offers: VBoxContainer = merchant.get_node("%RelicOffers")
	_check(pw_offers.get_child_count() == 2 and relic_offers.get_child_count() == 2, "Mercador Cego devia oferecer 2 planeswalkers e 2 relíquias lendárias")
	(pw_offers.get_child(0) as Button).pressed.emit()
	await get_tree().process_frame
	_check(not GameState.planeswalker.is_empty() and GameState.planeswalker_loyalty() == 2, "comprar um planeswalker devia dar lealdade 2")
	var rb: Button = relic_offers.get_child(0)
	_check(bool(CardDB.relics[String((merchant.get("_offer_relics") as Array)[0]["id"])].get("legendary", false)), "as relíquias do Mercador Cego deviam ser lendárias")
	merchant.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Loja normal: selar uma carta (Selo da Fúria na 1.ª carta) e Marca Eterna (Selo Planar 5).
	GameState.new_run("deck01", 6, 5)
	GameState.add_gold(40)
	GameState.map_options(1)
	GameState.choose_stop("shop")
	var shop: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	add_child(shop)
	await get_tree().process_frame
	shop.call("_on_seal")
	await get_tree().process_frame
	var picker := SceneRouter.top_overlay()
	_check(picker is SealPicker, "selar devia abrir o seletor de selos")
	if picker is SealPicker:
		(picker.get("_on_pick") as Callable).call("fury")
		picker.queue_free()
		await get_tree().process_frame
		var viewer := SceneRouter.top_overlay()
		_check(viewer is ZoneViewer, "depois do selo devia abrir o baralho")
		if viewer is ZoneViewer:
			var fv := _first_card_view(viewer)
			var sealed_card: CardInstance = fv.card
			viewer.call("_on_card_pressed", sealed_card)
			await get_tree().process_frame
			_check(String(GameState.deck[sealed_card.entry_index].get("seal", "")) == "fury", "a carta devia ficar com o Selo da Fúria")
	var relic_btn: Button = (shop.get_node("%RelicOffers") as VBoxContainer).get_child(0)
	relic_btn.pressed.emit()
	await get_tree().process_frame
	_check(GameState.relic_ids.size() == 1 and GameState.relic_locked.size() == 1, "com o Selo Planar 5 a relíquia comprada devia ficar presa")
	var owned: VBoxContainer = shop.get_node("%OwnedRelics")
	_check(owned.get_child_count() == 1 and ((owned.get_child(0) as HBoxContainer).get_child(1) as Button).disabled, "a relíquia presa não devia ter botão de vender ativo")
	SceneRouter.close_overlays()
	shop.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Draft: 5 boosters × 2 escolhas + 3 terrenos → run de 4 antes.
	var draft: Node = load("res://scenes/draft/Draft.tscn").instantiate()
	add_child(draft)
	await get_tree().process_frame
	for pack in 5:
		for pick in 2:
			var current: Array = draft.get("_current")
			_check(current.size() == 5 - pick, "o booster devia ter %d cartas, tem %d" % [5 - pick, current.size()])
			draft.call("_on_pick", CardDB.new_instance((current[0] as CardData).id))
			await get_tree().process_frame
		await get_tree().create_timer(0.3).timeout
	_check(String(draft.get("_stage")) == "lands", "depois de 5 boosters devia vir a escolha de terrenos")
	for pick in 3:
		var current: Array = draft.get("_current")
		draft.call("_on_pick", CardDB.new_instance((current[0] as CardData).id))
		await get_tree().process_frame
	_check(String(draft.get("_stage")) == "done" and (draft.get("_picked") as Array).size() == 10 and (draft.get("_lands") as Array).size() == 3, "o draft devia acabar com 10 cartas + 3 terrenos")
	SceneRouter._busy = true
	draft.call("_on_start")
	SceneRouter._busy = false
	_check(GameState.mode == "draft" and GameState.max_ante == 4 and GameState.deck.size() == 13 and GameState.free_mode, "a run de draft devia ter 13 cartas e 4 antes")
	var dbm := BattleManager.new()
	dbm.start(GameState.pick_enemy(1))
	_check(dbm.deck.hand.size() > 0, "a batalha com o baralho de draft não começou")
	GameState.ante = 4
	_check(bool(GameState.pick_enemy(4).get("boss", false)), "o ante 4 do draft devia ser o boss final")
	draft.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Quebra-cabeças: a vida de cada um é exatamente o melhor ataque; a cena lista-os; a batalha resolve-se.
	for pz in CardDB.puzzles:
		var best := PuzzleSolver.solve(pz)
		_check(int(best["total"]) == int(pz.get("hp", 0)), "puzzle %s: melhor ataque %d devia ser igual à vida %d" % [pz.get("id", ""), int(best["total"]), int(pz.get("hp", 0))])
	var pscene: Node = load("res://scenes/puzzles/Puzzles.tscn").instantiate()
	add_child(pscene)
	await get_tree().process_frame
	pscene.queue_free()
	await get_tree().process_frame
	GameState.clear_saved_run()
	GameState.puzzle_id = "p1"
	GameState.free_mode = true
	GameState.relic_ids.clear()
	GameState.player_hp = 20
	var pb: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(pb)
	await get_tree().process_frame
	var pbm: BattleManager = pb.battle
	_check(pbm.puzzle and pbm.max_turns == 1 and pbm.discards_left == 0 and pbm.deck.hand.size() == 5, "a batalha do enigma devia ter 1 turno, 0 canalizações e 5 cartas")
	_check(not GameState.has_saved_run(), "os enigmas não deviam gravar a run")
	var p1_line: Array = PuzzleSolver.solve(CardDB.get_puzzle("p1"))["line"]
	for id in p1_line:
		for c in pbm.deck.hand:
			if c.data.id == id:
				pb.call("_on_hand_card_pressed", c)
				break
	var result := [null]
	var cb := func(v: bool): result[0] = v
	EventBus.battle_ended.connect(cb)
	EventBus.battle_ended.disconnect(pb._on_battle_ended)
	pb.call("_on_end_turn")
	var guard := 0
	while result[0] == null and guard < 600:
		guard += 1
		await get_tree().process_frame
	EventBus.battle_ended.disconnect(cb)
	_check(result[0] == true, "a linha certa devia resolver o enigma 1")
	Stats.on_puzzle_solved("p1")
	_check(Stats.is_puzzle_solved("p1") and Stats.get_stat("puzzles_solved") == 1, "o enigma resolvido devia ficar registado")
	GameState.puzzle_id = ""
	pb.queue_free()
	await get_tree().process_frame
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	GameState.clear_saved_run()
	GameState.free_mode = false
	print("  mapa, acampamento, fonte, altar, Mercador Cego, selos na loja, draft e enigmas OK")

func _test_logic_battles() -> void:
	_check(CardDB.cards.size() == 357, "esperava 357 cartas (com a Ficha), há %d" % CardDB.cards.size())
	_check(CardDB.decks.size() == 18, "esperava 18 baralhos")
	var total_wins := 0
	for deck in CardDB.decks:
		GameState.new_run(String(deck.id), 12345)
		_check(GameState.deck.size() == int(deck.size), "baralho %s tem %d cartas" % [deck.name, GameState.deck.size()])
		# Todas as relíquias (acima do limite de 5 — é um teste de regras, não de loja).
		for relic_id in CardDB.relics.keys():
			GameState.relic_ids.append(String(relic_id))
		GameState.player_hp = 60   # vida persistente: dá folga para 4 batalhas seguidas sem loja
		GameState.player_max_hp = 60
		var wins := 0
		var max_total := 0
		for ante in range(1, 5):
			GameState.ante = ante
			var bm := BattleManager.new()
			var hp := GameState.enemy_hp_for_ante(ante)
			bm.start({"name": "Teste", "hp": hp, "max_hp": hp, "attack": 2, "text": "", "abilities": [
				{"trigger": "turn_end", "action": "steal_gold", "value": 1},
				{"trigger": "every_n_turns", "n": 3, "action": "destroy_strongest"},
				{"trigger": "turn_end", "action": "damage_all_creatures", "value": 1},
				{"trigger": "turn_end", "action": "discard_random", "value": 1},
				{"trigger": "turn_end", "action": "heal_self", "value": 1},
			]})
			var result := [null]
			var cb := func(v: bool): result[0] = v
			EventBus.battle_ended.connect(cb)
			var guard := 0
			while result[0] == null and guard < 50:
				guard += 1
				_play_everything(bm)
				var preview := bm.preview_attack()
				_check(preview.total() == int(round(preview.power * preview.mult * preview.damage_mult)), "total da cascata inconsistente")
				max_total = max(max_total, preview.total())
				# Canalizar uma carta por turno, para exercitar on_discard
				if not bm.deck.hand.is_empty() and bm.can_discard(bm.deck.hand[0]):
					bm.discard(bm.deck.hand[0])
				bm.end_turn()
			EventBus.battle_ended.disconnect(cb)
			_check(result[0] != null, "batalha %s ante %d não terminou" % [deck.name, ante])
			_check(bm.turn <= bm.max_turns + bm.extra_turns, "turnos a mais em %s" % deck.name)
			if result[0] == true:
				wins += 1
		print("  %-22s %d/4 vitórias, melhor ataque %d" % [deck.name, wins, max_total])
		_check(max_total > 0, "baralho %s nunca atacou" % deck.name)
		total_wins += wins
	_check(total_wins >= 18, "demasiado poucas vitórias com relíquias fortes: %d" % total_wins)

func _play_everything(bm: BattleManager) -> void:
	var played := true
	var guard := 0
	while played and guard < 40:
		guard += 1
		played = false
		for card in bm.deck.hand.duplicate():
			if bm.can_play(card):
				_check(bm.play(card), "play() falhou numa carta jogável")
				played = true
				break
	_check(bm.creatures().size() <= BattleManager.MAX_CREATURES, "mais criaturas do que o limite")

# ---------------------------------------------------------------------------

func _test_ui_battle() -> void:
	GameState.new_run("deck01", 777)
	GameState.add_relic("relic_ruby")
	GameState.add_relic("relic_banner")
	GameState.ante = 1
	GameState.clear_saved_run()
	var scene: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(scene)
	await get_tree().process_frame
	# A cena mudaria para a loja no fim; aqui queremos ficar no teste.
	EventBus.battle_ended.disconnect(scene._on_battle_ended)
	var bm: BattleManager = scene.get_node("BattleManager")
	_check(GameState.has_saved_run(), "o início do turno 1 devia ter gravado a run")
	var ended := [null]
	var cb := func(v: bool): ended[0] = v
	EventBus.battle_ended.connect(cb)
	# Turno 1: Canalizar pela UI, jogar tudo, atacar.
	var hand_box: Container = scene.get_node("%Hand")
	var dbtn: Button = scene.get_node("%DiscardBtn")
	dbtn.button_pressed = true
	await get_tree().process_frame
	for view in hand_box.get_children():
		if view is CardView and bm.can_discard(view.card):
			var before := bm.deck.graveyard.size()
			view.pressed.emit(view.card)
			await get_tree().process_frame
			_check(bm.deck.graveyard.size() == before + 1, "Canalizar pela UI não descartou")
			_check(not dbtn.button_pressed, "o modo Canalizar devia desligar-se depois de uma carta")
			break
	await _play_ui_turn(scene, bm, ended)
	_check(ended[0] != null or bm.turn == 2, "o turno 1 devia ter acabado (turno=%d)" % bm.turn)
	if ended[0] == null:
		# --- Overlays: pausa, carta em grande, grimório, configurações.
		(scene.get_node("%PauseBtn") as Button).pressed.emit()
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() is PauseMenu, "a pausa não abriu")
		if SceneRouter.top_overlay() is PauseMenu:
			(SceneRouter.top_overlay() as PauseMenu).close()
		await get_tree().process_frame
		await get_tree().process_frame
		_check(not SceneRouter.has_overlay(), "a pausa não fechou")
		for view in hand_box.get_children():
			if view is CardView:
				view.long_pressed.emit(view.card)
				break
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() is CardZoom, "o toque longo não abriu a carta em grande")
		SceneRouter.close_overlays()
		await get_tree().process_frame
		(scene.get_node("%LibraryBtn") as Button).pressed.emit()
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() is ZoneViewer, "o grimório não abriu")
		SceneRouter.close_overlays()
		await get_tree().process_frame
		var sm := SettingsMenu.open()
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() == sm, "as configurações não abriram")
		sm.close()
		await get_tree().process_frame
		await get_tree().process_frame
		# Desfazer pela UI: joga uma carta e anula.
		var hand_n := bm.deck.hand.size()
		for view in hand_box.get_children():
			if view is CardView and bm.can_play(view.card):
				view.pressed.emit(view.card)
				await get_tree().process_frame
				break
		var undo: Button = scene.get_node("%UndoBtn")
		if bm.deck.hand.size() == hand_n - 1:
			_check(not undo.disabled, "DESFAZER devia estar ativo depois de jogar")
			undo.pressed.emit()
			await get_tree().process_frame
			_check(bm.deck.hand.size() == hand_n, "DESFAZER não repôs a carta na mão")
		# Arrastar no tabuleiro: inverte a ordem das criaturas.
		if bm.board.size() >= 2:
			var first: CardInstance = bm.board[0]
			scene.call("_on_board_drag_started", first, Vector2(100, 100))
			scene.call("_on_board_drag_moved", first, Vector2(5000, 100))
			scene.call("_on_board_drag_ended", first, Vector2(5000, 100))
			_check(bm.board[bm.board.size() - 1] == first, "arrastar devia mover a criatura para o fim")
			var board_box: HBoxContainer = scene.get_node("%Board")
			_check(board_box.get_child(board_box.get_child_count() - 1) == scene._board_views[first.uid], "a vista devia acompanhar a nova ordem")
		# --- Gravação a meio: o início do turno 2 gravou a batalha; retoma-a numa cena nova.
		var saved := {"turn": bm.turn, "hand": bm.deck.hand.size(), "library": bm.deck.library.size(), "graveyard": bm.deck.graveyard.size(), "board": bm.board.size(), "hp": bm.enemy.hp, "mana": bm.mana_total, "discards": bm.discards_left}
		EventBus.battle_ended.disconnect(cb)
		scene.queue_free()
		await get_tree().process_frame
		GameState.new_run("deck05", 1)   # estado diferente: a retoma tem de vir do disco
		_check(GameState.load_run(), "load_run falhou com batalha a meio")
		_check(not GameState.pending_battle.is_empty(), "a gravação devia trazer a batalha")
		_check(String(GameState.deck_def.get("id", "")) == "deck01", "baralho errado na retoma")
		scene = load("res://scenes/battle/Battle.tscn").instantiate()
		add_child(scene)
		await get_tree().process_frame
		EventBus.battle_ended.disconnect(scene._on_battle_ended)
		bm = scene.get_node("BattleManager")
		EventBus.battle_ended.connect(cb)
		var same: bool = bm.turn == saved.turn and bm.deck.hand.size() == saved.hand and bm.deck.library.size() == saved.library \
			and bm.deck.graveyard.size() == saved.graveyard and bm.board.size() == saved.board and bm.enemy.hp == saved.hp \
			and bm.mana_total == saved.mana and bm.discards_left == saved.discards
		_check(same, "batalha retomada não bate certo: %s vs turno %d mão %d grimório %d cemitério %d tabuleiro %d" % [str(saved), bm.turn, bm.deck.hand.size(), bm.deck.library.size(), bm.deck.graveyard.size(), bm.board.size()])
		_check(GameState.pending_battle.is_empty(), "pending_battle devia ser consumida pela cena")
		for card in bm.board:
			_check(card.entry_index >= 0 and card.deck_entry == GameState.deck[card.entry_index], "criatura retomada perdeu a ligação ao baralho")
		print("  UI: batalha retomada no turno %d a partir do ficheiro" % bm.turn)
	# Continua até ao fim.
	var guard := 0
	while ended[0] == null and guard < 10:
		guard += 1
		await _play_ui_turn(scene, bm, ended)
	EventBus.battle_ended.disconnect(cb)
	_check(ended[0] != null, "batalha com UI não terminou")
	print("  UI: batalha terminou (vitória=%s) no turno %d" % [str(ended[0]), bm.turn])
	scene.queue_free()
	await get_tree().process_frame

## Joga tudo o que puder pela UI, carrega em ATACAR e espera que o turno avance (ou a batalha acabe).
func _play_ui_turn(scene: Node, bm: BattleManager, ended: Array) -> void:
	var progressed := true
	while progressed:
		progressed = false
		var hand_box: Container = scene.get_node("%Hand")
		for view in hand_box.get_children():
			if view is CardView and bm.can_play(view.card):
				view.pressed.emit(view.card)
				await get_tree().process_frame
				progressed = true
				break
	var btn: Button = scene.get_node("%EndTurn")
	_check(not btn.disabled, "botão de atacar devia estar ativo no turno %d" % bm.turn)
	btn.pressed.emit()
	var t0 := Time.get_ticks_msec()
	var turn_before := bm.turn
	while ended[0] == null and bm.turn == turn_before and Time.get_ticks_msec() - t0 < 20000:
		await get_tree().process_frame
	_check(ended[0] != null or bm.turn > turn_before, "a cascata/turno não avançou (timeout)")

func _first_card_view(viewer: Node) -> CardView:
	var stack: Array = [viewer]
	var fallback: CardView = null
	while not stack.is_empty():
		var n: Node = stack.pop_back()
		if n is CardView and not n.is_queued_for_deletion():
			if (n as CardView).playable:
				return n
			if fallback == null:
				fallback = n
		for c in n.get_children():
			stack.append(c)
	return fallback

func _test_other_scenes() -> void:
	# Progresso limpo e determinístico.
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	GameState.clear_saved_run()
	GameState.free_mode = false
	_check(GameState.is_deck_unlocked("deck01"), "deck01 devia estar aberto")
	_check(not GameState.is_deck_unlocked("deck02"), "deck02 devia estar bloqueado no início")
	_check(not GameState.is_act_unlocked(1), "ato II devia estar bloqueado no início")
	# Gravação e retoma da run.
	GameState.new_run("deck04", 42)
	GameState.add_gold(20)
	GameState.add_relic("relic_drum")
	GameState.ante = 3
	GameState.deck[0]["power_bonus"] = 15
	GameState.save_run()
	_check(GameState.has_saved_run(), "run não ficou gravada")
	GameState.new_run("deck01", 1)
	_check(GameState.load_run(), "não conseguiu carregar a run")
	_check(GameState.deck_def.get("id") == "deck04" and GameState.ante == 3 and "relic_drum" in GameState.relic_ids and int(GameState.deck[0]["power_bonus"]) == 15, "run carregada não bate certo")
	# Abandonar a run: conta como derrota no ante atual e apaga a gravação.
	GameState.new_run("deck03", 9)
	GameState.ante = 3
	GameState.save_run({}, "shop")
	GameState.abandon_run()
	_check(not GameState.has_saved_run(), "abandonar devia apagar a gravação")
	_check(GameState.best_ante("deck03") == 3, "abandonar no ante 3 devia registar melhor ante 3")
	# Retoma na loja: a gravação lembra-se de onde estava.
	GameState.new_run("deck02", 3)
	GameState.ante = 2
	GameState.save_run({}, "shop")
	_check(GameState.load_run() and GameState.saved_scene == "shop" and GameState.pending_battle.is_empty(), "gravação na loja não retoma na loja")
	# Desbloqueios.
	GameState.new_run("deck01", 5)
	GameState.ante = 4
	var unl := GameState.record_run_end(4, false)
	_check(GameState.is_deck_unlocked("deck02"), "deck02 devia desbloquear ao chegar ao ante 4 com deck01")
	_check(unl.size() == 1, "esperava 1 desbloqueio, veio %d" % unl.size())
	GameState.record_run_end(6, false)
	_check(GameState.is_act_unlocked(1), "ato II devia abrir ao chegar ao ante 6")
	_check(GameState.is_deck_unlocked("deck06") and not GameState.is_deck_unlocked("deck07"), "no ato II só o 1.º capítulo devia estar aberto")
	# Cenas (progresso: só o deck01 chegou ao ante 4 → ato I com 2 capítulos abertos).
	GameState.progress = {"best_ante": {"deck01": 4}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	GameState.new_run("deck04", 42)
	GameState.add_gold(20)   # 24 ouro → 4 de juros na loja
	GameState.add_relic("relic_drum")
	GameState.damage_player(8)
	# Evento: escolhe a opção do ouro e confirma o resultado.
	GameState.ante = 2
	GameState.pending_event = "fountain"
	var ev_scene: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(ev_scene)
	await get_tree().process_frame
	_check(GameState.saved_scene == "battle" or GameState.has_saved_run(), "evento devia gravar ao entrar")
	var gold_ev := GameState.gold
	var opts: VBoxContainer = ev_scene._options_box
	_check(opts.get_child_count() == 3, "a Fonte devia ter 3 opções")
	(opts.get_child(1) as Button).pressed.emit()
	await get_tree().process_frame
	await get_tree().process_frame
	_check(GameState.gold == gold_ev + 6, "a opção do cantil devia dar +6 ouro")
	_check(ev_scene._continue.visible and GameState.pending_event == "", "depois da escolha devia aparecer CONTINUAR")
	ev_scene.queue_free()
	await get_tree().process_frame
	var gold_in := GameState.gold
	for path in ["res://scenes/main/Main.tscn", "res://scenes/campaign/Campaign.tscn", "res://scenes/ui/HowToPlay.tscn", "res://scenes/shop/Shop.tscn", "res://scenes/ui/RunOver.tscn"]:
		var s: Node = load(path).instantiate()
		add_child(s)
		await get_tree().process_frame
		if path.ends_with("Main.tscn"):
			_check(s.get_node("%NewGame") != null and s.get_node("%Modes") != null and s.get_node("%Settings") != null, "menu sem botões")
		if path.ends_with("Campaign.tscn"):
			_check((s.get_node("%Difficulty") as Button).text.contains("NORMAL"), "a dificuldade (no ecrã da campanha) devia ser Normal")
		if path.ends_with("Campaign.tscn"):
			var list: VBoxContainer = s.get_node("%ChapterList")
			_check(list.get_child_count() == 5, "ato I devia listar 5 capítulos, listou %d" % list.get_child_count())
			var enabled := 0
			for b in list.get_children():
				if not (b as Button).disabled:
					enabled += 1
			_check(enabled == 2, "no ato I deviam estar abertos 2 capítulos (01 e 02), estão %d" % enabled)
			_check(not (s.get_node("%Story") as Label).text.is_empty(), "história vazia")
		if path.ends_with("Shop.tscn"):
			var offers: VBoxContainer = s.get_node("%CardOffers")
			_check(offers.get_child_count() == 3, "loja devia oferecer 3 cartas")
			var relic_offers := (s.get_node("%RelicOffers") as VBoxContainer).get_children().filter(func(b): return String(b.get_meta("kind", "")) == "relic")
			var voucher_offers := (s.get_node("%RelicOffers") as VBoxContainer).get_children().filter(func(b): return String(b.get_meta("kind", "")) == "voucher")
			_check(relic_offers.size() == 2, "loja devia oferecer 2 relíquias")
			_check(voucher_offers.size() == 1, "loja devia oferecer 1 Vale")
			_check(GameState.has_saved_run(), "a loja devia gravar a run ao entrar")
			_check(GameState.gold == gold_in + mini(5, int(gold_in / 5)), "juros: %d ouro deviam render %d (ouro=%d)" % [gold_in, mini(5, int(gold_in / 5)), GameState.gold])
			(s.get_node("%DeckButton") as Button).pressed.emit()
			await get_tree().process_frame
			_check(SceneRouter.top_overlay() is ZoneViewer, "ver baralho na loja não abriu")
			SceneRouter.close_overlays()
			await get_tree().process_frame
			# Curar e vida máxima.
			var hp_before := GameState.player_hp
			(s.get_node("%HealBtn") as Button).pressed.emit()
			_check(GameState.player_hp == min(GameState.player_max_hp, hp_before + 5), "curar na loja não curou")
			var max_before := GameState.player_max_hp
			(s.get_node("%MaxHpBtn") as Button).pressed.emit()
			_check(GameState.player_max_hp == max_before + 5, "vida máxima na loja não subiu")
			# Remover (escolhe a 1.ª carta do painel).
			var before := GameState.deck.size()
			s.call("_on_remove")
			await get_tree().process_frame
			var viewer := SceneRouter.top_overlay()
			_check(viewer is ZoneViewer, "remover devia abrir o baralho")
			if viewer is ZoneViewer:
				var first_view: CardView = _first_card_view(viewer)
				viewer.call("_on_card_pressed", first_view.card)
				await get_tree().process_frame
			_check(GameState.deck.size() == before - 1, "remoção na loja não removeu uma carta")
			# Melhorar (1.ª carta): bónus permanente.
			s.call("_on_upgrade")
			await get_tree().process_frame
			viewer = SceneRouter.top_overlay()
			if viewer is ZoneViewer:
				var fv: CardView = _first_card_view(viewer)
				var entry: Dictionary = GameState.deck[fv.card.entry_index]
				var pb := int(entry.get("power_bonus", 0))
				var mb := float(entry.get("mult_bonus", 0.0))
				viewer.call("_on_card_pressed", fv.card)
				await get_tree().process_frame
				_check(int(entry.get("power_bonus", 0)) > pb or float(entry.get("mult_bonus", 0.0)) > mb, "melhorar não deu bónus permanente")
			# Booster: escolhe 1 de 3.
			before = GameState.deck.size()
			s.call("_on_booster")
			await get_tree().process_frame
			viewer = SceneRouter.top_overlay()
			_check(viewer is ZoneViewer, "booster devia abrir 3 cartas")
			if viewer is ZoneViewer:
				var fv2: CardView = _first_card_view(viewer)
				viewer.call("_on_card_pressed", fv2.card)
				await get_tree().process_frame
			_check(GameState.deck.size() == before + 1, "booster não juntou uma carta")
			# Vender a relíquia que temos.
			var gold_before := GameState.gold
			var owned: VBoxContainer = s.get_node("%OwnedRelics")
			_check(owned.get_child_count() == GameState.relic_ids.size(), "lista das tuas relíquias errada")
			if owned.get_child_count() > 0:
				((owned.get_child(0) as HBoxContainer).get_child(1) as Button).pressed.emit()
				await get_tree().process_frame
				_check(GameState.relic_ids.is_empty() and GameState.gold > gold_before, "vender relíquia não funcionou")
			# Novas ofertas.
			var reroll: Button = s.get_node("%RerollBtn")
			if not reroll.disabled:
				reroll.pressed.emit()
				await get_tree().process_frame
				_check((s.get_node("%CardOffers") as VBoxContainer).get_child_count() == 3, "novas ofertas deviam voltar a dar 3 cartas")
			SceneRouter.close_overlays()
		if path.ends_with("RunOver.tscn"):
			_check((s.get_node("%Title") as Label).text == "DERROTA", "RunOver devia dizer DERROTA")
		s.queue_free()
		await get_tree().process_frame
	# Limpa o que o teste escreveu.
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	GameState.clear_saved_run()
	Settings.language = "auto"
	Settings.save_settings()
	print("  menu/campanha/como jogar/loja/fim carregam; gravação, abandono e desbloqueios OK")
