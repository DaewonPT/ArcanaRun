extends Node
## Teste de fumo headless:  godot --headless --path . res://tests/SmokeTest.tscn
## 1) Batalhas só com lógica (sem UI) com os 18 baralhos, com relíquias e inimigo com todas as habilidades.
## 2) Uma batalha a correr na cena real Battle.tscn (cascata animada com timers), com Canalizar.
## 3) Carregar as outras cenas (Main, Shop, RunOver) sem erros.
## Sai com código 0 se tudo passou, 1 se algo falhou.

var failures: Array[String] = []

func _ready() -> void:
	await get_tree().process_frame
	Settings.language = "pt"
	Settings.anim_speed = "normal"
	Settings.warn_mana = false   # os avisos opcionais têm o seu próprio teste
	Settings.warn_rare = false
	Settings.confirm_buy = false   # 0.13.0: a confirmação das compras caras tem o seu próprio teste
	Settings.apply()
	Stats.set_tutorial_done(true)
	_test_scripts_load()
	_test_settings()
	_test_rules()
	_test_mechanics_080()
	_test_090()
	await _test_0100()
	_test_0110()
	_test_0120()
	_test_content_update()
	_test_stats_and_custom()
	_test_logic_battles()
	await _test_ui_battle()
	await _test_other_scenes()
	await _test_new_scenes()
	await _test_scenes_080()
	await _test_scenes_090()
	await _test_scenes_0100()
	await _test_scenes_0110()
	await _test_scenes_0120()
	await _test_0121()
	_test_0130()
	await _test_content_0130()
	_test_run_0130()
	await _test_run_scenes_0130()
	await _test_modes_0130()
	await _test_scenes_0130()
	await _test_saves_0130()
	await _test_progress_0130()
	await _test_presentation_0130()
	await _test_campaign_0131()
	await _test_menu_0131()
	await _test_cards_0141()
	await _test_fixes_0140()
	if failures.is_empty():
		print("SMOKE TEST: OK")
		get_tree().quit(0)
	else:
		for f in failures:
			printerr("SMOKE TEST FAIL: " + f)
		get_tree().quit(1)

func _check(cond: bool, msg: String) -> void:
	if not cond:
		failures.append(msg)

# ---------------------------------------------------------------------------

func _test_settings() -> void:
	# Tradução: chaves em PT → EN; sem tradução fica o texto PT.
	Settings.language = "en"
	Settings.apply()
	_check(TranslationServer.translate("NOVO JOGO") == "NEW GAME", "tradução EN não funciona (TranslationServer)")
	_check(tr("ATACAR") == "ATTACK", "tr() não traduz para EN")
	_check(tr("Senado Azorius") == "Azorius Senate", "nomes dos baralhos não traduzem")
	_check(Cascade.label_for("power_add", 3) == "+3 Power", "etiquetas da cascata não traduzem")
	_check(tr("Goblin Guia") == "Goblin Guide", "nomes das cartas não traduzem (cards_en.json)")
	_check(tr(CardDB.get_card("c001").text).begins_with("+4 Mult; if it is the 1st"), "textos das cartas não traduzem")
	_check(tr("Texto sem tradução") == "Texto sem tradução", "texto sem entrada devia ficar igual")
	Settings.language = "pt"
	Settings.apply()
	_check(tr("NOVO JOGO") == "NOVO JOGO", "em PT o texto devia ficar igual")
	_check(TranslationServer.get_locale().begins_with("pt"), "locale devia ser pt_PT, é %s" % TranslationServer.get_locale())
	# Velocidade das animações e gravação das configurações.
	Settings.anim_speed = "instant"
	_check(Settings.dur(1.0) == 0.0, "instantâneo devia dar duração 0")
	Settings.anim_speed = "fast"
	_check(Settings.dur(1.0) < 1.0 and Settings.dur(1.0) > 0.0, "rápida devia encurtar")
	Settings.sfx_volume = 0.35
	Settings.vibration = false
	Settings.save_settings()
	Settings.sfx_volume = 1.0
	Settings.vibration = true
	Settings.anim_speed = "normal"
	Settings.load_settings()
	_check(is_equal_approx(Settings.sfx_volume, 0.35) and not Settings.vibration and Settings.anim_speed == "fast", "configurações não gravaram/carregaram")
	Settings.sfx_volume = 1.0
	Settings.vibration = true
	Settings.anim_speed = "normal"
	Settings.save_settings()
	Settings.apply()
	_check(AudioServer.get_bus_index("Sfx") >= 0 and AudioServer.get_bus_index("Music") >= 0, "buses de áudio em falta")
	print("  configurações/traduções OK")

func _test_rules() -> void:
	# Vida persistente, limite de relíquias, juros, inimigos por ato, bosses e regras.
	GameState.new_run("deck01", 11)
	_check(GameState.player_hp == 20 and GameState.player_max_hp == 20, "vida inicial devia ser 20/20")
	GameState.damage_player(7)
	var bm := BattleManager.new()
	bm.start(GameState.pick_enemy(1))
	_check(GameState.player_hp == 13, "a vida devia persistir entre batalhas (13), está %d" % GameState.player_hp)
	_check(bm.enemy.get("boss", false) == false and String(bm.enemy.get("id", "")) != "", "ante 1 devia ter um inimigo normal")
	GameState.heal(50)
	_check(GameState.player_hp == 20, "curar não devia passar da vida máxima")
	GameState.change_max_hp(5)
	_check(GameState.player_max_hp == 25, "vida máxima devia subir para 25")
	for i in 7:
		GameState.add_relic(String(CardDB.relics.keys()[i]))
	_check(GameState.relic_ids.size() == GameState.MAX_RELICS, "limite de relíquias devia ser %d" % GameState.MAX_RELICS)
	_check(not GameState.add_relic("relic_whetstone"), "add_relic devia recusar acima do limite")
	GameState.remove_relic(GameState.relic_ids[0])
	_check(GameState.relic_ids.size() == 4 and GameState.add_relic("relic_whetstone"), "vender devia abrir espaço")
	GameState.move_relic("relic_whetstone", 0)
	_check(GameState.relic_ids[0] == "relic_whetstone", "move_relic devia pôr a relíquia na frente")
	GameState.gold = 23
	GameState.interest_ante = 0
	_check(GameState.interest_due() == 4, "juros de 23 ouro deviam ser 4, são %d" % GameState.interest_due())
	GameState.pay_interest()
	_check(GameState.gold == 27 and GameState.interest_due() == 0, "juros deviam pagar uma vez por ante")
	# Bosses: ante 4 tem regra; ante 8 é o final.
	GameState.ante = 4
	var boss := GameState.pick_enemy(4)
	_check(bool(boss.get("boss", false)) and not (boss.get("rule", {}) as Dictionary).is_empty(), "ante 4 devia ter um boss com regra")
	GameState.ante = 8
	var final_boss := GameState.pick_enemy(8)
	_check(String(final_boss.get("id", "")) == "boss_zero", "ante 8 devia ser o boss final")
	# Regras de boss, uma a uma, sobre o mesmo baralho.
	GameState.new_run("deck05", 3)
	var tests := {
		"discards_minus": {"discards_minus": 1}, "hand_size": {"hand_size": 5},
		"creature_cost_plus": {"creature_cost_plus": 1}, "no_formations": {"no_formations": true},
		"relics_off": {"relics_off": true}, "color_silenced": {"color_silenced": "white"},
	}
	for key in tests:
		GameState.new_run("deck05", 3)
		GameState.relic_ids.append("relic_drum")
		GameState.ante = 4
		var b := BattleManager.new()
		b.start({"name": "Boss", "hp": 999999, "max_hp": 999999, "attack": 1, "text": "", "abilities": [], "boss": true, "rule": tests[key]})
		match key:
			"discards_minus":
				_check(b.discards_left == GameState.discards_for_battle() - 1, "Mordaça devia tirar 1 canalização")
			"hand_size":
				_check(b.deck.hand.size() == 5, "Peso devia dar mão de 5, deu %d" % b.deck.hand.size())
			"creature_cost_plus":
				var creature: CardInstance = null
				for c in b.deck.hand:
					if c.data.is_creature():
						creature = c
				if creature != null:
					_check(b.effects.cost_of(creature) == creature.data.cost + 1, "Tarifa devia custar +1")
			"no_formations", "relics_off", "color_silenced":
				_play_everything(b)
				var prev := b.preview_attack()
				if key == "no_formations":
					_check(prev.formations.is_empty(), "Caos devia anular as formações")
				elif key == "relics_off":
					var relic_steps := prev.steps.filter(func(st): return st.source_kind == "relic")
					_check(relic_steps.is_empty(), "relics_off devia calar as relíquias")
				else:
					var effect_steps := prev.steps.filter(func(st): return st.source_kind == "creature" and st.action != "power_add")
					_check(effect_steps.is_empty(), "cartas brancas silenciadas não deviam ter efeitos na cascata")
	# Pré-visualização por carta, contra-ataque e desfazer.
	GameState.new_run("deck05", 3)
	GameState.ante = 1
	var b2 := BattleManager.new()
	b2.start({"name": "Teste", "hp": 100000, "max_hp": 100000, "attack": 3, "text": "", "abilities": []})
	var playable: CardInstance = null
	for c in b2.deck.hand:
		if b2.can_play(c) and not c.data.is_land():
			playable = c
			break
	if playable != null:
		var hand_before := b2.deck.hand.duplicate()
		var delta := b2.preview_play(playable)
		_check(b2.deck.hand == hand_before and not (playable in b2.board), "preview_play não devia alterar o estado")
		var snap := b2.snapshot()
		b2.play(playable)
		var after := b2.preview_attack().total()
		_check(after == delta, "o delta previsto (%d) devia bater com o total depois de jogar (%d)" % [delta, after])
		var counter := b2.preview_enemy_phase()
		_check(int(counter["damage"]) == 3, "preview_enemy_phase devia ler o ataque do inimigo")
		_check(b2.restore_snapshot(snap), "restore_snapshot falhou")
		_check(b2.deck.hand.size() == hand_before.size() and b2.board.is_empty(), "desfazer devia repor a mão e o tabuleiro")
	# Eventos.
	GameState.new_run("deck01", 4)
	var ev := GameState.pick_event()
	_check(ev != "" and not CardDB.get_event(ev).is_empty(), "pick_event devia devolver um evento do ato I")
	_check(not GameState.seen_events.is_empty(), "o evento devia ficar registado como visto")
	print("  regras: vida persistente, relíquias, juros, bosses, previsões, desfazer, eventos OK")

# ---------------------------------------------------------------------------
# 0.8.0: mulligan, dupla face, selos, recapitular/exílio, planeswalker, selos planares, mapa.
# ---------------------------------------------------------------------------

## Batalha com mão/tabuleiro/grimório fixos (via restore), para testar mecânicas isoladas.
func _battle_with(hand: Array, board: Array = [], library: Array = [], discards: int = 3, mana: int = 6, attack: int = 0, max_turns: int = 5, graveyard: Array = []) -> BattleManager:
	var bm := BattleManager.new()
	var state := {
		"enemy": {"id": "test", "name": "Teste", "hp": 999999, "max_hp": 999999, "attack": attack, "text": "", "abilities": [], "boss": false, "rule": {}},
		"turn": 1, "max_turns": max_turns, "mana_total": mana, "mana_available": mana, "discards_left": discards,
		"player_hp": GameState.player_hp, "library": [], "hand": [], "graveyard": [], "board": [], "exile": [],
	}
	for i in GameState.deck.size():
		var id := String(GameState.deck[i]["id"])
		if id in hand:
			state["hand"].append({"id": id, "entry": i}); hand.erase(id)
		elif id in board:
			state["board"].append({"id": id, "entry": i}); board.erase(id)
		elif id in graveyard:
			state["graveyard"].append({"id": id, "entry": i, "exiled": true}); graveyard.erase(id)
		elif id in library:
			state["library"].append({"id": id, "entry": i}); library.erase(id)
	for id in hand:
		state["hand"].append({"id": id, "entry": -1})
	for id in board:
		state["board"].append({"id": id, "entry": -1})
	for id in graveyard:
		state["graveyard"].append({"id": id, "entry": -1, "exiled": true})
	for id in library:
		state["library"].append({"id": id, "entry": -1})
	bm.restore(state)
	return bm

func _find(cards: Array, id: String) -> CardInstance:
	for c in cards:
		if c.data.id == id:
			return c
	return null

func _test_mechanics_080() -> void:
	# --- Mulligan de Londres ---
	GameState.new_run("deck02", 21)
	var bm := BattleManager.new()
	bm.start(GameState.pick_enemy(1))
	_check(bm.can_mulligan(), "no turno 1 sem jogadas devia poder fazer mulligan")
	_check(bm.mulligan() and bm.deck.hand.size() == 6 and bm.pending_bottom == 1, "mulligan devia dar 6 cartas e pedir 1 para o fundo")
	_check(not bm.can_play(bm.deck.hand[0]) and not bm.can_mulligan(), "com cartas por pôr no fundo não se joga nem repete")
	var lib_before := bm.deck.library.size()
	_check(bm.bottom_card(bm.deck.hand[0]) and bm.pending_bottom == 0 and bm.deck.hand.size() == 5 and bm.deck.library.size() == lib_before + 1, "pôr no fundo devia tirar da mão e meter no grimório")
	_check(bm.mulligan() and bm.pending_bottom == 2, "o 2.º mulligan devia pedir 2 cartas para o fundo")
	bm.bottom_card(bm.deck.hand[0]); bm.bottom_card(bm.deck.hand[0])
	_check(bm.deck.hand.size() == 4 and bm.mulligan() and bm.pending_bottom == 3, "o 3.º mulligan devia ser permitido (fica com 3)")
	for i in 3:
		bm.bottom_card(bm.deck.hand[0])
	_check(bm.deck.hand.size() == 3 and not bm.can_mulligan(), "com 3 cartas já não há mulligan")
	_check(Stats.get_stat("mulligans") >= 3, "mulligans deviam contar nas estatísticas")
	var played_one := false
	for c in bm.deck.hand:
		if bm.can_play(c) and not c.data.is_land():
			played_one = bm.play(c)
			break
	if played_one:
		_check(bm.actions_this_turn == 1, "jogar devia contar como ação")
	# --- Dupla face: canalizar 3 com o Candidato na mão ---
	GameState.new_run("deck01", 5)
	GameState.add_card("c301")
	var b2 := _battle_with(["c301", "c001", "c002", "c003", "c004"], [], ["c005", "c006", "c007", "c008"], 3)
	var cand := _find(b2.deck.hand, "c301")
	_check(cand != null and cand.has_mission() and cand.mission_trigger() == "channel", "c301 devia ter missão de canalizar")
	for i in 3:
		var other: CardInstance = null
		for c in b2.deck.hand:
			if c != cand:
				other = c
				break
		b2.discard(other)
	_check(cand.transformed and cand.data.name == "Agente Duplo" and cand.power() == 50, "o Candidato devia virar Agente Duplo (50) depois de 3 canalizações")
	_check(Stats.get_stat("transforms") >= 1, "transformações deviam contar")
	b2.play(cand)
	var mul_steps := b2.preview_attack().steps.filter(func(st): return st.source_card == cand and st.action == "mult_mul")
	_check(mul_steps.size() == 1 and is_equal_approx(mul_steps[0].value, 3.0), "Agente Duplo devia dar ×3 Mult na cascata")
	# Dupla face: ouro (Relicário) e sobreviver a ataques (Noviço) — e gravar/retomar mantém a viragem.
	GameState.new_run("deck05", 5)
	GameState.gold = 4
	var b3 := _battle_with(["c306"], ["c304"], ["c041", "c042"], 3, 6, 0, 5)
	var rel := _find(b3.deck.hand, "c306")
	GameState.add_gold(8)
	b3.on_gold_changed()
	_check(rel.transformed and rel.data.name == "Relicário Aberto" and rel.data.power == 40, "o Relicário devia abrir com 10+ ouro")
	var nov := _find(b3.board, "c304")
	b3.end_turn()
	_check(not nov.transformed and nov.mission_count == 1, "o Noviço devia contar 1 ataque sobrevivido")
	b3.end_turn()
	_check(nov.transformed and nov.data.name == "Inquisidor Veterano", "o Noviço devia virar ao 2.º ataque")
	var saved := b3.to_dict()
	var b3b := BattleManager.new()
	b3b.restore(saved)
	var nov2 := _find(b3b.board, "c304")
	_check(nov2 != null and nov2.transformed and nov2.power() == 40, "a viragem devia sobreviver a gravar/retomar")
	# --- Selos de guilda ---
	GameState.new_run("deck05", 7)
	GameState.deck[0]["seal"] = "tithe"      # c039 Campeão
	GameState.deck[1]["seal"] = "vitality"   # c040 Tenente
	GameState.deck[2]["seal"] = "fury"       # c041 Falcão
	GameState.deck[3]["seal"] = "phyrexian"  # c042 Honra (feitiço)
	GameState.deck[4]["seal"] = "wisdom"     # c043 Marechal
	var b4 := _battle_with(["c039", "c040", "c041", "c042", "c043"], [], ["c044", "c045"], 3, 9)
	var gold_before := GameState.gold
	b4.play(_find(b4.deck.hand, "c039"))
	_check(GameState.gold == gold_before + 3, "Selo do Dízimo devia dar +3 ouro ao jogar")
	var champion := _find(b4.board, "c039")
	b4.play(_find(b4.deck.hand, "c040"))
	_check(champion.perm_power() == 15, "Selo da Vitalidade devia dar +15 permanente à criatura à esquerda")
	b4.play(_find(b4.deck.hand, "c041"))
	var hawk := _find(b4.board, "c041")
	b4.play(_find(b4.deck.hand, "c042"))
	var casc := b4.preview_attack()
	var fury_steps := casc.steps.filter(func(st): return st.source_card == hawk and st.retrigger)
	_check(fury_steps.size() >= 1, "Selo da Fúria devia reativar o Falcão")
	var phy := casc.steps.filter(func(st): return st.tag == "seal" and st.action == "mult_mul")
	_check(phy.size() == 1 and is_equal_approx(phy[0].value, 2.5), "Selo Phyrexiano devia dar ×2.5 Mult")
	var honra_entry: Dictionary = GameState.deck[3]
	b4.end_turn()
	_check(int(honra_entry.get("power_bonus", 0)) == -10 and bool(honra_entry.get("exiled_run", false)), "Selo Phyrexiano: Honra (10 Pod) devia perder 10 e ficar exilada da run")
	_check(not GameState.formation_levels.is_empty(), "Selo da Sabedoria devia subir uma formação ao fim do turno")
	var deck_size := GameState.deck.size()
	GameState.purge_exiled()
	_check(GameState.deck.size() == deck_size - 1, "a carta exilada devia sair do baralho (%d cartas), tem %d" % [deck_size - 1, GameState.deck.size()])
	# Nível de formação conta na cascata.
	GameState.formation_levels = {"pair": 2}
	var b5 := _battle_with([], ["c040", "c041"], [], 3, 9)   # dois custo 2: Pacto Dual
	var pair_steps := b5.preview_attack().steps.filter(func(st): return st.source_id == "pair")
	_check(pair_steps.size() == 1 and is_equal_approx(pair_steps[0].value, 3.0) and pair_steps[0].level == 2, "Pacto Dual nível 2 devia dar +3 Mult")
	# --- Recapitular e exílio ---
	GameState.new_run("deck03", 8)
	var b6 := _battle_with(["c019"], [], ["c020"], 3, 6, 0, 5, ["c018"])   # Ritual Sombrio no cemitério
	var ritual := _find(b6.deck.graveyard, "c018")
	_check(ritual != null and b6.flashback_cards().size() == 1 and b6.can_flashback(ritual), "Ritual Sombrio devia poder ser recapitulado")
	var mana_before := b6.mana_available
	_check(b6.play_flashback(ritual) and b6.mana_available == mana_before - 1, "recapitular devia custar o custo normal (1)")
	_check(ritual.zone == CardInstance.Zone.EXILE and ritual in b6.deck.exile and not (ritual in b6.deck.graveyard), "a carta recapitulada devia ir para o exílio")
	_check(b6.spells_this_turn.has(ritual) and b6.preview_attack().steps.any(func(st): return st.source_card == ritual), "o feitiço recapitulado devia entrar na cascata")
	_check(not b6.can_flashback(ritual), "não se recapitula duas vezes")
	var b6b := BattleManager.new()
	b6b.restore(b6.to_dict())
	_check(b6b.deck.exile.size() == 1, "o exílio devia sobreviver a gravar/retomar")
	_check(Stats.get_stat("flashbacks") >= 1, "recapitular devia contar")
	# --- Planeswalker ---
	GameState.new_run("deck01", 9)
	GameState.set_planeswalker("pw_red")
	_check(GameState.planeswalker_loyalty() == 2 and GameState.planeswalker_color() == "red", "planeswalker devia começar com 2 de lealdade")
	var b7 := _battle_with(["c001", "c002", "c003"], ["c007"], ["c004", "c005", "c006"], 3, 6)
	_check(b7.can_use_planeswalker(0) and not b7.can_use_planeswalker(2), "+1 disponível, −6 não (lealdade 2)")
	_check(b7.use_planeswalker(0) and GameState.planeswalker_loyalty() == 3, "+1 devia subir a lealdade para 3")
	_check(_find(b7.deck.hand, "c001").power_bonus == 10, "Ísaura +1 devia dar +10 Poder às cartas vermelhas na mão")
	_check(not b7.can_use_planeswalker(1), "só uma habilidade por turno")
	b7.play(_find(b7.deck.hand, "c001"))
	_check(GameState.planeswalker_loyalty() == 4, "jogar uma carta vermelha devia dar +1 lealdade")
	b7.end_turn()
	_check(b7.use_planeswalker(1) and GameState.planeswalker_loyalty() == 2 and is_equal_approx(b7.pw_mult_add, 10.0), "−2 devia custar 2 de lealdade e dar +10 Mult")
	var pw_steps := b7.preview_attack().steps.filter(func(st): return st.source_kind == "planeswalker")
	_check(pw_steps.size() == 1 and is_equal_approx(pw_steps[0].value, 10.0), "o planeswalker devia aparecer na cascata com +10 Mult")
	var b7b := BattleManager.new()
	b7b.restore(b7.to_dict())
	_check(is_equal_approx(b7b.pw_mult_add, 10.0) and b7b.pw_used_this_turn, "estado do planeswalker devia gravar")
	# Escudo do paladino: o inimigo não contra-ataca.
	GameState.set_planeswalker("pw_white")
	GameState.planeswalker["loyalty"] = 6
	var b8 := _battle_with(["c039"], [], ["c040"], 3, 6, 5)
	var hp_before := GameState.player_hp
	_check(b8.use_planeswalker(2) and b8.pw_shield and int(b8.preview_enemy_phase()["damage"]) == 0, "−6 do paladino devia bloquear o contra-ataque")
	b8.end_turn()
	_check(GameState.player_hp == hp_before, "com escudo o jogador não devia levar dano")
	_check(Stats.get_stat("pw_ultimates") >= 1, "a habilidade −6 devia contar")
	# --- Selos Planares ---
	GameState.new_run("deck01", 10, 8)
	_check(GameState.stake == 8 and GameState.hand_size_for_battle() == 5 and GameState.discards_for_battle() == 2, "Selo 8 devia dar mão 5 e 2 canalizações")
	GameState.map_choice = {"battle": "scout"}
	_check(GameState.battle_reward(0) == 1, "Selo 2+: Batedor sem ouro base (ante 1 → 1), deu %d" % GameState.battle_reward(0))
	GameState.map_choice = {"battle": "guard"}
	_check(GameState.battle_reward(0) == 4 + 1 + 4, "Guarda devia dar +4 ouro")
	GameState.ante = 4
	GameState.climates["2"] = "mana_eclipse"   # clima que não mexe na vida do boss
	var boss := GameState.pick_enemy(4)
	var expected := int(round(GameState.enemy_hp_for_ante(4) * 0.85 * 1.35))
	_check(int(boss["hp"]) == expected, "Selo 3: boss do ante 4 devia ter %d de vida, tem %d" % [expected, int(boss["hp"])])
	var b9 := BattleManager.new()
	b9.start(boss)
	_check(b9.deck.hand.size() == 5 and b9.discards_left <= 2, "batalha com Selo 8 devia respeitar mão 5 e 2 canalizações")
	b9.damage_enemy(int(b9.enemy.hp * 0.6))
	b9.end_turn()
	_check(b9.ascended and not (b9.enemy.get("rule2", {}) as Dictionary).is_empty(), "abaixo de metade o boss devia ascender (2.ª regra)")
	GameState.map_choice = {"battle": "guard"}
	GameState.ante = 2
	GameState.climates["1"] = "guild_market"   # sem clima que mexa na vida
	var guard := GameState.pick_enemy(2)
	_check(int(guard["hp"]) == int(round(GameState.enemy_hp_for_ante(2) * 1.25)) and String(guard["variant"]) == "guard", "Guarda devia ter +25 % de vida")
	# --- Mapa ---
	GameState.new_run("deck01", 12)
	var o1 := GameState.map_options(1)
	_check(o1["battle"] == ["scout", "guard"] and o1["stop"][0] == "shop" and o1["stop"].size() == 2, "mapa do ante 1 devia oferecer Batedor/Guarda e Loja + outra")
	var o4 := GameState.map_options(4)
	_check(o4["battle"] == ["boss"] and o4["stop"] == ["shop", "merchant"], "ante 4 devia ser boss + Loja/Mercador Cego")
	var plan_a := GameState.map_options(3).duplicate(true)
	GameState.new_run("deck01", 12)
	_check(GameState.map_options(3) == plan_a, "o mapa devia ser determinístico por semente")
	_check(GameState.stop_scene("rest") == "event" and GameState.pending_event == "node_rest", "acampamento devia abrir a cena de evento")
	_check(GameState.stop_scene("merchant") == "shop" and GameState.stop_scene("event") == "event", "paragens deviam mapear para as cenas certas")
	GameState.choose_battle("guard")
	_check(GameState.map_choice["battle"] == "guard" and GameState.map_phase == "battle", "choose_battle devia registar a escolha")
	GameState.next_ante()
	_check(GameState.map_choice.is_empty() and GameState.act_of_ante(2) == 1 and GameState.act_of_ante(3) == 2 and GameState.act_of_ante(9) == 5, "atos da run: 1-2 → I, 3-4 → II, 9+ → V")
	# Relíquias lendárias: fora do sorteio normal; juros a dobrar.
	var saw_legendary := false
	for i in 60:
		var r := CardDB.random_relic_offer(GameState.rng, [])
		if bool(r.get("legendary", false)):
			saw_legendary = true
	_check(not saw_legendary and CardDB.legendary_relics([]).size() == 5, "as 5 relíquias lendárias não deviam sair na loja normal")
	GameState.relic_ids.append("relic_double_tithe")
	GameState.gold = 25
	GameState.interest_ante = 0
	_check(GameState.interest_due() == 10, "Dízimo Dobrado devia dobrar os juros (10), deu %d" % GameState.interest_due())
	# Gravar/retomar v3: planeswalker, níveis, mapa, selo planar, selos nas cartas.
	GameState.new_run("deck02", 13, 3)
	GameState.set_planeswalker("pw_blue")
	GameState.formation_levels = {"band": 1}
	GameState.deck[0]["seal"] = "fury"
	GameState.deck[1]["colors"] = ["blue"]
	GameState.map_options(1)
	GameState.choose_stop("rest")
	GameState.save_run({}, "map")
	GameState.new_run("deck01", 1)
	_check(GameState.load_run(), "load_run v3 falhou")
	_check(GameState.stake == 3 and GameState.planeswalker.get("id", "") == "pw_blue" and GameState.formation_level("band") == 1, "selo planar/planeswalker/níveis não gravaram")
	_check(String(GameState.deck[0].get("seal", "")) == "fury" and GameState.deck[1].get("colors", []) == ["blue"], "selos e cores das cartas não gravaram")
	_check(GameState.map_phase == "stop" and GameState.map_choice.get("stop", "") == "rest" and GameState.map_plan.has("1") and GameState.saved_scene == "map", "estado do mapa não gravou")
	var inst := CardDB.new_instance(String(GameState.deck[1]["id"]), GameState.deck[1])
	_check(inst.data.colors == ["blue"] and inst.data.has_color("blue"), "a cor alterada na Fonte devia aplicar-se à carta")
	GameState.clear_saved_run()
	print("  0.8.0: mulligan, dupla face, selos, recapitular, planeswalker, selos planares, mapa OK")

# ---------------------------------------------------------------------------
# 0.9.0: climas, bosses em 2 fases e regras novas, relíquias de boss, contratos, elites, maldições,
# missões novas, formações de póquer, relíquias que escalam, modo daltónico e gravação v4.
# ---------------------------------------------------------------------------

func _test_090() -> void:
	# --- Clima Planar: sorteio por ato (ato I só climas suaves), determinístico ---
	GameState.new_run("deck01", 41)
	var cl1 := GameState.climate_for_ante(1)
	_check(cl1 != "" and int(CardDB.get_climate(cl1).get("min_act", 1)) == 1, "o clima do ato I devia ser suave (min_act 1), saiu '%s'" % cl1)
	_check(GameState.climate_for_ante(2) == cl1, "os dois antes do mesmo ato partilham o clima")
	var cl2 := GameState.climate_for_ante(3)
	_check(cl2 != "" and cl2 != cl1, "o ato II devia ter outro clima")
	GameState.new_run("deck01", 41)
	_check(GameState.climate_for_ante(1) == cl1 and GameState.climate_for_ante(3) == cl2, "os climas deviam ser determinísticos por semente")
	# Mercado das Guildas: ataque com 2+ cores dá +2 ouro.
	GameState.new_run("deck01", 42)
	var bg := _battle_with([], ["c003", "c039"], [], 3, 6)
	bg.climate = "guild_market"
	var gsteps := bg.preview_attack().steps.filter(func(st): return st.source_kind == "climate" and st.action == "gold")
	_check(gsteps.size() == 1 and is_equal_approx(gsteps[0].value, 2.0), "Mercado das Guildas devia dar +2 ouro com 2 cores")
	# Eco Temporal: a 1.ª criatura ativa duas vezes; o inimigo tem +15 % de vida.
	var be := _battle_with([], ["c003", "c007"], [], 3, 6)
	be.climate = "temporal_echo"
	var first: CardInstance = be.board[0]
	_check(be.preview_attack().steps.any(func(st): return st.source_card == first and st.retrigger), "Eco Temporal devia reativar a 1.ª criatura")
	GameState.new_run("deck01", 43)
	GameState.map_choice = {"battle": "scout"}
	GameState.climates["1"] = "guild_market"
	var hp_plain := int(GameState.pick_enemy(1)["hp"])
	GameState.new_run("deck01", 43)
	GameState.map_choice = {"battle": "scout"}
	GameState.climates["1"] = "temporal_echo"
	var hp_echo := int(GameState.pick_enemy(1)["hp"])
	_check(absf(hp_echo - hp_plain * 1.15) <= 2.0, "Eco Temporal: inimigo com +15 %% de vida (%d → %d)" % [hp_plain, hp_echo])
	# Maré de Éter: feitiços a 0 no turno 1 e +1 nos turnos 4 e 5.
	var ba := _battle_with(["c042"], [], [], 3, 6)
	ba.climate = "aether_tide"
	var spell := _find(ba.deck.hand, "c042")
	_check(ba.effects.cost_of(spell) == 0, "Maré de Éter: feitiços a 0 no turno 1")
	ba.turn = 4
	_check(ba.effects.cost_of(spell) == 2, "Maré de Éter: feitiço de custo 1 devia custar 2 no turno 4, custa %d" % ba.effects.cost_of(spell))
	# Chuva de Meteoros: 3.ª criatura +20 Poder e 2 de dano no fim do turno.
	var bmr := _battle_with([], ["c003", "c007", "c186"], ["c001", "c005"], 3, 6)
	bmr.climate = "meteor_rain"
	var third: CardInstance = bmr.board[2]
	var met := bmr.preview_attack().steps.filter(func(st): return st.source_kind == "climate" and st.source_card == third and st.action == "power_add")
	_check(met.size() == 1 and is_equal_approx(met[0].value, 20.0), "Chuva de Meteoros devia dar +20 Poder à 3.ª criatura")
	bmr.end_turn()
	_check(third.damage == 2 or not (third in bmr.board), "Chuva de Meteoros devia ferir a 3.ª criatura no fim do turno")
	# Eclipse de Mana: mana máxima 5 e +2 Mult por formação.
	var bec := _battle_with([], ["c003", "c007"], [], 3, 6)
	bec.climate = "mana_eclipse"
	var ec := bec.preview_attack()
	var ecl := ec.steps.filter(func(st): return st.source_kind == "climate" and st.action == "mult_add")
	_check(bec.mana_cap() == 5 and ecl.size() == 1 and is_equal_approx(ecl[0].value, 2.0 * ec.formation_ids.size()), "Eclipse de Mana: mana máx. 5 e +2 Mult por formação")
	# Ferrugem de Óleo: relíquias de +Poder/+Mult ×1.5; cartas sem selo −5 Poder.
	GameState.new_run("deck01", 44)
	GameState.add_relic("relic_drum")
	var bo := _battle_with([], ["c003"], [], 3, 6)
	var plain := bo.preview_attack()
	bo.climate = "oil_rust"
	var rust := bo.preview_attack()
	var drum_a := plain.steps.filter(func(st): return st.source_id == "relic_drum")
	var drum_b := rust.steps.filter(func(st): return st.source_id == "relic_drum")
	_check(drum_a.size() == 1 and drum_b.size() == 1 and is_equal_approx(drum_b[0].value, drum_a[0].value * 1.5), "Ferrugem de Óleo: relíquias ×1.5")
	var pa := plain.steps.filter(func(st): return st.source_kind == "creature" and st.action == "power_add")
	var pb := rust.steps.filter(func(st): return st.source_kind == "creature" and st.action == "power_add")
	_check(not pa.is_empty() and not pb.is_empty() and int(pb[0].value) == int(pa[0].value) - 5, "Ferrugem de Óleo: −5 Poder nas cartas sem selo")
	# Lua de Sangue: dia (ímpar) +3 Mult por branca/verde; noite (par) por preta/vermelha; viragens à noite.
	var bb := _battle_with([], ["c003", "c039"], [], 3, 6)
	bb.climate = "blood_moon"
	var day := bb.preview_attack().steps.filter(func(st): return st.source_kind == "climate")
	_check(day.size() == 1 and is_equal_approx(day[0].value, 3.0), "Lua de Sangue (dia): +3 Mult pela carta branca")
	bb.turn = 2
	var night := bb.preview_attack().steps.filter(func(st): return st.source_kind == "climate")
	_check(night.size() == 1 and is_equal_approx(night[0].value, 3.0), "Lua de Sangue (noite): +3 Mult pela carta vermelha")
	GameState.new_run("deck05", 45)
	var bdf := _battle_with(["c304"], [], ["c041", "c042", "c043"], 3, 6)
	bdf.climate = "blood_moon"
	bdf.turn = 2
	bdf.end_turn()
	var flip := _find(bdf.deck.hand, "c304")
	_check(flip != null and flip.transformed, "Lua de Sangue: as cartas de dupla face viram no fim da noite")
	# Areias Escaldantes: a partir do turno 4, ×1.5 Mult.
	var bs := _battle_with([], ["c003"], [], 3, 6)
	bs.climate = "scorching_sands"
	_check(bs.preview_attack().steps.filter(func(st): return st.source_kind == "climate").is_empty(), "Areias Escaldantes: nada antes do turno 4")
	bs.turn = 4
	var sand := bs.preview_attack().steps.filter(func(st): return st.source_kind == "climate" and st.action == "mult_mul")
	_check(sand.size() == 1 and is_equal_approx(sand[0].value, 1.5), "Areias Escaldantes: ×1.5 Mult a partir do turno 4")

	# --- Bosses em 2 fases ---
	GameState.new_run("deck01", 46)
	GameState.ante = 4
	GameState.climates["2"] = "guild_market"
	GameState.map_choice = {"battle": "boss"}
	var bp := BattleManager.new()
	bp.start(GameState.pick_enemy(4))
	var atk0 := bp.enemy_attack()
	var heard := [""]
	var on_phase2 := func(line: String): heard[0] = line
	EventBus.boss_phase2.connect(on_phase2)
	bp.damage_enemy(int(bp.enemy.hp * 0.6))
	bp.end_turn()
	EventBus.boss_phase2.disconnect(on_phase2)
	_check(bp.phase2 and bp.enemy_attack() >= atk0 + BattleManager.PHASE2_ATTACK, "abaixo de metade o boss devia despertar com +2 de ataque")
	_check(heard[0] != "", "o boss devia dizer uma fala ao despertar")
	_check(not bp.ascended, "sem Selo 8 o boss não devia ativar a 2.ª regra")
	var bp2 := BattleManager.new()
	bp2.restore(bp.to_dict())
	_check(bp2.phase2, "o despertar devia gravar")
	# Regras dos bosses novos.
	GameState.new_run("deck01", 47)
	var bh := _battle_with([], [], [], 3, 6, 3, 5, ["c001", "c003", "c005", "c007", "c186", "c193"])
	bh.rule = {"attack_per_graveyard": 3}
	_check(bh.enemy_attack() == 5, "Hidra: +1 de ataque por cada 3 cartas no cemitério (devia ser 5, é %d)" % bh.enemy_attack())
	var bf := _battle_with(["c001", "c003", "c005"], [], ["c007", "c186"], 3, 6)
	bf.rule = {"gold_tax": 1}
	GameState.gold = 10
	bf.discard(bf.deck.hand[0])
	_check(GameState.gold == 9, "Falsário: canalizar devia custar 1 ouro")
	var bt := _battle_with(["c005"], ["c001", "c003", "c007"], [], 3, 9)
	bt.rule = {"max_creatures": 3}
	_check(bt.max_creatures() == 3 and not bt.can_play(_find(bt.deck.hand, "c005")), "Titã de Cinza: só 3 lugares na Arena")
	var bem := _battle_with(["c042", "c005"], [], [], 3, 9)
	bem.rule = {"spell_cost_plus": 1, "creature_cost_minus": 1}
	_check(bem.effects.cost_of(_find(bem.deck.hand, "c042")) == 2 and bem.effects.cost_of(_find(bem.deck.hand, "c005")) == 1, "Imperatriz: feitiços +1, criaturas −1")
	var bd := _battle_with([], ["c001", "c003"], ["c005", "c007"], 3, 6)
	bd.rule = {"exile_rightmost": true}
	var rightmost: CardInstance = bd.board[1]
	bd.end_turn()
	_check(not (rightmost in bd.board) and rightmost in bd.deck.exile, "Devorador: a criatura mais à direita devia ir para o exílio")

	# --- Relíquias de boss e Baú de Espólio ---
	GameState.new_run("deck01", 48)
	GameState.ante = 4
	var offer := GameState.prepare_loot().duplicate()
	_check(offer.size() == 3 and offer.all(func(id): return bool(CardDB.relics[id].get("boss", false))), "o Baú devia oferecer 3 relíquias de boss")
	_check(GameState.prepare_loot() == offer, "a oferta do Baú devia ser determinística")
	var max0 := GameState.player_max_hp
	_check(GameState.add_boss_relic("relic_zero_mask") and GameState.player_max_hp == max0 - 5, "Máscara do Zero devia tirar 5 de vida máxima")
	_check(GameState.relic_ids.is_empty() and "relic_zero_mask" in GameState.active_relic_ids(), "as relíquias de boss ficam à parte mas estão ativas")
	var disc0 := GameState.discards_for_battle()
	GameState.add_boss_relic("relic_usurper_crown")
	_check(GameState.discards_for_battle() == disc0 - 1 and is_equal_approx(GameState.relic_passive("mana_plus"), 1.0), "Coroa do Usurpador: +1 mana, −1 canalização")
	var hand0 := GameState.hand_size_for_battle()
	GameState.add_boss_relic("relic_thousand_lids")
	_check(GameState.hand_size_for_battle() == hand0 + 1, "Mil Pálpebras: +1 carta na mão")
	_check(GameState.shop_price(5) == 5, "sem o Cálice os preços são os normais")
	GameState.add_boss_relic("relic_abyss_chalice")
	_check(GameState.shop_price(5) == 7, "Cálice do Abismo: preços +2")
	GameState.add_boss_relic("relic_glass_heart")
	var bgh := _battle_with([], [], [], 3, 6)
	GameState.player_hp = 5
	bgh.lose_life(50)
	_check(GameState.player_hp == 1 and GameState.death_save_used, "Coração de Vidro devia deixar-te com 1 de vida")
	bgh.lose_life(50)
	_check(GameState.player_hp <= 0, "o Coração de Vidro só salva uma vez")
	GameState.player_hp = GameState.player_max_hp
	GameState.map_choice = {"battle": "guard"}
	var r0 := GameState.battle_reward(0)
	GameState.add_boss_relic("relic_black_sand")
	_check(GameState.battle_reward(0) == maxi(0, r0 - 3), "Areia Negra: −3 ouro por vitória")
	GameState.ante = 1
	GameState.map_choice = {"battle": "scout"}
	var bbs := BattleManager.new()
	bbs.start(GameState.pick_enemy(1))
	_check(bbs.extra_turns >= 1, "Areia Negra devia dar um turno extra")
	_check(Stats.get_stat("boss_relics") >= 6, "relíquias de boss deviam contar")

	# --- Contratos ---
	GameState.new_run("deck01", 49)
	GameState.set_contract("swift")
	var bc := _battle_with([], [], [], 3, 6)
	bc.turn = 2
	var g0 := GameState.gold
	var res := GameState.resolve_contract(bc, true)
	_check(bool(res.get("success", false)) and GameState.gold == g0 + 10 and GameState.contract.is_empty(), "Contrato: vencer até ao turno 3 devia dar +10 ouro")
	GameState.set_contract("clean_hands")
	bc.discards_used = 1
	_check(not bool(GameState.resolve_contract(bc, true).get("success", true)), "Mãos Limpas falha se canalizaste")
	GameState.set_contract("untouched")
	bc.life_lost = 0
	_check(not bool(GameState.resolve_contract(bc, false).get("success", true)), "um contrato falha sempre numa derrota")
	_check(Stats.get_stat("contracts_done") >= 1, "contratos cumpridos deviam contar")

	# --- Mapa: Elite, Quadro de Contratos e Tribunal ---
	var saw := {}
	for sd in range(100, 160):
		GameState.new_run("deck01", sd)
		for a in [2, 3, 5, 6, 7]:
			var o := GameState.map_options(a)
			for k in o["battle"] + o["stop"]:
				saw[String(k)] = true
	_check(saw.has("elite") and saw.has("contracts") and saw.has("tribunal"), "o mapa devia ter Elite, Quadro de Contratos e Tribunal (viu %s)" % str(saw.keys()))
	_check(GameState.stop_scene("contracts") == "event" and GameState.pending_event == "node_contracts", "o Quadro de Contratos devia abrir a cena de evento")
	_check(GameState.stop_scene("tribunal") == "event" and GameState.pending_event == "node_tribunal", "o Tribunal devia abrir a cena de evento")
	GameState.pending_event = ""
	# Elite: +60 % de vida, +2 de ataque, +6 ouro e relíquia garantida.
	GameState.new_run("deck01", 50)
	GameState.ante = 3
	GameState.climates["2"] = "guild_market"
	GameState.map_choice = {"battle": "scout"}
	var sc := GameState.pick_enemy(3)
	GameState.new_run("deck01", 50)
	GameState.ante = 3
	GameState.climates["2"] = "guild_market"
	GameState.map_choice = {"battle": "elite"}
	var el := GameState.pick_enemy(3)
	_check(absf(int(el["hp"]) - int(sc["hp"]) * 1.6) <= 2.0 and int(el["attack"]) == int(sc["attack"]) + 2 and String(el["variant"]) == "elite", "Elite: +60 %% de vida e +2 de ataque")
	_check(GameState.battle_reward(0) == 4 + 3 + 6, "Elite devia dar +6 ouro (deu %d)" % GameState.battle_reward(0))
	var bel := BattleManager.new()
	bel.start(el)
	var relics0 := GameState.relic_ids.size()
	bel.damage_enemy(int(bel.enemy.hp))
	bel.end_turn()
	_check(bel.finished and bel.elite_relic != "" and GameState.relic_ids.size() == relics0 + 1, "vencer uma Elite devia dar uma relíquia")
	_check(Stats.get_stat("elites") >= 1, "elites vencidas deviam contar")

	# --- Maldições e missões novas ---
	GameState.new_run("deck01", 51)
	GameState.add_card("c314")
	var bcu := _battle_with(["c314", "c001"], [], ["c003"], 3, 6)
	var curse := _find(bcu.deck.hand, "c314")
	_check(curse != null and curse.data.is_curse() and not bcu.can_play(curse) and bcu.can_discard(curse), "a Maldição não se joga, só se canaliza")
	_check(not CardDB.cards_for_colors(["red", "white", "blue", "black", "green"]).any(func(c): return c.is_curse()), "as maldições não deviam sair na loja")
	var b13 := _battle_with(["c313"], [], ["c001", "c003"], 3, 6)
	b13.lose_life(5)
	var pact := _find(b13.deck.hand, "c313")
	_check(pact != null and pact.transformed, "Sangue do Pacto devia virar ao perder 5 de vida")
	var b12 := _battle_with(["c312", "c041"], ["c039", "c040", "c043", "c044"], [], 3, 9)
	b12.play(_find(b12.deck.hand, "c041"))
	var oath := _find(b12.deck.hand, "c312")
	_check(oath != null and oath.transformed, "Juramento do Escudeiro devia virar com a Arena cheia")

	# --- Formações de póquer ---
	GameState.new_run("deck01", 52)
	var f1 := _battle_with([], ["c003", "c007", "c103", "c088"], [], 3, 9).preview_attack().formation_ids
	_check("two_pair" in f1 and not ("pair" in f1), "custos 1-1-3-3 deviam dar Pacto Duplo, deu %s" % str(f1))
	var f2 := _battle_with([], ["c005", "c193", "c235", "c155", "c197"], [], 3, 9).preview_attack().formation_ids
	_check("full_house" in f2 and not ("trips" in f2), "custos 2-2-2-4-4 deviam dar Casa Cheia, deu %s" % str(f2))
	var bq := _battle_with([], ["c001", "c003", "c007", "c186"], [], 3, 9)
	var f3 := bq.preview_attack().formation_ids
	_check("quads" in f3, "custos 1-1-1-1 deviam dar Quadra, deu %s" % str(f3))
	_check(bq.effects.has_formation("trips") and not bq.effects.has_formation("two_pair"), "a Quadra conta como Tríade nas condições das cartas")
	_check(EffectResolver._cost_formation([2, 2], 0) == "two_pair" and EffectResolver._cost_formation([3, 2], 0) == "full_house" and EffectResolver._cost_formation([2, 1], 1) == "trips" and EffectResolver._cost_formation([1, 1, 1], 0) == "", "hierarquia das formações de custo errada")

	# --- Relíquias que escalam ---
	GameState.new_run("deck01", 53)
	GameState.add_relic("relic_hungry_grimoire")
	var bgr := _battle_with(["c001", "c003", "c005"], ["c007"], ["c186", "c193", "c235"], 3, 6)
	bgr.discard(_find(bgr.deck.hand, "c001"))
	bgr.discard(_find(bgr.deck.hand, "c003"))
	_check(GameState.relic_counter("relic_hungry_grimoire") == 2, "Grimório Faminto devia contar 2 canalizações")
	var grs := bgr.preview_attack().steps.filter(func(st): return st.source_id == "relic_hungry_grimoire")
	_check(grs.size() == 1 and is_equal_approx(grs[0].value, 20.0), "Grimório Faminto devia dar +20 Poder com 2 canalizações")
	_check(GameState.relic_scaling_text("relic_hungry_grimoire").contains("20"), "a relíquia devia mostrar o valor atual")
	GameState.add_relic("relic_collector_prism")
	for i in 3:
		GameState.add_card("c001")
	var prs := bgr.preview_attack().steps.filter(func(st): return st.source_id == "relic_collector_prism")
	_check(prs.size() == 1 and is_equal_approx(prs[0].value, 1.3), "Prisma do Colecionador: ×1.3 com 3 cartas novas")
	GameState.add_relic("relic_scar_collection")
	bgr.lose_life(5)
	var scs := bgr.preview_attack().steps.filter(func(st): return st.source_id == "relic_scar_collection")
	_check(GameState.relic_counter("relic_scar_collection") == 5 and scs.size() == 1 and is_equal_approx(scs[0].value, 2.0), "Coleção de Cicatrizes: +2 Mult com 5 de vida perdida")
	GameState.add_relic("relic_victory_standard")
	GameState.bump_relic_counters("battle_won")
	_check(GameState.relic_counter("relic_victory_standard") == 1, "Estandarte das Vitórias devia contar a vitória")
	GameState.remove_relic("relic_victory_standard")
	_check(not GameState.relic_counters.has("relic_victory_standard"), "vender a relíquia devia apagar o contador")

	# --- Modo daltónico ---
	Settings.colorblind = true
	var pip := CardIcon.pip("red")
	_check(pip.mana_color == "red" and pip.custom_minimum_size.x >= 16.0, "modo daltónico: pip maior e com o símbolo da cor")
	pip.free()
	Settings.colorblind = false

	# --- Gravar/retomar v4 ---
	GameState.add_boss_relic("relic_glass_heart")
	GameState.set_contract("army")
	GameState.climates["1"] = "aether_tide"
	GameState.interlude_key = "1"
	GameState.death_save_used = true
	var counters := GameState.relic_counters.duplicate()
	GameState.save_run({}, "map")
	GameState.new_run("deck02", 1)
	_check(GameState.load_run(), "load_run v4 falhou")
	_check("relic_glass_heart" in GameState.boss_relics and String(GameState.contract.get("id", "")) == "army" and String(GameState.climates.get("1", "")) == "aether_tide", "relíquias de boss, contrato e climas deviam gravar")
	_check(GameState.interlude_key == "1" and GameState.death_save_used and GameState.relic_counters == counters, "interlúdio, Coração de Vidro e contadores das relíquias deviam gravar")
	GameState.clear_saved_run()
	# --- Atualização da app (Releases do GitHub) ---
	var rel := {"name": "Zero-Sum 0.10.0", "tag_name": "v0.10.0-b12", "body": "code=10\n\nZero-Sum 0.10.0\nNovo: coisas.",
		"assets": [{"name": "ZeroSum.apk", "browser_download_url": "https://github.com/DaewonPT/ArcanaRun/releases/download/v0.10.0-b12/ZeroSum.apk"}]}
	var up := AppUpdate.parse_release(rel)
	_check(int(up.get("code", 0)) == 10 and String(up.get("apk", "")).ends_with("ZeroSum.apk") and String(up.get("notes", "")).contains("Novo") and String(up.get("name", "")) == "Zero-Sum 0.10.0", "AppUpdate devia ler versionCode, APK, nome e notas da Release")
	rel["assets"][0]["browser_download_url"] = "https://example.com/ZeroSum.apk"
	_check(AppUpdate.parse_release(rel).is_empty(), "AppUpdate só aceita APKs do repositório do jogo")
	_check(AppUpdate.parse_release({"body": "sem código", "assets": []}).is_empty(), "sem code= não há atualização")
	print("  0.9.0: climas, bosses em 2 fases, relíquias de boss, contratos, elites, maldições, formações de póquer, relíquias que escalam, gravação v4 OK")

func _test_scenes_090() -> void:
	Settings.anim_speed = "instant"
	# Baú de Espólio: 3 relíquias de boss; escolher uma dá-a e segue para o mapa.
	GameState.new_run("deck01", 60)
	GameState.ante = 4
	GameState.map_phase = "stop"
	GameState.prepare_loot()
	var loot = load("res://scenes/loot/Loot.tscn").instantiate()
	add_child(loot)
	await get_tree().process_frame
	var cards_box: HBoxContainer = loot.get("_cards")
	_check(cards_box != null and cards_box.get_child_count() == 3, "o Baú devia mostrar 3 relíquias")
	var pick_id := GameState.loot_offer[0]
	SceneRouter._busy = true   # go() não troca de cena durante o teste
	loot._on_pick(pick_id)
	await get_tree().create_timer(0.2).timeout
	SceneRouter._busy = false
	_check(pick_id in GameState.boss_relics and GameState.loot_offer.is_empty(), "escolher no Baú devia dar a relíquia de boss")
	_check(GameState.load_run() and GameState.saved_scene == "map" and pick_id in GameState.boss_relics, "depois do Baú a run devia ficar gravada no mapa")
	loot.queue_free()
	await get_tree().process_frame
	# Tribunal dos Deuses: paga, gira a roda (instantânea) e aplica o resultado.
	GameState.new_run("deck01", 61)
	GameState.add_gold(20)
	GameState.pending_event = "node_tribunal"
	var trib = load("res://scenes/event/Event.tscn").instantiate()
	add_child(trib)
	await get_tree().process_frame
	var spins0 := Stats.get_stat("tribunal_spins")
	var lines: Array[String] = []
	await trib._gamble({"gamble": "gold", "cost": 8}, lines)
	_check(Stats.get_stat("tribunal_spins") == spins0 + 1 and lines.size() >= 3 and GameState.pending_event == "", "o Tribunal devia cobrar, girar a roda e aplicar o resultado")
	trib.queue_free()
	SceneRouter.close_overlays()
	await get_tree().process_frame
	# Batalha 0.9.0: chips de clima e contrato, relíquia de boss na barra, marca de metade, intenção em ícones,
	# detalhe da cascata e despertar do boss.
	GameState.new_run("deck05", 62)
	GameState.ante = 4
	GameState.climates["2"] = "blood_moon"
	GameState.set_contract("swift")
	GameState.add_boss_relic("relic_abyss_chalice")
	GameState.choose_battle("boss")
	var bs = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(bs)
	EventBus.battle_ended.disconnect(bs._on_battle_ended)
	await get_tree().process_frame
	await get_tree().process_frame
	var bmb: BattleManager = bs.get_node("BattleManager")
	_check(bmb.climate == "blood_moon" and bs._climate_chip != null and bs._contract_chip != null, "a batalha devia mostrar os chips de clima e de contrato")
	_check(bs._relic_views.has("relic_abyss_chalice"), "as relíquias de boss deviam aparecer na barra de cima")
	_check(bs._hp_marker != null and bs._intent_row.get_child_count() >= 1, "boss: marca de metade da vida e intenção em ícones")
	for i in 3:
		var hand_box: Container = bs.get_node("%Hand")
		for v in hand_box.get_children():
			if v is CardView and bmb.can_play(v.card) and not v.card.data.is_land():
				_tap_play(v)
				break
		await get_tree().process_frame
	bs._open_breakdown()
	_check(SceneRouter.top_overlay() is CascadeBreakdown or bmb.preview_attack().is_empty(), "tocar no cálculo devia abrir o detalhe da cascata")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	bmb.damage_enemy(int(bmb.enemy.hp * 0.7))
	var t0 := bmb.turn
	bs._on_end_turn()
	var started := Time.get_ticks_msec()
	while bmb.turn == t0 and not bmb.finished and Time.get_ticks_msec() - started < 8000:
		await get_tree().process_frame
	_check(bmb.phase2 or bmb.finished, "o boss devia despertar abaixo de metade da vida")
	bs.queue_free()
	await get_tree().process_frame
	SceneRouter.close_overlays()
	GameState.clear_saved_run()
	Settings.anim_speed = "normal"
	print("  0.9.0: Baú de Espólio, Tribunal, chips, marca do boss, intenção, detalhe da cascata e despertar OK")

## Procura, na árvore de `root`, um nó que cumpra `pred` (para as cenas montadas em código).
func _find_node(root: Node, pred: Callable) -> Node:
	if root == null:
		return null
	if pred.call(root):
		return root
	for c in root.get_children():
		var hit := _find_node(c, pred)
		if hit != null:
			return hit
	return null

func _has_text(root: Node, prefix: String) -> bool:
	return _find_node(root, func(n: Node): return (n is Label or n is Button) and String(n.get("text")).begins_with(prefix)) != null

func _has_text_in(root: Node, part: String) -> bool:
	return _find_node(root, func(n: Node): return (n is Label or n is Button) and String(n.get("text")).contains(part)) != null

func _wait_until(cond: Callable, timeout_ms: int = 8000) -> bool:
	var t0 := Time.get_ticks_msec()
	while not cond.call() and Time.get_ticks_msec() - t0 < timeout_ms:
		await get_tree().process_frame
	return cond.call()

## 0.10.0 (cenas): Novidades, Configurações por separadores, exportar/importar, escala e bateria,
## História, Desafios, menu, Némesis no mapa, janela de Reação, Treino (Reforço, aviso e resultado)
## e resumo do fim da run.
func _test_scenes_0100() -> void:
	var old_lang := Settings.language
	Settings.language = "pt"   # os textos procurados abaixo estão em português
	Settings.anim_speed = "instant"
	Settings.apply()
	var saved_progress: Dictionary = GameState.progress.duplicate(true)
	# --- Novidades: abrem uma vez depois de atualizar ---
	GameState.progress["news_seen"] = ""
	NewsOverlay.maybe_show()
	await get_tree().process_frame
	var nv := String(NewsOverlay.current().get("version", ""))
	_check(nv == "0.14.1", "as Novidades deviam ser da 0.14.1 (são %s)" % nv)
	_check(SceneRouter.top_overlay() is NewsOverlay and String(GameState.progress.get("news_seen", "")) == nv, "as Novidades deviam abrir na 1.ª vez depois de atualizar")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	NewsOverlay.maybe_show()
	await get_tree().process_frame
	_check(not SceneRouter.has_overlay(), "as Novidades não deviam abrir outra vez")
	# --- Configurações: 4 separadores, exportar e importar ---
	var sm := SettingsMenu.open()
	await get_tree().process_frame
	for i in SettingsMenu.TABS.size():
		sm._show_tab(i)
		await get_tree().process_frame
		_check(sm._content.get_child_count() >= 2, "o separador %s devia ter opções" % SettingsMenu.TABS[i])
	GameState.progress["export_probe"] = 7
	var code := Settings.export_code()
	GameState.progress.erase("export_probe")
	_check(code.begins_with("ZS1:") and not Settings.parse_code(code).is_empty(), "o código exportado devia ler-se")
	var broken := code.substr(0, code.length() - 1) + ("1" if code.ends_with("0") else "0")
	_check(Settings.parse_code(broken).is_empty() and Settings.parse_code("ZS1:nada").is_empty(), "um código adulterado devia ser recusado")
	sm._on_import_open()
	var import_btn := Button.new()
	sm._import_edit.text = "ZS1:nada"
	sm._on_import(import_btn)
	_check(sm._import_note.text.begins_with("Código inválido"), "importar um código inválido devia avisar")
	sm._import_edit.text = code
	sm._on_import(import_btn)
	_check(sm._import_note.text.begins_with("Código válido") and not GameState.progress.has("export_probe"), "o 1.º toque em IMPORTAR devia só validar")
	SceneRouter._busy = true   # import → go("main") não troca de cena durante o teste
	sm._on_import(import_btn)
	SceneRouter._busy = false
	_check(int(GameState.progress.get("export_probe", 0)) == 7, "o 2.º toque devia importar o progresso")
	GameState.progress.erase("export_probe")
	import_btn.free()
	SceneRouter.close_overlays()
	await get_tree().process_frame
	# Escala, movimento reduzido e bateria.
	var old_fps := Settings.fps_cap
	var old_scale := Settings.ui_scale
	Settings.fps_cap = 30
	Settings.reduce_motion = true
	Settings.ui_scale = 1.2
	Settings.apply()
	_check(Engine.max_fps == 30 and not Settings.motion_ok(), "30 FPS e reduzir movimento deviam aplicar-se")
	_check(Settings.effective_scale() >= 1.0 and Settings.effective_scale() <= 1.2, "a escala efetiva devia ficar entre 100 e 120 %")
	Settings.fps_cap = old_fps
	Settings.reduce_motion = false
	Settings.ui_scale = old_scale
	Settings.apply()
	# --- História, Desafios e menu ---
	var saga = load("res://scenes/saga/Saga.tscn").instantiate()
	add_child(saga)
	await get_tree().process_frame
	_check(saga._detail.get_child_count() == 1 and _has_text(saga, "Regra: "), "a História devia mostrar o capítulo e a regra")
	saga.queue_free()
	var chs = load("res://scenes/challenges/Challenges.tscn").instantiate()
	add_child(chs)
	await get_tree().process_frame
	var grid := _find_node(chs, func(n: Node): return n is GridContainer) as GridContainer
	_check(grid != null and grid.get_child_count() == CardDB.challenges.size() and CardDB.challenges.size() == 16, "os Desafios deviam mostrar 16 desafios")
	chs.queue_free()
	# Menu em páginas: início (Continuar, Novo Jogo, Modos ›, Coleção ›), Modos de jogo e Coleção.
	GameState.new_run("deck05", 808)
	GameState.ante = 3
	GameState.save_run({}, "map")
	var menu = load("res://scenes/main/Main.tscn").instantiate()
	add_child(menu)
	await get_tree().process_frame
	_check(menu.current_page() == "main" and menu.get_node("%Continue").visible and _has_text(menu.get_node("%Continue"), "Falange Solar  ·  Ante 3"), "o início devia mostrar CONTINUAR com o baralho e o ante")
	_check(not menu.get_node("%Saga").is_visible_in_tree(), "os modos não deviam estar no início")
	menu.get_node("%NewGame").pressed.emit()
	await get_tree().process_frame
	_check(menu.current_page() == "new" and menu.get_node("%Saga").is_visible_in_tree() and menu.get_node("%Challenges").is_visible_in_tree() and menu.get_node("%FreeMode").is_visible_in_tree() and menu.get_node("%QuickRun").is_visible_in_tree(), "NOVO JOGO devia mostrar os modos (História, Desafios, Livre, Run Rápida)")
	_check(_has_text(menu.get_node("%Saga"), "0/%d" % CardDB.saga.size()) and _has_text(menu.get_node("%Challenges"), "0/%d" % CardDB.challenges.size()), "os modos deviam mostrar o progresso (capítulos e medalhas)")
	menu._notification(NOTIFICATION_WM_GO_BACK_REQUEST)
	menu.get_node("%Modes").pressed.emit()
	await get_tree().process_frame
	_check(menu.current_page() == "modes" and menu.get_node("%Training").is_visible_in_tree() and menu.get_node("%School").is_visible_in_tree(), "APRENDER E TREINAR devia mostrar a Escola e o Treino")
	menu._notification(NOTIFICATION_WM_GO_BACK_REQUEST)
	_check(menu.current_page() == "main", "o retroceder numa página devia voltar ao início")
	menu.get_node("%CollectionPage").pressed.emit()
	await get_tree().process_frame
	_check(menu.current_page() == "collection" and menu.get_node("%Builder").is_visible_in_tree() and menu.get_node("%Stats").is_visible_in_tree(), "COLEÇÃO devia mostrar as cartas, o construtor e as estatísticas")
	SceneRouter._busy = true   # go() não troca de cena durante o teste
	menu.get_node("%Stats").pressed.emit()
	SceneRouter._busy = false
	_check(MainMenu.return_page == "collection", "quem sai da Coleção devia voltar a essa página")
	menu.queue_free()
	await get_tree().process_frame
	menu = load("res://scenes/main/Main.tscn").instantiate()
	add_child(menu)
	await get_tree().process_frame
	_check(menu.current_page() == "collection" and MainMenu.return_page == "main", "o menu devia reabrir na página de onde se saiu")
	menu._show_page("main", false)
	GameState.clear_saved_run()
	var news_btn := _find_node(menu, func(n: Node): return n is Button and n.text == "NOVIDADES") as Button
	_check(news_btn != null and not SceneRouter.has_overlay(), "o menu devia ter o botão NOVIDADES (sem abrir sozinho)")
	if news_btn != null:
		news_btn.pressed.emit()
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() is NewsOverlay, "NOVIDADES devia abrir as notas da versão")
	SceneRouter.close_overlays()
	menu.queue_free()
	await get_tree().process_frame
	# --- Némesis no mapa (ante 3, no lugar da Elite) ---
	GameState.free_mode = false
	GameState.new_run("deck01", 31337)
	GameState.ante = 3
	GameState.map_phase = "battle"
	var mp = load("res://scenes/map/Map.tscn").instantiate()
	add_child(mp)
	await get_tree().process_frame
	_check(_has_text(mp, "Némesis · nível"), "o mapa devia mostrar o nó da Némesis no ante 3")
	mp.queue_free()
	await get_tree().process_frame
	# --- Janela de Reação na batalha ---
	GameState.new_run("deck01", 70)
	GameState.choose_battle("scout")
	var rb = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(rb)
	EventBus.battle_ended.disconnect(rb._on_battle_ended)
	await get_tree().process_frame
	await get_tree().process_frame
	var rbm: BattleManager = rb.get_node("BattleManager")
	var faith := CardDB.new_instance("c345")
	var guide := CardDB.new_instance("c001")
	for extra in [guide, faith]:
		extra.zone = CardInstance.Zone.HAND
		rbm.deck.hand.append(extra)
	rbm.mana_available = 1
	rb._refresh_all()
	var hp_r := GameState.player_hp
	var reactions0 := Stats.get_stat("reactions")
	# Aviso opcional: atacar com mana por gastar e uma carta que aumentava o ataque.
	Settings.warn_mana = true
	rb._on_end_turn()
	await get_tree().process_frame
	_check(rb._alive(rb._modal) and _has_text(rb._modal, "Atacar sem gastar a mana?"), "devia avisar antes de atacar com mana e cartas por jogar")
	rb._close_modal("never")
	_check(not Settings.warn_mana, "NÃO AVISAR MAIS devia desligar o aviso")
	var opened: bool = await _wait_until(func(): return rb._alive(rb._modal) and bool(rb._modal.get_meta("reaction", false)))
	_check(opened and _has_text(rb._modal, "NÃO REAGIR"), "devia abrir a janela de Reação antes do contra-ataque")
	if opened:
		rb._close_modal(faith)
		await _wait_until(func(): return rbm.turn >= 2 or rbm.finished)
	_check(GameState.player_hp == hp_r and Stats.get_stat("reactions") == reactions0 + 1, "reagir com o Escudo da Fé devia anular o contra-ataque")
	rb.queue_free()
	await get_tree().process_frame
	SceneRouter.close_overlays()
	# --- Treino: escolher a mão, Reforço, aviso de mana e resultado ---
	GameState.training = {}
	var trn = load("res://scenes/training/Training.tscn").instantiate()
	add_child(trn)
	await get_tree().process_frame
	_check(trn._grid.get_child_count() > 100, "o Treino devia listar as cartas")
	trn._hand.append_array(["c001", "c003", "c339"])
	trn._relics.append("relic_drum")
	trn._mana = 7
	trn._refresh_top()
	_check(trn._hand_row.get_child_count() == 3, "a mão do Treino devia mostrar 3 cartas")
	trn._relic_mode = true
	trn._refresh_list()
	_check(trn._grid.get_child_count() >= 20, "o Treino devia listar as relíquias")
	SceneRouter._busy = true
	trn._start()
	SceneRouter._busy = false
	_check(GameState.puzzle_id == "training" and "relic_drum" in GameState.relic_ids, "TREINAR devia preparar a batalha de treino")
	trn.queue_free()
	await get_tree().process_frame
	var runs0 := Stats.get_stat("runs")
	var tb = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(tb)
	await get_tree().process_frame
	await get_tree().process_frame
	var tbm: BattleManager = tb.get_node("BattleManager")
	_check(tbm.puzzle and int(tbm.enemy.hp) == GameState.TRAINING_HP and tb.enemy_hp_label.text == "∞", "o boneco de treino devia ter vida infinita")
	var hand_box: Container = tb.get_node("%Hand")
	for v in hand_box.get_children():
		if v is CardView and v.card.data.id == "c001":
			_tap_play(v)
	await get_tree().process_frame
	var fire: CardInstance = null
	for v in hand_box.get_children():
		if v is CardView and v.card.data.id == "c339":
			fire = v.card
			_tap_play(v)
	await get_tree().process_frame
	_check(fire != null and tb._alive(tb._modal) and _has_text(tb._modal, "COM REFORÇO"), "a Bola de Fogo devia perguntar se vai com Reforço")
	tb._close_modal("kick")
	await get_tree().process_frame
	_check(fire != null and fire.kicked and fire in tbm.spells_this_turn and tbm.mana_available == 3, "escolher COM REFORÇO devia jogar a carta com Reforço: 7 − 1 − (1 + 2) = 3 de mana (há %d)" % tbm.mana_available)
	tb._on_end_turn()   # no Treino (e nos enigmas) não há aviso de mana por gastar
	var result_open: bool = await _wait_until(func(): return tb._alive(tb._modal) and _has_text(tb._modal, "REPETIR"))
	_check(result_open and tbm.best_hit > 0 and _has_text(tb._modal, "Dano do ataque: "), "o Treino devia acabar com o dano e REPETIR / EDITAR / SAIR")
	_check(Stats.get_stat("runs") == runs0, "o Treino não devia contar como run")
	tb.queue_free()
	await get_tree().process_frame
	GameState.puzzle_id = ""
	Settings.warn_mana = false
	# --- Resumo do fim da run (capítulo da História vencido) ---
	GameState.new_saga_run("saga_white", 21)
	GameState.ante = GameState.max_ante
	GameState.last_victory = true
	GameState.run_log = {"damage_by_ante": {"1": 4000, "2": 9000, "3": 30000, "4": 120000}, "card_dmg": {"c001": 50000, "c315": 20000}, "relic_dmg": {"relic_drum": 8000}, "best_hit": 90000}
	var ro = load("res://scenes/ui/RunOver.tscn").instantiate()
	add_child(ro)
	await get_tree().process_frame
	_check(_find_node(ro, func(n: Node): return n is CardView and n.card != null and n.card.data.id == "c001") != null, "o resumo devia mostrar a carta MVP")
	_check(_find_node(ro, func(n: Node): return n is DamageChart) != null and _has_text(ro, "Maior golpe: "), "o resumo devia ter o maior golpe e o gráfico por ante")
	_check((ro.get_node("%Campaign") as Button).text == "HISTÓRIA" and GameState.saga_done("saga_white"), "vencer o capítulo devia voltar à História e marcá-lo como feito")
	ro.queue_free()
	await get_tree().process_frame
	GameState.progress = saved_progress
	Stats._ensure()
	GameState.save_progress()
	GameState.clear_saved_run()
	Settings.anim_speed = "normal"
	Settings.language = old_lang
	Settings.apply()
	Settings.save_settings()
	print("  0.10.0: Novidades, separadores, exportar/importar, História, Desafios, menu, Némesis no mapa, Reação, Treino, Reforço, aviso e resumo OK")

# ---------------------------------------------------------------------------
# 0.11.0: tipos de carta, palavras-chave, bosses que mexem nas cartas, dificuldade, talentos,
# dicas, Escola do Mago e o maior golpe.
# ---------------------------------------------------------------------------

## Todos os scripts do projeto compilam (um erro de parse num script que só se carrega mais tarde
## não aparecia no resultado do teste).
func _test_scripts_load() -> void:
	var bad: Array[String] = []
	var count := 0
	for dir in ["res://scripts", "res://scenes", "res://tests"]:
		for path in _gd_files(dir):
			count += 1
			var scr = load(path)
			if not (scr is GDScript) or not (scr as GDScript).can_instantiate():
				bad.append(path)
	_check(count > 50 and bad.is_empty(), "scripts que não compilam: %s" % ", ".join(PackedStringArray(bad)))
	print("  scripts: os %d compilam OK" % count)

func _gd_files(dir: String) -> Array[String]:
	var out: Array[String] = []
	var d := DirAccess.open(dir)
	if d == null:
		return out
	d.list_dir_begin()
	var f := d.get_next()
	while f != "":
		if d.current_is_dir():
			if not f.begins_with("."):
				out.append_array(_gd_files(dir + "/" + f))
		elif f.ends_with(".gd"):
			out.append(dir + "/" + f)
		f = d.get_next()
	d.list_dir_end()
	return out

## Há um Label/Button/RichTextLabel com este texto em qualquer parte (não só no início)?
func _contains_text(root: Node, needle: String) -> bool:
	return _find_node(root, func(n: Node):
		if n is Label or n is Button:
			return String(n.get("text")).contains(needle)
		if n is RichTextLabel:
			return (n as RichTextLabel).get_parsed_text().contains(needle)
		return false) != null

## Melhor ataque possível numa lição: todas as ordens de jogar a mão, com ou sem Reforço.
func _lesson_best(def: Dictionary, allow_kick: bool, allow_fb: bool = true, allow_pw: bool = true) -> int:
	GameState.planeswalker = {}
	if String(def.get("planeswalker", "")) != "":
		GameState.planeswalker = {"id": String(def["planeswalker"]), "loyalty": int(def.get("loyalty", 2))}
	var bm := BattleManager.new()
	bm.start_puzzle(def)
	var best := [0]
	_lesson_dfs(bm, best, allow_kick, allow_fb, allow_pw)
	bm.free()
	GameState.planeswalker = {}
	return best[0]

## Todas as sequências de jogadas de um turno (cartas, Reforço, Recapitular e planeswalker): o melhor ataque.
func _lesson_dfs(bm: BattleManager, best: Array, allow_kick: bool, allow_fb: bool = true, allow_pw: bool = true) -> void:
	best[0] = maxi(best[0], bm.preview_attack().total())
	var snap := bm.snapshot()
	var tried := {}
	for c in bm.deck.hand.duplicate():
		if not bm.can_play(c) or tried.has(c.data.id):
			continue
		tried[c.data.id] = true
		for kick in ([false, true] if allow_kick and bm.can_kick(c) else [false]):
			var inst := _find(bm.deck.hand, c.data.id)
			if inst == null:
				continue
			bm.play(inst, kick)
			_lesson_dfs(bm, best, allow_kick, allow_fb, allow_pw)
			bm.restore_snapshot(snap)
			bm.puzzle = true
	if allow_fb:
		for c in bm.flashback_cards().duplicate():
			if bm.can_flashback(c):
				bm.play_flashback(_find(bm.deck.graveyard, c.data.id))
				_lesson_dfs(bm, best, allow_kick, allow_fb, allow_pw)
				bm.restore_snapshot(snap)
				bm.puzzle = true
	if allow_pw and not GameState.planeswalker.is_empty():
		for i in bm.planeswalker_skills().size():
			if bm.can_use_planeswalker(i):
				bm.use_planeswalker(i)
				_lesson_dfs(bm, best, allow_kick, allow_fb, allow_pw)
				bm.restore_snapshot(snap)
				bm.puzzle = true

func _test_0110() -> void:
	var saved_progress: Dictionary = GameState.progress.duplicate(true)
	var saved_difficulty := GameState.difficulty
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	GameState.difficulty = "normal"
	Stats._ensure()
	GameState.free_mode = false
	GameState.new_run("deck05", 1101)
	GameState.relic_ids.clear()
	GameState.player_max_hp = 20
	GameState.player_hp = 20
	# --- Tipos e textos das cartas ---
	var with_kw := 0
	var bad_text: Array[String] = []
	var siglas := RegEx.create_from_string("\\((SP|MG|LD|CR|Retrigger)\\)|\\bPod\\b")
	for id in CardDB.cards:
		var cd: CardData = CardDB.cards[id]
		if not cd.keywords.is_empty():
			with_kw += 1
			_check(cd.is_creature(), "%s tem palavras-chave mas não é criatura" % id)
		if siglas.search(cd.text) != null or cd.text.begins_with("Encantamento. ") or cd.text.begins_with("Ficha. "):
			bad_text.append(String(id))
	_check(with_kw >= 31, "pelo menos 31 criaturas deviam ter palavras-chave (têm %d)" % with_kw)
	_check(bad_text.is_empty(), "textos com siglas ou com o tipo repetido: %s" % ", ".join(PackedStringArray(bad_text)))
	_check(CardDB.get_card("c046").keywords_line() == "Vínculo Vital · Vigilância", "o Anjo Matador do Mal devia ter Vínculo Vital e Vigilância (%s)" % CardDB.get_card("c046").keywords_line())
	var kinds := {"c001": "creature", "c339": "sorcery", "c345": "instant", "c331": "enchantment", "c050": "land", "tok_soldier": "token", "c314": "curse"}
	for cid in kinds:
		var tk := CardView.type_key(CardDB.get_card(cid))
		_check(tk == kinds[cid], "a faixa de %s devia ser %s (é %s)" % [cid, kinds[cid], tk])
	# --- Vigilância: bloqueia o contra-ataque sem sofrer dano ---
	var bv := _battle_with([], ["c043"], [], 3, 6, 50)
	var pv := bv.preview_enemy_phase()
	_check(pv["blocker"] == bv.board[0] and bool(pv.get("vigilant", false)), "a pré-visualização devia mostrar o bloqueio com Vigilância")
	var hp_v := GameState.player_hp
	bv.end_turn()
	_check(bv.turn == 2 and bv.board.size() == 1 and bv.board[0].damage == 0 and GameState.player_hp == hp_v, "a Vigilância devia travar 50 de dano sem sofrer nada")
	bv.free()
	# --- Vínculo Vital: cada ataque cura 1 ---
	GameState.player_hp = 15
	var bll := _battle_with([], ["c020"], [], 3, 6)
	var cll := bll.preview_attack()
	_check(cll.heal >= 1 and cll.steps.any(func(st): return st.action == "heal" and st.source_card == bll.board[0]), "o Vínculo Vital devia entrar na cascata a curar")
	bll._apply_cascade(cll)
	_check(GameState.player_hp == 16, "o Vínculo Vital devia curar 1 (vida %d)" % GameState.player_hp)
	bll.free()
	GameState.player_hp = 20
	# --- Proteção: as habilidades e regras do inimigo não lhe tocam ---
	var bp := _battle_with([], ["c031", "c001"], [], 3, 6)
	var hydra := _find(bp.board, "c031")
	var goblin := _find(bp.board, "c001")
	_check(bp.is_protected(hydra) and not bp.is_protected(goblin), "a Hidra de Kalonian devia ter Proteção")
	bp.enemy["abilities"] = [{"trigger": "turn_end", "action": "destroy_strongest"}]
	bp.enemy_abilities.on_turn_end(1)
	_check(hydra in bp.board and not (goblin in bp.board), "destruir a mais forte devia poupar a criatura com Proteção")
	bp.free()
	var bp2 := _battle_with([], ["c001", "c031"], [], 3, 6)
	bp2.rule["exile_rightmost"] = true
	bp2._boss_end_of_turn()
	_check(_find(bp2.board, "c031") != null and _find(bp2.board, "c001") == null, "o Devorador devia exilar a criatura sem Proteção")
	_check(bp2.mirror_best_creature() == null and bp2.mirror_uid == -1, "o Espelho não devia copiar uma criatura com Proteção")
	bp2.free()
	# --- Espelho Vivo: a criatura copiada não dá Poder base no ataque seguinte ---
	var bmr := _battle_with([], ["c001", "c043"], [], 3, 6)
	var mirrored: Array = []
	var on_mirror := func(c): mirrored.append(c)
	EventBus.creature_mirrored.connect(on_mirror)
	bmr.enemy["abilities"] = [{"trigger": "turn_end", "action": "mirror_best"}]
	bmr.enemy_abilities.on_turn_end(1)
	EventBus.creature_mirrored.disconnect(on_mirror)
	var marshal := _find(bmr.board, "c043")
	_check(mirrored.size() == 1 and mirrored[0] == marshal and bmr.mirror_uid == marshal.uid, "o Espelho devia copiar a criatura mais forte (Marechal de Benalia)")
	var cmr := bmr.preview_attack()
	var msteps: Array = cmr.steps.filter(func(st): return st.tag == "mirror")
	_check(msteps.size() == 1 and is_zero_approx(msteps[0].value) and msteps[0].source_card == marshal, "a criatura copiada não devia dar Poder base")
	var bmr2 := BattleManager.new()
	bmr2.restore(bmr.to_dict())
	_check(_find(bmr2.board, "c043") != null and bmr2.mirror_uid == _find(bmr2.board, "c043").uid, "o espelho devia sobreviver a gravar e retomar")
	bmr._apply_cascade(cmr)
	_check(bmr.mirror_uid == -1, "o espelho devia acabar depois do ataque")
	bmr.free()
	bmr2.free()
	# --- Ladra de Grimórios: rouba a carta mais cara da mão ---
	var bth := _battle_with(["c001", "c046", "c003"], [], [], 3, 6)
	var stolen: Array = []
	var on_stolen := func(c): stolen.append(c)
	EventBus.card_stolen.connect(on_stolen)
	bth.enemy["abilities"] = [{"trigger": "turn_end", "action": "steal_card"}]
	bth.enemy_abilities.on_turn_end(1)
	EventBus.card_stolen.disconnect(on_stolen)
	_check(stolen.size() == 1 and stolen[0].data.id == "c046" and _find(bth.deck.hand, "c046") == null and _find(bth.deck.exile, "c046") != null and bth.deck.hand.size() == 2, "a Ladra devia levar a carta mais cara para o exílio")
	bth.free()
	# --- Bosses novos ---
	for bid in ["boss_thief", "boss_mirror", "boss_fog"]:
		var e := CardDB.enemy_def(bid)
		_check(not e.is_empty() and bool(e.get("boss", false)) and String(e.get("text", "")) != "" and (e.get("lines", {}) as Dictionary).size() == 4, "falta o boss %s (ou as falas)" % bid)
	_check(bool((CardDB.enemy_def("boss_fog").get("rule", {}) as Dictionary).get("hide_text", false)), "a Bruxa do Nevoeiro devia esconder o texto")
	# --- Dificuldade (mais fácil desde a 0.11.0) ---
	_check(GameState.enemy_hp_for_ante(1) == 3000 and GameState.enemy_hp_for_ante(4) == 14900 and GameState.enemy_hp_for_ante(8) == 118000, "curva de vida da 0.11.0 no Normal")
	_check(GameState.turns_for_ante(1) == 5 and GameState.discards_for_battle() == 3, "Normal: 5 turnos e 3 canalizações")
	GameState.difficulty = "facil"
	_check(GameState.enemy_hp_for_ante(1) == 2100 and GameState.turns_for_ante(1) == 6 and GameState.discards_for_battle() == 4, "Fácil: 70% da vida, 6 turnos e 4 canalizações")
	_check(GameState.difficulty_text().contains("70%") and GameState.difficulty_text().contains("6 turnos"), "o texto da dificuldade devia dizer o que muda (%s)" % GameState.difficulty_text())
	GameState.difficulty = "dificil"
	_check(GameState.enemy_hp_for_ante(1) == 4500 and GameState.turns_for_ante(1) == 5 and GameState.discards_for_battle() == 2, "Difícil: 150% da vida e 2 canalizações")
	GameState.difficulty = "normal"
	# --- Talentos ---
	GameState.progress["talent_points"] = 30
	_check(GameState.talent_next_cost("t_gold") == 2 and GameState.buy_talent("t_gold") and GameState.talent_level("t_gold") == 1 and GameState.talent_points() == 28, "Bolsa Cheia devia custar 2 pontos")
	_check(GameState.buy_talent("t_gold") and GameState.buy_talent("t_gold") and not GameState.buy_talent("t_gold") and GameState.talent_next_cost("t_gold") == -1, "Bolsa Cheia: 3 níveis no máximo")
	_check(not GameState.buy_talent("t_channel"), "Mão Hábil (nível 3 do Combate) devia estar fechada sem pontos no ramo")
	_check(GameState.buy_talent("t_life") and GameState.buy_talent("t_shop") and GameState.buy_talent("t_power") and GameState.talent_points() == 7, "devia comprar Vigor, Freguês e Treino Base (sobram %d)" % GameState.talent_points())
	_check(not GameState.buy_talent("t_relic"), "sem pontos não devia comprar a Herança")
	_check(Stats.get_stat("talents_bought") == 6 and Stats.is_unlocked("ach_talents"), "6 níveis comprados deviam dar a conquista Grimório Pessoal")
	GameState.new_run("deck05", 1102)
	var g0 := GameState.gold
	var maxhp0 := GameState.player_max_hp
	var disc0 := GameState.discards_for_battle()
	var price0 := GameState.shop_price(5)
	GameState.apply_talents()
	_check(GameState.gold == g0 + 15 and GameState.player_max_hp == maxhp0 + 3 and GameState.player_hp == GameState.player_max_hp, "os talentos deviam dar +15 ouro e +3 de vida no início da run")
	_check(GameState.shop_price(5) == price0 - 1 and GameState.shop_price(1) == 1, "Freguês −1 ouro na loja (mínimo 1)")
	GameState.save_run({}, "map")
	GameState.run_talents = {}
	_check(GameState.load_run() and is_equal_approx(GameState.talent_value("start_gold"), 15.0), "os talentos da run deviam sobreviver a gravar e retomar")
	GameState.clear_saved_run()
	GameState.set_talents_enabled(false)
	GameState.new_run("deck05", 1103)
	var g1 := GameState.gold
	GameState.apply_talents()
	_check(GameState.gold == g1 and GameState.run_talents.is_empty(), "com os talentos desligados não deviam valer")
	GameState.set_talents_enabled(true)
	GameState.new_challenge_run("ch_glass", 9)
	GameState.apply_talents()
	_check(GameState.run_talents.is_empty(), "os talentos não deviam valer nos Desafios")
	GameState.reset_talents()
	_check(GameState.talent_points() == 30 and GameState.talent_level("t_gold") == 0, "DEVOLVER PONTOS devia devolver os 26 pontos gastos")
	GameState.progress["talents"] = {"t_power": 1, "t_relic": 1, "t_heal": 1, "t_channel": 1}
	GameState.new_run("deck05", 1104)
	GameState.relic_ids.clear()
	var disc_before := GameState.discards_for_battle()
	GameState.apply_talents()
	_check(GameState.discards_for_battle() == disc_before + 1, "Mão Hábil devia dar +1 canalização")
	var all_grown := true
	for e in GameState.deck:
		if CardDB.get_card(String(e["id"])).is_creature() and int(e.get("power_bonus", 0)) != 5:
			all_grown = false
	_check(all_grown and GameState.relic_ids.size() == 1, "Treino Base (+5 Poder) e Herança (uma relíquia) deviam valer no início")
	var bboss := BattleManager.new()
	bboss.start({"id": "test_boss", "name": "Boss", "hp": 100, "max_hp": 100, "attack": 0, "text": "", "abilities": [], "boss": true, "rule": {}})
	GameState.player_hp = 10
	GameState.after_battle(bboss, true)
	_check(GameState.player_hp == 15, "Respiro devia curar 5 depois de um boss (vida %d)" % GameState.player_hp)
	bboss.free()
	GameState.progress["talents"] = {}
	GameState.run_talents = {}
	var p0 := GameState.talent_points()
	GameState.new_run("deck05", 1105)
	GameState.record_run_end(5, false)
	_check(GameState.last_talent_points == 4 and GameState.talent_points() == p0 + 4, "cair no ante 5 devia dar 4 pontos de talento")
	GameState.record_run_end(8, true)
	_check(GameState.last_talent_points == 10, "vencer a run devia dar 8 + 2 pontos")
	var p1 := GameState.talent_points()
	GameState.record_run_end(1, false)
	_check(GameState.last_talent_points == 0 and GameState.talent_points() == p1, "abandonar no ante 1 não devia dar pontos")
	GameState.endless = true
	GameState.record_run_end(11, false)
	_check(GameState.last_talent_points == 2, "no fim do Infinito só deviam contar os antes depois do 8 (deu %d)" % GameState.last_talent_points)
	GameState.endless = false
	# --- Dicas ---
	for tid in ["land", "token", "kicker", "reaction", "enchantment", "flashback", "mission", "minion", "shield", "boss", "keyword", "mythic", "curse", "chain", "tribe", "seal", "planeswalker", "climate", "skip", "mirror", "thief", "fog", "nemesis", "voucher"]:
		_check(CardDB.tips.has(tid), "falta a dica '%s'" % tid)
	_check(not GameState.tip_seen("land"), "a dica dos Terrenos ainda não devia estar vista")
	GameState.mark_tip_seen("land")
	GameState.mark_tip_seen("land")
	_check(GameState.tip_seen("land") and (GameState.progress["tips_seen"] as Array).size() == 1, "cada dica só se marca uma vez")
	GameState.reset_tips()
	_check(not GameState.tip_seen("land"), "repor as dicas devia voltar a mostrá-las")
	# --- Escola do Mago: cada lição só se vence com a mecânica que ensina ---
	_check(CardDB.lessons.size() == 13, "a Escola devia ter 13 lições (tem %d)" % CardDB.lessons.size())
	GameState.new_run("deck01", 1106)
	GameState.relic_ids.clear()
	GameState.player_hp = 20
	for l in CardDB.lessons:
		for key in ["hand", "board"]:
			for cid in l.get(key, []):
				_check(CardDB.get_card(String(cid)) != null, "lição %s: a carta %s não existe" % [l.get("id", ""), cid])
		if String(l.get("goal_type", "win")) != "win":
			continue
		var with_best := _lesson_best(l, true)
		var without_def: Dictionary = (l as Dictionary).duplicate(true)
		var allow_kick := true
		var allow_fb := true
		var allow_pw := true
		for w in l.get("without", []):
			if String(w) == "kick":
				allow_kick = false
			elif String(w) == "flashback":
				allow_fb = false
			elif String(w) == "pw":
				allow_pw = false
			else:
				(without_def["hand"] as Array).erase(String(w))
		var without_best := _lesson_best(without_def, allow_kick, allow_fb, allow_pw)
		var lhp := int(l.get("hp", 0))
		_check(with_best >= lhp and without_best < lhp, "lição %s: com a mecânica %d, sem ela %d, vida %d" % [l.get("id", ""), with_best, without_best, lhp])
	GameState.start_lesson("lesson_land")
	_check(GameState.is_lesson_battle() and GameState.puzzle_id == "lesson_land", "começar uma lição devia preparar a batalha da lição")
	GameState.puzzle_id = ""
	for l in CardDB.lessons:
		GameState.mark_lesson_done(String(l.get("id", "")))
	_check(GameState.lesson_done("lesson_land") and Stats.get_stat("lessons") == CardDB.lessons.size() and Stats.is_unlocked("ach_school"), "as lições todas deviam dar a conquista Aluno do Mago")
	# --- O maior golpe guarda-se passo a passo ---
	GameState.new_run("deck01", 1107)
	GameState.relic_ids.clear()
	GameState.run_log = {}
	var bg := _battle_with([], ["c001", "c003", "c321"], [], 3, 6)
	var cg := bg.preview_attack()
	bg._apply_cascade(cg)
	var snap: Dictionary = GameState.run_log.get("best_cascade", {})
	_check(not snap.is_empty() and (snap.get("steps", []) as Array).size() == cg.steps.size() and int(snap.get("total", 0)) == int(GameState.run_log.get("best_hit", -1)) and int(snap.get("total", 0)) > 0, "o maior golpe devia guardar-se passo a passo")
	bg.free()
	GameState.progress = saved_progress
	GameState.difficulty = saved_difficulty
	Stats._ensure()
	GameState.save_progress()
	GameState.free_mode = false
	GameState.clear_saved_run()
	print("  0.11.0: tipos, palavras-chave, Espelho, Ladra, dificuldade, talentos, dicas, lições e maior golpe OK")

## 0.11.0 (cenas): menu (Escola e Talentos), Escola do Mago, lições jogadas no ecrã de batalha,
## Talentos, dicas, saltar a cascata, Nevoeiro, Espelho, Ladra, zoom de Terrenos e palavras-chave,
## Configurações, dificuldade na campanha e Rever o maior golpe.
func _test_scenes_0110() -> void:
	var old_lang := Settings.language
	var old_tips := Settings.tips_enabled
	var saved_difficulty := GameState.difficulty
	Settings.language = "pt"
	Settings.anim_speed = "instant"
	Settings.apply()
	var saved_progress: Dictionary = GameState.progress.duplicate(true)
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal", "talent_points": 4}
	GameState.difficulty = "normal"
	Stats._ensure()
	Stats.set_tutorial_done(true)
	# --- Menu: Escola do Mago nos Modos e Talentos na Coleção ---
	GameState.clear_saved_run()
	var menu = load("res://scenes/main/Main.tscn").instantiate()
	add_child(menu)
	await get_tree().process_frame
	SceneRouter.close_overlays()   # as Novidades abrem sozinhas com o progresso vazio
	await get_tree().process_frame
	menu._show_page("modes", false)
	await get_tree().process_frame
	var school_tile: Control = menu.get_node("%School")
	_check(school_tile.is_visible_in_tree() and _has_text(school_tile, "ESCOLA DO MAGO") and _has_text(school_tile, "0/%d" % CardDB.lessons.size()), "APRENDER E TREINAR devia ter a Escola do Mago (0/N)")
	menu._show_page("collection", false)
	await get_tree().process_frame
	_check(_has_text(menu.get_node("%Talents"), "TALENTOS") and _has_text(menu.get_node("%Talents"), "4 pts"), "a Coleção devia ter os Talentos com os pontos")
	menu._show_page("main", false)
	menu.queue_free()
	await get_tree().process_frame
	MainMenu.return_page = "main"
	# --- Escola do Mago ---
	var school = load("res://scenes/school/School.tscn").instantiate()
	add_child(school)
	await get_tree().process_frame
	var sgrid := _find_node(school, func(n: Node): return n is GridContainer) as GridContainer
	_check(sgrid != null and sgrid.get_child_count() == CardDB.lessons.size() and _has_text(school, "Lições: 0/%d" % CardDB.lessons.size()), "a Escola devia mostrar as lições todas (0/N)")
	if sgrid != null and sgrid.get_child_count() > 0:
		SceneRouter._busy = true
		(sgrid.get_child(0) as Button).pressed.emit()
		SceneRouter._busy = false
		_check(GameState.puzzle_id == "lesson_land", "a 1.ª lição devia ser a dos Terrenos")
	school.queue_free()
	await get_tree().process_frame
	# --- Lição dos Terrenos, jogada no ecrã de batalha ---
	GameState.start_lesson("lesson_land")
	var lb = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(lb)
	await get_tree().process_frame
	await get_tree().process_frame
	var lbm: BattleManager = lb.get_node("BattleManager")
	_check(lbm.puzzle and lb._alive(lb._lesson_panel) and _has_text(lb._lesson_panel, "LIÇÃO · Terrenos"), "a lição devia abrir com a explicação por cima")
	var lhand: Container = lb.get_node("%Hand")
	var lviews: Array = lhand.get_children().filter(func(v): return v is CardView)
	var land_view: CardView = lviews[lviews.size() - 1] if lviews.size() == 2 else null
	_check(land_view != null and land_view.card.data.is_land() and land_view.has_meta("fan_gap_before"), "o Terreno devia ficar no fim da mão, à parte")
	_check(land_view != null and land_view.cost_label.text == "+1" and land_view.type_label.text.begins_with("Terreno") and land_view.stats_label.text == "jogar: +1 mana", "o Terreno devia mostrar +1, o tipo e 'jogar: +1 mana'")
	for id in ["c050", "c040"]:
		var target: CardView = null
		for v in lhand.get_children():
			if v is CardView and not v.is_queued_for_deletion() and v.card.data.id == id:
				target = v
		if target != null:
			_tap_play(target)
		await get_tree().process_frame
	_check(lbm.board.size() == 2, "a Tenente de Thalia devia entrar depois do Terreno (Arena: %d)" % lbm.board.size())
	lb._on_end_turn()
	var lesson_ok: bool = await _wait_until(func(): return lb._alive(lb._modal) and _has_text(lb._modal, "LIÇÃO CONCLUÍDA!"))
	_check(lesson_ok and GameState.lesson_done("lesson_land") and _has_text(lb._modal, "PRÓXIMA LIÇÃO"), "vencer a lição devia marcá-la e oferecer a próxima")
	lb.queue_free()
	await get_tree().process_frame
	# --- Lição da Reação: o objetivo é reagir, não vencer ---
	GameState.start_lesson("lesson_reaction")
	var rl = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(rl)
	await get_tree().process_frame
	await get_tree().process_frame
	var rhand: Container = rl.get_node("%Hand")
	var faith: CardInstance = null
	var leader: CardView = null
	for v in rhand.get_children():
		if v is CardView and v.card.data.id == "c345":
			faith = v.card
		elif v is CardView and v.card.data.id == "c047":
			leader = v
	if leader != null:
		_tap_play(leader)
	await get_tree().process_frame
	rl._on_end_turn()
	var ropen: bool = await _wait_until(func(): return rl._alive(rl._modal) and bool(rl._modal.get_meta("reaction", false)))
	_check(ropen and faith != null, "a lição da Reação devia abrir a janela de Reação")
	if ropen and faith != null:
		rl._close_modal(faith)
	var rdone: bool = await _wait_until(func(): return rl._alive(rl._modal) and _has_text(rl._modal, "LIÇÃO CONCLUÍDA!"))
	_check(rdone and GameState.lesson_done("lesson_reaction"), "reagir devia concluir a lição (mesmo sem vencer)")
	rl.queue_free()
	await get_tree().process_frame
	GameState.puzzle_id = ""
	# --- Talentos ---
	GameState.progress["talent_points"] = 4
	GameState.progress["talents"] = {}
	GameState.progress.erase("talents_off")
	var tl = load("res://scenes/talents/Talents.tscn").instantiate()
	add_child(tl)
	await get_tree().process_frame
	var tiles := 0
	for t in CardDB.talents:
		if tl.find_child("Talent_" + String(t.get("id", "")), true, false) != null:
			tiles += 1
	_check(tiles == CardDB.talents.size() and tl._columns.get_child_count() == 3 and tl._points_label.text == "Pontos: 4", "os Talentos deviam mostrar os 3 ramos com todos os talentos e os pontos")
	var buy := tl.find_child("Talent_t_gold", true, false).find_child("Buy", true, false) as Button
	_check(buy != null and buy.text == "COMPRAR · 2" and not buy.disabled, "Bolsa Cheia devia custar 2")
	if buy != null:
		buy.pressed.emit()
		await get_tree().process_frame
	_check(GameState.talent_level("t_gold") == 1 and tl._points_label.text == "Pontos: 2", "comprar devia subir o nível e gastar os pontos")
	tl._toggle.pressed.emit()
	_check(not GameState.talents_enabled() and tl._toggle.text == "Talentos: DESLIGADOS", "o botão devia desligar os talentos")
	tl._toggle.pressed.emit()
	tl._on_reset()
	_check(tl._reset.text == "TENS A CERTEZA?" and GameState.talent_level("t_gold") == 1, "DEVOLVER PONTOS devia pedir confirmação")
	tl._on_reset()
	_check(GameState.talent_level("t_gold") == 0 and GameState.talent_points() == 4 and GameState.talents_enabled(), "confirmar devia devolver os pontos")
	tl.queue_free()
	await get_tree().process_frame
	# --- Dicas, saltar a cascata, Nevoeiro, Espelho e Ladra numa batalha normal ---
	Settings.tips_enabled = true
	GameState.reset_tips()
	GameState.free_mode = false
	GameState.new_run("deck01", 4711)
	GameState.relic_ids.clear()
	GameState.choose_battle("scout")
	var tb = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(tb)
	EventBus.battle_ended.disconnect(tb._on_battle_ended)
	await get_tree().process_frame
	await get_tree().process_frame
	var tbm: BattleManager = tb.get_node("BattleManager")
	var land := CardDB.new_instance("c008")
	land.zone = CardInstance.Zone.HAND
	tbm.deck.hand.append(land)
	for cid in ["c001", "c003", "c321"]:
		var cr := CardDB.new_instance(cid)
		cr.zone = CardInstance.Zone.BOARD
		tbm.board.append(cr)
	tb._refresh_all()
	await get_tree().process_frame
	_check(tb._alive(tb._tip_panel) and _has_text(tb._tip_panel, "DICA") and GameState.tip_seen("land"), "um Terreno na mão pela 1.ª vez devia mostrar a dica")
	Settings.tips_enabled = false
	GameState.reset_tips()
	tb._tip("land")
	_check(not GameState.tip_seen("land"), "com as dicas desligadas não devia aparecer nenhuma")
	Settings.anim_speed = "normal"
	tb._on_end_turn()
	var started: bool = await _wait_until(func(): return tb._animating, 3000)
	var ev := InputEventMouseButton.new()
	ev.button_index = MOUSE_BUTTON_LEFT
	ev.pressed = true
	var t_skip := Time.get_ticks_msec()
	tb._input(ev)
	var skipped := bool(tb._skip_cascade)
	var finished: bool = await _wait_until(func(): return not tb._animating, 5000)
	_check(started and skipped and finished and Time.get_ticks_msec() - t_skip < 1500, "tocar durante o ataque devia saltar logo para o total (%d ms)" % (Time.get_ticks_msec() - t_skip))
	await _wait_until(func(): return tbm.turn >= 2 and not tbm.resolving, 5000)
	Settings.anim_speed = "instant"
	tbm.rule["hide_text"] = true
	tb._refresh_all()
	await get_tree().process_frame
	var hv: CardView = null
	for v in tb.get_node("%Hand").get_children():
		if v is CardView and not v.is_queued_for_deletion():
			hv = v
			break
	_check(CardView.fog_hand and hv != null and hv.text_label.get_parsed_text() == "???" and hv.name_label.text != "???", "o Nevoeiro devia esconder o texto (não o nome) das cartas na mão")
	var bview: CardView = null
	for v in tb._board_views.values():
		if tb._alive(v):
			bview = v
	_check(bview != null and bview.text_label.get_parsed_text() != "???", "o Nevoeiro não devia esconder as cartas na Arena")
	tbm.rule.erase("hide_text")
	var copied := tbm.mirror_best_creature()
	if copied != null:
		EventBus.creature_mirrored.emit(copied)
	await get_tree().process_frame
	_check(copied != null and tb._board_views.has(copied.uid) and _has_text(tb._board_views[copied.uid], "ESPELHO"), "a criatura copiada devia ter a etiqueta ESPELHO")
	var taken := tbm.steal_best_card()
	if taken != null:
		EventBus.card_stolen.emit(taken)
	await get_tree().process_frame
	_check(taken != null and not tb._hand_views.has(taken.uid) and tb._history.any(func(h): return String(h).contains("Roubada: ")), "a Ladra devia tirar a carta da mão e avisar no registo")
	tb.queue_free()
	await get_tree().process_frame
	_check(not CardView.fog_hand, "o Nevoeiro devia acabar ao sair da batalha")
	Settings.tips_enabled = old_tips
	# --- Zoom: Terreno e palavras-chave explicados ---
	CardZoom.show_data(CardDB.get_card("c050"))
	await get_tree().process_frame
	var zoom := SceneRouter.top_overlay()
	_check(zoom is CardZoom and _contains_text(zoom, "Terreno: jogá-lo é de graça") and (_find_node(zoom, func(n: Node): return n is LandArt) != null or _zoom_has_art(zoom)), "o zoom de um Terreno devia explicá-lo e mostrar a paisagem (desenhada ou a ilustração)")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	CardZoom.show_data(CardDB.get_card("c046"))
	await get_tree().process_frame
	zoom = SceneRouter.top_overlay()
	_check(_contains_text(zoom, "Vínculo Vital · Vigilância") and _contains_text(zoom, "Vigilância: bloqueia o contra-ataque"), "o zoom devia listar e explicar as palavras-chave")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	# --- Configurações e campanha: dificuldade e dicas ---
	var sm := SettingsMenu.open()
	await get_tree().process_frame
	_check(_has_text(sm, "Dicas das mecânicas") and _has_text(sm, "Dificuldade"), "as Configurações deviam ter a Dificuldade e as Dicas das mecânicas")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	GameState.free_mode = false
	var cp = load("res://scenes/campaign/Campaign.tscn").instantiate()
	add_child(cp)
	await get_tree().process_frame
	var dbtn: Button = cp.get_node("%Difficulty")
	_check(dbtn != null and dbtn.text == "DIFICULDADE: NORMAL", "a campanha devia mostrar a dificuldade")
	if dbtn != null:
		dbtn.pressed.emit()
		_check(GameState.difficulty == "dificil" and dbtn.text == "DIFICULDADE: DIFÍCIL", "tocar devia mudar para Difícil")
	cp.queue_free()
	await get_tree().process_frame
	GameState.difficulty = "normal"
	# --- Fim da run: pontos de talento e Rever o maior golpe ---
	GameState.new_run("deck01", 1108)
	GameState.relic_ids.clear()
	GameState.run_log = {}
	var bg := _battle_with([], ["c001", "c003", "c321"], [], 3, 6)
	bg._apply_cascade(bg.preview_attack())
	bg.free()
	var snap: Dictionary = GameState.run_log.get("best_cascade", {})
	GameState.ante = 3
	GameState.last_victory = false
	var ro = load("res://scenes/ui/RunOver.tscn").instantiate()
	add_child(ro)
	await get_tree().process_frame
	_check((ro.get_node("%Detail") as Label).text.contains("Talentos: +2 pontos"), "o fim da run devia dizer os pontos de talento ganhos")
	var replay_btn := _find_node(ro, func(n: Node): return n is Button and n.name == "Replay") as Button
	_check(replay_btn != null and not snap.is_empty(), "o fim da run devia ter ▶ REVER O MAIOR GOLPE")
	if replay_btn != null:
		replay_btn.pressed.emit()
		await get_tree().process_frame
		var rp := SceneRouter.top_overlay()
		_check(rp is CascadeReplay, "o botão devia abrir o replay do maior golpe")
		if rp is CascadeReplay:
			var replay_done: bool = await _wait_until(func(): return rp._done)
			_check(replay_done and rp._total.text == Cascade.fmt_int(int(snap.get("total", 0))) and rp._list.get_child_count() == (snap.get("steps", []) as Array).size(), "o replay devia mostrar os passos todos e acabar no total")
		SceneRouter.close_overlays()
	ro.queue_free()
	await get_tree().process_frame
	GameState.progress = saved_progress
	GameState.difficulty = saved_difficulty
	Stats._ensure()
	GameState.save_progress()
	GameState.clear_saved_run()
	GameState.free_mode = false
	Settings.tips_enabled = old_tips
	Settings.anim_speed = "normal"
	Settings.language = old_lang
	Settings.apply()
	Settings.save_settings()
	print("  0.11.0: menu, Escola, lições, Talentos, dicas, saltar, Nevoeiro, Espelho, Ladra, zoom, dificuldade e replay OK")

const TEST_MANIFEST := "ZSUPD 1\nc 2\nmin 7\nn pt teste de assinatura\nf 015abd7f5cc57a2dd94b7590f04ad8084273905ee33ec5cebeae62276a97f862 7 data/teste.json\nsig MEUCIQCyx0L5sEplwno3v9GYj3yCR4GUQ+/SYSQZttAG8MBlrQIgcv0b2d+Wu7N+Dy4/L5dvlm+26ydRW0UFbNWuyFfm0IM=\n"

## 0.10.0: Fichas, tribos, Cadeias, conjuntos de selos, encantamentos, Reforço, Reação, lacaios,
## escudo, Míticas, cartas "+", Vales, Desafios, História, Némesis, desbloqueios e resumo da run.
func _test_0100() -> void:
	var saved_progress: Dictionary = GameState.progress.duplicate(true)
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	Stats._ensure()
	GameState.new_run("deck05", 4242)
	GameState.relic_ids.clear()
	GameState.player_max_hp = 20
	GameState.player_hp = 20
	# --- Fichas ---
	var bt := _battle_with(["c315", "c316"], [], [], 3, 8)
	_check(bt.play(_find(bt.deck.hand, "c315")), "Chamada da Milícia devia jogar-se")
	_check(bt.board.size() == 2 and bt.board[0].data.token and bt.board[0].power() == 10, "devia criar 2 Fichas de 10 Poder")
	bt.play(_find(bt.deck.hand, "c316"))
	_check(bt.board.size() == 4, "Capitã + 1 Ficha: 4 na Arena (há %d)" % bt.board.size())
	var ct := bt.preview_attack()
	_check(ct.steps.any(func(st): return st.source_kind == "tribe"), "3 Fichas e a Capitã deviam ativar o bónus de Soldados")
	_check(not ("pair" in ct.formation_ids) and not ("trips" in ct.formation_ids), "as Fichas (custo 0) não deviam fazer pactos")
	_check("band" in ct.formation_ids, "as Fichas deviam contar para o Bando")
	var tok: CardInstance = bt.board[0]
	bt.kill_creature(tok)
	_check(not (tok in bt.deck.graveyard) and bt.board.size() == 3, "a Ficha devia desaparecer ao morrer")
	var bt2 := BattleManager.new()
	bt2.restore(bt.to_dict())
	_check(bt2.board.size() == 3 and bt2.board[0].data.token, "as Fichas deviam sobreviver a gravar e retomar")
	bt.free()
	bt2.free()
	# --- Cadeia de cor (3 vermelhas seguidas: ×1.5) ---
	GameState.new_run("deck01", 77)
	GameState.relic_ids.clear()
	var reds: Array = []
	for e in GameState.deck:
		var cd := CardDB.get_card(String(e["id"]))
		if cd.is_creature() and cd.has_color("red") and not (cd.id in reds):
			reds.append(cd.id)
	var bc := _battle_with([], reds.slice(0, 3), [], 3, 6)
	var cc := bc.preview_attack()
	var chain: Array = cc.steps.filter(func(st): return st.source_kind == "chain")
	_check(chain.size() == 1 and is_equal_approx(chain[0].value, 1.5) and cc.chain_len == 3, "3 vermelhas seguidas deviam dar ×1.5 (cadeia %d)" % cc.chain_len)
	bc.free()
	# --- Conjunto de selos (3× Dízimo: +8 ouro) ---
	var sealed: Array = []
	for i in GameState.deck.size():
		var cd := CardDB.get_card(String(GameState.deck[i]["id"]))
		if cd.is_creature() and sealed.size() < 3 and not (cd.id in sealed):
			GameState.deck[i]["seal"] = "tithe"
			sealed.append(cd.id)
	var bs := _battle_with([], sealed.duplicate(), [], 3, 6)
	var cs := bs.preview_attack()
	_check(cs.steps.any(func(st): return st.source_kind == "seal_set") and cs.gold >= 8, "3 cartas com o Selo do Dízimo deviam dar +8 ouro")
	bs.free()
	for e in GameState.deck:
		e.erase("seal")
	# --- Reforço ---
	var bk := _battle_with(["c339"], [], [], 3, 6)
	var fb := _find(bk.deck.hand, "c339")
	_check(bk.can_kick(fb) and bk.preview_play(fb, true) > bk.preview_play(fb), "Bola de Fogo com Reforço devia prever mais dano")
	_check(bk.play(fb, true) and fb.kicked and bk.mana_available == 3, "o Reforço devia custar 1 + 2 de mana (sobram %d)" % bk.mana_available)
	var ck := bk.preview_attack()
	var mult_steps: Array = ck.steps.filter(func(st): return st.action == "mult_add" and st.source_card == fb)
	_check(mult_steps.size() == 2, "com Reforço a Bola de Fogo devia dar +4 e +4 Mult (%d passos)" % mult_steps.size())
	bk.free()
	# --- Encantamentos (máx. 2; entram na cascata; turn_start) ---
	var be := _battle_with(["c331", "c335", "c332"], ["c001"], [], 3, 10)
	_check(be.play(_find(be.deck.hand, "c331")) and be.play(_find(be.deck.hand, "c335")), "2 encantamentos deviam jogar-se")
	_check(be.enchantments.size() == 2 and not be.can_play(_find(be.deck.hand, "c332")), "máximo de 2 encantamentos em jogo")
	_check(be.preview_attack().steps.any(func(st): return st.source_kind == "enchantment"), "os encantamentos deviam entrar na cascata")
	var weak: CardInstance = be.board[0]
	var p0 := weak.power()
	be.next_turn()
	_check(weak.power() == p0 + 8, "o Bosque Ancestral devia fazer crescer a criatura mais fraca (+8)")
	var be2 := BattleManager.new()
	be2.restore(be.to_dict())
	_check(be2.enchantments.size() == 2, "os encantamentos deviam sobreviver a gravar e retomar")
	be.free()
	be2.free()
	# --- Reação (janela antes do contra-ataque) ---
	var br := _battle_with(["c345"], ["c001"], [], 3, 6, 3)
	var hp0 := GameState.player_hp
	var shield := _find(br.deck.hand, "c345")
	_check(br.can_react(shield), "Escudo da Fé devia poder reagir")
	var react := func(opts: Array): EventBus.reaction_done.emit.call_deferred(opts[0])
	EventBus.reaction_window.connect(react)
	br.end_turn()
	for i in 4:
		await get_tree().process_frame
	EventBus.reaction_window.disconnect(react)
	_check(br.turn == 2 and GameState.player_hp == hp0 and br.board[0].damage == 0, "a Reação devia anular o contra-ataque")
	_check(Stats.get_stat("reactions") >= 1, "a Reação devia contar nas estatísticas")
	br.free()
	# --- Lacaios e escudo ---
	var bl := _battle_with([], ["c001", "c003"], [], 3, 6)
	bl.minions.append(2)
	var cl := bl.preview_attack()
	_check(cl.steps[0].tag == "minion" and is_zero_approx(cl.steps[0].value), "o lacaio devia travar o Poder da 1.ª criatura")
	bl.enemy["shield_pct"] = 10.0
	var csh := bl.preview_attack()
	_check(csh.shield == 100000, "escudo de 10%% devia travar 100 000 (travou %d)" % csh.shield)
	_check(csh.net_total() == maxi(0, csh.total() - csh.shield), "o dano líquido devia descontar o escudo")
	bl.enemy["shield_pct"] = 0.0
	bl._apply_cascade(bl.preview_attack())
	_check(bl.minions.size() == 1 and bl.minions[0] == 1, "o lacaio devia gastar um golpe")
	_check(not GameState.run_log.is_empty() and int(GameState.run_log["damage_by_ante"].get(str(GameState.ante), 0)) > 0, "o resumo da run devia registar o dano")
	bl.free()
	# --- Míticas ---
	var bmy := _battle_with([], ["c350", "c001", "c003"], [], 3, 6)
	var cmy := bmy.preview_attack()
	var fsteps: Array = cmy.steps.filter(func(st): return st.source_kind == "formation")
	_check(fsteps.size() == cmy.formation_ids.size() * 2 and fsteps.size() > 0, "o Avatar da Convergência devia ativar as formações duas vezes")
	bmy.free()
	var bmm := _battle_with([], ["c355", "c001"], [], 3, 6)
	var cmm := bmm.preview_attack()
	_check(cmm.steps[cmm.steps.size() - 1].source_kind == "rule" and is_equal_approx(cmm.steps[cmm.steps.size() - 1].value, 1.5), "o Motor do Infinito devia fechar a cascata com ×1.5")
	bmm.free()
	_check(not CardDB.is_available(CardDB.get_card("c350")), "as Míticas deviam estar bloqueadas no início")
	# --- Cartas "+" ---
	var fplus := CardDB.get_card("c339").plus_version()
	_check(fplus.plus and is_equal_approx(float(fplus.effects[0]["value"]), 6.0), "Bola de Fogo+ devia dar +6 Mult")
	_check(fplus.display_text().begins_with("+6 Mult"), "o texto da versão + devia mostrar os números novos (%s)" % fplus.display_text())
	_check(GameState.forge_plus(0) and CardDB.new_instance(String(GameState.deck[0]["id"]), GameState.deck[0]).data.plus, "Forjar devia criar a versão + da carta")
	# --- Vales ---
	GameState.gold = 60
	var vid := GameState.shop_voucher_offer()
	_check(vid != "" and GameState.buy_voucher(vid) and vid in GameState.vouchers, "devia comprar o Vale à venda")
	GameState.vouchers.clear()
	GameState.vouchers.append_array(["v_hand", "v_relic", "v_channel", "v_reward"])
	_check(GameState.hand_size_for_battle() == 7 and GameState.max_relics() == 6 and GameState.discards_for_battle() == 4, "os Vales deviam dar +1 mão, +1 relíquia e +1 canalização")
	GameState.vouchers.clear()
	# --- Desafios ---
	GameState.new_challenge_run("ch_glass", 9)
	_check(GameState.mode == "challenge" and GameState.player_max_hp == 8, "Vidro devia começar com 8 de vida")
	GameState.new_challenge_run("ch_clock", 9)
	_check(GameState.turns_for_ante(1) == 4, "Contra o Relógio devia ter 4 turnos")
	GameState.new_challenge_run("ch_boss_rush", 9)
	_check(GameState.is_boss_ante(2) and GameState.is_boss_ante(6) and not GameState.is_boss_ante(3), "Maratona de Bosses: boss de 2 em 2")
	GameState.new_challenge_run("ch_no_relics", 9)
	_check(not GameState.add_relic("relic_drum"), "Mãos Vazias: não devia aceitar relíquias")
	GameState.new_challenge_run("ch_no_channel", 9)
	_check(GameState.discards_for_battle() == 0, "Mãos Atadas: 0 canalizações")
	GameState.new_challenge_run("ch_poverty", 9)
	_check(GameState.battle_reward(3) == 0, "Voto de Pobreza: as batalhas não dão ouro")
	GameState.new_challenge_run("ch_small", 9)
	_check(CardDB.shop_pool().all(func(cd): return cd.cost <= 2), "Só Miúdos: a loja só devia ter custo 2 ou menos")
	var bsm := BattleManager.new()
	GameState.ante = 1
	GameState.map_choice = {"battle": "scout"}
	bsm.start(GameState.pick_enemy(1))
	var big: CardInstance = null
	for cc2 in bsm.deck.library + bsm.deck.hand:
		if cc2.data.cost >= 3 and not cc2.data.is_land():
			big = cc2
	if big != null:
		bsm.deck.library.erase(big)
		bsm.deck.hand.erase(big)
		big.zone = CardInstance.Zone.HAND
		bsm.deck.hand.append(big)
		bsm.mana_available = 10
		_check(not bsm.can_play(big), "Só Miúdos: cartas de custo 3+ não deviam jogar-se")
	bsm.free()
	GameState.record_run_end(9, true)
	_check(GameState.challenge_done("ch_small") and Stats.get_stat("challenges_won") == 1 and Stats.is_content_unlocked("frame", "neon"), "vencer um Desafio devia dar medalha e a moldura Néon")
	# --- História ---
	GameState.new_saga_run("saga_white", 11)
	_check(GameState.mode == "saga" and GameState.max_ante == 4 and "c315" in GameState.deck_ids(), "o capítulo branco devia ter 4 antes e as cartas extra")
	GameState.ante = 4
	GameState.map_choice = {"battle": "boss"}
	var sb := GameState.pick_enemy(4)
	_check(String(sb.get("id", "")) == "saga_boss_white", "o boss do capítulo devia ser o Lorde Cinzento (veio %s)" % sb.get("id", ""))
	var bsg := BattleManager.new()
	bsg.start(sb)
	_check(bsg.board.size() == 2 and bsg.board[0].data.token, "a regra do capítulo branco devia pôr 2 Fichas na Arena")
	_check(bsg.max_creatures() == 4, "a regra do boss do capítulo devia deixar só 4 lugares")
	bsg.free()
	_check(not GameState.saga_unlocked(1), "o 2.º capítulo devia estar fechado")
	var wins_before := Stats.get_stat("wins")
	GameState.record_run_end(4, true)
	_check(GameState.saga_done("saga_white") and GameState.saga_unlocked(1) and Stats.is_content_unlocked("back", "dawn"), "acabar o capítulo devia abrir o seguinte e dar as costas Aurora")
	_check(Stats.get_stat("wins") == wins_before, "os capítulos da História não deviam contar como runs vencidas")
	GameState.new_saga_run("saga_blue", 12)
	var bfree := _battle_with(["c340", "c339"], [], [], 3, 3)
	bfree.rule["first_spell_free"] = true
	_check(bfree.effects.cost_of(_find(bfree.deck.hand, "c340")) == 0, "capítulo azul: o 1.º feitiço do turno devia ser grátis")
	bfree.free()
	# --- Némesis ---
	GameState.free_mode = false
	GameState.new_run("deck01", 31337)
	_check(GameState.nemesis_id != "" and GameState.nemesis_def().get("color", "") != "red", "a Némesis devia ser de uma cor fora do baralho")
	_check("nemesis" in GameState.map_options(3)["battle"] and not ("nemesis" in GameState.map_options(4)["battle"]), "a Némesis devia aparecer no ante 3 (no lugar da Elite)")
	GameState.ante = 5
	GameState.map_choice = {"battle": "nemesis"}
	var nd := GameState.pick_enemy(5)
	_check(String(nd.get("variant", "")) == "nemesis" and int(nd.get("nemesis_level", 0)) == 2 and float(nd.get("shield_pct", 0)) > 0.0, "a Némesis do ante 5 devia ser nível 2 com escudo")
	var bn := BattleManager.new()
	bn.start(nd)
	var g0 := GameState.gold
	GameState.after_battle(bn, true)
	_check(GameState.gold >= g0 + 12 and Stats.get_stat("nemesis_wins") == 1 and CardDB.is_available(CardDB.get_card("c356")), "vencer a Némesis devia dar ouro e desbloquear o Lich da Eternidade")
	bn.free()
	# --- Medalhas e sinergias ---
	GameState.progress["stakes"] = {"deck01": 5, "deck02": 8}
	_check(GameState.medal_for("deck01") == "silver" and GameState.medal_for("deck02") == "gold" and GameState.medal_for("deck03") == "", "medalhas por Selo Planar vencido")
	GameState.new_run("deck05", 3)
	_check(CardDB.synergy_reason(CardDB.get_card("c318")).begins_with("Tribo"), "o Estandarte da Legião devia combinar com os Soldados do baralho")
	_check(CardDB.collectible_cards().all(func(cd): return not cd.token), "a Ficha não devia aparecer na coleção")
	GameState.progress = saved_progress
	Stats._ensure()
	GameState.save_progress()
	GameState.free_mode = false
	GameState.clear_saved_run()
	print("  0.10.0: Fichas, tribos, cadeias, selos, encantamentos, reforço, reação, lacaios, escudo, míticas, +, vales, desafios, história e némesis OK")

func _test_content_update() -> void:
	var m := ContentUpdate.parse_manifest(TEST_MANIFEST)
	_check(not m.is_empty() and int(m["c"]) == 2 and (m["files"] as Array).size() == 1, "manifesto não foi lido")
	_check(ContentUpdate.verify(m), "assinatura válida devia passar")
	var tampered := ContentUpdate.parse_manifest(TEST_MANIFEST.replace("c 2", "c 3"))
	_check(not tampered.is_empty() and not ContentUpdate.verify(tampered), "manifesto adulterado devia falhar")
	var bad_path := ContentUpdate.parse_manifest(TEST_MANIFEST.replace("data/teste.json", "scripts/x.json"))
	_check(bad_path.is_empty(), "caminhos fora de data/ e i18n/ deviam ser recusados")
	_check(ContentUpdate.sha256_hex("{\"a\":1}".to_utf8_buffer()) == "015abd7f5cc57a2dd94b7590f04ad8084273905ee33ec5cebeae62276a97f862", "sha256 errado")
	_check(ContentUpdate.resolve("res://data/cards.json") == "res://data/cards.json", "sem conteúdo descarregado devia usar o APK")
	_check(ContentUpdate.installed_version() >= 1, "versão instalada devia ser pelo menos a do APK")
	# Conteúdo descarregado para uma versão anterior (ex.: o v2 da 0.8.0 num telemóvel que instalou a
	# 0.9.x) não pode passar à frente do que vem no APK.
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("user://content/data"))
	_write_text("user://content/data/formations.json", "[]")
	_write_text(ContentUpdate.VERSION_FILE, str(ContentUpdate.BUNDLED_CONTENT_VERSION - 1))
	_check(ContentUpdate.resolve("res://data/formations.json") == "res://data/formations.json", "conteúdo descarregado mais antigo do que o do APK devia ser ignorado")
	ContentUpdate.clear_if_stale()
	_check(not FileAccess.file_exists("user://content/data/formations.json") and not FileAccess.file_exists(ContentUpdate.VERSION_FILE), "conteúdo antigo devia ser apagado ao arrancar")
	_write_text("user://content/data/formations.json", "[]")
	_write_text(ContentUpdate.VERSION_FILE, str(ContentUpdate.BUNDLED_CONTENT_VERSION + 1))
	_check(ContentUpdate.resolve("res://data/formations.json") == "user://content/data/formations.json", "conteúdo descarregado mais novo do que o do APK devia ser usado")
	ContentUpdate.clear_if_stale()
	_check(FileAccess.file_exists("user://content/data/formations.json"), "conteúdo mais novo não devia ser apagado")
	ContentUpdate.clear_downloaded()
	_check(ContentUpdate.resolve("res://data/formations.json") == "res://data/formations.json", "depois de limpar devia voltar ao APK")
	print("  atualizações de conteúdo: manifesto, assinatura e conteúdo antigo ignorado OK")
	_test_release_metadata()

## A versão tem de bater certo em todo o lado: export_presets.cfg (o que o Android vê e o que a
## Release do GitHub anuncia), APP_VERSION_CODE (com que o jogo compara a Release — se ficar atrás,
## a app oferece-se a si própria como atualização), o menu, a tradução e notas_versao.txt.
func _test_release_metadata() -> void:
	var presets := FileAccess.get_file_as_string("res://export_presets.cfg")
	var code_m := RegEx.create_from_string("version/code=(\\d+)").search(presets)
	var name_m := RegEx.create_from_string("version/name=\"([^\"]+)\"").search(presets)
	_check(code_m != null and int(code_m.get_string(1)) == ContentUpdate.APP_VERSION_CODE, "version/code do export_presets.cfg tem de ser igual a ContentUpdate.APP_VERSION_CODE")
	# 0.12.0: o preset de teste (x86_64, para o emulador do Actions) tem de ter a mesma versão.
	for m in RegEx.create_from_string("version/code=(\\d+)").search_all(presets):
		_check(int(m.get_string(1)) == ContentUpdate.APP_VERSION_CODE, "todos os presets do export_presets.cfg deviam ter o mesmo version/code")
	var names := RegEx.create_from_string("version/name=\"([^\"]+)\"").search_all(presets)
	_check(names.size() >= 2 and names.all(func(m): return m.get_string(1) == names[0].get_string(1)), "os presets deviam ter o mesmo version/name")
	if name_m == null:
		_check(false, "export_presets.cfg sem version/name")
		return
	var version := name_m.get_string(1)
	var label := "Versão " + version   # 0.13.1: no menu passou de "protótipo" a "Versão"
	_check(FileAccess.get_file_as_string("res://scenes/main/Main.tscn").contains("\"%s\"" % label), "o menu (Main.tscn) devia mostrar \"%s\"" % label)
	_check(FileAccess.get_file_as_string("res://i18n/en.json").contains("\"%s\"" % label), "falta a tradução de \"%s\" (tools/make_en_json.py)" % label)
	_check(FileAccess.get_file_as_string("res://notas_versao.txt").begins_with("Zero-Sum " + version), "notas_versao.txt devia começar por \"Zero-Sum %s\"" % version)
	print("  versão %s (code %d) igual em export_presets, ContentUpdate, menu, tradução e notas OK" % [version, ContentUpdate.APP_VERSION_CODE])

func _write_text(path: String, text: String) -> void:
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f:
		f.store_string(text)
		f.close()

func _test_stats_and_custom() -> void:
	GameState.reset_progress()
	Stats.set_tutorial_done(true)
	GameState.new_run("deck01", 5)
	_check(Stats.get_stat("runs") == 1, "runs devia contar 1")
	_check(Stats.is_seen("cards", "c001"), "as cartas do baralho jogado deviam ficar descobertas")
	var unlocked := [""]
	var cb := func(id: String): unlocked[0] = id
	EventBus.achievement_unlocked.connect(cb)
	EventBus.damage_dealt.emit("enemy", 150000)
	EventBus.achievement_unlocked.disconnect(cb)
	_check(Stats.get_stat("best_attack") == 150000 and Stats.is_unlocked("attack_100k") and unlocked[0] == "attack_100k", "conquista Cem Mil não desbloqueou")
	_check(not Stats.is_unlocked("attack_1m"), "Um Milhão não devia estar desbloqueada")
	# Infinito.
	_check(GameState.map_options(10)["battle"] == ["scout", "guard"] and GameState.map_options(12)["battle"] == ["boss"], "mapa no infinito errado")
	GameState.endless = true
	_check(GameState.enemy_hp_for_ante(9) > GameState.enemy_hp_for_ante(8), "a vida devia continuar a subir no infinito")
	_check(bool(GameState.pick_enemy(12).get("boss", false)), "ante 12 devia ter boss no infinito")
	GameState.endless = false
	# Baralhos personalizados.
	var custom := {"id": "custom_1", "num": 0, "name": "Teste", "custom": true, "cards": ["c001", "c001", "c002", "c003", "c004", "c005", "c006", "c007", "c008", "c009"], "colors": ["red"], "size": 10, "difficulty": 0, "mechanic": "x"}
	CardDB.custom_decks["custom_1"] = custom
	CardDB.save_custom_decks()
	CardDB.load_custom_decks()
	_check(CardDB.get_deck("custom_1").get("name", "") == "Teste", "baralho personalizado não gravou/carregou")
	GameState.free_mode = true
	GameState.new_run("custom_1", 3)
	_check(GameState.deck.size() == 10 and GameState.deck_colors() == ["red"], "run com baralho personalizado errada")
	var bm := BattleManager.new()
	bm.start(GameState.pick_enemy(1))
	_check(bm.deck.hand.size() > 0, "batalha com baralho personalizado não começou")
	_check(Stats.decks_played() == 1, "baralhos personalizados não deviam contar para 'baralhos jogados' (%d)" % Stats.decks_played())
	CardDB.custom_decks.erase("custom_1")
	CardDB.save_custom_decks()
	GameState.free_mode = false
	# Progresso de uma versão antiga (só por baralho) alimenta os contadores globais.
	GameState.progress = {"best_ante": {"deck01": 6, "deck03": 9}, "wins": {"deck03": 2}, "difficulty": "normal"}
	Stats._ensure()
	_check(Stats.get_stat("best_ante") == 9 and Stats.decks_played() == 2 and Stats.get_stat("wins") == 2 and Stats.get_stat("runs") == 2, "migração do progresso antigo errada")
	Stats._ensure()
	_check(Stats.get_stat("wins") == 2, "a migração não devia repetir-se")
	GameState.reset_progress()
	Stats.set_tutorial_done(true)
	print("  estatísticas, conquistas, infinito e baralhos personalizados OK")

func _test_new_scenes() -> void:
	# Tutorial na primeira batalha + canhoto + texto grande.
	Stats.set_tutorial_done(false)
	Settings.left_handed = true
	Settings.large_text = true
	GameState.new_run("deck01", 8)
	GameState.ante = 1
	var scene: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(scene)
	await get_tree().process_frame
	EventBus.battle_ended.disconnect(scene._on_battle_ended)
	var tut: TutorialOverlay = null
	for c in scene.get_children():
		if c is TutorialOverlay:
			tut = c
	_check(tut != null, "o tutorial devia abrir na primeira batalha")
	var middle: HBoxContainer = scene.get_node("Layout/Middle")
	_check(middle.get_child(middle.get_child_count() - 1).name == "LeftCol", "modo canhoto devia pôr os botões à direita")
	var hand_box: Container = scene.get_node("%Hand")
	if hand_box.get_child_count() > 0:
		var v: CardView = hand_box.get_child(0)
		_check(int(v.get_meta("name_fs", 0)) == 13 and v._text_fs == 12, "texto grande devia aumentar a fonte das cartas")   # 0.14.1: nome 11 → 13, texto 10 → 12
	if tut != null:
		tut.call("_finish")
		await get_tree().process_frame
		_check(Stats.tutorial_done(), "saltar o tutorial devia marcá-lo como feito")
	Settings.left_handed = false
	Settings.large_text = false
	scene.queue_free()
	await get_tree().process_frame
	# Ecrãs novos: estatísticas, coleção (3 separadores), construtor.
	for path in ["res://scenes/ui/StatsScreen.tscn", "res://scenes/ui/Collection.tscn", "res://scenes/builder/DeckBuilder.tscn"]:
		var s: Node = load(path).instantiate()
		add_child(s)
		await get_tree().process_frame
		if path.ends_with("Collection.tscn"):
			for tab in ["relics", "enemies", "cards"]:
				s.call("_select_tab", tab)
				await get_tree().process_frame
		if path.ends_with("DeckBuilder.tscn"):
			s.call("_add_card", "c001")
			s.call("_add_card", "c001")
			s.call("_add_card", "c001")
			_check((s.get("_cards") as Array).size() == 2, "o construtor devia limitar a 2 cópias")
			for i in range(2, 12):
				s.call("_add_card", "c%03d" % i)
			_check((s.get("_cards") as Array).size() == 12, "o construtor devia ter 12 cartas")
			s.call("_on_save")
			_check(CardDB.custom_decks.has("custom_1") and FileAccess.file_exists(CardDB.CUSTOM_DECKS_PATH), "guardar no construtor falhou")
			CardDB.custom_decks.erase("custom_1")
			CardDB.save_custom_decks()
		s.queue_free()
		await get_tree().process_frame
	GameState.reset_progress()
	Stats.set_tutorial_done(true)
	print("  tutorial, canhoto, texto grande, estatísticas, coleção e construtor OK")

# ---------------------------------------------------------------------------
# 0.8.0: mapa, Mercador Cego, nós (acampamento/fonte/altar), selar na loja, draft, quebra-cabeças.
# ---------------------------------------------------------------------------

func _test_scenes_080() -> void:
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	Stats.set_tutorial_done(true)
	# Mapa: fase de batalha do ante 1, escolher Guarda grava a escolha; fase de paragem.
	GameState.free_mode = false
	GameState.new_run("deck01", 77)
	GameState.map_options(1)
	var map_scene: Node = load("res://scenes/map/Map.tscn").instantiate()
	add_child(map_scene)
	await get_tree().process_frame
	_check(GameState.has_saved_run() and GameState.saved_scene == "battle" or GameState.has_saved_run(), "o mapa devia gravar a run")
	var cols: Array = map_scene.get("_columns")
	_check(cols.size() == 4, "o mapa do ato I devia ter 4 colunas (2 antes × batalha/paragem), tem %d" % cols.size())
	var guard_btn: Button = (cols[0]["buttons"] as Dictionary).get("guard")
	_check(guard_btn != null and not guard_btn.disabled, "o Guarda do ante 1 devia estar escolhível")
	var shop_btn: Button = (cols[1]["buttons"] as Dictionary).get("shop")
	_check(shop_btn != null and shop_btn.disabled, "a paragem do ante 1 ainda não devia estar escolhível")
	# 0.9.0: interlúdio do Ato I por cima do mapa (uma vez por ato).
	await get_tree().process_frame
	_check(SceneRouter.top_overlay() is ActInterlude and GameState.interlude_key == "1", "o mapa do ante 1 devia abrir o interlúdio do Ato I")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	_check(ActInterlude.open_if_new() == null, "o interlúdio do mesmo ato não devia repetir")
	SceneRouter._busy = true   # go() não troca de cena durante o teste
	map_scene.call("_on_pick", 1, "battle", "guard")
	SceneRouter._busy = false
	_check(GameState.map_choice.get("battle", "") == "guard", "escolher Guarda no mapa não registou")
	map_scene.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# A batalha usa a escolha (Guarda = +25 % de vida) e no fim vai para o mapa em fase de paragem.
	GameState.map_phase = "stop"
	GameState.map_choice["stop"] = ""
	var map2: Node = load("res://scenes/map/Map.tscn").instantiate()
	add_child(map2)
	await get_tree().process_frame
	var cols2: Array = map2.get("_columns")
	var stop_buttons: Dictionary = cols2[1]["buttons"]
	_check(not (stop_buttons["shop"] as Button).disabled and (cols2[0]["buttons"]["guard"] as Button).disabled, "na fase de paragem só as paragens deviam estar ativas")
	SceneRouter._busy = true
	map2.call("_on_pick", 1, "stop", "rest")
	SceneRouter._busy = false
	_check(GameState.map_choice.get("stop", "") == "rest" and GameState.pending_event == "node_rest", "escolher o acampamento devia preparar o evento")
	map2.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Acampamento: curar 8.
	GameState.damage_player(10)
	var rest_scene: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(rest_scene)
	await get_tree().process_frame
	var hp0 := GameState.player_hp
	((rest_scene._options_box as VBoxContainer).get_child(0) as Button).pressed.emit()
	await get_tree().process_frame
	await get_tree().process_frame
	_check(GameState.player_hp == min(GameState.player_max_hp, hp0 + 8), "o acampamento devia curar 8")
	var ante_before := GameState.ante
	SceneRouter._busy = true
	rest_scene.call("_continue_run")
	SceneRouter._busy = false
	_check(GameState.ante == ante_before + 1 and GameState.map_phase == "battle" and GameState.saved_scene == "map" or GameState.ante == ante_before + 1, "continuar do evento devia avançar o ante e voltar ao mapa")
	rest_scene.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Fonte de Mana: recolorir 1 carta (o teste responde ao seletor com a 1.ª carta elegível).
	GameState.new_run("deck10", 5)   # Conclave Selesnya: verde/branco
	GameState.pending_event = "node_spring"
	var spring: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(spring)
	await get_tree().process_frame
	((spring._options_box as VBoxContainer).get_child(0) as Button).pressed.emit()
	for i in 3:
		for f in 3:
			await get_tree().process_frame
		var viewer := SceneRouter.top_overlay()
		if viewer is ZoneViewer:
			var fv := _first_card_view(viewer)
			viewer.call("_on_card_pressed", fv.card)
		else:
			break
	await get_tree().process_frame
	var recolored := 0
	for e in GameState.deck:
		if e.get("colors", []) == [GameState.main_color()]:
			recolored += 1
	_check(recolored >= 1, "a Fonte devia recolorir pelo menos 1 carta")
	spring.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Altar: fundir — sacrifica a 1.ª carta, a 2.ª herda os efeitos.
	GameState.new_run("deck05", 5)
	GameState.pending_event = "node_altar"
	var altar: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(altar)
	await get_tree().process_frame
	var size_before := GameState.deck.size()
	((altar._options_box as VBoxContainer).get_child(0) as Button).pressed.emit()
	for i in 2:
		for f in 3:
			await get_tree().process_frame
		var viewer := SceneRouter.top_overlay()
		if viewer is ZoneViewer:
			var fv := _first_card_view(viewer)
			viewer.call("_on_card_pressed", fv.card)
	await get_tree().process_frame
	await get_tree().process_frame
	var fused := 0
	for e in GameState.deck:
		if e.has("extra_effects"):
			fused += 1
	_check(GameState.deck.size() == size_before - 1 and fused == 1, "o Altar devia sacrificar 1 carta e fundir noutra (%d, %d)" % [GameState.deck.size(), fused])
	altar.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Mercador Cego: só relíquias lendárias e planeswalkers; comprar um planeswalker.
	GameState.new_run("deck01", 6)
	GameState.add_gold(40)
	GameState.map_options(4)
	GameState.ante = 4
	GameState.choose_stop("merchant")
	var merchant: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	add_child(merchant)
	await get_tree().process_frame
	_check(bool(merchant.get("merchant")), "a loja devia abrir em modo Mercador Cego")
	var pw_offers: VBoxContainer = merchant.get_node("%CardOffers")
	var relic_offers: VBoxContainer = merchant.get_node("%RelicOffers")
	_check(pw_offers.get_child_count() == 2 and relic_offers.get_child_count() == 2, "Mercador Cego devia oferecer 2 planeswalkers e 2 relíquias lendárias")
	(pw_offers.get_child(0) as Button).pressed.emit()
	await get_tree().process_frame
	_check(not GameState.planeswalker.is_empty() and GameState.planeswalker_loyalty() == 2, "comprar um planeswalker devia dar lealdade 2")
	var rb: Button = relic_offers.get_child(0)
	_check(bool(CardDB.relics[String((merchant.get("_offer_relics") as Array)[0]["id"])].get("legendary", false)), "as relíquias do Mercador Cego deviam ser lendárias")
	merchant.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Loja normal: selar uma carta (Selo da Fúria na 1.ª carta) e Marca Eterna (Selo Planar 5).
	GameState.new_run("deck01", 6, 5)
	GameState.add_gold(40)
	GameState.map_options(1)
	GameState.choose_stop("shop")
	var shop: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	add_child(shop)
	await get_tree().process_frame
	shop.call("_on_seal")
	await get_tree().process_frame
	var picker := SceneRouter.top_overlay()
	_check(picker is SealPicker, "selar devia abrir o seletor de selos")
	if picker is SealPicker:
		(picker.get("_on_pick") as Callable).call("fury")
		picker.queue_free()
		await get_tree().process_frame
		var viewer := SceneRouter.top_overlay()
		_check(viewer is ZoneViewer, "depois do selo devia abrir o baralho")
		if viewer is ZoneViewer:
			var fv := _first_card_view(viewer)
			var sealed_card: CardInstance = fv.card
			viewer.call("_on_card_pressed", sealed_card)
			await get_tree().process_frame
			_check(String(GameState.deck[sealed_card.entry_index].get("seal", "")) == "fury", "a carta devia ficar com o Selo da Fúria")
	var relic_btn: Button = (shop.get_node("%RelicOffers") as VBoxContainer).get_child(0)
	relic_btn.pressed.emit()
	await get_tree().process_frame
	_check(GameState.relic_ids.size() == 1 and GameState.relic_locked.size() == 1, "com o Selo Planar 5 a relíquia comprada devia ficar presa")
	var owned: VBoxContainer = shop.get_node("%OwnedRelics")
	_check(owned.get_child_count() == 1 and ((owned.get_child(0) as HBoxContainer).get_child(1) as Button).disabled, "a relíquia presa não devia ter botão de vender ativo")
	SceneRouter.close_overlays()
	shop.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Draft: 5 boosters × 2 escolhas + 3 terrenos → run de 4 antes.
	var draft: Node = load("res://scenes/draft/Draft.tscn").instantiate()
	add_child(draft)
	await get_tree().process_frame
	for pack in 5:
		for pick in 2:
			var current: Array = draft.get("_current")
			_check(current.size() == 5 - pick, "o booster devia ter %d cartas, tem %d" % [5 - pick, current.size()])
			draft.call("_on_pick", CardDB.new_instance((current[0] as CardData).id))
			await get_tree().process_frame
		await get_tree().create_timer(0.3).timeout
	_check(String(draft.get("_stage")) == "lands", "depois de 5 boosters devia vir a escolha de terrenos")
	for pick in 3:
		var current: Array = draft.get("_current")
		draft.call("_on_pick", CardDB.new_instance((current[0] as CardData).id))
		await get_tree().process_frame
	_check(String(draft.get("_stage")) == "done" and (draft.get("_picked") as Array).size() == 10 and (draft.get("_lands") as Array).size() == 3, "o draft devia acabar com 10 cartas + 3 terrenos")
	SceneRouter._busy = true
	draft.call("_on_start")
	SceneRouter._busy = false
	_check(GameState.mode == "draft" and GameState.max_ante == 4 and GameState.deck.size() == 13 and GameState.free_mode, "a run de draft devia ter 13 cartas e 4 antes")
	var dbm := BattleManager.new()
	dbm.start(GameState.pick_enemy(1))
	_check(dbm.deck.hand.size() > 0, "a batalha com o baralho de draft não começou")
	GameState.ante = 4
	_check(bool(GameState.pick_enemy(4).get("boss", false)), "o ante 4 do draft devia ser o boss final")
	draft.queue_free()
	await get_tree().process_frame
	await get_tree().process_frame
	# Quebra-cabeças: a vida de cada um é exatamente o melhor ataque; a cena lista-os; a batalha resolve-se.
	for pz in CardDB.puzzles:
		var best := PuzzleSolver.solve(pz)
		_check(int(best["total"]) == int(pz.get("hp", 0)), "puzzle %s: melhor ataque %d devia ser igual à vida %d" % [pz.get("id", ""), int(best["total"]), int(pz.get("hp", 0))])
	var pscene: Node = load("res://scenes/puzzles/Puzzles.tscn").instantiate()
	add_child(pscene)
	await get_tree().process_frame
	pscene.queue_free()
	await get_tree().process_frame
	GameState.clear_saved_run()
	GameState.puzzle_id = "p1"
	GameState.free_mode = true
	GameState.relic_ids.clear()
	GameState.player_hp = 20
	var pb: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(pb)
	await get_tree().process_frame
	var pbm: BattleManager = pb.battle
	_check(pbm.puzzle and pbm.max_turns == 1 and pbm.discards_left == 0 and pbm.deck.hand.size() == 5, "a batalha do enigma devia ter 1 turno, 0 canalizações e 5 cartas")
	_check(not GameState.has_saved_run(), "os enigmas não deviam gravar a run")
	var p1_line: Array = PuzzleSolver.solve(CardDB.get_puzzle("p1"))["line"]
	for id in p1_line:
		for c in pbm.deck.hand:
			if c.data.id == id:
				pb.call("_on_hand_card_pressed", c)
				break
	var result := [null]
	var cb := func(v: bool): result[0] = v
	EventBus.battle_ended.connect(cb)
	EventBus.battle_ended.disconnect(pb._on_battle_ended)
	pb.call("_on_end_turn")
	var guard := 0
	while result[0] == null and guard < 600:
		guard += 1
		await get_tree().process_frame
	EventBus.battle_ended.disconnect(cb)
	_check(result[0] == true, "a linha certa devia resolver o enigma 1")
	Stats.on_puzzle_solved("p1")
	_check(Stats.is_puzzle_solved("p1") and Stats.get_stat("puzzles_solved") == 1, "o enigma resolvido devia ficar registado")
	GameState.puzzle_id = ""
	pb.queue_free()
	await get_tree().process_frame
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	GameState.clear_saved_run()
	GameState.free_mode = false
	print("  mapa, acampamento, fonte, altar, Mercador Cego, selos na loja, draft e enigmas OK")

func _test_logic_battles() -> void:
	_check(CardDB.cards.size() == 459, "esperava 459 cartas (com as Fichas), há %d" % CardDB.cards.size())
	_check(CardDB.decks.size() == 20, "esperava 20 baralhos")
	var total_wins := 0
	for deck in CardDB.decks:
		GameState.new_run(String(deck.id), 12345)
		_check(GameState.deck.size() == int(deck.size), "baralho %s tem %d cartas" % [deck.name, GameState.deck.size()])
		# Todas as relíquias (acima do limite de 5 — é um teste de regras, não de loja).
		for relic_id in CardDB.relics.keys():
			GameState.relic_ids.append(String(relic_id))
		GameState.player_hp = 60   # vida persistente: dá folga para 4 batalhas seguidas sem loja
		GameState.player_max_hp = 60
		var wins := 0
		var max_total := 0
		for ante in range(1, 5):
			GameState.ante = ante
			var bm := BattleManager.new()
			var hp := GameState.enemy_hp_for_ante(ante)
			bm.start({"name": "Teste", "hp": hp, "max_hp": hp, "attack": 2, "text": "", "abilities": [
				{"trigger": "turn_end", "action": "steal_gold", "value": 1},
				{"trigger": "every_n_turns", "n": 3, "action": "destroy_strongest"},
				{"trigger": "turn_end", "action": "damage_all_creatures", "value": 1},
				{"trigger": "turn_end", "action": "discard_random", "value": 1},
				{"trigger": "turn_end", "action": "heal_self", "value": 1},
			]})
			var result := [null]
			var cb := func(v: bool): result[0] = v
			EventBus.battle_ended.connect(cb)
			var guard := 0
			while result[0] == null and guard < 50:
				guard += 1
				_play_everything(bm)
				var preview := bm.preview_attack()
				_check(preview.total() == int(round(preview.power * preview.mult * preview.damage_mult)), "total da cascata inconsistente")
				max_total = max(max_total, preview.total())
				# Canalizar uma carta por turno, para exercitar on_discard
				if not bm.deck.hand.is_empty() and bm.can_discard(bm.deck.hand[0]):
					bm.discard(bm.deck.hand[0])
				bm.end_turn()
			EventBus.battle_ended.disconnect(cb)
			_check(result[0] != null, "batalha %s ante %d não terminou" % [deck.name, ante])
			_check(bm.turn <= bm.max_turns + bm.extra_turns, "turnos a mais em %s" % deck.name)
			if result[0] == true:
				wins += 1
		print("  %-22s %d/4 vitórias, melhor ataque %d" % [deck.name, wins, max_total])
		_check(max_total > 0, "baralho %s nunca atacou" % deck.name)
		total_wins += wins
	_check(total_wins >= 18, "demasiado poucas vitórias com relíquias fortes: %d" % total_wins)

func _play_everything(bm: BattleManager) -> void:
	var played := true
	var guard := 0
	while played and guard < 40:
		guard += 1
		played = false
		for card in bm.deck.hand.duplicate():
			if bm.can_play(card):
				_check(bm.play(card), "play() falhou numa carta jogável")
				played = true
				break
	_check(bm.creatures().size() <= BattleManager.MAX_CREATURES, "mais criaturas do que o limite")

# ---------------------------------------------------------------------------

func _test_ui_battle() -> void:
	GameState.new_run("deck01", 777)
	GameState.add_relic("relic_ruby")
	GameState.add_relic("relic_banner")
	GameState.ante = 1
	GameState.clear_saved_run()
	var scene: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(scene)
	await get_tree().process_frame
	# A cena mudaria para a loja no fim; aqui queremos ficar no teste.
	EventBus.battle_ended.disconnect(scene._on_battle_ended)
	var bm: BattleManager = scene.get_node("BattleManager")
	_check(GameState.has_saved_run(), "o início do turno 1 devia ter gravado a run")
	var ended := [null]
	var cb := func(v: bool): ended[0] = v
	EventBus.battle_ended.connect(cb)
	# Turno 1: Canalizar pela UI, jogar tudo, atacar.
	var hand_box: Container = scene.get_node("%Hand")
	var dbtn: Button = scene.get_node("%DiscardBtn")
	dbtn.button_pressed = true
	await get_tree().process_frame
	for view in hand_box.get_children():
		if view is CardView and bm.can_discard(view.card):
			var before := bm.deck.graveyard.size()
			view.pressed.emit(view.card)
			await get_tree().process_frame
			_check(bm.deck.graveyard.size() == before + 1, "Canalizar pela UI não descartou")
			_check(not dbtn.button_pressed, "o modo Canalizar devia desligar-se depois de uma carta")
			break
	await _play_ui_turn(scene, bm, ended)
	_check(ended[0] != null or bm.turn == 2, "o turno 1 devia ter acabado (turno=%d)" % bm.turn)
	if ended[0] == null:
		# --- Overlays: pausa, carta em grande, grimório, configurações.
		(scene.get_node("%PauseBtn") as Button).pressed.emit()
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() is PauseMenu, "a pausa não abriu")
		if SceneRouter.top_overlay() is PauseMenu:
			(SceneRouter.top_overlay() as PauseMenu).close()
		await get_tree().process_frame
		await get_tree().process_frame
		_check(not SceneRouter.has_overlay(), "a pausa não fechou")
		for view in hand_box.get_children():
			if view is CardView:
				view.long_pressed.emit(view.card)
				break
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() is CardZoom, "o toque longo não abriu a carta em grande")
		SceneRouter.close_overlays()
		await get_tree().process_frame
		(scene.get_node("%LibraryBtn") as Button).pressed.emit()
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() is ZoneViewer, "o grimório não abriu")
		SceneRouter.close_overlays()
		await get_tree().process_frame
		var sm := SettingsMenu.open()
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() == sm, "as configurações não abriram")
		sm.close()
		await get_tree().process_frame
		await get_tree().process_frame
		# Desfazer pela UI: joga uma carta e anula.
		var hand_n := bm.deck.hand.size()
		for view in hand_box.get_children():
			if view is CardView and bm.can_play(view.card):
				_tap_play(view)
				await get_tree().process_frame
				break
		var undo: Button = scene.get_node("%UndoBtn")
		if bm.deck.hand.size() == hand_n - 1:
			_check(not undo.disabled, "DESFAZER devia estar ativo depois de jogar")
			undo.pressed.emit()
			await get_tree().process_frame
			_check(bm.deck.hand.size() == hand_n, "DESFAZER não repôs a carta na mão")
		# Arrastar no tabuleiro: inverte a ordem das criaturas.
		if bm.board.size() >= 2:
			var first: CardInstance = bm.board[0]
			scene.call("_on_board_drag_started", first, Vector2(100, 100))
			scene.call("_on_board_drag_moved", first, Vector2(5000, 100))
			scene.call("_on_board_drag_ended", first, Vector2(5000, 100))
			_check(bm.board[bm.board.size() - 1] == first, "arrastar devia mover a criatura para o fim")
			var board_box: HBoxContainer = scene.get_node("%Board")
			_check(board_box.get_child(board_box.get_child_count() - 1) == scene._board_views[first.uid], "a vista devia acompanhar a nova ordem")
		# --- Gravação a meio: o início do turno 2 gravou a batalha; retoma-a numa cena nova.
		var saved := {"turn": bm.turn, "hand": bm.deck.hand.size(), "library": bm.deck.library.size(), "graveyard": bm.deck.graveyard.size(), "board": bm.board.size(), "hp": bm.enemy.hp, "mana": bm.mana_total, "discards": bm.discards_left}
		EventBus.battle_ended.disconnect(cb)
		scene.queue_free()
		await get_tree().process_frame
		GameState.new_run("deck05", 1)   # estado diferente: a retoma tem de vir do disco
		_check(GameState.load_run(), "load_run falhou com batalha a meio")
		_check(not GameState.pending_battle.is_empty(), "a gravação devia trazer a batalha")
		_check(String(GameState.deck_def.get("id", "")) == "deck01", "baralho errado na retoma")
		scene = load("res://scenes/battle/Battle.tscn").instantiate()
		add_child(scene)
		await get_tree().process_frame
		EventBus.battle_ended.disconnect(scene._on_battle_ended)
		bm = scene.get_node("BattleManager")
		EventBus.battle_ended.connect(cb)
		var same: bool = bm.turn == saved.turn and bm.deck.hand.size() == saved.hand and bm.deck.library.size() == saved.library \
			and bm.deck.graveyard.size() == saved.graveyard and bm.board.size() == saved.board and bm.enemy.hp == saved.hp \
			and bm.mana_total == saved.mana and bm.discards_left == saved.discards
		_check(same, "batalha retomada não bate certo: %s vs turno %d mão %d grimório %d cemitério %d tabuleiro %d" % [str(saved), bm.turn, bm.deck.hand.size(), bm.deck.library.size(), bm.deck.graveyard.size(), bm.board.size()])
		_check(GameState.pending_battle.is_empty(), "pending_battle devia ser consumida pela cena")
		for card in bm.board:
			_check(card.entry_index >= 0 and card.deck_entry == GameState.deck[card.entry_index], "criatura retomada perdeu a ligação ao baralho")
		print("  UI: batalha retomada no turno %d a partir do ficheiro" % bm.turn)
	# Continua até ao fim.
	var guard := 0
	while ended[0] == null and guard < 10:
		guard += 1
		await _play_ui_turn(scene, bm, ended)
	EventBus.battle_ended.disconnect(cb)
	_check(ended[0] != null, "batalha com UI não terminou")
	print("  UI: batalha terminou (vitória=%s) no turno %d" % [str(ended[0]), bm.turn])
	scene.queue_free()
	await get_tree().process_frame

## Joga tudo o que puder pela UI, carrega em ATACAR e espera que o turno avance (ou a batalha acabe).
func _play_ui_turn(scene: Node, bm: BattleManager, ended: Array) -> void:
	var progressed := true
	while progressed:
		progressed = false
		var hand_box: Container = scene.get_node("%Hand")
		for view in hand_box.get_children():
			if view is CardView and bm.can_play(view.card):
				_tap_play(view)
				await get_tree().process_frame
				progressed = true
				break
	var btn: Button = scene.get_node("%EndTurn")
	_check(not btn.disabled, "botão de atacar devia estar ativo no turno %d" % bm.turn)
	btn.pressed.emit()
	var t0 := Time.get_ticks_msec()
	var turn_before := bm.turn
	while ended[0] == null and bm.turn == turn_before and Time.get_ticks_msec() - t0 < 20000:
		await get_tree().process_frame
	_check(ended[0] != null or bm.turn > turn_before, "a cascata/turno não avançou (timeout)")

func _first_card_view(viewer: Node) -> CardView:
	var stack: Array = [viewer]
	var fallback: CardView = null
	while not stack.is_empty():
		var n: Node = stack.pop_back()
		if n is CardView and not n.is_queued_for_deletion():
			if (n as CardView).playable:
				return n
			if fallback == null:
				fallback = n
		for c in n.get_children():
			stack.append(c)
	return fallback

func _test_other_scenes() -> void:
	# Progresso limpo e determinístico.
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	GameState.clear_saved_run()
	GameState.free_mode = false
	_check(GameState.is_deck_unlocked("deck01"), "deck01 devia estar aberto")
	_check(not GameState.is_deck_unlocked("deck02"), "deck02 devia estar bloqueado no início")
	_check(not GameState.is_act_unlocked(1), "ato II devia estar bloqueado no início")
	# Gravação e retoma da run.
	GameState.new_run("deck04", 42)
	GameState.add_gold(20)
	GameState.add_relic("relic_drum")
	GameState.ante = 3
	GameState.deck[0]["power_bonus"] = 15
	GameState.save_run()
	_check(GameState.has_saved_run(), "run não ficou gravada")
	GameState.new_run("deck01", 1)
	_check(GameState.load_run(), "não conseguiu carregar a run")
	_check(GameState.deck_def.get("id") == "deck04" and GameState.ante == 3 and "relic_drum" in GameState.relic_ids and int(GameState.deck[0]["power_bonus"]) == 15, "run carregada não bate certo")
	# Abandonar a run: conta como derrota no ante atual e apaga a gravação.
	GameState.new_run("deck03", 9)
	GameState.ante = 3
	GameState.save_run({}, "shop")
	GameState.abandon_run()
	_check(not GameState.has_saved_run(), "abandonar devia apagar a gravação")
	_check(GameState.best_ante("deck03") == 3, "abandonar no ante 3 devia registar melhor ante 3")
	# Retoma na loja: a gravação lembra-se de onde estava.
	GameState.new_run("deck02", 3)
	GameState.ante = 2
	GameState.save_run({}, "shop")
	_check(GameState.load_run() and GameState.saved_scene == "shop" and GameState.pending_battle.is_empty(), "gravação na loja não retoma na loja")
	# Desbloqueios.
	GameState.new_run("deck01", 5)
	GameState.ante = 4
	var unl := GameState.record_run_end(4, false)
	_check(GameState.is_deck_unlocked("deck02"), "deck02 devia desbloquear ao chegar ao ante 4 com deck01")
	_check(unl.size() == 1, "esperava 1 desbloqueio, veio %d" % unl.size())
	GameState.record_run_end(6, false)
	_check(GameState.is_act_unlocked(1), "ato II devia abrir ao chegar ao ante 6")
	_check(GameState.is_deck_unlocked("deck06") and not GameState.is_deck_unlocked("deck07"), "no ato II só o 1.º capítulo devia estar aberto")
	# Cenas (progresso: só o deck01 chegou ao ante 4 → ato I com 2 capítulos abertos).
	GameState.progress = {"best_ante": {"deck01": 4}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	GameState.new_run("deck04", 42)
	GameState.add_gold(20)   # 24 ouro → 4 de juros na loja
	GameState.add_relic("relic_drum")
	GameState.damage_player(8)
	# Evento: escolhe a opção do ouro e confirma o resultado.
	GameState.ante = 2
	GameState.pending_event = "fountain"
	var ev_scene: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(ev_scene)
	await get_tree().process_frame
	_check(GameState.saved_scene == "battle" or GameState.has_saved_run(), "evento devia gravar ao entrar")
	var gold_ev := GameState.gold
	var opts: VBoxContainer = ev_scene._options_box
	_check(opts.get_child_count() == 3, "a Fonte devia ter 3 opções")
	(opts.get_child(1) as Button).pressed.emit()
	await get_tree().process_frame
	await get_tree().process_frame
	_check(GameState.gold == gold_ev + 6, "a opção do cantil devia dar +6 ouro")
	_check(ev_scene._continue.visible and GameState.pending_event == "", "depois da escolha devia aparecer CONTINUAR")
	ev_scene.queue_free()
	await get_tree().process_frame
	var gold_in := GameState.gold
	for path in ["res://scenes/main/Main.tscn", "res://scenes/campaign/Campaign.tscn", "res://scenes/ui/HowToPlay.tscn", "res://scenes/shop/Shop.tscn", "res://scenes/ui/RunOver.tscn"]:
		var s: Node = load(path).instantiate()
		add_child(s)
		await get_tree().process_frame
		if path.ends_with("Main.tscn"):
			_check(s.get_node("%NewGame") != null and s.get_node("%Modes") != null and s.get_node("%Settings") != null, "menu sem botões")
		if path.ends_with("Campaign.tscn"):
			_check((s.get_node("%Difficulty") as Button).text.contains("NORMAL"), "a dificuldade (no ecrã da campanha) devia ser Normal")
		if path.ends_with("Campaign.tscn"):
			var list: VBoxContainer = s.get_node("%ChapterList")
			_check(list.get_child_count() == 5, "ato I devia listar 5 capítulos, listou %d" % list.get_child_count())
			var enabled := 0
			for b in list.get_children():
				if not (b as Button).disabled:
					enabled += 1
			_check(enabled == 2, "no ato I deviam estar abertos 2 capítulos (01 e 02), estão %d" % enabled)
			_check(not (s.get_node("%Story") as Label).text.is_empty(), "história vazia")
		if path.ends_with("Shop.tscn"):
			var offers: VBoxContainer = s.get_node("%CardOffers")
			_check(offers.get_child_count() == 3, "loja devia oferecer 3 cartas")
			var relic_offers := (s.get_node("%RelicOffers") as VBoxContainer).get_children().filter(func(b): return String(b.get_meta("kind", "")) == "relic")
			var voucher_offers := (s.get_node("%RelicOffers") as VBoxContainer).get_children().filter(func(b): return String(b.get_meta("kind", "")) == "voucher")
			_check(relic_offers.size() == 2, "loja devia oferecer 2 relíquias")
			_check(voucher_offers.size() == 1, "loja devia oferecer 1 Vale")
			_check(GameState.has_saved_run(), "a loja devia gravar a run ao entrar")
			_check(GameState.gold == gold_in + mini(5, int(gold_in / 5)), "juros: %d ouro deviam render %d (ouro=%d)" % [gold_in, mini(5, int(gold_in / 5)), GameState.gold])
			(s.get_node("%DeckButton") as Button).pressed.emit()
			await get_tree().process_frame
			_check(SceneRouter.top_overlay() is ZoneViewer, "ver baralho na loja não abriu")
			SceneRouter.close_overlays()
			await get_tree().process_frame
			# Curar e vida máxima.
			var hp_before := GameState.player_hp
			(s.get_node("%HealBtn") as Button).pressed.emit()
			_check(GameState.player_hp == min(GameState.player_max_hp, hp_before + 5), "curar na loja não curou")
			var max_before := GameState.player_max_hp
			(s.get_node("%MaxHpBtn") as Button).pressed.emit()
			_check(GameState.player_max_hp == max_before + 5, "vida máxima na loja não subiu")
			# Remover (escolhe a 1.ª carta do painel).
			var before := GameState.deck.size()
			s.call("_on_remove")
			await get_tree().process_frame
			var viewer := SceneRouter.top_overlay()
			_check(viewer is ZoneViewer, "remover devia abrir o baralho")
			if viewer is ZoneViewer:
				var first_view: CardView = _first_card_view(viewer)
				viewer.call("_on_card_pressed", first_view.card)
				await get_tree().process_frame
			_check(GameState.deck.size() == before - 1, "remoção na loja não removeu uma carta")
			# Melhorar (1.ª carta): bónus permanente.
			s.call("_on_upgrade")
			await get_tree().process_frame
			viewer = SceneRouter.top_overlay()
			if viewer is ZoneViewer:
				var fv: CardView = _first_card_view(viewer)
				var entry: Dictionary = GameState.deck[fv.card.entry_index]
				var pb := int(entry.get("power_bonus", 0))
				var mb := float(entry.get("mult_bonus", 0.0))
				viewer.call("_on_card_pressed", fv.card)
				await get_tree().process_frame
				_check(int(entry.get("power_bonus", 0)) > pb or float(entry.get("mult_bonus", 0.0)) > mb, "melhorar não deu bónus permanente")
			# Booster: escolhe 1 de 3.
			before = GameState.deck.size()
			s.call("_on_booster")
			await get_tree().process_frame
			viewer = SceneRouter.top_overlay()
			_check(viewer is ZoneViewer, "booster devia abrir 3 cartas")
			if viewer is ZoneViewer:
				var fv2: CardView = _first_card_view(viewer)
				viewer.call("_on_card_pressed", fv2.card)
				await get_tree().process_frame
			_check(GameState.deck.size() == before + 1, "booster não juntou uma carta")
			# Vender a relíquia que temos.
			var gold_before := GameState.gold
			var owned: VBoxContainer = s.get_node("%OwnedRelics")
			_check(owned.get_child_count() == GameState.relic_ids.size(), "lista das tuas relíquias errada")
			if owned.get_child_count() > 0:
				((owned.get_child(0) as HBoxContainer).get_child(1) as Button).pressed.emit()
				await get_tree().process_frame
				_check(GameState.relic_ids.is_empty() and GameState.gold > gold_before, "vender relíquia não funcionou")
			# Novas ofertas.
			var reroll: Button = s.get_node("%RerollBtn")
			if not reroll.disabled:
				reroll.pressed.emit()
				await get_tree().process_frame
				_check((s.get_node("%CardOffers") as VBoxContainer).get_child_count() == 3, "novas ofertas deviam voltar a dar 3 cartas")
			SceneRouter.close_overlays()
		if path.ends_with("RunOver.tscn"):
			_check((s.get_node("%Title") as Label).text == "DERROTA", "RunOver devia dizer DERROTA")
			_check(s.find_child("Share", true, false) is Button and not (s.share_summary as Dictionary).is_empty(), "o fim da run devia ter PARTILHAR")
			var vb: Control = s.get_node("%Title").get_parent()
			_check(vb.get_combined_minimum_size().y <= 720.0 - 32.0, "o fim da run devia caber em 720 px (pede %d)" % int(vb.get_combined_minimum_size().y))
		s.queue_free()
		await get_tree().process_frame
	# Limpa o que o teste escreveu.
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	GameState.clear_saved_run()
	Settings.language = "auto"
	Settings.save_settings()
	print("  menu/campanha/como jogar/loja/fim carregam; gravação, abandono e desbloqueios OK")


# ---------------------------------------------------------------------------
# 0.12.0
# ---------------------------------------------------------------------------

## 0.12.0 (lógica): espaços de gravação (6, com nome), migração do run.json antigo, Run Rápida.
func _test_0120() -> void:
	GameState.clear_all_saved_runs()
	# Migração: o ficheiro antigo passa para o espaço 1.
	var f := FileAccess.open(GameState.LEGACY_RUN_SAVE, FileAccess.WRITE)
	f.store_string(JSON.stringify({"version": 4, "deck_id": "deck03", "ante": 5, "mode": "campaign"}))
	f.close()
	GameState._migrate_legacy_run()
	_check(not FileAccess.file_exists(GameState.LEGACY_RUN_SAVE) and GameState.has_saved_run(1) and int(GameState.slot_info(1).get("ante", 0)) == 5, "o run.json antigo devia passar para o espaço 1")
	# Gravar em espaços diferentes, nome, resumo e o mais recente.
	GameState.current_slot = 2
	GameState.free_mode = false
	GameState.new_run("deck05", 4242)
	GameState.ante = 3
	GameState.save_run({}, "map")
	_check(GameState.has_saved_run(2) and GameState.saved_slot_count() == 2 and GameState.first_free_slot() == 3, "devia haver runs nos espaços 1 e 2")
	_check(GameState.latest_slot() == 2, "o CONTINUAR devia apontar para o espaço gravado há menos tempo")
	_check(GameState.slot_name(2) == "Jogo 2" and GameState.saved_run_summary(2) == "Falange Solar  ·  Ante 3", "nome e resumo do espaço 2 errados: %s / %s" % [GameState.slot_name(2), GameState.saved_run_summary(2)])
	_check(GameState.rename_slot(2, "  A minha run  ") and GameState.slot_name(2) == "A minha run" and GameState.run_name == "A minha run", "mudar o nome devia ficar gravado (sem espaços a mais)")
	_check(GameState.rename_slot(2, "x".repeat(40)) and GameState.slot_name(2).length() == GameState.RUN_NAME_MAX, "o nome devia ter no máximo %d letras" % GameState.RUN_NAME_MAX)
	GameState.rename_slot(2, "")
	_check(GameState.slot_name(2) == "Jogo 2", "nome vazio devia voltar a \"Jogo 2\"")
	GameState.rename_slot(2, "Falange")
	# Carregar outro espaço muda o espaço atual; o nome vem com a run.
	_check(GameState.load_run(2) and GameState.current_slot == 2 and GameState.run_name == "Falange" and GameState.ante == 3, "carregar o espaço 2 devia trazer a run e o nome")
	# Uma run nova sem passar pela escolha de espaço não estraga a que lá está.
	GameState.claim_slot_for_new_run()
	_check(GameState.current_slot == 3 and GameState.has_saved_run(2), "uma run nova sem escolha devia ir para um espaço livre")
	# Escolhido pelo jogador: substitui.
	GameState.current_slot = 1
	GameState.slot_confirmed = true
	GameState.claim_slot_for_new_run()
	_check(GameState.current_slot == 1 and not GameState.has_saved_run(1), "um espaço escolhido devia ser substituído")
	GameState.delete_slot(2)
	_check(GameState.saved_slot_count() == 0 and GameState.latest_slot() == 0, "apagar devia deixar os espaços vazios")
	# Run Rápida: 4 antes, boss final no 4.º, não conta para os baralhos da campanha.
	GameState.free_mode = false
	GameState.new_quick_run("deck02", 1, 777)
	_check(GameState.mode == "quick" and GameState.max_ante == 4 and GameState.free_mode, "a Run Rápida devia ter 4 antes")
	GameState.pick_enemy(4)
	_check(GameState.is_boss_ante(4) and bool(CardDB.enemy_def(GameState.current_enemy_id).get("final", false)), "o boss do ante 4 da Run Rápida devia ser um boss final")
	var best_before := GameState.best_ante("deck02")
	GameState.record_run_end(4, true)
	_check(GameState.best_ante("deck02") == best_before, "a Run Rápida não devia contar para o baralho da campanha")
	# Histórico: cada run que acaba fica registada (a mais recente primeiro); abandonar fica marcado.
	var hist: Array = GameState.run_history()
	_check(not hist.is_empty() and String(hist[0].get("mode", "")) == "quick" and bool(hist[0].get("won", false)) and int(hist[0].get("ante", 0)) == 4, "o histórico devia ter a Run Rápida vencida")
	GameState.free_mode = false
	GameState.new_run("deck01", 31)
	GameState.ante = 2
	GameState.abandon_run()
	hist = GameState.run_history()
	_check(hist.size() >= 2 and bool(hist[0].get("abandoned", false)) and String(hist[0].get("deck_id", "")) == "deck01", "abandonar devia ficar no histórico, marcado")
	_check(not GameState.run_abandoned, "a marca de abandono não devia ficar ligada")
	for i in GameState.HISTORY_MAX + 5:
		GameState._record_history(1, false)
	_check(GameState.run_history().size() == GameState.HISTORY_MAX, "o histórico devia guardar só as últimas %d runs" % GameState.HISTORY_MAX)
	# Revanche: o mesmo modo, baralho e Selo, no mesmo espaço.
	GameState.current_slot = 4
	GameState.free_mode = true
	GameState.new_quick_run("deck07", 2, 55)
	var info := GameState.rematch_info()
	GameState.clear_saved_run()
	GameState.slot_confirmed = true
	var scene := GameState.start_rematch(info)
	_check(scene == "map" and GameState.mode == "quick" and String(GameState.deck_def.get("id", "")) == "deck07" and GameState.stake == 2 and GameState.has_saved_run(4) and GameState.current_slot == 4, "a revanche devia repetir a Run Rápida no espaço 4")
	_check(GameState.start_rematch({"mode": "draft"}) == "draft", "a revanche do draft devia abrir um draft novo")
	GameState.clear_all_saved_runs()
	# Cópias de segurança: rodam ao abrir; um progress.json estragado recupera a cópia mais recente.
	var keep := GameState.progress.duplicate(true)
	for i in range(1, GameState.PROGRESS_BACKUPS + 1):
		if FileAccess.file_exists(GameState.backup_path(i)):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(GameState.backup_path(i)))
	GameState.progress = {"best_ante": {"deck01": 2}, "wins": {}, "difficulty": "normal", "stats": {"runs": 1}}
	GameState.save_progress()
	GameState._rotate_backups()
	GameState._rotate_backups()   # sem jogar não roda
	_check(GameState.backups_info().size() == 1, "abrir duas vezes sem jogar devia deixar 1 cópia")
	GameState.progress["stats"] = {"runs": 2}
	GameState.save_progress()
	GameState._rotate_backups()
	var bi := GameState.backups_info()
	_check(bi.size() == 2 and int(bi[0].get("runs", 0)) == 2 and int(bi[1].get("runs", 0)) == 1, "as cópias deviam rodar (a 1 é a mais recente)")
	var bad := FileAccess.open(GameState.PROGRESS_SAVE, FileAccess.WRITE)
	bad.store_string("{\"best_ante\": {\"deck0")
	bad.close()
	GameState.load_progress()
	_check(GameState.restored_backup == 1 and int(GameState.progress.get("stats", {}).get("runs", 0)) == 2, "um progresso estragado devia vir da cópia 1")
	GameState.restored_backup = 0
	_check(GameState.restore_backup(2) and int(GameState.progress["stats"].get("runs", 0)) == 1 and int(GameState.backups_info()[0].get("runs", 0)) == 2, "repor a cópia 2 devia guardar o atual como cópia 1")
	GameState.progress = keep
	GameState.save_progress()
	Stats._ensure()
	_check(ErrorReport.build().begins_with("Zero-Sum — relatório de erros") and ErrorReport.build().contains("Versão: "), "o relatório de erros devia ter a versão")
	# Melhor ordem: o Goblin Guia (c001) dá +20 Poder se for o 1.º da Arena.
	GameState.free_mode = false
	GameState.new_run("deck01", 99)
	GameState.relic_ids.clear()
	var bo := _battle_with([], ["c003", "c001"])
	bo.apply_board_order([_find(bo.board, "c003"), _find(bo.board, "c001")])
	var before := bo.preview_attack().net_total()
	var best := bo.best_board_order()
	_check(int(best["total"]) > before and (best["order"][0] as CardInstance).data.id == "c001" and bo.board[0].data.id == "c003", "a melhor ordem devia pôr o Goblin Guia à frente (sem mexer na Arena)")
	_check(bo.apply_board_order(best["order"]) and bo.preview_attack().net_total() == int(best["total"]), "aplicar a melhor ordem devia dar o ataque previsto")
	_check(String(bo.play_hint().get("kind", "")) == "attack", "sem cartas na mão a dica devia ser atacar")
	var bh := _battle_with(["c047", "c008"], ["c003"], [], 3, 1)
	var h2 := bh.play_hint()
	_check(String(h2.get("kind", "")) == "card" and (h2["card"] as CardInstance).data.id == "c047" and int(h2.get("gain", 0)) > 0, "a dica devia ser jogar o Líder da Milícia")
	var bl := _battle_with(["c010", "c008"], ["c003"], [], 3, 1)
	var h3 := bl.play_hint()
	_check(String(h3.get("kind", "")) == "land", "com uma carta de custo 2 e 1 de mana a dica devia ser jogar o Terreno")
	_check(absf(ZoneViewer.chance_at_least_one(10, 2, 3) - 0.53333) < 0.001 and ZoneViewer.chance_at_least_one(5, 0, 3) == 0.0 and ZoneViewer.chance_at_least_one(4, 1, 4) == 1.0, "probabilidades do grimório erradas")
	bo.free()
	bh.free()
	bl.free()
	_test_0120_mechanics()
	GameState.free_mode = false
	GameState.current_slot = 1
	GameState.clear_all_saved_runs()
	print("  0.12.0: espaços de gravação, migração, Run Rápida, histórico, revanche e cópias OK")

## 0.12.0 (cenas): menu (NOVO JOGO com os modos, escolha do espaço, JOGOS GUARDADOS, mudar o nome).
func _test_scenes_0120() -> void:
	var lang_before := Settings.language
	Settings.language = "pt"
	Settings.apply()
	GameState.clear_all_saved_runs()
	MainMenu.return_page = "main"
	GameState.current_slot = 2
	GameState.free_mode = false
	GameState.new_run("deck05", 808)
	GameState.ante = 3
	GameState.save_run({}, "map")
	var menu = load("res://scenes/main/Main.tscn").instantiate()
	add_child(menu)
	await get_tree().process_frame
	SceneRouter.close_overlays()
	await get_tree().process_frame
	_check(_has_text(menu.get_node("%Saves"), "JOGOS GUARDADOS") and _has_text(menu.get_node("%Saves"), "1/6"), "o início devia ter JOGOS GUARDADOS (1/6)")
	_check(int(menu.get_node("%Continue").get_meta("slot", 0)) == 2, "o CONTINUAR devia apontar para o espaço 2")
	menu.get_node("%NewGame").pressed.emit()
	await get_tree().process_frame
	menu.get_node("%QuickRun").pressed.emit()
	await get_tree().process_frame
	var picker := SceneRouter.top_overlay()
	_check(picker is SlotPicker, "escolher um modo devia perguntar o espaço de gravação")
	if picker is SlotPicker:
		var b2: Button = picker.find_child("Slot2", true, false)
		SceneRouter._busy = true   # go() não troca de cena durante o teste
		b2.pressed.emit()
		_check(_has_text(picker.find_child("Note", true, false), "\""), "um espaço ocupado devia pedir confirmação")
		b2.pressed.emit()
		SceneRouter._busy = false
		_check(GameState.current_slot == 2 and GameState.slot_confirmed and GameState.launch_mode == "quick", "confirmar devia escolher o espaço 2 para a Run Rápida")
		_check(GameState.has_saved_run(2), "a run do espaço só se apaga quando a nova começa")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	# JOGOS GUARDADOS: 6 espaços; NOME abre o pedido de texto; APAGAR pede 2 toques.
	menu._show_page("saves", false)
	await get_tree().process_frame
	var slots := 0
	for i in range(1, GameState.SLOT_COUNT + 1):
		if menu.get_node_or_null("%%Slot%d" % i) != null:
			slots += 1
	_check(slots == 6, "JOGOS GUARDADOS devia mostrar 6 espaços")
	menu.get_node("%Rename2").pressed.emit()
	await get_tree().process_frame
	var prompt := SceneRouter.top_overlay()
	_check(prompt is TextPrompt, "NOME devia pedir o nome novo")
	if prompt is TextPrompt:
		(prompt.find_child("Edit", true, false) as LineEdit).text = "Teste"
		(prompt.find_child("Ok", true, false) as Button).pressed.emit()
		await get_tree().process_frame
		_check(GameState.slot_name(2) == "Teste" and _has_text(menu.get_node("%Slot2"), "Teste"), "o nome devia mudar (também no botão)")
	var del: Button = menu.get_node("%Delete2")
	del.pressed.emit()
	_check(GameState.has_saved_run(2) and del.text == "APAGAR?", "APAGAR devia pedir confirmação")
	del.pressed.emit()
	await get_tree().process_frame
	_check(not GameState.has_saved_run(2), "o 2.º toque em APAGAR devia apagar a run")
	_check(menu.current_page() == "saves", "depois de apagar devia ficar em JOGOS GUARDADOS")
	menu.queue_free()
	await get_tree().process_frame
	MainMenu.return_page = "main"
	GameState.current_slot = 1
	GameState.clear_all_saved_runs()
	# --- Batalha: ▶▶, ORDENAR, MELHOR ORDEM, DICA (só no Fácil) e grimório com probabilidades ---
	GameState.free_mode = false
	GameState.new_run("deck01", 1201)
	GameState.relic_ids.clear()
	GameState.difficulty = "facil"
	Settings.hand_sort = "cost"
	Settings.anim_speed = "normal"
	GameState.choose_battle("scout")
	var fb = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(fb)
	EventBus.battle_ended.disconnect(fb._on_battle_ended)
	await get_tree().process_frame
	var fbm: BattleManager = fb.get_node("BattleManager")
	for cid in ["c003", "c001"]:
		var cr := CardDB.new_instance(cid)
		cr.zone = CardInstance.Zone.BOARD
		fbm.board.append(cr)
	fb._refresh_all()
	await get_tree().process_frame
	_check(fb.get_node("%HintBtn").visible and fb.get_node("%BestOrder").visible, "no Fácil com 2 criaturas deviam aparecer DICA e MELHOR ORDEM")
	var order: Array = fb._hand_order()
	var sorted_ok := true
	for i in range(1, order.size()):
		var a: CardInstance = order[i - 1]
		var b: CardInstance = order[i]
		if not a.data.is_land() and not b.data.is_land() and a.data.cost > b.data.cost:
			sorted_ok = false
		if a.data.is_land() and not b.data.is_land():
			sorted_ok = false
	_check(sorted_ok, "ORDENAR por custo devia pôr a mão por custo (Terrenos no fim)")
	fb.get_node("%SortBtn").pressed.emit()
	_check(Settings.hand_sort == "type", "ORDENAR devia passar a por tipo")
	var atk_before: int = fbm.preview_attack().net_total()
	fb.get_node("%BestOrder").pressed.emit()
	_check(fbm.board[0].data.id == "c001" and fbm.preview_attack().net_total() > atk_before and not fb._undo_stack.is_empty(), "MELHOR ORDEM devia reordenar a Arena (e poder desfazer)")
	fb.get_node("%SpeedBtn").pressed.emit()
	_check(Settings.anim_speed == "fast" and _has_text(fb.get_node("%SpeedBtn"), "▶▶"), "▶▶ devia acelerar as animações")
	Settings.anim_speed = "normal"
	fb._open_library()
	await get_tree().process_frame
	var lv := SceneRouter.top_overlay()
	_check(lv is ZoneViewer and lv.find_child("OddsNext", true, false) != null, "o grimório devia mostrar as probabilidades")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	GameState.difficulty = "normal"
	fb._refresh_all()
	_check(not fb.get_node("%HintBtn").visible, "fora do Fácil a DICA não devia aparecer")
	fb._celebrate_record(5000, 4000)
	_check(fb.banner.text.begins_with("NOVO RECORDE!"), "o recorde devia mostrar o letreiro")
	fb.queue_free()
	await get_tree().process_frame
	Settings.hand_sort = ""
	# --- Santuário: duas Bênçãos com preço + recusar; escolher aplica o preço e a Bênção ---
	GameState.new_run("deck01", 3131)
	GameState.add_gold(30)
	GameState.pending_event = "node_sanctuary"
	var sanct: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(sanct)
	await get_tree().process_frame
	var sbox: VBoxContainer = sanct._options_box
	_check(sbox.get_child_count() == 3, "o Santuário devia oferecer 2 Bênçãos e recusar (tem %d)" % sbox.get_child_count())
	var first_opt: Dictionary = sanct._options_cache[0]
	var bid := String(first_opt.get("effects", {}).get("blessing", ""))
	(sbox.get_child(0) as Button).pressed.emit()
	await get_tree().process_frame
	await get_tree().process_frame
	_check(bid != "" and bid in GameState.blessings, "escolher no Santuário devia dar a Bênção")
	sanct.queue_free()
	await get_tree().process_frame
	GameState.blessings.clear()
	# --- História: os dois livros; o II fechado até acabar 3 capítulos do I ---
	var saved_prog: Dictionary = GameState.progress.duplicate(true)
	GameState.progress["saga"] = {}
	var sg = load("res://scenes/saga/Saga.tscn").instantiate()
	add_child(sg)
	await get_tree().process_frame
	_check(sg.find_child("Book1", true, false) != null and sg.find_child("Book2", true, false) != null, "a História devia ter os dois livros")
	(sg.find_child("Book2", true, false) as Button).pressed.emit()
	await get_tree().process_frame
	_check(sg.find_child("Chapter_saga_azorius", true, false) != null and _has_text(sg, "Acaba 3 capítulos do Livro I"), "o Livro II devia mostrar as guildas (fechadas)")
	sg.queue_free()
	await get_tree().process_frame
	GameState.progress = saved_prog
	# --- Coleção: filtros das cartas e Bestiário ---
	var col = load("res://scenes/ui/Collection.tscn").instantiate()
	add_child(col)
	await get_tree().process_frame
	var tf: Button = col.find_child("TypeFilter", true, false)
	tf.pressed.emit()   # Criaturas
	var all_creatures := true
	for v in col._card_grid.get_children():
		if (v as Control).visible and not (v.get_meta("data") as CardData).is_type("creature"):
			all_creatures = false
	_check(all_creatures and col._type_filter == "creature", "o filtro de tipo devia deixar só criaturas")
	var kf: Button = col.find_child("KeywordFilter", true, false)
	kf.pressed.emit()   # Voar
	var all_fly := true
	for v in col._card_grid.get_children():
		if (v as Control).visible and not (v.get_meta("data") as CardData).has_keyword("flying"):
			all_fly = false
	_check(all_fly, "o filtro de palavra-chave devia deixar só cartas com Voar")
	Stats.mark_seen("enemies", "slime")
	GameState.progress["defeated"] = {"slime": 3}
	col._select_tab("enemies")
	await get_tree().process_frame
	var tile: Button = col.find_child("Enemy_slime", true, false)
	_check(tile != null and not tile.disabled and _has_text(tile, "Lodo"), "o Bestiário devia mostrar o Lodo")
	if tile != null:
		tile.pressed.emit()
		await get_tree().process_frame
		var page := SceneRouter.top_overlay()
		_check(page != null and page.name == "BestiaryPage" and _has_text(page, "Vencido 3 vezes."), "a página do Bestiário devia dizer quantas vezes o venceste")
		SceneRouter.close_overlays()
	col.queue_free()
	await get_tree().process_frame
	GameState.progress.erase("defeated")
	await _test_scenes_0120_data()
	Settings.language = lang_before
	Settings.apply()
	GameState.pending_event = ""
	GameState.clear_all_saved_runs()
	print("  0.12.0 (cenas): menu com modos, espaços e nomes; conforto na batalha; Santuário OK")

## Estatísticas com separadores (Histórico, Cartas, CSV) e códigos no Construtor.
func _test_scenes_0120_data() -> void:
	var saved_p: Dictionary = GameState.progress.duplicate(true)
	GameState.progress["history"] = []
	GameState.progress["card_stats"] = {"c001": {"dmg": 50, "plays": 9, "runs": 4, "wins": 1}, "c005": {"dmg": 900, "plays": 2, "runs": 3, "wins": 3}}
	GameState.free_mode = true
	GameState.new_run("deck01", 99)
	GameState.run_log["card_dmg"] = {"c005": 10}
	GameState.record_run_end(4, false)
	GameState.free_mode = false
	var st = load("res://scenes/ui/StatsScreen.tscn").instantiate()
	add_child(st)
	await get_tree().process_frame
	for t in ["summary", "history", "cards", "achievements"]:
		_check(st.find_child("Tab_" + t, true, false) != null, "falta o separador %s nas Estatísticas" % t)
	var hv0 := Stats.get_stat("history_viewed")
	(st.find_child("Tab_history", true, false) as Button).pressed.emit()
	await get_tree().process_frame
	var run0 = st.find_child("Run_0", true, false)
	_check(run0 != null and _has_text_in(run0, "Modo Livre") and _has_text(run0, "Caiu no ante 4"), "o Histórico devia mostrar a run (Modo Livre, caiu no ante 4)")
	_check(Stats.get_stat("history_viewed") == hv0 + 1 and Stats.is_unlocked("history_1"), "abrir o Histórico devia dar a conquista Arquivista")
	_check((st.find_child("CopyCsv", true, false) as Button).visible and st.csv_text().begins_with("date,"), "o Histórico devia ter COPIAR CSV")
	(st.find_child("Tab_cards", true, false) as Button).pressed.emit()
	await get_tree().process_frame
	var list: VBoxContainer = st.find_child("List", true, false)
	_check(list != null and list.get_child_count() >= 3 and list.get_child(1).name == "Card_c005", "as Cartas deviam começar pela que fez mais dano (c005)")
	(st.find_child("Sort_plays", true, false) as Button).pressed.emit()
	await get_tree().process_frame
	list = st.find_child("List", true, false)
	_check(st.card_sort == "plays" and list.get_child(1).name == "Card_c001", "ordenar por jogadas devia pôr a c001 primeiro")
	_check(st.csv_text().begins_with("id,card,damage"), "as Cartas deviam copiar o CSV das cartas")
	(st.find_child("Card_c001", true, false) as Button).pressed.emit()
	await get_tree().process_frame
	var zoom := SceneRouter.top_overlay()
	_check(zoom is CardZoom and _has_text_in(zoom, "Nas tuas runs:"), "a carta em grande devia mostrar as estatísticas dela")
	SceneRouter.close_overlays()
	(st.find_child("Tab_achievements", true, false) as Button).pressed.emit()
	await get_tree().process_frame
	_check(not (st.find_child("CopyCsv", true, false) as Button).visible, "as Conquistas não têm CSV")
	st.queue_free()
	await get_tree().process_frame
	# Construtor: copiar e colar um código.
	var db = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	add_child(db)
	await get_tree().process_frame
	_check(db.find_child("CopyCode", true, false) != null and db.find_child("PasteCode", true, false) != null, "o Construtor devia ter COPIAR/COLAR CÓDIGO")
	var code := DeckCode.encode("Partilhado", ["c001", "c002", "c002", "c003"])
	_check(db.apply_code(code) and db._cards.size() == 4 and db._name == "Partilhado" and db._name_edit.text == "Partilhado", "colar um código devia carregar o baralho e o nome")
	var again := DeckCode.decode(db.deck_code())
	_check(bool(again.get("ok", false)) and (again["cards"] as Array).size() == 4, "copiar o código devia dar o mesmo baralho")
	_check(not db.apply_code("nada disto") and db._cards.size() == 4, "um código inválido não devia mexer no baralho")
	db.queue_free()
	await get_tree().process_frame
	# Avisos: vários ao mesmo tempo ficam uns por baixo dos outros (no máximo 3), o resto espera.
	for i in 5:
		SceneRouter.toast("Aviso %d" % i, 0.2)
	await get_tree().create_timer(0.5).timeout
	var ys := {}
	var shown := 0
	for p in SceneRouter._toast_slots:
		if p != null and is_instance_valid(p):
			shown += 1
			ys[int((p as Control).global_position.y)] = true
	_check(shown <= SceneRouter.TOAST_MAX and ys.size() == shown and SceneRouter.toast_count() >= 2, "os avisos não se deviam tapar uns aos outros (%d no ecrã)" % shown)
	GameState.progress = saved_p
	Stats._ensure()


## 0.12.0 (mecânicas): Voar, Atropelar, Primeiro Golpe, cartas que dão palavras-chave, Chegada de Terreno,
## Terrenos especiais, inimigos novos, bosses sem repetir e marcos do Infinito.
func _test_0120_mechanics() -> void:
	GameState.free_mode = false
	GameState.new_run("deck01", 120)
	GameState.relic_ids.clear()
	# Voar: o lacaio trava a 1.ª criatura SEM Voar (c015 voa; c003 não).
	var bf := _battle_with([], ["c015", "c003"])
	bf.apply_board_order([_find(bf.board, "c015"), _find(bf.board, "c003")])
	bf.minions = [2]
	var cf := bf.preview_attack()
	var fly_ok := false
	var walk_blocked := false
	for st in cf.steps:
		if st.source_card != null and st.source_card.data.id == "c015" and st.action == "power_add" and st.value > 0 and st.tag != "minion":
			fly_ok = true
		if st.source_card != null and st.source_card.data.id == "c003" and st.tag == "minion":
			walk_blocked = true
	_check(fly_ok and walk_blocked, "Voar: o lacaio devia travar a criatura sem Voar, não a que voa")
	# Atropelar: escudo cortado a meio por cada criatura com Atropelar (c032).
	var bt := _battle_with([], ["c032", "c003"])
	bt.enemy["shield_pct"] = 10
	var shield_full := bt.shield_amount()
	_check(bt.preview_attack().shield == int(shield_full / 2), "Atropelar devia cortar o escudo a meio (%d → %d)" % [shield_full, bt.preview_attack().shield])
	# Primeiro Golpe: c186 dispara primeiro mesmo estando à direita.
	var bs := _battle_with([], ["c003", "c186"])
	bs.apply_board_order([_find(bs.board, "c003"), _find(bs.board, "c186")])
	var first_step: Cascade.Step = bs.preview_attack().steps[0]
	_check(first_step.source_card != null and first_step.source_card.data.id == "c186", "Primeiro Golpe devia disparar antes das outras criaturas")
	# Dar palavras-chave: Asas Emprestadas (c361) dá Voar às criaturas na Arena (fica gravado).
	var bg := _battle_with(["c361"], ["c003", "c001"], [], 3, 3)
	bg.play(_find(bg.deck.hand, "c361"))
	_check(_find(bg.board, "c003").has_keyword("flying") and _find(bg.board, "c001").has_keyword("flying"), "Asas Emprestadas devia dar Voar às criaturas")
	var saved := bg.to_dict()
	var bg2 := BattleManager.new()
	bg2.restore(saved)
	_check(_find(bg2.board, "c003") != null and _find(bg2.board, "c003").has_keyword("flying"), "as palavras-chave dadas deviam ficar na gravação")
	# Chegada de Terreno: Elemental da Clareira (c373) +15 Poder ao jogar um Terreno.
	var bl := _battle_with(["c008"], ["c373"], ["c002", "c004"], 3, 2)
	var el := _find(bl.board, "c373")
	var p0 := el.power()
	bl.play(_find(bl.deck.hand, "c008"))
	_check(el.power() == p0 + 15 and bl.landfalls == 1, "Chegada de Terreno devia dar +15 Poder (%d → %d)" % [p0, el.power()])
	# Terreno especial: Templo das Brumas (c381) compra 1 ao jogar e aparece na loja.
	var bt2 := _battle_with(["c381"], [], ["c002", "c004", "c005"], 3, 2)
	var hand0 := bt2.deck.hand.size()
	bt2.play(_find(bt2.deck.hand, "c381"))
	_check(bt2.deck.hand.size() == hand0, "o Templo das Brumas devia comprar 1 carta ao ser jogado")
	GameState.deck_def = CardDB.get_deck("deck02")
	_check(CardDB.shop_pool().any(func(c): return c.id == "c381"), "os Terrenos especiais deviam aparecer na loja")
	_check(not CardDB.shop_pool().any(func(c): return c.is_land() and not c.special_land), "os Terrenos normais não deviam aparecer na loja")
	# Inimigos novos.
	var be := _battle_with([], ["c003", "c001", "c005"], [], 3, 4, 1)
	var ea := EnemyAbilities.new(be)
	ea._apply({"action": "grow_attack", "value": 1})
	_check(int(be.enemy["attack"]) == 2, "o Glutão devia ficar com mais ataque")
	ea._apply({"action": "drain_mana", "value": 1})
	be.next_turn()
	_check(be.mana_available == be.mana_total - 1 and be.mana_drain == 0, "a Sanguessuga devia tirar 1 de mana no turno seguinte")
	be.enemy["shield_pct"] = 3
	ea._apply({"action": "grow_shield", "value": 1})
	_check(float(be.enemy["shield_pct"]) == 4.0, "a Muralha Viva devia subir o escudo")
	ea._apply({"action": "jail_strongest"})
	var jailed_id := ""
	for c in be.board:
		if c.uid == be.jailed_uid:
			jailed_id = c.data.id
	var jail_steps := be.preview_attack().steps.filter(func(st): return st.tag == "jail")
	_check(jailed_id != "" and jail_steps.size() == 1, "o Carcereiro devia prender a criatura mais forte")
	_check(be.shuffle_board() and be.board.size() == 3, "o Ilusionista devia baralhar a Arena")
	GameState.player_hp = 10
	ea._apply({"action": "punish_channel", "value": 1})
	_check(GameState.player_hp == 9, "o Inquisidor devia tirar 1 de vida ao canalizar")
	GameState.player_hp = 1
	ea._apply({"action": "punish_channel", "value": 1})
	_check(GameState.player_hp == 1, "o Inquisidor nunca devia tirar a última vida")
	GameState.player_hp = GameState.player_max_hp
	for id in ["glutton", "inquisitor", "illusionist", "mana_leech", "living_wall", "jailer"]:
		_check(not CardDB.enemy_def(id).is_empty(), "falta o inimigo %s" % id)
	# Bosses: nunca o mesmo duas vezes na run.
	GameState.new_run("deck01", 4242)
	GameState.max_ante = 12
	GameState.choose_battle("boss")
	GameState.pick_enemy(4)
	var b1 := GameState.current_enemy_id
	GameState.pick_enemy(8)
	var b2 := GameState.current_enemy_id
	_check(b1 != b2 and b1 in GameState.bosses_seen and b2 in GameState.bosses_seen, "o boss não se devia repetir na run (%s, %s)" % [b1, b2])
	# Marcos do Infinito.
	GameState.new_run("deck01", 77)
	GameState.endless = true
	var gold0 := GameState.gold
	var pts0 := GameState.talent_points()
	var txt := GameState.claim_endless_milestone(12)
	_check(txt != "" and GameState.gold == gold0 + 15 and GameState.talent_points() == pts0 + 3 and GameState.claim_endless_milestone(12) == "", "o marco do ante 12 devia dar 15 ouro e 3 pontos (uma vez)")
	_check(GameState.next_endless_milestone(9) == 16, "o próximo marco depois do 12 devia ser o 16")
	GameState.endless = false
	for b in [bf, bt, bs, bg, bg2, bl, bt2, be]:
		b.free()
	_test_0120_content()

## 0.12.0 (conteúdo): relíquias novas, Bênçãos, Arena, eventos novos e o veneno do Alquimista.
func _test_0120_content() -> void:
	GameState.free_mode = false
	GameState.new_run("deck04", 1212)
	GameState.relic_ids.clear()
	for id in ["relic_survey_map", "relic_earth_drum", "relic_seismograph", "relic_hive_heart", "relic_glyph_stone", "relic_aura_loom",
			"relic_feather_crown", "relic_iron_hoof", "relic_duelist_glove", "relic_wings_amulet", "relic_word_codex"]:
		_check(CardDB.relics.has(id), "falta a relíquia %s" % id)
	# Mapa do Agrimensor: +1 ouro por Terreno; Tambor da Terra: +2 Mult por Terreno jogado.
	GameState.relic_ids.append("relic_survey_map")
	GameState.relic_ids.append("relic_earth_drum")
	var br := _battle_with(["c008"], ["c003"], ["c002"], 3, 2)
	var g0 := GameState.gold
	var m0 := br.preview_attack().mult
	br.play(_find(br.deck.hand, "c008"))
	_check(GameState.gold == g0 + 1 and br.preview_attack().mult >= m0 + 2.0 - 0.001, "as relíquias de Terrenos deviam dar ouro e Mult")
	br.free()
	GameState.relic_ids.clear()
	# Bênçãos: não aparecem nas lojas; ficam fora do limite e entram na cascata.
	_check(not CardDB.is_relic_available(CardDB.relics["bless_fury"]), "as Bênçãos não deviam sair em lojas nem baús")
	_check(GameState.add_blessing("bless_fury") and "bless_fury" in GameState.active_relic_ids() and not GameState.add_blessing("bless_fury"), "a Bênção devia ficar ativa (uma vez)")
	var bb := _battle_with([], ["c003"])
	var steps_b := bb.preview_attack().steps.filter(func(st): return st.source_id == "bless_fury")
	_check(steps_b.size() == 1, "a Bênção da Fúria devia entrar na cascata")
	bb.free()
	GameState.save_run({}, "map")
	_check(GameState.load_run() and "bless_fury" in GameState.blessings, "as Bênçãos deviam ficar na gravação")
	GameState.clear_saved_run()
	# Alquimista Louco: o inimigo seguinte começa com −15% de vida (só esse).
	GameState.choose_battle("scout")
	GameState.ante = 2
	var seed_state := GameState.rng.state
	var hp_normal := int(GameState.pick_enemy(2)["hp"])
	GameState.rng.state = seed_state
	GameState.next_enemy_weaken = 15
	var hp_weak := int(GameState.pick_enemy(2)["hp"])
	_check(absi(hp_weak - int(round(hp_normal * 0.85))) <= 2 and GameState.next_enemy_weaken == 0, "o veneno devia tirar 15%% da vida (%d → %d)" % [hp_normal, hp_weak])
	# Arena: batalha extra (3 turnos, +50% de vida); vencer dá relíquia e ouro, perder só custa vida.
	_check(GameState.stop_scene("arena") == "battle" and GameState.arena_battle and GameState.turns_for_ante(2) == GameState.ARENA_TURNS, "a Arena devia abrir uma batalha de 3 turnos")
	GameState.rng.state = seed_state
	var arena_def := GameState.pick_arena_enemy()
	_check(int(arena_def["hp"]) > hp_normal and String(arena_def.get("variant", "")) == "arena" and String(GameState.map_choice.get("battle", "")) == "scout", "o campeão da Arena devia ter mais vida (sem mexer na batalha do ante)")
	var relics0 := GameState.relic_ids.size()
	var gold1 := GameState.gold
	GameState.finish_arena(true)
	_check(not GameState.arena_battle and (GameState.relic_ids.size() == relics0 + 1 or GameState.gold >= gold1 + GameState.ARENA_GOLD), "vencer a Arena devia dar relíquia e ouro")
	GameState.arena_battle = true
	GameState.player_hp = 3
	GameState.finish_arena(false)
	_check(GameState.player_hp == 1 and not GameState.arena_battle, "perder na Arena devia custar vida mas nunca a run")
	GameState.player_hp = GameState.player_max_hp
	# Eventos novos e as paragens do mapa.
	for id in ["dragon_hoard", "mad_alchemist", "sky_temple", "gladiator_pit", "stampede", "forbidden_library", "wandering_merchant", "mirror_lake", "tremor", "gamblers_den", "node_treasure", "node_sanctuary"]:
		_check(not CardDB.get_event(id).is_empty(), "falta o evento %s" % id)
	_check(GameState.stop_scene("treasure") == "event" and GameState.pending_event == "node_treasure", "o Tesouro devia abrir o evento dos baús")
	GameState.pending_event = ""
	# Palavra-chave para sempre (Templo do Céu): fica na entrada do baralho.
	var idx := -1
	for i in GameState.deck.size():
		var cd := CardDB.get_card(String(GameState.deck[i]["id"]))
		if cd.is_creature() and not cd.has_keyword("flying"):
			idx = i
			break
	GameState.deck[idx]["keywords_plus"] = ["flying"]
	var inst := CardDB.new_instance(String(GameState.deck[idx]["id"]), GameState.deck[idx])
	_check(inst.has_keyword("flying") and inst.data.has_keyword("flying"), "a palavra-chave ganha no evento devia ficar na carta")
	GameState.blessings.clear()
	# História: Livro II (10 guildas) abre com 3 capítulos do Livro I; depois estão todos abertos.
	var saved_p: Dictionary = GameState.progress.duplicate(true)
	_check(CardDB.saga.size() == 20, "a História devia ter 20 capítulos (tem %d)" % CardDB.saga.size())
	var book2: Array = []
	for i in CardDB.saga.size():
		if GameState.saga_book(i) == 2:
			book2.append(i)
	_check(book2.size() == 10, "o Livro II devia ter 10 capítulos")
	GameState.progress["saga"] = {"saga_white": true, "saga_blue": true}
	_check(not GameState.saga_unlocked(book2[0]) and not GameState.saga_book_open(2), "o Livro II devia estar fechado com 2 capítulos")
	GameState.progress["saga"]["saga_black"] = true
	_check(GameState.saga_unlocked(book2[0]) and GameState.saga_unlocked(book2[9]), "com 3 capítulos o Livro II devia abrir todo")
	for i in book2:
		var chd: Dictionary = CardDB.saga[i]
		_check(not CardDB.enemy_def(String(chd.get("boss", ""))).is_empty(), "capítulo %s sem boss" % chd.get("id", ""))
	var g_before := GameState.gold
	GameState.new_saga_run("saga_orzhov", 7)
	_check(GameState.gold == 4 + 15 and GameState.mode == "saga" and String(GameState.deck_def.get("id", "")) == "deck11", "o capítulo Orzhov devia começar com 15 ouro extra (tem %d)" % GameState.gold)
	GameState.progress = saved_p
	# Desafios novos.
	_check(CardDB.challenges.size() == 16, "deviam existir 16 desafios")
	GameState.new_challenge_run("ch_spells_only", 5)
	_check(not GameState.deck.any(func(e): return CardDB.get_card(String(e["id"])).is_creature()) and not CardDB.shop_pool().any(func(c): return c.is_creature()), "Só Magia: nem o baralho nem a loja deviam ter criaturas")
	GameState.new_challenge_run("ch_cursed_heir", 5)
	_check(GameState.relic_ids.size() == 1 and bool(CardDB.relics[GameState.relic_ids[0]].get("legendary", false)) and GameState.deck_ids().count("c314") >= 3, "Herança Maldita devia dar 3 Maldições e uma relíquia lendária")
	GameState.new_challenge_run("ch_open_sky", 5)
	var sky := BattleManager.new()
	sky.start(GameState.pick_enemy(1))
	_check(sky.minions.size() >= 3, "Céu Aberto: os inimigos deviam ter 3 lacaios")
	var cr: CardInstance = null
	for h in sky.deck.hand:
		if h.data.is_creature() and sky.can_play(h):
			cr = h
			break
	if cr != null:
		sky.play(cr)
		_check(cr.has_keyword("flying"), "Céu Aberto: as criaturas deviam ganhar Voar ao entrar")
	sky.free()
	GameState.new_challenge_run("ch_earthquake", 5)
	var eq := _battle_with(["c008"], ["c028"], ["c002"], 3, 2)
	eq.rule["land_buff"] = 15
	var cpow := _find(eq.board, "c028").power()
	eq.play(_find(eq.deck.hand, "c008"))
	_check(_find(eq.board, "c028").power() == cpow + 15, "Terramoto: cada Terreno devia dar +15 Poder às criaturas")
	eq.free()
	GameState.challenge_id = ""
	GameState.free_mode = false
	_test_0120_progression()

## 0.12.0 (progressão): árvore de talentos, conquistas novas, cosméticos, níveis e variantes de baralho.
func _test_0120_progression() -> void:
	var saved_p: Dictionary = GameState.progress.duplicate(true)
	_check(CardDB.talents.size() >= 18, "deviam existir pelo menos 18 talentos (tem %d)" % CardDB.talents.size())
	for b in GameState.TALENT_BRANCHES:
		_check(CardDB.talents.filter(func(t): return String(t.get("branch", "")) == b).size() >= 6, "o ramo %s devia ter pelo menos 6 talentos" % b)
	GameState.progress["talents"] = {"t_formation": 1, "t_block": 1, "t_keyword": 1, "t_first_turn": 1, "t_bounty": 1, "t_mending": 1, "t_regen": 1, "t_mult": 1}
	GameState.progress.erase("talents_off")
	GameState.free_mode = false
	GameState.new_run("deck05", 1201)
	GameState.relic_ids.clear()
	GameState.apply_talents()
	var mult_ok := true
	for e in GameState.deck:
		if CardDB.get_card(String(e["id"])).is_creature() and float(e.get("mult_bonus", 0.0)) < 0.5:
			mult_ok = false
	_check(mult_ok, "Instinto devia dar +0.5 Mult às criaturas iniciais")
	var bt := BattleManager.new()
	GameState.player_hp = 10
	bt.start({"id": "t", "name": "T", "hp": 99999, "max_hp": 99999, "attack": 0, "text": "", "abilities": [], "boss": false, "rule": {}})
	_check(GameState.player_hp == 11, "Regeneração devia curar 1 no início da batalha")
	var cr: CardInstance = null
	for h in bt.deck.hand:
		if h.data.is_creature() and bt.can_play(h):
			cr = h
			break
	if cr != null:
		var tough0 := cr.toughness()
		bt.play(cr)
		_check(cr.has_keyword("flying") and cr.toughness() == tough0 + 1, "Asas Antigas e Pele Dura deviam valer na 1.ª criatura")
	var opener := bt.preview_attack().steps.filter(func(st): return st.source_name == "Golpe de Abertura")
	_check(bt.turn == 1 and opener.size() == 1, "Golpe de Abertura devia dar Mult no 1.º turno")
	bt.free()
	GameState.progress["talents"] = {}
	GameState.run_talents = {}
	# Conquistas: 75, todas com estatística conhecida.
	_check(CardDB.achievements.size() >= 75, "deviam existir pelo menos 75 conquistas (há %d)" % CardDB.achievements.size())
	for a in CardDB.achievements:
		var stat := String((a.get("cond", {}) as Dictionary).get("stat", ""))
		_check(stat in Stats.STAT_KEYS or stat == "decks_played", "a conquista %s usa uma estatística desconhecida (%s)" % [a.get("id", ""), stat])
		var u: Dictionary = a.get("unlock", {}) if a.get("unlock") is Dictionary else {}
		if String(u.get("type", "")) in ["mat", "effect", "frame", "back"]:
			_check(not CardDB.get_cosmetic(String(u["type"]), String(u["id"])).is_empty(), "a conquista %s desbloqueia um cosmético que não existe" % a.get("id", ""))
	# Cosméticos: tapetes e efeitos rodam só pelos desbloqueados; o tapete desenha-se.
	Settings.arena_mat = "classic"
	GameState.progress["unlocks"] = {}
	_check(Settings.unlocked_cosmetics("mat") == ["classic"], "sem desbloqueios só devia haver o tapete clássico")
	Stats.grant_unlock("mat", "mat_marble")
	Settings.cycle_cosmetic("mat")
	_check(Settings.arena_mat == "mat_marble" and ArenaMat.make("mat_marble") is ArenaMat and ArenaMat.make("classic") is StyleBoxEmpty, "o tapete Mármore devia ficar escolhido")
	Settings.arena_mat = "classic"
	Settings.attack_fx = "classic"
	for sg in CardDB.saga:
		var rw: Dictionary = sg.get("reward", {})
		_check(not CardDB.get_cosmetic(String(rw.get("type", "")), String(rw.get("id", ""))).is_empty(), "o prémio do capítulo %s não existe" % sg.get("id", ""))
	for k in GameState.ENDLESS_MILESTONES:
		var mu: Dictionary = GameState.ENDLESS_MILESTONES[k]["unlock"]
		_check(not CardDB.get_cosmetic(String(mu["type"]), String(mu["id"])).is_empty(), "o prémio do marco %d não existe" % k)
	# Níveis de baralho: XP pelas runs; o nível abre variantes.
	GameState.progress["deck_xp"] = {}
	_check(GameState.deck_level("deck01") == 1 and GameState.deck_variants("deck01") == ["classic"], "um baralho novo devia estar no nível 1")
	GameState.free_mode = false
	GameState.new_run("deck01", 77)
	GameState.record_run_end(6, false)
	GameState.record_run_end(8, true)
	_check(GameState.deck_xp("deck01") == 6 + 11 and GameState.deck_level("deck01") == 2 and "sharp" in GameState.deck_variants("deck01"), "o baralho devia subir ao nível 2 (XP %d)" % GameState.deck_xp("deck01"))
	GameState.new_run("deck01", 78)
	var n0 := GameState.deck.size()
	GameState.apply_deck_variant("sharp")
	_check(GameState.deck.size() == n0 - 2 and GameState.deck.any(func(e): return String(e.get("seal", "")) == "fury"), "a variante Afiado devia tirar 2 cartas e dar um Selo da Fúria")
	GameState.new_run("deck01", 79)
	var hp0 := GameState.player_max_hp
	var g0 := GameState.gold
	GameState.apply_deck_variant("rich")
	_check(GameState.gold == g0 + 10 and GameState.player_max_hp == hp0 - 4, "a variante Rico devia dar 10 ouro e tirar 4 de vida máxima")
	GameState.progress = saved_p
	Stats._ensure()
	_test_0120_data()

## 0.12.0 (dados): estatísticas por carta, exportar em CSV, códigos de baralho e "Fuga da Prisão".
func _test_0120_data() -> void:
	var saved_p: Dictionary = GameState.progress.duplicate(true)
	GameState.progress["card_stats"] = {}
	GameState.progress["history"] = []
	GameState.free_mode = false
	GameState.new_run("deck01", 4242)
	var c1 := GameState.deck[0]["id"] as String
	var inst := CardDB.new_instance(c1)
	GameState.log_card_play(inst)
	GameState.log_card_play(inst)
	GameState.run_log["card_dmg"] = {c1: 1234}
	GameState.record_run_end(8, true)
	var cs := GameState.card_stat(c1)
	_check(int(cs.get("plays", 0)) == 2 and int(cs.get("dmg", 0)) == 1234 and int(cs.get("runs", 0)) == 1 and int(cs.get("wins", 0)) == 1, "a carta devia guardar 2 jogadas, 1234 de dano e 1 run vencida (%s)" % str(cs))
	var other := ""
	for e in GameState.deck:
		if String(e["id"]) != c1:
			other = String(e["id"])
			break
	_check(int(GameState.card_stat(other).get("runs", 0)) == 1 and int(GameState.card_stat(other).get("plays", 0)) == 0, "as outras cartas do baralho também contam a run")
	GameState.new_run("deck01", 4243)
	GameState.run_name = "Nome, com vírgula"
	GameState.record_run_end(3, false)
	_check(int(GameState.card_stat(c1).get("runs", 0)) == 2 and int(GameState.card_stat(c1).get("wins", 0)) == 1, "uma derrota conta a run mas não a vitória")
	var hist := GameState.history_csv().split("\n")
	_check(hist.size() == 3 and hist[0].begins_with("date,mode,deck,result") and hist[1].contains(",loss,") and hist[1].contains("\"Nome, com vírgula\"") and hist[2].contains(",win,"), "o CSV do histórico devia ter cabeçalho e 2 runs (a do nome com vírgula entre aspas)")
	var cards_csv := GameState.card_stats_csv().split("\n")
	_check(cards_csv[0] == "id,card,damage,plays,runs,wins,win_rate" and cards_csv[1].begins_with(c1 + ","), "o CSV das cartas devia começar pela que fez mais dano")
	_check(GameState._csv("a\"b") == "\"a\"\"b\"", "as aspas no CSV deviam dobrar")
	# Batalhas à parte (quebra-cabeças, treino, lições) não contam.
	GameState.reset_for_side_battle("p1")
	GameState.log_card_play(inst)
	_check(not GameState.run_log.get("card_plays", {}).has(c1) or int(GameState.run_log["card_plays"].get(c1, 0)) == 0, "um quebra-cabeças não devia contar jogadas")
	GameState.puzzle_id = ""
	# Códigos de baralho: ida e volta; cartas inválidas, bloqueadas e cópias a mais ficam de fora.
	GameState.progress["achievements"] = []
	GameState.progress["unlocks"] = {}
	var code := DeckCode.encode("Teste, 1|x", ["c005", "c001", "c001", "c357"])
	_check(code.begins_with("ZS1-"), "o código devia começar por ZS1-")
	var dec := DeckCode.decode("  " + code + "\n")
	var got: Array = dec.get("cards", [])
	got.sort()
	_check(bool(dec.get("ok", false)) and got == ["c001", "c001", "c005", "c357"] and String(dec.get("name", "")) == "Teste, 1/x", "o código devia voltar ao mesmo baralho (%s)" % str(dec))
	var bad := DeckCode.decode("olá")
	_check(not bool(bad.get("ok", true)) and String(bad.get("error", "")) != "", "um texto qualquer não é um código")
	_check(not bool(DeckCode.decode("ZS1-@@@").get("ok", true)), "um código estragado devia falhar sem rebentar")
	var locked := DeckCode.decode("ZS1-" + Marshalls.utf8_to_base64("X|999x2.1x3.351.tok_soldier"))
	_check(bool(locked.get("ok", false)) and (locked["cards"] as Array) == ["c001", "c001"] and int(locked.get("skipped", 0)) == 5, "cartas inexistentes, bloqueadas, fichas e a 3.ª cópia deviam ficar de fora (%s)" % str(locked))
	_check(not bool(DeckCode.decode("ZS1-" + Marshalls.utf8_to_base64("X|999")).get("ok", true)), "um código só com cartas inválidas não carrega nada")
	# Fuga da Prisão: vencer uma batalha em que o inimigo prendeu uma criatura.
	var j0 := Stats.get_stat("jails_survived")
	EventBus.battle_started.emit({"id": "warden_test"})
	EventBus.creature_jailed.emit(inst)
	EventBus.battle_ended.emit(true)
	EventBus.battle_started.emit({"id": "warden_test"})
	EventBus.battle_ended.emit(true)
	_check(Stats.get_stat("jails_survived") == j0 + 1, "só a batalha com uma criatura presa devia contar para a Fuga da Prisão")
	GameState.progress = saved_p
	Stats._ensure()
	print("  0.12.0 (dados): estatísticas por carta, CSV, códigos de baralho OK")
	_test_0120_presentation()

## 0.12.0 (apresentação): música por cena/ato/boss e efeitos sonoros com nome.
func _test_0120_presentation() -> void:
	for t in Music.TRACKS:
		_check(Music.has_track(t), "falta a faixa de música %s" % t)
	_check(Settings.has_music(), "com música, o controlo de volume devia aparecer")
	var ante0 := GameState.ante
	var max0 := GameState.max_ante
	var pz0 := GameState.puzzle_id
	GameState.puzzle_id = ""
	GameState.max_ante = 8
	_check(Music.track_for_scene("main") == "menu" and Music.track_for_scene("collection") == "menu", "os menus deviam tocar a faixa do menu")
	GameState.ante = 1
	_check(Music.track_for_scene("map") == "act1", "o ante 1 é o ato I")
	GameState.ante = 4
	_check(Music.track_for_scene("shop") == "act2", "o ante 4 é o ato II")
	GameState.ante = 8
	_check(Music.track_for_scene("event") == "act4", "o ante 8 é o ato IV")
	GameState.ante = 9
	_check(Music.track_for_scene("map") == "endless", "para lá do ante 8 é o Infinito")
	_check(Music.track_for_scene("run_over") == "", "no fim da run a música cala-se (toca o jingle)")
	GameState.ante = 2
	Music.play("act1")
	EventBus.battle_started.emit({"id": "x", "boss": true})
	_check(Music.current == "boss", "um boss devia trocar para a faixa dos bosses")
	EventBus.battle_started.emit({"id": "y"})
	_check(Music.current == "act1", "uma batalha normal toca a faixa do ato")
	GameState.puzzle_id = "p1"
	_check(Music.track_for_scene("battle") == "menu", "os enigmas e o Treino tocam a faixa calma")
	GameState.puzzle_id = pz0
	GameState.ante = ante0
	GameState.max_ante = max0
	Music.play("menu")
	for n in Sfx.NAMED:
		_check(Sfx._named.has(n), "falta o efeito sonoro %s" % n)
	Sfx._last_play.erase("coin")
	_check(Sfx.named("coin") and not Sfx.named("coin"), "um efeito repetido logo a seguir não devia tocar duas vezes")
	_test_0120_art()
	_test_0120_share()
	print("  0.12.0 (apresentação): música por ato e boss, %d efeitos sonoros OK" % Sfx.NAMED.size())

## Partilhar o resumo da run (texto e imagem montada; em headless não se desenha).
func _test_0120_share() -> void:
	var lang0 := Settings.language
	Settings.language = "pt"
	Settings.apply()
	GameState.free_mode = false
	GameState.new_run("deck12", 5150)
	GameState.ante = 8
	GameState.run_log = {"damage_by_ante": {"1": 1000, "2": 5000}, "card_dmg": {"c041": 4200}, "relic_dmg": {}, "card_plays": {}, "best_hit": 4400}
	var sm := RunShare.summary_from_state(true, false)
	_check(int(sm.get("damage", 0)) == 6000 and String(sm.get("mvp", "")) == "c041" and (sm.get("by_ante", []) as Array) == [1000, 5000], "o resumo da partilha devia ter o dano, o MVP e o dano por ante")
	var txt := RunShare.share_text(sm)
	_check(txt.contains("Zero-Sum") and txt.contains("Venci") and txt.contains("Fazemos Ameaças, não promessas."), "o texto da partilha devia ter o resultado e o lema")
	var card := RunShare.build_card(sm)
	_check(card.find_child("Result", true, false) is Label and (card.find_child("Result", true, false) as Label).text == "VITÓRIA", "a imagem devia dizer VITÓRIA")
	card.free()
	_check(RunShare.result_text({"endless": true, "ante": 13}) == "INFINITO · ANTE 13", "no Infinito a imagem diz o ante")
	Settings.language = lang0
	Settings.apply()

## Ilustrações opcionais (com texturas postas à mão: o projeto pode não ter imagens), cometas, vinheta.
func _test_0120_art() -> void:
	var img := Image.create(64, 36, false, Image.FORMAT_RGBA8)
	img.fill(Color(0.2, 0.6, 0.9))
	var tex := ImageTexture.create_from_image(img)
	var show0 := Settings.show_art
	Settings.show_art = true
	ArtLib.overrides = {"card:c001": tex, "portrait:slime": tex, "relic:relic_drum": tex, "background:act_2": tex}
	_check(ArtLib.has("card", "c001") and not ArtLib.has("card", "c_sem_arte"), "a ilustração da c001 devia existir (e a de uma carta sem imagem não)")
	var view: CardView = load("res://scenes/ui/CardView.tscn").instantiate()
	add_child(view)
	view.setup(CardDB.new_instance("c001"))
	_check(view.has_art() and (view._sigil == null or not view._sigil.visible), "com ilustração, a carta mostra-a e esconde o sigilo")
	Settings.show_art = false
	view.refresh()
	_check(not view.has_art() and view._sigil != null and view._sigil.visible, "com as ilustrações desligadas volta o sigilo")
	Settings.show_art = true
	CardView.art_on = false
	view.refresh()
	_check(not view.has_art(), "a Coleção e o Construtor não mostram ilustrações nas grelhas")
	CardView.art_on = true
	view.queue_free()
	var por := EnemyPortrait.new()
	por.art_id = "slime"
	_check(por._art_tex != null, "o retrato devia usar a ilustração do Lodo")
	por.art_id = "inimigo_sem_arte"
	_check(por._art_tex == null, "sem ilustração o retrato é o desenho de sempre")
	por.free()
	var rv: RelicView = load("res://scenes/ui/RelicView.tscn").instantiate()
	add_child(rv)
	rv.setup("relic_drum")
	_check(rv._art != null and not rv._icon.visible, "a relíquia com ilustração esconde o ícone")
	rv.queue_free()
	var bd := BattleBackdrop.new()
	bd.setup(2, "")
	_check(bd._art_texture() == tex, "o fundo do ato II devia usar a ilustração")
	Settings.show_art = false
	bd.setup(3, "")
	_check(bd._art_texture() == null, "com as ilustrações desligadas o fundo volta a ser o desenho")
	Settings.show_art = true
	bd.free()
	CardZoom.show_data(CardDB.get_card("c001"))
	var z := SceneRouter.top_overlay()
	_check(z is CardZoom and _zoom_has_art(z), "a carta em grande devia mostrar a ilustração")
	SceneRouter.close_overlays()
	ArtLib.overrides = {}
	Settings.show_art = show0
	# Cometas e vinheta (com animações normais e movimento ligado).
	var speed0 := Settings.anim_speed
	var rm0 := Settings.reduce_motion
	Settings.anim_speed = "normal"
	Settings.reduce_motion = false
	var trail := AttackTrail.fly(self, Vector2(100, 600), Vector2(200, 100), "red", 0.0)
	_check(trail != null, "o golpe final devia lançar um cometa")
	DamageVignette.flash(self, 0.8)
	var vig := 0
	for c in get_children():
		if c is DamageVignette:
			vig += 1
	_check(vig == 1, "levar dano devia avermelhar as bordas")
	_check(BossIntro.duration() > 1.0, "a entrada do boss devia durar mais de 1 s")
	Settings.reduce_motion = true
	_check(AttackTrail.fly(self, Vector2.ZERO, Vector2.ONE, "red") == null, "com o movimento reduzido não há cometas")
	Settings.anim_speed = speed0
	Settings.reduce_motion = rm0

## 0.12.1: mão com 2 toques (escolher e jogar), arrastar para mudar a ordem, chamas novas e tempo para
## ler a entrada dos bosses (não acelera com a velocidade).
func _test_0121() -> void:
	GameState.free_mode = false
	GameState.new_run("deck01", 1211)
	GameState.relic_ids.clear()
	GameState.difficulty = "normal"
	Settings.hand_sort = ""
	Settings.play_taps = 2
	Settings.anim_speed = "normal"
	GameState.choose_battle("scout")
	var b = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(b)
	EventBus.battle_ended.disconnect(b._on_battle_ended)
	await get_tree().process_frame
	var bm: BattleManager = b.get_node("BattleManager")
	var pick: CardInstance = null
	for c in bm.deck.hand:
		if not c.data.is_land() and bm.can_play(c) and not bm.can_kick(c):
			pick = c
			break
	_check(pick != null, "devia haver uma carta jogável na mão")
	if pick != null:
		var hand_before := bm.deck.hand.size()
		b._on_hand_card_tapped(pick)
		await get_tree().process_frame
		_check(bm.deck.hand.size() == hand_before and b._selected_uid == pick.uid and (b._hand_views[pick.uid] as CardView).is_selected(), "o 1.º toque devia só escolher a carta")
		_check(b.hand_box.selected == b._hand_views[pick.uid], "a carta escolhida devia ficar levantada na mão")
		b._on_hand_card_tapped(pick)
		await get_tree().process_frame
		_check(not (pick in bm.deck.hand) and b._selected_uid == -1, "o 2.º toque na mesma carta devia jogá-la")
	var other: CardInstance = null
	for c in bm.deck.hand:
		if not c.data.is_land():
			other = c
			break
	if other != null:
		b._on_hand_card_tapped(other)
		var ev := InputEventMouseButton.new()
		ev.button_index = MOUSE_BUTTON_LEFT
		ev.pressed = true
		ev.position = Vector2(4, 4)
		b._input(ev)
		_check(b._selected_uid == -1, "tocar fora da mão devia largar a carta escolhida")
	# Opção "1 toque" (Configurações): joga logo.
	Settings.play_taps = 1
	bm.mana_available = 20
	var quick: CardInstance = null
	for c in bm.deck.hand:
		if not c.data.is_land() and bm.can_play(c) and not bm.can_kick(c):
			quick = c
			break
	if quick != null:
		b._on_hand_card_tapped(quick)
		await get_tree().process_frame
		_check(not (quick in bm.deck.hand), "com 1 toque a carta devia ser jogada logo")
	Settings.play_taps = 2
	# Arrastar: a 1.ª carta (não Terreno) passa para o fim do grupo; os Terrenos não saem do grupo deles.
	for cid in ["c001", "c005", "c009"]:
		bm.deck.hand.append(CardDB.new_instance(cid))
	b._refresh_hand()
	await get_tree().process_frame
	var kids: Array = b.hand_box.get_children()
	var non_lands := 0
	var land_view: CardView = null
	for k in kids:
		if (k as CardView).card.data.is_land():
			if land_view == null:
				land_view = k
		else:
			non_lands += 1
	if non_lands >= 2:
		var first: CardView = kids[0]
		b.hand_box.move_child(first, non_lands - 1)
		Settings.hand_sort = "cost"
		b._commit_hand_order()
		_check(bm.deck.hand.find(first.card) == non_lands - 1 and Settings.hand_sort == "", "arrastar devia mudar a ordem da mão (e o ORDENAR passa a \"a tua ordem\")")
	if land_view != null:
		_check(b._hand_slot_for_x(-5000.0, land_view) == non_lands, "um Terreno arrastado devia ficar no grupo dos Terrenos")
	_check(not b._in_play_zone(b.hand_box.get_global_rect().position + Vector2(10, 10)) and b._in_play_zone(Vector2(10, 10)), "a zona de jogar devia ser só acima da mão")
	# Etiqueta JOGAR: conta como a carta escolhida.
	var cv: CardView = b._hand_views.values()[0]
	cv.set_selected(true, true)
	_check(cv._has_point(Vector2(6, -12)), "o JOGAR por cima da carta escolhida devia contar como a carta")
	cv.set_selected(false)
	_check(not cv._has_point(Vector2(6, -12)), "sem escolha, acima da carta já não conta")
	# Toques a sério (eventos do rato, como chegam do ecrã tátil), perto do fundo da carta — que sobe
	# 30 px quando é tocada: um toque rápido escolhe; segurar abre em grande; segurar e andar arrasta.
	b._set_selection(-1)
	await get_tree().process_frame
	var hv: CardView = b.hand_box.get_child(0)
	var hp := hv.get_global_rect().position + Vector2(hv.size.x * 0.5, hv.size.y - 6.0)
	_mouse_move(hp)
	_mouse_button(hp, true)
	await get_tree().process_frame
	await get_tree().process_frame
	_mouse_move(hp + Vector2(2, 1))
	_mouse_button(hp + Vector2(2, 1), false)
	await get_tree().process_frame
	_check(b._selected_uid == hv.card.uid, "um toque rápido perto do fundo da carta devia escolhê-la (a carta sobe debaixo do dedo)")
	b._set_selection(-1)
	await get_tree().process_frame
	hv = b.hand_box.get_child(0)
	hp = hv.get_global_rect().position + Vector2(hv.size.x * 0.5, hv.size.y - 6.0)
	_mouse_move(hp)
	_mouse_button(hp, true)
	await get_tree().process_frame
	_mouse_move(hp + Vector2(1, 2))
	await get_tree().create_timer(0.6).timeout
	_check(SceneRouter.top_overlay() is CardZoom, "segurar uma carta da mão devia abri-la em grande")
	_mouse_move(hp + Vector2(70, -10))
	await get_tree().process_frame
	_check(b._hand_drag_card == hv.card and not (SceneRouter.top_overlay() is CardZoom), "depois de abrir em grande, andar com o dedo devia pegar na carta (e fechar a carta em grande)")
	_mouse_button(hp + Vector2(70, -10), false)
	await get_tree().process_frame
	_check(b._hand_drag_card == null and b._drag_ghost == null, "largar devia pousar a carta na mão")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	# Chamas: ruído de textura (liso nos telemóveis), nas duas pílulas.
	var noise: NoiseTexture2D = b.get_script().fire_noise()
	_check(noise != null and noise.seamless, "as chamas deviam usar uma textura de ruído que se repete")
	_check(b._fire_rects.size() == 2 and (b._fire_rects[0].material as ShaderMaterial).get_shader_parameter("noise_tex") != null, "as duas pílulas deviam ter o ruído das chamas")
	b.queue_free()
	await get_tree().process_frame
	# Entrada dos bosses: o tempo para ler não acelera.
	Settings.anim_speed = "fast"
	_check(BossIntro.duration() >= 3.0, "a 2× a entrada do boss devia dar pelo menos 3 s para ler")
	_check(BossIntro.read_time("x") >= 3.0 and BossIntro.read_time("x".repeat(500)) <= 7.0, "o tempo de leitura devia ficar entre 3 e 7 s")
	Settings.anim_speed = "normal"
	print("  0.12.1: mão com 2 toques, arrastar na mão, JOGAR, chamas e leitura dos bosses OK")

## 0.12.1: jogar uma carta da mão pela UI — dois toques (escolher e jogar), ou um com a opção "1 toque".
func _tap_play(v: CardView) -> void:
	v.pressed.emit(v.card)
	if is_instance_valid(v) and Settings.play_taps == 2:
		v.pressed.emit(v.card)

func _mouse_move(p: Vector2) -> void:
	var ev := InputEventMouseMotion.new()
	ev.position = p
	ev.global_position = p
	ev.button_mask = MOUSE_BUTTON_MASK_LEFT if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) or _lmb_down else 0
	get_viewport().push_input(ev, true)   # coordenadas do ecrã do jogo (sem a escala da janela)

var _lmb_down := false

func _mouse_button(p: Vector2, down: bool) -> void:
	_lmb_down = down
	var ev := InputEventMouseButton.new()
	ev.position = p
	ev.global_position = p
	ev.button_index = MOUSE_BUTTON_LEFT
	ev.pressed = down
	ev.button_mask = MOUSE_BUTTON_MASK_LEFT if down else 0
	get_viewport().push_input(ev, true)   # coordenadas do ecrã do jogo (sem a escala da janela)

# ---------------------------------------------------------------------------
# 0.13.0
# ---------------------------------------------------------------------------

func _test_0130() -> void:
	GameState.free_mode = false
	GameState.new_run("deck01", 1301)
	GameState.relic_ids.clear()
	GameState.run_talents = {}
	GameState.player_hp = 20
	GameState.player_max_hp = 20
	# 1. Escolher quem bloqueia: Goblin Guia (2 ♥) e Sábio do Astrolábio (4 ♥) contra um golpe de 3.
	var bm := _battle_with([], ["c001", "c013"], [], 3, 6, 3)
	var g := _find(bm.board, "c001")
	var s := _find(bm.board, "c013")
	var p := bm.counter_plan()
	_check(p["blocker"] == s and bool(p["survives"]) and int(p["player_damage"]) == 0, "automático: a criatura mais robusta que sobrevive devia bloquear")
	_check(bm.set_blocker(g.uid) and bm.chosen_blocker == g.uid, "devia poder escolher quem bloqueia")
	p = bm.counter_plan()
	_check(p["blocker"] == g and not bool(p["survives"]) and int(p["player_damage"]) == 1 and g in p["deaths"], "a criatura escolhida trava o que aguenta (2) e o resto passa (1)")
	_check(not bm.set_blocker(987654), "não devia aceitar uma criatura que não está na Arena")
	bm.set_blocker(BattleManager.BLOCK_NONE)
	p = bm.counter_plan()
	_check(p["blocker"] == null and int(p["player_damage"]) == 3, "ninguém a bloquear: levas o golpe todo")
	GameState.player_hp = 3
	p = bm.counter_plan()
	_check(p["blocker"] == s, "ninguém a bloquear mas letal: volta ao bloqueio automático")
	GameState.player_hp = 20
	bm.set_blocker(g.uid)
	var d := bm.to_dict()
	var bm_r := BattleManager.new()
	bm_r.restore(d)
	_check(bm_r.chosen_blocker == bm_r.board[bm.board.find(g)].uid, "a escolha de quem bloqueia devia ficar gravada na batalha")
	bm_r.free()
	var hp0 := GameState.player_hp
	bm._enemy_phase()
	_check(not (g in bm.board) and GameState.player_hp == hp0 - 1, "o Goblin escolhido devia morrer e deixar passar 1 de dano")
	bm.set_blocker(s.uid)
	bm.next_turn()
	_check(bm.chosen_blocker == BattleManager.BLOCK_AUTO, "em cada turno o bloqueio volta a automático")
	bm.free()
	# Vigilância escolhida: bloqueia sem sofrer dano.
	var bv := _battle_with([], ["c001", "c043"], [], 3, 6, 5)
	var vig := _find(bv.board, "c043")
	bv.set_blocker(vig.uid)
	p = bv.counter_plan()
	_check(p["blocker"] == vig and bool(p["vigilant"]) and int(p["blocker_damage"]) == 0, "uma criatura com Vigilância escolhida bloqueia sem dano")
	bv.free()
	# 2. Golpe carregado: avisado um turno antes, o contra-ataque seguinte vale ×2; grava-se e gasta-se.
	var bc := _battle_with([], [], [], 3, 6, 4)
	bc.enemy["abilities"] = [{"trigger": "every_n_turns", "n": 2, "action": "charge_attack", "value": 100}]
	_check(bc.enemy_intent(2).size() == 1 and bc.enemy_intent(1).is_empty(), "a carga aparece na intenção dos turnos em que dispara")
	bc.enemy_abilities.on_turn_end(2)
	_check(is_equal_approx(bc.charge_mult, 2.0) and bc.enemy_attack() == 8, "golpe carregado: o ataque seguinte devia valer ×2")
	var bc2 := BattleManager.new()
	bc2.restore(bc.to_dict())
	_check(is_equal_approx(bc2.charge_mult, 2.0), "a carga devia ficar gravada")
	bc2.free()
	var hp1 := GameState.player_hp
	bc.end_turn()
	_check(GameState.player_hp == hp1 - 8 and is_equal_approx(bc.charge_mult, 1.0), "o golpe carregado devia acertar ×2 e gastar-se")
	bc.free()
	GameState.player_hp = 20
	# 3. Ordem de disparo: Primeiro Golpe primeiro.
	var bo := _battle_with([], ["c001", "c039", "c005"])
	var order := bo.strike_order()
	_check(order.size() == 3 and (order[0] as CardInstance).data.id == "c039" and (order[1] as CardInstance).data.id == "c001", "a ordem de disparo devia pôr o Primeiro Golpe à frente")
	bo.free()
	# 4. Ameaças: prender/copiar/destruir a mais forte (sem Proteção), exilar a da direita, meteoro na 3.ª.
	var bt := _battle_with([], ["c001", "c013", "c005"], [], 3, 6, 0)
	bt.enemy["abilities"] = [{"trigger": "turn_end", "action": "jail_strongest"}]
	var th := bt.threat_preview()
	_check(th.size() == 1 and String(th[0]["kind"]) == "jail" and (th[0]["card"] as CardInstance).data.id == "c013", "a seta devia apontar para a criatura que vai ser presa")
	bt.enemy["abilities"] = [{"trigger": "turn_end", "action": "destroy_strongest"}]
	bt.rule["exile_rightmost"] = true
	bt.climate = "meteor_rain"
	var kinds := {}
	for t in bt.threat_preview():
		kinds[String(t["kind"])] = (t["card"] as CardInstance).data.id
	_check(kinds.get("destroy", "") == "c013" and kinds.get("exile", "") == "c005" and not kinds.has("meteor") and not kinds.has("meteor_die"), "destruir a mais forte e exilar a da direita (o meteoro já não tem 3.ª criatura): %s" % str(kinds))
	var strongest := _find(bt.board, "c013")
	bt.enemy_abilities.on_turn_end(1)
	_check(not (strongest in bt.board), "destroy_strongest devia matar a criatura que a seta mostrou")
	bt.free()
	# 5. Pré-visualização com a carta jogada (o cálculo durante o arrasto) e porque não se joga.
	var bp := _battle_with(["c005", "c026"], ["c001"], [], 3, 2)
	var pc := bp.preview_cascade_with(_find(bp.deck.hand, "c005"))
	_check(pc != null and pc.total() - bp.preview_attack().total() == bp.preview_play(_find(bp.deck.hand, "c005")), "o ataque com a carta arrastada devia bater com o +X da carta")
	_check(bp.preview_cascade_with(_find(bp.deck.hand, "c026")) == null and bp.play_block_reason(_find(bp.deck.hand, "c026")) == "Falta mana.", "uma carta cara demais: sem pré-visualização e \"Falta mana.\"")
	bp.free()
	# 6. Guardar mana (talento Reserva / Cântaro de Mana): a que sobra passa para o turno seguinte (máx. 2).
	GameState.run_talents = {"keep_mana": 1.0}
	var bk := _battle_with([], [], [], 3, 3, 0)
	_check(bk.keep_mana_amount() == 1, "o talento Reserva devia guardar 1 de mana")
	var before := bk.mana_total
	bk.end_turn()
	_check(bk.mana_available == mini(bk.mana_total + 1, BattleManager.MAX_MANA) and bk.last_mana_saved == 1, "a mana guardada devia somar-se no turno seguinte (antes %d, agora %d/%d)" % [before, bk.mana_available, bk.mana_total])
	bk.free()
	GameState.run_talents = {}
	# 7. Jogada perfeita: vencer com toda a mana gasta dá +3 ouro.
	var bw := _battle_with([], ["c026"], [], 3, 4, 0)
	bw.enemy.hp = 10
	bw.enemy.max_hp = 10
	bw.mana_available = 0
	var gold0 := GameState.gold
	bw.end_turn()
	_check(bw.finished and bw.perfect_play and GameState.gold >= gold0 + BattleManager.PERFECT_GOLD, "vencer com a mana toda gasta devia ser uma jogada perfeita (+3 ouro)")
	bw.free()
	print("  0.13.0 (batalha): escolher o bloqueio, golpe carregado, ordem, ameaças, total ao vivo, guardar mana e jogada perfeita OK")

## 0.13.0 conteúdo: edições das cartas (cascata, sorteio, carta, loja e confirmação de compras caras),
## mecânicas das cartas novas (Fichas, mortes, Míticas), tribo dos Construtos e o Livro IV.
func _test_content_0130() -> void:
	GameState.free_mode = false
	GameState.new_run("deck01", 1303)
	GameState.relic_ids.clear()
	GameState.run_talents = {}
	GameState.player_hp = 20
	GameState.player_max_hp = 20
	# 1. Edições: Brilhante +40 Poder, Holográfica +6 Mult, Policromática ×1,5 Mult (uma Criatura sem efeitos de ataque).
	GameState.add_card("c393", false, "shiny")
	var entry: Dictionary = GameState.deck[GameState.deck.size() - 1]
	_check(String(entry.get("edition", "")) == "shiny", "add_card devia guardar a edição na entrada do baralho")
	var be := _battle_with([], ["c393"])
	var gear := _find(be.board, "c393")
	_check(gear != null and gear.edition() == "shiny", "a carta na Arena devia ter a edição da entrada do baralho")
	var with_ed := be.preview_attack()
	entry.erase("edition")
	var plain := be.preview_attack()
	_check(is_equal_approx(with_ed.power - plain.power, 40.0), "Brilhante devia dar +40 Poder (%s vs %s)" % [with_ed.power, plain.power])
	entry["edition"] = "holo"
	_check(is_equal_approx(be.preview_attack().mult - plain.mult, 6.0), "Holográfica devia dar +6 Mult")
	entry["edition"] = "poly"
	var poly := be.preview_attack()
	_check(is_equal_approx(poly.mult, plain.mult * 1.5), "Policromática devia dar ×1,5 Mult (%s vs %s)" % [poly.mult, plain.mult])
	var tagged := false
	for st in poly.steps:
		if st.tag == "edition" and st.source_id == "poly" and st.source_card == gear:
			tagged = true
	_check(tagged, "o passo da edição devia aparecer na cascata (tag edition)")
	# A carta mostra a edição (pedra na borda e símbolo na linha do tipo).
	var view: CardView = load("res://scenes/ui/CardView.tscn").instantiate()
	add_child(view)
	view.setup(gear)
	await get_tree().process_frame
	_check(view.get("_edition_gem") != null and view.type_label.text.contains("❖"), "a carta Policromática devia mostrar a pedra e o símbolo ❖")
	view.queue_free()
	be.free()
	_check(EffectResolver.edition_text("holo").contains("6"), "o texto da edição devia dizer o bónus")
	# Sorteio: Brilhante mais comum do que Holográfica, e esta do que Policromática; Terrenos nunca.
	var counts := {"": 0, "shiny": 0, "holo": 0, "poly": 0}
	var cd := CardDB.get_card("c394")
	for i in 3000:
		counts[GameState.roll_edition(cd)] += 1
	_check(int(counts["shiny"]) > int(counts["holo"]) and int(counts["holo"]) > int(counts["poly"]) and int(counts["poly"]) > 0 and int(counts[""]) > 2000, "probabilidades das edições estranhas: %s" % str(counts))
	var land_ed := ""
	for i in 300:
		land_ed += GameState.roll_edition(CardDB.get_card("c407"))
	_check(land_ed == "", "os Terrenos não deviam ter edição")
	# 2. Duplicação copia as Fichas da Arena; o Coração da Colmeia cria o dobro.
	var bd := _battle_with(["c415"], ["tok_gear", "tok_spirit"], [], 3, 6)
	_check(bd.play(_find(bd.deck.hand, "c415")), "a Duplicação devia poder ser lançada")
	var toks := 0
	for c in bd.board:
		if c.data.token:
			toks += 1
	_check(toks == 4, "a Duplicação devia copiar as 2 Fichas (há %d)" % toks)
	bd.free()
	var bh := _battle_with([], ["c451"])
	_check(bh.create_tokens(1, "tok_gear") == 2, "com o Coração da Colmeia cada Ficha devia vir a dobrar")
	bh.free()
	# 3. Mortes: Mártir da Alvorada (ao morrer) e Senhor da Carnificina (qualquer morte) fazem crescer as outras.
	var bm1 := _battle_with([], ["c426", "c001"])
	var gob := _find(bm1.board, "c001")
	var p0 := gob.power()
	bm1.kill_creature(_find(bm1.board, "c426"))
	_check(gob.power() >= p0 + 20 and bm1.creatures_died == 1, "o Mártir ao morrer devia dar +20 Poder às outras (%d → %d)" % [p0, gob.power()])
	bm1.free()
	var bm2 := _battle_with([], ["c452", "c001", "c013"])
	gob = _find(bm2.board, "c001")
	p0 = gob.power()
	bm2.kill_creature(_find(bm2.board, "c013"))
	_check(gob.power() >= p0 + BattleManager.DEATH_GROWTH, "o Senhor da Carnificina devia fazer crescer as outras quando uma morre")
	bm2.free()
	# 4. Coveiro Sombrio (+3 Mult por morte) e Vampira Anciã (vida abaixo de metade).
	var bg := _battle_with([], ["c435", "c001", "c013"])
	bg.kill_creature(_find(bg.board, "c001"))
	bg.kill_creature(_find(bg.board, "c013"))
	_check(_step_value(bg.preview_attack(), "c435", "mult_add") == 6.0, "o Coveiro devia dar +3 Mult por cada morte (2 mortes = +6)")
	bg.free()
	var bv := _battle_with([], ["c434"])
	_check(_step_value(bv.preview_attack(), "c434", "mult_add") == 0.0, "com a vida cheia a Vampira Anciã não dá Mult")
	GameState.player_hp = 5
	_check(_step_value(bv.preview_attack(), "c434", "mult_add") == 6.0, "com a vida abaixo de metade a Vampira Anciã devia dar +6 Mult")
	GameState.player_hp = 20
	bv.free()
	# 5. Eco do Primeiro Golpe: a 1.ª a disparar dispara duas vezes.
	var bec := _battle_with([], ["c001", "c454"])
	var first: CardInstance = bec.strike_order()[0]
	var echoed := false
	for st in bec.preview_attack().steps:
		if st.retrigger and st.source_card == first:
			echoed = true
	_check(echoed, "o Eco do Primeiro Golpe devia reativar a 1.ª criatura a disparar")
	bec.free()
	# 6. Fonte Primordial: +1 mana em cada turno.
	var bf := _battle_with([], ["c453"], [], 3, 2)
	var bn := _battle_with([], ["c001"], [], 3, 2)
	bf.next_turn()
	bn.next_turn()
	_check(bf.mana_total == bn.mana_total + 1, "a Fonte Primordial devia dar +1 mana (%d vs %d)" % [bf.mana_total, bn.mana_total])
	bf.free()
	bn.free()
	# 7. Guardião dos Segredos: os efeitos [Na Mão] disparam duas vezes.
	var bs := _battle_with(["c416"], ["c450", "tok_gear"])
	var hand_steps := 0
	for st in bs.preview_attack().steps:
		if st.source_card != null and st.source_card.data.id == "c416":
			hand_steps += 1
	_check(hand_steps == 2, "com o Guardião dos Segredos o Bosque Fervilhante devia disparar 2 vezes (%d)" % hand_steps)
	bs.free()
	# 8. Arquimaga do Fluxo: o 1.º feitiço de cada turno não custa mana.
	var ba := _battle_with(["c396", "c411"], ["c449"], [], 3, 6)
	_check(ba.effects.cost_of(_find(ba.deck.hand, "c396")) == 0, "o 1.º feitiço do turno devia ser grátis com a Arquimaga")
	ba.play(_find(ba.deck.hand, "c396"))
	_check(ba.effects.cost_of(_find(ba.deck.hand, "c411")) > 0, "o 2.º feitiço do turno já devia custar mana")
	ba.free()
	# 9. Biela de Bronze reativa o Construto da direita (não um Goblin); Relojoeiro Louco só na ponta direita.
	var br := _battle_with([], ["c395", "c394"])
	_check(_retriggered(br.preview_attack(), "c394"), "a Biela devia reativar o Construto à direita")
	br.free()
	br = _battle_with([], ["c395", "c001"])
	_check(not _retriggered(br.preview_attack(), "c001"), "a Biela não devia reativar uma criatura que não é Construto")
	br.free()
	var bw := _battle_with([], ["c013", "c401"])
	_check(_retriggered(bw.preview_attack(), "c013"), "o Relojoeiro na ponta direita devia reativar a 1.ª")
	bw.free()
	bw = _battle_with([], ["c401", "c013"])
	_check(not _retriggered(bw.preview_attack(), "c401"), "o Relojoeiro fora da ponta direita não reativa")
	bw.free()
	# 10. Banquete da Legião: +1 Mult por Ficha criada nesta batalha.
	var bl := _battle_with(["c419"], ["c001"], [], 3, 6)
	bl.create_tokens(3, "tok_gear")
	bl.play(_find(bl.deck.hand, "c419"))
	_check(_step_value(bl.preview_attack(), "c419", "mult_add") == 3.0, "o Banquete devia dar +1 Mult por cada Ficha criada (3)")
	bl.free()
	# 11. Tribo dos Construtos (2+ a atacar).
	var bt := _battle_with([], ["c393", "c394"])
	var tribe := false
	for st in bt.preview_attack().steps:
		if st.source_kind == "tribe" and st.source_id == "construct":
			tribe = true
	_check(tribe, "2 Construtos a atacar deviam dar o bónus da tribo")
	bt.free()
	# 12. Livro IV: aberto desde o início, capítulos que se desbloqueiam com conquistas.
	var act4 := -1
	for i in CardDB.campaign.size():
		if String(CardDB.campaign[i].get("id", "")) == "act4":
			act4 = i
	_check(act4 >= 0 and GameState.is_act_unlocked(act4), "o Livro IV devia existir e estar aberto")
	var ach_ok := false
	for a in Stats.achievements:
		var u = a.get("unlock")
		if u is Dictionary and String(u.get("type", "")) == "deck" and String(u.get("id", "")) == "deck19":
			ach_ok = true
	_check(ach_ok, "o baralho Engrenagens devia desbloquear-se com uma conquista")
	Stats.grant_unlock("deck", "deck19")
	_check(GameState.is_deck_unlocked("deck19"), "depois do desbloqueio o baralho 19 devia estar disponível")
	for id in ["c449", "c450", "c451", "c452", "c453", "c454"]:
		var found := false
		for a in Stats.achievements:
			var u = a.get("unlock")
			if u is Dictionary and String(u.get("type", "")) == "card" and String(u.get("id", "")) == id:
				found = true
		_check(found, "a Mítica %s devia ter uma conquista que a desbloqueia" % id)
	# 13. Loja: carta com edição custa mais, entra no baralho com a edição; compras caras pedem 2 toques.
	GameState.new_run("deck01", 1304)
	GameState.add_gold(60)
	GameState.map_options(1)
	GameState.choose_stop("shop")
	var shop: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	add_child(shop)
	await get_tree().process_frame
	var offers: Array = shop.get("_offer_cards")
	_check(not offers.is_empty(), "a loja devia ter cartas à venda")
	if not offers.is_empty():
		(shop.get("_offer_editions") as Array)[0] = "poly"
		shop.call("_build_offers")
		await get_tree().process_frame
		var btn: Button = (shop.get_node("%CardOffers") as VBoxContainer).get_child(0)
		var price: int = int(btn.get_meta("price"))
		_check(price == GameState.shop_price((offers[0] as CardData).price + 8), "a Policromática devia custar +8 ouro")
		_check(UiKit.wrap_text(btn).contains(EffectResolver.edition_name("poly")), "a oferta devia dizer que é Policromática")
		Settings.confirm_buy = true
		GameState.gold = price + 1   # cara: mais de metade do ouro
		var n0 := GameState.deck.size()
		btn.pressed.emit()
		_check(GameState.deck.size() == n0 and UiKit.wrap_text(btn).contains(tr("Toca outra vez para comprar por %d ouro.") % price), "com Confirmar compras caras o 1.º toque só devia avisar")
		btn.pressed.emit()
		_check(GameState.deck.size() == n0 + 1 and String(GameState.deck[n0].get("edition", "")) == "poly", "o 2.º toque devia comprar a carta Policromática")
		Settings.confirm_buy = false
	shop.queue_free()
	await get_tree().process_frame
	GameState.clear_saved_run()
	print("  0.13.0 (conteúdo): edições, Fichas, mortes, Míticas, Construtos, Livro IV e loja OK")

## 0.13.0 run: consumíveis, afixos das Elites, bosses novos (cascata ao contrário, Ladra de Relíquias, três
## fases, mão a encolher, silêncio, formações a meio), climas novos, conjuntos de relíquias, maldições do
## Infinito e consequências dos eventos.
func _test_run_0130() -> void:
	GameState.free_mode = false
	GameState.new_run("deck01", 1310)
	GameState.relic_ids.clear()
	GameState.run_talents = {}
	GameState.player_hp = 20
	GameState.player_max_hp = 20
	# 1. Consumíveis: 2 lugares, o 3.º não cabe.
	_check(GameState.add_consumable("potion_fury") and GameState.add_consumable("scroll_ward"), "devia caber 2 consumíveis")
	_check(not GameState.add_consumable("potion_heal") and GameState.consumables.size() == 2, "o 3.º consumível não devia caber")
	var bi := _battle_with([], ["c001", "c013"], [], 3, 6, 3)
	var base := bi.preview_attack()
	_check(bi.use_consumable(0) and is_equal_approx(bi.item_mult, 1.5), "o Elixir da Fúria devia dar ×1,5 no próximo ataque")
	var fury := bi.preview_attack()
	var item_step := false
	for st in fury.steps:
		if st.source_kind == "item":
			item_step = true
	_check(item_step and is_equal_approx(fury.mult, base.mult * 1.5), "o Elixir devia aparecer na cascata (×1,5)")
	_check(bi.use_consumable(0) and bi.ward and bi.counter_blocked() and int(bi.counter_plan()["damage"]) == 0, "o Pergaminho de Proteção devia travar o contra-ataque")
	_check(GameState.consumables.is_empty(), "os consumíveis usados deviam sair")
	var hp0 := GameState.player_hp
	bi.end_turn()
	_check(GameState.player_hp == hp0 and not bi.ward and is_equal_approx(bi.item_mult, 1.0), "o ataque devia gastar o Elixir e o contra-ataque travado gastar a Proteção")
	bi.free()
	var bf := _battle_with([], ["c001"], [], 3, 4, 0)
	var hp_e: int = bf.enemy.hp
	GameState.consumables = ["scroll_fire", "potion_mana"]
	_check(bf.use_consumable(0) and hp_e - int(bf.enemy.hp) == int(round(bf.enemy.max_hp * 0.08)), "o Pergaminho de Fogo devia tirar 8 % da vida máxima")
	var mana0 := bf.mana_available
	_check(bf.use_consumable(0) and bf.mana_available == mana0 + 2, "a Poção de Mana devia dar +2 de mana")
	GameState.consumables = ["scroll_time", "scroll_echo", "potion_heal"]
	var turns0 := bf.extra_turns
	_check(bf.use_consumable(0) and bf.extra_turns == turns0 + 1, "o Pergaminho do Tempo devia dar +1 turno")
	_check(bf.use_consumable(0) and _retriggered(bf.preview_attack(), "c001"), "o Pergaminho do Eco devia reativar a 1.ª criatura")
	_check(not bf.can_use_consumable("potion_heal"), "com a vida cheia a Poção de Vida não se usa")
	bf.free()
	GameState.player_hp = 10
	_check(GameState.use_consumable_outside(0) != "" and GameState.player_hp == 18 and GameState.consumables.is_empty(), "a Poção de Vida devia curar 8 no mapa")
	GameState.player_hp = 20
	GameState.consumables = ["scroll_purge"]
	_check(GameState.use_consumable_outside(0) == "" and GameState.consumables.size() == 1, "a Purificação escolhe a carta no mapa (não se gasta sozinha)")
	GameState.consumables.clear()
	# 2. Afixos das Elites: 1 até ao ante 5, 2 a partir do 6; Espinhoso custa vida ao atacar.
	GameState.map_choice = {"battle": "elite"}
	var elite := GameState.pick_enemy(3)
	_check((elite.get("affixes", []) as Array).size() == 1, "uma Elite no ante 3 devia ter 1 afixo")
	_check((GameState.roll_affixes(6) as Array).size() == 2, "a partir do ante 6 as Elites têm 2 afixos")
	GameState.map_choice = {}
	var bt := _battle_with([], ["c001"], [], 3, 4, 0)
	bt.rule["thorns"] = 1
	var hp1 := GameState.player_hp
	bt.end_turn()
	_check(GameState.player_hp == hp1 - 1, "o afixo Espinhoso devia custar 1 de vida por ataque")
	bt.free()
	GameState.player_hp = 20
	# 3. Bosses novos.
	GameState.relic_ids = ["relic_banner", "relic_drum"]
	var br := _battle_with([], ["c001", "c013"])
	var normal := br.preview_attack()
	br.rule["reverse_cascade"] = true
	var rev := br.preview_attack()
	_check(rev.steps.size() == normal.steps.size() and rev.steps[0].source_kind != "creature" and rev.total() <= normal.total(), "o Inversor devia disparar a cascata ao contrário (e valer menos)")
	br.rule.erase("reverse_cascade")
	_check(br.steal_relic() == "relic_banner" and not ("relic_banner" in GameState.active_relic_ids()), "a Ladra devia desligar a relíquia mais à esquerda")
	var gold0 := GameState.gold
	br.enemy.hp = 0
	br._finish(true)
	_check(GameState.stolen_relics.is_empty() and "relic_banner" in GameState.active_relic_ids() and GameState.gold >= gold0 + GameState.RELIC_THIEF_GOLD, "vencer a Ladra devia devolver a relíquia com +5 ouro")
	br.free()
	GameState.relic_ids.clear()
	var bp := _battle_with([], ["c001"], [], 3, 4, 2)
	bp.enemy["boss"] = true
	bp.enemy["phases"] = (CardDB.enemy_def("boss_hydra3").get("phases", []) as Array).duplicate(true)
	var atk0 := int(bp.enemy.attack)
	var disc0 := bp.discards_left
	bp.enemy.hp = int(bp.enemy.max_hp * 0.6)
	bp._check_phase2()
	_check(bp.phase_index == 1 and bp.phase2 and int(bp.enemy.attack) == atk0 + 2 and bp.discards_left == disc0 - 1, "a 2.ª cabeça da Hidra devia nascer aos 66 % (+2 ataque, −1 canalização)")
	bp.enemy.hp = int(bp.enemy.max_hp * 0.3)
	bp._check_phase2()
	_check(bp.phase_index == 2 and int(bp.enemy.attack) == atk0 + 4 and int(bp.rule.get("hand_size", 0)) == 5, "a 3.ª cabeça devia nascer aos 33 % (mão de 5)")
	var bp2 := BattleManager.new()
	bp2.restore(bp.to_dict())
	_check(bp2.phase_index == 2, "as fases da Hidra deviam ficar gravadas")
	bp2.free()
	bp.free()
	var bs := _battle_with([], ["c001"], ["c002", "c003", "c004", "c005", "c006", "c007", "c008"], 3, 4, 0)
	bs.rule["hand_shrink"] = 4
	bs.hand_size = 6
	bs.next_turn()
	_check(bs.hand_size == 5, "o Senhor das Marés devia encolher a mão para 5")
	bs.next_turn()
	bs.next_turn()
	_check(bs.hand_size == 4, "a mão não devia encolher abaixo de 4")
	bs.free()
	var bk := BattleManager.new()
	add_child(bk)
	var silence := CardDB.enemy_def("boss_silence").duplicate(true)
	silence["hp"] = 999999
	silence["max_hp"] = 999999
	bk.start(silence)
	var flyer := CardDB.new_instance("c041")
	_check(CardInstance.keywords_off and not flyer.has_keyword("flying"), "o Avatar do Silêncio devia desligar as palavras-chave")
	bk._finish(false)
	_check(not CardInstance.keywords_off and flyer.has_keyword("flying"), "as palavras-chave deviam voltar no fim da batalha")
	bk.queue_free()
	var bh := _battle_with([], ["c001", "c001"])
	var with_f := 0.0
	for st in bh.preview_attack().steps:
		if st.source_kind == "formation":
			with_f += st.value
	bh.rule["half_formations"] = true
	var half_f := 0.0
	for st in bh.preview_attack().steps:
		if st.source_kind == "formation":
			half_f += st.value
	_check(with_f > 0.0 and is_equal_approx(half_f, with_f * 0.5), "o Devorador devia deixar as formações a meio (%s → %s)" % [with_f, half_f])
	bh.free()
	# 4. Climas novos.
	var bc := _battle_with(["c046"], ["c041"], [], 3, 4, 2)
	bc.climate = "tailwind"
	_check(_climate_value(bc.preview_attack(), "power_add") == 20.0, "Vento Favorável: +20 Poder por criatura com Voar")
	bc.climate = "guild_festival"
	_check(_climate_value(bc.preview_attack(), "mult_add") >= 2.0, "Festival das Guildas: +2 Mult por cor")
	bc.climate = "eternal_winter"
	_check(_climate_value(bc.preview_attack(), "mult_add") == 2.0 * bc.deck.hand.size(), "Inverno Eterno: +2 Mult por carta na mão")
	bc.climate = "high_tide"
	var atk_ht := bc.enemy_attack()
	bc.climate = ""
	_check(atk_ht == bc.enemy_attack() + 1, "Maré Alta: o inimigo ataca +1")
	bc.climate = "comet_sky"
	var hp_c: int = bc.enemy.hp
	bc._climate_end_of_turn()
	_check(int(bc.enemy.hp) < hp_c, "Céu de Cometas: o inimigo devia perder vida no fim do turno")
	bc.free()
	var bl := _battle_with(["c382"], ["c001"], [], 3, 3, 0)
	bl.climate = "fertile_land"
	var m0 := bl.mana_available
	var land := _find(bl.deck.hand, "c382")
	_check(land != null and land.data.is_land() and bl.play(land), "devia poder jogar o Terreno")
	_check(bl.mana_available >= m0 + 2 and _climate_value(bl.preview_attack(), "mult_add") == 1.0, "Terra Fértil: o Terreno dá mana a mais e +1 Mult")
	bl.free()
	_check(CardDB.climates.size() >= 14, "deviam existir 14 climas")
	# 5. Conjuntos de relíquias: 2 Mox → +3 Mult; 3 → também ×1,3.
	GameState.relic_ids = ["relic_ruby", "relic_sapphire"]
	var bx := _battle_with([], ["c001"])
	var set2 := 0
	for st in bx.preview_attack().steps:
		if st.source_kind == "relic_set":
			set2 += 1
	GameState.relic_ids.append("relic_jet")
	var set3 := 0
	for st in bx.preview_attack().steps:
		if st.source_kind == "relic_set":
			set3 += 1
	_check(set2 == 1 and set3 == 2, "conjunto dos Mox: 1 bónus com 2 peças, 2 com 3 (%d, %d)" % [set2, set3])
	bx.free()
	GameState.relic_ids.clear()
	# 6. Maldições do Infinito: uma de 4 em 4 antes depois do fim; somam-se às regras.
	GameState.endless = true
	GameState.ante = GameState.max_ante + 3
	GameState.next_ante()
	_check(GameState.endless_curses.size() == 1 and not GameState.later_notes.is_empty(), "no ante 12 do Infinito devia chegar uma maldição global")
	GameState.endless_curses = ["ec_fury", "ec_vitality", "ec_haste", "ec_oblivion"]
	var turns_c := GameState.turns_for_ante(GameState.ante)
	GameState.endless_curses = []
	var turns_n := GameState.turns_for_ante(GameState.ante)
	var hand_n := GameState.hand_size_for_battle()
	GameState.endless_curses = ["ec_fury", "ec_vitality", "ec_haste", "ec_oblivion"]
	_check(turns_c == maxi(mini(turns_n, 3), turns_n - 1) and GameState.hand_size_for_battle() == hand_n - 1 and is_equal_approx(GameState.endless_hp_mult(), 1.25), "maldições: −1 turno, −1 carta e +25 % de vida")
	var bm_c := BattleManager.new()
	add_child(bm_c)
	bm_c.start({"name": "Teste", "hp": 1000, "max_hp": 1000, "attack": 2, "text": "", "abilities": []})
	bm_c.climate = ""   # o clima do Infinito pode ser a Maré Alta (+1)
	_check(bm_c.enemy_attack() == 4, "Maldição da Fúria: o inimigo ataca +2")
	bm_c.queue_free()
	GameState.endless_curses = []
	GameState.endless = false
	GameState.later_notes.clear()
	# 7. Consequências dos eventos (Cofre, Banqueiro): resolvem-se N antes depois.
	GameState.ante = 2
	GameState.gold = 5
	GameState.add_later(2, {"gold": 18}, "O Cofre devolve o depósito com juros.", "Cofre")
	GameState.next_ante()
	_check(GameState.gold == 5 and GameState.pending_later.size() == 1, "a consequência não devia chegar antes do tempo")
	GameState.next_ante()
	_check(GameState.gold == 23 and GameState.pending_later.is_empty() and GameState.later_notes.size() == 1, "o Cofre devia devolver 18 ouro dois antes depois")
	GameState.later_notes.clear()
	GameState.gold = 3
	GameState.player_hp = 20
	var lines := GameState.apply_simple_effects({"gold": -10})
	_check(GameState.gold == 0 and GameState.player_hp == 13 and lines.size() == 2, "sem ouro que chegue, a dívida paga-se em vida")
	GameState.player_hp = 20
	var evs := ["node_forge", "node_library", "node_vault", "banker", "strange_seed", "dragon_egg", "beggar", "oracle"]
	for id in evs:
		_check(not CardDB.get_event(id).is_empty(), "falta o evento %s" % id)
	_check(GameState.stop_scene("forge") == "event" and GameState.pending_event == "node_forge", "a Forja devia abrir a cena de evento")
	GameState.pending_event = ""
	for id in ["boss_inverter", "boss_relic_thief", "boss_hydra3", "boss_tides", "boss_silence", "boss_formation_eater"]:
		_check(bool(CardDB.enemy_def(id).get("boss", false)), "falta o boss %s" % id)
	print("  0.13.0 (run): consumíveis, afixos, bosses novos, climas, conjuntos, maldições do Infinito e consequências OK")

## 0.13.0 modos: Livro III da História (capítulos seguidos, bosses com a arte da Némesis, epílogo),
## Desafios com 3 estrelas, a lição de Chegada de Terreno e os 10 enigmas novos (todos com solução).
func _test_modes_0130() -> void:
	var book3: Array[int] = []
	for i in CardDB.saga.size():
		if GameState.saga_book(i) == 3:
			book3.append(i)
	_check(book3.size() == 5, "o Livro III devia ter 5 capítulos (tem %d)" % book3.size())
	var saved: Dictionary = GameState.progress.duplicate(true)
	GameState.progress["saga"] = {}
	_check(not GameState.saga_book_open(3) and not GameState.saga_unlocked(book3[0]), "o Livro III devia começar fechado")
	var n2 := 0
	for ch in CardDB.saga:
		if int(ch.get("book", 1)) == 2 and n2 < GameState.SAGA_BOOK_UNLOCK:
			GameState.progress["saga"][String(ch.get("id", ""))] = true
			n2 += 1
	_check(GameState.saga_unlocked(book3[0]) and not GameState.saga_unlocked(book3[1]), "com 3 capítulos do Livro II abre o 1.º do Livro III (só esse)")
	GameState.progress["saga"][String(CardDB.saga[book3[0]].get("id", ""))] = true
	_check(GameState.saga_unlocked(book3[1]), "acabar o 1.º capítulo do Livro III devia abrir o 2.º")
	for i in book3:
		var boss := CardDB.enemy_def(String(CardDB.saga[i].get("boss", "")))
		_check(bool(boss.get("boss", false)) and bool(boss.get("saga", false)), "o capítulo %s devia ter um boss da História" % CardDB.saga[i].get("id", ""))
	_check(String(CardDB.get_saga_chapter("saga3_5").get("epilogue", "")) != "", "o último capítulo devia ter epílogo")
	GameState.new_saga_run("saga3_1", 1320)
	GameState.ante = GameState.max_ante
	GameState.map_choice = {"battle": "boss"}
	var vex := GameState.pick_enemy(GameState.ante)
	_check(String(vex.get("id", "")) == "saga3_vex" and String(vex.get("art", "")) == "nem_vex", "o boss do capítulo devia ser a Vex, com a arte da Némesis")
	GameState.map_choice = {}
	# Desafios: estrelas (★ vencer, ★ metade da vida, ★ boss sem despertar) e o melhor fica.
	GameState.new_challenge_run(String(CardDB.challenges[0].get("id", "")), 1321)
	GameState.player_max_hp = 20
	GameState.player_hp = 15
	GameState.boss_clean = true
	_check(GameState.challenge_stars_for_run() == 3, "vida ≥ metade e boss sem despertar: 3 estrelas")
	GameState.player_hp = 5
	_check(GameState.challenge_stars_for_run() == 2, "com pouca vida: 2 estrelas")
	GameState.progress["challenge_stars"] = {String(CardDB.challenges[0].get("id", "")): 3}
	_check(GameState.challenge_stars(String(CardDB.challenges[0].get("id", ""))) == 3 and GameState.total_challenge_stars() >= 3, "as estrelas deviam ficar guardadas")
	GameState.progress = saved
	GameState.save_progress()
	GameState.clear_saved_run()
	# Lição nova e enigmas novos: o melhor golpe chega exatamente à vida do inimigo.
	_check(not CardDB.get_lesson("lesson_landfall").is_empty(), "falta a lição de Chegada de Terreno")
	GameState.new_run("deck01", 1322)
	GameState.relic_ids.clear()
	GameState.player_hp = 20
	var count := 0
	for p in CardDB.puzzles:
		var pid := String(p.get("id", ""))
		if int(pid.trim_prefix("p")) < 16:
			continue
		count += 1
		var best := PuzzleSolver.solve(p)
		_check(int(best["total"]) >= int(p.get("hp", 0)) and int(p.get("hp", 0)) > 1, "o enigma %s devia ter solução (melhor %d, vida %d)" % [pid, int(best["total"]), int(p.get("hp", 0))])
	_check(count == 10 and CardDB.puzzles.size() == 25, "deviam existir 25 enigmas (10 novos)")
	# Ecrã da História com 3 livros e o Livro III aberto.
	var saga_scene: Node = load("res://scenes/saga/Saga.tscn").instantiate()
	add_child(saga_scene)
	await get_tree().process_frame
	_check(_find_named(saga_scene, "Book3") != null, "a História devia ter o separador do Livro III")
	saga_scene.call("_show_book", 3)
	await get_tree().process_frame
	_check(_find_named(saga_scene, "Chapter_saga3_1") != null, "o Livro III devia mostrar os seus capítulos")
	saga_scene.queue_free()
	await get_tree().process_frame
	var ch_scene: Node = load("res://scenes/challenges/Challenges.tscn").instantiate()
	add_child(ch_scene)
	await get_tree().process_frame
	_check(_has_text_in(ch_scene, "★"), "os Desafios deviam mostrar as estrelas")
	ch_scene.queue_free()
	await get_tree().process_frame
	print("  0.13.0 (modos): Livro III, estrelas dos Desafios, lição de Chegada de Terreno e 10 enigmas novos OK")

## Soma dos passos do clima com esta ação.
func _climate_value(c: Cascade, action: String) -> float:
	var v := 0.0
	for st in c.steps:
		if st.source_kind == "climate" and st.action == action:
			v += st.value
	return v

## 0.13.0 run nas cenas: Forja das Edições, Biblioteca, mapa (fichas das poções, promessas e "Entretanto…"),
## poção na loja e a barra das poções na batalha.
func _test_run_scenes_0130() -> void:
	GameState.free_mode = false
	GameState.new_run("deck01", 1311)
	GameState.add_gold(40)
	# Forja: pagar 6 e escolher a carta que fica Brilhante.
	GameState.pending_event = "node_forge"
	var forge: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(forge)
	await get_tree().process_frame
	var gold0 := GameState.gold
	((forge._options_box as VBoxContainer).get_child(0) as Button).pressed.emit()
	for f in 3:
		await get_tree().process_frame
	var viewer := SceneRouter.top_overlay()
	_check(viewer is ZoneViewer, "a Forja devia abrir o baralho para escolher a carta")
	if viewer is ZoneViewer:
		var fv := _first_card_view(viewer)
		var picked: CardInstance = fv.card
		viewer.call("_on_card_pressed", picked)
		for f in 3:
			await get_tree().process_frame
		_check(String(GameState.deck[picked.entry_index].get("edition", "")) == "shiny" and GameState.gold == gold0 - 6, "a carta devia ficar Brilhante por 6 ouro")
	SceneRouter.close_overlays()
	forge.queue_free()
	await get_tree().process_frame
	# Biblioteca: copiar um pergaminho.
	GameState.pending_event = "node_library"
	var lib: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(lib)
	await get_tree().process_frame
	((lib._options_box as VBoxContainer).get_child(1) as Button).pressed.emit()
	for f in 3:
		await get_tree().process_frame
	_check(GameState.consumables.size() == 1 and String(CardDB.get_consumable(GameState.consumables[0]).get("kind", "")) == "scroll", "a Biblioteca devia dar um pergaminho")
	lib.queue_free()
	await get_tree().process_frame
	# Mapa: ficha do pergaminho, promessas e o que aconteceu entre antes.
	GameState.add_later(2, {"gold": 18}, "O Cofre devolve o depósito com juros.", "Cofre")
	GameState.later_notes = ["Teste: aconteceu uma coisa."]
	GameState.map_phase = "battle"
	var map: Node = load("res://scenes/map/Map.tscn").instantiate()
	add_child(map)
	for f in 4:
		await get_tree().process_frame
	_check(_find_named(map, "ItemChip0") != null, "o mapa devia mostrar a ficha do pergaminho")
	var dlg := SceneRouter.top_overlay()
	while dlg != null and not (dlg is ChoiceDialog):
		dlg.queue_free()
		await get_tree().process_frame
		dlg = SceneRouter.top_overlay()
	_check(dlg is ChoiceDialog and GameState.later_notes.is_empty(), "o mapa devia mostrar o que aconteceu entre antes (uma vez)")
	SceneRouter.close_overlays()
	map.queue_free()
	await get_tree().process_frame
	GameState.pending_later.clear()
	# Loja: uma poção ou pergaminho à venda.
	GameState.consumables.clear()
	GameState.map_options(1)
	GameState.choose_stop("shop")
	var shop: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	add_child(shop)
	await get_tree().process_frame
	var offer: Button = _find_named(shop, "ItemOffer")
	_check(offer != null, "a loja devia ter uma poção ou pergaminho à venda")
	if offer != null:
		offer.pressed.emit()
		await get_tree().process_frame
		_check(GameState.consumables.size() == 1, "comprar devia guardar o consumível")
	shop.queue_free()
	await get_tree().process_frame
	# Batalha: a barra das poções e usar uma.
	GameState.consumables = ["potion_mana"]
	GameState.clear_saved_run()
	var st := {"enemy": {"id": "test", "name": "Teste", "hp": 99999, "max_hp": 99999, "attack": 1, "text": "", "abilities": [], "boss": false, "rule": {}},
		"turn": 1, "max_turns": 5, "mana_total": 2, "mana_available": 2, "discards_left": 3, "player_hp": GameState.player_hp,
		"library": [], "hand": [{"id": "c001", "entry": -1}], "graveyard": [], "board": [], "exile": []}
	GameState.pending_battle = st
	var b: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(b)
	EventBus.battle_ended.disconnect(b._on_battle_ended)
	for f in 3:
		await get_tree().process_frame
	_check(_find_named(b, "ItemsBar") != null and _find_named(b, "Item0") != null, "a batalha devia mostrar a barra das poções")
	var bm: BattleManager = b.get_node("BattleManager")
	var mana0 := bm.mana_available
	b.call("_use_item", 0)
	await get_tree().process_frame
	_check(bm.mana_available == mana0 + 2 and GameState.consumables.is_empty(), "usar a Poção de Mana na batalha devia dar +2 de mana")
	b.queue_free()
	await get_tree().process_frame
	GameState.clear_saved_run()
	print("  0.13.0 (run, cenas): Forja, Biblioteca, mapa com poções e promessas, loja e barra das poções OK")

func _find_named(root: Node, nm: String) -> Node:
	var stack: Array = [root]
	while not stack.is_empty():
		var n: Node = stack.pop_back()
		if n.name == nm and not n.is_queued_for_deletion():
			return n
		stack.append_array(n.get_children())
	return null

## Soma dos valores de uma ação vindos de uma carta na cascata.
func _step_value(c: Cascade, card_id: String, action: String) -> float:
	var v := 0.0
	for st in c.steps:
		if st.source_card != null and st.source_card.data.id == card_id and st.action == action and not st.retrigger:
			v += st.value
	return v

## A carta disparou de novo (reativada) na cascata?
func _retriggered(c: Cascade, card_id: String) -> bool:
	for st in c.steps:
		if st.retrigger and st.source_card != null and st.source_card.data.id == card_id:
			return true
	return false

## 0.13.0 na cena da batalha: números de ordem, setas, escolher quem bloqueia, palavra-chave explicada,
## total ao vivo ao arrastar, sem jogadas, dicas no topo, rever o ataque, morte em pó e mana guardada.
func _test_scenes_0130() -> void:
	GameState.free_mode = false
	GameState.new_run("deck01", 1302)
	GameState.relic_ids.clear()
	GameState.difficulty = "normal"
	Settings.anim_speed = "normal"
	Settings.show_threats = true
	GameState.choose_battle("scout")
	var b = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(b)
	EventBus.battle_ended.disconnect(b._on_battle_ended)
	await get_tree().process_frame
	var bm: BattleManager = b.get_node("BattleManager")
	bm.enemy["abilities"] = [{"trigger": "turn_end", "action": "jail_strongest"}]
	bm.enemy["attack"] = 3
	bm.enemy.hp = 99999999   # nunca letal (com ataque letal não há contra-ataque nem ameaças)
	bm.enemy.max_hp = 99999999
	for id in ["c001", "c013", "c015"]:
		var c := CardDB.new_instance(id)
		c.zone = CardInstance.Zone.BOARD
		bm.board.append(c)
	b._refresh_board()
	b._refresh_preview()
	await get_tree().process_frame
	await get_tree().process_frame
	_check(b._overlay != null and b._overlay.badges.size() == 3, "com 3 criaturas deviam aparecer 3 números de ordem")
	var strongest: CardInstance = bm._strongest_unprotected(bm.board)
	var has_jail := false
	for t in b._overlay.threats:
		if t["node"] == b._board_views.get(strongest.uid) and bool(t["arrow"]) and String(t["text"]) == b.tr("PRESA"):
			has_jail = true
	_check(has_jail, "devia haver uma seta e a etiqueta PRESA na criatura que o Carcereiro vai prender")
	# Escolher quem bloqueia (tocar na intenção).
	var goblin := _find(bm.board, "c001")
	b._open_intent()
	await get_tree().process_frame
	var btn: Button = _find_node(b._modal, func(n): return n is Button and n.name == "Block_%d" % goblin.uid) if b._modal != null else null
	_check(btn != null, "a janela da intenção devia ter um botão para cada criatura bloquear")
	if btn != null:
		btn.pressed.emit()
		await get_tree().process_frame
		_check(bm.chosen_blocker == goblin.uid, "tocar na criatura devia escolhê-la para bloquear")
		_check(b._intent_sig.contains("|%d" % goblin.uid), "a intenção devia mostrar a escolha")
	# Palavra-chave: o ícone de Voar da Djinn explica-se.
	var djinn := _find(bm.board, "c015")
	var dv: CardView = b._board_views.get(djinn.uid)
	var kw_hit := {}
	if dv != null and dv._kw_box != null and dv._kw_box.get_child_count() > 0:
		var ic: Control = dv._kw_box.get_child(0)
		kw_hit = dv.keyword_at(ic.get_global_rect().get_center())
	_check(String(kw_hit.get("kw", "")) == "flying", "tocar no ícone de Voar devia encontrar a palavra-chave")
	if not kw_hit.is_empty():
		dv.keyword_tapped.emit(djinn, "flying", kw_hit["rect"])
		await get_tree().process_frame
		_check(b._kw_bubble != null and is_instance_valid(b._kw_bubble), "devia aparecer o balão com a explicação de Voar")
	# Total ao vivo: arrastar uma carta para a Arena mostra o ataque com ela.
	bm.mana_available = 20
	var pick: CardInstance = null
	for c in bm.deck.hand:
		if not c.data.is_land() and bm.can_play(c):
			pick = c
			break
	if pick != null:
		b._show_what_if(pick)
		_check(b._what_if and b.total_label.text == Cascade.fmt_int(bm.preview_cascade_with(pick).net_total()), "a arrastar, o total devia ser o do ataque com a carta")
		b._refresh_preview()
		_check(not b._what_if and b.total_label.text == Cascade.fmt_int(bm.preview_attack().net_total()), "ao largar fora, o total devia voltar ao de agora")
	# Sem jogadas: aviso no topo e ATACAR a brilhar.
	bm.mana_available = 0
	bm.land_played_this_turn = true
	bm.actions_this_turn = 1   # já jogou (sem Mulligan à vista)
	b._no_plays_turn = 0
	b._refresh_preview()
	await get_tree().process_frame
	await get_tree().process_frame
	_check(b._attack_glow != null and b._attack_glow.is_valid(), "sem jogadas, o ATACAR devia brilhar")
	_check(b._notice != null and is_instance_valid(b._notice) and b._notice.global_position.y < 80.0, "o aviso \"sem jogadas\" devia aparecer no topo")
	bm.mana_available = 20
	b._refresh_preview()
	_check(b._attack_glow == null, "com jogadas outra vez, o brilho devia parar")
	# Dica no topo (fora do cálculo).
	Settings.tips_enabled = true
	Stats.set_tutorial_done(true)
	GameState.reset_tips()
	b._tip_queue.clear()
	if b._tip_panel != null and is_instance_valid(b._tip_panel):
		b._tip_panel.queue_free()
		b._tip_panel = null
	b._tip("block")
	await get_tree().process_frame
	await get_tree().process_frame
	_check(b._tip_panel != null and is_instance_valid(b._tip_panel) and b._tip_panel.global_position.y < 80.0, "a dica devia aparecer no topo do ecrã")
	# Rever o último ataque.
	b._last_cascade = bm.preview_attack()
	b._last_attack_turn = 1
	b._replay_last_attack()
	await get_tree().process_frame
	_check(SceneRouter.top_overlay() is CascadeReplay, "devia abrir o rever do último ataque")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	# Morte em pó e mana guardada (cristais dourados a mais).
	var gv: CardView = b._board_views.get(goblin.uid)
	b._animate_death(gv)
	_check(_find_node(b, func(n): return n is DustFx) != null, "a criatura que morre devia desfazer-se em pó")
	b._mana_pips.set_mana(4, 3)
	_check(b._mana_pips._count() == 4, "a mana guardada devia aparecer como cristal a mais")
	b.queue_free()
	await get_tree().process_frame
	print("  0.13.0 (cena): ordem, setas, bloqueio, palavras-chave, total ao vivo, sem jogadas, dicas no topo, rever, pó e mana OK")

## 0.13.0 (relato do Paulo): DESFAZER num enigma não o torna numa run; perder um enigma nunca apaga o
## jogo guardado e oferece TENTAR OUTRA VEZ; o ATACAR não fica preso no fundo do Mulligan; a última run
## apagada ou substituída recupera-se.
func _test_saves_0130() -> void:
	# 1. Desfazer num enigma continua a ser um enigma.
	var pz := BattleManager.new()
	pz.start_puzzle(CardDB.get_puzzle("p1"))
	var snap := pz.snapshot()
	pz.restore_snapshot(snap)
	_check(pz.puzzle, "depois de DESFAZER, um enigma tem de continuar a ser um enigma")
	pz.free()
	# 2. Perder um enigma (mesmo que a flag se perdesse) não apaga a run do espaço e mostra TENTAR OUTRA VEZ.
	GameState.current_slot = 2
	GameState.new_run("deck03", 4242)
	GameState.ante = 3
	GameState.save_run({}, "map")
	var saved := FileAccess.get_file_as_string(GameState.slot_path(2))
	GameState.reset_for_side_battle("p1")
	var b = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(b)
	await get_tree().process_frame
	var bm: BattleManager = b.get_node("BattleManager")
	bm.puzzle = false   # o caso do erro antigo: o jogo esqueceu-se de que era um enigma
	bm.enemy.hp = 99999999
	b._on_end_turn()
	_check(await _wait_until(func(): return b._modal != null and is_instance_valid(b._modal) and b._modal.name == "PuzzleResult", 12000), "perder um enigma devia mostrar o resultado com TENTAR OUTRA VEZ")
	if b._modal != null and is_instance_valid(b._modal):
		_check(_find_node(b._modal, func(n): return n is Button and n.name == "RetryPuzzle") != null, "devia haver o botão TENTAR OUTRA VEZ")
	_check(FileAccess.file_exists(GameState.slot_path(2)) and FileAccess.get_file_as_string(GameState.slot_path(2)) == saved, "perder um enigma nunca pode apagar nem mudar o jogo guardado")
	b.queue_free()
	await get_tree().process_frame
	GameState.puzzle_id = ""
	# 3. ATACAR no fundo do Mulligan: avisa e não fica preso.
	GameState.load_run(2)
	GameState.choose_battle("scout")
	var b2 = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(b2)
	EventBus.battle_ended.disconnect(b2._on_battle_ended)
	await get_tree().process_frame
	var bm2: BattleManager = b2.get_node("BattleManager")
	bm2.pending_bottom = 1
	b2._refresh_all()
	_check(b2.end_turn_btn.disabled, "no fundo do Mulligan o ATACAR devia estar desligado")
	b2._on_end_turn()
	_check(not bm2.resolving, "atacar no fundo do Mulligan não devia começar o ataque")
	bm2.pending_bottom = 0
	b2._refresh_all()
	_check(not b2.end_turn_btn.disabled, "depois do fundo do Mulligan o ATACAR devia voltar")
	b2.queue_free()
	await get_tree().process_frame
	# 4. Recuperar a última run substituída.
	GameState.current_slot = 2
	GameState.slot_confirmed = true
	GameState.claim_slot_for_new_run()
	_check(not FileAccess.file_exists(GameState.slot_path(2)) and GameState.has_trash(), "substituir um jogo devia guardar uma cópia para recuperar")
	_check(String(GameState.trash_info().get("what", "")) != "", "a run para recuperar devia ter um resumo")
	var back_slot := GameState.restore_trash()
	var restored = JSON.parse_string(FileAccess.get_file_as_string(GameState.slot_path(2))) if FileAccess.file_exists(GameState.slot_path(2)) else null
	var original = JSON.parse_string(saved)
	_check(back_slot == 2 and restored is Dictionary and int(restored.get("ante", 0)) == 3 and int(restored.get("seed", 0)) == int(original.get("seed", -1)) and String(restored.get("deck_id", "")) == "deck03" and not GameState.has_trash(), "RECUPERAR devia pôr a run de volta no espaço 2")
	GameState.delete_slot(2)
	GameState.current_slot = 1
	print("  0.13.0 (saves): desfazer no enigma, enigma sem apagar o jogo + TENTAR OUTRA VEZ, ATACAR no Mulligan e recuperar run OK")

## 0.13.0 (progressão): costas por cor completa, mestria, Pesadelo, Selos Planares na Run Rápida e no
## Construtor, e o separador PERFIL das Estatísticas.
func _test_progress_0130() -> void:
	var saved_p: Dictionary = GameState.progress.duplicate(true)
	var saved_diff := GameState.difficulty
	var old_lang := Settings.language
	Settings.language = "pt"
	Settings.apply()
	Stats._ensure()
	GameState.progress["achievements"] = []
	GameState.progress["unlocks"] = {}
	# 1. Completar uma cor da Coleção dá umas costas de carta.
	GameState.progress["seen"]["cards"] = {}
	GameState.progress["stats"]["color_sets"] = 0
	var whites := Stats.color_set_ids("white")
	var bad := 0
	for id in whites:
		var cd := CardDB.get_card(id)
		if cd.token or cd.is_curse() or not cd.has_color("white"):
			bad += 1
	_check(whites.size() >= 60 and bad == 0, "a cor branca devia ter as suas cartas, sem Fichas nem Maldições (%d, %d más)" % [whites.size(), bad])
	for i in whites.size() - 1:
		Stats.mark_seen("cards", whites[i], false)
	var pr := Stats.color_set_progress("white")
	_check(pr == Vector2i(whites.size() - 1, whites.size()), "o progresso da cor branca devia ser %d/%d (é %d/%d)" % [whites.size() - 1, whites.size(), pr.x, pr.y])
	_check(not Stats.is_content_unlocked("back", "full_white"), "as costas brancas só depois de a cor estar completa")
	Stats.mark_seen("cards", whites[whites.size() - 1], false)
	_check(Stats.is_content_unlocked("back", "full_white") and "full_white" in Settings.unlocked_cosmetics("back"), "completar o branco devia dar as costas Coleção Branca")
	_check(Stats.get_stat("color_sets") == 1 and Stats.is_unlocked("color_set_1") and Stats.completed_color_sets() == 1, "uma cor completa devia contar (conquista Uma Cor Inteira)")
	_check(Stats.color_progress_text().contains(tr("Branco")) and Stats.color_progress_text().contains("✓"), "a linha das cores devia marcar o branco com ✓")
	(GameState.progress["unlocks"] as Dictionary).erase("back:full_white")
	Stats.check_color_sets()
	_check(Stats.is_content_unlocked("back", "full_white"), "quem já tinha a cor completa devia receber as costas ao abrir a Coleção")
	for b in (CardDB.cosmetics.get("backs", []) as Array):
		if String(b.get("color_set", "")) != "":
			_check(String(b.get("color_set", "")) in Stats.COLOR_SET_NAMES and ["diamond", "sun", "waves", "eclipse", "flame", "leaf", "prism", "crown"].has(String(b.get("pattern", ""))), "costas de cor com cor ou padrão errados: %s" % b.get("id", ""))
	var coll = load("res://scenes/ui/Collection.tscn").instantiate()
	add_child(coll)
	await get_tree().process_frame
	var cp = coll.find_child("ColorProgress", true, false)
	_check(cp is Label and String(cp.text).contains(tr("Azul")), "a Coleção devia mostrar as cartas descobertas por cor")
	coll.queue_free()
	await get_tree().process_frame
	# 2. Mestria: 15 / 50 / 120 jogadas, somadas em todas as runs.
	GameState.progress["card_stats"] = {"c001": {"plays": 14}, "c002": {"plays": 50}, "c003": {"plays": 130}}
	_check(GameState.card_mastery("c001") == 0 and GameState.card_mastery("c002") == 2 and GameState.card_mastery("c003") == 3, "mestria: 14 jogadas = nada, 50 = Prata, 130 = Ouro")
	GameState.progress["stats"]["masteries"] = 0
	GameState.free_mode = true
	GameState.new_run("deck01", 77)
	GameState.run_log["card_plays"] = {"c001": 2}
	GameState.record_run_end(3, false)
	GameState.free_mode = false
	var c001 := CardDB.get_card("c001").display_name()
	_check(GameState.card_mastery("c001") == 1 and GameState.last_unlocks.has(tr("Mestria %s: %s") % [tr("Bronze"), c001]), "16 jogadas deviam dar a Mestria Bronze (e aparecer no fim da run)")
	_check(Stats.get_stat("masteries") == 1 and Stats.is_unlocked("mastery_1"), "uma carta com Mestria de Ouro devia dar a conquista Mão Experiente")
	var mv: CardView = load("res://scenes/ui/CardView.tscn").instantiate()
	add_child(mv)
	mv.setup(CardDB.new_instance("c003"))
	await get_tree().process_frame
	_check(mv._mastery_badge != null, "uma carta com mestria devia ter a medalha na borda")
	mv.queue_free()
	# 3. Pesadelo: aparece depois de vencer no Difícil; inimigos com o dobro da vida e +1 de ataque.
	GameState.progress["stats"]["wins_hard"] = 0
	GameState.progress["stats"]["wins_nightmare"] = 0
	GameState.difficulty = "dificil"
	GameState.cycle_difficulty()
	_check(GameState.difficulty == "facil", "sem vitórias no Difícil o Pesadelo não aparece (Difícil → Fácil)")
	GameState.difficulty = "dificil"
	_check(GameState.difficulty_text().contains(tr("Vence uma run no Difícil para abrir o Pesadelo.")), "o Difícil devia dizer como se abre o Pesadelo")
	GameState.progress["stats"]["wins_hard"] = 1
	GameState.cycle_difficulty()
	_check(GameState.difficulty == "pesadelo" and GameState.nightmare_unlocked(), "depois de vencer no Difícil vem o Pesadelo")
	GameState.new_run("deck01", 78)
	_check(int(GameState.battle_rules().get("enemy_attack_plus", 0)) == 1 and is_equal_approx(float(GameState.DIFFICULTY_HP["pesadelo"]), 2.0), "no Pesadelo os inimigos atacam +1 e têm o dobro da vida")
	_check(GameState.difficulty_text().contains(tr("Os inimigos atacam +%d.") % 1), "o texto do Pesadelo devia dizer o ataque extra")
	Stats.on_run_end(true)
	_check(Stats.get_stat("wins_nightmare") == 1 and Stats.get_stat("wins_hard") == 2 and Stats.is_unlocked("nightmare_win") and Stats.is_content_unlocked("back", "nightmare"), "vencer no Pesadelo conta também como Difícil e dá as costas Pesadelo")
	GameState.difficulty = saved_diff
	# 4. Selos Planares na Run Rápida (escada própria) e nos baralhos do Construtor.
	GameState.progress["stakes"] = {}
	GameState.progress.erase("quick_stakes")
	GameState.progress.erase("custom_stakes")
	_check(GameState.max_stake("deck05", true) == 1, "na Run Rápida, sem vitórias, só o Selo 1")
	GameState.new_quick_run("deck05", 1, 123)
	GameState.record_run_end(4, true)
	GameState.free_mode = false
	_check(GameState.quick_stake_won("deck05") == 1 and GameState.max_stake("deck05", true) == 2 and GameState.last_unlocks.has(tr("Selo Planar %d aberto") % 2), "vencer uma Run Rápida no Selo 1 devia abrir o Selo 2")
	_check(GameState.stake_won("deck05") == 0, "a Run Rápida não mexe nos Selos da campanha")
	GameState.progress["stakes"]["deck05"] = 4
	_check(GameState.max_stake("deck05", true) == 5, "na Run Rápida conta também o Selo vencido na campanha")
	var custom := {"id": "custom_6", "num": 0, "name": "Teste", "custom": true, "cards": ["c001", "c001", "c002", "c003", "c004", "c005", "c006", "c007", "c008", "c009"], "colors": ["red"], "size": 10, "difficulty": 0, "mechanic": "x"}
	CardDB.custom_decks["custom_6"] = custom
	GameState.free_mode = true
	GameState.new_run("custom_6", 55, 2)
	GameState.record_run_end(8, true)
	GameState.free_mode = false
	_check(GameState.custom_stake_won("custom_6") == 2 and GameState.max_stake("custom_6") == 3 and Stats.get_stat("custom_stake") == 2, "vencer com um baralho do Construtor no Selo 2 devia abrir o Selo 3")
	CardDB.custom_decks.erase("custom_6")
	GameState.progress["custom_stakes"]["custom_1"] = 2
	var db = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	add_child(db)
	await get_tree().process_frame
	var sb = db.find_child("Stake", true, false)
	_check(sb is Button and String(sb.text).begins_with(tr("SELO %d") % 1), "o Construtor devia ter o botão do Selo Planar")
	if sb is Button:
		sb.pressed.emit()
		_check(db._stake == 2 and String(sb.text).begins_with(tr("SELO %d") % 2), "tocar no Selo devia passar ao Selo 2")
		sb.pressed.emit()
		sb.pressed.emit()
		_check(db._stake == 1, "depois do Selo mais alto aberto (3) devia voltar ao 1")
	db.queue_free()
	await get_tree().process_frame
	# 5. Perfil (separador das Estatísticas).
	GameState.progress["card_stats"] = {"c003": {"plays": 130, "dmg": 5000, "runs": 10, "wins": 4}, "c010": {"plays": 20, "dmg": 90000, "runs": 3, "wins": 1}}
	var st = load("res://scenes/ui/StatsScreen.tscn").instantiate()
	add_child(st)
	await get_tree().process_frame
	_check(st.tab == "profile" and st.find_child("Tab_profile", true, false) != null, "as Estatísticas deviam abrir no PERFIL")
	_check(st.find_child("ProfileCard", true, false) != null and st.find_child("ProfileProgress", true, false) != null, "o Perfil devia ter o cartão e o progresso")
	var mp = st.find_child("MostPlayed", true, false)
	_check(mp is CardView and (mp as CardView).card.data.id == "c003", "o Perfil devia mostrar a carta mais jogada (c003)")
	_check(st.top_card("dmg") == "c010" and st.mastery_counts() == [1, 0, 1], "o Perfil devia saber a carta com mais dano e as mestrias")
	_check(st.profile_title(0)[0] == "Aprendiz" and st.profile_title(30)[0] == "Arcanista" and int(st.profile_title(30)[1]) == 45 and int(st.profile_title(500)[1]) == 0, "títulos do Perfil errados")
	_check(_has_text_in(st, tr("Carta mais jogada")) and _has_text_in(st, tr("Cartas descobertas")), "o Perfil devia mostrar os destaques e o progresso")
	st.queue_free()
	await get_tree().process_frame
	GameState.progress = saved_p
	GameState.difficulty = saved_diff
	GameState.save_progress()
	Settings.language = old_lang
	Settings.apply()
	print("  0.13.0 (progressão): costas por cor, mestria, Pesadelo, Selos na Run Rápida e no Construtor, Perfil OK")

## 0.13.0 (apresentação e conforto): mão maior, modo de uma mão, carta em 3D, curva de mana, mapa vivo,
## temas das guildas e a música a crescer no ataque.
func _test_presentation_0130() -> void:
	var saved_scale := Settings.hand_scale
	var saved_one := Settings.one_hand
	var saved_tilt := Settings.tilt_3d
	var saved_left := Settings.left_handed
	Settings.anim_speed = "normal"
	Settings.reduce_motion = false
	Settings.performance_mode = false
	# 1. Tamanho das cartas da mão e modo de uma mão na batalha.
	Settings.hand_scale = 1.3
	Settings.one_hand = true
	Settings.left_handed = false
	GameState.free_mode = false
	GameState.new_run("deck01", 1303)
	GameState.relic_ids.clear()
	GameState.choose_battle("scout")
	var b = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(b)
	EventBus.battle_ended.disconnect(b._on_battle_ended)
	await get_tree().process_frame
	await get_tree().process_frame
	var hv: CardView = null
	for v in b._hand_views.values():
		hv = v
		break
	var big := (CardView.SIZE_NORMAL * 1.3).round()
	_check(hv != null and hv.custom_minimum_size == big and is_equal_approx(hv.size_scale, 1.3), "com a mão a 130 %% as cartas deviam ter %s (têm %s)" % [str(big), str(hv.custom_minimum_size) if hv else "—"])
	var thumb = b.find_child("ThumbCol", true, false)
	_check(thumb != null and b.end_turn_btn.get_parent() == thumb and b.discard_btn.get_parent() == thumb and b.undo_btn.get_parent() == thumb, "no modo de uma mão, ATACAR, CANALIZAR e DESFAZER deviam estar ao lado da mão")
	_check(thumb != null and thumb.get_index() == thumb.get_parent().get_child_count() - 1, "no modo de uma mão (destro) os botões ficam à direita da mão")
	Settings.left_handed = true
	Settings.apply()
	await get_tree().process_frame
	_check(thumb != null and is_instance_valid(thumb) and thumb.get_index() == 0, "no modo canhoto os botões de uma mão ficam à esquerda da mão")
	Settings.left_handed = false
	Settings.one_hand = false
	Settings.hand_scale = 1.0
	Settings.apply()
	await get_tree().process_frame
	var left_col = b.layout.get_node("Middle/LeftCol")
	_check(b.find_child("ThumbCol", true, false) == null and b.end_turn_btn.get_parent() == left_col and b.end_turn_btn.get_index() == 1 and b.undo_btn.get_parent().name == "ZonesRow", "desligar o modo de uma mão devia devolver os botões ao sítio")
	_check(b.hand_box.get_parent() == b.layout, "desligar o modo de uma mão devia devolver a mão ao fundo do ecrã")
	for v in b._hand_views.values():
		if is_instance_valid(v):
			_check((v as CardView).custom_minimum_size == CardView.SIZE_NORMAL, "a mão a 100 %% devia voltar ao tamanho normal")
			break
	# 2. A música cresce no ataque: a camada de percussão do andamento entra na cascata e sai no fim.
	for bpm in Music.TRACK_BPM.values():
		_check(ResourceLoader.exists(Music.drive_path(int(bpm))), "falta a camada de ataque de %d bpm" % int(bpm))
	Music.play("act1")
	await get_tree().process_frame
	var casc := Cascade.new()
	EventBus.cascade_presented.emit(casc)
	_check(Music._drive.stream != null and String(Music._drive.stream.resource_path).ends_with("music_drive_100.ogg"), "no ato I (100 bpm) a camada de ataque devia ser a de 100 bpm")
	EventBus.cascade_finished.emit()
	b.queue_free()
	await get_tree().process_frame
	_check(EventBus.cascade_started.get_connections().is_empty(), "fora da batalha ninguém pode ouvir cascade_started (o BattleManager ficava à espera da UI)")
	# 3. Temas das guildas na História.
	for ch in CardDB.saga:
		var m := String((ch as Dictionary).get("music", ""))
		if m != "":
			_check(Music.has_track(m) and Music.TRACK_BPM.has(m), "falta o tema %s (ou o seu andamento)" % m)
	GameState.new_saga_run("saga_izzet")
	_check(Music.act_track() == "guild_izzet" and Music.track_for_scene("map") == "guild_izzet", "o capítulo da Izzet devia tocar o tema da guilda")
	GameState.new_saga_run("saga_white")
	_check(Music.act_track().begins_with("act"), "os capítulos sem tema tocam a faixa do ato")
	GameState.saga_id = ""
	GameState.mode = "campaign"
	Music.play("menu")
	# 4. Carta em grande em 3D.
	Settings.tilt_3d = true
	CardZoom.show_data(CardDB.get_card("c005"))
	await get_tree().process_frame
	await get_tree().process_frame
	var z: CardZoom = SceneRouter.top_overlay() as CardZoom
	_check(z != null and z._tilt_on and z.find_child("TiltSheen", true, false) != null and z.find_child("TiltShadow", true, false) != null, "a carta em grande devia ter o brilho e a sombra do efeito 3D")
	if z != null and z._tilt_on:
		z.set_tilt(Vector2(0.8, -0.5))
		_check(absf(z._panel.rotation) > 0.01 and z._panel.scale.x < 1.0 and (z._sheen.material as ShaderMaterial).get_shader_parameter("tilt") == Vector2(0.8, -0.5), "inclinar devia rodar a carta e mexer o reflexo")
		z.close()
	await get_tree().process_frame
	Settings.tilt_3d = false
	CardZoom.show_data(CardDB.get_card("c005"))
	await get_tree().process_frame
	var z2: CardZoom = SceneRouter.top_overlay() as CardZoom
	_check(z2 != null and not z2._tilt_on, "com o 3D desligado a carta em grande fica direita")
	if z2 != null:
		z2.close()
	await get_tree().process_frame
	# 5. Curva de mana: no baralho da run e no Construtor.
	var curve := ManaCurve.new()
	curve.set_cards([CardDB.get_card("c001"), CardDB.get_card("c001"), CardDB.get_card("c002")])
	var c1 := CardDB.get_card("c001")
	_check(curve.count_at(c1.cost) >= 2 and curve.average_cost() > 0.0, "a curva de mana devia contar as cartas por custo")
	curve.free()
	GameState.new_run("deck01", 1304)
	var zv := ZoneViewer.open_deck("O TEU BARALHO")
	await get_tree().process_frame
	var zc = zv.find_child("ManaCurve", true, false)
	var lands := 0
	for e in GameState.deck:
		if CardDB.get_card(String(e["id"])).is_land():
			lands += 1
	_check(zc is ManaCurve and (zc as ManaCurve).lands == lands, "ver o baralho devia mostrar a curva de mana (com %d terrenos)" % lands)
	var zv2 := ZoneViewer.open_deck("ESCOLHE", func(_c): pass)
	await get_tree().process_frame
	_check(zv2.find_child("ManaCurve", true, false) == null, "a escolher uma carta não aparece a curva")
	zv2.close()
	zv.close()
	await get_tree().process_frame
	var db = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	add_child(db)
	await get_tree().process_frame
	_check(db.find_child("ManaCurve", true, false) is ManaCurve, "o Construtor devia mostrar a curva de mana")
	db.queue_free()
	await get_tree().process_frame
	# 6. Mapa vivo.
	GameState.new_run("deck01", 1305)
	GameState.map_options(1)
	var mp = load("res://scenes/map/Map.tscn").instantiate()
	add_child(mp)
	await get_tree().process_frame
	await get_tree().process_frame
	var bd = mp.find_child("MapBackdrop", true, false)
	_check(bd is MapBackdrop and (bd as MapBackdrop).act == 1 and mp.is_processing(), "o mapa devia ter a névoa e os pirilampos e animar os caminhos")
	_check(mp.find_child("DeckBtn", true, false) is Button, "o mapa devia ter o botão VER BARALHO")
	mp.queue_free()
	await get_tree().process_frame
	Settings.hand_scale = saved_scale
	Settings.one_hand = saved_one
	Settings.tilt_3d = saved_tilt
	Settings.left_handed = saved_left
	Settings.apply()
	print("  0.13.0 (apresentação): mão 130 %, uma mão, música no ataque, temas das guildas, carta 3D, curva de mana e mapa vivo OK")

# ---------------------------------------------------------------------------
## 0.13.1: a Campanha abre no Livro I (antes abria no livro mais avançado já aberto), lembra-se do
## livro escolhido ao voltar ao ecrã, e a Run Rápida tem a sua própria memória.
func _test_campaign_0131() -> void:
	(load("res://scenes/campaign/Campaign.gd") as GDScript).set("_last_act", {"campaign": 0, "free": 0, "quick": 0})   # 0.14.0: começa limpo
	var saved_best: Dictionary = (GameState.progress["best_ante"] as Dictionary).duplicate()
	var saved_free := GameState.free_mode
	GameState.free_mode = false
	GameState.launch_mode = ""
	GameState.progress["best_ante"]["deck01"] = 6   # chega ao ante 6 com um baralho do Livro I: abre o Livro II
	_check(GameState.is_act_unlocked(1), "com o ante 6 num baralho do Livro I, o Livro II devia abrir")
	var camp = load("res://scenes/campaign/Campaign.tscn").instantiate()
	add_child(camp)
	await get_tree().process_frame
	var acts: HBoxContainer = camp.get_node("%ActButtons")
	_check(int(camp.get("_act_index")) == 0 and (acts.get_child(0) as Button).button_pressed and not (acts.get_child(1) as Button).button_pressed,
		"a Campanha devia abrir no Livro I, mesmo com o Livro II aberto")
	(acts.get_child(1) as Button).pressed.emit()
	_check(int(camp.get("_act_index")) == 1, "tocar no Livro II devia mostrá-lo")
	camp.queue_free()
	await get_tree().process_frame
	camp = load("res://scenes/campaign/Campaign.tscn").instantiate()
	add_child(camp)
	await get_tree().process_frame
	_check(int(camp.get("_act_index")) == 1, "ao voltar à Campanha devia ficar no último livro escolhido")
	(camp.get_node("%ActButtons").get_child(0) as Button).pressed.emit()
	camp.queue_free()
	await get_tree().process_frame
	# Run Rápida: tudo aberto, mas também começa no Livro I (antes abria no Livro III).
	GameState.launch_mode = "quick"
	var quick = load("res://scenes/campaign/Campaign.tscn").instantiate()
	add_child(quick)
	await get_tree().process_frame
	_check(int(quick.get("_act_index")) == 0, "a Run Rápida devia abrir no Livro I")
	quick.queue_free()
	await get_tree().process_frame
	GameState.launch_mode = ""
	GameState.free_mode = saved_free
	GameState.progress["best_ante"] = saved_best
	print("  0.13.1: a Campanha e a Run Rápida abrem no Livro I e lembram-se do livro escolhido OK")

## 0.13.1: menu com o visual novo — título em New Rocker dourado (shader) com a divisória, fundo com a
## ilustração e o círculo de runas atrás do título, placas com moldura dourada, cantoneiras e medalhões,
## reflexo no CONTINUAR; e o ícone novo da app (leque de cartas).
func _test_menu_0131() -> void:
	var old_lang := Settings.language
	Settings.language = "pt"
	Settings.apply()
	var menu = load("res://scenes/main/Main.tscn").instantiate()
	add_child(menu)
	await get_tree().process_frame
	await get_tree().process_frame
	var title: Label = menu.get_node("%Title")
	var font := title.get_theme_font("font")
	_check(font != null and font.resource_path.ends_with("NewRocker-Regular.ttf"), "o título do menu devia estar em New Rocker")
	_check(title.material is ShaderMaterial and String((title.material as ShaderMaterial).shader.resource_path).ends_with("title_gold.gdshader"), "o título do menu devia ser dourado (shader)")
	_check(menu.find_child("TitleDivider", true, false) is OrnamentDivider, "por baixo do título devia haver a divisória")
	var bd = menu.find_child("MenuBackdrop", true, false)
	_check(bd is MenuBackdrop and (bd as MenuBackdrop).art != null, "o fundo do menu devia ter a ilustração")
	if bd is MenuBackdrop:
		var c: Vector2 = (bd as MenuBackdrop).rune_center()
		var title_rect := Rect2(title.global_position - (bd as Control).global_position, title.size)
		_check(title_rect.has_point(c), "o círculo de runas devia ficar atrás do título")
	var saves: Button = menu.get_node("%Saves")
	var med = saves.find_child("Medallion", true, false)
	_check(med is TileMedallion and (med as TileMedallion).has_art(), "JOGOS GUARDADOS devia ter o medalhão com a ilustração do mapa")
	var deco = saves.find_child("PlaqueDeco", false, false)
	_check(deco is PlaqueDeco and (deco as PlaqueDeco).corners and saves.get_child(0) == deco, "os botões do menu deviam ser placas com cantoneiras (por baixo do texto)")
	var sb := saves.get_theme_stylebox("normal") as StyleBoxFlat
	_check(sb != null and sb.border_width_top >= 1 and sb.border_color.r > 0.9 and sb.border_color.b < 0.7, "as placas deviam ter a moldura dourada")
	var cont: Button = menu.get_node("%Continue")
	var cdeco = cont.find_child("PlaqueDeco", false, false)
	_check(cdeco is PlaqueDeco and (cdeco as PlaqueDeco).sheen, "o CONTINUAR devia ter o reflexo a passar")
	SceneRouter.close_overlays()
	menu.queue_free()
	await get_tree().process_frame
	# Ícone novo (leque de cartas): 192 px, cantos transparentes e a carta creme ao meio.
	var icon := load("res://assets/icons/icon_192.png") as Texture2D
	var img: Image = icon.get_image() if icon != null else null
	_check(img != null and img.get_width() == 192 and img.get_pixel(0, 0).a < 0.05 and img.get_pixel(75, 125).r > 0.8, "o ícone da app devia ser o novo (leque de cartas)")
	Settings.language = old_lang
	Settings.apply()
	print("  0.13.1: menu com título New Rocker dourado, runas, faíscas, placas e medalhões; ícone novo OK")

## 0.14.1: a carta em grande tem a ilustração (desenhada pela camada de trás, CardFace)?
func _zoom_has_art(z: Node) -> bool:
	var fb := z.find_child("FaceBack", true, false) if z != null else null
	return fb is CardFace and (fb as CardFace).texture != null

## 0.14.1: cartas com o visual "Arte em destaque" — ilustração a toda a largura em cima, nome por cima dela (Lora,
## com sombra), custo numa esfera em cima à direita, pips por baixo, tipo numa pílula a meio da linha onde a
## arte acaba (com o losango da raridade), texto centrado com as cores (Poder, Mult, [Na Mão]), Poder numa
## pílula azul e Vida numa vermelha; fundo e contorno na cor da carta (degradê nas de várias cores) e o fio da
## raridade por dentro; sem ilustração, o sigilo (ou a paisagem) na zona da arte; a carta em grande igual.
func _test_cards_0141() -> void:
	var old_lang := Settings.language
	Settings.language = "pt"
	Settings.apply()
	# Cores do texto (português e inglês; "Multiplica" não é "Mult"; o número não se separa da palavra).
	var bb := CardView.card_bbcode("[Na Mão] Dá +25 Poder e ×1.5 Mult; Multiplica tudo.")
	_check(bb.contains("[color=#%s][lb]Na Mão][/color]" % CardView.BB_HAND) and bb.contains("[color=#%s]+25%sPoder[/color]" % [CardView.BB_POWER, String.chr(0xA0)]) and bb.contains("[color=#%s]×1.5%sMult[/color]" % [CardView.BB_MULT, String.chr(0xA0)]) and bb.contains("; Multiplica"), "o texto das cartas devia ter [Na Mão] a dourado, Poder a azul e Mult a vermelho")
	var bb_en := CardView.card_bbcode("[In Hand] +30 Power and ×1.3 Mult.")
	_check(bb_en.contains("[color=#%s][lb]In Hand]" % CardView.BB_HAND) and bb_en.contains("Power[/color]") and bb_en.contains("Mult[/color]"), "as cores do texto deviam funcionar em inglês")
	var zoom_bb := CardView.colorize_bbcode(CardZoom.glossary_bbcode("+5 Mult por carta na mão."))
	_check(zoom_bb.begins_with("[color=#%s]+5" % CardView.BB_MULT) and zoom_bb.contains("[url="), "na carta em grande as cores deviam juntar-se ao glossário")
	_check(ResourceLoader.exists("res://scripts/ui/CardFace.gd") and not ResourceLoader.exists("res://scripts/ui/CardGlass.gd"), "o vidro da 0.14.0 devia ter dado lugar ao CardFace")
	# Cartas na mão: uma de duas cores (rara), uma vermelha (rara, criatura com tribo), uma mítica, um Terreno,
	# um nome comprido, uma comum e uma com palavra-chave (Voar).
	var row := HBoxContainer.new()
	add_child(row)
	var ids := ["c055", "c096", "c356", "c008", "c194", "c060", "c015"]
	var views := {}
	for id in ids:
		var v: CardView = load("res://scenes/ui/CardView.tscn").instantiate()
		row.add_child(v)
		v.setup(CardDB.new_instance(id))
		views[id] = v
	for i in 4:
		await get_tree().process_frame
	var sph: CardView = views["c055"]
	var dragon: CardView = views["c096"]
	var lich: CardView = views["c356"]
	var land: CardView = views["c008"]
	var longn: CardView = views["c194"]
	var scribe: CardView = views["c060"]
	var djinn: CardView = views["c015"]
	var df: CardFace = dragon._face_front
	var red: Dictionary = CardFace.palette("red")
	_check(dragon._style.bg_color == red["bottom"] and dragon._style.border_color == red["border"] and dragon._style.border_width_top == 2 and sph._style.bg_color == CardFace.MULTI_BG[1], "o fundo e o contorno deviam ter a cor da carta")
	_check(sph._face_front.gradient_border and not df.gradient_border, "as cartas de duas cores deviam ter o contorno em degradê")
	_check(dragon.has_art() and dragon._face_back.texture != null and df.art_rect.size.x >= dragon.size.x - 5.0 and df.art_rect.position.y <= 3.0 and df.art_rect.size.y > dragon.size.y * 0.45, "a ilustração devia ocupar a largura toda, em cima")
	_check(dragon.name_label.position.y < df.art_rect.position.y + df.art_rect.size.y * 0.3 and dragon.name_label.get_theme_font("font") == CardView.title_font(), "o nome devia estar por cima da ilustração, em Lora")
	_check(df.orb_rect.size.x >= 18.0 and df.orb_rect.position.x > dragon.size.x * 0.6 and df.orb_rect.position.y < 12.0 and dragon.cost_label.get_rect().get_center().distance_to(df.orb_rect.get_center()) < 1.5, "o custo devia estar numa esfera em cima à direita")
	_check(df.pill_rect.position.y < df.art_rect.end.y and df.pill_rect.end.y > df.art_rect.end.y and absf(df.pill_rect.get_center().x - dragon.size.x * 0.5) < 1.0, "a pílula do tipo devia ficar a meio da linha onde a arte acaba")
	_check(df.pill_color == CardFace.PILL["creature"] and df.gem_color == CardFace.RARITY_GEM["rare"] and df.gem_glow and scribe._face_front.gem_color.a == 0.0, "a pílula devia ter a cor do tipo e o losango da raridade (as comuns nenhum)")
	_check(df.ring_color == CardFace.RARITY_RING["rare"] and scribe._face_front.ring_color.a == 0.0 and lich._face_front.ring_color == CardFace.RARITY_RING["mythic"], "o fio da raridade devia aparecer nas incomuns, raras e míticas")
	_check(dragon.stats_label.text == "65" and dragon.tough_label.text == "6" and df.power_rect.size.x > 20.0 and df.tough_rect.size.x > 20.0 and df.tough_rect.position.x > df.power_rect.end.x, "o Poder devia estar numa pílula à esquerda e a Vida noutra à direita")
	_check(sph.stats_label.text == "40" and sph.tough_label.text == "" and sph._face_front.tough_rect.size.x == 0.0, "um feitiço com Poder só tem a pílula do Poder")
	_check(dragon.text_label.text.begins_with("[center]") and dragon.text_label.text.contains("[color=#%s]+8" % CardView.BB_MULT), "o texto devia estar centrado, com o Mult a vermelho")
	_check(dragon.text_label.position.y >= df.pill_rect.end.y and dragon.text_label.position.y + dragon.text_label.size.y <= df.power_rect.position.y + 1.0, "o texto devia ficar entre a pílula do tipo e as pílulas de baixo")
	_check(land.cost_label.text == "+1" and land.stats_label.text == "jogar: +1 mana" and land._face_front.land_rect.size.x > 30.0 and land._face_front.power_rect.size.x == 0.0, "o Terreno devia mostrar +1 e 'jogar: +1 mana' numa pílula")
	_check(sph._face_front.pip_rects.size() == 2 and sph._face_front.pip_rects[0].position.y > sph._face_front.orb_rect.end.y, "as cartas de duas cores deviam ter os pips por baixo da esfera")
	_check(lich._style.border_color.r > 0.9 and lich._style.shadow_color.r > 0.9, "as míticas deviam ter o contorno a mudar de cor e brilho laranja")
	var nf := dragon.name_label.get_theme_font("font")
	_check(dragon.name_label.autowrap_mode == TextServer.AUTOWRAP_OFF and nf.get_string_size(dragon.name_label.text, HORIZONTAL_ALIGNMENT_LEFT, -1, dragon.name_label.get_theme_font_size("font_size")).x <= dragon.name_label.size.x + 1.0, "um nome médio devia caber numa linha (a encolher)")
	_check(longn.name_label.autowrap_mode != TextServer.AUTOWRAP_OFF and longn.name_label.get_visible_line_count() == 2, "um nome muito comprido devia passar a duas linhas")
	_check(dragon.type_label.size.x > 20.0 and dragon.type_label.uppercase and dragon.type_label.position.x > df.pill_rect.position.x, "o tipo devia ver-se, em maiúsculas, dentro da pílula")
	var kw_ok := djinn._kw_box.get_child_count() > 0 and djinn._face_front.kw_rects.size() == djinn._kw_box.get_child_count()
	if kw_ok:
		var ic: Control = djinn._kw_box.get_child(0)
		kw_ok = ic.position.y > djinn.name_label.position.y and ic.position.y < djinn._face_front.pill_rect.position.y and ic.position.x < djinn.size.x * 0.3
	_check(kw_ok, "as palavras-chave deviam ficar em coluna à esquerda, por baixo do nome, com um disco por trás")
	# Sem ilustrações (Coleção, Construtor): a zona da arte fica na cor da carta, com o sigilo.
	CardView.art_on = false
	var plain: CardView = load("res://scenes/ui/CardView.tscn").instantiate()
	row.add_child(plain)
	plain.setup(CardDB.new_instance("c096"))
	await get_tree().process_frame
	await get_tree().process_frame
	_check(not plain.has_art() and plain._sigil != null and plain._sigil.visible and plain._sigil.get_parent() == plain.art_slot and plain.art_slot.size.y > 60.0, "sem ilustração devia ficar o sigilo na zona da arte")
	CardView.art_on = true
	row.queue_free()
	await get_tree().process_frame
	# Carta em grande: as mesmas peças (ilustração, esfera, pílula do tipo, pílulas de baixo) e texto com cores.
	CardZoom.show_data(CardDB.get_card("c096"))
	for i in 4:
		await get_tree().process_frame
	var z: Node = SceneRouter.top_overlay()
	var zb = z.find_child("FaceBack", true, false) if z != null else null
	var zf = z.find_child("FaceFront", true, false) if z != null else null
	var zrich: RichTextLabel = _find_node(z, func(n: Node): return n is RichTextLabel) if z != null else null
	_check(zb is CardFace and (zb as CardFace).texture != null and zf is CardFace and (zf as CardFace).orb_rect.size.x > 40.0, "a carta em grande devia ter a ilustração e a esfera do custo")
	if zf is CardFace:
		var zff := zf as CardFace
		_check(zff.pill_rect.position.y < zff.art_rect.end.y and zff.pill_rect.end.y > zff.art_rect.end.y and zff.power_rect.size.x > 40.0 and zff.tough_rect.size.x > 40.0, "a carta em grande devia ter a pílula do tipo e as do Poder e da Vida")
	_check(zrich != null and zrich.text.begins_with("[center]") and zrich.text.contains("[color=#%s]" % CardView.BB_MULT), "o texto da carta em grande devia estar centrado e com as cores")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	Settings.language = old_lang
	Settings.apply()
	print("  0.14.1: cartas com o visual Arte em destaque (mão, sem ilustração e em grande) OK")

## 0.14.0: correções da revisão do código — círculo de runas desenhado uma vez (só roda) e no centro do texto
## do título, também com "Reduzir movimento"; brilho do CONTINUAR só redesenha quando passa; a Campanha
## não guarda livros bloqueados; o fim de uma Run Rápida volta à Run Rápida; os espaços dos jogos guardados
## não cortam a sombra das placas; créditos com a New Rocker.
func _test_fixes_0140() -> void:
	var old_lang := Settings.language
	Settings.language = "pt"
	Settings.apply()
	for motion_off in [false, true]:
		Settings.reduce_motion = motion_off
		Settings.apply()
		var menu = load("res://scenes/main/Main.tscn").instantiate()
		add_child(menu)
		for i in 4:
			await get_tree().process_frame
		var bd := menu.find_child("MenuBackdrop", true, false) as MenuBackdrop
		var title: Label = menu.get_node("%Title")
		var outer = bd.find_child("RunesOuter", false, false) if bd != null else null
		var inner = bd.find_child("RunesInner", false, false) if bd != null else null
		_check(outer is Node2D and inner is Node2D, "o círculo de runas devia estar em duas camadas")
		if bd != null and outer is Node2D:
			var c := bd.rune_center()
			var f := title.get_theme_font("font")
			var tw := f.get_string_size(title.text, HORIZONTAL_ALIGNMENT_LEFT, -1, title.get_theme_font_size("font_size")).x
			var text_cx := title.global_position.x - bd.global_position.x + minf(tw, title.size.x) * 0.5
			_check(absf(c.x - text_cx) < 2.0, "o círculo devia ficar no centro do texto do título")
			_check((outer as Node2D).position.distance_to(c) < 1.0, "o círculo devia estar no sítio certo%s" % (" com Reduzir movimento" if motion_off else ""))
			# Desenha-se uma vez: nos frames seguintes só roda (com movimento) ou fica parado.
			var draws := [0]
			(outer as Node2D).draw.connect(func(): draws[0] += 1)
			var rot0 := (outer as Node2D).rotation
			for i in 6:
				await get_tree().process_frame
			_check(draws[0] == 0, "o círculo de runas não devia ser redesenhado a cada frame")
			_check(((outer as Node2D).rotation != rot0) != motion_off, "o círculo devia rodar (e parar com Reduzir movimento)")
		menu.queue_free()
		await get_tree().process_frame
	Settings.reduce_motion = false
	Settings.apply()
	# Brilho do botão principal: na pausa entre passagens não redesenha.
	var btn := Button.new()
	btn.size = Vector2(300, 80)
	add_child(btn)
	var deco := PlaqueDeco.attach(btn, 14.0, false, true)
	await get_tree().process_frame
	deco._t = deco.sheen_period * 0.8   # na pausa
	deco._was_on = false
	var sheen_draws := [0]
	deco.draw.connect(func(): sheen_draws[0] += 1)
	for i in 4:
		await get_tree().process_frame
	_check(sheen_draws[0] == 0 and not deco.sheen_on(), "o brilho não devia redesenhar na pausa entre passagens")
	btn.queue_free()
	# Campanha: um livro bloqueado não fica guardado.
	var cs: GDScript = load("res://scenes/campaign/Campaign.gd")
	var saved_best: Dictionary = (GameState.progress["best_ante"] as Dictionary).duplicate()
	var saved_free := GameState.free_mode
	GameState.free_mode = false
	GameState.launch_mode = ""
	GameState.progress["best_ante"] = {}
	_check(not GameState.is_act_unlocked(2), "o Livro III devia estar bloqueado sem progresso")
	cs.set("_last_act", {"campaign": 2, "free": 0, "quick": 0})
	var camp = load("res://scenes/campaign/Campaign.tscn").instantiate()
	add_child(camp)
	await get_tree().process_frame
	_check(int(camp.get("_act_index")) == 0, "a Campanha não devia abrir num livro bloqueado")
	(camp.get_node("%ActButtons").get_child(2) as Button).pressed.emit()
	_check(int((cs.get("_last_act") as Dictionary).get("campaign", -1)) == 0, "tocar num livro bloqueado não o devia guardar")
	camp.queue_free()
	await get_tree().process_frame
	GameState.progress["best_ante"] = saved_best
	GameState.free_mode = saved_free
	cs.set("_last_act", {"campaign": 0, "free": 0, "quick": 0})
	# Espaços dos jogos guardados: o botão não corta (a coluna dos textos é que corta).
	var sb := SlotPicker.slot_button(1)
	_check(not sb.clip_contents, "os espaços dos jogos guardados não deviam cortar a sombra das placas")
	sb.free()
	# Créditos: as três fontes.
	var sm := SettingsMenu.open()
	await get_tree().process_frame
	var credits := false
	for i in SettingsMenu.TABS.size():
		sm._show_tab(i)
		await get_tree().process_frame
		credits = credits or _has_text_in(sm, "New Rocker")
	_check(credits, "os créditos deviam falar da New Rocker")
	SceneRouter.close_overlays()
	await get_tree().process_frame
	Settings.language = old_lang
	Settings.apply()
	print("  0.14.0: runas desenhadas uma vez e centradas, brilho na pausa, Campanha, espaços e créditos OK")
