extends Node
## Teste de fumo headless:  godot --headless --path . res://tests/SmokeTest.tscn
## 1) Batalhas só com lógica (sem UI) com os 18 baralhos, com relíquias e inimigo com todas as habilidades.
## 2) Uma batalha a correr na cena real Battle.tscn (cascata animada com timers), com Canalizar.
## 3) Carregar as outras cenas (Main, Shop, RunOver) sem erros.
## Sai com código 0 se tudo passou, 1 se algo falhou.

var failures: Array[String] = []

func _ready() -> void:
	await get_tree().process_frame
	Settings.language = "pt"
	Settings.anim_speed = "normal"
	Settings.apply()
	_test_settings()
	_test_rules()
	_test_logic_battles()
	await _test_ui_battle()
	await _test_other_scenes()
	if failures.is_empty():
		print("SMOKE TEST: OK")
		get_tree().quit(0)
	else:
		for f in failures:
			printerr("SMOKE TEST FAIL: " + f)
		get_tree().quit(1)

func _check(cond: bool, msg: String) -> void:
	if not cond:
		failures.append(msg)

# ---------------------------------------------------------------------------

func _test_settings() -> void:
	# Tradução: chaves em PT → EN; sem tradução fica o texto PT.
	Settings.language = "en"
	Settings.apply()
	_check(TranslationServer.translate("NOVO JOGO") == "NEW GAME", "tradução EN não funciona (TranslationServer)")
	_check(tr("ATACAR") == "ATTACK", "tr() não traduz para EN")
	_check(tr("Senado Azorius") == "Azorius Senate", "nomes dos baralhos não traduzem")
	_check(Cascade.label_for("power_add", 3) == "+3 Power", "etiquetas da cascata não traduzem")
	_check(tr("Texto sem tradução") == "Texto sem tradução", "texto sem entrada devia ficar igual")
	Settings.language = "pt"
	Settings.apply()
	_check(tr("NOVO JOGO") == "NOVO JOGO", "em PT o texto devia ficar igual")
	_check(TranslationServer.get_locale().begins_with("pt"), "locale devia ser pt_PT, é %s" % TranslationServer.get_locale())
	# Velocidade das animações e gravação das configurações.
	Settings.anim_speed = "instant"
	_check(Settings.dur(1.0) == 0.0, "instantâneo devia dar duração 0")
	Settings.anim_speed = "fast"
	_check(Settings.dur(1.0) < 1.0 and Settings.dur(1.0) > 0.0, "rápida devia encurtar")
	Settings.sfx_volume = 0.35
	Settings.vibration = false
	Settings.save_settings()
	Settings.sfx_volume = 1.0
	Settings.vibration = true
	Settings.anim_speed = "normal"
	Settings.load_settings()
	_check(is_equal_approx(Settings.sfx_volume, 0.35) and not Settings.vibration and Settings.anim_speed == "fast", "configurações não gravaram/carregaram")
	Settings.sfx_volume = 1.0
	Settings.vibration = true
	Settings.anim_speed = "normal"
	Settings.save_settings()
	Settings.apply()
	_check(AudioServer.get_bus_index("Sfx") >= 0 and AudioServer.get_bus_index("Music") >= 0, "buses de áudio em falta")
	print("  configurações/traduções OK")

func _test_rules() -> void:
	# Vida persistente, limite de relíquias, juros, inimigos por ato, bosses e regras.
	GameState.new_run("deck01", 11)
	_check(GameState.player_hp == 20 and GameState.player_max_hp == 20, "vida inicial devia ser 20/20")
	GameState.damage_player(7)
	var bm := BattleManager.new()
	bm.start(GameState.pick_enemy(1))
	_check(GameState.player_hp == 13, "a vida devia persistir entre batalhas (13), está %d" % GameState.player_hp)
	_check(bm.enemy.get("boss", false) == false and String(bm.enemy.get("id", "")) != "", "ante 1 devia ter um inimigo normal")
	GameState.heal(50)
	_check(GameState.player_hp == 20, "curar não devia passar da vida máxima")
	GameState.change_max_hp(5)
	_check(GameState.player_max_hp == 25, "vida máxima devia subir para 25")
	for i in 7:
		GameState.add_relic(String(CardDB.relics.keys()[i]))
	_check(GameState.relic_ids.size() == GameState.MAX_RELICS, "limite de relíquias devia ser %d" % GameState.MAX_RELICS)
	_check(not GameState.add_relic("relic_whetstone"), "add_relic devia recusar acima do limite")
	GameState.remove_relic(GameState.relic_ids[0])
	_check(GameState.relic_ids.size() == 4 and GameState.add_relic("relic_whetstone"), "vender devia abrir espaço")
	GameState.move_relic("relic_whetstone", 0)
	_check(GameState.relic_ids[0] == "relic_whetstone", "move_relic devia pôr a relíquia na frente")
	GameState.gold = 23
	GameState.interest_ante = 0
	_check(GameState.interest_due() == 4, "juros de 23 ouro deviam ser 4, são %d" % GameState.interest_due())
	GameState.pay_interest()
	_check(GameState.gold == 27 and GameState.interest_due() == 0, "juros deviam pagar uma vez por ante")
	# Bosses: ante 4 tem regra; ante 8 é o final.
	GameState.ante = 4
	var boss := GameState.pick_enemy(4)
	_check(bool(boss.get("boss", false)) and not (boss.get("rule", {}) as Dictionary).is_empty(), "ante 4 devia ter um boss com regra")
	GameState.ante = 8
	var final_boss := GameState.pick_enemy(8)
	_check(String(final_boss.get("id", "")) == "boss_zero", "ante 8 devia ser o boss final")
	# Regras de boss, uma a uma, sobre o mesmo baralho.
	GameState.new_run("deck05", 3)
	var tests := {
		"discards_minus": {"discards_minus": 1}, "hand_size": {"hand_size": 5},
		"creature_cost_plus": {"creature_cost_plus": 1}, "no_formations": {"no_formations": true},
		"relics_off": {"relics_off": true}, "color_silenced": {"color_silenced": "white"},
	}
	for key in tests:
		GameState.new_run("deck05", 3)
		GameState.relic_ids.append("relic_drum")
		GameState.ante = 4
		var b := BattleManager.new()
		b.start({"name": "Boss", "hp": 999999, "max_hp": 999999, "attack": 1, "text": "", "abilities": [], "boss": true, "rule": tests[key]})
		match key:
			"discards_minus":
				_check(b.discards_left == GameState.discards_for_battle() - 1, "Mordaça devia tirar 1 canalização")
			"hand_size":
				_check(b.deck.hand.size() == 5, "Peso devia dar mão de 5, deu %d" % b.deck.hand.size())
			"creature_cost_plus":
				var creature: CardInstance = null
				for c in b.deck.hand:
					if c.data.is_creature():
						creature = c
				if creature != null:
					_check(b.effects.cost_of(creature) == creature.data.cost + 1, "Tarifa devia custar +1")
			"no_formations", "relics_off", "color_silenced":
				_play_everything(b)
				var prev := b.preview_attack()
				if key == "no_formations":
					_check(prev.formations.is_empty(), "Caos devia anular as formações")
				elif key == "relics_off":
					var relic_steps := prev.steps.filter(func(st): return st.source_kind == "relic")
					_check(relic_steps.is_empty(), "relics_off devia calar as relíquias")
				else:
					var effect_steps := prev.steps.filter(func(st): return st.source_kind == "creature" and st.action != "power_add")
					_check(effect_steps.is_empty(), "cartas brancas silenciadas não deviam ter efeitos na cascata")
	# Pré-visualização por carta, contra-ataque e desfazer.
	GameState.new_run("deck05", 3)
	GameState.ante = 1
	var b2 := BattleManager.new()
	b2.start({"name": "Teste", "hp": 100000, "max_hp": 100000, "attack": 3, "text": "", "abilities": []})
	var playable: CardInstance = null
	for c in b2.deck.hand:
		if b2.can_play(c) and not c.data.is_land():
			playable = c
			break
	if playable != null:
		var hand_before := b2.deck.hand.duplicate()
		var delta := b2.preview_play(playable)
		_check(b2.deck.hand == hand_before and not (playable in b2.board), "preview_play não devia alterar o estado")
		var snap := b2.snapshot()
		b2.play(playable)
		var after := b2.preview_attack().total()
		_check(after == delta, "o delta previsto (%d) devia bater com o total depois de jogar (%d)" % [delta, after])
		var counter := b2.preview_enemy_phase()
		_check(int(counter["damage"]) == 3, "preview_enemy_phase devia ler o ataque do inimigo")
		_check(b2.restore_snapshot(snap), "restore_snapshot falhou")
		_check(b2.deck.hand.size() == hand_before.size() and b2.board.is_empty(), "desfazer devia repor a mão e o tabuleiro")
	# Eventos.
	GameState.new_run("deck01", 4)
	var ev := GameState.pick_event()
	_check(ev != "" and not CardDB.get_event(ev).is_empty(), "pick_event devia devolver um evento do ato I")
	_check(not GameState.seen_events.is_empty(), "o evento devia ficar registado como visto")
	print("  regras: vida persistente, relíquias, juros, bosses, previsões, desfazer, eventos OK")

func _test_logic_battles() -> void:
	_check(CardDB.cards.size() == 300, "esperava 300 cartas, há %d" % CardDB.cards.size())
	_check(CardDB.decks.size() == 18, "esperava 18 baralhos")
	var total_wins := 0
	for deck in CardDB.decks:
		GameState.new_run(String(deck.id), 12345)
		_check(GameState.deck.size() == int(deck.size), "baralho %s tem %d cartas" % [deck.name, GameState.deck.size()])
		# Todas as relíquias (acima do limite de 5 — é um teste de regras, não de loja).
		for relic_id in CardDB.relics.keys():
			GameState.relic_ids.append(String(relic_id))
		GameState.player_hp = 60   # vida persistente: dá folga para 4 batalhas seguidas sem loja
		GameState.player_max_hp = 60
		var wins := 0
		var max_total := 0
		for ante in range(1, 5):
			GameState.ante = ante
			var bm := BattleManager.new()
			var hp := GameState.enemy_hp_for_ante(ante)
			bm.start({"name": "Teste", "hp": hp, "max_hp": hp, "attack": 2, "text": "", "abilities": [
				{"trigger": "turn_end", "action": "steal_gold", "value": 1},
				{"trigger": "every_n_turns", "n": 3, "action": "destroy_strongest"},
				{"trigger": "turn_end", "action": "damage_all_creatures", "value": 1},
				{"trigger": "turn_end", "action": "discard_random", "value": 1},
				{"trigger": "turn_end", "action": "heal_self", "value": 1},
			]})
			var result := [null]
			var cb := func(v: bool): result[0] = v
			EventBus.battle_ended.connect(cb)
			var guard := 0
			while result[0] == null and guard < 50:
				guard += 1
				_play_everything(bm)
				var preview := bm.preview_attack()
				_check(preview.total() == int(round(preview.power * preview.mult * preview.damage_mult)), "total da cascata inconsistente")
				max_total = max(max_total, preview.total())
				# Canalizar uma carta por turno, para exercitar on_discard
				if not bm.deck.hand.is_empty() and bm.can_discard(bm.deck.hand[0]):
					bm.discard(bm.deck.hand[0])
				bm.end_turn()
			EventBus.battle_ended.disconnect(cb)
			_check(result[0] != null, "batalha %s ante %d não terminou" % [deck.name, ante])
			_check(bm.turn <= bm.max_turns + bm.extra_turns, "turnos a mais em %s" % deck.name)
			if result[0] == true:
				wins += 1
		print("  %-22s %d/4 vitórias, melhor ataque %d" % [deck.name, wins, max_total])
		_check(max_total > 0, "baralho %s nunca atacou" % deck.name)
		total_wins += wins
	_check(total_wins >= 18, "demasiado poucas vitórias com relíquias fortes: %d" % total_wins)

func _play_everything(bm: BattleManager) -> void:
	var played := true
	var guard := 0
	while played and guard < 40:
		guard += 1
		played = false
		for card in bm.deck.hand.duplicate():
			if bm.can_play(card):
				_check(bm.play(card), "play() falhou numa carta jogável")
				played = true
				break
	_check(bm.creatures().size() <= BattleManager.MAX_CREATURES, "mais criaturas do que o limite")

# ---------------------------------------------------------------------------

func _test_ui_battle() -> void:
	GameState.new_run("deck01", 777)
	GameState.add_relic("relic_ruby")
	GameState.add_relic("relic_banner")
	GameState.ante = 1
	GameState.clear_saved_run()
	var scene: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	add_child(scene)
	await get_tree().process_frame
	# A cena mudaria para a loja no fim; aqui queremos ficar no teste.
	EventBus.battle_ended.disconnect(scene._on_battle_ended)
	var bm: BattleManager = scene.get_node("BattleManager")
	_check(GameState.has_saved_run(), "o início do turno 1 devia ter gravado a run")
	var ended := [null]
	var cb := func(v: bool): ended[0] = v
	EventBus.battle_ended.connect(cb)
	# Turno 1: Canalizar pela UI, jogar tudo, atacar.
	var hand_box: HBoxContainer = scene.get_node("%Hand")
	var dbtn: Button = scene.get_node("%DiscardBtn")
	dbtn.button_pressed = true
	await get_tree().process_frame
	for view in hand_box.get_children():
		if view is CardView and bm.can_discard(view.card):
			var before := bm.deck.graveyard.size()
			view.pressed.emit(view.card)
			await get_tree().process_frame
			_check(bm.deck.graveyard.size() == before + 1, "Canalizar pela UI não descartou")
			_check(not dbtn.button_pressed, "o modo Canalizar devia desligar-se depois de uma carta")
			break
	await _play_ui_turn(scene, bm, ended)
	_check(ended[0] != null or bm.turn == 2, "o turno 1 devia ter acabado (turno=%d)" % bm.turn)
	if ended[0] == null:
		# --- Overlays: pausa, carta em grande, grimório, configurações.
		(scene.get_node("%PauseBtn") as Button).pressed.emit()
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() is PauseMenu, "a pausa não abriu")
		if SceneRouter.top_overlay() is PauseMenu:
			(SceneRouter.top_overlay() as PauseMenu).close()
		await get_tree().process_frame
		await get_tree().process_frame
		_check(not SceneRouter.has_overlay(), "a pausa não fechou")
		for view in hand_box.get_children():
			if view is CardView:
				view.long_pressed.emit(view.card)
				break
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() is CardZoom, "o toque longo não abriu a carta em grande")
		SceneRouter.close_overlays()
		await get_tree().process_frame
		(scene.get_node("%LibraryBtn") as Button).pressed.emit()
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() is ZoneViewer, "o grimório não abriu")
		SceneRouter.close_overlays()
		await get_tree().process_frame
		var sm := SettingsMenu.open()
		await get_tree().process_frame
		_check(SceneRouter.top_overlay() == sm, "as configurações não abriram")
		sm.close()
		await get_tree().process_frame
		await get_tree().process_frame
		# Desfazer pela UI: joga uma carta e anula.
		var hand_n := bm.deck.hand.size()
		for view in hand_box.get_children():
			if view is CardView and bm.can_play(view.card):
				view.pressed.emit(view.card)
				await get_tree().process_frame
				break
		var undo: Button = scene.get_node("%UndoBtn")
		if bm.deck.hand.size() == hand_n - 1:
			_check(not undo.disabled, "DESFAZER devia estar ativo depois de jogar")
			undo.pressed.emit()
			await get_tree().process_frame
			_check(bm.deck.hand.size() == hand_n, "DESFAZER não repôs a carta na mão")
		# Arrastar no tabuleiro: inverte a ordem das criaturas.
		if bm.board.size() >= 2:
			var first: CardInstance = bm.board[0]
			scene.call("_on_board_drag_started", first, Vector2(100, 100))
			scene.call("_on_board_drag_moved", first, Vector2(5000, 100))
			scene.call("_on_board_drag_ended", first, Vector2(5000, 100))
			_check(bm.board[bm.board.size() - 1] == first, "arrastar devia mover a criatura para o fim")
			var board_box: HBoxContainer = scene.get_node("%Board")
			_check(board_box.get_child(board_box.get_child_count() - 1) == scene._board_views[first.uid], "a vista devia acompanhar a nova ordem")
		# --- Gravação a meio: o início do turno 2 gravou a batalha; retoma-a numa cena nova.
		var saved := {"turn": bm.turn, "hand": bm.deck.hand.size(), "library": bm.deck.library.size(), "graveyard": bm.deck.graveyard.size(), "board": bm.board.size(), "hp": bm.enemy.hp, "mana": bm.mana_total, "discards": bm.discards_left}
		EventBus.battle_ended.disconnect(cb)
		scene.queue_free()
		await get_tree().process_frame
		GameState.new_run("deck05", 1)   # estado diferente: a retoma tem de vir do disco
		_check(GameState.load_run(), "load_run falhou com batalha a meio")
		_check(not GameState.pending_battle.is_empty(), "a gravação devia trazer a batalha")
		_check(String(GameState.deck_def.get("id", "")) == "deck01", "baralho errado na retoma")
		scene = load("res://scenes/battle/Battle.tscn").instantiate()
		add_child(scene)
		await get_tree().process_frame
		EventBus.battle_ended.disconnect(scene._on_battle_ended)
		bm = scene.get_node("BattleManager")
		EventBus.battle_ended.connect(cb)
		var same: bool = bm.turn == saved.turn and bm.deck.hand.size() == saved.hand and bm.deck.library.size() == saved.library \
			and bm.deck.graveyard.size() == saved.graveyard and bm.board.size() == saved.board and bm.enemy.hp == saved.hp \
			and bm.mana_total == saved.mana and bm.discards_left == saved.discards
		_check(same, "batalha retomada não bate certo: %s vs turno %d mão %d grimório %d cemitério %d tabuleiro %d" % [str(saved), bm.turn, bm.deck.hand.size(), bm.deck.library.size(), bm.deck.graveyard.size(), bm.board.size()])
		_check(GameState.pending_battle.is_empty(), "pending_battle devia ser consumida pela cena")
		for card in bm.board:
			_check(card.entry_index >= 0 and card.deck_entry == GameState.deck[card.entry_index], "criatura retomada perdeu a ligação ao baralho")
		print("  UI: batalha retomada no turno %d a partir do ficheiro" % bm.turn)
	# Continua até ao fim.
	var guard := 0
	while ended[0] == null and guard < 10:
		guard += 1
		await _play_ui_turn(scene, bm, ended)
	EventBus.battle_ended.disconnect(cb)
	_check(ended[0] != null, "batalha com UI não terminou")
	print("  UI: batalha terminou (vitória=%s) no turno %d" % [str(ended[0]), bm.turn])
	scene.queue_free()
	await get_tree().process_frame

## Joga tudo o que puder pela UI, carrega em ATACAR e espera que o turno avance (ou a batalha acabe).
func _play_ui_turn(scene: Node, bm: BattleManager, ended: Array) -> void:
	var progressed := true
	while progressed:
		progressed = false
		var hand_box: HBoxContainer = scene.get_node("%Hand")
		for view in hand_box.get_children():
			if view is CardView and bm.can_play(view.card):
				view.pressed.emit(view.card)
				await get_tree().process_frame
				progressed = true
				break
	var btn: Button = scene.get_node("%EndTurn")
	_check(not btn.disabled, "botão de atacar devia estar ativo no turno %d" % bm.turn)
	btn.pressed.emit()
	var t0 := Time.get_ticks_msec()
	var turn_before := bm.turn
	while ended[0] == null and bm.turn == turn_before and Time.get_ticks_msec() - t0 < 20000:
		await get_tree().process_frame
	_check(ended[0] != null or bm.turn > turn_before, "a cascata/turno não avançou (timeout)")

func _first_card_view(viewer: Node) -> CardView:
	var stack: Array = [viewer]
	while not stack.is_empty():
		var n: Node = stack.pop_back()
		if n is CardView:
			return n
		for c in n.get_children():
			stack.append(c)
	return null

func _test_other_scenes() -> void:
	# Progresso limpo e determinístico.
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	GameState.clear_saved_run()
	GameState.free_mode = false
	_check(GameState.is_deck_unlocked("deck01"), "deck01 devia estar aberto")
	_check(not GameState.is_deck_unlocked("deck02"), "deck02 devia estar bloqueado no início")
	_check(not GameState.is_act_unlocked(1), "ato II devia estar bloqueado no início")
	# Gravação e retoma da run.
	GameState.new_run("deck04", 42)
	GameState.add_gold(20)
	GameState.add_relic("relic_drum")
	GameState.ante = 3
	GameState.deck[0]["power_bonus"] = 15
	GameState.save_run()
	_check(GameState.has_saved_run(), "run não ficou gravada")
	GameState.new_run("deck01", 1)
	_check(GameState.load_run(), "não conseguiu carregar a run")
	_check(GameState.deck_def.get("id") == "deck04" and GameState.ante == 3 and "relic_drum" in GameState.relic_ids and int(GameState.deck[0]["power_bonus"]) == 15, "run carregada não bate certo")
	# Abandonar a run: conta como derrota no ante atual e apaga a gravação.
	GameState.new_run("deck03", 9)
	GameState.ante = 3
	GameState.save_run({}, "shop")
	GameState.abandon_run()
	_check(not GameState.has_saved_run(), "abandonar devia apagar a gravação")
	_check(GameState.best_ante("deck03") == 3, "abandonar no ante 3 devia registar melhor ante 3")
	# Retoma na loja: a gravação lembra-se de onde estava.
	GameState.new_run("deck02", 3)
	GameState.ante = 2
	GameState.save_run({}, "shop")
	_check(GameState.load_run() and GameState.saved_scene == "shop" and GameState.pending_battle.is_empty(), "gravação na loja não retoma na loja")
	# Desbloqueios.
	GameState.new_run("deck01", 5)
	GameState.ante = 4
	var unl := GameState.record_run_end(4, false)
	_check(GameState.is_deck_unlocked("deck02"), "deck02 devia desbloquear ao chegar ao ante 4 com deck01")
	_check(unl.size() == 1, "esperava 1 desbloqueio, veio %d" % unl.size())
	GameState.record_run_end(6, false)
	_check(GameState.is_act_unlocked(1), "ato II devia abrir ao chegar ao ante 6")
	_check(GameState.is_deck_unlocked("deck06") and not GameState.is_deck_unlocked("deck07"), "no ato II só o 1.º capítulo devia estar aberto")
	# Cenas (progresso: só o deck01 chegou ao ante 4 → ato I com 2 capítulos abertos).
	GameState.progress = {"best_ante": {"deck01": 4}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	GameState.new_run("deck04", 42)
	GameState.add_gold(20)   # 24 ouro → 4 de juros na loja
	GameState.add_relic("relic_drum")
	GameState.damage_player(8)
	# Evento: escolhe a opção do ouro e confirma o resultado.
	GameState.ante = 2
	GameState.pending_event = "fountain"
	var ev_scene: Node = load("res://scenes/event/Event.tscn").instantiate()
	add_child(ev_scene)
	await get_tree().process_frame
	_check(GameState.saved_scene == "battle" or GameState.has_saved_run(), "evento devia gravar ao entrar")
	var gold_ev := GameState.gold
	var opts: VBoxContainer = ev_scene._options_box
	_check(opts.get_child_count() == 3, "a Fonte devia ter 3 opções")
	(opts.get_child(1) as Button).pressed.emit()
	await get_tree().process_frame
	await get_tree().process_frame
	_check(GameState.gold == gold_ev + 6, "a opção do cantil devia dar +6 ouro")
	_check(ev_scene._continue.visible and GameState.pending_event == "", "depois da escolha devia aparecer CONTINUAR")
	ev_scene.queue_free()
	await get_tree().process_frame
	var gold_in := GameState.gold
	for path in ["res://scenes/main/Main.tscn", "res://scenes/campaign/Campaign.tscn", "res://scenes/ui/HowToPlay.tscn", "res://scenes/shop/Shop.tscn", "res://scenes/ui/RunOver.tscn"]:
		var s: Node = load(path).instantiate()
		add_child(s)
		await get_tree().process_frame
		if path.ends_with("Main.tscn"):
			_check(s.get_node("%NewGame") != null and s.get_node("%Difficulty") != null and s.get_node("%Settings") != null, "menu sem botões")
			_check((s.get_node("%Difficulty") as Button).text.contains("NORMAL"), "dificuldade devia ser Normal")
		if path.ends_with("Campaign.tscn"):
			var list: VBoxContainer = s.get_node("%ChapterList")
			_check(list.get_child_count() == 5, "ato I devia listar 5 capítulos, listou %d" % list.get_child_count())
			var enabled := 0
			for b in list.get_children():
				if not (b as Button).disabled:
					enabled += 1
			_check(enabled == 2, "no ato I deviam estar abertos 2 capítulos (01 e 02), estão %d" % enabled)
			_check(not (s.get_node("%Story") as Label).text.is_empty(), "história vazia")
		if path.ends_with("Shop.tscn"):
			var offers: VBoxContainer = s.get_node("%CardOffers")
			_check(offers.get_child_count() == 3, "loja devia oferecer 3 cartas")
			_check((s.get_node("%RelicOffers") as VBoxContainer).get_child_count() == 2, "loja devia oferecer 2 relíquias")
			_check(GameState.has_saved_run(), "a loja devia gravar a run ao entrar")
			_check(GameState.gold == gold_in + mini(5, int(gold_in / 5)), "juros: %d ouro deviam render %d (ouro=%d)" % [gold_in, mini(5, int(gold_in / 5)), GameState.gold])
			(s.get_node("%DeckButton") as Button).pressed.emit()
			await get_tree().process_frame
			_check(SceneRouter.top_overlay() is ZoneViewer, "ver baralho na loja não abriu")
			SceneRouter.close_overlays()
			await get_tree().process_frame
			# Curar e vida máxima.
			var hp_before := GameState.player_hp
			(s.get_node("%HealBtn") as Button).pressed.emit()
			_check(GameState.player_hp == min(GameState.player_max_hp, hp_before + 5), "curar na loja não curou")
			var max_before := GameState.player_max_hp
			(s.get_node("%MaxHpBtn") as Button).pressed.emit()
			_check(GameState.player_max_hp == max_before + 5, "vida máxima na loja não subiu")
			# Remover (escolhe a 1.ª carta do painel).
			var before := GameState.deck.size()
			s.call("_on_remove")
			await get_tree().process_frame
			var viewer := SceneRouter.top_overlay()
			_check(viewer is ZoneViewer, "remover devia abrir o baralho")
			if viewer is ZoneViewer:
				var first_view: CardView = _first_card_view(viewer)
				viewer.call("_on_card_pressed", first_view.card)
				await get_tree().process_frame
			_check(GameState.deck.size() == before - 1, "remoção na loja não removeu uma carta")
			# Melhorar (1.ª carta): bónus permanente.
			s.call("_on_upgrade")
			await get_tree().process_frame
			viewer = SceneRouter.top_overlay()
			if viewer is ZoneViewer:
				var fv: CardView = _first_card_view(viewer)
				var entry: Dictionary = GameState.deck[fv.card.entry_index]
				var pb := int(entry.get("power_bonus", 0))
				var mb := float(entry.get("mult_bonus", 0.0))
				viewer.call("_on_card_pressed", fv.card)
				await get_tree().process_frame
				_check(int(entry.get("power_bonus", 0)) > pb or float(entry.get("mult_bonus", 0.0)) > mb, "melhorar não deu bónus permanente")
			# Booster: escolhe 1 de 3.
			before = GameState.deck.size()
			s.call("_on_booster")
			await get_tree().process_frame
			viewer = SceneRouter.top_overlay()
			_check(viewer is ZoneViewer, "booster devia abrir 3 cartas")
			if viewer is ZoneViewer:
				var fv2: CardView = _first_card_view(viewer)
				viewer.call("_on_card_pressed", fv2.card)
				await get_tree().process_frame
			_check(GameState.deck.size() == before + 1, "booster não juntou uma carta")
			# Vender a relíquia que temos.
			var gold_before := GameState.gold
			var owned: VBoxContainer = s.get_node("%OwnedRelics")
			_check(owned.get_child_count() == GameState.relic_ids.size(), "lista das tuas relíquias errada")
			if owned.get_child_count() > 0:
				((owned.get_child(0) as HBoxContainer).get_child(1) as Button).pressed.emit()
				await get_tree().process_frame
				_check(GameState.relic_ids.is_empty() and GameState.gold > gold_before, "vender relíquia não funcionou")
			# Novas ofertas.
			var reroll: Button = s.get_node("%RerollBtn")
			if not reroll.disabled:
				reroll.pressed.emit()
				await get_tree().process_frame
				_check((s.get_node("%CardOffers") as VBoxContainer).get_child_count() == 3, "novas ofertas deviam voltar a dar 3 cartas")
			SceneRouter.close_overlays()
		if path.ends_with("RunOver.tscn"):
			_check((s.get_node("%Title") as Label).text == "DERROTA", "RunOver devia dizer DERROTA")
		s.queue_free()
		await get_tree().process_frame
	# Limpa o que o teste escreveu.
	GameState.progress = {"best_ante": {}, "wins": {}, "difficulty": "normal"}
	GameState.save_progress()
	GameState.clear_saved_run()
	Settings.language = "auto"
	Settings.save_settings()
	print("  menu/campanha/como jogar/loja/fim carregam; gravação, abandono e desbloqueios OK")
