class_name Shots0200
extends RefCounted
## Capturas da 0.20.0 «Sem armadilhas» (Screenshots.tscn -- --only=0200 --out=<pasta>). O mesmo script corre no código
## da 0.19.1 (o «antes») e no da 0.20.0 (o «depois»), por isso só usa o que já existia na 0.19.1. `s` é o nó do
## Screenshots (_wait, _shoot, _clear_toasts, _battle_state, _tap_play). Não mexer o rato por cima da janela.

const TAP_OUTSIDE := Vector2(40, 40)   # fora de qualquer janela centrada

static func run(s: Node) -> void:
	Settings.tips_enabled = false
	Settings.set_opt("dim_idle", false, false)    # o ecrã escurecido (2 min sem toques) taparia as capturas
	Settings.set_opt("auto_perf", false, false)   # e a oferta do modo de desempenho também
	Settings.set_opt("edge_guard", false, false)  # no Windows a área segura tira a barra de tarefas: faixa cinzenta em baixo
	Storage.crashed_before = false                # sem o aviso de fecho inesperado no menu
	GameState.free_mode = false
	GameState.puzzle_id = ""
	await _menu(s)
	await _shop_long_press(s)
	await _retry(s)
	await _builder(s)
	await _draft(s)
	await _kicker(s)
	await _last_turn(s)
	await _you_die(s)
	await _relic_step(s)
	await _defeat(s)
	await _defeat_long(s)
	await _rewards(s)
	await _tutorial(s)
	await _big_text(s)
	Settings.language = "pt"
	Settings.reset_options(["dim_idle", "auto_perf", "edge_guard", "menu_text", "large_text", "left_handed"], false)
	Settings.apply()
	GameState.clear_saved_run()

# --- Ajudas ---

## A cena passa a ser a cena atual (como o SceneRouter.go a deixa): o que lê get_tree().current_scene (texto dos
## menus, avisos durante a batalha) porta-se como no jogo.
static func _mount(s: Node, path: String) -> Node:
	var n: Node = load(path).instantiate()
	s.get_tree().root.add_child(n)
	s.get_tree().current_scene = n
	return n

static func _unmount(s: Node, n: Node) -> void:
	SceneRouter.close_overlays()
	s.get_tree().current_scene = s
	if is_instance_valid(n):
		n.queue_free()
	await s.get_tree().process_frame

## D13: textos cortados ou fora do ecrã numa cena, um por entrada («texto [porquê]»): rótulos com várias linhas que
## não mostram todas, rótulos e botões de uma linha mais largos do que a caixa, e textos fora do ecrã (1280×720) ou da
## zona à vista de quem os recorta (listas que se arrastam, filas de altura fixa). Só usa o motor (corre na 0.19.1).
static func cuts(root: Node, screen: Rect2 = Rect2(0, 0, 1280, 720)) -> Array[String]:
	var out: Array[String] = []
	_cuts(root, screen, out)
	out.sort()
	return out

static func _cuts(n: Node, area: Rect2, out: Array[String]) -> void:
	if n is CanvasItem and (not (n as CanvasItem).visible or (n as CanvasItem).modulate.a < 0.01):
		return
	if n is Control:
		var c := n as Control
		var r := c.get_global_rect()
		var txt := ""
		var why := ""
		if c is Label:
			var l := c as Label
			txt = l.text
			if l.autowrap_mode != TextServer.AUTOWRAP_OFF:
				if l.get_line_count() > l.get_visible_line_count():
					why = "linhas"
			elif l.clip_text or l.text_overrun_behavior != TextServer.OVERRUN_NO_TRIMMING:
				if l.get_theme_font("font").get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, l.get_theme_font_size("font_size")).x > l.size.x + 2.0:
					why = "largura"
		elif c is Button:
			var b := c as Button
			txt = b.text
			if b.clip_text or b.text_overrun_behavior != TextServer.OVERRUN_NO_TRIMMING:
				var st := b.get_theme_stylebox("normal")
				var pad := st.get_margin(SIDE_LEFT) + st.get_margin(SIDE_RIGHT) if st != null else 0.0
				if b.get_theme_font("font").get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, b.get_theme_font_size("font_size")).x + pad > b.size.x + 2.0:
					why = "largura"
		if txt.strip_edges() != "" and c.size.x >= 8.0:
			if why == "" and not area.grow(2.0).encloses(r):
				why = "fora"
			if why != "":
				out.append("%s [%s]" % [txt.replace("
", " ").substr(0, 48), why])
		if c.clip_contents or c is ScrollContainer or c is BaseButton or c is PanelContainer:   # caixas desenhadas: o texto fica lá dentro
			area = area.intersection(r)
	for ch in n.get_children():
		_cuts(ch, area, out)

## Batalha retomada com este estado; com `keep_end`, o fim da batalha segue o caminho do jogo.
static func _battle(s: Node, st: Dictionary, keep_end: bool = false) -> Node:
	GameState.pending_battle = st
	var b: Node = _mount(s, "res://scenes/battle/Battle.tscn")
	if not keep_end:
		EventBus.battle_ended.disconnect(b._on_battle_ended)
	await s._wait(1.8)
	return b

static func _mouse(s: Node, p: Vector2, down: bool) -> void:
	var ev := InputEventMouseButton.new()
	ev.position = p
	ev.global_position = p
	ev.button_index = MOUSE_BUTTON_LEFT
	ev.pressed = down
	ev.button_mask = MOUSE_BUTTON_MASK_LEFT if down else 0
	s.get_viewport().push_input(ev, true)   # coordenadas do ecrã do jogo

static func _tap(s: Node, p: Vector2) -> void:
	_mouse(s, p, true)
	await s.get_tree().process_frame
	_mouse(s, p, false)
	await s.get_tree().process_frame

static func _back(s: Node) -> void:
	s.get_tree().root.propagate_notification(Node.NOTIFICATION_WM_GO_BACK_REQUEST)

## Espera pela condição, no máximo `secs`; false se o tempo acabou sem ela (a captura a seguir sairia no estado errado).
static func _until(s: Node, cond: Callable, secs: float = 15.0) -> bool:
	var t0 := Time.get_ticks_msec()
	while not bool(cond.call()) and Time.get_ticks_msec() - t0 < int(secs * 1000.0):
		await s.get_tree().process_frame
	return bool(cond.call())

## ATACAR como o dedo; se a 0.20.0 pedir o 2.º toque (o ataque perde a run), dá-o.
static func _attack(s: Node, b: Node) -> void:
	var bm: BattleManager = b.battle
	b.call("_on_end_turn_pressed")
	await s._wait(0.3)
	if not (bm.resolving or bm.finished or bool(b._animating)):
		b.call("_on_end_turn_pressed")

## Avisos de progresso pelo caminho do jogo: uma conquista (por omissão a 1.ª da lista) e um desbloqueio (este chega
## 1,6 s depois).
static func _progress_notices(ach: String = "") -> void:
	EventBus.achievement_unlocked.emit(ach if ach != "" else String(CardDB.achievements[0].get("id", "")))
	EventBus.content_unlocked.emit("relic", "relic_banner")

static func _relic_popping(b: Node) -> bool:
	var views: Dictionary = b.get("_relic_views")
	for v in views.values():
		if is_instance_valid(v) and (v as Control).scale.x > 1.05:
			return true
	return false

static func _text_mode(lang: String, big: bool, left: bool) -> void:
	Settings.language = lang
	Settings.large_text = big
	Settings.set_opt("menu_text", 1.3 if big else 1.0, false)
	Settings.left_handed = left
	Settings.apply()

# --- Capturas (F21) ---

## C11: o menu com uma conquista e um desbloqueio.
static func _menu(s: Node) -> void:
	var m: Node = _mount(s, "res://scenes/main/Main.tscn")
	await s._wait(1.4)
	if SceneRouter.overlay_layer.find_child("FirstRun", true, false) != null:
		printerr("CAPTURAS 0200: a janela «Antes de começar» apareceu (falta progress.first_questions)")
	s._clear_toasts()
	_progress_notices()
	await s._wait(2.4)
	await s._shoot("200_01_menu_aviso_progresso")
	await _unmount(s, m)

## A1: segurar uma relíquia da loja (o balão) e largar o mesmo dedo.
static func _shop_long_press(s: Node) -> void:
	GameState.new_run("deck01", 20002)
	GameState.relic_ids.clear()
	GameState.ante = 2
	GameState.gold = 40
	GameState.map_options(2)
	GameState.choose_stop("shop")
	var shop: Node = _mount(s, "res://scenes/shop/Shop.tscn")
	await s._wait(1.6)
	s._clear_toasts()
	var offers: Node = shop.get_node_or_null("%RelicOffers")
	if offers == null or offers.get_child_count() == 0:
		printerr("CAPTURAS 0200: a loja não tem relíquias à venda")
	else:
		var p := (offers.get_child(0) as Control).get_global_rect().get_center()
		_mouse(s, p, true)
		await s._wait(maxf(0.5, Settings.long_press_time() + 0.12) + 0.3)   # o tempo do SceneRouter._explain_input, com folga
		await _until(s, func(): return SceneRouter._alive(SceneRouter._balloon), 2.0)   # num frame lento o balão chega depois
		if not SceneRouter._alive(SceneRouter._balloon):
			printerr("CAPTURAS 0200: o balão da loja não abriu")
		await s._wait(0.1)   # o balão só se posiciona no frame a seguir
		await s._shoot("200_02a_loja_balao")
		_mouse(s, p, false)
		await s._wait(0.5)
		await s._shoot("200_02b_loja_depois_de_largar")
	await _unmount(s, shop)
	GameState.clear_saved_run()

## A2: «REPETIR A BATALHA?» e um toque fora dela.
static func _retry(s: Node) -> void:
	GameState.new_run("deck01", 20003)
	GameState.relic_ids.clear()
	Settings.set_opt("assist_retry", true, false)
	var b: Node = await _battle(s, s._battle_state("bandit", ["c010", "c002"], ["c001"]))
	b.call("_offer_retry")
	await s._wait(1.8)
	await s._shoot("200_03a_repetir_batalha")
	await _tap(s, TAP_OUTSIDE)
	await s._wait(0.5)
	await s._shoot("200_03b_repetir_tocar_fora")
	Settings.reset_options(["assist_retry"], false)
	await _unmount(s, b)
	GameState.clear_saved_run()

## A3: o Construtor com cartas por guardar e o retroceder.
static func _builder(s: Node) -> void:
	load("res://scenes/builder/DeckBuilder.gd").reset_memory()
	var db: Node = _mount(s, "res://scenes/builder/DeckBuilder.tscn")
	await s._wait(0.4)
	for id in ["c001", "c001", "c002", "c003", "c009", "c018", "c019", "c021", "c028", "c039", "c040", "c050"]:
		db.call("_add_card", id)
	await s._wait(0.3)
	await s._shoot("200_04a_construtor_por_guardar")
	SceneRouter._busy = true   # na 0.19.1 o retroceder sai logo para o menu: aqui a cena não muda
	_back(s)
	await s._wait(0.5)
	await s._shoot("200_04b_construtor_retroceder")
	await _unmount(s, db)
	SceneRouter._busy = false
	load("res://scenes/builder/DeckBuilder.gd").reset_memory()

## A4: o draft com 2 escolhas e o retroceder.
static func _draft(s: Node) -> void:
	var dr: Node = _mount(s, "res://scenes/draft/Draft.tscn")
	await s._wait(0.6)
	for _i in 2:
		var cur: Array = dr.get("_current")
		dr.call("_on_pick", CardDB.new_instance((cur[0] as CardData).id))
		await s._wait(0.4)
	SceneRouter._busy = true
	_back(s)
	await s._wait(0.5)
	await s._shoot("200_05_draft_sair")
	await _unmount(s, dr)
	SceneRouter._busy = false

## A5: a janela do Reforço e um toque fora dela.
static func _kicker(s: Node) -> void:
	GameState.new_run("deck01", 20006)
	GameState.relic_ids.clear()
	var b: Node = await _battle(s, s._battle_state("bandit", ["c339", "c010", "c002"], ["c001"]))
	var bm: BattleManager = b.battle
	var fire: CardInstance = null
	for c in bm.deck.hand:
		if (c as CardInstance).data.id == "c339":
			fire = c
	b.call("_on_hand_card_pressed", fire)
	await s._wait(0.5)
	await s._shoot("200_06a_reforco")
	await _tap(s, TAP_OUTSIDE)
	await s._wait(0.5)
	await s._shoot("200_06b_reforco_tocar_fora")
	if bool(b.call("_alive", b.get("_modal"))):
		b.call("_close_modal", null)
	await _unmount(s, b)
	GameState.clear_saved_run()

## B7: o último turno (letreiro, ATACAR que não chega, 1.º toque); depois em inglês com o texto no máximo e canhoto.
static func _last_turn(s: Node) -> void:
	GameState.new_run("deck01", 20007)
	GameState.relic_ids.clear()
	var st: Dictionary = s._battle_state("bandit", ["c010", "c002", "c004"], ["c001", "c003", "c005"])
	st["turn"] = 4
	var b: Node = await _battle(s, st)
	var bm: BattleManager = b.battle
	await _attack(s, b)
	if not await _until(s, func(): return bm.turn == 5):
		printerr("CAPTURAS 0200: a batalha não chegou ao último turno (200_07a/07b)")
	await s._wait(0.35)
	await s._shoot("200_07a_ultimo_turno_letreiro")
	await s._wait(1.6)
	await s._shoot("200_07b_ultimo_turno_nao_chega")
	b.call("_on_end_turn_pressed")   # só o 1.º toque
	await s._wait(0.4)
	await s._shoot("200_07c_ultimo_turno_primeiro_toque")
	await _until(s, func(): return bm.finished or (not bm.resolving and not bool(b._animating)))
	await _unmount(s, b)
	for v in [["en", true, false, "200_07d_nao_chega_en_texto_grande"], ["pt", false, true, "200_07e_nao_chega_canhoto"]]:
		_text_mode(String(v[0]), bool(v[1]), bool(v[2]))
		GameState.new_run("deck01", 20007)
		GameState.relic_ids.clear()
		var st2: Dictionary = s._battle_state("bandit", ["c010", "c002", "c004"], ["c001", "c003", "c005"])
		st2["turn"] = 5
		var b2: Node = await _battle(s, st2)
		await s._wait(1.6)   # o letreiro «ÚLTIMO TURNO» (depois do da abertura) não pode tapar o ATACAR
		if not await _until(s, func(): return not (b2.get("banner") as Control).visible, 4.0):
			printerr("CAPTURAS 0200: o letreiro ainda está por cima do ATACAR (%s)" % String(v[3]))
		await s._shoot(String(v[3]))
		await _unmount(s, b2)
	_text_mode("pt", false, false)
	GameState.clear_saved_run()

## B7: o contra-ataque que mata («MORRES»), em português e em inglês com o texto no máximo.
static func _you_die(s: Node) -> void:
	for v in [["pt", false, "200_08a_morres"], ["en", true, "200_08b_morres_en_texto_grande"]]:
		_text_mode(String(v[0]), bool(v[1]), false)
		GameState.new_run("deck01", 20008)
		GameState.relic_ids.clear()
		GameState.player_hp = 3
		var st: Dictionary = s._battle_state("bandit", ["c010", "c002", "c001"], [])
		st["enemy"]["attack"] = 40
		var b: Node = await _battle(s, st)
		await s._shoot(String(v[2]))
		await _unmount(s, b)
	_text_mode("pt", false, false)
	GameState.clear_saved_run()

## B8: o passo de uma relíquia a meio da cascata.
static func _relic_step(s: Node) -> void:
	GameState.new_run("deck01", 20009)
	GameState.relic_ids.clear()
	for id in ["relic_drum", "relic_banner"]:
		GameState.add_relic(id)
	var b: Node = await _battle(s, s._battle_state("bandit", ["c010", "c002"], ["c001", "c003", "c005"]))
	var bm: BattleManager = b.battle
	b.call("_on_end_turn_pressed")
	if not await _until(s, func(): return bool(b._animating) and Shots0200._relic_popping(b), 12.0):
		printerr("CAPTURAS 0200: o passo de uma relíquia não apareceu na cascata (200_09)")
	await s._shoot("200_09_passo_reliquia")
	await _until(s, func(): return bm.finished or (not bm.resolving and not bool(b._animating)))
	await _unmount(s, b)
	GameState.clear_saved_run()

## B9: a derrota por turnos (o letreiro) e o fim da run a seguir, com avisos de progresso dados na batalha
## (C11: na 0.20.0 o fim da run mostra-os em «Também ganhaste:», com o detalhe comprido, dentro dos 720 px).
static func _defeat(s: Node) -> void:
	GameState.new_run("deck01", 20010)
	GameState.relic_ids.clear()
	var st: Dictionary = s._battle_state("bandit", ["c010", "c002"], ["c001", "c003", "c005"])
	st["turn"] = 5
	SceneRouter._busy = true   # a derrota leva ao fim da run: a cena não muda durante as capturas
	var b: Node = await _battle(s, st, true)
	var bm: BattleManager = b.battle
	await _attack(s, b)
	if not await _until(s, func(): return bm.finished, 20.0):
		printerr("CAPTURAS 0200: a batalha não acabou em derrota (200_10a)")
	await s._wait(0.45)
	await s._shoot("200_10a_derrota_turnos")
	_progress_notices("cards_1000")   # uma conquista que se ganha a perder (a 1.ª da lista é a «Primeira Vitória»)
	await s._wait(2.0)
	await _unmount(s, b)
	SceneRouter._busy = false
	var ro: Node = _mount(s, "res://scenes/ui/RunOver.tscn")
	await s._wait(1.2)
	await s._shoot("200_10b_runover_turnos")
	await _unmount(s, ro)
	GameState.clear_saved_run()

## O fim de uma run longa perdida com 5 avisos de progresso retidos na última batalha (C11: «Também ganhaste:» com 2
## e «… e mais 3»). O resumo, a causa e as duas filas de botões têm de caber nos 720 px.
static func _defeat_long(s: Node) -> void:
	long_defeat_state()
	var hold := Node.new()
	hold.add_to_group("hold_progress_notices")   # como a batalha da 0.20.0: os avisos ficam para o fim da run
	s.add_child(hold)
	for id: String in ["cards_1000", "channels_100", "flashback_5", "two_faces", "decks_5"]:   # conquistas que se ganham a perder
		EventBus.achievement_unlocked.emit(id)
	s.remove_child(hold)
	hold.queue_free()
	var ro: Node = _mount(s, "res://scenes/ui/RunOver.tscn")
	await s._wait(1.2)
	await s._shoot("200_10c_runover_tudo")
	await _unmount(s, ro)
	GameState.clear_saved_run()

## Uma run perdida no ante 6 com tudo o que alonga o RunOver: a causa com um número grande, talentos e fragmentos no
## detalhe, e o resumo completo (carta MVP, relíquia que mais deu, REVER O MAIOR GOLPE, dano e ouro por ante).
## Também usado pelo Test0200 (o conteúdo; a altura só se mede com ecrã).
static func long_defeat_state() -> void:
	GameState.new_run("deck01", 20012)
	GameState.ante = 6
	GameState.player_hp = 0
	GameState.last_victory = false
	GameState.last_loss = {"cause": "turns", "enemy": "", "boss": true, "hp_left": 1234567, "hp_left_pct": 38, "unspent_mana": 3,
		"unspent_turns": 0, "discards_left": 1, "shield": false, "shield_absorbed": 0, "trample_attacks": 0, "creatures_died": 2,
		"life_lost": 9, "rituals_resolved": 0, "turns": 5}
	var gold: Dictionary = {}
	var dmg: Dictionary = {}
	for a in range(1, 7):
		gold[str(a)] = {"in": 18 + a * 4, "out": 12 + a * 5, "interest": a, "sold": 0}
		dmg[str(a)] = 900 * a * a * a
	GameState.run_log["damage_by_ante"] = dmg
	GameState.run_log["gold_by_ante"] = gold
	GameState.run_log["card_dmg"] = {"c010": 98000, "c002": 41000}
	GameState.run_log["relic_dmg"] = {"relic_drum": 36000}
	GameState.run_log["best_hit"] = 64000
	GameState.run_log["best_cascade"] = {"steps": [{"kind": "card", "text": "c010"}]}

## C11: avisos de progresso durante a batalha e o ecrã das recompensas.
static func _rewards(s: Node) -> void:
	GameState.new_run("deck01", 20011)
	GameState.relic_ids.clear()
	var b: Node = await _battle(s, s._battle_state("bandit", ["c010", "c002"], ["c001", "c003"]))
	s._clear_toasts()
	_progress_notices()
	await s._wait(2.4)
	await s._shoot("200_11a_batalha_com_avisos")
	var rw := BattleRewards.open(b, TranslationServer.translate("ANTE %d VENCIDO") % 1, [["victory", 8], ["turns", 2, 2]], [], 10, 20)
	await s._wait(4.2)
	await s._shoot("200_11b_recompensas_tambem_ganhaste")
	rw.queue_free()
	await _unmount(s, b)
	GameState.clear_saved_run()

## D12: o tutorial da 1.ª batalha, no início e depois do 1.º ataque.
static func _tutorial(s: Node) -> void:
	Stats.set_tutorial_done(false)
	GameState.new_run("deck01", 9)
	GameState.pending_battle = {}
	var b: Node = _mount(s, "res://scenes/battle/Battle.tscn")
	EventBus.battle_ended.disconnect(b._on_battle_ended)
	var bm: BattleManager = b.battle
	bm.enemy["hp"] = 400000   # o 1.º ataque não pode ganhar a batalha (o tutorial fecharia)
	bm.enemy["max_hp"] = 400000
	EventBus.enemy_hp_changed.emit(400000, 400000)
	await s._wait(1.6)
	await s._shoot("200_12a_tutorial_inicio")
	for c in b.get_children():
		if c is TutorialOverlay and (c.get("_next_btn") as Button).visible:
			(c.get("_next_btn") as Button).pressed.emit()   # 0.20.0: o passo do MULLIGAN avança com CONTINUAR
			await s._wait(0.4)
	for v in (b.get_node("%Hand") as Container).get_children():
		if v is CardView and bm.can_play((v as CardView).card) and not (v as CardView).card.data.is_land():
			s._tap_play(v)
			break
	await s._wait(0.6)
	if bool(b.call("_alive", b.get("_modal"))):
		b.call("_close_modal", "plain")   # se a carta tiver Reforço
		await s._wait(0.4)
	await _attack(s, b)
	await _until(s, func(): return bm.turn >= 2 and not bool(b._animating), 20.0)
	# O passo a seguir ao ataque só aparece quando o letreiro «TURNO 2» sai (0.20.0): esperar pelo painel.
	var tut_up: bool = await _until(s, func():
		for c in b.get_children():
			if c is TutorialOverlay and (c.get("_panel") as Control).visible:
				return true
		return false, 6.0)
	if not tut_up:
		printerr("CAPTURAS 0200: o painel do tutorial não apareceu depois do ataque (200_12b)")
	await s._wait(0.8)
	await s._shoot("200_12b_tutorial_depois_do_ataque")
	await _unmount(s, b)
	Stats.set_tutorial_done(true)
	GameState.clear_saved_run()

## D13: o mapa, a loja, um evento com 4 opções e o baú com o texto no máximo; cada captura escreve os textos cortados.
static func _big_text(s: Node, scale: float = 1.3, tag: String = "texto_maximo") -> void:
	_text_mode("pt", true, false)
	Settings.set_opt("menu_text", scale, false)
	GameState.new_run("deck01", 20013)
	GameState.ante = 2
	GameState.map_phase = "battle"
	GameState.interlude_key = GameState.climate_key(2)
	var m: Node = _mount(s, "res://scenes/map/Map.tscn")
	await s._wait(1.4)
	await _shoot_cuts(s, m, "200_13a_mapa_" + tag)
	await _unmount(s, m)
	GameState.map_options(2)
	GameState.choose_stop("shop")
	var shop: Node = _mount(s, "res://scenes/shop/Shop.tscn")
	await s._wait(1.6)
	await _shoot_cuts(s, shop, "200_13b_loja_" + tag)
	await _unmount(s, shop)
	GameState.pending_event = "node_forge"
	var ev: Node = _mount(s, "res://scenes/event/Event.tscn")
	await s._wait(1.2)
	await _shoot_cuts(s, ev, "200_13c_evento_" + tag)
	await _unmount(s, ev)
	GameState.pending_event = ""
	GameState.ante = 4
	GameState.map_phase = "stop"
	GameState.prepare_loot()
	var loot: Node = _mount(s, "res://scenes/loot/Loot.tscn")
	await s._wait(1.4)
	await _shoot_cuts(s, loot, "200_13d_bau_" + tag)
	await _unmount(s, loot)
	_text_mode("pt", false, false)
	GameState.clear_saved_run()

static func _shoot_cuts(s: Node, scene: Node, name: String) -> void:
	s._clear_toasts()
	await s._shoot(name)
	print("cortes ", name, ": ", " | ".join(cuts(scene)))

## D13 (--only=0200d13): só os 4 ecrãs do «Texto dos menus», a 100 %, 115 % e 130 %, para comparar os cortes.
static func run_big_text(s: Node) -> void:
	Settings.tips_enabled = false
	Settings.set_opt("dim_idle", false, false)
	Settings.set_opt("auto_perf", false, false)
	Settings.set_opt("edge_guard", false, false)
	Storage.crashed_before = false
	GameState.free_mode = false
	GameState.puzzle_id = ""
	await _big_text(s, 1.0, "texto_100")
	await _big_text(s, 1.15, "texto_115")
	await _big_text(s)
	Settings.language = "pt"
	Settings.reset_options(["dim_idle", "auto_perf", "edge_guard", "menu_text", "large_text", "left_handed"], false)
	Settings.apply()
	GameState.clear_saved_run()
