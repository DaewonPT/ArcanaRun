class_name Test0190
extends RefCounted
## Testes da 0.19.0 (as 300 coisas que faltavam), chamados pelo SmokeTest: `await Test0190.run(self)`.
## Cada secção do documento tem a sua função; usam o _check() e as ajudas do SmokeTest (`t`).

static func run(t: Node) -> void:
	var old_lang := Settings.language
	Settings.language = "pt"   # os textos comparados são os portugueses
	await base(t)
	await section1(t)
	await section2(t)
	await section3(t)
	await section4(t)
	await section5(t)
	await section6(t)
	await section7(t)
	await section8(t)
	await section9(t)
	Settings.language = old_lang

# ---------------------------------------------------------------------------
# Base: gravações seguras (225–228, 254), perfis (291), opções novas, Configurações (287–290)
# ---------------------------------------------------------------------------

static func base(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	# Gravação atómica, cópia .bak e leitura da cópia quando o ficheiro se estraga.
	var path := "user://zs_test_saveio.json"
	SaveIO.remove(path)
	t._check(SaveIO.write_json(path, {"v": 1}, true) and SaveIO.read_json(path).get("v") == 1, "SaveIO devia gravar e ler")
	var before := SaveIO.skipped
	SaveIO.write_json(path, {"v": 1}, true)
	t._check(SaveIO.skipped == before + 1, "SaveIO não devia regravar o mesmo texto (254)")
	t._check(SaveIO.write_json(path, {"v": 2}, true) and FileAccess.file_exists(path + ".bak"), "a 2.ª gravação devia deixar a anterior em .bak (226)")
	t._check(not FileAccess.file_exists(path + ".tmp"), "não devia ficar o ficheiro .tmp")
	var bad := FileAccess.open(path, FileAccess.WRITE)
	bad.store_string("{\"v\": 3")
	bad.close()
	SaveIO.forget(path)
	var rec = SaveIO.read_json(path)
	t._check(rec is Dictionary and int(rec.get("v", 0)) == 1 and path in SaveIO.recovered, "um ficheiro estragado devia ler-se da cópia (227)")
	SaveIO.remove(path)
	t._check(not FileAccess.file_exists(path) and not FileAccess.file_exists(path + ".bak"), "remove devia apagar o ficheiro e a cópia")
	t._check(SaveIO.space_left() != 0, "devia saber-se o espaço livre (228)")
	# A run: não regrava igual (254) e tem cópia (226).
	GameState.current_slot = 6
	GameState.new_run("deck01", 1901)
	GameState.save_run({}, "map")
	var w := SaveIO.writes
	GameState.save_run({}, "map")
	t._check(SaveIO.writes == w, "gravar a run sem mudanças não devia escrever outra vez (254)")
	GameState.gold += 1
	GameState.save_run({}, "map")
	t._check(SaveIO.writes == w + 1 and FileAccess.file_exists(GameState.slot_path(6) + ".bak"), "gravar com mudanças devia escrever e deixar a cópia (226)")
	# Lixo com várias runs e 7 dias (229).
	GameState.trash_slot(6, "deleted")
	GameState.delete_slot(6)
	t._check(GameState.has_trash() and not GameState.has_saved_run(6), "apagar devia ir para o lixo")
	var n_trash := GameState.trash_list().size()
	t._check(n_trash >= 1 and String(GameState.trash_info(0).get("reason", "")) == "deleted", "o lixo devia ter a run apagada")
	var back := GameState.restore_trash(0)
	t._check(back > 0 and GameState.trash_list().size() == n_trash - 1, "recuperar devia tirar do lixo")
	if back > 0:
		GameState.delete_slot(back)
	GameState.current_slot = 1
	# Opções novas: valores, tipos e escolhas.
	t._check(Settings.opt("long_press") == "normal" and Settings.opt("buttons_big") == 0, "as opções novas deviam começar nos valores por omissão")
	Settings.set_opt("long_press", "nada", false)
	t._check(Settings.opt("long_press") == "normal", "uma escolha inválida devia voltar ao valor por omissão")
	Settings.cycle_opt("long_press")
	t._check(Settings.opt("long_press") == "long", "rodar devia passar ao valor seguinte")
	Settings.set_opt("menu_text", 1.15, false)
	t._check(is_equal_approx(float(Settings.opt("menu_text")), 1.15), "um número devia ficar como está")
	Settings.reset_options(["long_press", "menu_text"], false)
	t._check(Settings.opt("long_press") == "normal" and is_equal_approx(float(Settings.opt("menu_text")), 1.0), "repor devia voltar ao normal (290)")
	var changed := Settings.apply_preset("vision")
	t._check(changed.size() >= 5 and Settings.large_text and float(Settings.opt("menu_text")) > 1.0, "a predefinição Visão devia ligar várias opções (287)")
	Settings.reset_options(Settings.PRESETS["vision"].keys())
	t._check(not Settings.large_text and not Settings.high_contrast, "repor devia desligar o que a predefinição ligou")
	# Gravar e ler as opções (o tipo sobrevive ao JSON).
	Settings.set_opt("vibration_strength", 3, false)
	var d: Dictionary = JSON.parse_string(JSON.stringify(Settings._settings_dict()))
	Settings.opts.clear()
	Settings._load_from(d)
	t._check(Settings.opt("vibration_strength") == 3 and typeof(Settings.opt("vibration_strength")) == TYPE_INT, "a opção devia voltar do JSON com o tipo certo")
	Settings.reset_options(["vibration_strength"])
	# Áudio: bus dos cliques, mono e sons suaves.
	t._check(AudioServer.get_bus_index("UI") >= 0, "devia haver o bus UI (cliques, 270)")
	Settings.set_opt("mono", true, false)
	Settings.set_opt("soft_sounds", true, false)
	Settings.apply()
	t._check(_bus_has(AudioServer.get_bus_index("Master"), "AudioEffectStereoEnhance") and _bus_has(AudioServer.get_bus_index("Sfx"), "AudioEffectLowPassFilter"), "o som mono e os sons suaves deviam pôr os efeitos nos buses (269, 272)")
	Settings.reset_options(["mono", "soft_sounds"])
	t._check(not _bus_has(AudioServer.get_bus_index("Master"), "AudioEffectStereoEnhance"), "desligar devia tirar os efeitos")
	# Perfis (291): um perfil novo começa sem nada e o 1 fica como estava.
	Profiles.reset_cache()
	var p1_runs := int(Stats.get_stat("runs"))
	Settings.set_opt("clock", true)
	var pid := Profiles.create("Teste")
	t._check(pid > 1 and Profiles.count() >= 2 and Profiles.name_of(pid) == "Teste", "devia criar o perfil")
	t._check(Profiles.switch_to(pid) and Profiles.active() == pid, "devia mudar para o perfil novo")
	t._check(Settings.path().begins_with("user://perfil_%d/" % pid) and GameState.progress_path().begins_with("user://perfil_%d/" % pid), "o perfil novo devia ter a sua pasta")
	t._check(int(Stats.get_stat("runs")) == 0 and not bool(Settings.opt("clock")) and not GameState.has_any_saved_run(), "o perfil novo devia começar sem progresso, sem jogos e com as opções normais")
	Settings.set_opt("clock", false)
	t._check(Profiles.switch_to(1) and int(Stats.get_stat("runs")) == p1_runs and bool(Settings.opt("clock")), "voltar ao perfil 1 devia repor o que lá estava")
	Settings.set_opt("clock", false)
	t._check(Profiles.remove(pid) and Profiles.get_profile(pid).is_empty() and not DirAccess.dir_exists_absolute("user://perfil_%d/" % pid), "devia apagar o perfil e a pasta dele")
	t._check(not Profiles.remove(1), "o perfil 1 nunca se apaga")
	# Configurações: separadores, pesquisa, ajuda, repor, predefinições e perfis.
	var sm := SettingsMenu.open()
	await tree.process_frame
	for tab in SettingsMenu.TABS:
		sm._show_tab(String(tab[0]))
		await tree.process_frame
		t._check(sm._content.get_child_count() >= 2, "o separador %s devia ter opções" % tab[1])
	sm._show_tab("access")
	await tree.process_frame
	t._check(sm._content.get_node_or_null("Presets") != null, "o separador ACESSIBILIDADE devia ter as predefinições")
	sm._show_tab("profile")
	await tree.process_frame
	t._check(sm._content.find_child("Profile1", true, false) != null, "o separador PERFIL devia mostrar o perfil 1")
	var found: Array = sm.matches("vibra")
	var has_vib := false
	for o in found:
		has_vib = has_vib or String(o.get("key", "")) == "vibration"
	t._check(has_vib, "procurar «vibra» devia encontrar a Vibração (288)")
	sm._search.text = "volume"
	sm._on_search("volume")
	await tree.process_frame
	t._check(sm._content.find_child("Opt_master_volume", true, false) != null, "a pesquisa devia mostrar o Volume geral")
	t._check(sm._content.find_child("Help", true, false) != null, "cada opção devia ter a sua ajuda (289)")
	sm._search.text = ""
	sm._show_tab("perf")
	await tree.process_frame
	t._check(sm._content.find_child("Cost", true, false) != null, "as opções que gastam bateria deviam dizê-lo (222)")
	t._check(sm._content.find_child("ResetTab", true, false) != null, "cada separador devia ter o REPOR (290)")
	# Todas as opções têm tradução para inglês.
	var untranslated: Array[String] = []
	for o in sm._options():
		for k in ["label", "help"]:
			var txt := String(o.get(k, ""))
			if txt != "" and Settings._en.get_message(txt) == "":
				untranslated.append(txt)
		var names = o.get("names", [])
		var values: Array = names.values() if names is Dictionary else names
		for nm in values:
			if Settings._en.get_message(String(nm)) == "":
				untranslated.append(String(nm))
	for tab in SettingsMenu.TABS:
		if Settings._en.get_message(String(tab[1])) == "":
			untranslated.append(String(tab[1]))
	t._check(untranslated.is_empty(), "opções sem inglês: %s" % ", ".join(untranslated))
	sm.close()
	await tree.process_frame
	print("  0.19.0 (base): gravações seguras, lixo, opções novas, som, perfis e Configurações OK")

static func _bus_has(bus: int, cls: String) -> bool:
	if bus < 0:
		return false
	for i in AudioServer.get_bus_effect_count(bus):
		if AudioServer.get_bus_effect(bus, i).get_class() == cls:
			return true
	return false

# ---------------------------------------------------------------------------
# 1. Ergonomia de entrada e controlo (1–32)
# ---------------------------------------------------------------------------

static func _key(code: Key) -> InputEventKey:
	var k := InputEventKey.new()
	k.keycode = code
	k.pressed = true
	return k

static func _touch(index: int, pos: Vector2, pressed: bool) -> InputEventScreenTouch:
	var e := InputEventScreenTouch.new()
	e.index = index
	e.position = pos
	e.pressed = pressed
	return e

static func _drag(index: int, pos: Vector2) -> InputEventScreenDrag:
	var e := InputEventScreenDrag.new()
	e.index = index
	e.position = pos
	return e

static func _center(c: Control) -> Vector2:
	return c.get_global_rect().get_center()

static func section1(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	# 3, 4: o toque longo e o arrasto à escolha.
	Settings.set_opt("long_press", "long", false)
	Settings.set_opt("drag_threshold", "high", false)
	t._check(is_equal_approx(Settings.long_press_time(), 0.65) and is_equal_approx(Settings.drag_px(), 26.0), "o toque longo e o arrasto deviam seguir as opções (3, 4)")
	Settings.reset_options(["long_press", "drag_threshold"], false)
	# 7: dois toques seguidos contam como um.
	UiKit.tap_guard_on = true
	t._check(UiKit.allow_tap("t190") and not UiKit.allow_tap("t190"), "dois toques seguidos deviam contar como um (7)")
	UiKit.tap_guard_on = false
	# 25: as filas de botões do lado da mão dominante.
	var row := HBoxContainer.new()
	var ra := Control.new()
	ra.name = "A"
	var rb := Control.new()
	rb.name = "B"
	row.add_child(ra)
	row.add_child(rb)
	Settings.left_handed = true
	UiKit.hand_mirror(row)
	UiKit.hand_mirror(row)
	var mirrored := row.get_child(0) == rb
	Settings.left_handed = false
	UiKit.hand_mirror(row)
	t._check(mirrored and row.get_child(0) == ra, "a mão esquerda devia virar as filas e a direita voltar a pô-las como estavam (25)")
	row.free()
	# 19: com rato a sério, passar por cima explica (no telemóvel não).
	var cv: CardView = load("res://scenes/ui/CardView.tscn").instantiate()
	t.add_child(cv)
	cv.setup(CardDB.new_instance("c001"))
	var rv := RelicView.new()
	t.add_child(rv)
	rv.setup("relic_drum")
	var was_mouse := SceneRouter.real_mouse
	SceneRouter.real_mouse = false
	var touch_tip := cv._get_tooltip(Vector2(5, 5))
	SceneRouter.real_mouse = true
	var mouse_tip := cv._get_tooltip(Vector2(5, 5))
	var relic_tip := rv._get_tooltip(Vector2(5, 5))
	SceneRouter.real_mouse = was_mouse
	t._check(touch_tip == "" and mouse_tip.contains("\n") and relic_tip.contains("\n"), "o rato por cima devia explicar a carta e a relíquia (19)")
	cv.queue_free()
	rv.queue_free()
	# 26: botões maiores (e voltar ao normal).
	Settings.set_opt("buttons_big", 2, false)
	var bb := UiKit.button("X", 48, 16)
	t.add_child(bb)
	await tree.process_frame
	await tree.process_frame
	var big := bb.custom_minimum_size.y
	Settings.set_opt("buttons_big", 0, false)
	SceneRouter.refresh_buttons(bb)
	t._check(is_equal_approx(big, 64.0) and is_equal_approx(bb.custom_minimum_size.y, 48.0), "os botões deviam crescer para 64 px e voltar a 48 (26)")
	bb.queue_free()
	# 28, 29: bordas — o gesto de voltar e a palma.
	t._check(SceneRouter.near_edge(Vector2(4, 300)) and not SceneRouter.near_edge(Vector2(640, 300)), "um toque colado à borda devia contar como borda (28)")
	t._check(SceneRouter.safe_insets()["left"] == 0.0, "sem entalhes, a área segura não devia tirar nada")
	Settings.set_opt("palm_guard", true, false)
	var palm := InputEventMouseButton.new()
	palm.device = InputEvent.DEVICE_ID_EMULATION
	palm.button_index = MOUSE_BUTTON_LEFT
	palm.pressed = true
	palm.position = Vector2(3, 400)
	var swallowed := SceneRouter._palm_filter(palm)
	palm.pressed = false
	var swallowed_up := SceneRouter._palm_filter(palm)
	var finger := InputEventMouseButton.new()
	finger.device = InputEvent.DEVICE_ID_EMULATION
	finger.button_index = MOUSE_BUTTON_LEFT
	finger.pressed = true
	finger.position = Vector2(640, 400)
	var kept := not SceneRouter._palm_filter(finger)
	finger.pressed = false
	SceneRouter._palm_filter(finger)
	Settings.reset_options(["palm_guard"], false)
	t._check(swallowed and swallowed_up and kept, "a palma na borda devia ser ignorada e o dedo no meio não (29)")
	# 17, 20: comando — os botões ganham foco e a moldura; voltar ao toque tira-os.
	var pad_root := Control.new()
	pad_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	var pb1 := UiKit.button("UM", 50, 16)
	pad_root.add_child(pb1)
	SceneRouter.show_overlay(pad_root)
	await tree.process_frame
	SceneRouter.set_pad_mode(true)
	await tree.process_frame
	var focused := pb1.has_focus() and pb1.focus_mode == Control.FOCUS_ALL and pb1.get_theme_stylebox("focus") == SceneRouter.focus_style()
	SceneRouter.set_pad_mode(false)
	t._check(focused and not pb1.has_focus() and pb1.focus_mode == Control.FOCUS_NONE, "com comando, o 1.º botão da janela devia ficar escolhido com a moldura (17, 20)")
	pad_root.queue_free()
	await tree.process_frame
	# 9: deslizar troca de separador; 22: a Coleção volta ao mesmo separador.
	load("res://scenes/ui/Collection.gd").reset_memory()
	var col: Node = load("res://scenes/ui/Collection.tscn").instantiate()
	t.add_child(col)
	await tree.process_frame
	var sw := col.find_child("SwipeArea", false, false) as SwipeArea
	t._check(sw != null, "a Coleção devia ter o deslizar entre separadores (9)")
	if sw != null:
		sw.simulate(Vector2(900, 400), Vector2(700, 410))
		await tree.process_frame
	t._check(String(col.get("_tab")) == "relics", "deslizar para a esquerda devia passar às relíquias (9)")
	col.queue_free()
	await tree.process_frame
	var col2: Node = load("res://scenes/ui/Collection.tscn").instantiate()
	t.add_child(col2)
	await tree.process_frame
	t._check(String(col2.get("_tab")) == "relics", "a Coleção devia reabrir no mesmo separador (22)")
	col2.queue_free()
	load("res://scenes/ui/Collection.gd").reset_memory()
	await tree.process_frame
	# 21: com rato, arrastar a lista desliza-a.
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(300, 200)
	sc.size = Vector2(300, 200)
	var tall := Control.new()
	tall.custom_minimum_size = Vector2(280, 2000)
	sc.add_child(tall)
	t.add_child(sc)
	await tree.process_frame
	ScrollFling.attach(sc)
	var fl := sc.get_node_or_null("ScrollFling") as ScrollFling
	if fl != null:
		var down := InputEventMouseButton.new()
		down.button_index = MOUSE_BUTTON_LEFT
		down.pressed = true
		down.global_position = Vector2(100, 300)
		fl._on_input(down)
		var mv := InputEventMouseMotion.new()
		mv.global_position = Vector2(100, 220)
		fl._on_input(mv)
	t._check(fl != null and sc.scroll_vertical == 80, "arrastar a lista com o rato devia deslizá-la (21)")
	sc.queue_free()
	# 32: trocar a ordem dos jogos guardados.
	GameState.current_slot = 5
	GameState.new_run("deck01", 19051)
	GameState.save_run({}, "map")
	GameState.current_slot = 6
	GameState.new_run("deck02", 19052)
	GameState.save_run({}, "map")
	t._check(GameState.swap_slots(5, 6) and String(GameState.slot_info(5).get("what", "")) == TranslationServer.translate(String(CardDB.get_deck("deck02").get("name", ""))) and GameState.current_slot == 5,
		"▲ ▼ deviam trocar os jogos de espaço (32)")
	GameState.delete_slot(5)
	GameState.delete_slot(6)
	GameState.current_slot = 1
	# A batalha: canalizar a arrastar (1), deslizar para cima (2), zona de cancelar (14), segurar ATACAR (5),
	# toques guardados (6), dois dedos (8), equipamento a arrastar (12), menu da criatura (16), mão em grelha (15),
	# teclado (18), carta em grande com as vizinhas (10), botões e altura da mão (24, 27).
	GameState.new_run("deck01", 19001)
	GameState.clear_saved_run()
	var st := {"enemy": {"id": "test", "name": "Teste", "hp": 99999, "max_hp": 99999, "attack": 1, "text": "", "abilities": [], "boss": false, "rule": {}},
		"turn": 1, "max_turns": 5, "mana_total": 6, "mana_available": 6, "discards_left": 3, "player_hp": GameState.player_hp,
		"library": [{"id": "c005", "entry": -1}, {"id": "c010", "entry": -1}, {"id": "c005", "entry": -1}, {"id": "c010", "entry": -1}],
		"hand": [{"id": "c001", "entry": -1}, {"id": "c002", "entry": -1}, {"id": "c003", "entry": -1}, {"id": "c004", "entry": -1},
		{"id": "c008", "entry": -1}, {"id": "c489", "entry": -1}], "graveyard": [], "board": [{"id": "c099", "entry": -1}, {"id": "c069", "entry": -1}], "exile": []}
	GameState.pending_battle = st
	var b: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	t.add_child(b)
	EventBus.battle_ended.disconnect(b._on_battle_ended)
	await t._wait_until(func(): return not b._animating, 8000)
	await tree.process_frame
	var bm: BattleManager = b.battle
	var warn_rare := Settings.warn_rare
	var warn_mana := Settings.warn_mana
	Settings.warn_rare = false
	Settings.warn_mana = false
	# 1 + 14: arrastar para cima do CANALIZAR canaliza; a etiqueta diz o que acontece.
	var spell := t._find(bm.deck.hand, "c002") as CardInstance
	var sv: Control = b._hand_views.get(spell.uid)
	var p0 := _center(sv)
	b._on_hand_drag_started(spell, p0)
	var zones_ok: bool = b._cancel_zone != null and b._drop_hint != null
	b._on_hand_drag_moved(spell, Vector2(640, 200))
	var play_hint := String((b._drop_hint.get_node("Text") as Label).text) if b._drop_hint != null else ""
	var cancel_shown: bool = b._cancel_zone != null and b._cancel_zone.visible
	var dpos := _center(b.discard_btn)
	b._on_hand_drag_moved(spell, dpos)
	var over: bool = b._discard_zone
	var discard_hint := String((b._drop_hint.get_node("Text") as Label).text) if b._drop_hint != null else ""
	var grave0 := bm.deck.graveyard.size()
	b._on_hand_drag_ended(spell, dpos)
	await tree.process_frame
	t._check(zones_ok and cancel_shown and play_hint == TranslationServer.translate("▲ Larga para jogar"), "ao arrastar devia aparecer a zona de cancelar e a etiqueta (14)")
	t._check(over and discard_hint == TranslationServer.translate("Larga para canalizar") and bm.deck.graveyard.size() == grave0 + 1 and not (spell in bm.deck.hand), "largar em cima do CANALIZAR devia canalizar a carta (1)")
	t._check(b._drop_hint == null and b._cancel_zone == null, "ao largar, a etiqueta e a zona deviam sair")
	# 2: deslizar depressa para cima joga a carta (sem a levar até à Arena).
	var land := t._find(bm.deck.hand, "c008") as CardInstance
	var lp := _center(b._hand_views.get(land.uid))
	b._on_hand_drag_started(land, lp)
	var now := Time.get_ticks_msec()
	b._drag_samples = [[now - 60, lp], [now, lp + Vector2(0, -90)]]
	b._drag_start_y = lp.y
	b._on_hand_drag_ended(land, lp + Vector2(0, -90))
	await tree.process_frame
	t._check(not (land in bm.deck.hand), "um gesto rápido para cima devia jogar a carta (2)")
	# Desistir a meio (dois dedos, por exemplo): a carta volta à mão.
	var c3 := t._find(bm.deck.hand, "c003") as CardInstance
	b._on_hand_drag_started(c3, _center(b._hand_views.get(c3.uid)))
	b._on_hand_drag_moved(c3, Vector2(640, 200))
	b._cancel_hand_drag()
	await tree.process_frame
	t._check(c3 in bm.deck.hand and b._drag_ghost == null, "desistir do arrasto devia deixar a carta na mão")
	# 5: ATACAR a segurar.
	Settings.set_opt("hold_attack", true, false)
	b._on_end_turn_pressed()
	var not_yet: bool = not bm.resolving and bm.turn == 1
	b._on_end_turn_down()
	b._hold_tick(0.2)
	var still: bool = not b._hold_fired and b._hold_t > 0.0
	bm.resolving = true   # o ataque a sério não corre no teste
	b._hold_tick(0.4)
	bm.resolving = false
	var fired: bool = b._hold_fired
	b._on_end_turn_pressed()   # o largar depois de disparar não conta
	t._check(not_yet and still and fired and not b._hold_fired and not bm.resolving, "com ATACAR a segurar, só meio segundo com o dedo em cima ataca (5)")
	b._on_end_turn_up()
	Settings.reset_options(["hold_attack"], false)
	# 6: um toque durante o turno do inimigo fica guardado.
	var c4 := t._find(bm.deck.hand, "c004") as CardInstance
	bm.resolving = true
	b._on_hand_card_tapped(c4)
	var queued: bool = b._queued_tap_uid == c4.uid
	bm.resolving = false
	b._run_queued_tap()
	t._check(queued and b._selected_uid == c4.uid, "o toque guardado devia acontecer quando o turno volta (6)")
	b._set_selection(-1)
	# 8: dois dedos — tocar abre a pausa; deslizar para a esquerda desfaz.
	b._input(_touch(0, Vector2(500, 300), true))
	b._input(_touch(1, Vector2(620, 300), true))
	b._input(_touch(0, Vector2(500, 300), false))
	b._input(_touch(1, Vector2(620, 300), false))
	await tree.process_frame
	t._check(SceneRouter.top_overlay() is PauseMenu, "tocar com dois dedos devia abrir a pausa (8)")
	if SceneRouter.top_overlay() is PauseMenu:
		(SceneRouter.top_overlay() as PauseMenu).close()
	await tree.process_frame
	await tree.process_frame
	var c1 := t._find(bm.deck.hand, "c001") as CardInstance
	b._on_hand_card_pressed(c1)   # jogar dá uma jogada para desfazer
	await tree.process_frame
	var played: bool = not (c1 in bm.deck.hand)
	b._input(_touch(0, Vector2(700, 300), true))
	b._input(_touch(1, Vector2(800, 330), true))
	b._input(_drag(0, Vector2(560, 305)))
	b._input(_drag(1, Vector2(660, 335)))
	b._input(_touch(0, Vector2(560, 305), false))
	b._input(_touch(1, Vector2(660, 335), false))
	await tree.process_frame
	var back_in_hand := false
	for c in bm.deck.hand:
		back_in_hand = back_in_hand or c.data.id == "c001"
	t._check(played and back_in_hand, "deslizar com dois dedos para a esquerda devia desfazer (8)")
	# 16: toque longo numa criatura — o menu; passar para a ponta direita.
	var boar := t._find(bm.board, "c099") as CardInstance
	var shifter := t._find(bm.board, "c069") as CardInstance
	b._open_creature_menu(boar)
	await tree.process_frame
	var menu: Node = b._modal.find_child("CreatureMenu", true, false) if b._modal != null else null
	var last_btn: Node = menu.find_child("Act_last", true, false) if menu != null else null
	t._check(menu != null and menu.find_child("Act_see", true, false) != null and menu.find_child("Threats", true, false) != null and last_btn is Button, "o toque longo numa criatura devia abrir o menu dela (16)")
	if last_btn is Button:
		(last_btn as Button).pressed.emit()
	await tree.process_frame
	t._check(bm.board.find(boar) == bm.board.size() - 1, "PASSAR PARA A PONTA DIREITA devia mudar a ordem (16)")
	# 12: arrastar o equipamento de uma criatura para a outra (1 de mana).
	var wings := t._find(bm.deck.hand, "c489") as CardInstance
	b._equip_drop_uid = boar.uid
	b._on_hand_card_pressed(wings)
	await tree.process_frame
	await tree.process_frame
	var on_boar := bm.equipment_holder(wings) == boar
	var mana0 := bm.mana_available
	b._start_equip_drag(wings, Vector2(400, 300))
	var ghost_ok: bool = b._eq_ghost != null
	b._end_equip_drag(_center(b._board_views.get(shifter.uid)))
	await tree.process_frame
	t._check(on_boar and ghost_ok and bm.equipment_holder(wings) == shifter and bm.mana_available == mana0 - BattleManager.EQUIP_MOVE_COST, "arrastar o equipamento devia passá-lo para a outra criatura por 1 de mana (12)")
	# 15: com 8 ou mais cartas, a mão em grelha.
	for id in ["c001", "c002", "c003", "c004", "c005", "c001"]:
		bm.deck.hand.append(CardDB.new_instance(id))
	b._refresh_hand()
	b._refresh_grid_btn()
	t._check(b._grid_btn != null and b._grid_btn.visible, "com 8 cartas devia aparecer a mão em grelha (15)")
	b._open_hand_grid()
	await tree.process_frame
	t._check(SceneRouter.top_overlay() is ZoneViewer, "a mão em grelha devia abrir")
	SceneRouter.close_overlays()
	await tree.process_frame
	# 18: teclado — o número escolhe a carta; a seta passa à seguinte.
	b._unhandled_input(_key(KEY_2))
	var order: Array = b._hand_in_order()
	var sel2: bool = order.size() >= 3 and b._selected_uid == (order[1] as CardInstance).uid
	b._unhandled_input(_key(KEY_RIGHT))
	t._check(sel2 and b._selected_uid == (order[2] as CardInstance).uid, "o teclado devia escolher as cartas (18)")
	b._set_selection(-1)
	# 10: a carta em grande com as vizinhas da mão; passar à seguinte.
	b._on_card_long_pressed(order[0])
	await tree.process_frame
	var z := SceneRouter.top_overlay() as CardZoom
	var z2: CardZoom = z.go_step(1) if z != null else null
	await tree.process_frame
	t._check(z2 != null and z2.current_item() == order[1] and SceneRouter.top_overlay() == z2 and z2.find_child("Next", false, false) != null, "a carta em grande devia passar à carta seguinte da mão (10)")
	SceneRouter.close_overlays()
	await tree.process_frame
	# 24, 27: os botões onde quiseres e a altura da mão.
	Settings.set_opt("battle_buttons", "right", false)
	Settings.set_opt("hand_offset", 32, false)
	b._apply_handedness()
	var middle: Node = b.layout.get_node("Middle")
	var right_side: bool = middle.get_child(middle.get_child_count() - 1).name == "LeftCol"
	var offset_ok: bool = is_equal_approx(b.layout.offset_bottom, -66.0)
	Settings.set_opt("battle_buttons", "bottom", false)
	b._apply_handedness()
	var by_hand: bool = b.one_hand_active()
	Settings.reset_options(["battle_buttons", "hand_offset"], false)
	b._apply_handedness()
	t._check(right_side and offset_ok and by_hand and not b.one_hand_active(), "os botões da batalha e a altura da mão deviam seguir as opções (24, 27)")
	Settings.warn_rare = warn_rare
	Settings.warn_mana = warn_mana
	b.queue_free()
	await tree.process_frame
	GameState.clear_saved_run()
	# 11: arrastar uma relíquia tua para a zona VENDER, na loja.
	GameState.new_run("deck01", 19011)
	GameState.relic_ids.assign(["relic_drum"])
	GameState.relic_locked.clear()
	GameState.map_choice = {"stop": "shop"}
	var shop: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	t.add_child(shop)
	await tree.process_frame
	await tree.process_frame
	var gold0 := GameState.gold
	var price := GameState.relic_sell_price("relic_drum")
	shop._on_owned_drag_started("relic_drum", Vector2(100, 600))
	var zone: Control = shop._sell_zone
	var had_zone := zone != null
	var over_sell := false
	if had_zone:
		shop._on_owned_drag_moved("relic_drum", _center(zone))
		over_sell = shop._over_sell
		shop._on_owned_drag_ended("relic_drum", _center(zone))
	await tree.process_frame
	t._check(had_zone and over_sell and not ("relic_drum" in GameState.relic_ids) and GameState.gold == gold0 + price, "largar a relíquia na zona VENDER devia vendê-la (11)")
	shop.queue_free()
	await tree.process_frame
	# 23: o mapa arrasta-se (numa lista).
	GameState.new_run("deck01", 19023)
	var map: Node = load("res://scenes/map/Map.tscn").instantiate()
	t.add_child(map)
	await tree.process_frame
	await tree.process_frame
	t._check(map.find_child("BoardScroll", true, false) is ScrollContainer and map.find_child("Board", true, false).get_parent() is ScrollContainer, "o mapa devia estar numa lista que se arrasta (23)")
	map.queue_free()
	await tree.process_frame
	GameState.clear_saved_run()
	print("  0.19.0 (1. controlo): toque longo, arrasto, canalizar e jogar a arrastar, zona de cancelar, segurar ATACAR, toques guardados, dois dedos, equipamento, menu da criatura, grelha, teclado, comando, rato, botões, bordas, palma, lista com rato, loja, mapa e espaços OK")

# ---------------------------------------------------------------------------
# 2. Gestão de inventários (33–66)
# ---------------------------------------------------------------------------

static func section2(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	var tr_ := func(x: String) -> String: return TranslationServer.translate(x)
	SceneRouter.close_overlays()   # o interlúdio do ato que o mapa da secção 1 abriu
	await tree.process_frame
	# 34: ordenar.
	var l: Array = [CardDB.get_card("c005"), CardDB.get_card("c001"), CardDB.get_card("c016")]
	CardSort.sort(l, "cost")
	var by_cost: bool = (l[0] as CardData).cost <= (l[1] as CardData).cost and (l[1] as CardData).cost <= (l[2] as CardData).cost
	CardSort.sort(l, "rarity")
	t._check(by_cost and (l[0] as CardData).rarity == "rare" and CardSort.next_key("num") == "cost", "ordenar devia seguir o custo e a raridade (34)")
	# 44: favoritas.
	var fav0 := GameState.is_favorite("c003")
	GameState.toggle_favorite("c003")
	var fav1 := GameState.is_favorite("c003")
	GameState.toggle_favorite("c003")
	t._check(not fav0 and fav1 and not GameState.is_favorite("c003"), "a estrela devia marcar e desmarcar a favorita (44)")
	# 45: NOVO — descoberta e ainda não aberta.
	GameState.ensure_opened_baseline()
	var seen_before := Stats.is_seen("cards", "c450")
	if not seen_before:
		Stats.mark_seen("cards", "c450", false)
	var was_new := GameState.is_new("cards", "c450")
	GameState.mark_opened("cards", "c450")
	t._check((seen_before or was_new) and not GameState.is_new("cards", "c450"), "uma carta nova devia ter o NOVO até ser aberta (45)")
	# 65: mais um lugar de poção com o talento.
	var slots0 := GameState.consumable_slots()
	GameState.run_talents["item_slots"] = 1.0
	t._check(GameState.consumable_slots() == slots0 + 1, "o talento Bolsa Funda devia dar mais um lugar de poção (65)")
	GameState.run_talents.erase("item_slots")
	# Construtor: 12 espaços, pesquisa, ordem, números, avisos, completar, lista, duplicar, copiar, mudar de lugar, nota, mão de exemplo, memória.
	var keep_decks: Dictionary = CardDB.custom_decks.duplicate(true)
	CardDB.custom_decks.clear()
	load("res://scenes/builder/DeckBuilder.gd").reset_memory()
	var db: Node = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	t.add_child(db)
	await tree.process_frame
	t._check(db._slot_opt.item_count == 12, "o Construtor devia ter 12 espaços (37)")
	db._search = "Batedor das Brasas"
	db._rebuild()
	var found := false
	for v in db._grid.get_children():
		found = found or (v is CardView and (v as CardView).card.data.id == "c001")
	t._check(found and db._grid.get_child_count() <= 3, "procurar pelo nome devia encontrar a carta (33)")
	db._search = ""
	db._sort = "power"
	db._rebuild()
	var first: CardView = db._grid.get_child(0) as CardView
	t._check(first != null and first.card.data.power >= 60, "ordenar pelo Poder devia pôr as mais fortes primeiro (34)")
	db._sort = "num"
	for id in ["c016", "c016", "c069", "c099"]:
		db._add_card(id)
	var warns: Array = db.deck_warnings(db._cards)
	t._check(not warns.is_empty() and warns[0] == tr_.call("Faltam %d cartas para jogar (mínimo %d).") % [db.MIN_CARDS - db._cards.size(), db.MIN_CARDS], "o Construtor devia avisar o que falta (40)")
	var added: int = db.complete_deck(4242)
	var nums: Dictionary = db.deck_numbers(db._cards)
	t._check(added > 0 and db._cards.size() == 20 and int(nums["lands"]) >= 3 and int(nums["t3"]) > 0 and int(nums["avg_power"]) > 0, "COMPLETAR devia encher até 20 cartas, com Terrenos, e dar os números (39, 41)")
	db._note = "feitiços + Destreza"
	var txt: String = db.deck_text()
	t._check(txt.contains("×") and txt.contains("feitiços + Destreza") and String(db._deck_dict().get("note", "")) == "feitiços + Destreza", "a lista em texto e a nota deviam sair do baralho (38, 43)")
	db._name = "Teste"
	db._on_save()
	var dup: int = db.duplicate_deck()
	t._check(dup == 2 and CardDB.custom_decks.has("custom_2") and db._slot == 2 and String(CardDB.custom_decks["custom_2"].get("name", "")).contains("Teste"), "DUPLICAR devia copiar para o espaço livre (36)")
	db._load_slot(1)
	var moved: bool = db.move_slot(1)
	t._check(moved and db._slot == 2 and String(CardDB.custom_decks.get("custom_2", {}).get("name", "")) == "Teste", "mudar de lugar devia trocar os espaços (32)")
	t._check(db.copy_campaign_deck("deck01") and db._cards.size() == (CardDB.get_deck("deck01").get("cards", []) as Array).size(), "copiar da campanha devia trazer as cartas do baralho (42)")
	db._open_sample_hand()
	await tree.process_frame
	var sh := SceneRouter.top_overlay()
	var hand: Node = sh.find_child("Hand", true, false) if sh != null else null
	t._check(hand != null and hand.get_child_count() == 6, "a mão de exemplo devia mostrar 6 cartas (35)")
	SceneRouter.close_overlays()
	await tree.process_frame
	db._page = 0
	db._load_slot(2)
	db.queue_free()
	await tree.process_frame
	var db2: Node = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	t.add_child(db2)
	await tree.process_frame
	t._check(db2._slot == 2, "o Construtor devia reabrir no mesmo espaço (22)")
	db2.queue_free()
	await tree.process_frame
	load("res://scenes/builder/DeckBuilder.gd").reset_memory()
	CardDB.custom_decks = keep_decks
	CardDB.save_custom_decks()
	# Coleção: fações, de onde vem, filtros, filtros guardados, OUTROS, conjuntos, Bestiário, Diário.
	load("res://scenes/ui/Collection.gd").reset_memory()
	var col: Node = load("res://scenes/ui/Collection.tscn").instantiate()
	t.add_child(col)
	await tree.process_frame
	var fp: Vector2i = col.faction_progress("deck01")
	t._check(fp.y > 0 and fp.x <= fp.y and col.find_child("FactionProgress", true, false) != null, "a Coleção devia mostrar o progresso por fação (47)")
	var unseen: CardData = null
	for d in CardDB.collectible_cards():
		if not Stats.is_seen("cards", (d as CardData).id):
			unseen = d
			break
	if unseen != null:
		t._check(col.card_source(unseen) != "", "uma carta por descobrir devia dizer onde se ganha (46)")
	col._own_filter = "missing"
	col._refilter()
	var all_missing := true
	for d in col.shown_cards():
		all_missing = all_missing and not Stats.is_seen("cards", (d as CardData).id)
	col._own_filter = ""
	GameState.toggle_favorite("c001")
	col._fav_only = true
	col._refilter()
	var only_fav: bool = col.shown_cards().size() == GameState.favorites().size()
	GameState.toggle_favorite("c001")
	col._fav_only = false
	t._check(all_missing and only_fav, "os filtros «não tenho» e «só favoritas» deviam filtrar (44, 48)")
	var keep_sf = GameState.progress.get("saved_filters")
	col.save_filters("azuis", {"color": "blue", "type": "spell"})
	col.apply_filters(col.saved_filters()[0]["f"])
	await tree.process_frame
	t._check(String(col.get("_color_filter")) == "blue" and String(col.get("_type_filter")) == "spell", "aplicar uns filtros guardados devia repô-los (49)")
	if keep_sf == null:
		GameState.progress.erase("saved_filters")
	else:
		GameState.progress["saved_filters"] = keep_sf
	col._select_tab("others")
	await tree.process_frame
	t._check(col.find_child("Others", true, false) != null and col.find_child("Other_" + String(CardDB.vouchers[0].get("id", "")), true, false) != null, "a Coleção devia ter os Vales, as poções e os patronos (50)")
	col._relic_cat = "sets"
	col._select_tab("relics")
	await tree.process_frame
	var set_ids: Array = col._tile_ids
	var all_in_sets := not set_ids.is_empty()
	for id in set_ids:
		all_in_sets = all_in_sets and not CardDB.relic_set_of(String(id)).is_empty()
	t._check(all_in_sets, "o filtro Conjuntos devia mostrar as relíquias dos conjuntos (51)")
	col._relic_cat = "all"
	var e0: Dictionary = CardDB.enemies[0]
	t._check(col.enemy_passes(e0, GameState.act_of_ante(int(e0.get("min_ante", 1))), "", "") and not col.enemy_passes(e0, 5 if GameState.act_of_ante(int(e0.get("min_ante", 1))) != 5 else 1, "", ""), "o Bestiário devia filtrar por ato (52)")
	col._select_tab("diary")
	await tree.process_frame
	col._filter_diary("zzzz-nada")
	var any_visible := false
	for k in col._diary_buttons:
		any_visible = any_visible or (col._diary_buttons[k] as Button).visible
	t._check(not any_visible, "procurar no Diário devia esconder as páginas que não batem certo (66)")
	col.queue_free()
	load("res://scenes/ui/Collection.gd").reset_memory()
	await tree.process_frame
	# 66: conquistas — procurar e «quase feitas».
	var st: Node = load("res://scenes/ui/StatsScreen.tscn").instantiate()
	t.add_child(st)
	await tree.process_frame
	st.select_tab("achievements")
	await tree.process_frame
	st._ach_search = "zzzz-nada"
	st._filter_medals()
	var medals: Node = st.find_child("Medals", true, false)
	var shown := 0
	if medals != null:
		for m in medals.get_children():
			if (m as Control).visible:
				shown += 1
	t._check(medals != null and shown == 0 and st.find_child("AchSearch", true, false) != null, "procurar nas Conquistas devia filtrar as medalhas (66)")
	st.queue_free()
	await tree.process_frame
	# A run: ver o baralho com filtros (54), histórico (56), mudanças da carta (55), números (57), proteger (64),
	# comparar (53), «A minha run» (58–62), trocar com as relíquias cheias (63).
	GameState.new_run("deck01", 19201)
	GameState.deck[0]["power_bonus"] = 10
	GameState.log_deck("power", String(GameState.deck[0]["id"]), "+10")
	var zv := ZoneViewer.open_deck("Teste")
	await tree.process_frame
	zv._mod_filter = "upgraded"
	zv._apply_filters()
	await tree.process_frame
	var grid_cards := 0
	for g in zv.find_children("*", "CardView", true, false):
		grid_cards += 1
	t._check(zv.find_child("DeckFilters", true, false) != null and zv.find_child("DeckHistory", true, false) != null and grid_cards == 1, "o «Ver baralho» devia filtrar as melhoradas e ter o histórico (54, 56)")
	SceneRouter.close_overlays()
	await tree.process_frame
	var lines := CardZoom.card_history_lines(String(GameState.deck[0]["id"]))
	t._check(lines.size() == 1 and lines[0].contains("10"), "a carta devia mostrar o que ganhou nesta run (55)")
	ZoneViewer.open_deck_history()
	await tree.process_frame
	var hw := SceneRouter.top_overlay()
	t._check(hw != null and hw.find_child("Lines", true, false) != null and hw.find_child("Lines", true, false).get_child_count() >= 1, "o histórico do baralho devia listar as mudanças (56)")
	SceneRouter.close_overlays()
	await tree.process_frame
	var inst := ZoneViewer.deck_instances()[0]
	CardZoom.show_card(inst)
	await tree.process_frame
	var z := SceneRouter.top_overlay() as CardZoom
	if z != null:
		z._add_protect_toggle(inst.entry_index)
		var pb := z.find_child("Protect", true, false) as Button
		if pb != null:
			pb.pressed.emit()
	t._check(bool(GameState.deck[0].get("protected", false)), "🛡 NÃO REMOVER devia proteger a carta (64)")
	SceneRouter.close_overlays()
	await tree.process_frame
	var offer := CardDB.new_instance("c005")
	var cw := CardZoom.show_compare(offer, inst)
	await tree.process_frame
	t._check(cw.find_child("Pair", true, false) != null and cw.find_children("*", "CardView", true, false).size() == 2, "COMPARAR devia pôr as duas cartas lado a lado (53)")
	SceneRouter.close_overlays()
	await tree.process_frame
	var r_ids: Array = []
	for rid in CardDB.relics:
		var rd: Dictionary = CardDB.relics[rid]
		if not bool(rd.get("boss", false)) and not bool(rd.get("blessing", false)) and not bool(rd.get("legendary", false)) and r_ids.size() < GameState.max_relics() + 1:
			r_ids.append(String(rid))
	GameState.relic_ids.assign(r_ids.slice(0, 2))
	GameState.run_log["relic_dmg"] = {r_ids[0]: 1234}
	var ri := RunInfo.open("relics")
	await tree.process_frame
	var row0: Node = ri.find_child("Relic_" + r_ids[0], true, false)
	var facts_ok: bool = row0 != null and String((row0.find_child("Facts", true, false) as Label).text).contains("1")
	ri.move_relic(r_ids[0], 1)
	await tree.process_frame
	var moved_ok: bool = GameState.relic_ids[1] == r_ids[0]
	ri.show_tab("formations")
	await tree.process_frame
	var forms := ri.find_children("Formation_*", "", true, false).size()
	t._check(facts_ok and moved_ok and forms == CardDB.formations.size(), "«A minha run» devia mostrar o dano das relíquias, mudar a ordem e listar as formações (58–62)")
	SceneRouter.close_overlays()
	await tree.process_frame
	# 63: com as relíquias cheias, comprar abre a escolha da que sai.
	GameState.relic_ids.assign(r_ids.slice(0, GameState.max_relics()))
	GameState.relic_locked.clear()
	GameState.gold = 99
	GameState.map_choice = {"stop": "shop"}
	var shop: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	t.add_child(shop)
	await tree.process_frame
	var new_id := ""
	for rid in CardDB.relics:
		var rd2: Dictionary = CardDB.relics[rid]
		if not (String(rid) in GameState.relic_ids) and not bool(rd2.get("boss", false)) and not bool(rd2.get("blessing", false)):
			new_id = String(rid)
			break
	var dummy := Button.new()
	shop.add_child(dummy)
	var out_id: String = GameState.relic_ids[0]
	shop._swap_buy(dummy, new_id, 3, CardDB.relics[new_id], "relic:" + new_id)
	await tree.process_frame
	var sw := SceneRouter.top_overlay()
	var was_swap := sw is RelicSwap
	if was_swap:
		(sw as RelicSwap)._pick(out_id)
	await tree.process_frame
	t._check(was_swap and new_id in GameState.relic_ids and not (out_id in GameState.relic_ids), "com as relíquias cheias, comprar devia trocar pela escolhida (63)")
	# 64: remover uma protegida pede um 2.º sim.
	GameState.deck[0]["protected"] = true
	var n0 := GameState.deck.size()
	shop.removed_this_visit = false
	shop._on_remove()
	await tree.process_frame
	var zv2 := SceneRouter.top_overlay() as ZoneViewer
	if zv2 != null:
		zv2._on_card_pressed(ZoneViewer.deck_instances()[0])
	await tree.process_frame
	var dlg := SceneRouter.top_overlay()
	var asked: bool = dlg is ChoiceDialog and GameState.deck.size() == n0
	if dlg is ChoiceDialog:
		(dlg as ChoiceDialog)._pick("yes")
	await tree.process_frame
	t._check(asked and GameState.deck.size() == n0 - 1, "remover uma carta protegida devia pedir confirmação e depois remover (64)")
	SceneRouter.close_overlays()
	shop.queue_free()
	await tree.process_frame
	GameState.clear_saved_run()
	print("  0.19.0 (2. inventários): ordenar, favoritas, NOVO, Construtor (12 espaços, pesquisa, números, avisos, completar, lista, duplicar, copiar, mudar, mão de exemplo, memória), Coleção (fações, origem, filtros, guardados, OUTROS, conjuntos, Bestiário, Diário), Conquistas, baralho da run, histórico, comparar, A minha run, troca e proteger OK")

# ---------------------------------------------------------------------------
# 3. Loot e economia (67–100)
# ---------------------------------------------------------------------------

## Uma loja nova (fresca) para os testes da secção 3.
static func _fresh_shop(t: Node, stop: String = "shop") -> Node:
	GameState.pending_battle = {}
	GameState.saved_scene = "map"
	GameState.map_choice = {"stop": stop}
	var shop: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	t.add_child(shop)
	return shop

static func _free_shop(t: Node, shop: Node) -> void:
	SceneRouter.close_overlays()
	if is_instance_valid(shop):
		shop.queue_free()
	await t.get_tree().process_frame

static func section3(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	GameState.new_run("deck01", 19301)
	GameState.run_talents = {}
	# 67: probabilidades (somam 100) e a janela da loja.
	var odds := Economy.card_odds(true)
	var tot := 0.0
	for k in odds:
		tot += float(odds[k])
	var rel := Economy.relic_odds()
	var rtot := 0.0
	for k in rel:
		rtot += float(rel[k])
	var shop_script: Script = load("res://scenes/shop/Shop.gd")
	t._check(absf(tot - 100.0) < 0.5 and absf(rtot - 100.0) < 0.5 and String(shop_script.odds_text()).contains("%"), "as probabilidades da loja deviam somar 100 % (67)")
	# 69: juros previstos.
	t._check(Economy.next_interest(23) == 4 and Economy.next_interest(100) == GameState.interest_cap(), "os juros previstos deviam contar 1 por cada 5 (69)")
	# 74: proteção contra azar — 6 lojas sem raras, a seguinte mostra uma.
	GameState.econ["rare_drought"] = Economy.RARE_PITY
	GameState.gold = 99
	GameState.interest_ante = GameState.ante
	var shop := _fresh_shop(t)
	await tree.process_frame
	var has_rare := false
	for c in shop._offer_cards:
		has_rare = has_rare or Economy.is_rare(c)
	t._check(has_rare and Economy.drought() == 0 and (not shop._pity_forced or String(shop._pity_label.text).contains("garantida")), "a proteção contra azar devia garantir uma rara (74)")
	var commons: Array[CardData] = []
	for c in CardDB.shop_pool():
		if String(c.rarity) == "common" and commons.size() < 3:
			commons.append(c)
	var eds: Array[String] = ["", "", ""]
	GameState.econ["rare_drought"] = Economy.RARE_PITY
	var forced := Economy.apply_pity(commons, eds, GameState.rng)
	t._check(forced and Economy.is_rare(commons[2]) and Economy.drought() == 0, "à 7.ª loja sem raras, uma devia ser garantida (74)")
	t._check(String(shop.interest_label.text).contains("Se saíres com"), "a loja devia dizer os juros da próxima loja (69)")
	# 83: regatear muda os preços das ofertas desta visita.
	var tile0: ShopCardTile = shop._tiles[0]
	var base_price := tile0.price
	shop._on_haggle()
	await tree.process_frame
	var tile1: ShopCardTile = shop._tiles[0]
	t._check(shop._haggle != 0 and tile1.price != base_price and shop._haggle_btn.disabled, "regatear devia mudar os preços uma vez (83)")
	# 70: o cesto — duas ofertas, o total, comprar tudo e desfazer tudo.
	var gold0 := GameState.gold
	var deck0 := GameState.deck.size()
	shop._set_basket_mode(true)
	shop._toggle_basket(shop._tiles[0].key)
	shop._toggle_basket(shop._tiles[1].key)
	await tree.process_frame
	var total: int = shop._basket_total()
	t._check(shop._basket_bar.visible and total == shop._tiles[0].price + shop._tiles[1].price and String(shop._basket_label.text).contains(str(total)) \
		and shop._tiles[0].has_node("BasketMark"), "o cesto devia mostrar o total e as marcas (70)")
	shop._buy_basket()
	await tree.process_frame
	t._check(GameState.gold == gold0 - total and GameState.deck.size() == deck0 + 2 and not shop._basket_bar.visible, "COMPRAR TUDO devia comprar o cesto (70)")
	var spent: Dictionary = GameState.run_log.get("spent", {})
	t._check(int(spent.get("card", 0)) == total and not (GameState.run_log.get("bought", []) as Array).is_empty(), "as compras deviam ficar no registo do ouro (72, 73)")
	shop._on_undo()
	await tree.process_frame
	t._check(GameState.gold == gold0 and GameState.deck.size() == deck0, "DESFAZER devia desfazer o cesto todo (70)")
	# 80: com o talento Freguês, o preço antigo aparece riscado.
	GameState.run_talents["shop_discount"] = 1.0
	shop._haggle = 0
	shop._build_offers()
	await tree.process_frame
	var old_l: Node = (shop._tiles[0] as ShopCardTile)._price_row.get_node_or_null("Old")
	t._check(old_l != null and (old_l as Label).visible, "um desconto devia mostrar o preço antigo riscado (80)")
	GameState.run_talents.erase("shop_discount")
	# 79: reservar uma carta — 1 ouro, carimbo, e na loja seguinte aparece à venda.
	var rt: ShopCardTile = null
	for x in shop._tiles:
		if not (x as ShopCardTile).bought:
			rt = x
	var g1 := GameState.gold
	var rid_card := rt.card.data.id
	var rkey := rt.key
	shop._on_tile_reserve(rt)
	await tree.process_frame
	t._check(GameState.gold == g1 - Economy.RESERVE_PRICE and String(Economy.reserved().get("id", "")) == rid_card and shop._reserved_key == rkey, "RESERVAR devia guardar a carta por 1 ouro (79)")
	# 77: vender uma poção.
	GameState.consumables.clear()
	GameState.add_consumable("potion_heal")
	shop._build_owned()
	var g2 := GameState.gold
	shop.sell_item(0)
	t._check(GameState.consumables.is_empty() and GameState.gold == g2 + Economy.consumable_sale_value("potion_heal"), "vender uma poção devia dar metade do preço (77)")
	# 97: valor de venda nas tuas relíquias.
	GameState.relic_ids.assign(["relic_drum"])
	shop._build_owned()
	t._check(shop.owned_box.find_child("SellTag", true, false) != null, "as tuas relíquias deviam mostrar o valor de venda (97)")
	# 78: remover uma carta devolve ouro conforme a raridade.
	var idx := -1
	for i in GameState.deck.size():
		var cd := CardDB.get_card(String(GameState.deck[i]["id"]))
		if cd != null and not cd.is_curse() and not cd.token:
			idx = i
			break
	var inst := CardDB.new_instance(String(GameState.deck[idx]["id"]), GameState.deck[idx])
	inst.entry_index = idx
	var g3 := GameState.gold
	shop.removed_this_visit = false
	shop._remove_now(inst)
	t._check(GameState.gold == g3 - shop._svc(GameState.removal_price()) + Economy.card_sale_value(inst.data), "remover devia devolver 1 a 3 ouro (78)")
	# 76, 81: booster — NOVAS CARTAS (uma vez, a pagar) e NENHUMA SERVE (o próximo custa metade).
	shop.booster_this_visit = false
	shop._booster_renewed = false
	shop._on_booster()
	await tree.process_frame
	var bo := SceneRouter.top_overlay() as BoosterOpen
	var renewed := false
	if bo != null:
		var before_ids: Array = bo._cards.map(func(c): return c.data.id)
		var g4 := GameState.gold
		bo.renew_cards()
		renewed = GameState.gold == g4 - shop._p(Economy.BOOSTER_RENEW_PRICE) and bo._cards.map(func(c): return c.data.id) != before_ids and bo.has_node("Extras")
		bo.skip_all()
	await tree.process_frame
	await tree.process_frame
	t._check(renewed and shop.booster_this_visit and Economy.booster_half() and shop._booster_price() == maxi(1, int(shop._p(5) / 2)), "o booster devia renovar uma vez e, sem escolha, ficar a metade (76, 81)")
	await _free_shop(t, shop)
	# 79 (continuação): na loja do ante seguinte, a carta reservada está à venda.
	GameState.next_ante()
	GameState.interest_ante = GameState.ante
	var shop2 := _fresh_shop(t)
	await tree.process_frame
	t._check(shop2._offer_cards.size() > 0 and shop2._offer_cards[0].id == rid_card and Economy.reserved().is_empty(), "a carta reservada devia estar na loja seguinte (79)")
	await _free_shop(t, shop2)
	# 84: empréstimo do Mercador Cego, pago na loja seguinte.
	var gl := GameState.gold
	t._check(Economy.take_loan() and GameState.gold == gl + Economy.LOAN_AMOUNT and Economy.loan() == Economy.LOAN_DUE and not Economy.take_loan(), "o Mercador Cego devia emprestar uma vez (84)")
	GameState.next_ante()
	var g5 := GameState.gold
	var paid := Economy.pay_loan()
	t._check(paid == Economy.LOAN_DUE and GameState.gold == g5 - Economy.LOAN_DUE and Economy.loan() == 0, "o empréstimo devia pagar-se na loja seguinte (84)")
	# 71: previsão do ouro para a próxima loja.
	GameState.map_phase = "battle"
	var fc := Economy.next_shop_forecast()
	t._check(int(fc["total"]) == int(fc["gold"]) + int(fc["battle"]) - int(fc["loan"]) + int(fc["interest"]) and int(fc["battle"]) > 0, "a previsão do ouro devia somar tudo (71)")
	# 100: risco a troco de ouro.
	GameState.ante = 2
	GameState.map_phase = "battle"
	Economy.set_risk(true)
	var rk := Economy.risk_active()
	var def := CardDB.enemy_def("slime")
	var e_risk := GameState.build_enemy(def, 2, "scout")
	var t_risk := GameState.turns_for_ante(2)
	Economy.clear_risk()
	var e_plain := GameState.build_enemy(def, 2, "scout")
	var t_plain := GameState.turns_for_ante(2)
	var effect_ok := false
	match String(rk.get("id", "")):
		"hp":
			effect_ok = int(e_risk["hp"]) > int(e_plain["hp"])
		"atk":
			effect_ok = int(e_risk["attack"]) == int(e_plain["attack"]) + Economy.RISK_ATTACK
		"turn":
			effect_ok = t_risk == t_plain - 1
	t._check(not rk.is_empty() and int(rk.get("gold", 0)) > 0 and effect_ok, "o risco devia mudar a batalha e pagar ouro (100)")
	# 75: carta depois da batalha (opção da run).
	Economy.set_card_rewards(true)
	Economy.prepare_card_reward()
	var pend := Economy.pending_card_reward()
	var d0 := GameState.deck.size()
	var ok75 := pend.size() == 3 and Economy.take_card_reward(String(pend[0])) and GameState.deck.size() == d0 + 1
	Economy.prepare_card_reward()
	var g6 := GameState.gold
	ok75 = ok75 and Economy.skip_card_reward() == Economy.CARD_SKIP_GOLD and GameState.gold == g6 + Economy.CARD_SKIP_GOLD and Economy.pending_card_reward().is_empty()
	Economy.prepare_card_reward()
	var crp := CardRewardPick.open(func(_id): pass)
	await tree.process_frame
	ok75 = ok75 and crp.find_children("Card_*", "", true, false).size() == 3
	crp.choose("")
	await tree.process_frame
	t._check(ok75, "a carta depois da batalha devia dar 1 de 3 ou ouro (75)")
	Economy.set_card_rewards(false)
	# 82: renovar o Baú de Espólio (uma vez, a pagar).
	GameState.gold = 50
	GameState.prepare_loot()
	var loot0 := GameState.loot_offer.duplicate()
	var ok82 := Economy.renew_loot() and GameState.loot_offer != loot0 and GameState.gold == 50 - GameState.shop_price(Economy.LOOT_RENEW_PRICE) and not Economy.renew_loot()
	t._check(ok82, "o Baú de Espólio devia renovar-se uma vez (82)")
	GameState.loot_offer.clear()
	# 86: o ouro que sobra antes do boss final.
	GameState.ante = GameState.max_ante
	GameState.map_phase = "battle"
	GameState.gold = 21
	var hp0 := GameState.player_max_hp
	var due86 := Economy.final_trade_due()
	Economy.final_trade("hp")
	t._check(due86 and GameState.player_max_hp == hp0 + 10 and GameState.gold == 1 and not Economy.final_trade_due(), "antes do boss final o ouro devia virar vida (86)")
	# 95: trocar uma relíquia (uma vez por run, mesma raridade).
	GameState.ante = 3
	GameState.relic_ids.assign(["relic_drum"])
	var rar := String(CardDB.relics["relic_drum"].get("rarity", ""))
	var nid := Economy.trade_relic("relic_drum")
	t._check(nid != "" and nid in GameState.relic_ids and String(CardDB.relics[nid].get("rarity", "")) == rar and Economy.trade_relic(nid) == "", "trocar uma relíquia devia dar outra da mesma raridade, uma vez (95)")
	# 96: a relíquia da Elite tem a raridade que o mapa mostra.
	GameState.relic_ids.clear()
	var want := Economy.elite_rarity(GameState.ante)
	var got := GameState.grant_elite_relic()
	t._check(got != "" and String(CardDB.relics[got].get("rarity", "")) == want, "a Elite devia dar a relíquia da raridade anunciada (96)")
	# 98: quanto deu cada Vale.
	GameState.vouchers.assign(["v_reward"])
	Economy.credit_voucher("reward_plus", 2)
	Economy.credit_voucher("reward_plus", 2)
	t._check(Economy.voucher_gold("v_reward") == 4 and Economy.voucher_result("v_reward").contains("4"), "o Vale devia contar o ouro que deu (98)")
	# 99: quanto rendeu cada talento.
	var keep_t = GameState.progress.get("talents", {}).duplicate() if GameState.progress.get("talents") is Dictionary else {}
	var keep_tg = GameState.progress.get("talent_gold")
	if not (GameState.progress.get("talents") is Dictionary):
		GameState.progress["talents"] = {}
	GameState.progress["talents"]["t_bounty"] = 1
	GameState.run_talents["boss_gold"] = 3.0
	var tg0 := Economy.talent_gold("t_bounty")
	Economy.credit_talent("boss_gold", 3)
	t._check(Economy.talent_gold("t_bounty") == tg0 + 3, "o talento devia contar o ouro que rendeu (99)")
	GameState.progress["talents"] = keep_t
	if keep_tg == null:
		GameState.progress.erase("talent_gold")
	else:
		GameState.progress["talent_gold"] = keep_tg
	GameState.run_talents = {}
	# 72, 73, 92: o gráfico do ouro, onde gastei e o resumo do ato.
	var rows := Economy.gold_rows()
	var gc := GoldChart.new()
	gc.set_rows(rows)
	var where: String = load("res://scenes/ui/RunOver.gd").where_spent_text(GameState.run_log)
	gc.free()
	t._check(not rows.is_empty() and where.contains("ouro"), "o fim da run devia ter o gráfico do ouro e onde gastei (72, 73)")
	t._check(ActInterlude.act_summary_text(1).contains("ouro"), "o interlúdio devia resumir o ato anterior (92)")
	# 67, 68, 85: Tribunal com a roda, hipóteses nos eventos de sorte, baús com cor.
	for eid in ["node_tribunal", "dragon_hoard", "node_treasure"]:
		GameState.pending_event = eid
		var ev: Node = load("res://scenes/event/Event.tscn").instantiate()
		t.add_child(ev)
		await tree.process_frame
		match eid:
			"node_tribunal":
				t._check(ev.find_child("WheelOdds", true, false) != null, "o Tribunal devia mostrar a hipótese de cada setor (67)")
			"dragon_hoard":
				var all_pct := true
				for b in ev._options_box.get_children():
					var txt := UiKit.wrap_text(b as Button)
					if txt.contains("50") or txt.contains("—"):
						all_pct = all_pct and (txt.contains("%") or not txt.contains("50"))
				t._check(all_pct, "os eventos de sorte deviam dizer a hipótese (68)")
			"node_treasure":
				var icons := 0
				for b in ev._options_box.get_children():
					if (b as Node).has_node("Icon"):
						icons += 1
				t._check(icons == 3, "os baús do Tesouro deviam ter a cor do que têm (85)")
		ev.queue_free()
		await tree.process_frame
	GameState.pending_event = ""
	# 87, 88: a loja da Torre e o Mercador da Corrida.
	GameState.new_tower_run("deck01", 19302)
	GameState.ante = 5
	GameState.tower_prepare_offer()
	GameState.gold = 40
	var ss := Economy.side_shop()
	var cid := String((ss.get("cards", []) as Array)[0])
	var txt87 := Economy.side_buy("card", cid)
	t._check(Economy.side_shop_open() and txt87 != "" and Economy.side_bought("card:" + cid) and GameState.gold == 40 - Economy.side_price("card", cid), "a Torre devia ter loja nos andares de boss (87)")
	var sso := SideShop.open()
	await tree.process_frame
	t._check(sso.find_child("Buy_card_" + cid, true, false) != null and (sso.find_child("Buy_card_" + cid, true, false) as Button).disabled, "a loja da Torre devia mostrar o VENDIDO (87)")
	SceneRouter.close_overlays()
	await tree.process_frame
	GameState.new_rush_run("deck01", 19303)
	var opens: Array = []
	for a in [2, 4, 7]:
		GameState.ante = a
		opens.append(Economy.side_shop_open())
	t._check(opens == [false, true, true] and Economy.side_gold_for_win() == Economy.RUSH_BOSS_GOLD, "o Mercador da Corrida devia abrir de 3 em 3 bosses (88)")
	# 89, 90: prémio da 1.ª vez e fragmentos.
	t._check(Economy.first_win_bonus("deck_que_nao_existe", 3) == Economy.FIRST_WIN_DECK + Economy.FIRST_WIN_STAKE, "a 1.ª vitória devia dar pontos a mais (89)")
	var frag0 := Economy.fragments()
	var locked_back := ""
	for b in (CardDB.cosmetics.get("backs", []) as Array):
		if not (String(b.get("id", "")) in Settings.unlocked_cosmetics("back")):
			locked_back = String(b.get("id", ""))
			break
	var ok90 := true
	if locked_back != "":
		Economy.add_fragments(Economy.cosmetic_price("back"))
		ok90 = Economy.buy_cosmetic("back", locked_back) and locked_back in Settings.unlocked_cosmetics("back") and Economy.fragments() == frag0
		(GameState.progress["unlocks"] as Dictionary).erase("back:" + locked_back)
	GameState.progress["fragments"] = frag0
	GameState.save_progress()
	t._check(ok90, "os fragmentos deviam comprar cosméticos (90)")
	# 91, 93, 94: marco do Infinito com prémio, Bestiário com o que dá e o perigo, tabela de preços.
	var col_script: Script = load("res://scenes/ui/Collection.gd")
	var boss_rit: Dictionary = {}
	for e in CardDB.enemies:
		if e.get("ritual") is Dictionary:
			boss_rit = e
			break
	t._check(String(load("res://scenes/map/Map.gd").milestone_prize(12)).contains("15"), "o mapa devia dizer o prémio do próximo marco (91)")
	t._check(String(col_script.enemy_rewards_text(CardDB.enemy_def("slime"))).contains("ouro") and String(col_script.enemy_danger_text(boss_rit)) != "", "o Bestiário devia dizer o que cada inimigo dá e o perigo (93)")
	t._check(Economy.price_table().contains("Booster") and Economy.price_table().contains("Juros"), "o Como Jogar devia ter a tabela de preços (94)")
	GameState.clear_saved_run()
	print("  0.19.0 (3. economia): probabilidades, juros previstos, cesto, previsão, gráfico do ouro, onde gastei, proteção contra azar, carta depois das batalhas, booster (renovar e saltar), vender poções e cartas, reservar, descontos, Baú, regatear, empréstimo, baús, ouro final, lojas da Torre e da Corrida, 1.ª vitória, fragmentos, marcos, ato, Bestiário, preços, troca de relíquias, Elite, Vales, talentos e risco OK")

# ---------------------------------------------------------------------------
# 4. Clareza visual (101–134)
# ---------------------------------------------------------------------------

static func section4(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	# Cartas soltas: Poder com cor (101), de onde vem (102), versão + (127, 134), Mana de Sangue (113).
	var cv: CardView = load("res://scenes/ui/CardView.tscn").instantiate()
	t.add_child(cv)
	var ci := CardDB.new_instance("c001")
	ci.power_bonus = 10
	cv.setup(ci)
	await tree.process_frame
	t._check(cv.stats_label.get_theme_color("font_color") == CardView.DELTA_UP, "o Poder acima do da carta devia ficar a verde (101)")
	t._check(CardZoom.power_breakdown(ci).contains(TranslationServer.translate("nesta batalha")) and CardZoom.power_breakdown(CardDB.new_instance("c001")) == "", "a carta em grande devia dizer de onde vem o Poder (102)")
	var pi := CardDB.new_instance("c001")
	pi.data = pi.data.plus_version()
	cv.setup(pi)
	var plus_mark := false
	for m in cv.marks():
		if String(m.get("text", "")) == "+":
			plus_mark = true
	t._check(plus_mark, "a carta + devia ter uma marca (134)")
	t._check(pi.data.plus_pairs.is_empty() or cv.text_label.text.contains("[color=#8ff0a4]"), "os números novos da carta + deviam estar pintados (127)")
	cv.setup(CardDB.new_instance("c476"))
	var life_mark := false
	for m in cv.marks():
		if String(m.get("text", "")).ends_with("♥"):
			life_mark = true
	t._check(life_mark, "a Mana de Sangue devia mostrar o custo em vida (113)")
	cv.queue_free()
	# 120: brilho das ilustrações.
	Settings.set_opt("art_brightness", 1.3, false)
	var tint := ArtLib.art_tint()
	Settings.reset_options(["art_brightness"], false)
	t._check(is_equal_approx(tint.r, 1.3) and ArtLib.art_tint() == Color.WHITE, "o brilho das ilustrações devia seguir a opção (120)")
	# 126: a raridade no booster.
	var tag_holder := Control.new()
	tag_holder.size = Vector2(169, 242)
	t.add_child(tag_holder)
	load("res://scenes/shop/BoosterOpen.gd").rarity_tag(tag_holder, "mythic")
	var rtag := tag_holder.get_node_or_null("RarityTag")
	t._check(rtag != null and String((rtag.get_child(0).get_node("Text") as Label).text) == TranslationServer.translate("Mítica").to_upper(), "a carta mítica do booster devia dizer a raridade (126)")
	tag_holder.queue_free()
	# A batalha.
	GameState.new_run("deck01", 19401)
	GameState.clear_saved_run()
	GameState.relic_ids.clear()
	GameState.add_relic("relic_drum")
	GameState.consumables.clear()
	GameState.add_consumable("scroll_fire")
	var st := {"enemy": {"id": "test", "name": "Teste", "hp": 99999, "max_hp": 99999, "attack": 1, "text": "", "abilities": [], "boss": false, "rule": {}},
		"turn": 1, "max_turns": 5, "mana_total": 6, "mana_available": 6, "discards_left": 3, "player_hp": GameState.player_hp,
		"library": [{"id": "c005", "entry": -1}, {"id": "c010", "entry": -1}, {"id": "c003", "entry": -1}],
		"hand": [{"id": "c010", "entry": -1}, {"id": "c002", "entry": -1}, {"id": "c008", "entry": -1}, {"id": "c476", "entry": -1}],
		"graveyard": [], "board": [{"id": "c001", "entry": -1}, {"id": "c003", "entry": -1}, {"id": "c005", "entry": -1}], "exile": []}
	GameState.pending_battle = st
	var b: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	t.add_child(b)
	EventBus.battle_ended.disconnect(b._on_battle_ended)
	await t._wait_until(func(): return not b._animating, 8000)
	await tree.process_frame
	var bm: BattleManager = b.battle
	bm.weak_color = "red"
	b._refresh_all()
	b._refresh_preview()
	await tree.process_frame
	# 103: o valor previsto em cada relíquia.
	var rview: RelicView = b._relic_views.get("relic_drum")
	t._check(rview != null and rview.preview_text().begins_with("+"), "a relíquia devia mostrar o que vai dar no ataque (103)")
	# 105, 106, 107, 129: marcas e brilho.
	var c1 := t._find(bm.board, "c001") as CardInstance
	var c5 := t._find(bm.board, "c005") as CardInstance
	var pact := TranslationServer.translate("Pacto")
	var fm := _mark_has((b._board_views[c1.uid] as CardView), "◆ " + pact) and not _mark_has((b._board_views[c5.uid] as CardView), pact)
	t._check(fm, "as criaturas do Pacto deviam ter a marca da formação (105)")
	var h10 := t._find(bm.deck.hand, "c010") as CardInstance
	var h2 := t._find(bm.deck.hand, "c002") as CardInstance
	t._check(_mark_has(b._hand_views[h10.uid], TranslationServer.translate("◆ fecha %s").split(" %")[0]), "a carta que fecha uma formação devia ter a marca (106)")
	t._check(_mark_has(b._hand_views[h2.uid], TranslationServer.translate("Fraco")) and not _mark_has(b._hand_views[h10.uid], TranslationServer.translate("Fraco")), "as cartas da cor fraca deviam ter a marca (107)")
	var land := t._find(bm.deck.hand, "c008") as CardInstance
	var hand_step := false
	for s in b._s4_cascade.steps:
		if s.source_kind == "hand" and s.source_card == land:
			hand_step = true
	t._check(not hand_step or (b._hand_views[land.uid] as CardView).hand_glow.a > 0.0, "a carta [Na Mão] que conta devia brilhar (129)")
	# 109: quanto falta.
	t._check(String(b._need_text).begins_with(TranslationServer.translate("faltam %s").split(" ")[0]) and String(b.enemy_hp_label.text).contains(b._need_text), "devia dizer quanto falta para LETAL (109)")
	# 108: ouro do Excesso previsto.
	var hp0 := int(bm.enemy.hp)
	bm.enemy["hp"] = 10
	var mx0 := int(bm.enemy.max_hp)
	bm.enemy["max_hp"] = 100
	var og: int = b.overkill_preview(210)
	bm.enemy["hp"] = hp0
	bm.enemy["max_hp"] = mx0
	t._check(og == 4 or (og == 8 and GameState.relic_passive("overkill_double") > 0.0), "o ouro do Excesso devia prever-se antes de atacar (108)")
	# 128: a vida a perder no ATACAR.
	bm.enemy["attack"] = 999
	b._refresh_preview()
	t._check(String(b.end_turn_btn.text).contains("♥"), "o ATACAR devia dizer a vida que vais perder (128)")
	bm.enemy["attack"] = 1
	# 112: estados com contador.
	bm.jailed_uid = c5.uid
	bm.frozen_uid = h2.uid
	bm.frozen_cost = 1
	b._refresh_board()
	b._refresh_hand()
	t._check((b._board_views[c5.uid] as CardView)._tag_text == TranslationServer.translate("PRESA · 1 turno") and (b._hand_views[h2.uid] as CardView)._tag_kind == "frozen", "os estados deviam ter o contador (112)")
	bm.jailed_uid = -1
	bm.frozen_uid = -1
	b._refresh_board()
	# 111: lacaios com a linha até à criatura que travam.
	bm.minions = [2]
	b._refresh_preview()
	var minion_line := false
	for th in b._overlay.threats:
		if bool((th as Dictionary).get("minion", false)):
			minion_line = true
	t._check(minion_line, "o lacaio devia ter uma linha até à criatura que trava (111)")
	bm.minions = []
	# 110: o escudo na barra.
	bm.enemy["shield_pct"] = 10
	b._refresh_preview()
	t._check(bm.shield_amount() > 0 and b._shield_bar != null, "o escudo devia ir para a barra de vida (110)")
	bm.enemy["shield_pct"] = 0
	# 114: a carta nova brilha.
	var extra := CardDB.new_instance("c005")
	extra.zone = CardInstance.Zone.HAND
	bm.deck.hand.append(extra)
	b._refresh_hand()
	await tree.process_frame
	t._check(b._hand_views.has(extra.uid) and (b._hand_views[extra.uid] as CardView).flash_a > 0.0, "a carta que entrou na mão devia brilhar (114)")
	# 115: encantamentos separados dos feitiços do turno.
	var en := CardDB.new_instance("c331")
	en.zone = CardInstance.Zone.ENCHANT
	bm.enchantments.append(en)
	bm.spells_this_turn.append(CardDB.new_instance("c004"))
	b._refresh_enchantments()
	b._refresh_spells()
	var sep: Control = b._ench_box.get_node_or_null("EnchSep")
	t._check(sep != null and sep.visible, "os encantamentos deviam ficar separados dos feitiços do turno (115)")
	bm.enchantments.erase(en)
	bm.spells_this_turn.clear()
	b._refresh_enchantments()
	b._refresh_spells()
	# 116: a fila do inimigo numerada (com o ritual que acaba neste turno).
	bm.ritual = {"turns": 1, "action": "heal", "value": 1, "text": "Teste"}
	b._intent_sig = ""
	b._refresh_preview()
	var numbered: bool = b._intent_row.get_child_count() >= 2
	for chip in b._intent_row.get_children():
		if (chip as PanelContainer).get_child(0).get_node_or_null("Order") == null:
			numbered = false
	t._check(numbered, "a fila do inimigo devia estar numerada pela ordem (116)")
	bm.ritual = {}
	b._intent_sig = ""
	b._refresh_preview()
	# 117: o turno do inimigo em 3 segundos.
	b._enemy_log_from = b._history.size()
	b._log("Teste ataca!")
	b._show_enemy_recap()
	t._check(b._enemy_recap.size() == 1 and String(b._enemy_recap[0]) == "Teste ataca!", "devia rever o que o inimigo fez (117)")
	# 118: foco na cascata.
	Settings.set_opt("focus_cascade", true, false)
	var v1: Control = b._board_views[c1.uid]
	var v5: Control = b._board_views[c5.uid]
	b._focus_step(v1)
	var dimmed := v5.modulate != Color.WHITE and v1.modulate == Color.WHITE
	b._focus_clear()
	Settings.reset_options(["focus_cascade"], false)
	t._check(dimmed and v5.modulate == Color.WHITE, "o foco devia escurecer tudo menos quem dispara (118)")
	# 119: fundo calmo.
	Settings.set_opt("calm_bg", true, false)
	b._setup_backdrop()
	var calm: bool = b._backdrop == null or b._backdrop.modulate == b.CALM_BG
	Settings.reset_options(["calm_bg"], false)
	b._setup_backdrop()
	t._check(calm, "o fundo calmo devia escurecer o fundo da batalha (119)")
	# 121: os botões desligados dizem porquê.
	b._undo_stack.clear()
	b._refresh_zone_buttons()
	t._check(UiKit.why_text(b.undo_btn) == TranslationServer.translate("Nada para desfazer neste turno."), "o DESFAZER desligado devia dizer porquê (121)")
	# 130: o clima a agir.
	bm.climate = "aether_tide"
	b._climate_turn_notices(1)
	await tree.process_frame
	t._check(b._climate_told.has("aether1") and b._alive(b._climate_notice_node), "o clima devia avisar quando mexe nos custos (130)")
	bm.climate = ""
	# 131, 132: contadores das mecânicas.
	bm.crown = true
	b._refresh_info_row()
	t._check(TranslationServer.translate("Coroa") in b.mech_entries() and b._mech_chip.visible, "os contadores das mecânicas deviam estar num só sítio (131)")
	bm.crown = false
	b._mech_deck_tags = {"delirium": true, "domain": true, "_done": true}
	var det: Array = b.mech_details()
	var has_del := false
	var has_dom := false
	for l in det:
		has_del = has_del or String(l).begins_with(TranslationServer.translate("Delírio"))
		has_dom = has_dom or String(l).begins_with(TranslationServer.translate("Domínio"))
	t._check(has_del and has_dom, "o Delírio e o Domínio deviam dizer o que falta (132)")
	b._mech_deck_tags = {}
	# 133: a poção que dá letal.
	t._check(b.item_gives_lethal("scroll_fire", b._s4_cascade, 5, 0) and not b.item_gives_lethal("scroll_fire", b._s4_cascade, 99999, 0), "o pergaminho que acaba a batalha devia brilhar (133)")
	# 104: +Mult e ×Mult com cor e tamanho próprios.
	var n0: int = b.get_child_count()
	b._pop(b.formation_label, "×2 Mult", b.COLOR_MULT_X, "mult_mul")
	var pop := b.get_child(b.get_child_count() - 1) as Label
	t._check(b.get_child_count() == n0 + 1 and pop != null and pop.get_theme_font_size("font_size") == 33, "o ×Mult devia voar maior e com cor própria (104)")
	Settings.warn_mana = false
	b.queue_free()
	await tree.process_frame
	# Shop: o porquê dos botões (121).
	GameState.new_run("deck01", 19402)
	GameState.map_options(1)
	GameState.choose_stop("shop")
	GameState.gold = 0
	var shop: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	t.add_child(shop)
	await tree.process_frame
	await tree.process_frame
	t._check(UiKit.why_text(shop.booster_btn).begins_with(TranslationServer.translate("Faltam %d de ouro.").split(" ")[0]), "o booster sem ouro devia dizer quanto falta (121)")
	shop.queue_free()
	await tree.process_frame
	# Mapa: NOVO (122), caminho até ao boss (123), legenda (124), quem vem a seguir (125).
	GameState.new_run("deck01", 19403)
	var had: Variant = GameState.progress.get("seen_nodes")
	GameState.progress["seen_nodes"] = []
	var new_ok := not GameState.node_seen("vault") and GameState.node_seen("shop")
	GameState.progress["seen_nodes"] = ["vault"]
	new_ok = new_ok and GameState.node_seen("vault")
	if had == null:
		GameState.progress.erase("seen_nodes")
	else:
		GameState.progress["seen_nodes"] = had
	t._check(new_ok, "os nós nunca visitados deviam ter a marca NOVO (122)")
	GameState.ante = 2
	GameState.map_phase = "battle"
	var map_script: Script = load("res://scenes/map/Map.gd")
	var path: Dictionary = map_script.boss_path()
	t._check(int(path.get("battles", -1)) == 2 and String(path.get("boss_id", "")) != "" and String(path.get("text", "")).contains("2"), "o mapa devia dizer quantas batalhas faltam para o boss (123)")
	var boss_id := String(path["boss_id"])
	t._check(String(map_script.node_legend("elite", 2)).contains(TranslationServer.translate("Risco: %s.").split(":")[0]), "o toque longo devia mostrar o que o nó dá e o risco (124)")
	var planned := GameState.planned_enemy(2)
	GameState.choose_battle("scout")
	var picked := GameState.pick_enemy(2)
	t._check(planned != "" and String(picked.get("id", "")) == planned and GameState.planned_enemy(2) == planned, "o inimigo que o mapa mostra devia ser o da batalha (125)")
	GameState.ante = 4
	GameState.map_phase = "battle"
	GameState.choose_battle("boss")
	var boss := GameState.pick_enemy(4)
	t._check(String(boss.get("id", "")) == boss_id, "o boss que o mapa mostrou devia ser o da batalha (123)")
	t._check(String(map_script.next_enemy_text(boss_id)) != "", "o mapa devia ter o texto do próximo inimigo (125)")
	GameState.clear_saved_run()
	print("  0.19.0 (4. clareza visual): Poder com cor e de onde vem, relíquias previstas, +Mult e ×Mult, formações, cor fraca, Excesso, quanto falta, escudo na barra, lacaios, estados, Mana de Sangue, carta nova, encantamentos, fila e recapitulação do inimigo, foco, fundo calmo, brilho, botões que explicam, NOVO, caminho do boss, legenda, a seguir, raridade, cartas +, vida a perder, [Na Mão], clima, contadores e poções letais OK")

static func _mark_has(v: CardView, txt: String) -> bool:
	if v == null:
		return false
	for m in v.marks():
		if String(m.get("text", "")).contains(txt):
			return true
	return false

# ---------------------------------------------------------------------------
# 5. Legibilidade e HUD (135–168): verificadores de texto (166, 167, 168)
# ---------------------------------------------------------------------------

## 166: textos visíveis com letra abaixo de `min_px` (fora das cartas, que encolhem o texto para caber).
static func scan_min_font(root: Node, min_px: int = 11) -> Array[String]:
	var out: Array[String] = []
	_scan(root, func(c: Control):
		var key := "normal_font_size" if c is RichTextLabel else "font_size"
		var t := _text_of(c)
		if t.strip_edges() == "":
			return
		var fs := c.get_theme_font_size(key)
		if fs > 0 and fs < min_px:
			out.append("%s (%d px): %s" % [c.get_path(), fs, t.substr(0, 30)]), out)
	return out

## 167: textos com pouco contraste com o fundo (o painel mais próximo com fundo opaco): rácio < `min_ratio`.
static func scan_contrast(root: Node, min_ratio: float = 3.0) -> Array[String]:
	var out: Array[String] = []
	_scan(root, func(c: Control):
		if not (c is Label) or _text_of(c).strip_edges() == "":
			return
		var fg := c.get_theme_color("font_color")
		var bg := _bg_behind(c)
		if bg.a <= 0.0 or fg.a < 0.5:
			return
		var r := contrast_ratio(fg, bg)
		if r < min_ratio:
			out.append("%s (%.1f): %s" % [c.get_path(), r, _text_of(c).substr(0, 30)]), out)
	return out

## 168: textos cortados (botões e etiquetas que cortam ou põem «…» e não cabem na caixa).
static func scan_overflow(root: Node) -> Array[String]:
	var out: Array[String] = []
	_scan(root, func(c: Control):
		var t := _text_of(c)
		if t.strip_edges() == "" or c.size.x < 8.0 or c is RichTextLabel:
			return
		var clips := false
		if c is Label:
			var l := c as Label
			clips = (l.clip_text or l.text_overrun_behavior != TextServer.OVERRUN_NO_TRIMMING) and l.autowrap_mode == TextServer.AUTOWRAP_OFF
		elif c is Button:
			clips = (c as Button).clip_text or (c as Button).text_overrun_behavior != TextServer.OVERRUN_NO_TRIMMING
		if not clips or c.has_meta("ellipsis_ok"):
			return
		var font := c.get_theme_font("font")
		var fs := c.get_theme_font_size("font_size")
		var pad := 0.0
		if c is Button:
			var st := c.get_theme_stylebox("normal")
			pad = st.get_margin(SIDE_LEFT) + st.get_margin(SIDE_RIGHT) if st != null else 0.0
		var w := font.get_string_size(t, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x + pad
		if w > c.size.x + 2.0:
			out.append("%s (%d > %d): %s" % [c.get_path(), int(w), int(c.size.x), t.substr(0, 30)]), out)
	return out

static func contrast_ratio(a: Color, b: Color) -> float:
	var la := _lum(a)
	var lb := _lum(b)
	return (maxf(la, lb) + 0.05) / (minf(la, lb) + 0.05)

static func _lum(c: Color) -> float:
	var f := func(v: float) -> float: return v / 12.92 if v <= 0.03928 else pow((v + 0.055) / 1.055, 2.4)
	return 0.2126 * float(f.call(c.r)) + 0.7152 * float(f.call(c.g)) + 0.0722 * float(f.call(c.b))

static func _bg_behind(c: Control) -> Color:
	var p: Node = c.get_parent()
	var depth := 0
	while p != null and depth < 12:
		if p is PanelContainer or p is Panel or p is Button:
			var st: StyleBox = (p as Control).get_theme_stylebox("panel" if not (p is Button) else "normal")
			if st is StyleBoxFlat and (st as StyleBoxFlat).draw_center and (st as StyleBoxFlat).bg_color.a >= 0.75:
				return (st as StyleBoxFlat).bg_color
		p = p.get_parent()
		depth += 1
	return Color(0, 0, 0, 0)

static func _text_of(c: Control) -> String:
	if c is Label:
		return (c as Label).text
	if c is Button:
		return (c as Button).text
	if c is RichTextLabel:
		return (c as RichTextLabel).get_parsed_text()
	return ""

## Percorre os controlos visíveis (fora das cartas, das relíquias e das miniaturas desenhadas).
static func _scan(n: Node, fn: Callable, _out = null) -> void:
	if n is CanvasItem and not (n as CanvasItem).is_visible_in_tree():
		return
	if n is CardView or n is CardFace or n is RelicView or n is CardMarks:
		return
	if n is Control and (n is Label or n is Button or n is RichTextLabel):
		fn.call(n)
	for ch in n.get_children():
		_scan(ch, fn)

static func section5(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	# 135, 149, 150: texto das cartas maior, cartas claras e lembretes das palavras-chave.
	var cv: CardView = load("res://scenes/ui/CardView.tscn").instantiate()
	t.add_child(cv)
	var fly_id := ""
	for id in CardDB.cards:
		var d: CardData = CardDB.cards[id]
		if d.is_creature() and d.has_keyword("flying") and not d.token:
			fly_id = String(id)
			break
	Settings.set_opt("kw_reminders", true, false)
	Settings.set_opt("light_cards", true, false)
	cv.setup(CardDB.new_instance(fly_id))
	await tree.process_frame
	var reminder := cv.text_label.text.contains("(") and cv.text_label.text.contains(TranslationServer.translate("Voar"))
	var light := cv.text_label.get_theme_color("default_color") == CardView.LIGHT_BODY
	Settings.reset_options(["kw_reminders", "light_cards"], false)
	cv.setup(CardDB.new_instance("c001"))
	await tree.process_frame
	t._check(Settings.large_text or cv._text_fs == roundi(11.0 * cv._u), "o texto das cartas devia ser maior por omissão (135)")
	t._check(light, "as cartas claras deviam ter o texto escuro (149)")
	t._check(reminder, "o lembrete da palavra-chave devia estar na carta (150)")
	cv.queue_free()
	# 137, 138, 161: avisos com histórico, mais tempo e as conquistas no canto.
	SceneRouter.toast("Aviso de teste 190", 1.0, false)
	t._check(String(SceneRouter.toast_log.back().get("text", "")) == "Aviso de teste 190", "o sino devia guardar os avisos (137)")
	var nl := NoticeLog.open()
	await tree.process_frame
	t._check(nl.lines() >= 1, "a janela dos avisos devia mostrá-los (137)")
	nl.queue_free()
	Settings.set_opt("toast_time", "longer", false)
	var tl := Settings.toast_seconds(2.8)
	Settings.set_opt("toast_time", "tap", false)
	var tt := Settings.toast_seconds(2.8)
	Settings.reset_options(["toast_time"], false)
	t._check(is_equal_approx(tl, 8.0) and tt == 0.0 and is_equal_approx(Settings.toast_seconds(2.8), 2.8), "o tempo dos avisos devia seguir a opção (138)")
	SceneRouter._toast_queue.clear()   # (os outros avisos dos testes ocupam os lugares)
	for i in SceneRouter._toast_slots.size():
		var old = SceneRouter._toast_slots[i]
		if old != null and is_instance_valid(old):
			(old as Node).queue_free()
		SceneRouter._toast_slots[i] = null
	SceneRouter.toast("Conquista de teste", 1.0, false, {}, true)
	await tree.process_frame
	await tree.process_frame
	await tree.process_frame
	var corner := false
	for p in SceneRouter._toast_slots:
		if p != null and is_instance_valid(p) and bool(p.get_meta("corner", false)):
			corner = (p as Control).global_position.x > 400.0
	t._check(corner, "o aviso da conquista devia ir para o canto (161)")
	for p2 in SceneRouter._toast_slots:
		if p2 != null and is_instance_valid(p2):
			(p2 as Node).queue_free()
	SceneRouter._toast_queue.clear()
	# 136: o texto dos menus maior.
	Settings.set_opt("menu_text", 1.3, false)
	var nl2 := NoticeLog.open()
	await tree.process_frame
	await tree.process_frame
	var big_txt := false
	for l in nl2.find_children("*", "Label", true, false):
		if (l as Label).text == "Aviso de teste 190":
			big_txt = (l as Label).get_theme_font_size("font_size") >= 22
	nl2.queue_free()
	Settings.reset_options(["menu_text"], false)
	t._check(big_txt, "o texto das janelas devia crescer com o «Texto dos menus» (136)")
	# 140: o relógio.
	Settings.set_opt("clock", true, false)
	SceneRouter.refresh_clock()
	var clock := SceneRouter.clock_text()
	Settings.reset_options(["clock"], false)
	SceneRouter.refresh_clock()
	t._check(clock.length() == 5 and clock[2] == ":" and SceneRouter.clock_text() == "", "o relógio devia aparecer no canto (140)")
	# 146, 163, 165: números, máquina de escrever, menos maiúsculas.
	Settings.set_opt("numbers", "short", false)
	var sn := Settings.short_numbers(false)
	Settings.set_opt("numbers", "full", false)
	var fn := Settings.short_numbers(true)
	Settings.reset_options(["numbers"], false)
	t._check(sn and not fn and Settings.short_numbers(true) and not Settings.short_numbers(false), "os números deviam seguir a opção (146)")
	Settings.set_opt("typewriter", "instant", false)
	var tw0 := Settings.typewriter_cps()
	Settings.reset_options(["typewriter"], false)
	t._check(tw0 == 0.0 and Settings.typewriter_cps() > 0.0, "a máquina de escrever devia seguir a opção (163)")
	t._check(UiKit.calm_caps("NÃO LEVAR NADA DESTA VEZ") == "Não levar nada desta vez" and UiKit.calm_caps("ATACAR") == "ATACAR" and UiKit.calm_caps("Comprar · 3") == "Comprar · 3", "os textos compridos deviam ficar em letra normal (165)")
	# 143, 144: o toque longo e o modo explicar.
	var tip_btn := UiKit.button("X", 48, 16)
	tip_btn.tooltip_text = "Explicação de teste"
	tip_btn.position = Vector2(600, 300)
	tip_btn.size = Vector2(80, 48)
	var holder := Control.new()
	holder.set_anchors_preset(Control.PRESET_FULL_RECT)
	t.add_child(holder)
	holder.add_child(tip_btn)
	await tree.process_frame
	var tip := SceneRouter.tip_at(Vector2(640, 324))
	t._check(String(tip.get("text", "")) == "Explicação de teste", "o toque longo devia encontrar a explicação do ícone (143)")
	SceneRouter.set_explain_mode(true)
	var press := InputEventMouseButton.new()
	press.button_index = MOUSE_BUTTON_LEFT
	press.pressed = true
	press.position = Vector2(640, 324)
	var swallowed := SceneRouter._explain_input(press)
	press.pressed = false
	var swallowed_up := SceneRouter._explain_input(press)
	await tree.process_frame
	var balloon_ok := SceneRouter._alive(SceneRouter._balloon)
	SceneRouter.set_explain_mode(false)
	t._check(swallowed and swallowed_up and balloon_ok and not SceneRouter.explain_mode, "no modo explicar, o toque devia explicar em vez de agir (144)")
	holder.queue_free()
	if SceneRouter._alive(SceneRouter._balloon):
		SceneRouter._balloon.queue_free()
	# 145, 151, 164: o Como Jogar na página certa, com ícones e NOVO.
	var h := HowToPlay.open_at("LOJA")
	await tree.process_frame
	var icons := 0
	for sct in h.sections:
		if (sct.panel as Control).find_child("Icon", true, false) != null:
			icons += 1
	var seen0 := int(GameState.progress.get("howto_seen_code", 0))
	GameState.progress["howto_seen_code"] = 0
	var news := h.new_titles()
	GameState.progress["howto_seen_code"] = seen0
	t._check(h.index_of("LOJA") >= 0 and h.index_of("A CASCATA") >= 0, "a ajuda devia abrir na página do ecrã (145)")
	t._check(icons == h.sections.size(), "cada regra devia ter a sua imagem (151)")
	t._check("MARCAS E PREVISÕES" in news, "as regras novas deviam ter NOVO (164)")
	h.queue_free()
	await tree.process_frame
	# 152: glossário com um exemplo.
	var gi := -1
	for i in CardDB.glossary.size():
		if String(CardDB.glossary[i].get("term", "")) == "Voar":
			gi = i
	t._check(gi >= 0 and CardZoom.glossary_example(gi) != "", "o glossário devia ter uma carta de exemplo (152)")
	# 148: A+ na carta em grande (o botão grava a opção: começa e acaba desligada).
	Settings.set_opt("zoom_text", false, false)
	CardZoom.show_card(CardDB.new_instance("c001"))
	await tree.process_frame
	var z := SceneRouter.top_overlay()
	var tsb: Button = null
	if z != null:
		tsb = z.find_child("TextSize", true, false) as Button
	var found_a := tsb != null
	if found_a:
		tsb.pressed.emit()
	await tree.process_frame
	var zoom_on := bool(Settings.opt("zoom_text"))
	Settings.set_opt("zoom_text", false)
	SceneRouter.close_overlays()
	t._check(found_a and zoom_on, "o A+ devia aumentar a letra da carta em grande (148)")
	# 154: os títulos com o caminho.
	var col: Node = load("res://scenes/ui/Collection.tscn").instantiate()
	t.add_child(col)
	await tree.process_frame
	col._select_tab("relics")
	var path_txt := String(col._path_title.text)
	col.queue_free()
	t._check(path_txt.contains("›") and path_txt.contains(UiKit.sentence(TranslationServer.translate("RELÍQUIAS"))), "a Coleção devia mostrar o caminho no título (154)")
	# A batalha: 139, 141, 142, 147, 153, 155–160, 162.
	GameState.new_run("deck01", 19501)
	GameState.clear_saved_run()
	GameState.relic_ids.clear()
	GameState.add_relic("relic_drum")
	GameState.set_contract("formations")
	var st := {"enemy": {"id": "test", "name": "Teste", "hp": 99999, "max_hp": 99999, "attack": 1, "text": "", "abilities": [], "boss": false, "rule": {}},
		"turn": 1, "max_turns": 5, "mana_total": 6, "mana_available": 6, "discards_left": 3, "player_hp": GameState.player_hp, "climate": "tailwind",
		"library": [{"id": "c005", "entry": -1}], "hand": [{"id": "c010", "entry": -1}, {"id": "c002", "entry": -1}],
		"graveyard": [], "board": [{"id": "c001", "entry": -1}, {"id": "c003", "entry": -1}], "exile": []}
	GameState.pending_battle = st
	Settings.set_opt("icon_labels", true, false)
	Settings.set_opt("hud_climate", false, false)
	var b: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	t.add_child(b)
	EventBus.battle_ended.disconnect(b._on_battle_ended)
	await t._wait_until(func(): return not b._animating, 8000)
	await tree.process_frame
	var bm: BattleManager = b.battle
	t._check(b.icon_captions() >= 3, "os ícones da batalha deviam ter o nome por baixo (142)")
	t._check(b._climate_chip == null, "sem o clima na barra de cima, o chip do clima não devia aparecer (141)")
	Settings.reset_options(["icon_labels", "hud_climate"], false)
	var fv = b.total_label.get_theme_font("font")
	t._check(fv is FontVariation and not (fv as FontVariation).opentype_features.is_empty(), "o total devia usar algarismos da mesma largura (147)")
	t._check(String(b._relic_count.text) == "1/%d" % GameState.max_relics(), "a prateleira devia contar as relíquias (153)")
	b._refresh_all()
	var con_lab: Label = b._contract_chip.get_meta("label") if b._alive(b._contract_chip) else null
	t._check(con_lab != null and con_lab.text.contains(TranslationServer.translate("%d de %d formações").split(" ")[1]), "o contrato devia contar durante a batalha (158)")
	bm.rule = {"gold_tax": 1}
	b._refresh_all()
	t._check(String(b.enemy_text.text).contains(str(GameState.gold)), "a regra do boss devia dizer o efeito em ti (157)")
	bm.rule = {}
	# 155, 156: histórico com filtros e o turno.
	b._log("Linha minha")
	b._enemy_log_from = b._history.size()
	b._enemy_turn_logging = true
	b._log("Linha dele")
	b._enemy_turn_logging = false
	b._log("Ganhaste 3 de ouro.")
	var only_enemy := String(b.history_text("enemy"))
	var only_gold := String(b.history_text("gold"))
	t._check(only_enemy.contains("Linha dele") and not only_enemy.contains("Linha minha") and only_gold.contains("ouro") and not only_gold.contains("Linha"), "o histórico devia ter filtros (155)")
	t._check(String(b._history.back()).begins_with("T1"), "cada linha do histórico devia ter o turno (156)")
	b._enemy_log_from = -1
	# 159, 160: números da cascata maiores e com fundo.
	Settings.set_opt("cascade_big", true, false)
	b._pop(b.formation_label, "+5 Poder", b.COLOR_POWER, "power_add")
	var pop := b.get_child(b.get_child_count() - 1) as Label
	Settings.reset_options(["cascade_big"], false)
	t._check(pop != null and pop.get_theme_font_size("font_size") > 26 and pop.get_theme_stylebox("normal") is StyleBoxFlat, "os números a voar deviam ser maiores e ter fundo (159, 160)")
	# 139: as falas dos bosses até tocares.
	Settings.set_opt("boss_wait", true, false)
	b._say("Fala de teste", 0.1)
	await t.get_tree().create_timer(0.5).timeout
	var stays: bool = b._alive(b._bubble) and b._bubble.mouse_filter == Control.MOUSE_FILTER_STOP
	Settings.reset_options(["boss_wait"], false)
	t._check(stays, "a fala do boss devia ficar até lhe tocares (139)")
	if b._alive(b._bubble):
		b._bubble.queue_free()
	# 162: recolher o painel do inimigo.
	b.toggle_enemy_panel()
	var folded: bool = b.enemy_collapsed() and not b.enemy_text.visible
	b.toggle_enemy_panel()
	t._check(folded and not b.enemy_collapsed() and b.enemy_text.visible, "o painel do inimigo devia recolher e voltar a abrir (162)")
	# 145: a ajuda do ecrã da batalha.
	t._check(SceneRouter.help_title() == "A CASCATA" or tree.current_scene == null or tree.current_scene.name != "Battle", "a ajuda da batalha devia ir para A CASCATA (145)")
	# 166, 167, 168: letra mínima, contraste e textos cortados na batalha.
	var small := scan_min_font(b)
	var low := scan_contrast(b)
	t._check(small.is_empty(), "letra abaixo de 11 px na batalha (166): %s" % ", ".join(PackedStringArray(small.slice(0, 4))))
	t._check(low.is_empty(), "pouco contraste na batalha (167): %s" % ", ".join(PackedStringArray(low.slice(0, 4))))
	b.queue_free()
	await tree.process_frame
	GameState.contract = {}
	# 166, 167, 168 nos ecrãs dos menus (também em inglês).
	var bad: Array[String] = []
	var old_lang := Settings.language
	for lang in ["pt", "en"]:
		Settings.language = lang
		Settings.apply()
		GameState.new_run("deck01", 19502)
		GameState.map_options(1)
		for path in ["res://scenes/main/Main.tscn", "res://scenes/map/Map.tscn", "res://scenes/shop/Shop.tscn", "res://scenes/ui/Collection.tscn"]:
			if path.contains("shop"):
				GameState.choose_stop("shop")
			var n: Node = load(path).instantiate()
			t.add_child(n)
			await t.get_tree().create_timer(0.6).timeout
			for x in scan_min_font(n) + scan_contrast(n):
				bad.append(lang + " " + x)
			if lang == "en":
				for x in scan_overflow(n):
					bad.append(lang + " " + x)
			n.queue_free()
			SceneRouter.close_overlays()
			await tree.process_frame
	Settings.language = old_lang
	Settings.apply()
	t._check(bad.is_empty(), "textos pequenos, com pouco contraste ou cortados em inglês (166–168): %s" % ", ".join(PackedStringArray(bad.slice(0, 5))))
	GameState.clear_saved_run()
	print("  0.19.0 (5. legibilidade): texto das cartas, texto dos menus, sino e tempo dos avisos, falas dos bosses, relógio, barra de cima, nomes dos ícones, toque longo e modo explicar, ajuda do ecrã, números, algarismos, A+, cartas claras, lembretes, Como Jogar com imagens e NOVO, glossário com exemplos, contador de relíquias, caminho, histórico com filtros e turno, regras e contrato a contar, cascata maior e com fundo, conquistas no canto, painel recolhível, máquina de escrever, menos maiúsculas e os verificadores de letra, contraste e texto cortado OK")

# ---------------------------------------------------------------------------
# 6. Respeito pelo tempo e pela sessão (169–202)
# ---------------------------------------------------------------------------

static func section6(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	var keep_hist = GameState.progress.get("history", []).duplicate(true) if GameState.progress.get("history") is Array else []
	var keep_tm = GameState.progress.get("time_by_mode", {}).duplicate() if GameState.progress.get("time_by_mode") is Dictionary else {}
	# 169, 171: a duração das runs (média por modo, na pausa e no histórico).
	t._check(GameState.fmt_duration(45) == "45 s" and GameState.fmt_duration(720) == "12 min" and GameState.fmt_duration(3900) == "1 h 05 min", "a duração devia escrever-se «45 s», «12 min», «1 h 05 min» (169)")
	GameState.progress["history"] = [{"mode": "quick", "deck_id": "deck01", "deck": "Centelha", "secs": 1200, "ante": 4, "won": true, "t": 1760000000.0}, {"mode": "quick", "deck_id": "deck01", "deck": "Centelha", "secs": 1800, "ante": 4, "won": false, "t": 1760000000.0}]
	t._check(GameState.avg_run_secs("quick") == 1500, "a média das Runs Rápidas devia ser 25 min (169)")
	GameState.new_quick_run("deck01", 1, 19601)
	GameState.ante = 2
	t._check(GameState.run_time_left_text().contains("min"), "a pausa devia dizer quanto falta para acabar a run (169)")
	var ss: Node = load("res://scenes/ui/StatsScreen.tscn").instantiate()
	var row: Control = ss._history_row(GameState.run_history()[0], 0)
	var row_txt := _all_text(row)
	row.free()
	t._check(row_txt.contains("20 min") and row_txt.contains("2025-10-09"), "cada run do histórico devia ter a duração e o dia (171)")
	# 170: o tempo de jogo por modo e por baralho.
	GameState.progress["time_by_mode"] = {"quick": 600.0, "campaign": 1800.0}
	var tm: Array = ss.time_by_mode()
	t._check(tm.size() == 2 and String(tm[0][0]) == "campaign", "as Estatísticas deviam ordenar o tempo por modo (170)")
	ss.free()
	# 176, 177, 201: Batalha avulsa, Run de 2 antes e Só batalhas.
	GameState.new_short_run("skirmish", "deck01", 1, 19602)
	var sk := GameState.max_ante == 1 and not GameState.is_boss_ante(1)
	GameState.new_short_run("mini", "deck01", 1, 19603)
	var mi := GameState.max_ante == 2 and GameState.is_boss_ante(2) and not GameState.is_boss_ante(1)
	GameState.new_short_run("brawl", "deck01", 1, 19604)
	t._check(sk and mi and GameState.max_ante == 4 and GameState.mode == "brawl", "os modos curtos deviam ter 1, 2 e 4 antes (176, 177, 201)")
	# 179: as últimas escolhas ficam de uma sessão para a outra.
	var keep_lc = GameState.progress.get("last_choice", {}).duplicate(true) if GameState.progress.get("last_choice") is Dictionary else {}
	GameState.remember_choice("quick", "deck03", 2, "classic", 0)
	var lc := GameState.last_choice("quick")
	t._check(String(lc.get("deck", "")) == "deck03" and int(lc.get("stake", 0)) == 2 and String(GameState.last_choice("_last").get("kind", "")) == "quick", "as últimas escolhas deviam ficar guardadas (179)")
	# 178, 193, 194 e os modos curtos no menu.
	var m: Node = load("res://scenes/main/Main.tscn").instantiate()
	t.add_child(m)
	await tree.process_frame
	var qp := m.find_child("QuickPlay", true, false) as Button
	t._check(qp != null and String(m.quick_play_text()).contains(TranslationServer.translate(String(CardDB.get_deck("deck03").get("name", "")))), "o JOGAR devia começar com o último baralho (178)")
	t._check(m.find_child("Skirmish", true, false) != null and m.find_child("MiniRun", true, false) != null and m.find_child("Brawl", true, false) != null, "o NOVO JOGO devia ter os modos curtos (176, 177, 201)")
	var qdesc := m.find_child("QuickRun", true, false)
	t._check(qdesc != null and _all_text(qdesc).contains("≈ 25 min"), "o NOVO JOGO devia dizer a duração média da Run Rápida (169)")
	t._check(m.find_child("RandomPuzzle", true, false) != null, "os modos deviam ter o ENIGMA AO ACASO (193)")
	m.queue_free()
	await tree.process_frame
	GameState.progress["last_choice"] = keep_lc
	var pz := GameState.random_unsolved_puzzle()
	t._check(pz == "" or not Stats.is_puzzle_solved(pz), "o enigma ao acaso devia ser um por resolver (193)")
	var near := GameState.closest_achievement()
	t._check(near.is_empty() or (int(near["have"]) < int(near["need"]) and int(near["have"]) > 0), "a conquista mais perto devia estar a meio (194)")
	# 175: onde ficaste.
	GameState.new_quick_run("deck01", 1, 19605)
	GameState.map_options(1)
	var lines := SessionWindows.resume_lines()
	t._check(lines.size() >= 3 and lines.back().begins_with("A seguir"), "o resumo de onde ficaste devia ter o baralho, a vida e o que vem a seguir (175)")
	var went := [false]
	var rs := SessionWindows.open_resume(func(): went[0] = true)
	await tree.process_frame
	(rs.find_child("GoOn", true, false) as Button).pressed.emit()
	t._check(went[0], "o CONTINUAR do resumo devia seguir para a run (175)")
	SceneRouter.close_overlays()
	await tree.process_frame
	# 196: as regras ao voltar, depois de um mês.
	var keep_lp = GameState.progress.get("last_played", 0)
	GameState.progress["last_played"] = int(Time.get_unix_time_from_system()) - 40 * 86400
	var rr := SessionWindows.maybe_rules_refresher()
	t._check(rr != null and rr.name == "RulesRefresher", "depois de um mês sem jogar, devia aparecer o resumo das regras (196)")
	SceneRouter.close_overlays()
	await tree.process_frame
	t._check(SessionWindows.maybe_rules_refresher() == null, "o resumo das regras não devia voltar no dia seguinte (196)")
	GameState.progress["last_played"] = keep_lp
	# 172, 195: o lembrete de pausa e o limite.
	var br := SceneRouter.break_reminder("Teste")
	await tree.process_frame
	t._check(br.find_child("SaveQuit", true, false) != null, "o lembrete de pausa devia ter GUARDAR E SAIR (172)")
	SceneRouter.close_overlays()
	await tree.process_frame
	var keep_runs := SceneRouter.session_runs
	Settings.set_opt("self_limit", "runs1", false)
	SceneRouter.session_runs = 1
	SceneRouter._limit_shown = false
	SceneRouter._check_session()
	await tree.process_frame
	var limited := SceneRouter.has_overlay()
	Settings.reset_options(["self_limit"], false)
	SceneRouter.session_runs = keep_runs
	SceneRouter.close_overlays()
	await tree.process_frame
	t._check(limited, "ao chegar ao limite que escolheste, devia aparecer o aviso (195)")
	# 180: o turno do inimigo mais rápido.
	Settings.set_opt("enemy_speed", "instant", false)
	var inst := Settings.enemy_speed_factor()
	Settings.reset_options(["enemy_speed"], false)
	t._check(inst < 0.2 and is_equal_approx(Settings.enemy_speed_factor(), 1.0), "o turno do inimigo devia ter uma velocidade própria (180)")
	# 191: os avisos guardados para o fim da batalha.
	var fired := [0]
	SceneRouter._deferred.append(func(): fired[0] += 1)
	SceneRouter.flush_deferred_notices()
	t._check(fired[0] == 1 and SceneRouter._deferred.is_empty(), "os avisos guardados deviam sair no fim da batalha (191)")
	# 198: interlúdios só da primeira vez.
	var keep_seen = GameState.progress.get("interludes_seen", []).duplicate() if GameState.progress.get("interludes_seen") is Array else []
	GameState.progress["interludes_seen"] = ["act_1"]
	GameState.interlude_key = ""
	Settings.set_opt("interludes", "first", false)
	var il := ActInterlude.open_if_new()
	Settings.reset_options(["interludes"], false)
	t._check(il == null, "com «só da primeira vez», um interlúdio já visto não devia abrir (198)")
	GameState.progress["interludes_seen"] = keep_seen
	SceneRouter.close_overlays()
	# 200: treinar esta batalha (do PORQUE PERDI?).
	GameState.new_quick_run("deck01", 1, 19606)
	var foe := ""
	for e in CardDB.enemies:
		if not bool(e.get("boss", false)) and not bool(e.get("saga", false)):
			foe = String(e.get("id", ""))
			break
	GameState.start_enemy_training(foe, 3)
	t._check(GameState.puzzle_id == "training_boss" and String(GameState.training_boss_enemy().get("id", "")) == foe and GameState.ante == 3, "o treino devia ser contra o mesmo inimigo, no mesmo ante (200)")
	GameState.puzzle_id = ""
	GameState.training = {}
	# A batalha: 181, 184, 188, 189, 199.
	GameState.new_quick_run("deck01", 1, 19607)
	GameState.clear_saved_run()
	GameState.map_options(1)
	GameState.remember_node_choice()
	var st := {"enemy": {"id": "test", "name": "Teste", "hp": 99999, "max_hp": 99999, "attack": 1, "text": "", "abilities": [], "boss": false, "rule": {}},
		"turn": 1, "max_turns": 5, "mana_total": 6, "mana_available": 6, "discards_left": 3, "player_hp": GameState.player_hp,
		"library": [{"id": "c005", "entry": -1}], "hand": [{"id": "c010", "entry": -1}, {"id": "c002", "entry": -1}],
		"graveyard": [], "board": [], "exile": []}
	GameState.pending_battle = st
	var b: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	t.add_child(b)
	EventBus.battle_ended.disconnect(b._on_battle_ended)
	await t._wait_until(func(): return not b._animating, 8000)
	await tree.process_frame
	var bm: BattleManager = b.battle
	# 189: numa cascata enorme, só os passos que mais contam.
	var big := Cascade.new()
	for i in 60:
		var step := Cascade.Step.new()
		step.action = "power_add"
		step.value = float(i)
		step.mult_after = 1.0
		big.add(step)
	var keep: Dictionary = b.summary_steps(big)
	t._check(keep.size() <= 15 and keep.has(59) and keep.has(58), "uma cascata com 60 passos devia mostrar só os maiores e o último (189)")
	t._check(b.summary_steps(Cascade.new()).is_empty(), "uma cascata pequena devia mostrar-se toda (189)")
	# 181: a apresentação só da 1.ª vez.
	b._intro_seen_before()   # (só os bosses passam por aqui: a 1.ª vez fica registada)
	Settings.set_opt("intro_once", true, false)
	var seen_twice: bool = b._intro_seen_before()
	Settings.reset_options(["intro_once"], false)
	t._check(seen_twice, "com a opção, a apresentação de um inimigo já visto devia saltar-se (181)")
	# 188: as recompensas num aviso.
	var rtxt: String = b.rewards_toast_text("VITÓRIA", {"gold_before": 10, "gold_after": 22}, [["relic", "relic_drum"]])
	t._check(rtxt.contains("+12") and rtxt.contains(TranslationServer.translate(String(CardDB.relics["relic_drum"].get("name", "")))), "o aviso das recompensas devia ter o ouro e a relíquia (188)")
	# 184: sem jogadas, ataca sozinho (e um toque cancela).
	bm.mana_available = 0
	var none: bool = b._no_plays_left()
	b._auto_end_id = 5
	b.cancel_auto_end()
	t._check(none and b._auto_end_id == 6, "sem mana, devia contar como sem jogadas, e um toque cancela o ataque automático (184)")
	# 199: voltar ao mapa e escolher outro nó.
	t._check(b.can_undo_node(), "no início da batalha devia dar para voltar ao mapa (199)")
	b.queue_free()
	await tree.process_frame
	t._check(GameState.undo_node_choice() and GameState.map_phase == "battle" and not GameState.can_undo_node(), "desfazer o nó devia voltar à escolha da batalha (199)")
	# 173: bom sítio para parar, uma vez por ante.
	GameState.new_short_run("mini", "deck01", 1, 19608)
	GameState.ante = 2
	GameState.map_phase = "stop"
	var mp: Node = load("res://scenes/map/Map.tscn").instantiate()
	t.add_child(mp)
	await tree.process_frame
	mp._safe_stop_note()
	t._check(bool(GameState.run_log.get("safe_2", false)), "depois do boss, o mapa devia dizer que é um bom sítio para parar (173)")
	mp.queue_free()
	await tree.process_frame
	# 190: o cronómetro e o recorde por modo.
	Settings.set_opt("speedrun", true, false)
	SceneRouter._refresh_speedrun(true)
	var shown := SceneRouter.speedrun_text() != ""
	Settings.reset_options(["speedrun"], false)
	SceneRouter._refresh_speedrun(false)
	t._check(shown and SceneRouter.speedrun_text() == "", "o cronómetro devia aparecer só com a opção (190)")
	# 202: «Experimentar já» nas Novidades.
	t._check(NewsOverlay.new().has_method("_build"), "as Novidades deviam existir (202)")
	GameState.progress["history"] = keep_hist
	GameState.progress["time_by_mode"] = keep_tm
	GameState.save_progress()
	Settings.save_settings()
	GameState.clear_saved_run()
	SceneRouter.close_overlays()
	print("  0.19.0 (6. tempo e sessão): duração dos modos e quanto falta, tempo de jogo, data e duração das runs, lembrete de pausa, bom sítio para parar, onde ficaste, modos curtos, JOGAR, últimas escolhas, turno do inimigo, apresentação só da 1.ª vez, ataque automático, cascatas resumidas, recompensas num aviso, avisos guardados, interlúdios, enigma ao acaso, conquista mais perto, limite, regras ao voltar, desfazer o nó, treinar esta batalha e cronómetro OK")

static func _all_text(n: Node) -> String:
	var out := ""
	if n is Label:
		out += (n as Label).text + " "
	elif n is Button:
		out += (n as Button).text + " "
	for c in n.get_children():
		out += _all_text(c)
	return out

# ---------------------------------------------------------------------------
# 7. Gestão térmica (203–224; o 220 e o 221 ficam para depois)
# ---------------------------------------------------------------------------

static func section7(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	# 203, 211: o acelerómetro só com cartas holográficas à vista; o brilho só na carta em grande.
	var rare_id := ""
	for id in CardDB.cards:
		var d: CardData = CardDB.cards[id]
		if d.rarity == "rare" and not d.token:
			rare_id = String(id)
			break
	var before := CardView.foil_live
	var cv: CardView = load("res://scenes/ui/CardView.tscn").instantiate()
	t.add_child(cv)
	cv.setup(CardDB.new_instance(rare_id))
	await tree.process_frame
	var counted := CardView.foil_live == before + 1
	Settings.set_opt("foil_zoom_only", true, false)
	cv.setup(CardDB.new_instance(rare_id))
	await tree.process_frame
	var zoom_only := cv._foil == null and CardView.foil_live == before
	Settings.reset_options(["foil_zoom_only"], false)
	cv.setup(CardDB.new_instance(rare_id))
	cv.queue_free()
	await tree.process_frame
	t._check(counted and CardView.foil_live == before, "as cartas holográficas no ecrã deviam contar-se (203)")
	t._check(zoom_only, "com a opção, as raras pequenas deviam ficar sem brilho (211)")
	t._check(not (CardView.foil_live == 0 and not SceneRouter.has_overlay()) or not SceneRouter.tilt_needed(), "sem cartas holográficas, o acelerómetro não devia ler-se (203)")
	# 204: os sensores que o jogo não usa.
	t._check(not bool(ProjectSettings.get_setting("input_devices/sensors/enable_gyroscope", true)) and not bool(ProjectSettings.get_setting("input_devices/sensors/enable_magnetometer", true)) \
		and not bool(ProjectSettings.get_setting("input_devices/sensors/enable_gravity", true)), "o giroscópio, a gravidade e o magnetómetro deviam estar desligados (204)")
	# 205, 206, 223: FPS da sessão, aquecimento e o relatório.
	var th := Thermal.new()
	t.add_child(th)
	var keep_key := SceneRouter._scene_key
	SceneRouter._scene_key = "battle"
	var keep_perf := Settings.performance_mode
	Settings.performance_mode = false
	th.add_window(58.0, 60.0)
	for i in Thermal.SLOW_WINDOWS:
		th.add_window(24.0, 60.0)
	var auto_on := Settings.performance_mode and bool(Settings.opt("auto_perf_on"))
	t._check(th.windows == 1 + Thermal.SLOW_WINDOWS and is_equal_approx(th.fps_min, 24.0) and th.avg_fps() < 40.0, "os FPS deviam medir-se a sessão toda (205)")
	t._check(auto_on and th.auto_done, "quedas longas deviam ligar o modo de desempenho sozinho (206)")
	t._check(th.report_line().contains("mínimo 24") and th.report_line().contains("automático"), "o relatório devia ter os FPS da sessão (223)")
	Settings.performance_mode = keep_perf
	Settings.set_opt("auto_perf_on", false, false)
	Settings.apply()
	# 214: escurecer o ecrã parado (o 1.º toque só acende).
	th.set_dimmed(true)
	var was_dim := th.dimmed()
	var woke := th.wake()
	t._check(was_dim and woke and not th.dimmed(), "o ecrã escurecido devia acender ao 1.º toque (214)")
	th.queue_free()
	SceneRouter._scene_key = keep_key
	t._check(String(ErrorReport.build()).contains("FPS"), "o relatório de erros devia dizer os FPS (223)")
	# 207, 208, 224: a decoração para com uma janela aberta e sem foco.
	SceneRouter.app_focused = false
	var unfocused := SceneRouter.decor_still()
	SceneRouter.app_focused = true
	var dlg := ChoiceDialog.open("Teste", "Teste", [["OK", null, true]])
	await tree.process_frame
	var behind := SceneRouter.decor_still()
	SceneRouter.close_overlays()
	await tree.process_frame
	t._check(unfocused and behind, "a decoração devia parar sem foco e por trás das janelas (208, 224)")
	# 210: janelas sem desfocar no modo de desempenho.
	Settings.performance_mode = true
	var no_blur := not UiKit.blur_ok()
	Settings.performance_mode = keep_perf
	t._check(no_blur, "no modo de desempenho, as janelas não deviam desfocar (210)")
	# 212: o teto comum de partículas.
	FxBudget.clear()
	var a := Node.new()
	var b := Node.new()
	var ga := FxBudget.grant(a, 200)
	var gb := FxBudget.grant(b, 100)
	t._check(ga == 200 and gb == FxBudget.CAP - 200 and FxBudget.used() == FxBudget.CAP, "as partículas deviam ter um teto comum (212)")
	FxBudget.release(a)
	t._check(FxBudget.grant(b, 100) == 100, "ao acabar um efeito, as partículas deviam voltar ao teto (212)")
	a.free()
	b.free()
	FxBudget.clear()
	# 216: o tema preto.
	Settings.set_opt("theme", "black", false)
	var mb := MenuBackdrop.new()
	t.add_child(mb)
	await tree.process_frame
	var black := Settings.black_theme() and mb._rune_a == null
	mb.queue_free()
	Settings.reset_options(["theme"], false)
	t._check(black and not Settings.black_theme(), "o tema preto devia tirar o fundo e as runas (216)")
	# 217: a música parada a sério com o volume a 0.
	var keep_mv := Settings.music_volume
	Settings.music_volume = 0.0
	var silent := not Music.audible()
	Settings.music_volume = keep_mv
	t._check(silent and (Music.audible() or keep_mv <= 0.001 or bool(Settings.opt("muted"))), "com a música a 0, nada devia tocar (217)")
	# 218: as ilustrações pedidas ficam numa fila (uma de cada vez).
	var items: Array = []
	for id in ["c001", "c002", "c003", "c004"]:
		items.append(["card", id])
	ArtLib.preload_async(items)
	var queued := ArtLib.queued()
	ArtLib.preload_async([])
	t._check(queued >= 2 or not Settings.show_art or ArtLib.total() == 0, "as ilustrações deviam carregar uma de cada vez (218)")
	t._check(ArtLib.queued() == 0, "a fila das ilustrações devia esvaziar quando já não são precisas (218)")
	# 219: a poupança extra (20 FPS fora da batalha).
	Settings.set_opt("saver_extra", true, false)
	var saver := SceneRouter.saver_applies("map") and not SceneRouter.saver_applies("battle")
	Settings.reset_options(["saver_extra"], false)
	t._check(saver and SceneRouter.SAVER_FPS == 20 and not SceneRouter.saver_applies("map"), "a poupança extra devia pôr 20 FPS fora da batalha (219)")
	# 209, 213: chamas paradas no modo de desempenho e cascatas gigantes mais leves.
	GameState.new_run("deck01", 19701)
	GameState.clear_saved_run()
	var st := {"enemy": {"id": "test", "name": "Teste", "hp": 99999, "max_hp": 99999, "attack": 1, "text": "", "abilities": [], "boss": false, "rule": {}},
		"turn": 1, "max_turns": 5, "mana_total": 6, "mana_available": 6, "discards_left": 3, "player_hp": GameState.player_hp,
		"library": [{"id": "c005", "entry": -1}], "hand": [{"id": "c010", "entry": -1}], "graveyard": [], "board": [], "exile": []}
	GameState.pending_battle = st
	var bt: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	t.add_child(bt)
	EventBus.battle_ended.disconnect(bt._on_battle_ended)
	await t._wait_until(func(): return not bt._animating, 8000)
	Settings.performance_mode = true
	await tree.process_frame
	await tree.process_frame
	var still: bool = bt._fire_still and bt._fire_rects.size() == 2 and bt._fire_rects[0].material == null and bt._fire_rects[0].get_child_count() == 1
	Settings.performance_mode = keep_perf
	await tree.process_frame
	await tree.process_frame
	t._check(still and (keep_perf or bt._fire_rects[0].material is ShaderMaterial), "no modo de desempenho, as chamas deviam ser uma imagem fixa (209)")
	var big := Cascade.new()
	for i in 30:
		big.add(Cascade.Step.new())
	t._check(bt.cascade_is_heavy(big) and not bt.cascade_is_heavy(Cascade.new()), "as cascatas gigantes deviam levar menos efeitos (213)")
	bt.queue_free()
	await tree.process_frame
	GameState.clear_saved_run()
	Settings.save_settings()
	print("  0.19.0 (7. calor): acelerómetro só quando é preciso, sensores desligados, FPS da sessão, modo de desempenho automático, decoração parada (janelas, sem foco, menu a descansar), chamas paradas, janelas sem desfocar, brilho só na carta em grande, teto de partículas, cascatas mais leves, ecrã escurecido, tema preto, música parada a 0, ilustrações com calma, poupança extra e FPS no relatório OK")

# ---------------------------------------------------------------------------
# 8. Desempenho e armazenamento (230–253; 225–229 e 254 estão na base; o 237 fica para depois)
# ---------------------------------------------------------------------------

static func section8(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	# 230: fecho inesperado — o cadeado da sessão.
	Storage.lock(true)
	Storage.session_start()
	var crash := Storage.crashed_before
	Storage.lock(false)
	Storage.session_start()
	var clean := not Storage.crashed_before
	Storage.crashed_before = true
	var rep_crash := ErrorReport.build().contains("fechou-se de repente")
	Storage.crashed_before = false
	t._check(crash and clean and FileAccess.file_exists(Storage.SESSION_LOCK) and rep_crash, "um fecho inesperado devia notar-se no arranque seguinte (230)")
	# 231, 232: o progresso num ficheiro.
	var code := Settings.export_code()
	var fpath := Storage.export_progress_file(code)
	var found := false
	for f in Storage.find_progress_files():
		if String(f[0]) == fpath:
			found = true
	t._check(fpath != "" and found and Storage.read_progress_file(fpath) == code, "o progresso devia ir para um ficheiro e voltar a ler-se dele (231, 232)")
	if fpath != "":
		DirAccess.remove_absolute(fpath)
	# 233: espaço ocupado.
	var usage := Storage.usage()
	t._check(usage.size() == 6 and int(usage[0][2]) > 0 and Storage.fmt_bytes(1536) == "2 KB", "as Configurações deviam dizer o espaço ocupado (233)")
	# 234, 235: as imagens partilhadas em JPG e só as 10 últimas.
	var img := Image.create(64, 64, false, Image.FORMAT_RGB8)
	img.fill(Color(0.3, 0.2, 0.5))
	DirAccess.make_dir_recursive_absolute(RunShare.DIR)
	for i in 12:
		img.save_jpg(RunShare.DIR + "zero-sum-20990101-0000%02d.jpg" % i)
	var shot := RunShare.save(img)
	var left := 0
	var d := DirAccess.open(RunShare.DIR)
	for f in d.get_files():
		if f.begins_with("zero-sum-"):
			left += 1
	t._check(shot.ends_with(".jpg") and left == RunShare.KEEP_SHARED, "as partilhas deviam ser JPG e ficar só as 10 últimas (234, 235)")
	Storage.clear_dir(RunShare.DIR)
	# 236, 248: miniaturas feitas no telemóvel (e só as recentes em memória).
	var made := ThumbCache.make_now("c001")
	ThumbCache._tex.clear()
	ThumbCache._order.clear()
	var th := ThumbCache.texture("c001")
	t._check(made and th != null and th.get_size() == Vector2(ThumbCache.SIZE) and not ThumbCache.needed(), "as miniaturas deviam poder fazer-se no telemóvel (236)")
	ThumbCache.clear()
	ArtLib._blur.clear()
	ArtLib._blur_order.clear()
	for i in ArtLib.BLUR_KEEP + 6:
		ArtLib.remember_blur("test:%d" % i, null)
	var capped := ArtLib._blur.size() <= ArtLib.BLUR_KEEP
	ArtLib.trim()
	t._check(capped and ArtLib._blur.size() <= ArtLib.TRIM_BLUR, "as ilustrações feitas no jogo deviam ficar só as recentes (248)")
	ArtLib._blur.clear()
	ArtLib._blur_order.clear()
	# 238, 239, 240: som, letra e ilustrações mais leves.
	var sfx := load("res://assets/audio/sfx/back.wav") as AudioStreamWAV
	t._check(sfx != null and sfx.format == AudioStreamWAV.FORMAT_QOA, "os efeitos curtos deviam ir comprimidos (238)")
	var inter := load("res://assets/fonts/Inter-Medium.otf") as FontFile
	var inter_kb := FileAccess.get_file_as_bytes("res://assets/fonts/Inter-Medium.otf").size() / 1024
	t._check(inter != null and inter.has_char("ç".unicode_at(0)) and inter.has_char("€".unicode_at(0)) and inter.has_char("★".unicode_at(0)) and inter_kb < 300, "o Inter devia ter só as letras usadas, sem perder nenhuma (239)")
	t._check(FileAccess.get_file_as_string("res://assets/art/cards/c001.webp.import").contains("lossy_quality=0.72"), "as ilustrações das cartas deviam ir mais leves (240)")
	# 242: o tamanho da atualização.
	var rel := AppUpdate.parse_release({"body": "code=99\nNotas", "name": "Zero-Sum 9.9.9", "assets": [{"name": "ZeroSum_v9.9.9.apk", "size": 54525952,
		"browser_download_url": AppUpdate.APK_PREFIX + "v9.9.9/ZeroSum_v9.9.9.apk"}]})
	t._check(AppUpdate.size_text(rel) == "52 MB", "o botão da atualização devia dizer o tamanho (242)")
	# 243, 246: o arranque medido.
	ErrorReport.boot["menu_ms"] = 1234
	t._check(ErrorReport.boot.has("cards_ms") and ErrorReport.boot_line().contains("1234 ms") and ErrorReport.build().contains("Arranque"), "o relatório devia ter o tempo de arranque (246)")
	# 244: as traduções já juntas (guardadas prontas).
	var hits0 := DataCache.hits
	TranslationServer.remove_translation(Settings._en)
	Settings._load_translations()
	var cached_tr := DataCache.hits > hits0 and Settings._en is OptimizedTranslation
	t._check(cached_tr and Settings._en.get_message("JOGAR") == "PLAY", "as traduções deviam ler-se prontas, sem as juntar de novo (244)")
	# 245: os dados num formato mais rápido.
	var hits1 := DataCache.hits
	var a: Array = CardDB._load_json(CardDB.ENEMIES_PATH)
	var b: Array = CardDB._load_json(CardDB.ENEMIES_PATH)
	var plain = JSON.parse_string(FileAccess.get_file_as_string(ContentUpdate.resolve(CardDB.ENEMIES_PATH)))
	t._check(DataCache.hits > hits1 and a.size() == b.size() and b.size() == (plain as Array).size() and str(b[0]) == str(plain[0]), "os dados deviam ler-se da cache, iguais ao JSON (245)")
	# 247: a roda de espera.
	SceneRouter.show_spinner(true)
	var spin := SceneRouter.spinner_visible()
	SceneRouter.show_spinner(false)
	t._check(spin and not SceneRouter.spinner_visible(), "devia haver uma roda de espera para os ecrãs lentos (247)")
	# 250: o modo programador (5 toques na versão).
	var m: Node = load("res://scenes/main/Main.tscn").instantiate()
	t.add_child(m)
	await tree.process_frame
	SceneRouter.close_overlays()
	var was_dev := bool(Settings.opt("dev_mode"))
	for i in 5:
		m.dev_tap()
	var dev_on := bool(Settings.opt("dev_mode")) != was_dev and SceneRouter.dev_text().contains("FPS")
	Settings.set_opt("dev_mode", was_dev, false)
	SceneRouter.refresh_dev_overlay()
	m.queue_free()
	await tree.process_frame
	t._check(dev_on, "5 toques na versão deviam ligar o modo programador (250)")
	# 251: o teste de desempenho do emulador tem a batalha cheia.
	var pst := PerfBench.battle_state()
	t._check((pst["hand"] as Array).size() == 6 and (pst["board"] as Array).size() == 5 and not PerfBench.requested(), "o teste de desempenho devia montar uma batalha cheia (251)")
	# 252: abrir a Coleção, o Bestiário e a Galeria várias vezes e a memória voltar ao normal.
	GameState.new_run("deck01", 19801)
	var base_objs := 0
	for round in 3:
		var col: Node = load("res://scenes/ui/Collection.tscn").instantiate()
		t.add_child(col)
		await tree.process_frame
		for tab in ["cards", "enemies", "gallery"]:
			col._select_tab(tab)
			await tree.process_frame
		col.queue_free()
		await tree.process_frame
		await tree.process_frame
		var objs := int(Performance.get_monitor(Performance.OBJECT_COUNT))
		if round == 0:
			base_objs = objs
		elif round == 2:
			t._check(objs <= base_objs + 400, "a memória devia voltar ao normal depois da Coleção (252): %d → %d objetos" % [base_objs, objs])
	GameState.clear_saved_run()
	print("  0.19.0 (8. desempenho e armazenamento): fecho inesperado, progresso num ficheiro, espaço ocupado, partilhas JPG e só as 10 últimas, miniaturas no telemóvel, som, letra e ilustrações mais leves, tamanho da atualização, arranque medido, traduções e dados prontos, roda de espera, memória das ilustrações, modo programador, teste de desempenho e teste de memória OK")

# ---------------------------------------------------------------------------
# 9. Acessibilidade e personalização global (255–300; o 261 fica para depois)
# ---------------------------------------------------------------------------

static func section9(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	# 255, 257: ler a carta (com a descrição da ilustração).
	var c1 := CardDB.get_card("c001")
	var spoken := Speech.card_text(c1)
	Speech.say("[b]Olá[/b] ×2")
	t._check(spoken.contains(c1.display_name()) and (spoken.contains("Ilustração de") or not ArtLib.has("card", "c001")) and Speech.last == "Olá vezes 2", "a carta devia ler-se em voz alta, com a ilustração (255, 257)")
	t._check(ArtLib.describe("portrait", "bandit").contains("Retrato") or not ArtLib.has("portrait", "bandit"), "as ilustrações deviam ter uma descrição (257)")
	# 0.19.1: a música baixa enquanto a voz lê e volta quando a voz se cala (sem voz nos testes, volta logo).
	Music.duck_for_speech(40)
	await tree.create_timer(Music.DUCK_IN + 0.15).timeout
	var low: bool = Music.ducked() and Music.duck_db() < -15.0
	await tree.create_timer(Music.DUCK_MIN + Music.DUCK_QUIET + Music.DUCK_OUT + 0.4).timeout
	t._check(low and not Music.ducked() and Music.duck_db() > -0.5, "a música devia baixar enquanto a voz lê e voltar no fim (0.19.1)")
	Settings.set_opt("tts_duck", false, false)
	Music.duck_for_speech(40)
	t._check(not Music.ducked(), "com a opção desligada, a música não devia baixar (0.19.1)")
	Settings.reset_options(["tts_duck"], false)
	# 256: modo leitor — o 1.º toque lê, o 2.º carrega.
	Settings.set_opt("reader", true, false)
	var rb := UiKit.button("TESTE LEITOR", 50, 18)
	rb.position = Vector2(300, 300)
	rb.size = Vector2(200, 50)
	t.add_child(rb)
	await tree.process_frame
	var ev := InputEventMouseButton.new()
	ev.button_index = MOUSE_BUTTON_LEFT
	ev.pressed = true
	ev.position = rb.get_global_rect().get_center()
	var first: bool = SceneRouter._reader_input(ev)
	var said := Speech.last
	var up := ev.duplicate() as InputEventMouseButton
	up.pressed = false
	SceneRouter._reader_input(up)
	var second: bool = SceneRouter._reader_input(ev)
	Settings.reset_options(["reader"], false)
	rb.queue_free()
	t._check(first and said.to_lower().contains("teste leitor") and not second, "no modo leitor, o 1.º toque devia ler e o 2.º carregar (256)")
	# 258, 259: letra para dislexia e mais espaço.
	Settings.set_opt("dyslexic", true, false)
	Settings.set_opt("spacing", true, false)
	Settings.apply()
	var rf := Settings.root_font()
	var dys := rf is FontVariation and (rf as FontVariation).base_font != null and String((rf as FontVariation).base_font.resource_path).contains("OpenDyslexic")
	Settings.reset_options(["dyslexic", "spacing"], false)
	Settings.apply()
	t._check(dys and (tree.root.theme == null or Settings.high_contrast), "a letra para dislexia e o espaço deviam ir para todo o texto (258, 259)")
	# 262: filtro de daltonismo.
	Settings.set_opt("colorblind_filter", "deutan", false)
	SceneRouter.refresh_cvd()
	var cvd := SceneRouter.cvd_mode()
	Settings.reset_options(["colorblind_filter"], false)
	SceneRouter.refresh_cvd()
	t._check(cvd == 2 and SceneRouter.cvd_mode() == 0, "o filtro de daltonismo devia corrigir o ecrã todo (262)")
	# 263, 264: o símbolo da cor na moldura e os padrões nos estados.
	var keep_cb := Settings.colorblind
	Settings.colorblind = true
	var cv: CardView = load("res://scenes/ui/CardView.tscn").instantiate()
	t.add_child(cv)
	cv.setup(CardDB.new_instance("c001"))
	cv.set_frozen(true, 1)
	await tree.process_frame
	var marks := cv.find_child("CbMarks", true, false)
	var pattern: bool = cv._mirror_tag != null and not cv._mirror_tag.draw.get_connections().is_empty()
	cv.queue_free()
	Settings.colorblind = keep_cb
	t._check(marks != null and marks.find_child("Watermark", true, false) != null, "no modo daltónico, o símbolo da cor devia estar na moldura e no fundo (263)")
	t._check(pattern, "os estados deviam ter um padrão além da cor (264)")
	# 265, 266: formas no mapa e letras nas medalhas.
	var all_shapes := true
	for k in load("res://scenes/map/Map.gd").NODE_INFO:
		if not load("res://scenes/map/Map.gd").NODE_SHAPES.has(k):
			all_shapes = false
	t._check(all_shapes, "cada tipo de nó devia ter uma forma (265)")
	t._check(CardView.medal_letter(1) == "B" and CardView.medal_letter(2) == "P" and CardView.medal_letter(3) == "O", "as medalhas deviam ter letra (266)")
	# 267, 268: legendas dos sons e avisos para os olhos e a mão.
	Settings.set_opt("captions", true, false)
	Settings.set_opt("cues", true, false)
	var cues0 := SceneRouter.cues_shown
	Sfx.named("boss")
	Sfx.named("relic")
	await tree.process_frame
	var caps := SceneRouter.captions_shown()
	Settings.reset_options(["captions", "cues"], false)
	t._check(caps >= 1 and SceneRouter.cues_shown >= cues0 + 1, "os sons deviam ter legendas e avisos que se veem (267, 268)")
	# 271: silenciar num toque.
	var m0 := Settings.is_muted()
	Settings.toggle_mute()
	var m1 := Settings.is_muted()
	Settings.toggle_mute()
	t._check(m1 != m0 and Settings.is_muted() == m0, "devia dar para silenciar num toque (271)")
	# 273, 274: música do ataque à parte e a jukebox.
	Settings.set_opt("menu_track", "act1", false)
	var jt := Music.track_for_scene("main")
	Settings.reset_options(["menu_track"], false)
	var jb := Jukebox.open()
	await tree.process_frame
	var rows := jb.find_children("Track_*", "", true, false).size()
	SceneRouter.close_overlays()
	await tree.process_frame
	t._check(not Settings.has_music() or (jt == "act1" and rows >= 7 and Music.track_for_scene("main") == "menu"), "a jukebox devia tocar as faixas e escolher a do menu (274)")
	# 275, 276: o movimento por partes e a força dos abanões.
	Settings.set_opt("fx_shake", false, false)
	var no_shake := not Settings.fx_ok("shake") and Settings.fx_ok("particles") == (not Settings.reduce_motion and Settings.anim_scale() > 0.0)
	Settings.reset_options(["fx_shake"], false)
	Settings.set_opt("shake_strength", 0.5, false)
	var half := is_equal_approx(Settings.shake_scale(), 0.5)
	Settings.reset_options(["shake_strength"], false)
	t._check(no_shake and half, "o movimento devia desligar-se por partes, com a força dos abanões (275, 276)")
	# 277, 286: as perguntas do 1.º arranque.
	var keep_q = GameState.progress.get("first_questions", false)
	var fr := SessionWindows.open_first_run()
	await tree.process_frame
	(fr.find_child("Q_no_flash", true, false) as Button).pressed.emit()
	var flash_off := not bool(Settings.opt("fx_flash"))
	Settings.reset_options(["fx_flash"], false)
	SceneRouter.close_overlays()
	GameState.progress["first_questions"] = keep_q
	t._check(fr.find_child("FlashWarning", true, false) != null and flash_off, "no 1.º arranque devia perguntar e avisar das luzes a piscar (277, 286)")
	# 278: modo assistido.
	GameState.new_run("deck01", 19901)
	var foe: Dictionary = GameState.pick_enemy(1)
	var bm0 := BattleManager.new()
	bm0.start(foe)
	var hp0 := int(bm0.enemy["max_hp"])
	var turns0 := bm0.max_turns
	var disc0 := bm0.discards_left
	bm0.free()
	Settings.set_opt("assist_hp", true, false)
	Settings.set_opt("assist_turn", true, false)
	Settings.set_opt("assist_channel", true, false)
	var bm1 := BattleManager.new()
	bm1.start(foe)
	var assisted := int(bm1.enemy["max_hp"]) == int(ceil(hp0 * BattleManager.ASSIST_HP)) and bm1.max_turns == turns0 + 1 and bm1.discards_left == disc0 + 1
	bm1.free()
	Settings.reset_options(["assist_hp", "assist_turn", "assist_channel"], false)
	t._check(assisted, "o modo assistido devia dar +1 turno, +1 canalização e menos vida aos inimigos (278)")
	# 281, 282: DICA em todas as dificuldades e texto simples.
	Settings.set_opt("simple_text", true, false)
	var simple := CardData.simplify("Reativa todas as cartas de Custo 2 na Arena.")
	Settings.reset_options(["simple_text"], false)
	t._check(simple.contains("mesa") and simple.contains("outra vez"), "o texto simples devia trocar as palavras do jogo (282)")
	# 293, 294: as cartas noutra língua e o formato dos números.
	Settings.set_opt("cards_language", "en", false)
	var en_name := c1.display_name()
	Settings.reset_options(["cards_language"], false)
	Settings.set_opt("number_format", "pt", false)
	var n1 := Cascade.fmt_int(12345)
	Settings.reset_options(["number_format"], false)
	t._check(en_name != c1.display_name() or Settings._en.get_message(c1.name) == "", "as cartas deviam poder ficar noutra língua (293)")
	t._check(n1 == "12.345" and Cascade.fmt_int(12345) == "12 345", "o formato dos números devia seguir a opção (294)")
	# 292, 295, 297: modo tablet, cor de destaque e fundo do menu.
	Settings.set_opt("tablet", "on", false)
	var tab := Settings.is_tablet() and Settings.hand_scale_eff() > Settings.hand_scale
	Settings.reset_options(["tablet"], false)
	Settings.set_opt("accent", "blue", false)
	var blue := UiKit.button("X", 48, 16, UiKit.PRIMARY)
	var bcol := (blue.get_theme_stylebox("normal") as StyleBoxFlat).bg_color
	Settings.reset_options(["accent"], false)
	blue.free()
	Settings.set_opt("menu_bg", "plain", false)
	var plain := MenuBackdrop.menu_art_id() == ""
	Settings.reset_options(["menu_bg"], false)
	t._check(tab, "o modo tablet devia aumentar as cartas da mão (292)")
	t._check(bcol.b > bcol.r, "a cor de destaque devia mudar os botões principais (295)")
	t._check(plain and MenuBackdrop.menu_art_id() != "", "o fundo do menu devia ser à escolha (297)")
	# 298: o nome e o retrato do mago na imagem de partilha.
	var sm := RunShare.summary_from_state(true, false)
	var card := RunShare.build_card(sm)
	t._check(String(sm.get("mage", "")) != "" and card.find_child("MageName", true, false) != null, "a imagem de partilha devia ter o mago (298)")
	card.free()
	# 299, 300: cosméticos por baralho e ao acaso.
	var frames := Settings.unlocked_cosmetics("frame")
	GameState.set_deck_cosmetic("frame", "deck01", String(frames.back()))
	var per_deck := GameState.deck_cosmetic("frame", "deck01") == String(frames.back())
	GameState.set_deck_cosmetic("frame", "deck01", "")
	Settings.set_opt("random_cosmetics", true, false)
	GameState.new_run("deck01", 19902)
	var rolled: bool = GameState.run_log.get("cosm") is Dictionary and (GameState.run_log["cosm"] as Dictionary).has("frame")
	Settings.reset_options(["random_cosmetics"], false)
	t._check(per_deck and GameState.deck_cosmetic("frame", "deck01") == "", "cada baralho devia poder ter a sua moldura (299)")
	t._check(rolled, "com a opção, cada run devia sortear os cosméticos (300)")
	GameState.clear_saved_run()
	Settings.save_settings()
	print("  0.19.0 (9. acessibilidade e personalização): cartas lidas em voz alta, modo leitor, descrição das ilustrações, letra para dislexia, espaço, filtro de daltonismo, símbolos e padrões, formas no mapa, medalhas com letra, legendas e avisos dos sons, silenciar, jukebox, movimento por partes, perguntas do 1.º arranque, modo assistido, texto simples, cartas noutra língua, números, tablet, cor de destaque, fundo do menu, mago na partilha e cosméticos por baralho e ao acaso OK")
