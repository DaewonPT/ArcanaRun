extends Node
## Calcula o melhor ataque de cada quebra-cabeças (para fixar a vida do inimigo):
##   godot --headless --path . res://tests/PuzzleTune.tscn

func _ready() -> void:
	await get_tree().process_frame
	GameState.new_run("deck01", 1)
	GameState.relic_ids.clear()
	GameState.player_hp = 20
	for p in CardDB.puzzles:
		var t0 := Time.get_ticks_msec()
		var best := PuzzleSolver.solve(p)
		print("PUZZLE %s %s: max=%d hp=%d line=%s (%d ms)" % [p.get("id", ""), p.get("name", ""), int(best["total"]), int(p.get("hp", 0)), str(best["line"]), Time.get_ticks_msec() - t0])
	get_tree().quit()
