extends Node
## Calcula, para cada lição da Escola do Mago, o melhor ataque com a mecânica e sem ela, para fixar a
## vida do inimigo no meio:  godot --headless --path . res://tests/LessonTune.tscn

func _ready() -> void:
	await get_tree().process_frame
	GameState.new_run("deck01", 1)
	GameState.relic_ids.clear()
	GameState.player_hp = 20
	for l in CardDB.lessons:
		if String(l.get("goal_type", "win")) != "win":
			continue
		var with_best := _best(l, true)
		var without_def: Dictionary = (l as Dictionary).duplicate(true)
		var allow_kick := true
		for w in l.get("without", []):
			if String(w) == "kick":
				allow_kick = false
			else:
				(without_def["hand"] as Array).erase(String(w))
		var without_best := _best(without_def, allow_kick)
		print("LESSON %s: com=%d sem=%d vida=%d (tem de ficar entre os dois)" % [l.get("id", ""), with_best, without_best, int(l.get("hp", 0))])
	get_tree().quit()

func _best(def: Dictionary, allow_kick: bool) -> int:
	var bm := BattleManager.new()
	bm.start_puzzle(def)
	var best := [0]
	_dfs(bm, best, allow_kick)
	bm.free()
	return best[0]

func _dfs(bm: BattleManager, best: Array, allow_kick: bool) -> void:
	best[0] = maxi(best[0], bm.preview_attack().total())
	var snap := bm.to_dict()
	var ids := {}
	for c in bm.deck.hand.duplicate():
		if not bm.can_play(c) or ids.has(c.data.id):
			continue
		ids[c.data.id] = true
		for kick in ([false, true] if allow_kick and bm.can_kick(c) else [false]):
			var inst: CardInstance = null
			for h in bm.deck.hand:
				if h.data.id == c.data.id:
					inst = h
					break
			if inst == null:
				continue
			bm.play(inst, kick)
			_dfs(bm, best, allow_kick)
			bm.restore(snap)
			bm.puzzle = true
