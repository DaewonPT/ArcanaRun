class_name Test0200
extends RefCounted
## Testes da 0.20.0 «Sem armadilhas», chamados pelo SmokeTest: `await Test0200.run(self)`; só estes com
## `-- --only=0200`. Um teste por requisito (`_test_0200_<id>`); usam o _check() e as ajudas do SmokeTest (`t`)
## e as de baixo.

static func run(t: Node) -> void:
	var old_lang := Settings.language
	Settings.language = "pt"   # os textos comparados são os portugueses
	await _test_0200_base(t)
	await _test_0200_a1(t)
	await _test_0200_a2(t)
	await _test_0200_a3(t)
	await _test_0200_a4(t)
	await _test_0200_a5(t)
	await _test_0200_a6(t)
	await _test_0200_b7(t)
	await _test_0200_b8(t)
	await _test_0200_b9(t)
	await _test_0200_b10(t)
	await _test_0200_final_battle(t)
	await _test_0200_c11(t)
	await _test_0200_final_menus(t)
	await _test_0200_e16(t)
	await _test_0200_d12(t)
	await _test_0200_final_tutorial(t)
	await _test_0200_d13(t)
	await _test_0200_d14(t)
	await _test_0200_d15(t)
	await _test_0200_e19(t)
	await _test_0200_e17(t)
	await _test_0200_e18(t)
	await _test_0200_builder_more_back(t)
	await _test_0200_shop_protected_back(t)
	await _test_0200_f20(t)
	await _test_0200_release(t)
	Settings.language = old_lang

# --- Ajudas ---

## Estado para GameState.pending_battle (o Battle.tscn retoma-o tal e qual): inimigo de teste com 99 999 de vida e
## 1 de ataque (`enemy` junta ou troca campos) e 4 cartas no grimório. Chamar antes GameState.new_run(…).
static func battle_state(hand: Array, board: Array = [], turn: int = 1, max_turns: int = 5, mana: int = 6, enemy: Dictionary = {}) -> Dictionary:
	var e := {"id": "test", "name": "Teste", "hp": 99999, "max_hp": 99999, "attack": 1, "text": "", "abilities": [], "boss": false, "rule": {}}
	e.merge(enemy, true)
	var st := {"enemy": e, "turn": turn, "max_turns": max_turns, "mana_total": mana, "mana_available": mana, "discards_left": 3,
		"player_hp": GameState.player_hp, "library": [], "hand": [], "graveyard": [], "board": [], "exile": []}
	for id in hand:
		st["hand"].append({"id": String(id), "entry": -1})
	for id in board:
		st["board"].append({"id": String(id), "entry": -1})
	for id in ["c005", "c010", "c005", "c010"]:
		st["library"].append({"id": id, "entry": -1})
	return st

## Abre o Battle.tscn com esse estado (filho de `t`) e espera que assente. O fim da batalha não muda de cena.
static func open_battle(t: Node, state: Dictionary) -> Node:
	GameState.pending_battle = state
	var b: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	t.add_child(b)
	EventBus.battle_ended.disconnect(b._on_battle_ended)
	await t._wait_until(func(): return not b._animating, 8000)
	await t.get_tree().process_frame
	return b

## Fecha as janelas, liberta a cena e espera um frame.
static func close_scene(t: Node, n: Node) -> void:
	SceneRouter.close_overlays()
	if is_instance_valid(n):
		n.queue_free()
	await t.get_tree().process_frame

## O «retroceder» do Android, como o telemóvel (e o SceneRouter._pad_input) o entrega: primeiro ao SceneRouter e às
## janelas, depois ao ecrã. Chega a todos os nós: libertar antes as cenas de outros testes (o Main no início sai do jogo).
static func back(t: Node) -> void:
	t.get_tree().root.propagate_notification(Node.NOTIFICATION_WM_GO_BACK_REQUEST)

## Um toque curto (rato emulado, como o Android entrega o dedo), em coordenadas do ecrã do jogo.
static func tap(t: Node, pos: Vector2) -> void:
	t._mouse_button(pos, true)
	await t.get_tree().process_frame
	t._mouse_button(pos, false)
	await t.get_tree().process_frame

## Toque longo: carrega, espera que o balão do SceneRouter abra (o tempo do _explain_input, com folga) e larga.
static func long_press(t: Node, pos: Vector2) -> void:
	t._mouse_button(pos, true)
	await t.get_tree().create_timer(maxf(0.5, Settings.long_press_time() + 0.12)).timeout
	await t._wait_until(func(): return SceneRouter._alive(SceneRouter._balloon), 1500)   # sem balão (own_long_press) só espera o limite
	t._mouse_button(pos, false)
	await t.get_tree().process_frame

## Os textos dos botões de um ChoiceDialog, pela ordem pedida (Choice0, Choice1…).
static func choice_texts(d: Node) -> Array:
	var out: Array = []
	var b := d.find_child("Choice0", true, false) as Button
	while b != null:
		out.append(b.text)
		b = d.find_child("Choice%d" % out.size(), true, false) as Button
	return out

## A6: uma janela de teste com UiKit.window, por cima de tudo. Com i >= 0 tem ✕ (on_close), que conta em calls[i] e fecha.
static func _a6_window(title: String, calls: Array, i: int) -> Control:
	var o := Control.new()
	o.name = "A6Window"
	o.set_anchors_preset(Control.PRESET_FULL_RECT)
	o.mouse_filter = Control.MOUSE_FILTER_STOP
	SceneRouter.show_overlay(o)
	var on_close := Callable()
	if i >= 0:
		on_close = func():
			calls[i] += 1
			UiKit.close_animated(o)
	UiKit.window(o, 420, title, UiKit.GOLD, on_close)
	return o

## K3: sem ecrã a janela dos testes tem 1280×1280 e tudo «cabia». Quem mede se algo cabe no ecrã usa a do telemóvel
## (o tamanho do projeto, 1280×720) e no fim repõe a antiga, que esta função devolve (`t.get_tree().root.size = …`).
static func phone_window(t: Node) -> Vector2i:
	var keep: Vector2i = t.get_tree().root.size
	t.get_tree().root.size = Vector2i(int(ProjectSettings.get_setting("display/window/size/viewport_width")), int(ProjectSettings.get_setting("display/window/size/viewport_height")))
	return keep

## Ficheiros com estas extensões debaixo de `dir` (recursivo; sem pastas escondidas, __pycache__ nem tests/_probe).
static func _text_files(dir: String, exts: Array[String], out: Array[String]) -> void:
	for d: String in DirAccess.get_directories_at(dir):
		if not d.begins_with(".") and d != "__pycache__" and d != "_probe":
			_text_files(dir.path_join(d), exts, out)
	for f: String in DirAccess.get_files_at(dir):
		if f.get_extension() in exts:
			out.append(dir.path_join(f))

# --- Testes ---

## A1: com o balão do toque longo aberto, largar o mesmo dedo não carrega no botão (um Button do menu e uma linha da
## loja). O toque curto fica igual, o botão não fica preso e os nós com own_long_press (o ATACAR) não mudam.
static func _test_0200_a1(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	# Fronteira: um botão com toque longo próprio (own_long_press, como o «segurar para atacar») carrega ao largar, sem balão.
	var holder := Control.new()
	holder.set_anchors_preset(Control.PRESET_FULL_RECT)
	t.add_child(holder)
	var own := UiKit.button("X", 48, 16)
	own.tooltip_text = "Explicação de teste"
	own.set_meta("own_long_press", true)
	own.position = Vector2(600, 300)
	own.size = Vector2(80, 48)
	holder.add_child(own)
	var presses: Array = [0]
	own.pressed.connect(func(): presses[0] += 1)
	await tree.process_frame
	await long_press(t, Vector2(640, 324))
	t._check(int(presses[0]) == 1 and not SceneRouter._alive(SceneRouter._balloon), "um botão com toque longo próprio (own_long_press) devia carregar ao largar e sem balão, como hoje (A1)")
	holder.queue_free()
	await tree.process_frame
	# Um Button do menu: o sino (abre os AVISOS) explica-se no toque longo. O JOGAR tem o mesmo defeito, mas começava uma run.
	Storage.crashed_before = false
	var m: Node = load("res://scenes/main/Main.tscn").instantiate()
	t.add_child(m)
	await tree.process_frame
	await tree.process_frame
	SceneRouter.close_overlays()   # as Novidades ou as regras que o menu tenha aberto
	await tree.process_frame
	var bell := m.find_child("Bell", true, false) as Button
	var modes := m.get_node("%Modes") as Button
	var pb := Test0190._center(bell)
	await long_press(t, pb)
	t._check(SceneRouter._alive(SceneRouter._balloon), "segurar no sino do menu devia abrir o balão da explicação (A1)")
	t._check(not (SceneRouter.top_overlay() is NoticeLog), "largar o dedo depois do balão não devia carregar no sino do menu (A1)")
	SceneRouter.close_overlays()
	await tree.process_frame
	# O botão não fica preso: o toque seguinte noutro botão vai para esse (se o largar fosse engolido, ia para o sino).
	await tap(t, Test0190._center(modes))
	t._check(m.current_page() == "modes" and not (SceneRouter.top_overlay() is NoticeLog), "depois de segurar no sino, um toque noutro botão devia carregar nesse e não no sino (A1)")
	m.call("_show_page", "main", false)
	await tree.process_frame
	await tap(t, pb)
	t._check(SceneRouter.top_overlay() is NoticeLog, "um toque curto no sino devia abrir os AVISOS (A1)")
	await close_scene(t, m)
	# Uma linha da loja: segurar numa relíquia para ler o texto todo não a compra; o toque curto a seguir compra.
	GameState.new_run("deck01", 20101)
	GameState.relic_ids.clear()
	GameState.gold = 999
	var keep_cb := Settings.confirm_buy
	Settings.confirm_buy = false   # um toque compra (sem o «Toca outra vez para comprar»)
	var keep_size := phone_window(t)   # «à vista» nos 720 px do telemóvel (K3)
	var shop: Node = Test0190._fresh_shop(t)
	await tree.process_frame
	await tree.process_frame
	SceneRouter.close_overlays()
	await tree.process_frame
	var row: Button = null
	for c in (shop.get_node("%RelicOffers") as Node).get_children():
		if row == null and c is Button and c.has_meta("kind") and String(c.get_meta("kind")) == "relic":
			row = c
	var pr := Test0190._center(row) if row != null else Vector2(-1, -1)
	t._check(row != null and t.get_viewport().get_visible_rect().has_point(pr), "a loja devia ter uma relíquia à venda à vista (A1)")
	if row != null:
		var gold0 := GameState.gold   # depois dos juros que a loja paga ao abrir
		await long_press(t, pr)
		t._check(SceneRouter._alive(SceneRouter._balloon), "segurar numa relíquia da loja devia abrir o balão com o texto todo (A1)")
		t._check(GameState.gold == gold0 and GameState.relic_ids.is_empty(), "segurar numa relíquia da loja para ler e largar não devia comprá-la: o ouro fica igual (A1)")
		var gold1 := GameState.gold
		await tap(t, pr)
		t._check(GameState.gold < gold1 and GameState.relic_ids.size() == 1, "um toque curto na mesma relíquia devia comprá-la, também logo a seguir a um toque longo (A1)")
	Settings.confirm_buy = keep_cb
	if SceneRouter._alive(SceneRouter._balloon):
		SceneRouter._balloon.queue_free()
	await Test0190._free_shop(t, shop)
	tree.root.size = keep_size
	GameState.clear_saved_run()
	print("  0.20.0 (A1): segurar para ler não carrega no botão (sino do menu e relíquia da loja), o toque curto e o own_long_press iguais OK")

## Tarefa 2 (A2): janelas que só decidem com os botões (ChoiceDialog.buttons_only): «Repetir a batalha?» e «O ouro
## que sobra». As outras continuam a fechar com null no toque fora e no retroceder.
static func _test_0200_a2(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	# 1) A opção. set(): o teste compila mesmo antes de o membro existir (Passo 2).
	var got: Array = []
	var d := ChoiceDialog.open("Teste", "", [["SIM", "yes", true], ["NÃO", "no"]])
	d.set("buttons_only", true)
	d.chosen.connect(func(v): got.append(v))
	await tree.process_frame
	await tree.process_frame
	await tap(t, Vector2(40, 40))
	back(t)
	await tree.process_frame
	await tree.process_frame
	var open1: bool = is_instance_valid(d) and SceneRouter.top_overlay() == d
	t._check(open1 and got.is_empty(), "com buttons_only, o toque fora e o retroceder deviam deixar a janela aberta (A2)")
	if open1:
		d._pick("no")
	await tree.process_frame
	t._check(got.size() == 1 and got[0] == "no" and not SceneRouter.has_overlay(), "com buttons_only, os botões deviam continuar a decidir (A2)")
	SceneRouter.close_overlays()
	await tree.process_frame
	# 2) Sem a opção fica como antes: o toque fora fecha com null.
	var got2: Array = []
	var d2 := ChoiceDialog.open("Teste", "", [["OK", "ok", true]])
	d2.chosen.connect(func(v): got2.append(v))
	await tree.process_frame
	await tree.process_frame
	await tap(t, Vector2(40, 40))
	await tree.process_frame
	t._check(got2.size() == 1 and got2[0] == null and not SceneRouter.has_overlay(), "sem buttons_only, o toque fora devia fechar a janela com null, como antes (A2)")
	SceneRouter.close_overlays()
	await tree.process_frame
	# 3) «Repetir a batalha?»: o toque fora e o retroceder deixam-na aberta; ACABAR A RUN acaba; REPETIR repete.
	GameState.new_run("deck01", 20021)
	GameState.clear_saved_run()
	GameState.relic_ids.clear()
	Settings.set_opt("assist_retry", true, false)
	SceneRouter._busy = true   # REPETIR chama SceneRouter.go("battle"): a cena não muda durante o teste
	var b: Node = await open_battle(t, battle_state(["c010", "c002"], ["c001"]))
	var res: Array = []
	var offer := func() -> void: res.append(await b._offer_retry())
	offer.call()
	await t._wait_until(func(): return SceneRouter.top_overlay() is ChoiceDialog, 5000)
	var dlg: Control = SceneRouter.top_overlay()
	t._check(dlg != null and dlg.name == "RetryOffer", "o modo assistido devia abrir «Repetir a batalha?» (A2)")
	await tap(t, Vector2(40, 40))
	back(t)
	await tree.process_frame
	await tree.process_frame
	var still: bool = is_instance_valid(dlg) and SceneRouter.top_overlay() == dlg
	t._check(still and res.is_empty(), "com «Repetir a batalha?» aberta, o toque fora e o retroceder deviam deixar a janela aberta e a run viva (A2)")
	var end_btn: Button = (t._find_named(dlg, "Choice1") as Button) if still else null
	t._check(end_btn != null and end_btn.text == "ACABAR A RUN", "o 2.º botão de «Repetir a batalha?» devia ser ACABAR A RUN (A2)")
	if end_btn != null:
		await tree.create_timer(0.3).timeout   # a janela acaba de entrar (pop_in)
		await tap(t, Test0190._center(end_btn))
	await t._wait_until(func(): return not res.is_empty(), 2000)
	t._check(res.size() == 1 and res[0] == false and not SceneRouter.has_overlay(), "só o ACABAR A RUN devia acabar a run (A2)")
	res.clear()
	offer.call()
	await t._wait_until(func(): return SceneRouter.top_overlay() is ChoiceDialog, 5000)
	var top: Control = SceneRouter.top_overlay()
	var again: Button = (t._find_named(top, "Choice0") as Button) if top != null else null
	var again_ok: bool = again != null and again.text == "REPETIR A BATALHA"
	if again != null:
		await tree.create_timer(0.3).timeout
		await tap(t, Test0190._center(again))
	await t._wait_until(func(): return not res.is_empty(), 2000)
	t._check(again_ok and res.size() == 1 and res[0] == true and not GameState.pending_battle.is_empty(), "REPETIR A BATALHA devia recomeçar a batalha (A2)")
	# B2: o «uma vez por run» fica gravado depois do REPETIR (o _restore_snap repõe o run_log)
	t._check(bool(GameState.run_log.get("retry_used", false)), "depois de REPETIR, a run devia ficar marcada como «retry_used» (A2/B2)")
	GameState.pending_battle = {}
	res.clear()
	offer.call()
	await tree.process_frame
	await tree.process_frame
	t._check(res.size() == 1 and res[0] == false and not (SceneRouter.top_overlay() is ChoiceDialog), "depois de REPETIR, o _offer_retry seguinte devia devolver false sem abrir a janela (A2/B2)")
	SceneRouter.close_overlays()   # (se abriu) não deixar a janela pendurada
	SceneRouter._busy = false
	Settings.reset_options(["assist_retry"], false)
	await close_scene(t, b)
	GameState.clear_saved_run()
	# 4) «O ouro que sobra» (antes do boss final, uma vez por run): o toque fora e o retroceder não gastam a troca.
	GameState.new_run("deck01", 20022)
	GameState.clear_saved_run()
	GameState.ante = GameState.max_ante
	GameState.map_phase = "battle"
	GameState.interlude_key = GameState.climate_key(GameState.ante)   # sem o interlúdio do ato por cima
	GameState.gold = 21
	var mp: Node = load("res://scenes/map/Map.tscn").instantiate()
	t.add_child(mp)
	await tree.process_frame
	await tree.process_frame
	SceneRouter.close_overlays()   # o que o mapa abra sozinho
	await tree.process_frame
	var due := Economy.final_trade_due()
	mp.call("_final_trade")
	await tree.process_frame
	var ft: Control = SceneRouter.top_overlay()
	await tap(t, Vector2(40, 40))
	back(t)
	await tree.process_frame
	await tree.process_frame
	var kept: bool = is_instance_valid(ft) and SceneRouter.top_overlay() == ft and ft.name == "FinalTrade"
	t._check(due and kept and Economy.final_trade_due() and GameState.gold == 21, "«O ouro que sobra» só devia decidir com os botões: o toque fora e o retroceder não podem gastar a troca (A2)")
	if kept:
		(ft as ChoiceDialog)._pick("keep")
	await tree.process_frame
	t._check(not Economy.final_trade_due() and GameState.gold == 21, "GUARDAR O OURO devia fechar a troca sem gastar ouro (A2)")
	await close_scene(t, mp)
	GameState.clear_saved_run()
	print("  0.20.0 (A2): «Repetir a batalha?» e «O ouro que sobra» só decidem com os botões; as outras janelas fecham como antes OK")

## Tarefa 0: as capturas sem a janela «Antes de começar» e as ajudas de cima a funcionar (comportamento da 0.19.1).
static func _test_0200_base(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	# As capturas começam com este progresso: a janela FirstRun não pode abrir por cima.
	var shots: GDScript = load("res://tests/Screenshots.gd")
	var bp: Dictionary = shots.get_script_constant_map().get("BASE_PROGRESS", {})
	var keep: Dictionary = GameState.progress
	GameState.progress = bp.duplicate(true)
	var asks := SessionWindows.needs_first_questions()
	GameState.progress = keep
	t._check(not bp.is_empty() and not asks, "as capturas não podem abrir a janela «Antes de começar» (Screenshots.BASE_PROGRESS sem first_questions)")
	# Batalha no último turno com a mão e a Arena dadas.
	GameState.new_run("deck01", 20001)
	GameState.clear_saved_run()
	var b: Node = await open_battle(t, battle_state(["c001", "c002"], ["c099"], 5, 5))
	var bm: BattleManager = b.battle
	t._check(bm.turn == 5 and bm.turns_left() == 0 and bm.board.size() == 1 and bm.deck.hand.size() == 2, "battle_state/open_battle deviam abrir a batalha no último turno com a mão e a Arena dadas")
	await close_scene(t, b)
	GameState.clear_saved_run()
	# O retroceder fecha a janela de cima (com null) e o ecrã de baixo não reage nesse frame.
	var got: Array = []
	var d := ChoiceDialog.open("Teste", "", [["OK", "ok"]])
	d.chosen.connect(func(v): got.append(v))
	await tree.process_frame
	back(t)
	var same_frame := SceneRouter.has_overlay()
	await tree.process_frame
	await tree.process_frame
	t._check(got.size() == 1 and got[0] == null and same_frame and not SceneRouter.has_overlay(), "back() devia fechar a janela de cima como o retroceder do Android")
	SceneRouter.close_overlays()
	await tree.process_frame
	# O toque longo abre o balão; o toque curto carrega no botão, também logo a seguir a um toque longo.
	var holder := Control.new()
	holder.set_anchors_preset(Control.PRESET_FULL_RECT)
	t.add_child(holder)
	var btn := UiKit.button("X", 48, 16)
	btn.tooltip_text = "Explicação de teste"
	btn.position = Vector2(600, 300)
	btn.size = Vector2(80, 48)
	holder.add_child(btn)
	var presses: Array = [0]
	btn.pressed.connect(func(): presses[0] += 1)
	await tree.process_frame
	await long_press(t, Vector2(640, 324))
	var balloon := SceneRouter._alive(SceneRouter._balloon)
	var before := int(presses[0])
	await tap(t, Vector2(640, 324))
	t._check(balloon, "long_press() devia abrir o balão da explicação")
	t._check(int(presses[0]) == before + 1, "tap() devia carregar no botão, também logo a seguir a um toque longo")
	holder.queue_free()
	if SceneRouter._alive(SceneRouter._balloon):
		SceneRouter._balloon.queue_free()
	await tree.process_frame
	print("  0.20.0 (base): capturas sem «Antes de começar», batalha no último turno, retroceder, toque e toque longo OK")

## A3: as alterações no Construtor marcam «• por guardar». Com elas, o MENU (◀), o retroceder e a mudança de espaço
## perguntam «Guardar as alterações?» (fechar = VOLTAR); sem elas sai-se com 1 toque. Os espaços deste PC (cartas, Selos e costas) ficam iguais.
static func _test_0200_a3(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	var keep_decks: Dictionary = CardDB.custom_decks.duplicate(true)
	var keep_stakes: Dictionary = GameState.progress.get("custom_stakes", {}).duplicate(true)   # o passo F2 troca os espaços 3 e 4 a sério
	var keep_backs: Dictionary = GameState.progress.get("deck_backs", {}).duplicate(true)
	CardDB.custom_decks.clear()
	CardDB.custom_decks["custom_3"] = {"id": "custom_3", "num": 0, "name": "Guardado", "custom": true,
		"cards": ["c001", "c001", "c002", "c003", "c005", "c009", "c010", "c018", "c019", "c050"]}
	SceneRouter._busy = true   # o go("main") do Construtor não pode trocar de cena (tiraria o SmokeTest)
	load("res://scenes/builder/DeckBuilder.gd").reset_memory()
	var db: Node = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	t.add_child(db)   # abre no espaço 1, vazio
	await tree.process_frame
	await tree.process_frame
	if db.has_method("has_unsaved_changes") and db.find_child("Menu", true, false) is Button and db.find_child("Unsaved", true, false) is Label:
		await _a3_steps(t, db)   # um erro lá dentro só pára os passos: a limpeza de baixo corre sempre
	else:
		t._check(false, "o Construtor devia ter o botão «Menu», a marca «Unsaved» e has_unsaved_changes() (A3)")
	await close_scene(t, db)
	SceneRouter._busy = false
	load("res://scenes/builder/DeckBuilder.gd").reset_memory()
	CardDB.custom_decks = keep_decks
	CardDB.save_custom_decks()
	GameState.progress["custom_stakes"] = keep_stakes
	GameState.progress["deck_backs"] = keep_backs
	GameState.save_progress()
	print("  0.20.0 (A3): «• por guardar» e «Guardar as alterações?» no MENU, no retroceder e ao mudar de espaço; fechar = VOLTAR; sem alterações sai logo OK")

static func _a3_steps(t: Node, db: Node) -> void:
	var tree: SceneTree = t.get_tree()
	var menu := db.find_child("Menu", true, false) as Button
	var mark := db.find_child("Unsaved", true, false) as Label
	var panel := db.find_child("DeckPanel", true, false) as Control
	var left: Array = [0]
	var go_on := func(): left[0] += 1   # «sair», visto de fora (o go("main") a sério mudaria de cena)
	# Sem alterações: sem marca; o MENU não abre janela e o _leave sai logo.
	t._check(not mark.visible and not db.has_unsaved_changes(), "o Construtor acabado de abrir não devia estar «por guardar» (A3)")
	menu.pressed.emit()
	await tree.process_frame
	db._leave(go_on)
	t._check(not SceneRouter.has_overlay() and left[0] == 1, "sem alterações, o MENU devia sair logo, sem janela (A3)")
	var w0 := panel.size.x
	# Juntar uma carta continua a ser 1 toque e marca «• por guardar»; tirá-la volta a «sem alterações».
	db._add_card("c001")
	await tree.process_frame
	t._check(mark.visible and mark.text == "• por guardar" and db.has_unsaved_changes() and not SceneRouter.has_overlay(), "juntar uma carta devia marcar «• por guardar» junto ao título, sem janela (A3)")
	db._remove_card("c001")
	t._check(not mark.visible and not db.has_unsaved_changes(), "tirar a carta que se juntou devia voltar a «sem alterações» (A3)")
	# Menos de MIN_CARDS: só SAIR SEM GUARDAR e VOLTAR; tocar fora = VOLTAR.
	db._add_card("c001")
	menu.pressed.emit()
	await tree.process_frame
	var dlg := SceneRouter.top_overlay()
	t._check(dlg is ChoiceDialog and t._has_text_in(dlg, "GUARDAR AS ALTERAÇÕES?") and choice_texts(dlg) == ["SAIR SEM GUARDAR", "VOLTAR"], "com menos de %d cartas, o MENU devia abrir «Guardar as alterações?» só com SAIR SEM GUARDAR e VOLTAR (A3)" % int(db.MIN_CARDS))
	await tap(t, Vector2(40, 40))
	await tree.process_frame
	t._check(not SceneRouter.has_overlay() and db.is_inside_tree() and db._cards.size() == 1, "tocar fora da janela devia ser VOLTAR: a carta fica (A3)")
	# Retroceder: abre a janela; o 2.º retroceder fecha-a (VOLTAR) e o Construtor não reage nesse toque.
	back(t)
	await tree.process_frame
	var opened: bool = SceneRouter.top_overlay() is ChoiceDialog
	back(t)
	var same_frame := SceneRouter.has_overlay()
	await tree.process_frame
	await tree.process_frame
	t._check(opened and same_frame and SceneRouter.top_overlay() == null and db._cards.size() == 1, "com alterações, o retroceder devia abrir a janela e o 2.º retroceder fechá-la como VOLTAR (A3)")
	# SAIR SEM GUARDAR sai.
	db._leave(go_on)
	(SceneRouter.top_overlay().find_child("Choice0", true, false) as Button).pressed.emit()
	await tree.process_frame
	t._check(left[0] == 2, "SAIR SEM GUARDAR devia sair (A3)")
	# Com MIN_CARDS cartas: GUARDAR, NÃO GUARDAR e VOLTAR; VOLTAR mantém as cartas, sem gravar.
	for id in ["c002", "c003", "c005", "c009", "c010", "c018", "c019", "c021", "c028"]:
		db._add_card(id)
	menu.pressed.emit()
	await tree.process_frame
	dlg = SceneRouter.top_overlay()
	t._check(dlg is ChoiceDialog and choice_texts(dlg) == ["GUARDAR", "NÃO GUARDAR", "VOLTAR"], "com %d cartas, a janela devia ter GUARDAR, NÃO GUARDAR e VOLTAR (A3)" % int(db.MIN_CARDS))
	(dlg.find_child("Choice2", true, false) as Button).pressed.emit()
	await tree.process_frame
	await tree.process_frame
	t._check(db._cards.size() == 10 and db._cards.has("c001") and not CardDB.custom_decks.has("custom_1") and mark.visible and not SceneRouter.has_overlay(), "VOLTAR devia manter as cartas, sem gravar (A3)")
	# Com 20 cartas (o alvo do COMPLETAR) e a letra normal o título é mais largo: a marca tem linha própria e o painel não alarga.
	var extra: Array = ["c030", "c031", "c032", "c033", "c034", "c035", "c036", "c037", "c038", "c039"]
	for id in extra:
		db._add_card(id)
	await tree.process_frame
	await tree.process_frame
	t._check(db._cards.size() == 20 and is_equal_approx(panel.size.x, w0), "a marca «• por guardar» devia caber sem alargar o painel do baralho, também com 20 cartas (A3)")
	for id in extra:
		db._remove_card(id)
	await tree.process_frame
	# GUARDAR grava e sai, e a marca sai.
	db._leave(go_on)
	(SceneRouter.top_overlay().find_child("Choice0", true, false) as Button).pressed.emit()
	await tree.process_frame
	t._check(left[0] == 3 and (CardDB.custom_decks.get("custom_1", {}).get("cards", []) as Array).size() == 10 and FileAccess.file_exists(CardDB.custom_decks_path()) and not mark.visible, "GUARDAR devia gravar e sair (A3)")
	# Mudar de espaço com alterações: VOLTAR fica (o seletor também volta); NÃO GUARDAR carrega o outro.
	db._add_card("c039")
	var opt := db._slot_opt as OptionButton
	opt.select(2)
	opt.item_selected.emit(2)
	await tree.process_frame
	dlg = SceneRouter.top_overlay()
	t._check(dlg is ChoiceDialog and db._slot == 1, "mudar de espaço com alterações devia perguntar antes de carregar o outro (A3)")
	(dlg.find_child("Choice2", true, false) as Button).pressed.emit()
	await tree.process_frame
	t._check(db._slot == 1 and opt.selected == 0 and db._cards.size() == 11, "VOLTAR devia ficar no espaço 1, com o seletor no 1 e as 11 cartas (A3)")
	opt.select(2)
	opt.item_selected.emit(2)
	await tree.process_frame
	(SceneRouter.top_overlay().find_child("Choice1", true, false) as Button).pressed.emit()
	await tree.process_frame
	t._check(db._slot == 3 and db._cards.size() == 10 and db._name == "Guardado" and not mark.visible and (CardDB.custom_decks["custom_1"]["cards"] as Array).size() == 10, "NÃO GUARDAR devia carregar o espaço 3 e deixar o 1 como estava gravado (A3)")
	# LIMPAR e o nome também contam; carregar um espaço tira a marca.
	db._on_more_choice("clear")
	t._check(mark.visible, "LIMPAR devia marcar «• por guardar» (A3)")
	db._load_slot(3)
	(db._name_edit as LineEdit).text_changed.emit("Outro nome")
	t._check(mark.visible, "mudar o nome devia marcar «• por guardar» (A3)")
	db._load_slot(3)
	t._check(not mark.visible and db._name == "Guardado", "carregar um espaço devia tirar a marca (A3)")
	# F1: ao mudar de espaço sem se poder guardar, o botão diz «MUDAR SEM GUARDAR».
	db._load_slot(3)
	db._cards.clear()
	db._add_card("c001")
	opt.select(2)
	opt.item_selected.emit(2)
	await tree.process_frame
	dlg = SceneRouter.top_overlay()
	t._check(dlg is ChoiceDialog and choice_texts(dlg) == ["MUDAR SEM GUARDAR", "VOLTAR"], "ao mudar de espaço com menos de %d cartas, o botão devia ser «MUDAR SEM GUARDAR» (A3/F1)" % int(db.MIN_CARDS))
	(dlg as ChoiceDialog)._pick(null)
	await tree.process_frame
	# F2: ⋯ › PARA TRÁS / PARA A FRENTE com alterações passa pela janela; NÃO GUARDAR larga-as e troca.
	db._on_more_choice("fwd")
	await tree.process_frame
	dlg = SceneRouter.top_overlay()
	t._check(dlg is ChoiceDialog and db._slot == 3 and choice_texts(dlg) == ["MUDAR SEM GUARDAR", "VOLTAR"], "PARA A FRENTE com alterações devia perguntar antes de mudar o espaço (A3/F2)")
	(dlg as ChoiceDialog)._pick("discard")
	await tree.process_frame
	t._check(db._slot == 4 and (CardDB.custom_decks["custom_4"]["cards"] as Array).size() == 10 and not mark.visible, "MUDAR SEM GUARDAR devia trocar com o espaço 3 como estava gravado, sem levar a carta solta (A3/F2)")
	db._load_slot(3)
	# Sem alterações, o retroceder sai logo (sem janela).
	back(t)
	await tree.process_frame
	t._check(not SceneRouter.has_overlay(), "sem alterações, o retroceder devia sair logo, sem janela (A3)")

## Tarefa 4 (A4): com ≥ 1 carta escolhida, o MENU e o retroceder do draft perguntam «SAIR DO DRAFT?» (SAIR / FICAR;
## fechar = FICAR, com singular e plural). Sem escolhas, saem logo.
static func _test_0200_a4(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	SceneRouter._busy = true   # SAIR (e o MENU sem escolhas) chamam SceneRouter.go("main"): a cena não muda no teste
	var dr: Node = load("res://scenes/draft/Draft.tscn").instantiate()
	t.add_child(dr)
	await tree.process_frame
	await tree.process_frame
	var menu: Button = t._find_node(dr, func(n: Node) -> bool: return n is Button and (n as Button).text == "MENU") as Button
	# Antes da 1.ª escolha: o MENU e o retroceder saem logo, sem janela.
	if menu != null:
		menu.pressed.emit()
	await tree.process_frame
	var menu_quiet: bool = SceneRouter.top_overlay() == null   # medido antes do retroceder, que fecharia qualquer janela
	back(t)
	await tree.process_frame
	t._check(menu != null and menu_quiet and SceneRouter.top_overlay() == null, "antes da 1.ª escolha, o MENU e o retroceder do draft deviam sair logo, sem perguntar (A4)")
	# 1 escolha: o MENU pergunta, no singular, com SAIR e FICAR.
	var cur: Array = dr.get("_current")
	dr.call("_on_pick", CardDB.new_instance((cur[0] as CardData).id))
	await tree.process_frame
	if menu != null:
		menu.pressed.emit()
	await tree.process_frame
	var dlg: Control = SceneRouter.top_overlay()
	var asked: bool = dlg is ChoiceDialog and dlg.name == "DraftLeave" and t._has_text(dlg, "SAIR DO DRAFT?") and t._has_text_in(dlg, "Perdes a carta escolhida.")
	var b0: Button = (t._find_named(dlg, "Choice0") as Button) if dlg != null else null
	var b1: Button = (t._find_named(dlg, "Choice1") as Button) if dlg != null else null
	t._check(asked and b0 != null and b0.text == "SAIR" and b1 != null and b1.text == "FICAR", "depois de 1 escolha, o MENU devia perguntar «Sair do draft? Perdes a carta escolhida.» com SAIR e FICAR (A4)")
	# Tocar fora da janela (e de qualquer botão do draft) é FICAR.
	await tap(t, Vector2(1240, 360))
	await tree.process_frame
	t._check(not SceneRouter.has_overlay() and is_instance_valid(dr) and (dr.get("_picked") as Array).size() == 1, "tocar fora da janela devia ser FICAR: o draft fica com a carta escolhida (A4)")
	# O retroceder pergunta; o 2.º retroceder fecha só a janela (FICAR) e o draft não volta a perguntar no mesmo toque.
	back(t)
	await tree.process_frame
	var asked_back: bool = SceneRouter.top_overlay() is ChoiceDialog and SceneRouter.top_overlay().name == "DraftLeave"
	back(t)
	var same_frame := SceneRouter.has_overlay()
	await tree.process_frame
	await tree.process_frame
	t._check(asked_back and same_frame and not SceneRouter.has_overlay(), "depois de 1 escolha, o retroceder devia perguntar, e o 2.º retroceder fechar só a janela (A4)")
	# 2 escolhas: plural.
	cur = dr.get("_current")
	dr.call("_on_pick", CardDB.new_instance((cur[0] as CardData).id))
	await tree.create_timer(0.4).timeout   # a 2.ª escolha fecha o booster (0,25 s) e abre o seguinte
	if menu != null:
		menu.pressed.emit()
	await tree.process_frame
	var dlg2: Control = SceneRouter.top_overlay()
	t._check(dlg2 != null and t._has_text_in(dlg2, "Perdes as 2 cartas escolhidas."), "com 2 escolhas, a janela devia dizer «Perdes as 2 cartas escolhidas.» (A4)")
	# SAIR fecha a janela e pede o menu (com _busy, a cena não muda).
	var leave: Button = (t._find_named(dlg2, "Choice0") as Button) if dlg2 != null else null
	var had_leave := leave != null   # o botão é libertado com a janela: guardar antes
	if had_leave:
		leave.pressed.emit()
	await tree.process_frame
	t._check(had_leave and not SceneRouter.has_overlay(), "SAIR devia fechar a janela e sair do draft (A4)")
	SceneRouter._busy = false
	await close_scene(t, dr)
	print("  0.20.0 (A4): o draft pergunta antes de sair (MENU e retroceder, singular e plural) e sem escolhas sai logo OK")

## B9: a derrota diz porquê. Na batalha, o letreiro «DERROTA» (vermelho) ganha uma 2.ª linha — «faltaram» com o número
## certo (turnos) ou «sem vida» — e fica o tempo de se ler; no RunOver, o detalhe começa pela mesma frase e o
## PORQUE PERDI? está na 1.ª fila, do tamanho do REVANCHE. Fronteiras: na Dupla falta a vida dos dois; o fim cabe em 720 px.
## Mais: o run_log com «secs» (como o tick_time o grava) já não estraga o log_cascade da run nova.
static func _test_0200_b9(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	var saved_progress: Dictionary = GameState.progress.duplicate(true)
	var runs0: int = SceneRouter.session_runs
	Settings.set_opt("assist_retry", false, false)    # sem «Repetir a batalha?» pelo meio
	Settings.set_opt("short_banners", false, false)   # o letreiro com o tempo normal
	# Erro da 0.19.1: o tick_time grava «secs» primeiro e o _ensure_run_log não criava o resto.
	GameState.new_run("deck01", 20089)
	GameState.run_log["secs"] = 5
	var bmc: BattleManager = t._battle_with(["c010"])
	var cc := Cascade.new()
	cc.power = 10
	cc.mult = 2.0
	cc.steps.append(Cascade.Step.new())
	GameState.log_cascade(cc, 20)
	bmc.free()
	t._check(int((GameState.run_log.get("damage_by_ante", {}) as Dictionary).get(str(GameState.ante), 0)) == 20, "o log_cascade com o run_log só com «secs» devia registar o dano por ante (B9)")
	# Dupla: o que falta é a vida dos dois inimigos.
	GameState.new_run("deck01", 20090)
	GameState.player_hp = 10
	var bmp: BattleManager = t._battle_with(["c010"])
	bmp.enemy["hp"] = 300
	bmp.enemy2 = {"id": "test2", "name": "Teste 2", "hp": 200, "max_hp": 200, "attack": 0, "abilities": []}
	var left_pair := int(bmp.loss_report().get("hp_left", -1))
	bmp.free()
	t._check(left_pair == 500, "na Dupla, a vida que falta (hp_left) devia somar os dois inimigos: 500 (B9): %d" % left_pair)
	for cause in ["turns", "life", "short"]:
		var by_turns: bool = cause != "life"
		var short_on: bool = cause == "short"   # «letreiros curtos»: o 1,2 s do min_hold tem de se manter
		Settings.set_opt("short_banners", short_on, false)
		var nm := "turnos" if by_turns else "vida"
		GameState.new_run("deck01", 20091 if by_turns else 20092)
		GameState.clear_saved_run()
		GameState.relic_ids.clear()
		if not by_turns:
			GameState.player_hp = 3                 # antes do battle_state: o estado leva esta vida
			GameState.death_save_used = true        # sem o Coração de Vidro (relíquia ou talento) a salvar
		var st: Dictionary = battle_state(["c010"], ["c001"], 5, 5) if by_turns else battle_state(["c010"], [], 1, 5, 6, {"attack": 40})
		var b: Node = await open_battle(t, st)
		var bm: BattleManager = b.battle
		bm.end_turn()   # o ataque direto, sem a confirmação de 2 toques do ATACAR (B7)
		var ended: bool = await t._wait_until(func(): return bm.finished, 20000)
		var left := int(bm.enemy.get("hp", 0))
		var lead := ("Os turnos acabaram · faltaram %s" % Cascade.fmt_int(left)) if by_turns else "Ficaste sem vida"
		SceneRouter._busy = true   # o fim da batalha não muda de cena
		b._on_battle_ended(false)
		var full := String(b._banner_full)
		var lock_ms: int = int(b._banner_lock_until) - Time.get_ticks_msec()
		var tone := String(b._band.tone) if b._band != null else ""
		t._check(ended and String(GameState.last_loss.get("cause", "")) == ("turns" if by_turns else "life"), "a batalha de teste devia perder por %s (B9)" % nm)
		t._check(full == "DERROTA\n" + lead, "o letreiro devia dizer «DERROTA» e, por baixo, «%s» (B9): %s" % [lead, full.replace("\n", " / ")])
		t._check(tone == "red", "o letreiro da derrota com duas linhas devia continuar vermelho (%s) (B9)" % nm)
		t._check(lock_ms >= (1200 + 500 - 150 if short_on else 2000), "o letreiro da derrota devia ficar o tempo de se ler, 1,8 s (%s) (B9): %d ms" % [nm, lock_ms])
		await tree.create_timer(2.2).timeout   # o _on_battle_ended espera 1,8 s antes do RunOver (o go() não muda de cena)
		SceneRouter._busy = false
		await close_scene(t, b)
		# o resumo de dano (com a carta MVP) entra na medição: é o que se vê depois de uma derrota
		var ro: Node = load("res://scenes/ui/RunOver.tscn").instantiate()
		t.add_child(ro)
		await tree.process_frame
		await tree.process_frame
		var detail := (ro.get_node("%Detail") as Label).text
		t._check(detail.begins_with(lead + ". "), "o detalhe do fim da run devia começar por «%s. » (B9): %s" % [lead, detail.get_slice("\n", 0)])
		var why := ro.find_child("WhyLost", true, false) as Button
		var again := ro.find_child("Rematch", true, false) as Button
		var row1: Node = ro.get_node("%Campaign").get_parent()
		t._check(why != null and again != null and why.get_parent() == row1 and why.custom_minimum_size == again.custom_minimum_size and why.get_theme_font_size("font_size") == again.get_theme_font_size("font_size"), "PORQUE PERDI? devia estar na 1.ª fila, do tamanho do REVANCHE (%s) (B9)" % nm)
		var vb: Control = ro.get_node("%Title").get_parent()
		t._check(vb.get_combined_minimum_size().y <= 720.0 - 32.0, "o fim da run com a causa devia caber em 720 px (pede %d) (B9)" % int(vb.get_combined_minimum_size().y))
		# o detalhe mais comprido (Talentos + prémio da 1.ª vez + fragmentos): 4 linhas, com o resumo, também cabe
		var det := ro.get_node("%Detail") as Label
		if det.text.count("\n") < 3:   # como o RunOver os escreve: Talentos, 1.ª vez e fragmentos na mesma linha
			det.text += "\n" + "Talentos: +3 pontos (Coleção → Talentos).  (2 do prémio da 1.ª vez)  ·  +5 fragmentos para cosméticos."
		await tree.process_frame
		await tree.process_frame
		ro.call("_shrink_to_fit")   # o mesmo que corre ao abrir, agora com o detalhe mais comprido
		await tree.process_frame
		t._check(vb.get_combined_minimum_size().y <= 720.0 - 32.0, "o fim da run com o detalhe mais comprido devia caber em 720 px (pede %d) (B9)" % int(vb.get_combined_minimum_size().y))
		ro.queue_free()
		await tree.process_frame
	GameState.progress = saved_progress
	Stats._ensure()
	GameState.save_progress()
	GameState.clear_saved_run()
	GameState.last_loss = {}
	SceneRouter.session_runs = runs0
	Settings.reset_options(["assist_retry", "short_banners"], false)
	print("  0.20.0 (B9): derrota por turnos («faltaram» e o número) e por vida («sem vida») no letreiro e no RunOver, PORQUE PERDI? na 1.ª fila OK")

## B8: no passo de cada relíquia, o número que salta fica por baixo do medalhão e inteiro dentro do ecrã (y ≥ 8), e a
## câmara está a 1× (aproximou-se nas criaturas e voltou antes do 1.º passo que não é de criatura nem de feitiço).
## Fronteiras: com o texto da cascata maior a etiqueta continua dentro; nas criaturas continua a sair por cima.
static func _test_0200_b8(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	var perf0: bool = Settings.performance_mode
	var rm0: bool = Settings.reduce_motion
	Settings.performance_mode = false   # a câmara só se aproxima com animações
	Settings.reduce_motion = false
	GameState.new_run("deck01", 20081)
	GameState.clear_saved_run()
	GameState.relic_ids.clear()
	for id in ["relic_drum", "relic_banner"]:
		GameState.add_relic(id)
	var keep_size := phone_window(t)   # «dentro do ecrã» = nos 1280×720 do telemóvel (K3)
	var b: Node = await open_battle(t, battle_state(["c010", "c002"], ["c001", "c003", "c005"]))
	var bm: BattleManager = b.battle
	var vp: Viewport = b.get_viewport()
	var screen := Rect2(Vector2.ZERO, b.get_viewport_rect().size)
	bm.end_turn()   # o ataque direto: a cascata anima-se na mesma (sem o botão nem a confirmação da B7)
	await t._wait_until(func(): return bool(b._animating), 4000)
	var by_text := {}   # texto do passo da relíquia -> id da relíquia
	var cas: Cascade = b._last_cascade
	if cas != null:
		for s in cas.steps:
			if s.source_kind == "relic":
				by_text[String(s.label)] = String(s.source_id)
	var zmax := 1.0
	var seen := 0
	var bad_rect: Array[String] = []
	var bad_zoom := 0
	var t0 := Time.get_ticks_msec()
	while bool(b._animating) and Time.get_ticks_msec() - t0 < 15000:
		zmax = maxf(zmax, float(b._cam_zoom))
		for c in b.get_children():
			if not (c is Label) or (c as Label).is_queued_for_deletion():
				continue
			for txt in by_text:
				if not (c as Label).text.ends_with(String(txt)):
					continue
				seen += 1
				var r := (c as Label).get_global_rect()
				var on_screen: Rect2 = vp.canvas_transform * r   # onde se vê de facto (com o zoom da câmara)
				var medal: Control = b._relic_views.get(by_text[txt])
				if not screen.encloses(on_screen) or on_screen.position.y < 8.0 or medal == null or r.position.y < medal.get_global_rect().end.y:
					bad_rect.append("%s em %s" % [txt, str(on_screen)])
				if not is_equal_approx(float(b._cam_zoom), 1.0) or not vp.canvas_transform.is_equal_approx(Transform2D.IDENTITY):
					bad_zoom += 1
		await tree.process_frame
	t._check(by_text.size() >= 1 and seen > 0 and zmax > 1.0, "a cascata de teste devia ter passos de relíquias e a câmara devia aproximar-se nas criaturas (relíquias %d, vistas %d, zoom máx. %.2f) (B8)" % [by_text.size(), seen, zmax])
	t._check(bad_rect.is_empty(), "a etiqueta de cada relíquia devia ficar por baixo do medalhão e inteira dentro do ecrã, com y ≥ 8 (B8): %s" % ", ".join(PackedStringArray(bad_rect.slice(0, 3))))
	t._check(bad_zoom == 0, "durante os passos das relíquias a câmara devia estar a 1× (B8): %d frames com zoom" % bad_zoom)
	await t._wait_until(func(): return bm.finished or (not bm.resolving and not bool(b._animating)), 8000)
	# Fronteiras: o texto da cascata maior (1,35×) numa relíquia; numa criatura, o número continua a sair por cima.
	Settings.set_opt("cascade_big", true, false)
	var rv: Control = b._relic_views["relic_banner"]
	b._pop(rv, "×2 Mult", Color.WHITE, "mult_mul")
	var big := b.get_child(b.get_child_count() - 1) as Label
	var big_start_ok := big != null and screen.encloses(big.get_global_rect()) and big.get_global_rect().position.y >= maxf(8.0, rv.get_global_rect().end.y)
	await tree.create_timer(Settings.dur(0.6)).timeout   # o fim do movimento da etiqueta
	var big_end_ok := big != null and is_instance_valid(big) and screen.encloses(big.get_global_rect()) and big.get_global_rect().position.y >= maxf(8.0, rv.get_global_rect().end.y)
	Settings.reset_options(["cascade_big"], false)
	t._check(big_start_ok and big_end_ok, "com o texto da cascata maior, a etiqueta da relíquia devia ficar por baixo do medalhão e dentro do ecrã (B8)")
	var cv: Control = null
	for v in b._board_views.values():
		if b._alive(v):
			cv = v
			break
	var up: Label = null
	if cv != null:
		b._pop(cv, "+1 Poder", Color.WHITE, "power_add")
		up = b.get_child(b.get_child_count() - 1) as Label
	t._check(up != null and up.get_global_rect().position.y < cv.get_global_rect().position.y, "nas criaturas, o número devia continuar a sair por cima da carta (B8)")
	Settings.performance_mode = perf0
	Settings.reduce_motion = rm0
	vp.canvas_transform = Transform2D.IDENTITY
	await close_scene(t, b)
	tree.root.size = keep_size
	GameState.relic_ids.clear()
	GameState.clear_saved_run()
	print("  0.20.0 (B8): etiqueta da relíquia por baixo do medalhão e dentro do ecrã, câmara a 1× nos passos das relíquias OK")

## E16: o resumo do Construtor conta os Terrenos com is_land(); Encantamentos e Equipamentos contam à parte
## («%d outros», só quando há algum).
static func _test_0200_e16(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	var keep_decks: Dictionary = CardDB.custom_decks.duplicate(true)
	CardDB.custom_decks.clear()
	load("res://scenes/builder/DeckBuilder.gd").reset_memory()
	var db: Node = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	t.add_child(db)
	await tree.process_frame
	for id in ["c001", "c002", "c331", "c332"]:   # criatura, feitiço e 2 Encantamentos; nenhum Terreno
		db._add_card(id)
	var s := String(db._summary.text)
	t._check(s.contains("1 criaturas · 1 feitiços · 0 terrenos · 2 outros · cores:") and int(db.deck_numbers(db._cards)["lands"]) == 0, "um baralho sem Terrenos e com 2 Encantamentos devia dizer 0 terrenos e 2 outros (E16): " + s)
	db._add_card("c488")   # Equipamento
	s = String(db._summary.text)
	t._check(s.contains("· 0 terrenos · 3 outros ·"), "os Equipamentos também deviam contar em «outros» (E16): " + s)
	db._on_clear_choice("clear")   # LIMPAR já confirmado (com alterações por guardar pergunta antes; F13)
	for id in ["c001", "c050"]:   # criatura e Terreno
		db._add_card(id)
	s = String(db._summary.text)
	t._check(s.contains("· 1 terrenos · cores:") and not s.contains("outros"), "sem Encantamentos nem Equipamentos, o resumo não devia falar de «outros» (E16): " + s)
	await close_scene(t, db)
	load("res://scenes/builder/DeckBuilder.gd").reset_memory()
	CardDB.custom_decks = keep_decks
	print("  0.20.0 (E16): o resumo do Construtor conta os Terrenos com is_land() e os outros à parte OK")

## Tarefa 5 (A5): a janela do Reforço tem VOLTAR. VOLTAR, o toque fora e o retroceder deixam a carta na mão, a mana e o
## DESFAZER iguais; um toque dentro não fecha; arrastar a carta e JOGAR funcionam como antes.
static func _test_0200_a5(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	GameState.new_run("deck01", 20051)
	GameState.clear_saved_run()
	GameState.relic_ids.clear()   # sem relíquias que mudem o custo do Reforço
	var b: Node = await open_battle(t, battle_state(["c339", "c010", "c002"], ["c001"]))
	var bm: BattleManager = b.battle
	var fire: CardInstance = t._find(bm.deck.hand, "c339")
	var mana0: int = bm.mana_available
	var hand0: int = bm.deck.hand.size()
	var undo0: int = (b._undo_stack as Array).size()
	t._check(fire != null and bm.can_kick(fire), "preparação: a Rajada de Fogo devia poder ir com Reforço (A5)")
	# 1) VOLTAR.
	b._on_hand_card_pressed(fire)
	await tree.process_frame
	var back_btn: Button = (t._find_named(b._modal, "KickerBack") as Button) if b._alive(b._modal) else null
	t._check(back_btn != null and back_btn.text == "VOLTAR" and back_btn.custom_minimum_size.y >= 48.0, "a janela do Reforço devia ter um VOLTAR com pelo menos 48 px (A5)")
	if back_btn != null:
		back_btn.pressed.emit()
	await tree.process_frame
	t._check(not b._alive(b._modal) and fire in bm.deck.hand and bm.deck.hand.size() == hand0 and bm.mana_available == mana0 and (b._undo_stack as Array).size() == undo0, "VOLTAR devia fechar o Reforço com a carta na mão, a mana igual e nada para desfazer (A5)")
	# 2) O retroceder faz o mesmo (já era assim; a A6 não o pode estragar).
	b._on_hand_card_pressed(fire)
	await tree.process_frame
	back(t)
	await tree.process_frame
	t._check(not b._alive(b._modal) and fire in bm.deck.hand and bm.mana_available == mana0, "o retroceder devia fechar o Reforço como VOLTAR (A5)")
	# 3) Um toque dentro da janela (no título) não a fecha; um toque fora é VOLTAR.
	b._on_hand_card_pressed(fire)
	await tree.create_timer(0.3).timeout   # a janela acaba de entrar (pop_in)
	var labels: Array = (b._modal as Node).find_children("*", "Label", true, false) if b._alive(b._modal) else []
	if not labels.is_empty():
		await tap(t, Test0190._center(labels[0] as Control))
	t._check(not labels.is_empty() and b._alive(b._modal), "um toque dentro da janela do Reforço não a devia fechar (A5)")
	await tap(t, Vector2(40, 40))
	t._check(not b._alive(b._modal) and fire in bm.deck.hand and bm.mana_available == mana0 and (b._undo_stack as Array).size() == undo0, "um toque fora da janela do Reforço devia ser como VOLTAR (A5)")
	if b._alive(b._modal):
		b._close_modal("")
	await tree.process_frame
	# 4) Arrastar a carta até à Arena abre a janela; o largar desse dedo não conta como toque fora.
	var hv: Control = b._hand_views.get(fire.uid)
	if hv != null:
		var hp := hv.get_global_rect().position + Vector2(hv.size.x * 0.5, hv.size.y - 6.0)
		t._mouse_move(hp)
		t._mouse_button(hp, true)
		await tree.process_frame
		await tree.process_frame
		t._mouse_move(hp + Vector2(0, -60))
		await tree.process_frame
		t._mouse_move(Vector2(640, 200))
		await tree.process_frame
		t._mouse_button(Vector2(640, 200), false)
		await tree.process_frame
		await tree.process_frame
	t._check(hv != null and b._alive(b._modal) and t._has_text(b._modal, "COM REFORÇO") and fire in bm.deck.hand, "arrastar a Rajada de Fogo até à Arena devia abrir o Reforço, e largar o dedo não o pode fechar (A5)")
	if b._alive(b._modal):
		b._close_modal("")
	await tree.process_frame
	# 5) JOGAR continua a jogar, sem Reforço.
	var cost: int = bm.effects.cost_of(fire)
	b._on_hand_card_pressed(fire)
	await tree.process_frame
	var plain: Button = (t._find_node(b._modal, func(n: Node) -> bool: return n is Button and (n as Button).text.begins_with("JOGAR")) as Button) if b._alive(b._modal) else null
	var had_plain := plain != null   # o JOGAR liberta-se com a janela
	if had_plain:
		plain.pressed.emit()
	await tree.process_frame
	t._check(had_plain and not (fire in bm.deck.hand) and bm.mana_available == mana0 - cost and not fire.kicked, "JOGAR devia continuar a jogar a carta, sem Reforço (A5)")
	await t._wait_until(func(): return not b._animating, 8000)
	await close_scene(t, b)
	GameState.clear_saved_run()
	print("  0.20.0 (A5): Reforço com VOLTAR; toque fora e retroceder = VOLTAR; arrastar e JOGAR como antes OK")

## A6: o retroceder do Android fecha a janela de cima (UiKit.window com on_close) e só essa, sem o ecrã de baixo reagir
## nesse toque. Nas Configurações, numa sub-página volta ao separador (como o VOLTAR) e na página principal fecha.
static func _test_0200_a6(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	# 1. Qualquer UiKit.window com on_close: o on_close da de cima, uma vez; a de baixo fica.
	var calls: Array = [0, 0]
	var low := _a6_window("Baixo", calls, 0)
	_a6_window("Cima", calls, 1)
	await tree.process_frame
	back(t)
	await tree.process_frame
	t._check(int(calls[0]) == 0 and int(calls[1]) == 1 and SceneRouter.top_overlay() == low, "o retroceder devia chamar o on_close só da janela de cima, uma vez (A6)")
	back(t)
	await tree.process_frame
	t._check(int(calls[0]) == 1 and int(calls[1]) == 1 and not SceneRouter.has_overlay(), "o 2.º retroceder devia fechar a janela de baixo (A6)")
	SceneRouter.close_overlays()
	await tree.process_frame
	# Fronteira: sem ✕ (sem on_close, como as recompensas e a escolha de carta) o retroceder segue as regras da janela.
	var plain := _a6_window("Sem fechar", calls, -1)
	await tree.process_frame
	back(t)
	await tree.process_frame
	t._check(SceneRouter.top_overlay() == plain, "uma janela sem ✕ (sem on_close) não devia fechar com o retroceder (A6)")
	SceneRouter.close_overlays()
	await tree.process_frame
	# B1: um ChoiceDialog buttons_only por cima de uma janela com on_close: o retroceder não fecha nenhuma das duas.
	var calls_b: Array = [0]
	var under := _a6_window("Baixo", calls_b, 0)
	var dlg := ChoiceDialog.open("Teste", "", [["OK", "ok"]])
	dlg.buttons_only = true
	await tree.process_frame
	back(t)
	await tree.process_frame
	t._check(int(calls_b[0]) == 0 and SceneRouter.top_overlay() == dlg and is_instance_valid(under) and not under.is_queued_for_deletion(), "o retroceder com um ChoiceDialog buttons_only por cima de uma janela não devia fechar nenhuma das duas (A6/B1)")
	SceneRouter.close_overlays()
	await tree.process_frame
	# 2. As janelas da especificação.
	GameState.new_run("deck01", 20601)
	var keep_q = GameState.progress.get("first_questions", false)
	var keep_news = GameState.progress.get("news_seen", "")   # o open_first_run também marca as Novidades como vistas
	var went: Array = [false]
	var openers: Array = [
		["FirstRun", func() -> Control: return SessionWindows.open_first_run()],
		["ResumeSummary", func() -> Control: return SessionWindows.open_resume(func(): went[0] = true)],
		["RulesRefresher", func() -> Control: return SessionWindows.open_rules()],
		["BreakReminder", func() -> Control: return SceneRouter.break_reminder("Teste")],
		["Jukebox", func() -> Control: return Jukebox.open()],
		["DeckCosmetics", func() -> Control: return DeckCosmetics.open("deck01")],
	]
	for op in openers:
		var w: Control = (op[1] as Callable).call()
		await tree.process_frame
		var right := String(w.name) == String(op[0])
		back(t)
		var same_frame := SceneRouter.has_overlay()   # o ecrã por baixo não reage neste toque
		var gone := w.is_queued_for_deletion() or w.has_meta("closing")
		await tree.process_frame
		t._check(right and gone and same_frame, "o retroceder devia fechar a janela %s, com o ecrã de baixo sem reagir nesse toque (A6)" % op[0])
		SceneRouter.close_overlays()
		await tree.process_frame
	t._check(not bool(went[0]), "fechar «Onde ficaste» com o retroceder não devia continuar a run (A6)")
	GameState.progress["first_questions"] = keep_q
	GameState.progress["news_seen"] = keep_news
	GameState.save_progress()
	GameState.clear_saved_run()
	# 3. RUNS APAGADAS por cima do menu: fecha só a janela. O menu fica numa página onde um retroceder que lhe chegasse
	# mudava de página (no início sairia do jogo) e não pode mudar nesse toque.
	Storage.crashed_before = false
	var m: Node = load("res://scenes/main/Main.tscn").instantiate()
	t.add_child(m)
	await tree.process_frame
	await tree.process_frame
	SceneRouter.close_overlays()
	await tree.process_frame
	(m.get_node("%Modes") as Button).pressed.emit()
	await tree.process_frame
	m.call("_open_trash")
	await tree.process_frame
	var trash := SceneRouter.top_overlay()
	var is_trash := trash != null and String(trash.name) == "TrashWindow"
	back(t)
	var trash_gone := is_trash and (trash.is_queued_for_deletion() or trash.has_meta("closing"))
	await tree.process_frame
	t._check(trash_gone and m.current_page() == "modes", "o retroceder devia fechar só as RUNS APAGADAS: o menu por baixo não muda de página nesse toque (A6)")
	await close_scene(t, m)
	# 4. Configurações: numa sub-página o retroceder volta ao separador (como o VOLTAR); na página principal fecha.
	for page in ["_on_backups_open", "_on_storage_open", "_show_code_panel", "_on_import_open"]:
		var sm := SettingsMenu.open()
		var closed_n: Array = [0]
		sm.closed.connect(func(): closed_n[0] += 1)
		await tree.process_frame
		if page == "_show_code_panel":
			sm._show_code_panel("ZS1:teste")   # a página do EXPORTAR, sem mexer na área de transferência
		else:
			sm.call(page)
		await tree.process_frame
		var in_sub := sm._content.get_node_or_null("Back") != null
		back(t)
		await tree.process_frame
		var alive := is_instance_valid(sm)
		var to_tab := alive and SceneRouter.top_overlay() == sm and int(closed_n[0]) == 0 and sm._tab == "game" and t._find_named(sm, "Storage") != null
		t._check(in_sub and to_tab, "numa sub-página das Configurações (%s), o retroceder devia voltar ao separador, como o VOLTAR (A6)" % page)
		var closing := not alive
		if alive:
			back(t)
			closing = sm.is_queued_for_deletion() or sm.has_meta("closing")
		await tree.process_frame
		t._check(closing and int(closed_n[0]) == 1, "na página principal das Configurações, o retroceder devia fechar como hoje (A6)")
		SceneRouter.close_overlays()
		await tree.process_frame
	# Fronteira: a Jukebox aberta por cima das Configurações (que tratam o retroceder sozinhas): fecha só a Jukebox.
	var sm2 := SettingsMenu.open()
	var jb := Jukebox.open()
	await tree.process_frame
	back(t)
	var jb_gone := jb.is_queued_for_deletion() or jb.has_meta("closing")
	await tree.process_frame
	t._check(jb_gone and is_instance_valid(sm2) and SceneRouter.top_overlay() == sm2, "com a Jukebox por cima das Configurações, o retroceder devia fechar só a Jukebox (A6)")
	SceneRouter.close_overlays()
	await tree.process_frame
	print("  0.20.0 (A6): o retroceder fecha só a janela de cima (UiKit.window, as 7 janelas, RUNS APAGADAS sem mexer no menu) e as sub-páginas das Configurações voltam ao separador OK")

## B7: o último turno à vista (letreiro «ÚLTIMO TURNO» + «faltam X» durante ≥ 1,2 s, bolinha vermelha) e o ATACAR que
## diz a verdade («NÃO CHEGA», «MORRES», a vermelho e a caber, também em inglês com o texto no máximo). Em run, um ataque
## que perde a run pede um 2.º toque em 3 s, antes do aviso da mana, também numa batalha retomada; nunca noutros turnos,
## com ataque letal, na Fuga, na Arena nem num enigma.
static func _test_0200_b7(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	var old_warn: bool = Settings.warn_mana   # repor à mão: o reset_options punha-o a true (LEGACY_DEFAULTS)
	Settings.warn_mana = false
	Settings.set_opt("short_banners", true, false)   # o letreiro do último turno fica 1,2 s mesmo assim
	# --- A. Do turno 4 para o 5 (o último), sem atacantes; com canalizações, uma poção que serve e o patrono. ---
	GameState.new_run("deck01", 20071)
	GameState.clear_saved_run()
	GameState.relic_ids.clear()
	GameState.consumables.clear()
	GameState.consumables.append("potion_fury")    # serve já: entra no aviso
	GameState.consumables.append("potion_giant")   # precisa de criaturas na Arena: não entra
	GameState.set_planeswalker("pw_red")
	var b: Node = await open_battle(t, battle_state(["c002"], [], 4, 5))
	var bm: BattleManager = b.battle
	t._check(not String(b.end_turn_btn.text).contains("NÃO CHEGA") and b._turn_pips.get("last") != true,
		"antes do último turno, o ATACAR e as bolinhas deviam ficar como estavam (B7)")
	var seen: Array = []
	var on_turn := func(_n: int) -> void: seen.append([String(b._banner_full), int(b._banner_lock_until) - Time.get_ticks_msec()])
	await t._wait_until(func(): return Time.get_ticks_msec() >= int(b._banner_lock_until), 3000)   # o «ANTE 1 / TURNO 4» já saiu (F7: senão o «ÚLTIMO TURNO» espera por ele)
	EventBus.turn_started.connect(on_turn)
	b._on_end_turn()
	t._check(bm.resolving or bm.finished or bm.turn == 5, "fora do último turno, um só toque no ATACAR devia atacar (B7)")
	await t._wait_until(func(): return bm.turn == 5 and not bool(b._animating), 15000)
	await tree.process_frame
	EventBus.turn_started.disconnect(on_turn)
	var want: String = "ÚLTIMO TURNO\n" + String(TranslationServer.translate("faltam %s")) % b._num(int(bm.enemy.hp))
	var got: Array = ["", 0]
	if not seen.is_empty():
		got = seen[seen.size() - 1]
	t._check(String(got[0]) == want and int(got[1]) >= 1200,
		"no início do último turno, o letreiro devia dizer «%s» e ficar pelo menos 1,2 s, mesmo com letreiros curtos (B7; foi «%s», %d ms)" % [want.replace("\n", " / "), String(got[0]).replace("\n", " / "), int(got[1])])
	bm.enemy2 = {"id": "test2", "hp": 7, "max_hp": 7}   # C1: na Dupla, a vida que falta soma os dois
	var pair_left: int = int(bm.call("hp_left")) if bm.has_method("hp_left") else -1
	bm.enemy2 = {}
	t._check(pair_left == int(bm.enemy.hp) + 7, "na Dupla, a vida que falta ao inimigo (BattleManager.hp_left) devia somar os dois (B7/C1)")
	var kill_one: int = int(bm.enemy.hp)   # derruba o alvo; o 2.º fica de pé e, com 99 de ataque, a soma dos dois «matava»
	bm.enemy2 = {"id": "test2", "hp": 7, "max_hp": 7, "attack": 99}
	var pair_risk: String = b._attack_risk(kill_one, bm.counter_plan())
	bm.enemy2 = {}
	var solo_risk: String = b._attack_risk(kill_one, bm.counter_plan())
	t._check(pair_risk == "short" and solo_risk == "",
		"no último turno da Dupla, um golpe que só derruba o 1.º inimigo devia dar «NÃO CHEGA» (não «LETAL» nem «MORRES»); sozinho é letal (B7/C1; há «%s» e «%s»)" % [pair_risk, solo_risk])
	var fake := Cascade.new()   # o mesmo golpe no cálculo: o resto do ecrã (LETAL verde, «não há contra-ataque») também não o deve dar por letal
	fake.power = kill_one
	bm.enemy2 = {"id": "test2", "hp": 7, "max_hp": 7, "attack": 99}
	var pair_calc: bool = b._show_calc(fake, true)
	bm.enemy2 = {}
	var solo_calc: bool = b._show_calc(fake, true)
	b._refresh_preview()
	t._check(not pair_calc and solo_calc, "na Dupla, o cálculo não devia dar por letal um golpe que só derruba o alvo (o outro contra-ataca); sozinho devia (B7/C1)")
	t._check(b._turn_pips.get("last") == true, "no último turno, a bolinha desse turno devia ficar vermelha (TurnPips.last) (B7)")
	var txt: String = b.end_turn_btn.text
	t._check(txt == "ATACAR  ·  NÃO CHEGA" and b.end_turn_btn.get_theme_stylebox("normal") == b.get("_danger_style") and _b7_fits(b),
		"no último turno, com um ataque que não chega, o ATACAR devia dizer «ATACAR  ·  NÃO CHEGA», a vermelho e a caber (B7; há «%s»)" % txt)
	bm.extra_turns += 1   # como o Pergaminho do Tempo a meio do último turno
	b._refresh_preview()
	var extra_txt: String = b.end_turn_btn.text
	var extra_pip = b._turn_pips.get("last")
	bm.extra_turns -= 1
	b._refresh_preview()
	t._check(not extra_txt.contains("NÃO CHEGA") and extra_pip != true and String(b.end_turn_btn.text) == "ATACAR  ·  NÃO CHEGA",
		"um turno extra a meio do último turno (Pergaminho do Tempo) devia tirar o «NÃO CHEGA» e a bolinha vermelha, e tirá-lo devia repô-los (B7)")
	GameState.puzzle_id = "training"   # o boneco do Treino tem vida infinita: nunca «NÃO CHEGA»
	b._refresh_preview()
	var dummy_txt: String = b.end_turn_btn.text
	GameState.puzzle_id = ""
	b._refresh_preview()
	t._check(not dummy_txt.contains("NÃO CHEGA"), "no Treino com o boneco o ATACAR não devia dizer «NÃO CHEGA» (B7)")
	_b7_lang(true)
	b._refresh_preview()
	var en_txt: String = b.end_turn_btn.text
	var en_fits := _b7_fits(b)
	_b7_lang(false)
	b._refresh_preview()
	t._check(en_txt == "ATTACK  ·  NOT ENOUGH" and en_fits, "em inglês e com o texto no máximo, o ATACAR devia dizer «ATTACK  ·  NOT ENOUGH» e caber no botão, sem «…» (B7/C3; há «%s»)" % en_txt)
	var t0 := Time.get_ticks_msec()
	b._on_end_turn()
	var first_ok: bool = not bm.resolving and not bm.finished and b.get("_attack_armed") == true
	var armed_txt: String = b.end_turn_btn.text
	var armed_fits := _b7_fits(b)
	await t._wait_until(func(): return _b7_warning(t, b) != "", 2500)
	var warn := _b7_warning(t, b)
	t._check(first_ok and armed_txt == "toca outra vez para atacar" and armed_fits,
		"no último turno (em run), o 1.º toque no ATACAR não devia atacar e o botão devia dizer «toca outra vez para atacar», a caber (B7; há «%s»)" % armed_txt)
	t._check(warn.begins_with("Este ataque não chega: perdes a run.") and warn.contains("3 canalizações") and warn.contains("Elixir da Fúria")
		and warn.contains("o patrono") and not warn.contains("Poção do Gigante"),
		"o 1.º toque devia avisar logo «Este ataque não chega: perdes a run.» e juntar só o que ainda se pode usar (canalizações, poções que servem, patrono) (B7; há «%s»)" % warn)
	await tree.create_timer(maxf(0.1, 3.3 - float(Time.get_ticks_msec() - t0) / 1000.0)).timeout
	t._check(b.get("_attack_armed") != true and String(b.end_turn_btn.text) == "ATACAR  ·  NÃO CHEGA" and not bm.resolving and not bm.finished,
		"passados 3 s sem o 2.º toque, o ATACAR devia voltar a «NÃO CHEGA», sem atacar (B7)")
	b._on_end_turn()
	var rearmed: bool = b.get("_attack_armed") == true and not bm.resolving and not bm.finished
	b._on_end_turn()
	t._check(rearmed and (bm.resolving or bm.finished), "depois dos 3 s, o 1.º toque devia voltar a pedir confirmação e o 2.º (dentro dos 3 s) devia atacar (B7)")
	await t._wait_until(func(): return bm.finished, 15000)
	await close_scene(t, b)
	GameState.clear_saved_run()
	# --- B. «MORRES»: turno 2 de 5, 40 de ataque contra 3 de vida, Arena vazia, sem Coração de Vidro, nada por usar. ---
	GameState.new_run("deck01", 20072)
	GameState.clear_saved_run()
	GameState.relic_ids.clear()
	GameState.consumables.clear()
	GameState.planeswalker = {}
	GameState.death_save_used = true   # nem a relíquia nem o talento Segundo Fôlego salvam
	GameState.player_hp = 3
	Settings.warn_mana = true          # 2 criaturas na mão e 6 de mana: o aviso da mana também quer aparecer
	var d: Node = await open_battle(t, battle_state(["c001", "c003"], [], 2, 5, 6, {"attack": 40}))
	var dm: BattleManager = d.battle
	dm.discards_left = 0
	d._refresh_all()
	var die_txt: String = d.end_turn_btn.text
	t._check(die_txt == "ATACAR  ·  MORRES" and d.end_turn_btn.get_theme_stylebox("normal") == d.get("_danger_style") and _b7_fits(d) and d._turn_pips.get("last") != true,
		"com o contra-ataque previsto a matar (fora do último turno), o ATACAR devia dizer «ATACAR  ·  MORRES», a vermelho e a caber (B7; há «%s»)" % die_txt)
	d._on_end_turn()
	var only_warned: bool = d.get("_attack_armed") == true and not dm.resolving and not bool(d._alive(d._modal))
	await t._wait_until(func(): return _b7_warning(t, d) != "", 2500)
	var d_warn := _b7_warning(t, d)
	d._on_end_turn()
	var mana_asked: bool = bool(d._alive(d._modal)) and t._has_text(d._modal, "Atacar sem gastar a mana?")
	if bool(d._alive(d._modal)):
		d._close_modal("no")
	await tree.process_frame
	t._check(d_warn == "Este contra-ataque mata-te: perdes a run.",
		"com «MORRES», o aviso devia ser só «Este contra-ataque mata-te: perdes a run.» (sem canalizações, poções nem patrono por usar) (B7; há «%s»)" % d_warn)
	t._check(only_warned and mana_asked and not dm.resolving and String(d.end_turn_btn.text) == "ATACAR  ·  MORRES",
		"a confirmação do ATACAR devia vir antes do aviso da mana: o 1.º toque só avisa e o 2.º abre «Atacar sem gastar a mana?», que continua igual; ao dizer que não, o ATACAR volta a «MORRES» (B7; há «%s»)" % String(d.end_turn_btn.text))
	Settings.warn_mana = false
	_b7_lang(true)
	d._refresh_preview()
	var en_die: String = d.end_turn_btn.text
	var en_die_fits := _b7_fits(d)
	d._on_end_turn()   # 1.º toque: só muda o botão
	var en_armed: String = d.end_turn_btn.text
	var en_armed_fits := _b7_fits(d)
	_b7_lang(false)
	d._refresh_preview()
	var pt_armed: String = d.end_turn_btn.text
	t._check(en_die == "ATTACK  ·  YOU DIE" and en_die_fits and en_armed == "tap again to attack" and en_armed_fits and pt_armed == "toca outra vez para atacar",
		"em inglês e com o texto no máximo, o ATACAR devia dizer «ATTACK  ·  YOU DIE» e, ao 1.º toque, «tap again to attack», a caber, sem «…» (B7/C3; há «%s» e «%s»)" % [en_die, en_armed])
	GameState.death_save_used = false
	GameState.add_boss_relic("relic_glass_heart")
	d._refresh_preview()
	var heart_txt: String = d.end_turn_btn.text
	t._check(not heart_txt.contains("MORRES") and d.get("_attack_armed") != true and d.end_turn_btn.get_theme_stylebox("normal") != d.get("_danger_style"),
		"com o Coração de Vidro por usar, o contra-ataque não mata: nem «MORRES» nem confirmação (B7; há «%s»)" % heart_txt)
	GameState.boss_relics.clear()
	GameState.death_save_used = true
	GameState.arena_battle = true   # na Arena perder custa vida, nunca a run
	d._refresh_preview()
	d._on_end_turn()
	t._check(dm.resolving or dm.finished, "na Arena (perder não acaba a run) o ATACAR não devia pedir o 2.º toque (B7)")
	await t._wait_until(func(): return dm.finished or not dm.resolving, 15000)
	GameState.arena_battle = false
	await close_scene(t, d)
	GameState.death_save_used = false
	GameState.clear_saved_run()
	# --- C. Fuga no turno 4 de 4: não há último turno (ganha-se a sobreviver). ---
	GameState.new_run("deck01", 20073)
	GameState.clear_saved_run()
	GameState.relic_ids.clear()
	var f: Node = await open_battle(t, battle_state(["c002"], [], 4, 4, 6, {"objective": "escape"}))
	var fm: BattleManager = f.battle
	var f_txt: String = f.end_turn_btn.text
	t._check(fm.objective == "escape" and fm.turns_left() == 0 and not f_txt.contains("NÃO CHEGA") and f._turn_pips.get("last") != true
		and not String(f._banner_full).contains("ÚLTIMO TURNO"),
		"na Fuga não há último turno: nem «NÃO CHEGA», nem bolinha vermelha, nem «ÚLTIMO TURNO» (B7; há «%s»)" % f_txt)
	f._on_end_turn()
	t._check(fm.resolving or fm.finished, "na Fuga, um só toque no ATACAR devia atacar (B7)")
	await t._wait_until(func(): return fm.finished, 15000)
	await close_scene(t, f)
	GameState.clear_saved_run()
	# --- D. Fora de run (enigma 1, sem jogadas: o ataque não chega no único turno): ataca logo. ---
	GameState.new_run("deck01", 20074)
	GameState.clear_saved_run()
	GameState.pending_battle = {}
	GameState.puzzle_id = "p1"
	var p: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	t.add_child(p)
	EventBus.battle_ended.disconnect(p._on_battle_ended)
	await t._wait_until(func(): return not bool(p._animating), 8000)
	await tree.process_frame
	var pm: BattleManager = p.battle
	t._check(pm.puzzle and pm.turns_left() == 0 and pm.preview_attack().net_total() < int(pm.enemy.hp),
		"pré-condição: o enigma 1 sem jogadas está no único turno e o ataque não chega (B7)")
	p._on_end_turn()
	t._check(pm.resolving or pm.finished, "fora de run (enigma), o 1.º toque no ATACAR devia atacar logo, sem confirmação (B7)")
	await t._wait_until(func(): return pm.finished, 15000)
	await close_scene(t, p)
	GameState.puzzle_id = ""
	GameState.clear_saved_run()
	# --- E. Último turno com um ataque letal (batalha retomada): «ÚLTIMO TURNO» no letreiro, «LETAL» e 1 toque ataca. ---
	GameState.new_run("deck01", 20075)
	GameState.clear_saved_run()
	GameState.relic_ids.clear()
	var e: Node = await open_battle(t, battle_state(["c002"], ["c001"], 5, 5, 6, {"hp": 1, "max_hp": 1}))
	var em: BattleManager = e.battle
	var e_txt: String = e.end_turn_btn.text
	t._check(String(e._banner_full).contains("ÚLTIMO TURNO"),
		"ao retomar uma batalha no último turno, o letreiro devia dizer «ÚLTIMO TURNO» (B7; foi «%s»)" % String(e._banner_full).replace("\n", " / "))
	t._check(e_txt.contains("LETAL") and not e_txt.contains("NÃO CHEGA") and e.end_turn_btn.get_theme_stylebox("normal") != e.get("_danger_style"),
		"no último turno com um ataque letal, o ATACAR devia continuar verde, com «LETAL» (B7; há «%s»)" % e_txt)
	e._on_end_turn()
	t._check((em.resolving or em.finished) and e.get("_attack_armed") != true, "no último turno com um ataque letal, um só toque devia atacar (B7)")
	await t._wait_until(func(): return em.finished, 15000)
	await close_scene(t, e)
	GameState.clear_saved_run()
	# --- F. Batalha retomada (CONTINUAR) no último turno, com um ataque que não chega: como numa batalha nova (C2). ---
	GameState.new_run("deck01", 20076)
	GameState.clear_saved_run()
	GameState.relic_ids.clear()
	GameState.pending_battle = battle_state(["c002"], [], 5, 5)   # o open_battle à mão: o letreiro sai no _ready
	var r: Node = load("res://scenes/battle/Battle.tscn").instantiate()
	t.add_child(r)
	var r_hold: int = int(r._banner_lock_until) - Time.get_ticks_msec()
	var r_banner := String(r._banner_full)
	EventBus.battle_ended.disconnect(r._on_battle_ended)
	await t._wait_until(func(): return not r._animating, 8000)
	await tree.process_frame
	var rm: BattleManager = r.battle
	var r_want: String = "ÚLTIMO TURNO\n" + String(TranslationServer.translate("ANTE %d")) % GameState.ante + "  ·  " \
		+ String(TranslationServer.translate("faltam %s")) % r._num(rm.hp_left())
	t._check(r_banner == r_want and r_hold >= 1200,
		"ao retomar no último turno, o letreiro devia ser o de uma batalha nova, «%s», durante pelo menos 1,2 s (B7/C2; foi «%s», %d ms)" % [r_want.replace("\n", " / "), r_banner.replace("\n", " / "), r_hold])
	r._on_end_turn()
	var r_armed: bool = r.get("_attack_armed") == true and not rm.resolving and not rm.finished
	var r_txt: String = r.end_turn_btn.text
	r._on_end_turn()
	t._check(r_armed and r_txt == "toca outra vez para atacar" and (rm.resolving or rm.finished),
		"ao retomar uma batalha no último turno com um ataque que não chega, o 1.º toque devia só avisar e o 2.º atacar (B7/C2; botão «%s»)" % r_txt)
	await t._wait_until(func(): return rm.finished, 15000)
	await close_scene(t, r)
	GameState.clear_saved_run()
	# Limpar
	Settings.warn_mana = old_warn
	Settings.reset_options(["short_banners"], false)
	GameState.consumables.clear()
	GameState.planeswalker = {}
	print("  0.20.0 (B7): último turno (letreiro ≥ 1,2 s, bolinha vermelha, também ao retomar), NÃO CHEGA e MORRES a vermelho e a caber em inglês com o texto no máximo, 2 toques em 3 s só em run e antes do aviso da mana, Coração de Vidro, turno extra, Dupla, Treino, Fuga, Arena, enigma e LETAL OK")

## O ATACAR cabe no botão (o texto inteiro, sem «…»), com a letra que tem agora; o Test0190.scan_overflow concorda (C3).
static func _b7_fits(b: Node) -> bool:
	var btn: Button = b.end_turn_btn
	var sb := btn.get_theme_stylebox("normal")
	var room := btn.size.x - sb.get_margin(SIDE_LEFT) - sb.get_margin(SIDE_RIGHT)
	return btn.get_theme_font("font").get_string_size(btn.text, HORIZONTAL_ALIGNMENT_LEFT, -1, btn.get_theme_font_size("font_size")).x <= room + 0.5 \
		and Test0190.scan_overflow(btn).is_empty() and not btn.text.contains("…")

## C3: inglês com o texto no máximo (Letra grande e «Texto dos menus» a 1,3), ou português com as duas opções repostas.
static func _b7_lang(en: bool) -> void:
	Settings.language = "en" if en else "pt"
	if en:
		Settings.set_opt("large_text", true, false)
		Settings.set_opt("menu_text", 1.3, false)
	else:
		Settings.reset_options(["large_text", "menu_text"], false)
	Settings.apply()

## O texto do aviso do 1.º toque (o Label que diz «perdes a run»), ou "" se não estiver no ecrã.
static func _b7_warning(t: Node, b: Node) -> String:
	var l: Node = t._find_node(b, func(n: Node) -> bool: return n is Label and (n as Label).text.contains("perdes a run"))
	return (l as Label).text if l != null else ""

## B10: tira o aviso do topo da batalha e esvazia a fila (cada parte do teste começa do zero).
static func _b10_clear(t: Node, b: Node) -> void:
	b._warn_queue.clear()
	if b._alive(b._notice):
		b._notice.queue_free()
	await t.get_tree().process_frame

## B10: os avisos da batalha leem-se. Usam o «tempo dos avisos» (também «até tocares») e o clima também; aparecem
## em fila; o resumo começa por «Levaste» e não leva as linhas que são tuas; o golpe carregado entra na fila; tocar
## no resumo abre o histórico em «Só o inimigo» (C6: só o resumo e o golpe carregado apanham o toque). Fronteiras: a
## resposta a um toque aparece logo (ataque automático e o 1.º toque do ATACAR da B7) e, em inglês, um resumo
## comprido cabe no ecrã.
static func _test_0200_b10(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	SceneRouter._toast_queue.clear()   # (os avisos de outros testes, no modo «até tocares», ficariam por cima do clima)
	for i in SceneRouter._toast_slots.size():
		var old = SceneRouter._toast_slots[i]
		if old != null and is_instance_valid(old):
			(old as Node).queue_free()
		SceneRouter._toast_slots[i] = null
	var old_tips := Settings.tips_enabled
	Settings.tips_enabled = false   # nenhuma dica empurra os avisos para baixo
	Settings.reset_options(["toast_time", "assist_rewind"], false)
	GameState.new_run("deck01", 20100)
	GameState.relic_ids.clear()
	GameState.clear_saved_run()
	var b: Node = await open_battle(t, battle_state(["c001", "c002"]))
	var bm: BattleManager = b.battle
	if b.get("_warn_queue") == null:
		t._check(false, "a batalha devia ter a fila de avisos (Battle._warn_queue) (B10)")
		await close_scene(t, b)
		GameState.clear_saved_run()
		Settings.tips_enabled = old_tips
		return
	await _b10_clear(t, b)
	# 1. O resumo do turno dele: «Levaste N» primeiro, até 3 linhas, sem as linhas tuas; o golpe carregado vai para a fila.
	var took := TranslationServer.translate("Levaste %d de dano.") % 7
	b._enemy_log_from = b._history.size()
	b._enemy_turn_logging = true
	b._log("Teste curou-se!")
	b._log(took)
	b._log("Teste destruiu a tua criatura mais forte!")
	b._log("Teste carrega um golpe!")
	Settings.set_opt("assist_rewind", true, false)
	bm.turn = 2
	bm.last_mana_saved = 2
	bm.charge_mult = 1.5
	b._on_turn_started(2)
	await tree.process_frame
	var head := TranslationServer.translate("No turno dele: ")
	var shown := String((b._notice.get_child(0) as Label).text) if b._alive(b._notice) else ""
	t._check(b._enemy_recap.size() >= 1 and String(b._enemy_recap[0]) == took, "no resumo do turno dele, «Levaste N» devia vir em 1.º lugar (B10)")
	t._check(shown.begins_with(head + took), "o aviso do turno dele devia começar por «Levaste» (B10)")
	t._check(shown.trim_prefix(head).split("  ·  ").size() == 3, "o aviso do turno dele devia mostrar até 3 linhas (B10)")
	var enemy_only := String(b.history_text("enemy"))
	for line in [TranslationServer.translate("Mana guardada: +%d neste turno.") % 2, TranslationServer.translate("↺ Modo assistido: podes rebobinar o turno anterior na pausa (uma vez por batalha).")]:
		t._check(not (line in b._enemy_recap) and not enemy_only.contains(line), "«%s» é tua: não devia entrar no resumo nem em «Só o inimigo» (B10)" % line)
	t._check(enemy_only.contains(took), "«Levaste» devia estar em «Só o inimigo» (B10)")
	var charge := TranslationServer.translate("%s carregou um golpe: este turno ataca com ×%s!") % [TranslationServer.translate(String(bm.enemy.name)), b._fmt_mult(1.5)]
	t._check(b._warn_queue.size() == 1 and String(b._warn_queue[0][0]) == charge, "o golpe carregado devia entrar na fila a seguir ao resumo, sem o substituir (B10)")
	t._check(b._alive(b._notice) and b._notice.mouse_filter == Control.MOUSE_FILTER_STOP and b._warn_queue.size() == 1 \
		and (b._warn_queue[0] as Array).size() > 4 and bool(b._warn_queue[0][4]), "o resumo e o golpe carregado deviam apanhar o toque (abrem o histórico) (B10/C6)")
	bm.charge_mult = 1.0
	bm.last_mana_saved = 0
	Settings.reset_options(["assist_rewind"], false)
	# 2. Dois avisos seguidos: o 2.º espera que o 1.º saia e não o apaga; um aviso que não é do inimigo não apanha o toque (C6).
	await _b10_clear(t, b)
	var t0 := Time.get_ticks_msec()
	b._warn("Aviso A", UiKit.GOLD, 0.8)
	b._warn("Aviso B", UiKit.GOLD, 0.8)
	await tree.process_frame
	var pa: Control = b._notice
	t._check(t._contains_text(pa, "Aviso A") and not t._contains_text(b, "Aviso B") and b._warn_queue.size() == 1, "com dois avisos seguidos, o 1.º devia ficar e o 2.º esperar na fila (B10)")
	t._check(pa.mouse_filter == Control.MOUSE_FILTER_IGNORE, "um aviso que não é do turno do inimigo não devia apanhar o toque (não tapa as relíquias) (B10/C6)")
	var got_b: bool = await t._wait_until(func(): return b._alive(b._notice) and t._contains_text(b._notice, "Aviso B"), 4000)
	t._check(got_b and not b._alive(pa) and Time.get_ticks_msec() - t0 >= 1000, "o 2.º aviso devia aparecer depois de o 1.º sair (B10)")
	# 3. A fila é curta e não guarda repetidos.
	await _b10_clear(t, b)
	for i in 6:
		b._warn("Fila %d" % i, UiKit.GOLD, 0.8)
	b._warn("Fila 0", UiKit.GOLD, 0.8)
	b._warn("Fila 2", UiKit.GOLD, 0.8)
	t._check(b._warn_queue.size() == b.WARN_QUEUE_MAX and String(b._warn_queue[0][0]) == "Fila 1", "a fila devia ser curta (%d à espera) e sem repetidos (B10)" % b.WARN_QUEUE_MAX)
	b._warn("Resposta cheia", UiKit.GOLD, 0.8, true)   # o «Fila 0» do ecrã volta à frente; sai o último a chegar
	t._check(b._warn_queue.size() == b.WARN_QUEUE_MAX and String(b._warn_queue[0][0]) == "Fila 0" and String(b._warn_queue[-1][0]) == "Fila 2",
		"com a fila cheia, a resposta a um toque devia pôr à frente o aviso que estava no ecrã sem passar de %d à espera (B10)" % b.WARN_QUEUE_MAX)
	# 4. A resposta a um toque (now) aparece logo: o aviso de informação volta à frente da fila, a resposta a um toque não.
	await _b10_clear(t, b)
	b._warn("Resumo de teste", Color(0.75, 0.6, 1.0), 3.0)
	b._start_auto_end()
	b.cancel_auto_end()   # (o tempo de 1 s passa nas partes seguintes, com a batalha ainda aberta)
	var auto := TranslationServer.translate("Sem jogadas: ataque automático em 1 s (toca para cancelar).")
	t._check(t._contains_text(b._notice, auto) and b._warn_queue.size() == 1 and String(b._warn_queue[0][0]) == "Resumo de teste", "o aviso do ataque automático devia aparecer logo e o resumo voltar à fila (B10)")
	t._check(b._notice.mouse_filter == Control.MOUSE_FILTER_IGNORE, "a resposta a um toque não devia apanhar o toque (B10/C6)")
	b._warn(TranslationServer.translate("Não há jogadas para desfazer."), UiKit.TEXT_DIM, 1.4, true)
	t._check(b._warn_queue.size() == 1, "uma resposta a um toque, substituída por outra, não devia voltar à fila (B10)")
	var p_undo: Control = b._notice
	b._warn(TranslationServer.translate("Não há jogadas para desfazer."), UiKit.TEXT_DIM, 1.4, true)   # (o 1.º toque da B7 depois dos 3 s)
	t._check(b._alive(b._notice) and b._notice != p_undo and t._contains_text(b._notice, TranslationServer.translate("Não há jogadas para desfazer.")) \
		and b._warn_queue.size() == 1, "a mesma resposta a um toque, outra vez, devia substituir a do ecrã e recomeçar o tempo (B10)")
	# 5. «Tempo dos avisos» longo: o aviso e o do clima ficam 5 s.
	await _b10_clear(t, b)
	Settings.set_opt("toast_time", "long", false)
	bm.climate = "aether_tide"
	b._climate_told.clear()
	var t1 := Time.get_ticks_msec()
	b._warn("Aviso longo", UiKit.GOLD, 1.0)
	b._climate_turn_notices(1)
	await tree.create_timer(4.0).timeout   # no «normal» já teriam saído os dois (1,45 s e 3,05 s)
	t._check(b._alive(b._notice) and t._contains_text(b._notice, "Aviso longo"), "com o tempo dos avisos longo, o aviso devia durar o tempo longo (B10)")
	t._check(b._alive(b._climate_notice_node), "com o tempo dos avisos longo, o aviso do clima devia durar o tempo longo (B10)")
	var gone: bool = await t._wait_until(func(): return not b._alive(b._notice), 4000)
	t._check(gone and Time.get_ticks_msec() - t1 >= 5000, "o aviso longo devia sair só depois do tempo longo (B10)")
	# 6. «Até tocares»: o resumo e o do clima ficam no ecrã e o aviso seguinte espera. Tocar no resumo fecha-o e abre o
	#    histórico em «Só o inimigo»; tocar no aviso seguinte só o fecha (senão ficava preso); tocar no do clima fecha-o.
	await _b10_clear(t, b)
	Settings.set_opt("toast_time", "tap", false)
	b._climate_told.clear()
	b._enemy_log_from = b._history.size()
	b._enemy_turn_logging = true
	b._log("Toca-me")
	b._show_enemy_recap()
	b._warn("Fecha-me", UiKit.GOLD, 0.8)
	b._climate_turn_notices(1)
	await tree.create_timer(1.6).timeout
	var pn: Control = b._notice
	var cn: Control = b._climate_notice_node
	t._check(b._alive(pn) and t._contains_text(pn, "Toca-me") and b._warn_queue.size() == 1 and b._alive(cn) and cn.mouse_filter == Control.MOUSE_FILTER_STOP,
		"com «até tocares», o resumo e o aviso do clima deviam ficar até lhes tocar, e o aviso seguinte esperar (B10)")
	await tap(t, Test0190._center(pn))
	await tree.process_frame
	var h := SceneRouter.top_overlay()
	var opened: bool = h != null and h.name == "HistoryLog"
	var chip: Button = (t._find_named(h, "Chip_enemy") as Button) if opened else null
	var lines: Label = (t._find_named(h, "Lines") as Label) if opened else null
	t._check(opened and chip != null and chip.button_pressed and lines != null and lines.text == String(b.history_text("enemy")), "tocar no resumo devia abrir o histórico no filtro «Só o inimigo» (B10)")
	t._check(not b._alive(pn), "tocar no resumo devia fechá-lo (B10)")
	SceneRouter.close_overlays()
	await tree.process_frame
	await tree.process_frame
	var pf: Control = b._notice
	var pf_ok: bool = b._alive(pf) and t._contains_text(pf, "Fecha-me") and pf.mouse_filter == Control.MOUSE_FILTER_STOP
	if pf_ok:
		await tap(t, Test0190._center(pf))
	t._check(pf_ok and not b._alive(pf) and SceneRouter.top_overlay() == null,
		"com «até tocares», o aviso seguinte devia entrar quando o resumo sai e fechar-se com um toque, sem abrir o histórico (B10/C6)")
	await tap(t, Test0190._center(cn))
	t._check(not b._alive(cn), "com «até tocares», tocar no aviso do clima devia fechá-lo (B10)")
	# C6: no «até tocares», a resposta a um toque não apanha o toque e sai sozinha; o aviso seguinte não fica preso atrás dela.
	b._warn("Resposta", UiKit.GOLD, 0.8, true)
	b._warn("Depois", UiKit.GOLD, 0.8)
	await tree.process_frame
	var pr: Control = b._notice
	t._check(b._alive(pr) and t._contains_text(pr, "Resposta") and pr.mouse_filter == Control.MOUSE_FILTER_IGNORE, "com «até tocares», a resposta a um toque não devia apanhar o toque (B10/C6)")
	var next_in: bool = await t._wait_until(func(): return b._alive(b._notice) and t._contains_text(b._notice, "Depois"), 3000)
	t._check(next_in and not b._alive(pr), "com «até tocares», a resposta a um toque devia sair sozinha e deixar entrar o aviso seguinte (B10/C6)")
	bm.climate = ""
	Settings.reset_options(["toast_time"], false)
	# 7. Fronteira: em inglês, um resumo comprido parte-se em linhas e cabe no ecrã (nos 1280×720 do telemóvel, K3).
	var keep_size := phone_window(t)
	await _b10_clear(t, b)
	Settings.language = "en"
	Settings.apply()
	b._enemy_log_from = b._history.size()
	b._enemy_turn_logging = true
	for nm in ["Archmage of the Endless Tower", "Weaver of Mirrors", "Lady of a Thousand Hands"]:
		b._log(TranslationServer.translate("%s carregou um golpe: este turno ataca com ×%s!") % [nm, "2.5"])
	b._log(TranslationServer.translate("Levaste %d de dano.") % 12)
	b._show_enemy_recap()
	for _i in 3:
		await tree.process_frame
	var en_ok: bool = b._alive(b._notice) and b.get_viewport_rect().encloses(b._notice.get_global_rect()) \
		and String((b._notice.get_child(0) as Label).text).begins_with("On its turn: You took 12")
	t._check(en_ok, "em inglês, o resumo devia começar por «You took» e caber no ecrã (B10)")
	tree.root.size = keep_size
	Settings.language = "pt"
	Settings.apply()
	await _b10_clear(t, b)
	await close_scene(t, b)
	GameState.clear_saved_run()
	# 8. Fronteira com a B7: o aviso do 1.º toque do ATACAR no último turno aparece logo, mesmo com outro aviso no ecrã.
	GameState.new_run("deck01", 20101)
	GameState.relic_ids.clear()
	GameState.clear_saved_run()
	var b2: Node = await open_battle(t, battle_state(["c001", "c002"], [], 5, 5))
	await _b10_clear(t, b2)
	b2._warn("Resumo de teste", Color(0.75, 0.6, 1.0), 3.0)
	b2._on_end_turn()   # 1.º toque: não ataca (B7)
	await tree.process_frame
	t._check(not b2.battle.resolving and t._contains_text(b2._notice, TranslationServer.translate("Este ataque não chega: perdes a run.")) \
		and b2._warn_queue.size() >= 1 and String(b2._warn_queue[0][0]) == "Resumo de teste", "o aviso do 1.º toque do ATACAR devia aparecer logo e o que estava no ecrã voltar à fila (B10)")
	await close_scene(t, b2)
	GameState.clear_saved_run()
	Settings.tips_enabled = old_tips
	Settings.reset_options(["toast_time", "assist_rewind"], false)
	print("  0.20.0 (B10): avisos da batalha com o tempo dos avisos e em fila, «Levaste» primeiro, toque abre «Só o inimigo», clima, resposta a um toque e inglês OK")

## Revisão final (batalha). No último turno com «NÃO CHEGA», nenhum caminho ataca sem o 2.º toque: o ataque automático
## nem arranca (sem «ataca!» nem brilho), nunca arma a confirmação e o Espaço e o X do comando cancelam-no; com o ATACAR
## a segurar, o botão armado pede para segurar outra vez; o «ÚLTIMO TURNO» espera que o letreiro importante se leia; a
## fila de avisos não deita fora o resumo do inimigo nem o golpe carregado; os espinhos da Elite contam para o «MORRES»
## (sem o dizer quando uma criatura se sacrifica); o letreiro da derrota fica 1,2 s também na velocidade «Instantânea».
static func _test_0200_final_battle(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	var old_warn: bool = Settings.warn_mana
	Settings.warn_mana = false
	Settings.set_opt("auto_end", true, false)
	# --- Último turno (5 de 5) sem jogadas: sem mana, canalizações, poções nem patrono; o ataque não chega. ---
	GameState.new_run("deck01", 20201)
	GameState.clear_saved_run()
	GameState.relic_ids.clear()
	GameState.consumables.clear()
	GameState.planeswalker = {}
	var st := battle_state(["c002"], [], 5, 5, 0)
	st["discards_left"] = 0
	var b: Node = await open_battle(t, st)
	var bm: BattleManager = b.battle
	var auto := TranslationServer.translate("Sem jogadas: ataque automático em 1 s (toca para cancelar).")
	var glow = b.get("_attack_glow")
	t._check(b._no_plays_left() and String(b.end_turn_btn.text) == "ATACAR  ·  NÃO CHEGA", "pré-condição: último turno sem jogadas e com um ataque que não chega (F9; há «%s»)" % b.end_turn_btn.text)
	t._check(not t._contains_text(b, auto) and not t._contains_text(b, "Já não tens jogadas") and not (glow is Tween and (glow as Tween).is_valid()),
		"no último turno com «NÃO CHEGA», nada de «ataca!», ATACAR a brilhar nem ataque automático (F9)")
	await tree.create_timer(1.3).timeout
	t._check(b.get("_attack_armed") != true and not bm.resolving and not bm.finished, "o fim de turno automático não devia armar nem atacar no «NÃO CHEGA» (K2/F9)")
	# K2: o automático já a contar e o Espaço (ou o X do comando): o 1.º só avisa e o automático não ataca por ele.
	var pad := InputEventJoypadButton.new()
	pad.button_index = JOY_BUTTON_X
	pad.pressed = true
	for pair in [[Test0190._key(KEY_SPACE), "o Espaço"], [pad, "o X do comando"]]:
		var ev: InputEvent = pair[0]
		b._disarm_attack(b._attack_arm_token)
		b._start_auto_end()
		b._input(ev)             # a ordem do Viewport: _input e depois _unhandled_input
		b._unhandled_input(ev)
		var armed: bool = b.get("_attack_armed") == true and not bm.resolving
		await tree.create_timer(1.3).timeout
		t._check(armed and not bm.resolving and not bm.finished,
			"com o ataque automático a contar, %s no «NÃO CHEGA» devia só avisar, e o automático não devia atacar a seguir (K2)" % String(pair[1]))
	b._disarm_attack(b._attack_arm_token)
	b._start_auto_end()
	await tree.create_timer(1.3).timeout
	var auto_armed = b.get("_attack_armed")
	b._on_end_turn()
	t._check(auto_armed != true and b.get("_attack_armed") == true and not bm.resolving and not bm.finished,
		"o ataque automático não devia armar a confirmação no «NÃO CHEGA»; depois dele, um só toque devia só avisar (K2)")
	# K1: com «ATACAR a segurar», o ATACAR armado pede para segurar outra vez (em português e em inglês, a caber).
	b._disarm_attack(b._attack_arm_token)
	Settings.set_opt("hold_attack", true, false)
	b._on_end_turn_down()
	b._hold_tick(1.0)          # segurou o meio segundo: o 1.º «toque»
	b._on_end_turn_up()
	b._on_end_turn_pressed()   # o largar do botão depois de segurar não conta
	var hold_txt: String = b.end_turn_btn.text
	var hold_fits := _b7_fits(b)
	b._refresh_preview()
	var hold_txt2: String = b.end_turn_btn.text
	_b7_lang(true)
	b._refresh_preview()
	var hold_en: String = b.end_turn_btn.text
	var hold_en_fits := _b7_fits(b)
	_b7_lang(false)
	b._refresh_preview()
	t._check(b.get("_attack_armed") == true and not bm.resolving and hold_txt == "segura outra vez para atacar" and hold_txt2 == hold_txt
		and hold_fits and hold_en == "hold again to attack" and hold_en_fits,
		"com «ATACAR a segurar», o ATACAR armado devia dizer «segura outra vez para atacar» («hold again to attack», a caber) (K1; há «%s», «%s», «%s»)" % [hold_txt, hold_txt2, hold_en])
	Settings.reset_options(["hold_attack"], false)
	b._disarm_attack(b._attack_arm_token)
	# F7: o «ÚLTIMO TURNO» espera que o boss a despertar (ou o Coração de Vidro) se leia, em vez de o cortar.
	var boss_txt := "O BOSS DESPERTA\n+2 de ataque"
	b._show_banner(boss_txt, 1.1)
	var t0 := Time.get_ticks_msec()
	b._show_last_turn_banner()
	var kept: bool = String(b._banner_full) == boss_txt
	var came: bool = await t._wait_until(func(): return String(b._banner_full).begins_with("ÚLTIMO TURNO"), 4000)
	var waited := Time.get_ticks_msec() - t0
	t._check(kept and came and waited >= 1100, "o «ÚLTIMO TURNO» devia esperar que «O BOSS DESPERTA» se lesse e só depois aparecer (F7; %d ms)" % waited)
	# K16: a fila nunca passa de WARN_QUEUE_MAX e o que sai é um aviso de informação, nunca o resumo nem o golpe carregado.
	await _b10_clear(t, b)
	for txt in ["Info 0", "Info A", "Info B"]:
		b._warn(txt, UiKit.GOLD, 3.0)
	b._warn("Resumo do inimigo", Color(0.75, 0.6, 1.0), 3.0, false, true)
	b._warn("Resposta a um toque", UiKit.GOLD, 1.0, true)   # o «Info 0» do ecrã volta à frente da fila cheia
	var q1: Array = b._warn_queue.map(func(q: Array) -> String: return String(q[0]))
	t._check(q1.size() <= b.WARN_QUEUE_MAX and q1.has("Resumo do inimigo") and String(q1[0]) == "Info 0",
		"com a fila cheia, a resposta a um toque devia pôr à frente o aviso do ecrã sem deitar fora o resumo do inimigo (K16; fila %s)" % str(q1))
	await _b10_clear(t, b)
	for txt in ["Info 0", "Info A", "Info B", "Info C"]:
		b._warn(txt, UiKit.GOLD, 3.0)
	b._warn("Golpe carregado", Color(1.0, 0.6, 0.2), 3.2, false, true)
	var q2: Array = b._warn_queue.map(func(q: Array) -> String: return String(q[0]))
	t._check(q2.size() <= b.WARN_QUEUE_MAX and q2.has("Golpe carregado"), "com a fila cheia de avisos de informação, o golpe carregado devia entrar na mesma (K16; fila %s)" % str(q2))
	await _b10_clear(t, b)
	await close_scene(t, b)
	GameState.clear_saved_run()
	Settings.reset_options(["auto_end"], false)
	# --- F8: Elite Espinhosa (2), 5 de vida e 4 de contra-ataque, turno 2 de 5, sem Coração de Vidro. ---
	for with_creature in [false, true]:
		GameState.new_run("deck01", 20202)
		GameState.clear_saved_run()
		GameState.relic_ids.clear()
		GameState.consumables.clear()
		GameState.death_save_used = true
		GameState.player_hp = 5
		var e: Node = await open_battle(t, battle_state(["c002"], ["c005"] if with_creature else [], 2, 5, 6, {"attack": 4, "rule": {"thorns": 2}}))
		var em: BattleManager = e.battle
		if not with_creature:
			em.play(em.deck.hand[0])   # um feitiço: o ataque deixa de ser vazio (os espinhos só picam num ataque)
			e._refresh_all()
			var die_txt: String = e.end_turn_btn.text
			em.rule.erase("thorns")
			e._refresh_preview()
			var plain_txt: String = e.end_turn_btn.text
			t._check(die_txt == "ATACAR  ·  MORRES" and plain_txt.contains("−4♥") and not plain_txt.contains("MORRES"),
				"os espinhos da Elite (5 de vida, −2, e o contra-ataque de 4) deviam dar «MORRES»; sem espinhos, «−4♥» (F8; há «%s» e «%s»)" % [die_txt, plain_txt])
		else:
			var c_txt: String = e.end_turn_btn.text
			t._check(not c_txt.contains("MORRES") and e.get("_attack_armed") != true,
				"com uma criatura que se sacrifica depois dos espinhos (fica-se com 3 e leva-se 1), o ATACAR não devia dizer «MORRES» (F8; há «%s»)" % c_txt)
			# F6: na velocidade «Instantânea» o letreiro da derrota fica 1,2 s antes do fim da run (o go() não muda de cena).
			var saved_progress: Dictionary = GameState.progress.duplicate(true)
			var runs0: int = SceneRouter.session_runs
			var old_speed: String = Settings.anim_speed
			Settings.anim_speed = "instant"
			Settings.set_opt("assist_retry", false, false)
			SceneRouter._busy = true
			var d0 := Time.get_ticks_msec()
			await e._on_battle_ended(false)
			var shown := Time.get_ticks_msec() - d0
			SceneRouter._busy = false
			Settings.anim_speed = old_speed
			Settings.reset_options(["assist_retry"], false)
			t._check(shown >= 1000 and String(e._banner_full).begins_with("DERROTA"),   # (o temporizador pode acabar um frame mais cedo)
				"na velocidade «Instantânea», o letreiro da derrota devia ficar 1,2 s antes de a run acabar (F6; %d ms)" % shown)
			GameState.progress = saved_progress
			Stats._ensure()
			GameState.save_progress()
			GameState.last_loss = {}
			SceneRouter.session_runs = runs0
		await close_scene(t, e)
		GameState.clear_saved_run()
	GameState.death_save_used = false
	Settings.warn_mana = old_warn
	print("  0.20.0 (revisão final, batalha): Espaço, comando e automático sem atacar no NÃO CHEGA, segurar outra vez, ÚLTIMO TURNO depois do boss, fila com o resumo, espinhos no MORRES e derrota na velocidade Instantânea OK")

## C11: os avisos de progresso (conquista, cosmético, desbloqueio, página do Diário) não tapam a batalha: ficam retidos
## (e logo no sino) e saem em «Também ganhaste:» nas recompensas ou no RunOver, ou no ecrã seguinte. Fora da batalha
## vão sempre para o canto, um de cada vez. Os outros avisos não mudam. «Conquistas no canto» e «Avisos só entre
## batalhas» saíram das Configurações.
static func _test_0200_c11(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	var vp: Vector2 = t.get_viewport().get_visible_rect().size
	Settings.reset_options(["menu_text", "ach_corner", "toast_time"], false)
	SceneRouter.close_overlays()
	var ach_id := String(CardDB.achievements[0].get("id", ""))
	var ach2_id := String(CardDB.achievements[1].get("id", ""))
	var ach_txt := _c11_ach_text(0)
	var ach2_txt := _c11_ach_text(1)
	var diary_txt := String(TranslationServer.translate("Diário do Mago: nova página — «%s».")) % String(TranslationServer.translate(String(Stats.diary_page("d01").get("title", ""))))
	var relic_txt := "✦ " + Stats.unlock_label({"type": "relic", "id": "relic_banner"}, "Desbloqueaste %s: %s")
	var dawn_txt := String(TranslationServer.translate(String(CardDB.get_cosmetic("back", "dawn").get("name", "dawn"))))
	# 1. Batalha aberta: os outros avisos aparecem como sempre; os de progresso não aparecem, ficam à espera e no sino.
	GameState.new_run("deck01", 20111)
	GameState.clear_saved_run()
	var b: Node = await open_battle(t, battle_state(["c010", "c002"], ["c001"]))
	Stats.check_diary(false)   # (as páginas que o progresso deste PC já dava abrem-se sem aviso)
	await _c11_clear(t)
	SceneRouter.toast("Gravado (teste C11)", 0.5)
	await tree.process_frame
	await tree.process_frame
	var p0 := _c11_panels()
	t._check(p0.size() == 1 and not bool(p0[0].get_meta("corner", false)), "os outros avisos (gravado, erros…) deviam continuar a aparecer durante a batalha, ao centro (C11)")
	await _c11_clear(t)
	Stats.diary_unlocked().erase("d01")
	var fresh := Stats.check_diary()
	EventBus.achievement_unlocked.emit(ach_id)
	EventBus.content_unlocked.emit("relic", "relic_banner")
	EventBus.content_unlocked.emit("back", "dawn")
	await tree.process_frame
	await tree.process_frame
	var want: Array = [diary_txt, ach_txt, relic_txt, dawn_txt]
	var held_txt: Array = []
	for h in _c11_held():
		held_txt.append(String(h[0]))
	var bell: Array = []
	for e in SceneRouter.toast_log.slice(-4):
		bell.append(String(e.get("text", "")))
	t._check(fresh.size() == 1 and _c11_panels().is_empty() and SceneRouter._toast_queue.is_empty(), "com a batalha aberta, os avisos de progresso (Diário, conquista, desbloqueio, cosmético) não deviam aparecer no ecrã (C11)")
	t._check(held_txt == want, "os avisos de progresso deviam ficar na lista de espera do SceneRouter, pela ordem (C11)")
	t._check(bell == want, "os avisos retidos deviam entrar logo no sino, pela ordem (C11)")
	# 2. As recompensas mostram «Também ganhaste:» (no máximo 3 linhas: 2 avisos e «… e mais 2») e esvaziam a lista.
	var rw := BattleRewards.open(b, "ANTE 1 VENCIDO", [["victory", 8], ["turns", 2, 2]], [], 10, 20)
	await tree.process_frame
	await tree.process_frame
	var more_txt := String(TranslationServer.translate("… e mais %d nos AVISOS (o sino).")) % 2
	t._check(rw.find_child("AlsoWon", true, false) != null and t._contains_text(rw, "Também ganhaste:") and t._contains_text(rw, diary_txt) \
		and t._contains_text(rw, ach_txt) and t._contains_text(rw, more_txt) and not t._contains_text(rw, relic_txt) and _c11_held().is_empty(),
		"as recompensas deviam mostrar «Também ganhaste:» com os avisos retidos (2 e «… e mais 2») e esvaziar a lista (C11)")
	SceneRouter.close_overlays()
	await tree.process_frame
	# 3. Com o texto dos menus no máximo, a janela com a secção cabe no ecrã.
	Settings.set_opt("menu_text", 1.3, false)
	for i in 4:
		EventBus.achievement_unlocked.emit(String(CardDB.achievements[i].get("id", "")))
	var rw2 := BattleRewards.open(b, "ANTE 1 VENCIDO", [["victory", 8], ["turns", 2, 2]], [["relic", "relic_drum"]], 10, 20)
	await tree.create_timer(0.6).timeout
	# (sem ecrã, o vp tem 1280 × 1280; a janela vem ao centro, por isso cabe nos 720 px do jogo se tiver até 720 de altura)
	var r := (rw2._body.get_meta("panel") as Control).get_global_rect()
	t._check(rw2.find_child("AlsoWon", true, false) != null and t._contains_text(rw2, "Também ganhaste:") and r.size.y <= 720.0 - 16.0,
		"com o texto dos menus no máximo, as recompensas com «Também ganhaste:» deviam caber no ecrã (altura %d) (C11)" % int(r.size.y))
	SceneRouter.close_overlays()
	Settings.reset_options(["menu_text"], false)
	await _c11_clear(t)
	# 4. Sair sem recompensas: os avisos esperam pelo ecrã seguinte. O RunOver não os solta; a Torre, por exemplo, sim.
	EventBus.achievement_unlocked.emit(ach_id)
	await close_scene(t, b)
	GameState.clear_saved_run()
	t._check(_c11_panels().is_empty() and _c11_held().size() == 1, "fechar a batalha não devia soltar os avisos retidos: esperam pelo ecrã seguinte (C11)")
	var fake_ro := Control.new()
	fake_ro.name = "RunOver"
	tree.root.add_child(fake_ro)
	await tree.process_frame
	await tree.process_frame
	t._check(_c11_panels().is_empty() and _c11_held().size() == 1, "o RunOver mostra ele próprio os avisos retidos: ao abrir não os devia soltar no canto (C11)")
	fake_ro.queue_free()
	var nxt := Control.new()
	nxt.name = "Tower"
	tree.root.add_child(nxt)
	for _i in 3:
		await tree.process_frame
	var shown := false
	for p in _c11_panels():
		shown = shown or (bool(p.get_meta("corner", false)) and Test0190._all_text(p).contains(ach_txt))
	t._check(shown and _c11_held().is_empty(), "sem recompensas nem RunOver, o ecrã seguinte devia mostrar os avisos retidos no canto (C11)")
	nxt.queue_free()
	await _c11_clear(t)
	# 4b. SAIR PARA O MENU a meio da batalha (ajuste D3): o menu mostra o aviso retido no canto e a lista fica vazia.
	var b3: Node = await open_battle(t, battle_state(["c010", "c002"], ["c001"]))
	await _c11_clear(t)
	EventBus.achievement_unlocked.emit(ach2_id)
	var held_in := _c11_held().size() == 1 and _c11_panels().is_empty()
	await close_scene(t, b3)
	GameState.clear_saved_run()
	var menu := Control.new()
	menu.name = "Main"   # o ecrã do SceneRouter.go("main"), sem trocar a cena do teste
	tree.root.add_child(menu)
	for _i in 3:
		await tree.process_frame
	var on_menu := false
	for p in _c11_panels():
		on_menu = on_menu or (bool(p.get_meta("corner", false)) and Test0190._all_text(p).contains(ach2_txt))
	t._check(held_in and on_menu and _c11_held().is_empty(), "SAIR PARA O MENU a meio da batalha: o aviso retido devia aparecer no canto do menu e a lista ficar vazia (C11/D3)")
	menu.queue_free()
	await _c11_clear(t)
	# 5. Derrota: o RunOver mostra «Também ganhaste:» com os avisos da batalha perdida e com as conquistas do próprio
	# fim da run (ajuste D1), e cabe em 720 px com o resumo de dano, a causa e a linha (o _shrink_to_fit da B9).
	var keep_log: Dictionary = GameState.run_log.duplicate(true)
	var keep_win := GameState.last_victory
	GameState.new_run("deck01", 20112)
	GameState.clear_saved_run()
	var keep: Dictionary = GameState.progress.duplicate(true)
	var b2: Node = await open_battle(t, battle_state(["c010", "c002"], ["c001"]))
	await _c11_clear(t)
	EventBus.achievement_unlocked.emit(ach2_id)
	EventBus.achievement_unlocked.emit(String(CardDB.achievements[2].get("id", "")))
	EventBus.achievement_unlocked.emit(String(CardDB.achievements[3].get("id", "")))
	Stats.stats()["wins"] = maxi(1, Stats.get_stat("wins"))   # a 1.ª conquista volta a ganhar-se no record_run_end (D1)
	(GameState.progress["achievements"] as Array).erase(ach_id)
	await close_scene(t, b2)
	GameState.last_victory = false
	GameState.last_loss = {"cause": "turns", "hp_left": 12345}
	GameState.run_log["damage_by_ante"] = {"1": 1200, "2": 5400}
	GameState.run_log["card_dmg"] = {"c010": 6600}
	GameState.run_log["best_hit"] = 5400
	var ro: Node = load("res://scenes/ui/RunOver.tscn").instantiate()
	t.add_child(ro)
	await tree.process_frame
	var ro_txt := String((ro.get_node("%Unlocks") as Label).text)
	t._check(ro_txt.contains("Também ganhaste:") and ro_txt.contains(ach2_txt) and _c11_held().is_empty(), "o RunOver devia mostrar «Também ganhaste:» com os avisos da batalha perdida e esvaziar a lista (C11)")
	var lg: Array = []
	for e in SceneRouter.toast_log:
		lg.append(String(e.get("text", "")))
	t._check(_c11_panels().is_empty() and lg.rfind(ach_txt) > lg.rfind(_c11_ach_text(3)),
		"as conquistas do fim da run (record_run_end) deviam ficar retidas para «Também ganhaste:», e não no canto por cima do RunOver (C11/D1)")
	await tree.process_frame
	await tree.process_frame
	var vb: Control = ro.get_node("%Title").get_parent()
	var need := int(vb.get_combined_minimum_size().y)   # o mesmo critério da B9 (sem ecrã, o vp tem 1280 de altura)
	t._check(ro.find_child("Charts", true, false) != null and String((ro.get_node("%Detail") as Label).text).begins_with("Os turnos acabaram") \
		and need <= 720 - 32,
		"o RunOver com o resumo de dano, a causa e «Também ganhaste:» devia caber em 720 px (pede %d) (C11)" % need)
	await close_scene(t, ro)
	# 5b. Vitória num capítulo da História com o prémio pela 1.ª vez: o grant_unlock do record_run_end também fica retido
	# (D1), mas o prémio já está em «Desbloqueaste:» e não se repete em «Também ganhaste:».
	await _c11_clear(t)
	var free0 := GameState.free_mode
	GameState.new_saga_run("saga_blue", 20113)
	GameState.clear_saved_run()
	if GameState.progress.get("saga") is Dictionary:
		(GameState.progress["saga"] as Dictionary).erase("saga_blue")
	(GameState.progress["unlocks"] as Dictionary).erase("back:tide")
	_c11_held().append([ach2_txt, 2.8, false, {}, true])   # um aviso retido na última batalha
	GameState.ante = GameState.max_ante
	GameState.last_victory = true
	var tide_lbl := Stats.unlock_label({"type": "back", "id": "tide"}, "%s: %s")
	var ro2: Node = load("res://scenes/ui/RunOver.tscn").instantiate()
	t.add_child(ro2)
	await tree.process_frame
	var ro2_txt := String((ro2.get_node("%Unlocks") as Label).text)
	t._check(tide_lbl in GameState.last_unlocks and ro2_txt.contains("Também ganhaste:") and ro2_txt.contains(ach2_txt) \
		and ro2_txt.count(tide_lbl) == 1 and _c11_held().is_empty() and _c11_panels().is_empty(),
		"no fim de um capítulo da História, o prémio devia aparecer só em «Desbloqueaste:», e não outra vez em «Também ganhaste:» (C11/D1)")
	await close_scene(t, ro2)
	GameState.free_mode = free0
	GameState.new_run("deck01", 20113)
	GameState.progress = keep
	Stats._ensure()
	Stats._rares_cache = -1
	GameState.save_progress()
	GameState.clear_saved_run()
	GameState.last_loss = {}
	GameState.run_log = keep_log
	GameState.last_victory = keep_win
	# 6. Fora da batalha: no canto de cima à direita, um de cada vez; a opção antiga é ignorada; o cosmético é pequeno.
	await _c11_clear(t)
	EventBus.achievement_unlocked.emit(ach_id)
	EventBus.achievement_unlocked.emit(ach2_id)
	for _i in 3:
		await tree.process_frame
	var p1 := _c11_panels()
	t._check(p1.size() == 1 and bool(p1[0].get_meta("corner", false)) and _c11_right(p1[0], vp) and Test0190._all_text(p1[0]).contains(ach_txt) \
		and SceneRouter._toast_queue.size() == 1, "fora da batalha, os avisos de progresso deviam aparecer no canto de cima à direita, um de cada vez (C11)")
	if p1.size() == 1:
		var slot := SceneRouter._toast_slots.find(p1[0])
		(p1[0] as Node).queue_free()
		SceneRouter._free_toast_slot(slot, p1[0])
	for _i in 3:
		await tree.process_frame
	var p2 := _c11_panels()
	t._check(p2.size() == 1 and bool(p2[0].get_meta("corner", false)) and Test0190._all_text(p2[0]).contains(ach2_txt), "o aviso de progresso seguinte devia aparecer quando o anterior sai (C11)")
	await _c11_clear(t)
	Settings.set_opt("ach_corner", false, false)
	EventBus.achievement_unlocked.emit(ach_id)
	for _i in 3:
		await tree.process_frame
	var p3 := _c11_panels()
	t._check(p3.size() == 1 and bool(p3[0].get_meta("corner", false)) and _c11_right(p3[0], vp), "a opção antiga «Conquistas no canto» devia ser ignorada: as conquistas vão sempre para o canto (C11)")
	Settings.reset_options(["ach_corner"], false)
	await _c11_clear(t)
	EventBus.content_unlocked.emit("back", "dawn")
	for _i in 3:
		await tree.process_frame
	var p4 := _c11_panels()
	var small := p4.size() == 1 and String(p4[0].name) == "UnlockToast" and bool(p4[0].get_meta("corner", false)) and _c11_right(p4[0], vp)
	if small:
		for l in (p4[0] as Node).find_children("*", "Label", true, false):
			small = small and (l as Label).get_theme_font_size("font_size") <= 16
	t._check(small, "o aviso de cosmético fora da batalha devia ser pequeno (letra até 16 px) e no canto (C11)")
	await _c11_clear(t)
	# 7. As duas opções saíram das Configurações.
	var sm := SettingsMenu.open()
	await tree.process_frame
	var keys: Array = []
	for o in sm._options():
		keys.append(String(o.get("key", "")))
	t._check(not ("ach_corner" in keys), "a opção «Conquistas no canto» devia ter saído das Configurações (C11)")
	t._check(not ("defer_notices" in keys), "a opção «Avisos só entre batalhas» devia ter saído das Configurações: os avisos de progresso esperam sempre pelo fim da batalha (C11)")
	sm.close()
	await tree.process_frame
	SceneRouter.close_overlays()
	await _c11_clear(t)
	Settings.reset_options(["menu_text", "ach_corner", "toast_time"], false)
	print("  0.20.0 (C11): avisos de progresso retidos na batalha e no sino, «Também ganhaste:» nas recompensas e no RunOver, ecrã seguinte, canto um de cada vez, opções retiradas OK")

## Revisão final, menus e avisos: as predefinições e o código antigo dos avisos (K4/F14), «Também ganhaste:» à vista
## desde o início (F1) e numa linha só (K17), o marco do Infinito uma vez (F10), as janelas só com botões (F12), LIMPAR
## no Construtor (F13) e o RunOver com tudo dentro dos 720 px (K10).
static func _test_0200_final_menus(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await _c11_clear(t)
	# K4/F14: as predefinições só ligam opções que estão nas Configurações (o «CONCENTRAÇÃO: N opções ligadas» conta-as)
	# e os avisos guardados da 0.19.0 (191) saíram com a opção «Avisos só entre batalhas».
	var sm := SettingsMenu.open()
	await tree.process_frame
	var keys: Array = []
	for o in sm._options():
		keys.append(String(o.get("key", "")))
	sm.close()
	SceneRouter.close_overlays()
	await tree.process_frame
	var stray: Array[String] = []
	for pid in Settings.PRESETS:
		for k in (Settings.PRESETS[pid] as Dictionary):
			if not (String(k) in keys):
				stray.append(String(k))
	t._check(stray.is_empty(), "as predefinições só deviam ligar opções das Configurações; a mais: %s (K4)" % ", ".join(PackedStringArray(stray)))
	t._check(not SceneRouter.has_method("flush_deferred_notices") and not SceneRouter.has_method("_flush_deferred"),
		"o código dos avisos guardados da 0.19.0 (191) devia ter saído com a opção (K4/F14)")
	# F1: «Também ganhaste:» à vista desde que as recompensas abrem: quem carrega logo em CONTINUAR também o vê.
	var ach_txt := _c11_ach_text(0)
	_c11_held().append([ach_txt, 2.8, false, {}, true])
	var rw := BattleRewards.open(t, "ANTE 1 VENCIDO", [["victory", 8], ["turns", 2, 2]], [["relic", "relic_drum"]], 10, 20)
	await tree.process_frame
	var box := rw.find_child("AlsoWon", true, false) as Control
	var seen: bool = box != null and box.modulate.a >= 0.99 and t._contains_text(rw, ach_txt)
	rw._btn.pressed.emit()
	await tree.process_frame
	t._check(seen and _c11_held().is_empty(), "«Também ganhaste:» devia estar à vista desde que as recompensas abrem: quem carrega logo em CONTINUAR também o vê (F1)")
	SceneRouter.close_overlays()
	await tree.process_frame
	# K17: cortada a uma linha, a secção diz quantos avisos há no sino (sem «… e mais» sozinho); com 0, nenhuma.
	var three: Array[String] = ["a", "b", "c"]
	var one := SceneRouter.notice_lines(three, 1)
	var alone := String(TranslationServer.translate("%d avisos no sino (AVISOS).")) % 3
	t._check(one.size() == 1 and one[0] == alone and SceneRouter.notice_lines(three, 0).is_empty() and SceneRouter.notice_lines(three, 2).size() == 2,
		"com uma linha só, «Também ganhaste:» devia dizer «%s» (e com 0 linhas, nenhuma) (K17)" % alone)
	# F10: o cosmético do marco do Infinito já está na linha do marco; não se repete em «Também ganhaste:».
	var ante0 := GameState.ante
	GameState.ante = 12
	GameState.last_milestone_text = "+15 ouro"
	var mat_txt := "✦ " + Stats.unlock_label({"type": "mat", "id": "infinity"}, "Desbloqueaste %s: %s")
	_c11_held().append(["Infinito", 3.4, false, {"kind": "mat", "id": "infinity"}, true])
	_c11_held().append([ach_txt, 2.8, false, {}, true])
	var rw2 := BattleRewards.open(t, "ANTE 12 VENCIDO", [["victory", 8]], [["text", "∞ marco"]], 10, 18)
	await tree.process_frame
	t._check(t._contains_text(rw2, ach_txt) and not t._contains_text(rw2, mat_txt) and _c11_held().is_empty(),
		"o cosmético do marco do Infinito não devia aparecer outra vez em «Também ganhaste:» (F10)")
	SceneRouter.close_overlays()
	GameState.ante = ante0
	GameState.last_milestone_text = ""
	await tree.process_frame
	# F12: numa janela só com botões, o toque fora e o retroceder respondem (som de recusa e o painel abana).
	var d := ChoiceDialog.open("REPETIR A BATALHA?", "", [["REPETIR", "retry"], ["DESISTIR", "quit"]])
	d.buttons_only = true
	await tree.create_timer(0.4).timeout   # o pop_in acaba
	var heard: Array = []
	var on_sound := func(n: String): heard.append(n)
	Sfx.played.connect(on_sound)
	var x0 := d._panel.position.x
	Sfx._last_play.erase("deny")
	await tap(t, Vector2(20, 20))
	await tree.create_timer(0.03).timeout
	var moved := absf(d._panel.position.x - x0) > 0.5
	await tree.create_timer(0.4).timeout
	var rest := absf(d._panel.position.x - x0) < 0.5
	Sfx._last_play.erase("deny")
	back(t)
	await tree.process_frame
	Sfx.played.disconnect(on_sound)
	t._check(heard.count("deny") == 2 and moved and rest and is_instance_valid(d) and not d._done,
		"numa janela só com botões, o toque fora e o retroceder deviam dar o som de recusa e abanar o painel, sem fechar (F12)")
	SceneRouter.close_overlays()
	await tree.process_frame
	# F13: LIMPAR no Construtor com alterações por guardar pergunta (fechar = VOLTAR); sem elas, limpa logo.
	var keep_decks: Dictionary = CardDB.custom_decks.duplicate(true)
	CardDB.custom_decks.clear()
	CardDB.custom_decks["custom_1"] = {"id": "custom_1", "num": 0, "name": "Guardado", "custom": true, "cards": ["c001", "c002", "c003"]}
	SceneRouter._busy = true
	load("res://scenes/builder/DeckBuilder.gd").reset_memory()
	var db: Node = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	t.add_child(db)   # abre no espaço 1, com o baralho guardado
	await tree.process_frame
	await tree.process_frame
	db._on_more_choice("clear")
	await tree.process_frame
	var clean_ok: bool = (db._cards as Array).is_empty() and not SceneRouter.has_overlay()
	db._add_card("c001")
	db._on_more_choice("clear")
	await tree.process_frame
	var dlg := SceneRouter.top_overlay()
	var asked: bool = dlg is ChoiceDialog and choice_texts(dlg) == ["LIMPAR", "VOLTAR"] and (db._cards as Array).size() == 1
	var kept := false
	if asked:
		await tap(t, Vector2(20, 20))   # fechar por fora = VOLTAR
		await tree.process_frame
		kept = (db._cards as Array).size() == 1 and not SceneRouter.has_overlay()
		db._on_more_choice("clear")
		await tree.process_frame
		var top := SceneRouter.top_overlay()
		if top != null and top.find_child("Choice0", true, false) is Button:
			(top.find_child("Choice0", true, false) as Button).pressed.emit()
		await tree.process_frame
	t._check(clean_ok and asked and kept and (db._cards as Array).is_empty(),
		"LIMPAR com alterações por guardar devia pedir confirmação (LIMPAR / VOLTAR, fechar = VOLTAR); sem elas, limpa logo (F13)")
	await close_scene(t, db)
	SceneRouter._busy = false
	load("res://scenes/builder/DeckBuilder.gd").reset_memory()
	CardDB.custom_decks = keep_decks
	CardDB.save_custom_decks()
	# K10: o RunOver de uma run longa perdida (causa comprida, talentos, fragmentos, o resumo todo) com 5 avisos
	# retidos cabe nos 720 px, com as duas filas de botões (o mesmo estado da captura 200_10c), em português e em inglês.
	var keep: Dictionary = GameState.progress.duplicate(true)
	for en in [false, true]:
		Settings.language = "en" if en else "pt"
		Settings.apply()
		await _c11_clear(t)
		Shots0200.long_defeat_state()
		for i in 5:
			_c11_held().append([_c11_ach_text(i), 2.8, false, {}, true])
		var ro: Node = load("res://scenes/ui/RunOver.tscn").instantiate()
		t.add_child(ro)
		for _i in 3:
			await tree.process_frame
		var vb: Control = ro.get_node("%Title").get_parent()
		var need := vb.get_combined_minimum_size()
		var unl := String((ro.get_node("%Unlocks") as Label).text)
		var more := String(TranslationServer.translate("… e mais %d nos AVISOS (o sino).")).split("%")[0]
		# Sem ecrã as letras medem quase o dobro da altura (o Inter a 16 px dá 32 em vez de 20): aí a altura não diz nada.
		# Com janela a 1280×720 este RunOver pede 651 px em português e em inglês, sem encolher (captura 200_10c).
		var real_font: bool = (ro.get_node("%Detail") as Label).get_theme_font("font").get_height(16) < 24.0
		t._check(ro.find_child("GoldChart", true, false) != null and ro.find_child("Replay", true, false) != null \
			and String((ro.get_node("%Detail") as Label).text).contains(Cascade.fmt_int(1234567)) \
			and unl.contains(String(TranslationServer.translate("Também ganhaste:"))) and unl.contains(more) \
			and (need.y <= 720.0 - 32.0 or not real_font) and need.x <= 1280.0 - 80.0,
			"o RunOver com tudo (resumo, causa, talentos, «Também ganhaste:» e «… e mais») devia caber em 1280×720 em %s (pede %d×%d) (K10)" % ["inglês" if en else "português", int(need.x), int(need.y)])
		await close_scene(t, ro)
	Settings.language = "pt"
	Settings.apply()
	GameState.new_run("deck01", 20113)
	GameState.progress = keep
	Stats._ensure()
	Stats._rares_cache = -1
	GameState.save_progress()
	GameState.clear_saved_run()
	GameState.last_loss = {}
	await _c11_clear(t)
	print("  0.20.0 (revisão final, menus e avisos): predefinições, «Também ganhaste:» à vista e numa linha, marco do Infinito, janelas só com botões, LIMPAR e RunOver com tudo OK")

## C11: os avisos retidos do SceneRouter, lidos sem tipo (o teste compila antes de held_notices existir).
static func _c11_held() -> Array:
	var h = SceneRouter.get("held_notices")
	return h if h is Array else []

## C11: tira os avisos do ecrã, da fila e da lista de espera, e espera um frame (os painéis libertados saem da árvore).
static func _c11_clear(t: Node) -> void:
	_c11_held().clear()
	SceneRouter._toast_queue.clear()
	for i in SceneRouter._toast_slots.size():
		var p = SceneRouter._toast_slots[i]
		if p != null and is_instance_valid(p):
			(p as Node).queue_free()
		SceneRouter._toast_slots[i] = null
	await t.get_tree().process_frame

## C11: os avisos no ecrã (painéis vivos do SceneRouter).
static func _c11_panels() -> Array:
	var out: Array = []
	for p in SceneRouter._toast_slots:
		if p != null and is_instance_valid(p) and not (p as Node).is_queued_for_deletion():
			out.append(p)
	return out

## C11: o painel está encostado ao canto de cima à direita, como o SceneRouter._show_toast o põe (14 px da margem).
static func _c11_right(p: Control, vp: Vector2) -> bool:
	return absf(p.get_global_rect().end.x - (vp.x - 14.0)) < 2.0

## C11: o texto do aviso da conquista n.º i, como o SceneRouter o escreve.
static func _c11_ach_text(i: int) -> String:
	var a: Dictionary = CardDB.achievements[i]
	return "★ " + String(TranslationServer.translate("Conquista: %s")) % String(TranslationServer.translate(String(a.get("name", a.get("id", "")))))

## D12: o tutorial com os 8 passos (o MULLIGAN primeiro), os números desta batalha, o passo do Poder × Mult depois da
## 1.ª cascata, o tutorial numa batalha retomada e a dica das formações.
static func _test_0200_d12(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	var old_diff := GameState.difficulty
	var old_tips := Settings.tips_enabled
	Settings.set_opt("assist_turn", false, false)      # os números da batalha vêm só da dificuldade
	Settings.set_opt("assist_channel", false, false)
	# 1. Batalha nova do ante 1 no Fácil: 8 passos pela ordem e os números desta batalha.
	Stats.set_tutorial_done(false)
	GameState.difficulty = "facil"
	GameState.new_run("deck01", 20121)
	GameState.clear_saved_run()
	var b: Node = await open_battle(t, {})   # pending_battle vazio: batalha nova do ante 1
	var bm: BattleManager = b.battle
	var tut := _d12_tutorial(b)
	var ids: Array = []
	var texts := {}
	if tut != null:
		for st in tut._steps:
			ids.append(String((st as Dictionary).get("id", "")))
			texts[ids.back()] = tut._step_text(st as Dictionary) if tut.has_method("_step_text") else String((st as Dictionary).get("text", ""))
	var turns := bm.max_turns + bm.extra_turns
	var ch := bm.discards_left + bm.discards_used
	t._check(ids == ["mulligan", "play", "attack", "mult", "enemy", "channel", "undo", "graveyard"], "o tutorial devia ter 8 passos: MULLIGAN, jogar, ATACAR, Mult, inimigo, CANALIZAR, DESFAZER e CEMITÉRIO (D12; tem %s)" % str(ids))
	t._check(String(texts.get("mulligan", "")) == "Se a mão não te agradar, MULLIGAN dá-te uma mão nova (uma carta vai para o fundo). Só no turno 1, antes de jogares.", "o 1.º passo devia explicar o MULLIGAN antes da 1.ª carta (D12)")
	t._check(turns == 6 and String(texts.get("attack", "")).ends_with(" Tens 6 turnos para o derrotar."), "no Fácil, o passo do ATACAR devia acabar em «Tens 6 turnos para o derrotar.» (D12; %d turnos)" % turns)
	t._check((ch == 4 or bm.climate == "eternal_winter") and String(texts.get("channel", "")).ends_with(" Tens %d por batalha." % ch), "no Fácil, o passo do CANALIZAR devia dizer «Tens 4 por batalha.» (D12; «%s»)" % String(texts.get("channel", "")).right(24))
	t._check(String(texts.get("mult", "")) == "O Poder soma-se e o Mult multiplica. O Mult vem das cartas, das relíquias e das FORMAÇÕES, que são combinações de cartas na Arena. A ordem na Arena conta: arrasta para trocar.", "o passo do Mult devia ter o texto da especificação (D12)")
	t._check(String(texts.get("graveyard", "")) == "Feitiços com ↺ lançam-se do CEMITÉRIO uma segunda vez. Depois da batalha escolhes o caminho no mapa. Boa sorte.", "o último passo devia ser o antigo passo 6, sem o MULLIGAN (D12)")
	# 2. MULLIGAN (CONTINUAR) → jogar uma carta → ATACAR → cascata → Mult no início do turno 2 → painel do inimigo.
	if tut != null:
		bm.enemy["hp"] = 400000   # o 1.º ataque não pode acabar a batalha (o tutorial fechava)
		bm.enemy["max_hp"] = 400000
		t._check(_d12_step(tut) == "mulligan" and tut._next_btn.visible, "o tutorial devia começar no MULLIGAN, com CONTINUAR (D12)")
		tut._next_btn.pressed.emit()
		await tree.process_frame
		var v := _d12_playable(b)
		t._check(_d12_step(tut) == "play" and v != null, "depois do CONTINUAR vinha «jogar uma carta» (D12; o seed 20121 tem de dar uma criatura jogável)")
		if v != null:
			t._tap_play(v)
			await t._wait_until(func(): return Test0200._d12_step(tut) != "play", 3000)
		t._check(_d12_step(tut) == "attack", "depois de jogar a carta vinha o ATACAR; o Mult só depois da 1.ª cascata (D12; está em «%s»)" % _d12_step(tut))
		b._on_end_turn_pressed()
		await t._wait_until(func(): return bm.turn >= 2 and not bool(b._animating) and is_instance_valid(tut) and tut._panel.visible, 20000)
		t._check(_d12_step(tut) == "mult" and tut._panel.visible and tut._target_control() == b.get_node("%MultPill"), "depois da 1.ª cascata devia aparecer o passo do Mult, a apontar para o Poder × Mult (D12; está em «%s»)" % _d12_step(tut))
		if is_instance_valid(tut):
			tut._next_btn.pressed.emit()
			await tree.process_frame
		t._check(_d12_step(tut) == "enemy" and is_instance_valid(tut) and tut._panel.visible, "depois do Mult vinha o painel do inimigo, logo à vista (D12)")
	await close_scene(t, b)
	GameState.clear_saved_run()
	# 3. Jogar uma carta no passo do MULLIGAN passa logo para o ATACAR (o MULLIGAN já não dá).
	GameState.new_run("deck01", 20121)
	GameState.clear_saved_run()
	b = await open_battle(t, {})
	tut = _d12_tutorial(b)
	var v2 := _d12_playable(b)
	if tut != null and v2 != null:
		t._tap_play(v2)
		await t._wait_until(func(): return Test0200._d12_step(tut) == "attack", 3000)
	t._check(_d12_step(tut) == "attack", "jogar uma carta no passo do MULLIGAN devia saltar o MULLIGAN e o «jogar uma carta» (D12; está em «%s»)" % _d12_step(tut))
	await close_scene(t, b)
	GameState.clear_saved_run()
	# 3b. ATACAR no passo do MULLIGAN. Com uma criatura na Arena há cascata: MULLIGAN → jogar → ATACAR → Mult no turno 2.
	#     Com a Arena vazia não há cascata: no turno 2 o tutorial passa ao «jogar uma carta» (o MULLIGAN já não dá).
	for c in [[["c001"], "mult"], [[], "play"]]:
		GameState.new_run("deck01", 20121)
		GameState.clear_saved_run()
		b = await open_battle(t, battle_state(["c002", "c003", "c010"], c[0]))
		bm = b.battle
		tut = _d12_tutorial(b)
		var start := _d12_step(tut)
		b._on_end_turn_pressed()
		await t._wait_until(func(): return bm.turn >= 2 and not bool(b._animating) and is_instance_valid(tut) and tut._panel.visible, 20000)
		t._check(start == "mulligan" and bm.turn >= 2 and _d12_step(tut) == String(c[1]) and tut._panel.visible, "ATACAR no passo do MULLIGAN com %d criatura(s) na Arena devia levar a «%s» no turno 2 (D12; começou em «%s», está em «%s» no turno %d)" % [(c[0] as Array).size(), String(c[1]), start, _d12_step(tut), bm.turn])
		await close_scene(t, b)
		GameState.clear_saved_run()
	# 4. Batalha retomada com o tutorial por fazer: turno 2 → CANALIZAR; turno 1 → MULLIGAN; turno 1 já com uma
	#    jogada (o MULLIGAN já não dá) → «jogar uma carta».
	GameState.difficulty = old_diff
	for c in [[2, 0, "channel"], [1, 0, "mulligan"], [1, 1, "play"]]:
		GameState.new_run("deck01", 20122)
		GameState.clear_saved_run()
		var st := battle_state(["c001", "c002", "c010"], [], int(c[0]))
		st["actions_this_turn"] = int(c[1])
		b = await open_battle(t, st)
		tut = _d12_tutorial(b)
		t._check(_d12_step(tut) == String(c[2]), "numa batalha retomada no turno %d (%d jogadas), o tutorial devia abrir em «%s» (D12; «%s»)" % [int(c[0]), int(c[1]), String(c[2]), _d12_step(tut)])
		if String(c[2]) == "channel":
			t._check(tut != null and tut._text.text.ends_with(" Tens 3 por batalha."), "o CANALIZAR retomado devia dizer as canalizações desta batalha (D12)")
		await close_scene(t, b)
		GameState.clear_saved_run()
	# Sem tutorial com ele feito, e fora do ante 1, mesmo numa batalha retomada.
	Stats.set_tutorial_done(true)
	GameState.new_run("deck01", 20122)
	b = await open_battle(t, battle_state(["c001", "c002"], [], 2))
	t._check(_d12_tutorial(b) == null, "com o tutorial feito, a batalha retomada não devia abrir o tutorial (D12)")
	await close_scene(t, b)
	Stats.set_tutorial_done(false)
	GameState.new_run("deck01", 20122)
	GameState.ante = 2
	b = await open_battle(t, battle_state(["c001", "c002"], [], 2))
	t._check(_d12_tutorial(b) == null, "fora do ante 1 o tutorial não devia abrir (D12)")
	await close_scene(t, b)
	Stats.set_tutorial_done(true)
	GameState.clear_saved_run()
	# 5. A dica das formações sai a 1.ª vez que o ataque previsto tem uma formação (c001 + c003: Pacto Dual).
	Settings.tips_enabled = true
	var had_tip := GameState.tip_seen("formation")
	if GameState.progress.get("tips_seen") is Array:
		(GameState.progress["tips_seen"] as Array).erase("formation")
	GameState.new_run("deck01", 20123)
	GameState.clear_saved_run()
	b = await open_battle(t, battle_state(["c010"], ["c001", "c003"]))
	b._check_tips()
	t._check(CardDB.tips.has("formation") and GameState.tip_seen("formation"), "com uma formação no ataque previsto devia sair a dica das formações (D12)")
	if not had_tip and GameState.progress.get("tips_seen") is Array:
		(GameState.progress["tips_seen"] as Array).erase("formation")
		GameState.save_progress()
	await close_scene(t, b)
	GameState.clear_saved_run()
	# 6. Os textos novos em inglês.
	var en := {
		"Se a mão não te agradar, MULLIGAN dá-te uma mão nova (uma carta vai para o fundo). Só no turno 1, antes de jogares.": "If you don't like your hand, MULLIGAN gives you a new one (one card goes to the bottom). Only on turn 1, before you play.",
		"Tens %d turnos para o derrotar.": "You have %d turns to defeat it.",
		"O Poder soma-se e o Mult multiplica. O Mult vem das cartas, das relíquias e das FORMAÇÕES, que são combinações de cartas na Arena. A ordem na Arena conta: arrasta para trocar.": "Power adds up and Mult multiplies. Mult comes from cards, relics and FORMATIONS, which are card combinations in the Arena. The order in the Arena matters: drag to swap.",
		"CANALIZAR: liga o botão e toca numa carta da mão para a trocar por outra. Tens %d por batalha.": "CHANNEL: switch the button on and tap a card in hand to swap it for another. You have %d per battle.",
		"Feitiços com ↺ lançam-se do CEMITÉRIO uma segunda vez. Depois da batalha escolhes o caminho no mapa. Boa sorte.": "Spells with ↺ can be cast from the GRAVEYARD a second time. After the battle you choose your path on the map. Good luck.",
	}
	var wrong: Array[String] = []
	for k in en:
		if Settings._en.get_message(String(k)) != String(en[k]):
			wrong.append(String(k).substr(0, 30))
	t._check(wrong.is_empty() and Settings._en.get_message(String(CardDB.tips.get("formation", "-"))) != "", "os textos novos do tutorial e a dica das formações deviam ter inglês (D12; %s)" % ", ".join(wrong))
	GameState.difficulty = old_diff
	Settings.tips_enabled = old_tips
	Settings.reset_options(["assist_turn", "assist_channel"], false)
	Stats.set_tutorial_done(true)
	GameState.clear_saved_run()
	print("  0.20.0 (D12): tutorial com 8 passos, números reais, Mult depois da 1.ª cascata, batalha retomada e dica das formações OK")

static func _d12_tutorial(b: Node) -> TutorialOverlay:
	for c in b.get_children():
		if c is TutorialOverlay and not c.is_queued_for_deletion():
			return c
	return null

## O id do passo à vista ("" sem tutorial ou na 0.19.1, que não tinha ids).
static func _d12_step(tut: TutorialOverlay) -> String:
	if not is_instance_valid(tut) or tut._step >= tut._steps.size():
		return ""
	return String((tut._steps[tut._step] as Dictionary).get("id", ""))

## Uma criatura jogável da mão, sem Reforço (sem janela a meio).
static func _d12_playable(b: Node) -> CardView:
	var bm: BattleManager = b.battle
	for v in (b.get_node("%Hand") as Container).get_children():
		if v is CardView:
			var d: CardData = (v as CardView).card.data
			if bm.can_play((v as CardView).card) and d.is_creature() and not d.has_kicker():
				return v as CardView
	return null

## Revisão final (tutorial): os números escrevem-se quando o passo aparece (K5), sem canalizações o passo do CANALIZAR
## salta-se (K5), o passo do Mult espera que o letreiro do turno saia (K5) e o MULLIGAN faz andar o passo dele (F16).
static func _test_0200_final_tutorial(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	var old_diff := GameState.difficulty
	Settings.set_opt("assist_turn", false, false)
	Settings.set_opt("assist_channel", false, false)
	Stats.set_tutorial_done(false)
	GameState.difficulty = "facil"
	GameState.new_run("deck01", 20121)
	GameState.clear_saved_run()
	var b: Node = await open_battle(t, {})
	var bm: BattleManager = b.battle
	var tut := _d12_tutorial(b)
	t._check(tut != null and _d12_step(tut) == "mulligan", "a batalha nova do ante 1 devia abrir o tutorial no MULLIGAN (revisão final)")
	if tut != null:
		# K5: um turno extra ganho depois de o tutorial abrir aparece no passo do ATACAR.
		bm.extra_turns += 1
		tut._on_signal("card_played")   # MULLIGAN e «jogar» passam; fica o ATACAR
		await tree.process_frame
		var want := " Tens %d turnos para o derrotar." % (bm.max_turns + bm.extra_turns)
		t._check(_d12_step(tut) == "attack" and tut._text.text.ends_with(want), "o passo do ATACAR devia dizer os turnos de agora (K5; queria «%s», tem «%s»)" % [want, tut._text.text.right(34)])
		# K5: o passo do Mult só aparece depois de o letreiro do turno sair (desenhava-se por cima da seta).
		tut._on_signal("cascade_started")
		await tree.process_frame
		t._check(_d12_step(tut) == "mult" and not tut._panel.visible, "depois da cascata, o passo do Mult esperava pelo turno seguinte (K5)")
		var banner: Control = b.banner
		if b._banner_tw != null and b._banner_tw.is_valid():
			b._banner_tw.kill()
		banner.visible = true
		tut._on_turn_started(2)
		await tree.process_frame
		await tree.process_frame
		await tree.process_frame
		t._check(not tut._panel.visible and not tut._arrow.visible, "com o letreiro do turno no ecrã, o passo do Mult (e a seta) ainda não deviam aparecer (K5)")
		banner.visible = false
		await t._wait_until(func(): return is_instance_valid(tut) and tut._panel.visible, 2000)
		t._check(tut._panel.visible and tut._arrow.visible and _d12_step(tut) == "mult", "quando o letreiro sai, o passo do Mult devia aparecer (K5)")
		# K5: sem canalizações nesta batalha (Inverno Eterno), o passo do CANALIZAR salta-se.
		tut._next_btn.pressed.emit()   # Mult → inimigo
		await tree.process_frame
		bm.discards_left = 0
		bm.discards_used = 0
		tut._next_btn.pressed.emit()   # inimigo → (CANALIZAR) → DESFAZER
		await tree.process_frame
		t._check(_d12_step(tut) == "undo" and not tut._text.text.contains("por batalha"), "sem canalizações, depois do inimigo devia vir o DESFAZER e não «Tens 0 por batalha» (K5; está em «%s»)" % _d12_step(tut))
		t._check(tut.get("_bounce_tw") is Tween, "o vaivém da seta devia estar num membro com tipo (_bounce_tw: Tween) (K5)")
	await close_scene(t, b)
	GameState.clear_saved_run()
	# K5: com canalizações, o número é o de quando o passo aparece (gastar uma antes não muda o total; ganhar uma, sim).
	GameState.new_run("deck01", 20121)
	GameState.clear_saved_run()
	b = await open_battle(t, {})
	bm = b.battle
	tut = _d12_tutorial(b)
	if tut != null and bm.climate != "eternal_winter":
		for i in tut._steps.size():
			if String((tut._steps[i] as Dictionary).get("id", "")) == "enemy":
				tut._step = i
		bm.discards_left += 2
		tut._advance()
		await tree.process_frame
		t._check(_d12_step(tut) == "channel" and tut._text.text.ends_with(" Tens %d por batalha." % (bm.discards_left + bm.discards_used)), "o passo do CANALIZAR devia dizer as canalizações de agora (K5; «%s»)" % tut._text.text.right(24))
	await close_scene(t, b)
	GameState.clear_saved_run()
	# F16: o MULLIGAN faz andar o passo do MULLIGAN (o botão some e o jogo pede uma carta para o fundo).
	GameState.new_run("deck01", 20121)
	GameState.clear_saved_run()
	b = await open_battle(t, {})
	bm = b.battle
	tut = _d12_tutorial(b)
	t._check(tut != null and _d12_step(tut) == "mulligan" and bm.can_mulligan(), "na batalha nova devia dar para fazer MULLIGAN no passo do MULLIGAN (F16)")
	if tut != null and bm.can_mulligan():
		bm.mulligan()
		await tree.process_frame
		await tree.process_frame
		t._check(_d12_step(tut) == "play", "depois do MULLIGAN o tutorial devia passar para «jogar uma carta» (F16; está em «%s»)" % _d12_step(tut))
	await close_scene(t, b)
	GameState.clear_saved_run()
	Stats.set_tutorial_done(true)
	GameState.difficulty = old_diff
	Settings.reset_options(["assist_turn", "assist_channel"], false)
	print("  0.20.0 (revisão final, tutorial): números na altura do passo, sem «Tens 0», Mult depois do letreiro e MULLIGAN a andar OK")

## D13: o SIM em «Texto maior» liga também o texto dos menus (1,15), com a frase nova; o mapa, a loja, o evento e o baú
## crescem com o «Texto dos menus» sem textos novos cortados.
static func _test_0200_d13(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	# 1. A pergunta do 1.º arranque, pela janela.
	Settings.reset_options(["large_text", "menu_text"], false)
	var keep_q = GameState.progress.get("first_questions", false)
	var keep_news = GameState.progress.get("news_seen", "")
	var o := SessionWindows.open_first_run()
	await tree.process_frame
	var q := o.find_child("Q_large_text", true, false) as Button
	t._check(t._contains_text(o, "Letras maiores nas cartas e nos menus."), "a pergunta «Texto maior» devia dizer «Letras maiores nas cartas e nos menus.» (D13)")
	if q != null:
		q.pressed.emit()
	t._check(Settings.large_text and is_equal_approx(Settings.menu_text_scale(), 1.15), "depois do SIM em «Texto maior», menu_text_scale() devia ser 1,15 (D13; é %.2f)" % Settings.menu_text_scale())
	if q != null:
		q.pressed.emit()
	t._check(not Settings.large_text and is_equal_approx(Settings.menu_text_scale(), 1.0), "voltar ao NÃO devia repor o texto dos menus a 100 % (D13)")
	t._check(Settings._en.get_message("Letras maiores nas cartas e nos menus.") == "Bigger letters on cards and in menus.", "a frase nova devia ter inglês (D13)")
	SceneRouter.close_overlays()
	await tree.process_frame
	GameState.progress["first_questions"] = keep_q
	GameState.progress["news_seen"] = keep_news
	GameState.save_progress()
	Settings.reset_options(["large_text", "menu_text"])   # o set_first_answer grava no disco: repor e gravar
	# 2. Os 4 ecrãs estão na lista, crescem e não ganham textos cortados com o texto no máximo (1,3).
	var missing: Array[String] = []
	for nm in ["Map", "Shop", "Event", "Loot"]:
		if not (nm in SceneRouter.MENU_TEXT_SCENES):
			missing.append(nm)
	t._check(missing.is_empty(), "MENU_TEXT_SCENES devia ter o mapa, a loja, o evento e o baú (D13; faltam %s)" % ", ".join(missing))
	# Medido com a altura do telemóvel (720): sem ecrã a janela dos testes tem 1280 de altura e cabia tudo.
	var keep_size: Vector2i = tree.root.size
	tree.root.size = Vector2i(1280, 720)
	await tree.process_frame
	for c: Array in [["res://scenes/map/Map.tscn", ""], ["res://scenes/map/Map.tscn", "paragem"], ["res://scenes/map/Map.tscn", "ante 1"], ["res://scenes/shop/Shop.tscn", ""], ["res://scenes/event/Event.tscn", "altar"],
			["res://scenes/event/Event.tscn", "node_forge"], ["res://scenes/event/Event.tscn", "well"], ["res://scenes/loot/Loot.tscn", ""]]:
		var path := String(c[0])
		var nm: String = path.get_file().get_basename()
		var what := nm if String(c[1]) == "" else "%s (%s)" % [nm, String(c[1])]
		var r10: Array = await _d13_measure(t, path, 1.0, String(c[1]))
		t._check(int(r10[0]) > 0 and String(r10[2]) == nm, "o teste do D13 devia encontrar o rótulo conhecido do %s (cena «%s»)" % [what, String(r10[2])])
		for scale: float in [1.15, 1.3]:
			var r: Array = await _d13_measure(t, path, scale, String(c[1]))
			t._check(int(r[0]) > int(r10[0]) and String(r[2]) == nm, "com o texto dos menus a %.2f, o %s devia crescer (D13; %d → %d px, cena «%s»)" % [scale, what, int(r10[0]), int(r[0]), String(r[2])])
			var fresh := _d13_new_cuts(r10[1], r[1])
			t._check(fresh.is_empty(), "com o texto dos menus a %.2f, o %s não devia ter textos cortados ou fora do ecrã que a 1,0 não estavam (D13): %s" % [scale, what, " | ".join(fresh)])
	tree.root.size = keep_size
	Settings.reset_options(["menu_text"], false)
	GameState.pending_event = ""
	GameState.clear_saved_run()
	print("  0.20.0 (D13): «Texto maior» liga o texto dos menus; mapa, loja, evento e baú crescem sem cortes novos (1,15 e 1,3, a 720 de altura) OK")

## D13: os textos de `big` (Shots0200.cuts) que não estavam em `base`; cada entrada de `base` só desconta uma vez.
static func _d13_new_cuts(base: Array, big: Array) -> Array[String]:
	var left: Array = []
	for e in base:
		left.append(String(e).get_slice(" [", 0))
	var out: Array[String] = []
	for e in big:
		var i := left.find(String(e).get_slice(" [", 0))
		if i >= 0:
			left.remove_at(i)
		else:
			out.append(String(e))
	return out

## D13: monta a cena como cena atual com o texto dos menus a `scale` e devolve [letra de um rótulo conhecido (-1 se
## não houver), textos cortados ou fora do ecrã (Shots0200.cuts), nome da cena].
static func _d13_measure(t: Node, path: String, scale: float, event: String = "") -> Array:
	var tree: SceneTree = t.get_tree()
	GameState.new_run("deck01", 20131)
	GameState.relic_ids.clear()
	GameState.clear_saved_run()
	GameState.pending_battle = {}
	GameState.ante = 2
	GameState.map_phase = "battle"
	GameState.interlude_key = GameState.climate_key(2)
	GameState.pending_event = ""
	var known_text := ""
	if path.ends_with("Map.tscn"):
		if event == "paragem":    # as paragens são a escolha (legendas compridas na 4.ª coluna)
			GameState.map_phase = "stop"
		elif event == "ante 1":   # a escolha na 1.ª coluna, encostada à esquerda
			GameState.ante = 1
			GameState.interlude_key = GameState.climate_key(1)
	elif path.ends_with("Shop.tscn"):
		GameState.map_options(2)
		GameState.choose_stop("shop")
	elif path.ends_with("Event.tscn"):
		GameState.pending_event = event
		known_text = String(CardDB.get_event(event).get("text", "-"))
	elif path.ends_with("Loot.tscn"):
		GameState.ante = 4
		GameState.map_phase = "stop"
		GameState.prepare_loot()
		known_text = "O boss caiu."
	Settings.set_opt("menu_text", scale, false)
	var n: Node = Shots0200._mount(t, path)
	await tree.process_frame
	await tree.process_frame
	await tree.process_frame
	var known: Node = null
	if path.ends_with("Map.tscn"):
		var hint: Node = t._find_named(n, "Hint")
		known = t._find_node(hint, func(x: Node): return x is Label) if hint != null else null
	elif path.ends_with("Shop.tscn"):
		known = t._find_named(n, "ServicesTitle")
	else:
		known = t._find_node(n, func(x: Node): return x is Label and (x as Label).text.begins_with(known_text))
	var fs := (known as Label).get_theme_font_size("font_size") if known is Label else -1
	var ov: Array[String] = Shots0200.cuts(n)
	var nm := String(n.name)
	await Shots0200._unmount(t, n)
	await tree.process_frame   # a cena libertada sai antes da próxima com o mesmo nome (senão o nome muda)
	return [fs, ov, nm]

## D14: as perguntas do 1.º arranque marcam as Novidades desta versão como vistas.
static func _test_0200_d14(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	var keep_q = GameState.progress.get("first_questions", false)
	var keep_news = GameState.progress.get("news_seen", "")
	Settings.set_opt("news_auto", true, false)
	GameState.progress["news_seen"] = ""   # quem acabou de instalar
	SessionWindows.open_first_run()
	await tree.process_frame
	var v := String(NewsOverlay.current().get("version", ""))
	t._check(v != "" and String(GameState.progress.get("news_seen", "")) == v, "open_first_run devia gravar progress.news_seen = %s (D14)" % v)
	SceneRouter.close_overlays()
	await tree.process_frame
	await tree.process_frame
	NewsOverlay.maybe_show()   # o que o menu faz no regresso
	await tree.process_frame
	var news := false
	for c in SceneRouter.overlay_layer.get_children():
		news = news or (c is NewsOverlay and not c.is_queued_for_deletion())
	t._check(not news, "depois das perguntas do 1.º arranque, as Novidades não deviam abrir no regresso ao menu (D14)")
	SceneRouter.close_overlays()
	await tree.process_frame
	GameState.progress["first_questions"] = keep_q
	GameState.progress["news_seen"] = keep_news
	GameState.save_progress()
	Settings.reset_options(["news_auto"], false)
	print("  0.20.0 (D14): Novidades marcadas como vistas no 1.º arranque OK")

## D15: «PLANESWALKER» passa a «PATRONOS» (pt) e «PATRONS» (en); o teste dos nomes apanha a palavra em maiúsculas.
static func _test_0200_d15(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	var h = JSON.parse_string(FileAccess.get_file_as_string("res://i18n/howto.json"))
	var pt := String(h.get("pt", "")) if h is Dictionary else ""
	var en := String(h.get("en", "")) if h is Dictionary else ""
	t._check(pt.contains("\n\nPATRONOS\nUm por run") and en.contains("\n\nPATRONS\nOne per run") and not (pt + en).contains("PLANESWALKER"), "a secção do Como Jogar devia chamar-se PATRONOS / PATRONS (D15)")
	t._check(String(HowToPlay.SECTION_ICONS.get("PATRONOS", "")) == "star" and not HowToPlay.SECTION_ICONS.has("PLANESWALKER"), "o ícone da secção devia estar na chave PATRONOS (D15)")
	var words: Array = (t.get_script() as GDScript).get_script_constant_map().get("MTG_WORDS", [])
	var caught := false
	for w in words:
		caught = caught or "PLANESWALKER\nUm por run".contains(String(w))
	t._check("PLANESWALKER" in words and caught, "MTG_WORDS devia apanhar «PLANESWALKER» em maiúsculas (D15)")
	t._check("FLASHBACK" in words and en.contains("\n\nRECALL AND EXILE\nSpells marked"), "o Como Jogar em inglês devia ter RECALL AND EXILE (como «Recall» no resto do jogo) e MTG_WORDS apanhar «FLASHBACK» em maiúsculas")
	var before: int = t.failures.size()
	t._check_no_mtg_names()
	t._check(t.failures.size() == before, "com «PLANESWALKER» nas MTG_WORDS, os textos do jogo deviam continuar sem nomes do Magic (D15)")
	var how := HowToPlay.open_overlay()
	await tree.process_frame
	t._check(how.index_of("PATRONOS") >= 0 and how.index_of("PLANESWALKER") < 0, "o Como Jogar devia ter a secção PATRONOS (D15)")
	SceneRouter.close_overlays()
	await tree.process_frame
	print("  0.20.0 (D15): PATRONOS no Como Jogar e PLANESWALKER nas palavras proibidas OK")

## E19: a ajuda das «Legendas dos sons» diz «do lado direito», que é onde elas aparecem.
static func _test_0200_e19(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	var want := "«O boss ruge», «Relíquia dispara»… do lado direito do ecrã, para quem joga sem som."
	var sm := SettingsMenu.open("sound")
	await tree.process_frame
	var help := ""
	for o in sm._options():
		if String((o as Dictionary).get("key", "")) == "captions":
			help = String((o as Dictionary).get("help", ""))
	t._check(help == want, "a ajuda das legendas devia dizer «do lado direito do ecrã» (E19; diz «%s»)" % help)
	t._check(Settings._en.get_message(want) == "«The boss roars», «Relic fires»… on the right of the screen, for those playing without sound.", "a ajuda nova das legendas devia ter inglês (E19)")
	t._check(not FileAccess.get_file_as_string("res://scripts/autoload/SceneRouter.gd").contains("no lado esquerdo, a meio"), "o comentário das legendas no SceneRouter devia dizer «no lado direito» (E19)")
	sm.close()
	await tree.process_frame
	print("  0.20.0 (E19): legendas «do lado direito» OK")

## E17: com as falas do mercador em «nunca», sair da loja não espera; nos outros casos espera Settings.dur(1.2).
## (Sem janela, o _animated() da loja é falso e a espera nunca acontece: por isso o teste lê o _leave_wait().)
static func _test_0200_e17(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	GameState.new_run("deck01", 20171)
	GameState.relic_ids.clear()
	GameState.clear_saved_run()
	var shop: Node = Test0190._fresh_shop(t)
	await tree.process_frame
	SceneRouter.close_overlays()   # o _on_continue não faz nada com uma janela aberta
	await tree.process_frame
	await tree.process_frame
	var has := shop.has_method("_leave_wait")
	t._check(has, "a loja devia ter _leave_wait() -> float (E17)")
	if has:
		var old_speed := Settings.anim_speed
		Settings.set_opt("merchant_lines", "never", false)
		var w_never := float(shop.call("_leave_wait"))
		Settings.set_opt("merchant_lines", "always", false)
		var w_always := float(shop.call("_leave_wait"))
		Settings.set_opt("merchant_lines", "sometimes", false)
		Settings.anim_speed = "fast"
		var w_fast := float(shop.call("_leave_wait"))
		Settings.anim_speed = old_speed
		t._check(is_zero_approx(w_never), "com as falas do mercador em «nunca», sair da loja não devia esperar (E17; %.2f s)" % w_never)
		t._check(is_equal_approx(w_always, Settings.dur(1.2)) and is_equal_approx(w_fast, 1.2 * float(Settings.SPEED_SCALE["fast"])), "nos outros casos a espera devia ser Settings.dur(1.2) (E17; %.2f e %.2f s)" % [w_always, w_fast])
	# Com a janela (_animated() verdadeiro, forçado numa loja derivada): «nunca» sai ao 1.º toque, «always» arma a despedida.
	await Test0190._free_shop(t, shop)
	# F15: com «às vezes», só espera quando o balão sai (semente em que o randf() do _say dá mais de 0,35 → sem balão).
	var quiet_seed := 0
	for sd in 200:
		seed(sd)
		if randf() > 0.35:
			quiet_seed = sd
			break
	for mode in ["never", "always", "sometimes"]:
		Settings.set_opt("merchant_lines", mode, false)
		var src := GDScript.new()
		src.source_code = "extends \"res://scenes/shop/Shop.gd\"
func _animated() -> bool:
	return true
"
		src.reload()
		GameState.pending_battle = {}
		GameState.saved_scene = "map"
		GameState.map_choice = {"stop": "shop"}
		shop = load("res://scenes/shop/Shop.tscn").instantiate()
		shop.set_script(src)
		t.add_child(shop)
		await tree.process_frame
		SceneRouter.close_overlays()
		await tree.process_frame
		var ante0 := GameState.ante
		SceneRouter._busy = true   # o go("map") não troca de cena
		seed(quiet_seed)
		shop.call("_on_continue")
		if mode == "sometimes":
			t._check(GameState.ante == ante0 + 1 and shop.find_child("MerchantSays", true, false) == null, "com as falas em «às vezes» e sem balão, o 1.º toque em PRÓXIMO ANTE devia sair logo, sem esperar 1,2 s (F15)")
		elif mode == "never":
			t._check(GameState.ante == ante0 + 1, "com as falas em «nunca» e a loja animada, o 1.º toque em PRÓXIMO ANTE devia sair logo (E17)")
		else:
			t._check(GameState.ante == ante0 and bool(shop.get("_leave_armed")), "com as falas em «always» e a loja animada, o 1.º toque só devia armar a despedida (E17)")
		SceneRouter._busy = false
		shop._leave_armed = false   # não deixar o temporizador de 1,2 s sair da loja depois do teste
		await Test0190._free_shop(t, shop)
	randomize()
	Settings.reset_options(["merchant_lines"], false)
	GameState.clear_saved_run()
	print("  0.20.0 (E17): sair da loja sem esperar com as falas desligadas ou sem balão OK")

## E18: o CardView liga o resized das marcas do modo daltónico uma só vez. O Godot recusa a 2.ª ligação (só deixa o
## erro «Signal 'resized' is already connected» no log): a prova da falha é o grep do Passo 2/4; aqui fica a contagem.
static func _test_0200_e18(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	Settings.set_opt("colorblind", true, false)
	var v: CardView = load("res://scenes/ui/CardView.tscn").instantiate()
	t.add_child(v)
	v.setup(CardDB.new_instance("c001"))   # criatura vermelha: tem marcas do modo daltónico
	await tree.process_frame
	v.refresh()   # na 0.19.1 cada refresh voltava a ligar o resized
	v.refresh()
	await tree.process_frame
	var marks: Control = v._cb_marks
	var first_id := marks.get_instance_id() if marks != null else 0
	t._check(marks != null and marks.resized.get_connections().size() == 1, "as marcas do modo daltónico deviam ter o resized ligado uma vez (E18)")
	# Desligar e voltar a ligar o modo daltónico: marcas novas, ligadas outra vez uma só vez.
	Settings.colorblind = false
	v.refresh()
	Settings.colorblind = true
	v.refresh()
	await tree.process_frame
	t._check(v._cb_marks != null and v._cb_marks.get_instance_id() != first_id and v._cb_marks.resized.get_connections().size() == 1, "ao voltar a ligar o modo daltónico, as marcas novas deviam ter o resized ligado uma vez (E18)")
	v.queue_free()
	Settings.reset_options(["colorblind"], false)
	await tree.process_frame
	print("  0.20.0 (E18): o resized das marcas do modo daltónico ligado uma vez OK")

## Fechar um ChoiceDialog por fora (retroceder) dá null: o MAIS (⋯) do Construtor não pode dar SCRIPT ERROR
## (String(null)) e o resultado é o seguro: nada muda.
static func _test_0200_builder_more_back(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	SceneRouter._busy = true
	load("res://scenes/builder/DeckBuilder.gd").reset_memory()
	var db: Node = load("res://scenes/builder/DeckBuilder.tscn").instantiate()
	t.add_child(db)
	await tree.process_frame
	await tree.process_frame
	db._add_card("c001")
	var n0: int = db._cards.size()
	db._open_more()
	await tree.process_frame
	t._check(SceneRouter.top_overlay() is ChoiceDialog, "o ⋯ do Construtor devia abrir a janela MAIS (fechar por fora)")
	back(t)
	await tree.process_frame
	await tree.process_frame
	t._check(not SceneRouter.has_overlay() and db._cards.size() == n0, "fechar o MAIS com o retroceder devia deixar tudo como estava (fechar por fora)")
	await close_scene(t, db)
	SceneRouter._busy = false
	# Falha com o código antigo (String(null) dá SCRIPT ERROR, mas o resultado «nada muda» é o mesmo).
	t._check(not FileAccess.get_file_as_string("res://scenes/builder/DeckBuilder.gd").contains("match String(v)"), "o DeckBuilder não devia usar match String(v) (fechar por fora)")
	print("  0.20.0 (fechar por fora): o MAIS do Construtor fechado com o retroceder não muda nada OK")

## Fechar um ChoiceDialog por fora (retroceder) dá null: a pergunta da «Carta protegida» da loja (REMOVER) não pode dar
## SCRIPT ERROR (String(null)) e o resultado é o seguro: a carta fica.
static func _test_0200_shop_protected_back(t: Node) -> void:
	var tree: SceneTree = t.get_tree()
	SceneRouter.close_overlays()
	await tree.process_frame
	GameState.new_run("deck01", 20172)
	GameState.relic_ids.clear()
	GameState.clear_saved_run()
	var shop: Node = Test0190._fresh_shop(t)
	await tree.process_frame
	SceneRouter.close_overlays()
	await tree.process_frame
	GameState.deck[0]["protected"] = true
	var n1 := GameState.deck.size()
	shop.removed_this_visit = false
	shop._on_remove()
	await tree.process_frame
	var zv := SceneRouter.top_overlay() as ZoneViewer
	if zv != null:
		zv._on_card_pressed(ZoneViewer.deck_instances()[0])
	await tree.process_frame
	t._check(SceneRouter.top_overlay() is ChoiceDialog, "REMOVER uma carta protegida devia pedir confirmação (fechar por fora)")
	back(t)
	await tree.process_frame
	await tree.process_frame
	t._check(GameState.deck.size() == n1 and not bool(shop.removed_this_visit), "fechar a pergunta da carta protegida devia deixar o baralho como estava (fechar por fora)")
	# Falha com o código antigo (String(null) dá SCRIPT ERROR, mas o resultado «nada muda» é o mesmo).
	t._check(not FileAccess.get_file_as_string("res://scenes/shop/Shop.gd").contains("String(ans) != \"yes\""), "a loja não devia usar String(ans) != \"yes\" (fechar por fora)")
	SceneRouter.close_overlays()
	await Test0190._free_shop(t, shop)
	GameState.clear_saved_run()
	print("  0.20.0 (fechar por fora): a «Carta protegida» da loja fechada com o retroceder não muda nada OK")

## Tarefa 15 (F20): o projeto.zip sai sem as ferramentas de lançamento que ficam fora do repositório (a lista
## PRIVATE_FILES do script dos zips) e nada do que vai nele aponta para elas. Numa cópia pública (sem esse script) não
## há nada a ver.
static func _test_0200_f20(t: Node) -> void:
	var src := "res://tools/make_release_zips.py"
	if not FileAccess.file_exists(src):
		print("  0.20.0 (F20): cópia pública, nada a verificar OK")
		return
	var only_full: Array[String] = []
	var block := RegEx.create_from_string("PRIVATE_FILES = \\{([^}]*)\\}").search(FileAccess.get_file_as_string(src))
	if block != null:
		for m: RegExMatch in RegEx.create_from_string("\"([^\"]+)\"").search_all(block.get_string(1)):
			only_full.append(m.get_string(1))
	t._check(only_full.size() >= 4, "o script dos zips devia ter PRIVATE_FILES com as ferramentas que só vão no projeto completo (F20)")
	# os .md que o script deixa fora do zip (pelo começo do nome) vêm do próprio script, para este ficheiro não os repetir
	var notes := RegEx.create_from_string("name\\.startswith\\(\"([^\"]+)\"\\)").search(FileAccess.get_file_as_string(src))
	var files: Array[String] = []
	_text_files("res://", ["gd", "tscn", "tres", "godot", "cfg", "gdshader", "py", "json", "md", "txt", "yml", "html", "svg"], files)
	t._check(files.size() > 100 and "res://README.md" in files, "o F20 devia ler os ficheiros do projeto, com o README.md (leu %d) (K8)" % files.size())
	var hits: Array[String] = []
	for f: String in files:
		var rel := f.trim_prefix("res://")
		var fname := rel.get_file()
		if rel in only_full or rel == "tests/Test0200.gd" or (notes != null and fname.begins_with(notes.get_string(1)) and fname.ends_with(".md")):   # (ficam fora do projeto.zip)
			continue
		var txt := FileAccess.get_file_as_string(f)
		for p: String in only_full:
			if txt.contains(p.get_file().get_basename()):
				hits.append("%s → %s" % [rel, p.get_file()])
	t._check(hits.is_empty(), "o que vai no projeto.zip não pode apontar para as ferramentas que só vão no projeto completo (F20): %s" % ", ".join(PackedStringArray(hits)))
	print("  0.20.0 (F20): %d ficheiros lidos, %d ferramentas só no projeto completo e nada do projeto.zip aponta para elas OK" % [files.size(), only_full.size()])

## Tarefa 16: lançamento. A versão subiu (0.20.0 / code 31 ou mais), o conteúdo embutido passa o 24 da 0.19.1, o
## --min-app do make_manifest acompanha o code, as Novidades têm inglês e um EXPERIMENTAR JÁ que existe, e o Inter
## (subconjunto, tools/subset_fonts.py) tem todas as letras dos textos que o original tem.
static func _test_0200_release(t: Node) -> void:
	var presets := FileAccess.get_file_as_string("res://export_presets.cfg")
	var names := RegEx.create_from_string("version/name=\"([^\"]+)\"").search_all(presets)
	var version: String = names[0].get_string(1) if not names.is_empty() else ""
	var vn := version.split(".")
	var num: int = int(vn[0]) * 10000 + int(vn[1]) * 100 + int(vn[2]) if vn.size() == 3 else 0
	t._check(num >= 2000 and ContentUpdate.APP_VERSION_CODE >= 31, "a versão devia ser a 0.20.0 (ou mais nova) com o code 31 (ou maior): é %s, code %d" % [version, ContentUpdate.APP_VERSION_CODE])
	t._check(ContentUpdate.BUNDLED_CONTENT_VERSION >= 25, "BUNDLED_CONTENT_VERSION devia passar do 24 da 0.19.1 (o maior entre 24 e o c publicado, + 1)")
	var mm := RegEx.create_from_string("\"--min-app\", type=int, default=(\\d+)").search(FileAccess.get_file_as_string("res://tools/make_manifest.py"))
	t._check(mm != null and int(mm.get_string(1)) == ContentUpdate.APP_VERSION_CODE, "o --min-app do make_manifest.py devia ser o code da versão (%d)" % ContentUpdate.APP_VERSION_CODE)
	var en: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://i18n/en.json"))
	t._check(String(en.get("Versão " + version, "")) == "Version " + version, "en.json devia traduzir «Versão %s» por «Version %s»" % [version, version])
	# Novidades: as da versão, com o título, ≥ 5 linhas, tudo com inglês, e o EXPERIMENTAR JÁ numa página que existe.
	var news := NewsOverlay.current()
	var items: Array = news.get("items", [])
	var no_en: Array[String] = []
	for s in [String(news.get("title", ""))] + items:
		if String(en.get(String(s), "")) == "":
			no_en.append(String(s).substr(0, 40))
	t._check(String(news.get("version", "")) == version and String(news.get("title", "")) == "Novidades da " + version and items.size() >= 5 and no_en.is_empty(), "as Novidades deviam ser as da %s, com título, ≥ 5 linhas e inglês (sem inglês: %s)" % [version, str(no_en)])
	var target := String(news.get("try", ""))
	var howto: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://i18n/howto.json"))
	t._check(not target.begins_with("howto:") or String(howto.get("pt", "")).contains("\n\n%s\n" % target.substr(6)), "o EXPERIMENTAR JÁ das Novidades devia abrir uma página do Como Jogar que existe (%s)" % target)
	# Letras: o que o tools/subset_fonts.py lá poria (os mesmos ficheiros) tem de estar no Inter do jogo.
	var inter := load("res://assets/fonts/Inter-Medium.otf") as FontFile
	var full := FontFile.new()
	var full_ok := full.load_dynamic_font("res://tools/brand/fonts_src/Inter-Medium.otf") == OK
	var lost := {}
	if full_ok and inter != null:
		var files: Array[String] = ["res://notas_versao.txt"]
		for d: String in ["res://data", "res://i18n"]:
			for f: String in DirAccess.get_files_at(d):
				if f.ends_with(".json"):
					files.append(String(d).path_join(f))
		_text_files("res://scenes", ["gd", "tscn"], files)
		_text_files("res://scripts", ["gd"], files)
		for f: String in DirAccess.get_files_at("res://tests"):
			if f.ends_with(".gd"):
				files.append("res://tests/" + f)
		for f: String in DirAccess.get_files_at("res://tools"):
			if f.begins_with("en_") and f.ends_with(".py"):
				files.append("res://tools/" + f)
		var rx := RegEx.create_from_string("[^\\x{00}-\\x{7F}]+")
		var seen := {}
		for f: String in files:
			for m: RegExMatch in rx.search_all(FileAccess.get_file_as_string(f)):
				var s := m.get_string()
				for i in s.length():
					var c := s.unicode_at(i)
					if seen.has(c):
						continue
					seen[c] = true
					if full.has_char(c) and not inter.has_char(c):
						lost[String.chr(c)] = true
	t._check(full_ok and inter != null and lost.is_empty(), "o Inter do jogo devia ter todas as letras dos textos (correr tools/subset_fonts.py): %s" % "".join(PackedStringArray(lost.keys())))
	print("  0.20.0 (lançamento): versão %s (code %d, conteúdo %d), --min-app, Novidades com inglês e letras do Inter OK" % [version, ContentUpdate.APP_VERSION_CODE, ContentUpdate.BUNDLED_CONTENT_VERSION])
