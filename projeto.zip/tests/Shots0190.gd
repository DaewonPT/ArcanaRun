class_name Shots0190
extends RefCounted
## Capturas da 0.19.0 (Screenshots.tscn -- --only=0190, ou --only=0190s3 só para a secção 3). `s` é o nó do
## Screenshots (tem _wait, _shoot, _shoot_scene e _clear_toasts).

## 3. Loot e economia: loja (cabeçalho, cesto, probabilidades, booster), Mercador Cego (empréstimo), mapa (previsão,
## risco, Elite), carta depois da batalha, Baú, eventos (roda e baús), interlúdio, fim da run (ouro), Torre (loja),
## Campanha (opção das cartas) e Bestiário.
static func section3(s: Node) -> void:
	var tree: SceneTree = s.get_tree()
	Settings.tips_enabled = false
	Settings.show_art = true
	GameState.new_run("deck07", 19031)
	GameState.relic_ids.clear()
	for id in ["relic_aether_battery", "relic_veteran_medal", "relic_ruby"]:
		GameState.add_relic(id)
	GameState.consumables.clear()
	GameState.add_consumable("potion_heal")
	GameState.ante = 2
	GameState.gold = 34
	GameState.econ["rare_drought"] = 3
	GameState.run_talents = {"shop_discount": 1.0}
	GameState.map_options(2)
	GameState.choose_stop("shop")
	var shop: Node = load("res://scenes/shop/Shop.tscn").instantiate()
	s.add_child(shop)
	await s._wait(1.6)
	s._clear_toasts()
	await s._shoot("190_s3a_loja")
	shop.call("_set_basket_mode", true)
	var tiles: Array = shop.get("_tiles")
	if tiles.size() > 1:
		shop.call("_toggle_basket", (tiles[0] as ShopCardTile).key)
		shop.call("_toggle_basket", (tiles[1] as ShopCardTile).key)
	shop.call("_toggle_basket", "item")
	await s._wait(0.5)
	await s._shoot("190_s3b_loja_cesto")
	shop.call("_set_basket_mode", false)
	shop.call("_open_odds")
	await s._wait(0.6)
	await s._shoot("190_s3c_probabilidades")
	SceneRouter.close_overlays()
	await s._wait(0.3)
	if tiles.size() > 2:
		shop.call("_on_tile_tapped", tiles[2])
	await s._wait(0.4)
	await s._shoot("190_s3c2_loja_reservar")
	shop.call("_on_booster")
	await s._wait(3.6)
	await s._shoot("190_s3d_booster_extras")
	SceneRouter.close_overlays()
	await s._wait(0.3)
	shop.queue_free()
	await tree.process_frame
	GameState.run_talents = {}
	GameState.ante = 4
	GameState.map_options(4)
	GameState.choose_stop("merchant")
	await s._shoot_scene("res://scenes/shop/Shop.tscn", "190_s3e_mercador_emprestimo", 1.2)
	# Mapa: previsão, risco, Elite com a raridade.
	GameState.new_run("deck01", 19032)
	GameState.ante = 3
	GameState.gold = 23
	GameState.map_phase = "battle"
	GameState.interlude_key = GameState.climate_key(3)
	GameState.map_plan[str(3)] = {"battle": ["scout", "guard", "elite"], "stop": ["shop", "event"]}
	Economy.set_risk(true)
	await s._shoot_scene("res://scenes/map/Map.tscn", "190_s3f_mapa", 1.4)
	Economy.clear_risk()
	# A carta depois da batalha.
	Economy.set_card_rewards(true)
	Economy.prepare_card_reward()
	var map: Node = load("res://scenes/map/Map.tscn").instantiate()
	s.add_child(map)
	await s._wait(1.6)
	await s._shoot("190_s3g_carta_depois")
	SceneRouter.close_overlays()
	map.queue_free()
	await tree.process_frame
	Economy.set_card_rewards(false)
	GameState.econ.erase("card_reward")
	# O Baú de Espólio com RENOVAR.
	GameState.ante = 4
	GameState.gold = 30
	GameState.prepare_loot()
	await s._shoot_scene("res://scenes/loot/Loot.tscn", "190_s3h_bau_renovar", 1.0)
	SceneRouter.close_overlays()
	# Eventos: a roda do Tribunal e os baús do Tesouro.
	GameState.pending_event = "node_tribunal"
	await s._shoot_scene("res://scenes/event/Event.tscn", "190_s3i_tribunal", 0.8)
	GameState.pending_event = "node_treasure"
	await s._shoot_scene("res://scenes/event/Event.tscn", "190_s3j_tesouro", 0.8)
	GameState.pending_event = ""
	# O interlúdio do ato II com o resumo do ato I.
	GameState.run_log["act_log"] = {"1": {"gold": 46, "cards": 4, "relics": 2}}
	GameState.ante = 3
	GameState.interlude_key = ""
	var inter := ActInterlude.open_if_new()
	await s._wait(1.2)
	await s._shoot("190_s3k_interludio_resumo")
	if inter != null:
		inter.close()
	SceneRouter.close_overlays()
	await s._wait(0.3)
	# Fim da run: o ouro por ante e ONDE GASTEI.
	GameState.run_log["damage_by_ante"] = {"1": 3200, "2": 7400, "3": 12800, "4": 21000}
	GameState.run_log["card_dmg"] = {"c001": 9000}
	GameState.run_log["relic_dmg"] = {"relic_ruby": 4100}
	GameState.run_log["gold_by_ante"] = {"1": {"in": 12, "out": 8}, "2": {"in": 18, "out": 14, "interest": 3}, "3": {"in": 24, "out": 30, "interest": 4, "sold": 4}, "4": {"in": 20, "out": 5, "interest": 5}}
	GameState.run_log["spent"] = {"card": 28, "relic": 18, "service": 7, "reroll": 4}
	GameState.run_log["bought"] = [{"k": "card", "id": "c001", "p": 6, "a": 2}]
	GameState.run_log["best_hit"] = 12000
	GameState.ante = 4
	GameState.player_hp = 0
	GameState.last_victory = false
	await s._shoot_scene("res://scenes/ui/RunOver.tscn", "190_s3l_fim_ouro", 1.2)
	# A Torre num andar de boss, com a loja.
	GameState.new_tower_run("deck01", 19033)
	GameState.ante = 5
	GameState.gold = 22
	GameState.tower_prepare_offer()
	var tw: Node = load("res://scenes/tower/Tower.tscn").instantiate()
	s.add_child(tw)
	await s._wait(1.2)
	await s._shoot("190_s3m_torre_loja")
	SideShop.open()
	await s._wait(0.6)
	await s._shoot("190_s3n_loja_da_torre")
	SceneRouter.close_overlays()
	tw.queue_free()
	await tree.process_frame
	# A Campanha com a opção das cartas.
	GameState.free_mode = false
	await s._shoot_scene("res://scenes/campaign/Campaign.tscn", "190_s3o_campanha", 0.9)
	GameState.clear_saved_run()

## 4. Clareza visual: a batalha com as marcas (formação, fecha, cor fraca, +, sangue), o valor nas relíquias,
## quanto falta, o escudo na barra, os lacaios, a fila do inimigo, os contadores, o clima, a poção letal, a carta
## em grande (de onde vem o Poder), o mapa (NOVO, boss, a seguir, legenda), o booster (mítica) e as Configurações.
static func section4(s: Node) -> void:
	var tree: SceneTree = s.get_tree()
	Settings.tips_enabled = false
	Settings.show_art = true
	GameState.free_mode = false
	GameState.new_run("deck01", 19041)
	GameState.relic_ids.clear()
	for id in ["relic_drum", "relic_ruby", "relic_lens"]:
		GameState.add_relic(id)
	GameState.consumables.clear()
	GameState.add_consumable("scroll_fire")
	GameState.ante = 3
	var normal_id := ""
	for e in CardDB.enemies:
		if not bool(e.get("boss", false)) and not bool(e.get("saga", false)) and normal_id == "":
			normal_id = String(e.get("id", ""))
	var st: Dictionary = s._battle_state(normal_id, ["c010", "c002", "c008", "c476", "c004"], ["c001", "c003", "c005"])
	st["enemy"]["shield_pct"] = 2
	st["enemy"]["ritual"] = {}
	var b: Node = s._open_battle(st)
	await s._wait(1.8)
	var bm: BattleManager = b.battle
	bm.weak_color = "red"
	bm.minions = [2]
	bm.ritual = {"turns": 1, "action": "heal", "value": 1, "text": "Teste"}
	bm.crown = true
	var pc := CardDB.new_instance("c005")
	pc.data = pc.data.plus_version()
	pc.zone = CardInstance.Zone.HAND
	bm.deck.hand.append(pc)
	b._intent_sig = ""
	b._refresh_defense()
	b._refresh_all()
	b._refresh_preview()
	b._refresh_info_row()
	await s._wait(0.8)
	s._clear_toasts()
	await s._wait(0.1)
	s._clear_toasts()
	await s._shoot("190_s4a_batalha_marcas")
	# O clima a agir e a recapitulação do inimigo.
	bm.climate = "aether_tide"
	b._climate_turn_notices(1)
	b._enemy_log_from = b._history.size()
	b._log(TranslationServer.translate("Levaste %d de dano.") % 3)
	b._show_enemy_recap()
	await s._wait(0.6)
	await s._shoot("190_s4b_clima_e_turno_dele")
	bm.climate = ""
	# Poção que dá letal e o ouro do Excesso.
	bm.enemy["shield_pct"] = 0
	bm.enemy["hp"] = 900
	EventBus.enemy_hp_changed.emit(900, int(bm.enemy.max_hp))
	bm.minions = []
	b._intent_sig = ""
	b._refresh_defense()
	b._refresh_preview()
	await s._wait(0.5)
	await s._shoot("190_s4c_letal_e_pocao")
	# A carta em grande: de onde vem o Poder.
	var c1 := (bm.board[0] as CardInstance)
	c1.power_bonus = 15
	CardZoom.show_card(c1)
	await s._wait(0.6)
	await s._shoot("190_s4d_poder_de_onde_vem")
	SceneRouter.close_overlays()
	await s._wait(0.2)
	# Os contadores das mecânicas.
	b._mech_deck_tags = {"delirium": true, "domain": true, "_done": true}
	b._refresh_info_row()
	b._open_mech_info()
	await s._wait(0.5)
	await s._shoot("190_s4e_contadores")
	SceneRouter.close_overlays()
	b.queue_free()
	await tree.process_frame
	# O mapa: NOVO, caminho até ao boss, quem vem a seguir e a legenda.
	GameState.new_run("deck01", 19042)
	GameState.ante = 2
	GameState.map_phase = "battle"
	GameState.interlude_key = GameState.climate_key(2)
	var had: Variant = GameState.progress.get("seen_nodes")
	GameState.progress["seen_nodes"] = []
	var nid := GameState.planned_enemy(2)
	Stats.mark_seen("enemies", nid)
	var map: Node = load("res://scenes/map/Map.tscn").instantiate()
	s.add_child(map)
	await s._wait(1.6)
	s._clear_toasts()
	await s._shoot("190_s4f_mapa")
	map.open_legend("elite", 2)
	await s._wait(0.5)
	await s._shoot("190_s4g_legenda")
	SceneRouter.close_overlays()
	map.queue_free()
	await tree.process_frame
	if had == null:
		GameState.progress.erase("seen_nodes")
	else:
		GameState.progress["seen_nodes"] = had
	# O booster com uma mítica.
	var holder := Control.new()
	holder.set_anchors_preset(Control.PRESET_FULL_RECT)
	s.add_child(holder)
	var row := HBoxContainer.new()
	row.position = Vector2(300, 160)
	row.add_theme_constant_override("separation", 30)
	holder.add_child(row)
	for rid in [["c001", "common"], ["c005", "uncommon"], ["c069", "rare"], ["c099", "mythic"]]:
		var v: CardView = load("res://scenes/ui/CardView.tscn").instantiate()
		v.custom_minimum_size = Vector2(169, 242)
		row.add_child(v)
		v.setup(CardDB.new_instance(String(rid[0])))
		await tree.process_frame
		load("res://scenes/shop/BoosterOpen.gd").rarity_tag(v, String(rid[1]))
	await s._wait(0.5)
	await s._shoot("190_s4h_raridade")
	holder.queue_free()
	await tree.process_frame
	# As Configurações → Visual (foco, fundo calmo, brilho).
	SettingsMenu.open("visual")
	await s._wait(0.8)
	await s._shoot("190_s4i_config_visual")
	SceneRouter.close_overlays()
	GameState.clear_saved_run()

## 5. Legibilidade e HUD: a batalha com os nomes dos ícones, o relógio, o contador de relíquias, o contrato a contar e
## a regra com o efeito; o histórico com filtros; o painel recolhido; o modo explicar; as cartas claras com lembretes;
## o A+ e o glossário; o Como Jogar (ícones e NOVO); o sino; a Coleção com o caminho; as Configurações → Texto e HUD.
static func section5(s: Node) -> void:
	var tree: SceneTree = s.get_tree()
	Settings.tips_enabled = false
	Settings.show_art = true
	GameState.free_mode = false
	GameState.new_run("deck01", 19051)
	GameState.relic_ids.clear()
	for id in ["relic_drum", "relic_ruby"]:
		GameState.add_relic(id)
	GameState.set_contract("formations")
	GameState.gold = 14
	Settings.set_opt("icon_labels", true, false)
	Settings.set_opt("clock", true, false)
	SceneRouter.refresh_clock()
	var boss_id := "boss_forger"
	var st: Dictionary = s._battle_state(boss_id, ["c010", "c002", "c008", "c004"], ["c001", "c003", "c005"])
	var b: Node = s._open_battle(st)
	await s._wait(1.8)
	b._refresh_all()
	SceneRouter.toast("★ " + TranslationServer.translate("Conquista: %s") % "Teste", 6.0, false, {}, true)
	await s._wait(0.8)
	await s._shoot("190_s5a_batalha_hud")
	# O ataque com os números grandes e com fundo (a meio da cascata).
	Settings.set_opt("cascade_big", true, false)
	b._pop(b._board_views.values()[0], "+30 Poder", b.COLOR_POWER, "power_add")
	b._pop(b._relic_views.values()[1], "×2 Mult", b.COLOR_MULT_X, "mult_mul")
	await s._wait(0.15)
	await s._shoot("190_s5b_cascata_maior")
	Settings.reset_options(["cascade_big"], false)
	await s._wait(0.6)
	# O histórico com filtros.
	b._log("O Forjador de Moedas cobrou 1 ouro.")
	b._open_history()
	await s._wait(0.5)
	await s._shoot("190_s5c_historico")
	SceneRouter.close_overlays()
	await s._wait(0.3)
	# O painel do inimigo recolhido e o modo explicar.
	b.toggle_enemy_panel()
	SceneRouter.set_explain_mode(true)
	await s._wait(0.3)
	SceneRouter.show_balloon(TranslationServer.translate("Grimório"), b.library_btn.get_global_rect().get_center())
	await s._wait(0.5)
	await s._shoot("190_s5d_recolhido_e_explicar")
	SceneRouter.set_explain_mode(false)
	b.toggle_enemy_panel()
	b.queue_free()
	Settings.reset_options(["icon_labels"], false)
	await tree.process_frame
	# Cartas claras com os lembretes das palavras-chave.
	Settings.set_opt("light_cards", true, false)
	Settings.set_opt("kw_reminders", true, false)
	var holder := Control.new()
	holder.set_anchors_preset(Control.PRESET_FULL_RECT)
	s.add_child(holder)
	var bgr := ColorRect.new()
	bgr.color = Color(0.1, 0.08, 0.14)
	bgr.set_anchors_preset(Control.PRESET_FULL_RECT)
	holder.add_child(bgr)
	var row := HBoxContainer.new()
	row.position = Vector2(200, 180)
	row.add_theme_constant_override("separation", 26)
	holder.add_child(row)
	var shown := 0
	for id in CardDB.cards:
		var d: CardData = CardDB.cards[id]
		if shown < 5 and d.is_creature() and not d.token and not d.keywords.is_empty():
			var v: CardView = load("res://scenes/ui/CardView.tscn").instantiate()
			v.custom_minimum_size = Vector2(169, 242)
			row.add_child(v)
			v.setup(CardDB.new_instance(String(id)))
			shown += 1
	await s._wait(0.6)
	await s._shoot("190_s5e_cartas_claras")
	holder.queue_free()
	Settings.reset_options(["light_cards", "kw_reminders"], false)
	await tree.process_frame
	# A carta em grande com o A+ e um termo do glossário com exemplo.
	Settings.set_opt("zoom_text", true, false)
	CardZoom.show_card(CardDB.new_instance("c001"))
	await s._wait(0.5)
	var z := SceneRouter.top_overlay()
	if z != null and z.has_method("_show_term"):
		for i in CardDB.glossary.size():
			if String(CardDB.glossary[i].get("term", "")) == "Arena":
				z.call("_show_term", i)
	await s._wait(0.3)
	await s._shoot("190_s5f_zoom_a_mais")
	SceneRouter.close_overlays()
	Settings.set_opt("zoom_text", false, false)
	await s._wait(0.3)
	# O Como Jogar com ícones e NOVO, aberto na página certa.
	var seen0 := int(GameState.progress.get("howto_seen_code", 0))
	GameState.progress["howto_seen_code"] = 0
	HowToPlay.open_at("MARCAS E PREVISÕES")
	await s._wait(0.8)
	await s._shoot("190_s5g_como_jogar")
	SceneRouter.close_overlays()
	GameState.progress["howto_seen_code"] = seen0
	await s._wait(0.3)
	# O sino com os últimos avisos.
	SceneRouter.toast("Compraste: Tambor de Guerra.", 1.0, false)
	NoticeLog.open()
	await s._wait(0.5)
	await s._shoot("190_s5h_avisos")
	SceneRouter.close_overlays()
	await s._wait(0.3)
	# A Coleção com o caminho no título.
	var col: Node = load("res://scenes/ui/Collection.tscn").instantiate()
	s.add_child(col)
	await s._wait(1.0)
	col._select_tab("relics")
	await s._wait(0.6)
	await s._shoot("190_s5i_colecao_caminho")
	col.queue_free()
	await tree.process_frame
	# O mapa com o «?».
	GameState.ante = 2
	GameState.map_phase = "battle"
	GameState.interlude_key = GameState.climate_key(2)
	await s._shoot_scene("res://scenes/map/Map.tscn", "190_s5j_mapa_ajuda", 1.4)
	# As Configurações → Texto e HUD.
	SettingsMenu.open("text")
	await s._wait(0.8)
	await s._shoot("190_s5k_config_texto")
	SceneRouter.close_overlays()
	Settings.reset_options(["clock"], false)
	SceneRouter.refresh_clock()
	GameState.contract = {}
	GameState.clear_saved_run()

## 6. Tempo e sessão: o menu (JOGAR, modos curtos, durações, enigma ao acaso, conquista perto), onde ficaste,
## regras ao voltar, lembrete de pausa, Estatísticas com o tempo, a pausa com quanto falta e as Configurações → Ritmo.
static func section6(s: Node) -> void:
	var tree: SceneTree = s.get_tree()
	Settings.tips_enabled = false
	var keep_hist = GameState.progress.get("history", []).duplicate(true) if GameState.progress.get("history") is Array else []
	var keep_tm = GameState.progress.get("time_by_mode", {}).duplicate() if GameState.progress.get("time_by_mode") is Dictionary else {}
	var keep_ps = GameState.progress.get("play_secs", 0.0)
	GameState.progress["history"] = [
		{"mode": "quick", "deck_id": "deck01", "deck": "Centelha Rubra", "secs": 1320, "ante": 4, "won": true, "t": 1761000000.0, "best_hit": 4200, "stake": 2},
		{"mode": "campaign", "deck_id": "deck05", "deck": "Maré Profunda", "secs": 2900, "ante": 5, "won": false, "t": 1760500000.0, "best_hit": 2600},
		{"mode": "mini", "deck_id": "deck03", "deck": "Floresta", "secs": 620, "ante": 2, "won": true, "t": 1760000000.0, "best_hit": 1900}]
	GameState.progress["time_by_mode"] = {"campaign": 10800.0, "quick": 5400.0, "mini": 1240.0}
	GameState.progress["play_secs"] = 17440.0
	GameState.remember_choice("quick", "deck01", 2, "classic", 0)
	await s._shoot_scene("res://scenes/main/Main.tscn", "190_s6a_menu_jogar", 1.6)
	var m: Node = load("res://scenes/main/Main.tscn").instantiate()
	s.add_child(m)
	await s._wait(1.2)
	m._show_page("new", false)
	await s._wait(0.6)
	await s._shoot("190_s6b_novo_jogo_curtos")
	m._show_page("modes", false)
	await s._wait(0.6)
	await s._shoot("190_s6c_modos_enigma")
	m.queue_free()
	await tree.process_frame
	var old_lang := Settings.language
	Settings.language = "en"
	Settings.apply()
	var me: Node = load("res://scenes/main/Main.tscn").instantiate()
	s.add_child(me)
	await s._wait(1.2)
	me._show_page("new", false)
	await s._wait(0.6)
	await s._shoot("190_s6b2_novo_jogo_en")
	me.queue_free()
	Settings.language = old_lang
	Settings.apply()
	await tree.process_frame
	# Onde ficaste e as regras ao voltar.
	GameState.new_quick_run("deck01", 1, 19061)
	GameState.relic_ids.clear()
	for id in ["relic_drum", "relic_ruby"]:
		GameState.add_relic(id)
	GameState.ante = 3
	GameState.map_options(3)
	SessionWindows.open_resume(func(): pass)
	await s._wait(0.6)
	await s._shoot("190_s6d_onde_ficaste")
	SceneRouter.close_overlays()
	await s._wait(0.3)
	SessionWindows.open_rules()
	await s._wait(0.6)
	await s._shoot("190_s6e_regras_ao_voltar")
	SceneRouter.close_overlays()
	await s._wait(0.3)
	SceneRouter.break_reminder(TranslationServer.translate("Já jogas há %s. Que tal uma pausa?") % GameState.fmt_duration(3720))
	await s._wait(0.6)
	await s._shoot("190_s6f_pausa")
	SceneRouter.close_overlays()
	await s._wait(0.3)
	# As Estatísticas com o tempo de jogo e o histórico com o dia e a duração.
	await s._shoot_scene("res://scenes/ui/StatsScreen.tscn", "190_s6g_estatisticas_tempo", 1.4)
	var ss: Node = load("res://scenes/ui/StatsScreen.tscn").instantiate()
	s.add_child(ss)
	await s._wait(1.0)
	ss.select_tab("history")
	await s._wait(0.6)
	await s._shoot("190_s6h_historico_dia")
	ss.queue_free()
	await tree.process_frame
	# As Configurações → Ritmo.
	SettingsMenu.open("pace")
	await s._wait(0.8)
	await s._shoot("190_s6i_config_ritmo")
	SceneRouter.close_overlays()
	await s._wait(0.3)
	# A batalha: a pausa com quanto falta e o OUTRO NÓ DO MAPA; o cronómetro.
	GameState.progress["history"].append({"mode": "quick", "deck_id": "deck01", "secs": 1500, "ante": 4, "won": true, "t": 1761000000.0})
	GameState.map_options(3)
	GameState.remember_node_choice()
	Settings.set_opt("speedrun", true, false)
	GameState.run_log["secs"] = 754.0
	var st: Dictionary = s._battle_state("bandit", ["c010", "c002", "c008", "c004"], [])
	var b: Node = s._open_battle(st)
	await s._wait(1.8)
	b._open_pause()
	await s._wait(0.8)
	await s._shoot("190_s6j_pausa_falta")
	SceneRouter.close_overlays()
	b.queue_free()
	Settings.reset_options(["speedrun"], false)
	await tree.process_frame
	GameState.progress["history"] = keep_hist
	GameState.progress["time_by_mode"] = keep_tm
	GameState.progress["play_secs"] = keep_ps
	GameState.clear_saved_run()

## 7. Calor: as Configurações → Desempenho e Visual, o tema preto (menu e batalha), o ecrã escurecido e as chamas paradas.
static func section7(s: Node) -> void:
	var tree: SceneTree = s.get_tree()
	Settings.tips_enabled = false
	SettingsMenu.open("perf")
	await s._wait(0.8)
	await s._shoot("190_s7a_config_desempenho")
	SceneRouter.close_overlays()
	await s._wait(0.3)
	Settings.set_opt("theme", "black", false)
	await s._shoot_scene("res://scenes/main/Main.tscn", "190_s7b_menu_tema_preto", 1.4)
	GameState.new_run("deck01", 19071)
	GameState.relic_ids.clear()
	GameState.add_relic("relic_drum")
	var st: Dictionary = s._battle_state("bandit", ["c010", "c002", "c008", "c004"], ["c001", "c003"])
	var b: Node = s._open_battle(st)
	await s._wait(1.8)
	await s._shoot("190_s7c_batalha_tema_preto")
	Settings.reset_options(["theme"], false)
	b.queue_free()
	await tree.process_frame
	# Modo de desempenho: as chamas paradas por trás das pílulas e o ecrã escurecido ao fim de 2 minutos.
	var keep_perf := Settings.performance_mode
	Settings.performance_mode = true
	var b2: Node = s._open_battle(s._battle_state("bandit", ["c010", "c002", "c008", "c004"], ["c001", "c003", "c005"]))
	await s._wait(1.8)
	b2._fire_target = 0.9
	b2._fire_level = 0.9
	await s._wait(0.4)
	await s._shoot("190_s7d_chamas_paradas")
	SceneRouter.thermal.set_dimmed(true)
	await s._wait(0.3)
	await s._shoot("190_s7e_ecra_escurecido")
	SceneRouter.thermal.set_dimmed(false)
	Settings.performance_mode = keep_perf
	b2.queue_free()
	await tree.process_frame
	GameState.clear_saved_run()

## 8. Armazenamento: o espaço ocupado, o progresso num ficheiro, o aviso de fecho inesperado, a atualização com o
## tamanho, o modo programador e a roda de espera.
static func section8(s: Node) -> void:
	var tree: SceneTree = s.get_tree()
	Settings.tips_enabled = false
	var sm := SettingsMenu.open("game")
	await s._wait(0.6)
	sm._on_storage_open()
	await s._wait(0.5)
	await s._shoot("190_s8a_espaco_ocupado")
	sm._on_export()
	await s._wait(0.5)
	await s._shoot("190_s8b_exportar_ficheiro")
	SceneRouter.close_overlays()
	await s._wait(0.3)
	var m: Node = load("res://scenes/main/Main.tscn").instantiate()
	s.add_child(m)
	await s._wait(1.4)
	SceneRouter.close_overlays()
	m._show_update({"name": "Zero-Sum 0.19.1", "size": 54525952, "apk": AppUpdate.APK_PREFIX + "x/ZeroSum_v0.19.1.apk"})
	Settings.set_opt("dev_mode", true, false)
	SceneRouter.refresh_dev_overlay()
	SceneRouter.show_spinner(true)
	await s._wait(0.6)
	await s._shoot("190_s8c_menu_atualizar_programador")
	SceneRouter.show_spinner(false)
	Settings.set_opt("dev_mode", false, false)
	SceneRouter.refresh_dev_overlay()
	Storage.crashed_before = true
	m.maybe_crash_offer()
	await s._wait(0.6)
	await s._shoot("190_s8d_fecho_inesperado")
	SceneRouter.close_overlays()
	m.queue_free()
	await tree.process_frame

## 9. Acessibilidade e personalização: o tema claro (Configurações, Como Jogar, escolha), as perguntas do 1.º arranque,
## a carta com o altifalante, o modo daltónico (moldura, padrões, formas no mapa), o filtro de cores, as legendas
## dos sons, a batalha com o botão de silenciar, a jukebox, os cosméticos do baralho e a imagem de partilha com o mago.
static func section9(s: Node) -> void:
	var tree: SceneTree = s.get_tree()
	Settings.tips_enabled = false
	Settings.set_opt("theme", "light", false)
	Settings.apply()
	SettingsMenu.open("access")
	await s._wait(0.8)
	await s._shoot("190_s9a_tema_claro_config")
	SceneRouter.close_overlays()
	await s._wait(0.3)
	HowToPlay.open_at("A CASCATA")
	await s._wait(0.8)
	await s._shoot("190_s9b_tema_claro_como_jogar")
	SceneRouter.close_overlays()
	await s._wait(0.3)
	SessionWindows.open_first_run()
	await s._wait(0.6)
	await s._shoot("190_s9c_primeiro_arranque_claro")
	SceneRouter.close_overlays()
	Settings.reset_options(["theme"], false)
	Settings.apply()
	await s._wait(0.3)
	CardZoom.show_card(CardDB.new_instance("c001"))
	await s._wait(0.6)
	await s._shoot("190_s9d_carta_ouvir")
	SceneRouter.close_overlays()
	await s._wait(0.3)
	# Modo daltónico: símbolos na moldura, padrões nos estados e formas no mapa.
	var keep_cb := Settings.colorblind
	Settings.colorblind = true
	GameState.new_run("deck01", 19091)
	GameState.relic_ids.clear()
	GameState.add_relic("relic_drum")
	GameState.add_relic("relic_ruby")
	var st: Dictionary = s._battle_state("bandit", ["c010", "c002", "c008", "c004"], ["c001", "c003", "c005"])
	var b: Node = s._open_battle(st)
	await s._wait(1.8)
	var hv: Array = b._hand_views.values()
	if not hv.is_empty():
		(hv[0] as CardView).set_frozen(true, 1)
	Settings.set_opt("captions", true, false)
	Sfx.named("relic")
	Sfx.named("boss")
	await s._wait(0.3)
	await s._shoot("190_s9e_daltonico_batalha_legendas")
	Settings.reset_options(["captions"], false)
	Settings.set_opt("colorblind_filter", "deutan", false)
	SceneRouter.refresh_cvd()
	await s._wait(0.4)
	await s._shoot("190_s9f_filtro_deuteranopia")
	Settings.reset_options(["colorblind_filter"], false)
	SceneRouter.refresh_cvd()
	b.queue_free()
	await tree.process_frame
	GameState.ante = 2
	GameState.map_phase = "stop"
	GameState.map_options(2)
	await s._shoot_scene("res://scenes/map/Map.tscn", "190_s9g_mapa_formas", 1.4)
	Settings.colorblind = keep_cb
	Jukebox.open()
	await s._wait(0.6)
	await s._shoot("190_s9h_jukebox")
	SceneRouter.close_overlays()
	await s._wait(0.3)
	DeckCosmetics.open("deck01")
	await s._wait(0.6)
	await s._shoot("190_s9i_cosmeticos_baralho")
	SceneRouter.close_overlays()
	await s._wait(0.3)
	var sm := RunShare.summary_from_state(true, false)
	var card := RunShare.build_card(sm)
	var holder := Control.new()
	holder.set_anchors_preset(Control.PRESET_FULL_RECT)
	s.add_child(holder)
	card.scale = Vector2(0.5, 0.5)
	holder.add_child(card)
	await s._wait(0.6)
	await s._shoot("190_s9j_partilha_mago")
	holder.queue_free()
	await tree.process_frame
	GameState.clear_saved_run()
