extends Node
## Simulação de equilíbrio (headless):  godot --headless --path . res://tests/Balance.tscn
##  A) baralho inicial, sem loja: até que ante chega cada cor? (10 seeds)
##  B) com uma loja "gananciosa" (compra relíquias por ordem + 1 carta por visita): até onde vai?

var _verbose := false
const RELIC_ORDER := ["relic_drum", "relic_ruby", "relic_seed", "relic_seal", "relic_banner", "relic_grimoire", "relic_lotus", "relic_tectonic", "relic_purse", "relic_forge"]

func _ready() -> void:
	await get_tree().process_frame
	print("--- A) sem loja")
	for color in ["white", "red", "green"]:
		_report(color, false)
	print("--- B) com loja gananciosa")
	_verbose = true
	for color in ["white", "red", "green"]:
		_report(color, true)
	get_tree().quit()

func _report(color: String, shop: bool) -> void:
	var reached: Array[int] = []
	var total := 0
	for seed_v in range(1, 11):
		var r := _simulate_run(color, seed_v, shop)
		reached.append(r)
		total += r
	print("%s: perde no ante %s (média %.1f)" % [color, str(reached), float(total) / reached.size()])

## Devolve o ante em que a run acabou (9 = venceu os 8 antes).
func _simulate_run(color: String, seed_v: int, shop: bool) -> int:
	GameState.new_run(color, seed_v)
	var ante := 1
	while ante <= GameState.max_ante:
		GameState.ante = ante
		if not _simulate_battle(ante):
			return ante
		if shop:
			_greedy_shop(color)
		ante += 1
	return ante

func _simulate_battle(ante: int) -> bool:
	var pool := CardDB.enemies.filter(func(e): return int(e.get("min_ante", 1)) <= ante)
	var def: Dictionary = pool[GameState.rng.randi_range(0, pool.size() - 1)]
	var hp := GameState.enemy_hp_for_ante(ante)
	var bm := BattleManager.new()
	bm.start({"name": def.name, "hp": hp, "max_hp": hp, "attack": int(def.attack), "text": "", "abilities": def.get("abilities", [])})
	var result := [null]
	var cb := func(v: bool): result[0] = v
	EventBus.battle_ended.connect(cb)
	var guard := 0
	while result[0] == null and guard < 50:
		guard += 1
		var played := true
		while played:
			played = false
			for card in bm.deck.hand.duplicate():
				if bm.can_play(card):
					bm.play(card)
					played = true
					break
		bm.end_turn()
	EventBus.battle_ended.disconnect(cb)
	if result[0] != true and _verbose:
		print("    ante %d: morreu contra %s (ataque %d) — inimigo %d/%d, jogador %d, turno %d, relíquias %d, deck %d" % [ante, def.name, int(def.attack), bm.enemy.hp, hp, GameState.player_hp, bm.turn, GameState.relic_ids.size(), GameState.deck_ids.size()])
	return result[0] == true

func _greedy_shop(color: String) -> void:
	# 1 relíquia (a primeira que consiga pagar, pela ordem) ...
	var color_relic := {"red": "relic_ruby", "green": "relic_seed", "white": "relic_seal"}
	for relic_id in RELIC_ORDER:
		if relic_id in GameState.relic_ids:
			continue
		if relic_id in color_relic.values() and relic_id != color_relic[color]:
			continue   # relíquia de outra cor: um humano não a comprava
		var price: int = int(CardDB.relics[relic_id].get("price", 99))
		if GameState.gold >= price:
			GameState.spend_gold(price)
			GameState.add_relic(relic_id)
			break
	# ... e 1 carta da cor (a mais cara que consiga pagar).
	var options: Array = CardDB.cards_by_color(color).filter(func(c): return c.type != "land" and c.rarity != "starter")
	options.sort_custom(func(a, b): return a.price > b.price)
	for c in options:
		if GameState.gold >= c.price:
			GameState.spend_gold(c.price)
			GameState.add_card(c.id)
			break
