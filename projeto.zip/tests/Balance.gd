extends Node
## Simulação de equilíbrio (headless):  godot --headless --path . res://tests/Balance.tscn
##  A) cada baralho sem loja: até que ante chega? (N seeds)
##  B) com uma loja "sensata" (relíquias das suas cores por ordem + 1 carta por visita): até onde vai?
## O bot joga tudo o que pode (terrenos só se não tiver outra coisa) e canaliza uma carta por turno
## se tiver mais de 2 na mão.

const SEEDS := 8
const COLOR_RELIC := {"red": "relic_ruby", "green": "relic_seed", "white": "relic_seal", "blue": "relic_sapphire", "black": "relic_jet"}
const RELIC_ORDER := ["COLOR", "relic_banner", "COLOR", "relic_drum", "relic_lotus", "relic_crown", "relic_grimoire", "relic_mirror", "relic_lens", "relic_hourglass", "relic_anvil", "relic_echo", "relic_tectonic", "relic_purse"]

var _verbose := false
var _deaths: Dictionary = {}   # nome do inimigo -> contagem
var _causes: Dictionary = {"turnos": 0, "vida": 0}   # porque acabou a run (com loja)
var _left_pct: Array = []      # % da vida do inimigo que ficou por tirar, nas derrotas por turnos
var _loss_ante: Dictionary = {}  # ante -> derrotas (com loja)
var _seeds := SEEDS
var _lose_hp := false   # experiência: perder por turnos tira vida em vez de acabar a run

func _ready() -> void:
	await get_tree().process_frame
	var only := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--deck="):
			only = arg.substr(7)
		elif arg.begins_with("--difficulty="):
			GameState.difficulty = arg.substr(13)
		elif arg.begins_with("--seeds="):
			_seeds = int(arg.substr(8))
		elif arg.begins_with("--ante-hp="):
			GameState.ante_hp = Array(arg.substr(10).split(",")).map(func(x): return int(x))
		elif arg.begins_with("--turns="):
			GameState.base_turns = int(arg.substr(8))
		elif arg == "--lose-hp":
			_lose_hp = true
	print("dificuldade: %s" % GameState.difficulty)
	print("--- A) sem loja")
	var sum_a := 0.0
	for deck in CardDB.decks:
		if only != "" and String(deck.id) != only:
			continue
		sum_a += _report(deck, false)
	print("--- B) com loja")
	_verbose = "--verbose" in OS.get_cmdline_user_args()
	var sum_b := 0.0
	var n := 0
	for deck in CardDB.decks:
		if only != "" and String(deck.id) != only:
			continue
		sum_b += _report(deck, true)
		n += 1
	print("média geral: sem loja %.1f · com loja %.1f" % [sum_a / max(1, n), sum_b / max(1, n)])
	print("mortes por inimigo (com loja): ", str(_deaths))
	var wins_total := 0
	var runs_total := 0
	for k in _win_count:
		wins_total += int(_win_count[k])
	runs_total = n * _seeds
	var avg_left := 0.0
	for v in _left_pct:
		avg_left += float(v)
	avg_left = avg_left / max(1, _left_pct.size())
	print("vitórias com loja: %d/%d (%.0f%%) · fim por turnos %d, por vida %d · faltava em média %.0f%% da vida do inimigo" % [wins_total, runs_total, 100.0 * wins_total / max(1, runs_total), _causes["turnos"], _causes["vida"], avg_left])
	print("derrotas por ante (com loja): ", str(_loss_ante))
	get_tree().quit()

var _win_count: Dictionary = {}

func _report(deck: Dictionary, shop: bool) -> float:
	var reached: Array[int] = []
	var total := 0
	var wins := 0
	for seed_v in range(1, _seeds + 1):
		var r := _simulate_run(String(deck.id), seed_v, shop)
		reached.append(r)
		total += r
		if r > GameState.max_ante:
			wins += 1
	var avg := float(total) / reached.size()
	if shop:
		_win_count[String(deck.id)] = wins
	print("%02d %-22s perde no ante %s  média %.1f  vitórias %d/%d" % [int(deck.num), deck.name, str(reached), avg, wins, _seeds])
	return avg

## Devolve o ante em que a run acabou (9 = venceu os 8 antes).
func _simulate_run(deck_id: String, seed_v: int, shop: bool) -> int:
	GameState.new_run(deck_id, seed_v)
	var ante := 1
	while ante <= GameState.max_ante:
		GameState.ante = ante
		if not _simulate_battle(ante, shop):
			if not _lose_hp or GameState.player_hp <= 0:
				return ante
			GameState.player_hp -= 5 + ante
			if GameState.player_hp <= 0:
				return ante
		if shop:
			_sensible_shop()
		ante += 1
	return ante

func _simulate_battle(ante: int, verbose_ok: bool) -> bool:
	var def := GameState.pick_enemy(ante)
	var hp: int = def.hp
	var bm := BattleManager.new()
	bm.start(def)
	var result := [null]
	var cb := func(v: bool): result[0] = v
	EventBus.battle_ended.connect(cb)
	var guard := 0
	while result[0] == null and guard < 50:
		guard += 1
		_bot_turn(bm)
		bm.end_turn()
	EventBus.battle_ended.disconnect(cb)
	if result[0] != true and verbose_ok:
		_deaths[def.name] = _deaths.get(def.name, 0) + 1
		_loss_ante[ante] = int(_loss_ante.get(ante, 0)) + 1
		if GameState.player_hp <= 0:
			_causes["vida"] += 1
		else:
			_causes["turnos"] += 1
			_left_pct.append(100.0 * float(bm.enemy.hp) / max(1.0, float(hp)))
		if _verbose:
			print("    ante %d: morreu contra %s — inimigo %d/%d, jogador %d, turno %d, relíquias %d, deck %d" % [ante, def.name, bm.enemy.hp, hp, GameState.player_hp, bm.turn, GameState.relic_ids.size(), GameState.deck.size()])
	return result[0] == true

func _bot_turn(bm: BattleManager) -> void:
	# Canaliza um terreno se já tiver 2 na mão, ou a carta mais cara que não consiga pagar.
	if bm.discards_left > 0 and bm.deck.hand.size() > 2:
		var worst: CardInstance = null
		for c in bm.deck.hand:
			if not bm.can_play(c) and not c.data.is_land() and c.data.cost > bm.mana_total:
				if worst == null or c.data.cost > worst.data.cost:
					worst = c
		if worst != null:
			bm.discard(worst)
	var played := true
	var guard := 0
	while played and guard < 40:
		guard += 1
		played = false
		# melhor valor estimado por mana primeiro; terrenos só no fim
		var options := bm.deck.hand.filter(func(c): return bm.can_play(c) and not c.data.is_land())
		options.sort_custom(func(a, b): return _value_per_mana(a, bm) > _value_per_mana(b, bm))
		if not options.is_empty():
			bm.play(options[0], bm.can_kick(options[0]))   # Reforço sempre que houver mana
			played = true
			continue
		for c in bm.deck.hand.duplicate():
			if c.data.is_land() and bm.can_play(c) and bm.deck.lands_in_hand().size() >= 2:
				bm.play(c)
				played = true
				break

func _sensible_shop() -> void:
	GameState.pay_interest()
	# Vida persistente: cura de emergência antes de tudo; o resto depois das relíquias.
	while GameState.player_hp < 8 and GameState.gold >= 3:
		GameState.spend_gold(3)
		GameState.heal(5)
	var colors: Array = GameState.deck_colors()
	for entry in RELIC_ORDER:
		var relic_id := String(entry)
		if relic_id == "COLOR":
			var bought := false
			for col in colors:
				var rid: String = COLOR_RELIC.get(String(col), "")
				if rid != "" and not (rid in GameState.relic_ids):
					var p: int = int(CardDB.relics[rid].get("price", 99))
					if GameState.gold >= p and GameState.relic_ids.size() < GameState.max_relics():
						GameState.spend_gold(p)
						GameState.add_relic(rid)
						bought = true
						break
			if colors.is_empty() and not ("relic_gear" in GameState.relic_ids) and GameState.gold >= 7 and GameState.relic_ids.size() < GameState.max_relics():
				GameState.spend_gold(7)
				GameState.add_relic("relic_gear")
				bought = true
			if bought:
				break
			continue
		if relic_id in GameState.relic_ids or GameState.relic_ids.size() >= GameState.max_relics():
			continue
		var price: int = int(CardDB.relics[relic_id].get("price", 99))
		if GameState.gold >= price:
			GameState.spend_gold(price)
			GameState.add_relic(relic_id)
			break
	while GameState.player_hp < 14 and GameState.gold >= 3:
		GameState.spend_gold(3)
		GameState.heal(5)
	# ... e 1 carta das cores (a mais cara que consiga pagar).
	var options: Array = CardDB.cards_for_colors(colors)
	options.sort_custom(func(a, b): return a.price > b.price)
	for c in options:
		if GameState.gold >= c.price:
			GameState.spend_gold(c.price)
			GameState.add_card(c.id)
			break

## Estimativa grosseira do valor de uma carta neste momento (para o bot escolher o que jogar).
func _value_per_mana(card: CardInstance, bm: BattleManager) -> float:
	var attackers := bm.creatures().size()
	var spells := bm.spells_this_turn.size()
	var score := float(card.power())
	if card.data.is_creature():
		score += 20.0 * (bm.turns_left() - 1)   # fica no tabuleiro: vale pelos turnos que faltam
	for e in card.data.effects:
		var raw = e.get("value", 0)
		var v := float(raw) if (raw is int or raw is float) else 0.0
		var count := 1.0
		match String(e.get("per", "")):
			"attacker": count = attackers + 1
			"spell": count = spells + 1
			"played": count = attackers + spells + 1
			"graveyard": count = bm.deck.graveyard.size()
			"hand": count = bm.deck.hand.size() - 1
			"gold": count = GameState.gold
			"": count = 1.0
			_: count = 2.0
		match String(e.get("action", "")):
			"mult_add": score += 25.0 * v * count
			"mult_mul": score += 60.0 * (v - 1.0) * (1.0 + 0.5 * (count - 1.0))
			"power_add": score += v * count
			"grow", "grow_self": score += v * 2.0
			"retrigger": score += 40.0
			"draw": score += 5.0 * v
	return score / max(1.0, float(bm.effects.cost_of(card)))
