# -*- coding: utf-8 -*-
"""Traduções para inglês da 0.14.2 (importado por tools/make_en_json.py, depois do en_0141).

CODE: textos da interface (chave = o texto em português, como no código).
EXTRA: textos soltos dos dados que não têm id próprio (Novidades).
"""

CODE = {
    "SAIR PARA O MENU": "EXIT TO MENU",
    "SAIR PARA O MENU (no fim do ataque)": "EXIT TO MENU (after the attack)",
}

EXTRA = {}


def build_data(root):
    """Pares {português: inglês} dos textos soltos (Novidades)."""
    return dict(EXTRA)
