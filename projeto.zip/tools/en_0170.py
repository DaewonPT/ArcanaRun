# -*- coding: utf-8 -*-
"""Traduções para inglês da 0.17.0 (importado por tools/make_en_json.py, depois do en_0161).

CODE: textos da interface (chave = o texto em português, como no código).
Dados (emparelhados pelos ids, para os textos portugueses poderem mudar sem se perder a tradução):
  ENEMIES  — os 8 inimigos novos (nome, regra, história, Ascensão, falas e rituais);
  EVENTS   — as 9 partes das histórias em cadeia (título, texto e, por ordem, as opções);
  DIARY    — as 24 páginas do Diário do Mago (título, texto e a pista para as abrir);
  ACHIEVEMENTS, COSMETICS — conquistas e cosméticos novos;
EXTRA: textos soltos (nomes dos modos, medalhas…) que não estão em nenhum tr("…") literal.
"""
import json
import os

CODE = {
    # Menu: a Campanha conta os baralhos dos livros (eram «18» escritos à mão).
    "Os %d baralhos, um a um: sobe os Selos Planares e ganha medalhas.":
        "The %d decks, one by one: climb the Planar Stakes and earn medals.",
    # Atualização da app: o APK da Release tem a versão no nome (ZeroSum_vX.Y.Z.apk).
    "Quando acabar, abre o ficheiro %s e toca em Instalar. O teu progresso fica.":
        "When it finishes, open the %s file and tap Install. Your progress is kept.",
    # Menu: Torre do Arquimago e Corrida de Bosses; Treino contra bosses.
    "Andares seguidos, sem loja.": "Floor after floor, no shop.",
    "Recorde: andar %d": "Record: floor %d",
    "Abre com %d bosses (%d/%d).": "Opens at %d bosses (%d/%d).",
    "Bosses vencidos, seguidos.": "Bosses you beat, back to back.",
    "Melhor: medalha de %s": "Best: %s medal",
    "Vence %d bosses da campanha para abrir a Corrida de Bosses (tens %d).":
        "Beat %d campaign bosses to open the Boss Rush (you have %d).",
    "Testa combos contra um boneco ou luta outra vez com um boss que já venceste.":
        "Test combos on a dummy or fight a boss you have beaten again.",
    # Escolha do baralho (Torre / Corrida).
    "TORRE": "TOWER",
    "CORRIDA": "RUSH",
    "Torre do Arquimago: andares seguidos, sem loja nem mapa. Depois de cada andar, uma carta, uma relíquia ou descanso; de 5 em 5 andares, um boss.":
        "Archmage's Tower: floor after floor, with no shop or map. After each floor, a card, a relic or a rest; every 5 floors, a boss.",
    "Recorde: andar %d.": "Record: floor %d.",
    "Corrida de Bosses: os %d bosses que já venceste, seguidos, com 30 %% de cura entre eles. Medalha pela média de turnos (ouro ≤ 2,5 · prata ≤ 3,5).":
        "Boss Rush: the %d bosses you have beaten, back to back, with 30 %% healing between them. Medal by average turns (gold ≤ 2.5 · silver ≤ 3.5).",
    "Melhor: %s, média de %s turnos.": "Best: %s, average of %s turns.",
    # Ecrã da Torre / Corrida.
    "Vida %d/%d": "Life %d/%d",
    "Relíquias: %d": "Relics: %d",
    "BARALHO (%d)": "DECK (%d)",
    "ANDARES": "FLOORS",
    "Ainda sem recorde": "No record yet",
    "vencido": "beaten",
    "agora": "now",
    "BOSSES": "BOSSES",
    "%d t.": "%d t.",
    "Turnos: %d  ·  média %s": "Turns: %d  ·  average %s",
    "Ouro: média até 2,5 turnos · prata: até 3,5.": "Gold: average up to 2.5 turns · silver: up to 3.5.",
    "ANDAR %d VENCIDO": "FLOOR %d CLEARED",
    "Escolhe um prémio: uma carta para o baralho, uma relíquia ou descansar.":
        "Choose a reward: a card for your deck, a relic or a rest.",
    "UMA CARTA": "A CARD",
    "LEVAR": "TAKE",
    "RELÍQUIA DE BOSS": "BOSS RELIC",
    "UMA RELÍQUIA": "A RELIC",
    "Já tens todas as relíquias que havia para oferecer.": "You already have every relic there was to offer.",
    "Tens as relíquias cheias: escolhes a que sai.": "Your relic slots are full: you pick the one that goes.",
    "DESCANSAR": "REST",
    "+%d de vida": "+%d life",
    "%s entra no baralho.": "%s joins your deck.",
    "Descansaste: +%d de vida.": "You rested: +%d life.",
    "ANDAR %d": "FLOOR %d",
    "BOSS %d DE %d": "BOSS %d OF %d",
    "Vida %s  ·  Ataque %d  ·  %d turnos": "Life %s  ·  Attack %d  ·  %d turns",
    "O boss seguinte está no andar %d.": "The next boss is on floor %d.",
    "Vence-o e escolhes uma relíquia de boss.": "Beat it and you choose a boss relic.",
    "Curaste %d de vida ao vencer o boss anterior.": "You healed %d life by beating the previous boss.",
    "Entre bosses curas 30 % da vida máxima. Sem loja: conta só o teu baralho.":
        "Between bosses you heal 30% of your max life. No shop: only your deck counts.",
    "SUBIR AO ANDAR %d": "CLIMB TO FLOOR %d",
    "ENFRENTAR O BOSS": "FACE THE BOSS",
    "Ainda não tens relíquias.": "You have no relics yet.",
    "AS TUAS RELÍQUIAS": "YOUR RELICS",
    "Andar %d": "Floor %d",
    "Boss %d/%d": "Boss %d/%d",
    # Relíquias cheias (Torre).
    "RELÍQUIAS CHEIAS": "RELICS FULL",
    "Para levares %s, escolhe a relíquia que sai.": "To take %s, choose the relic that goes.",
    "TROCAR": "SWAP",
    # Batalha.
    "ANDAR %d VENCIDO": "FLOOR %d CLEARED",
    "BOSS %d DE %d VENCIDO": "BOSS %d OF %d BEATEN",
    "CORRIDA COMPLETA": "RUSH COMPLETE",
    "BOSS VENCIDO": "BOSS BEATEN",
    "TREINO CONTRA BOSS": "BOSS TRAINING",
    "Treino contra %s": "Training against %s",
    "Venceste %s em %d turno(s), com %d de vida.": "You beat %s in %d turn(s), with %d life left.",
    "%s ficou com %d %% da vida.": "%s was left with %d %% of its life.",
    "O bronze ignora ↻": "Bronze ignores ↻",
    "Copiou %s: cada vez que dispara no teu ataque, o contra-ataque dela sobe 1.":
        "Copied %s: each time it fires in your attack, her counterattack rises by 1.",
    # Fim da Torre / da Corrida.
    "FIM DA TORRE": "END OF THE TOWER",
    "%s chegou ao andar %d da Torre do Arquimago.\nRelíquias: %d  ·  Baralho: %d cartas  ·  Seed: %d":
        "%s reached floor %d of the Archmage's Tower.\nRelics: %d  ·  Deck: %d cards  ·  Seed: %d",
    "NOVO RECORDE: andar %d!": "NEW RECORD: floor %d!",
    "%s venceu os %d bosses em %d turnos (média de %s por boss).":
        "%s beat the %d bosses in %d turns (average of %s per boss).",
    "É o teu melhor resultado na Corrida.": "It's your best Boss Rush result.",
    "%s caiu no boss %d de %d: %s.": "%s fell at boss %d of %d: %s.",
    "Bosses vencidos nesta Corrida: %d.": "Bosses beaten in this Rush: %d.",
    "Dano por andar": "Damage per floor",
    "Dano por boss": "Damage per boss",
    # Treino contra bosses.
    "Boneco": "Dummy",
    "Um boss já vencido, com a regra e as habilidades dele · não mexe na run":
        "A boss you have beaten, with its rule and abilities · doesn't touch your run",
    "LUTAR": "FIGHT",
    "Ainda não venceste nenhum boss da campanha. Vence um numa run e ele fica aqui para treinares.":
        "You haven't beaten any campaign boss yet. Beat one in a run and it shows up here to train against.",
    "Baralho: %s  ·  Relíquias: %d/%d  ·  Vida do boss do ante %d":
        "Deck: %s  ·  Relics: %d/%d  ·  Boss life of ante %d",
    "Boss (%d)": "Boss (%d)",
    "Relíquias (%d/%d)": "Relics (%d/%d)",
    "Escolhe o boss (só os que já venceste numa run)": "Choose the boss (only the ones you have beaten in a run)",
    "Escolhe o baralho": "Choose the deck",
    # Pactos do Infinito.
    "PACTO DO INFINITO": "ENDLESS PACT",
    "Ante %d: escolhe a maldição que se junta às outras até ao fim da run. As piores pagam mais ouro.":
        "Ante %d: choose the curse that joins the others until the end of the run. The worst ones pay more gold.",
    "As maldições somam-se: vês as que tens no mapa, em «Maldições».":
        "Curses stack: you can see yours on the map, under «Curses».",
    "Escolhe uma das maldições para continuar.": "Choose one of the curses to continue.",
    "Pacto aceite: %s (+%d ouro).": "Pact accepted: %s (+%d gold).",
    "De %d em %d antes escolhes uma nova num Pacto (as piores pagam mais ouro). Juntam-se umas às outras.":
        "Every %d antes you choose a new one in a Pact (the worst ones pay more gold). They stack.",
    # Histórias em cadeia.
    "HISTÓRIA · PARTE %d DE %d": "STORY · PART %d OF %d",
    "Parte %d de %d: %s": "Part %d of %d: %s",
    # Diário do Mago.
    "Diário do Mago: nova página — «%s».": "Mage's Journal: new page — «%s».",
    "Vence %s.": "Beat %s.",
    "Vence um boss que ainda não encontraste.": "Beat a boss you haven't met yet.",
    "Descobre %d cartas raras ou míticas (%d/%d).": "Discover %d rare or mythic cards (%d/%d).",
    "Páginas da história do Plano: abrem-se ao vencer bosses, acabar capítulos, descobrir cartas raras e com outros feitos.":
        "Pages of the Plane's story: they open as you beat bosses, finish chapters, discover rare cards and other feats.",
    "Página %d de %d": "Page %d of %d",
    "Para a abrir: %s": "To open it: %s",
}

EXTRA = {
    # Nomes dos modos (GameState.MODE_NAMES) e títulos das peças do menu.
    "Torre do Arquimago": "Archmage's Tower",
    "Corrida de Bosses": "Boss Rush",
    "TORRE DO ARQUIMAGO": "ARCHMAGE'S TOWER",
    "CORRIDA DE BOSSES": "BOSS RUSH",
    # Medalhas da Corrida.
    "Ouro": "Gold",
    "Prata": "Silver",
    "Bronze": "Bronze",
    "Medalha de ouro!": "Gold medal!",
    "Medalha de prata!": "Silver medal!",
    "Medalha de bronze!": "Bronze medal!",
    "DIÁRIO": "JOURNAL",
    # Novidades da 0.17.0.
    "Novidades da 0.17.0": "What's new in 0.17.0",
    "Torre do Arquimago: andares seguidos sem loja — depois de cada um, uma carta, uma relíquia ou descanso.":
        "Archmage's Tower: floor after floor with no shop — after each one, a card, a relic or a rest.",
    "Corrida de Bosses: os bosses que já venceste, seguidos, com medalha pela média de turnos.":
        "Boss Rush: the bosses you have beaten, back to back, with a medal for your average turns.",
    "Treino contra bosses: luta outra vez com um boss que já venceste, sem mexer na run.":
        "Boss training: fight a boss you have beaten again, without touching your run.",
    "Pactos do Infinito: escolhes 1 de 3 maldições e as piores pagam mais ouro.":
        "Endless Pacts: you choose 1 of 3 curses and the worst ones pay more gold.",
    "8 inimigos novos, entre eles o Rei dos Rituais e a Senhora das Mil Mãos.":
        "8 new enemies, among them the Ritual King and the Lady of a Thousand Hands.",
    "Histórias em cadeia: 3 histórias em 3 partes em que as tuas escolhas contam.":
        "Chain stories: 3 stories in 3 parts where your choices matter.",
    "Diário do Mago: 24 páginas da história do Plano, na Coleção.":
        "Mage's Journal: 24 pages of the Plane's story, in the Collection.",
}

ENEMIES = {
    "weaver": {
        "name": "Looking-Glass Weaver",
        "text": "Copies your rarest relic: every time it fires in your attack, the Weaver's next counterattack rises by 1. With no relics to copy, she attacks +1.",
        "lore": "She weaves with threads of light whatever she sees in others. The brighter your relic shines, the sharper her thread gets.",
    },
    "bronze_colossus": {
        "name": "Bronze Colossus",
        "text": "Bronze skin: the first 2 retriggers (↻) of each attack don't count.",
        "lore": "Forged for a war nobody remembers anymore. Blows that echo twice hit its chest and bounce back.",
    },
    "drought_druid": {
        "name": "Drought Druid",
        "text": "Drinks the earth: each Land you play heals her for 4 % of her max life.",
        "lore": "Wherever she walks, rivers shrink and roots scream. Every patch of earth you step on is a glass of water to her.",
    },
    "hungry_shade": {
        "name": "Hungry Shade",
        "text": "End of each turn: exiles the top 2 cards of your graveyard.",
        "lore": "It eats memories — not yours, your cards'. Whatever it swallows never comes back from the graveyard.",
    },
    "swarm_queen": {
        "name": "Swarm Queen",
        "text": "Starts with 1 minion and calls another every 2 turns (up to 4).",
        "lore": "She never fights alone. Every buzz is an order, and every order is one more wing between you and her.",
    },
    "frost_sentinel": {
        "name": "Frost Sentinel",
        "text": "End of each turn: freezes the most expensive card in your hand — next turn it costs +2.",
        "lore": "It guards a post that no longer exists, in a winter that never ended. It touches your cards and they weigh twice as much.",
    },
    "boss_ritual_king": {
        "name": "Ritual King",
        "text": "BOSS · Liturgy: his rituals follow one another without a pause, and each one that completes gives him +1 attack.",
        "lore": "He reigns over a temple where the prayers never stopped. The faithful died centuries ago; the prayers carry on.",
        "rule2_text": "Ascension: rituals take 1 turn less.",
        "lines": {"intro": "Every candle I light is a promise. And I keep them all.", "hit": "One more verse of the liturgy.",
                  "phase2": "The choir sings on its own now!", "defeat": "The candles… are going out…"},
        "rituals": ["Drains 2 of your mana next turn", "Makes you discard 2 random cards", "Destroys your strongest Creature"],
    },
    "boss_thousand_hands": {
        "name": "Lady of a Thousand Hands",
        "text": "BOSS · Thousand Hands: you get +2 cards in hand, but at the end of each turn she takes the ones you didn't play.",
        "lore": "Nobody knows how many arms she has. What is known: she never gives back what she takes — and she takes everything you hesitate to use.",
        "rule2_text": "Ascension: −1 channel.",
        "lines": {"intro": "So many hands… and all of them want what you have.", "hit": "Hand that over.",
                  "phase2": "Now I'll take your very fingers!", "defeat": "The hands… empty…"},
        "ritual": "Steals the most expensive card in your hand",
    },
}

# Cada opção: [rótulo, texto, (opcional) dicionário com "later", "win_text", "lose_text"].
EVENTS = {
    "chain_cartographer_1": {
        "title": "The Lost Cartographer",
        "text": "At the crossroads, an old man with a torn backpack holds out half a map. «The other half leads to a treasure room no Summoner has ever seen. I'm only short the money for the journey.»",
        "options": [
            ["Pay for his journey", "−6 gold. He promises to send you news.",
             {"later": "The Cartographer left you a parcel on the road: a potion or a scroll."}],
            ["Buy his map", "−4 gold: his half stays with you."],
            ["Keep walking", "Nothing happens… for now."],
        ],
    },
    "chain_cartographer_2": {
        "title": "The Observatory Ruins",
        "text": "Between two hills, the ruins of an observatory swallowed by ivy. Someone passed through here not long ago.",
        "options": [
            ["Follow the Cartographer's marks", "He's inside and shares what he found: a random relic."],
            ["Decipher the map", "The traps cost you 4 life, but you reach the right room."],
            ["Sell the map to a merchant", "+12 gold. Someone will get there first."],
            ["Explore blindly", "50 %: a relic. 50 %: you lose 5 life.",
             {"win_text": "You find a relic among the fallen books.", "lose_text": "The floor gives way under your feet."}],
            ["Keep walking", "Nothing happens."],
        ],
    },
    "chain_cartographer_3": {
        "title": "The Treasure Room",
        "text": "At the end of the road, a door with a star-shaped lock. Inside, vaults nobody has opened in centuries.",
        "options": [
            ["Go in with the Cartographer", "He gives you the bigger share: a legendary relic."],
            ["Open the door with the map", "A rare card and 15 gold."],
            ["Peek through the keyhole", "The merchant took almost everything; 8 gold is left on the floor."],
            ["Force the door", "You lose 3 life and find a rare card."],
            ["Knock on the door", "A hermit opens it and gives you a potion or a scroll."],
            ["Keep walking", "Nothing happens."],
        ],
    },
    "chain_apprentice_1": {
        "title": "The Runaway Apprentice",
        "text": "A girl in a scorched tunic runs towards you. «I ran away from the Mage School! I opened the forbidden book and now they want me to retake the exam. Will you hide me?»",
        "options": [
            ["Hide her in the wagon", "She promises to pay you later.",
             {"later": "The Apprentice sends you 10 gold and a note: «It's not over yet.»"}],
            ["Take her back to the School", "+8 gold reward."],
            ["Teach her a trick", "One of your cards gains permanent +15 Power."],
        ],
    },
    "chain_apprentice_2": {
        "title": "The Exam",
        "text": "The School's old master waits for you at the door. «Today the Apprentice takes the forbidden spells exam. Would you like to watch?»",
        "options": [
            ["Help her study all night", "You lose 2 max life; she passes with honours."],
            ["Watch the exam", "She fails and glares at you. The master pays you 6 gold."],
            ["Lend her your best card", "She studies it and gives it back stronger: one of your cards gains permanent +1 Mult."],
            ["Stay out of it", "Nothing happens."],
        ],
    },
    "chain_apprentice_3": {
        "title": "The New Mage",
        "text": "A blindfolded mage waits for you in the middle of the road, surrounded by sparks. She is no longer an apprentice.",
        "options": [
            ["Accept her gift", "A legendary relic."],
            ["Hear her threat", "She leaves a Curse in your deck; the master makes up for it with 15 gold."],
            ["Train with her", "Two of your cards gain permanent +1 Mult."],
            ["Greet her", "She remembers you: +6 gold."],
            ["Keep walking", "Nothing happens."],
        ],
    },
    "chain_spirits_1": {
        "title": "The Well of Laments",
        "text": "In a wide desert, an ancient well murmurs names. Three spirits rise from the bottom: «We are trapped. Take us with you to clean water.»",
        "options": [
            ["Carry them in a flask", "You lose 3 life: they weigh like stones. They promise to help you."],
            ["Seal them in a jar", "You get a potion or a scroll made of their lament."],
            ["Cover the well", "Nothing happens… for now."],
        ],
    },
    "chain_spirits_2": {
        "title": "The Mirror Lake",
        "text": "A lake so still the sky seems to lie beneath it. The spirits tremble at the sight of the water.",
        "options": [
            ["Release them into the water", "The spirits dance over the lake: you heal 8."],
            ["Open the jar at the lake", "You repent in time: +2 max life."],
            ["Sell the jar to a collector", "+14 gold. The laments can be heard in the distance."],
            ["Look at your reflection", "Your reflection winks at you: one of your cards gains permanent +20 Power."],
            ["Keep walking", "Nothing happens."],
        ],
    },
    "chain_spirits_3": {
        "title": "The Temple in the Clouds",
        "text": "A stairway climbs into the clouds. At the top, someone has been waiting for you for a long time.",
        "options": [
            ["Climb with the spirits", "Grateful, they leave you a legendary relic."],
            ["Pray at the temple", "You heal all your life and gain +4 max life."],
            ["Face the monks", "They pay you to forget: +12 gold, but a Curse in your deck."],
            ["Climb alone", "Your reflection waits for you at the top: two cards gain permanent +1 Mult."],
            ["Rest on the steps", "You heal 6."],
            ["Keep walking", "Nothing happens."],
        ],
    },
}

DIARY = {
    "d01": ["First page",
            "I bought this notebook from a merchant who couldn't see, but who knew exactly what I wanted. He told me a Summoner without a journal forgets what they won — and, worse, forgets what they lost. So I write. Today I set out with a borrowed deck, twenty life and an almost empty purse. The cards weigh in my hand like promises. They say the Plane is emptying and that Summoners are the reason. If that's true, I want to know how much is left."],
    "d02": ["The sum is always zero",
            "I learned the Plane's first law the hard way: nothing is created. Every card I win was taken from someone; every blow I land is strength someone else no longer has. The ancients called it the Zero Sum and carved it above the doors of their schools. Nobody carves it now, but everyone feels it. When my cascade grows, I feel the world around me shrink. I wonder where everything that is lost goes — and who is counting."],
    "d03": ["The Gag Judge",
            "I beat the Gag Judge. In his court nobody speaks, not even the cards: every spell I cast seemed to scream inside a box. When he fell, the silver mask came loose and underneath there was no mouth at all — just a smooth, old scar. Someone silenced him first. I kept his gavel. Not as a trophy: to remind me that some laws aren't written, only imposed."],
    "d04": ["The Toll Collector",
            "The Toll Collector charged me for every card I played, even the ones I didn't have yet. He has coins sewn into his skin and keys to bridges that were never built. In the end, he added up what I owed him and the number came to zero. He laughed like someone losing on purpose. I think he knows the Sum better than I do: he never gets rich, he just makes gold change hands."],
    "d05": ["The Keeper of Weight",
            "The Keeper of Weight doesn't attack: it balances. Everything I had in excess — a full hand, relics, life — it took for the scales. I realised too late that its strength was my haste. I played light, one card at a time, and the scales no longer knew what to weigh. When the colossus stopped, the pans hung motionless in the air, neither full nor empty. They're still there, I think."],
    "d06": ["The Thousand-Eyed Hydra",
            "The Thousand-Eyed Hydra doesn't look at me: it looks at my graveyard. Every card I left there was one more eye opening on its skin. I learned to leave no trail, to reuse whatever fell before it could see. When the last head closed, the eyes went out one by one, like the windows of a city falling asleep. Some memories only exist while someone keeps watch over them."],
    "d07": ["The Ash Titan",
            "The Ash Titan rose from what was left of a whole city. Every step it took left ruins underneath. I beat it with a storm of spells, one after another, without giving it time to breathe smoke. When it fell, the ash didn't settle: it drifted north, slowly, as if it still had somewhere to go. The volcanoes of Brasalta fell silent that night. I don't know if from relief or mourning."],
    "d08": ["The Empress of the Solar Wind",
            "The Empress of the Solar Wind despises spells: she says they are words for those with no army. Creatures obey her the way clouds obey the wind. I beat her with soldiers in a line, as she likes — and still she looked at me with pity. Before vanishing in the glare, she told me the sun's wind is weakening. That one day there will be no wind left for anyone."],
    "d09": ["The Grimoire Thief",
            "The Grimoire Thief stole three pages of this journal. She gave them back at the end of the battle, read and annotated in the margin, in a thin, patient hand. On one of them she wrote: «You write like someone afraid of forgetting. Good.» I don't know if I beat her or if she simply finished reading. Since then, I write more slowly."],
    "d10": ["The Fog Witch",
            "In the Witch's fog, the words slip off the cards. I played from memory, counting on my fingers what each one did. She laughed whenever I got it right, as if she were the one teaching me. When the fog lifted, the cards had all their text back — except one, which has stayed blank to this day. I keep it at the bottom of the deck. Sometimes it seems to remember something."],
    "d11": ["The Ritual King",
            "The Ritual King reigns over a temple where the prayers never stopped. The faithful died centuries ago; the prayers carry on by themselves, verse after verse, and each one that completes makes him stronger. I learned a ritual only breaks with one big blow, at the right moment. When the last verse went unsaid, the silence in the temple was so deep I heard my own heart."],
    "d12": ["The Lady of a Thousand Hands",
            "The Lady of a Thousand Hands gave me more cards than I ever had — and took every one I hesitated to play. It was the most expensive lesson of my journey: what you don't use, you lose. I beat her by playing everything, saving nothing for later. When her hands were empty for the first time, they opened slowly, like someone putting down something heavy. She seemed grateful."],
    "d13": ["The Zero-Sum",
            "I reached the end of all accounts. The Zero-Sum has no face: it has an empty circle where everything I won and everything I lost cancel out. I fought it and felt I was fighting my own journal. I won — or we drew, I'm not sure. For an instant, the Plane's scales stood exactly in the middle. Then they started moving again. I think that's what keeps us alive."],
    "d14": ["The Five Kingdoms",
            "Before the Factions there were five pure kingdoms, one per colour: the fire of the Red Mountains, the folded time of the Misty Isle, the contracts of the Abyss, the Glade that grows a hand's breadth a day and the Solar Phalanx that marches in line. Each believed it had the right answer to the Sum. They fell on one another, of course. But I played with their decks and understood: the answers weren't wrong. They were alone.",
            "Win a run with a Book I deck."],
    "d15": ["The Factions",
            "From the ruins of the kingdoms the Factions were born: two colours, one fixed idea. The Crystal Court legislates, the Veiled Brotherhood plots, the Crimson Circus destroys for a laugh, the House of Debt charges interest even to the dead. I won with one of them and understood the rule: a faction isn't an army, it's a way of thinking. Whoever plays it well stops thinking like themselves. I don't know whether that scares me or pleases me.",
            "Win a run with a Book II deck."],
    "d16": ["The Thrones",
            "Above the Factions sit the Thrones, and those no longer even have a colour. The Throne of Ruin feeds on curses, the Artificer's Forge on soulless machines, and the Convergence wants all five colours in a single hand. They are the only decks that reach the end of the Plane. I won with one of them and felt the weight of the crown: everything I conquered was taken from someone. The Thrones never forget the Sum.",
            "Win a run with a Book III deck."],
    "d17": ["The Recruits",
            "Not every Summoner inherits a kingdom or a faction. In the Workshop I met a girl who built an army of wheels and springs, and an old man who commanded a Legion of nameless tokens. Nobody gave them anything: they made it all by hand. I played with them and won. It's my favourite page in this journal — it proves the Sum can also be dodged with stubbornness.",
            "Win a run with a Book IV deck."],
    "d18": ["The ones who speak",
            "In Story mode there are bosses who speak. They don't just threaten: they tell you about their lives as they fight, as if they needed someone to listen before the end. The grey lord of the Dawn Wall apologised to me in the middle of the battle. The king of Corvália only wanted to feel cold again. I write their names here so someone remembers. The Sum keeps no memories — I do.",
            "Finish a Story chapter."],
    "d19": ["Cards that remember",
            "I have seen ten rare cards now. There's a difference that isn't in their Power: rares remember who used them before. I feel it when I shuffle them — a warmth, an impatience. An old man at the market swore to me that every rare was once a Summoner who lost everything and got trapped in the paper. I don't believe it. But I've treated them with more care ever since."],
    "d20": ["The weight of rares",
            "Forty rare and mythic cards have passed through my hands. I'm starting to recognise their quirks: some want to be played early, others wait for the exact moment and sulk if I waste them. My deck is no longer a tool, it's company. Sometimes, at night, I hear them swapping places inside the pouch. In the morning they're always in the order I'll need."],
    "d21": ["The grimoire almost full",
            "Eighty rares. My grimoire is almost full and starting to weigh like an old book. Now I understand why the Thrones keep their cards in vaults: it isn't greed, it's fear. Every rare one Summoner gathers is a rare another doesn't have. The Sum applies here too. Maybe one day I'll have to choose which ones to give back to the Plane."],
    "d22": ["Beyond the eighth ante",
            "I passed the eighth ante and the Plane didn't end. It goes on, darker, hungrier, with bosses I've already seen coming back stronger. They call it the Endless, but it isn't endless: it's just the place where the Sum stops being in a hurry. There, each victory costs a little more than the one before. I kept going anyway. I write this to remember it was I who chose to stay.",
            "Earn an Endless milestone (beyond ante 8)."],
    "d23": ["The Archmage's Tower",
            "They say the Archmage tried to escape the Sum by climbing above it, floor by floor, to where no account could reach him. He built the Tower out of the enemies he beat, one locked on each floor. I climbed ten floors with no shop or map, just my deck and whatever I picked up along the way. Up there the air is thin and the cards tremble. I haven't seen the top yet. I doubt he ever did.",
            "Reach floor 10 of the Archmage's Tower."],
    "d24": ["The stories that come back",
            "Some encounters on the road don't end when I move on. A lost cartographer, a runaway apprentice, spirits in a well — they come back an act later, changed by what I did the first time. I learned that small choices count towards the Sum too. What I give someone today comes back tomorrow, sometimes doubled, sometimes as a debt. Now I choose more carefully.",
            "Finish a chain story in a run."],
}

ACHIEVEMENTS = {
    "pacts_3": ["Dark Pacts", "Accept 3 Endless Pacts."],
    "tower_10": ["Arcane Climber", "Reach floor 10 of the Archmage's Tower."],
    "tower_25": ["Archmage", "Reach floor 25 of the Archmage's Tower."],
    "rush_done": ["Out of Breath", "Finish a Boss Rush."],
    "rush_gold": ["Rush Champion", "Earn the gold medal in a Boss Rush."],
    "chains_1": ["Storyteller", "Finish a chain story in a run."],
    "chains_3": ["Chronicler of the Plane", "Finish all 3 chain stories."],
    "diary_10": ["Scribe", "Open 10 pages of the Mage's Journal."],
    "diary_all": ["Complete Journal", "Open every page of the Mage's Journal."],
}

COSMETICS = {
    "back:x_tower": "Archmage's Tower",
    "frame:champion": "Champion",
    "mat:mat_journal": "Parchment",
}


def _load(root, name):
    path = os.path.join(root, "data", name)
    return json.load(open(path, encoding="utf-8")) if os.path.exists(path) else []


def _put(out, pt, en):
    if isinstance(pt, str) and pt and isinstance(en, str) and en:
        out[pt] = en


def build_data(root):
    """Pares {português: inglês} dos textos dos dados novos (pelos ids) e os de EXTRA."""
    out = {}
    for e in _load(root, "enemies.json"):
        t = ENEMIES.get(str(e.get("id", "")))
        if not t:
            continue
        for field in ("name", "text", "lore", "rule2_text"):
            _put(out, e.get(field), t.get(field))
        lines = e.get("lines") if isinstance(e.get("lines"), dict) else {}
        for k, v in lines.items():
            _put(out, v, t.get("lines", {}).get(k))
        for i, r in enumerate(e.get("rituals") or []):
            if isinstance(r, dict) and i < len(t.get("rituals", [])):
                _put(out, r.get("text"), t["rituals"][i])
        if isinstance(e.get("ritual"), dict):
            _put(out, e["ritual"].get("text"), t.get("ritual"))
    for ev in _load(root, "events.json"):
        t = EVENTS.get(str(ev.get("id", "")))
        if not t:
            continue
        _put(out, ev.get("title"), t["title"])
        _put(out, ev.get("text"), t["text"])
        for i, o in enumerate(ev.get("options", [])):
            if i >= len(t["options"]):
                break
            spec = t["options"][i]
            _put(out, o.get("label"), spec[0])
            _put(out, o.get("text"), spec[1])
            more = spec[2] if len(spec) > 2 else {}
            eff = o.get("effects", {}) if isinstance(o.get("effects"), dict) else {}
            if isinstance(eff.get("later"), dict):
                _put(out, eff["later"].get("text"), more.get("later"))
            if isinstance(eff.get("chance"), dict):
                _put(out, eff["chance"].get("win_text"), more.get("win_text"))
                _put(out, eff["chance"].get("lose_text"), more.get("lose_text"))
    for p in _load(root, "diary.json"):
        t = DIARY.get(str(p.get("id", "")))
        if not t:
            continue
        _put(out, p.get("title"), t[0])
        _put(out, p.get("text"), t[1])
        hint = (p.get("unlock") or {}).get("hint")
        if len(t) > 2:
            _put(out, hint, t[2])
    for a in _load(root, "achievements.json"):
        t = ACHIEVEMENTS.get(str(a.get("id", "")))
        if t:
            _put(out, a.get("name"), t[0])
            _put(out, a.get("text"), t[1])
    cos = _load(root, "cosmetics.json")
    if cos and isinstance(cos[0], dict):
        for kind, items in cos[0].items():
            for c in items:
                key = "%s:%s" % (kind[:-1], c.get("id", ""))
                _put(out, c.get("name"), COSMETICS.get(key))
    out.update(EXTRA)
    return out
