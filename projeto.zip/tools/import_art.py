#!/usr/bin/env python3
"""Põe no jogo as imagens geradas no Gemini (lotes de tools/art_batches.json).

Cada lote tem até 10 imagens, pedidas por ordem (imagem 1 = descrição 1). O Paulo descarrega-as por
essa ordem para Downloads\\Zero-Sum\\Arte\\<Lote>, sem mudar os nomes — por isso a ordem vem da data de
modificação dos ficheiros (ou do nome, com --order name).

Uso (na raiz do projeto):
    python3 tools/import_art.py "<pasta do lote>" --batch "Cartas 01" [--sheet folha.png] [--dry-run]
    python3 tools/import_art.py "<pasta Arte>" --all [--sheet-dir DIR]   # cada subpasta = um lote
    python3 tools/import_art.py --status                                  # o que já está no jogo

Recorta e reduz cada imagem para o uso no jogo e grava WebP em assets/art/<pasta>/<id>.webp:
    card        16:9, 512×288   (por trás do texto da carta e na carta em grande)
    portrait    quadrado, 320×320 (retrato redondo do inimigo / planeswalker)
    relic       quadrado, 160×160 (medalhão da relíquia)
    background  16:9, 1280×720  (fundo da batalha: ato ou clima)
A folha de contacto (--sheet) mostra cada imagem com o id e a descrição curta, para confirmar a ordem.
"""
import argparse
import json
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps

ROOT = Path(__file__).resolve().parent.parent
BATCHES = ROOT / "tools" / "art_batches.json"
EXTS = {".png", ".jpg", ".jpeg", ".webp"}
SPEC = {
    "card": {"size": (512, 288), "quality": 80, "bias": 0.42},
    "portrait": {"size": (320, 320), "quality": 82, "bias": 0.38},
    "relic": {"size": (160, 160), "quality": 84, "bias": 0.5},
    "background": {"size": (1280, 720), "quality": 76, "bias": 0.5},
}


def load_batches():
    data = json.loads(BATCHES.read_text(encoding="utf-8"))
    return data["batches"]


def find_batch(batches, title):
    norm = title.strip().lower()
    for b in batches:
        if b["title"].lower() == norm or Path(b["folder"]).name.lower() == norm:
            return b
    raise SystemExit(f"Lote desconhecido: {title!r}. Lotes: " + ", ".join(b["title"] for b in batches))


def list_images(folder, order):
    files = [p for p in Path(folder).iterdir() if p.is_file() and p.suffix.lower() in EXTS]
    if order == "name":
        files.sort(key=lambda p: p.name.lower())
    else:
        files.sort(key=lambda p: (p.stat().st_mtime, p.name.lower()))
    return files


def cover(img, size, bias):
    """Recorta para o formato de `size` (centrado na horizontal, `bias` na vertical) e reduz."""
    img = ImageOps.exif_transpose(img).convert("RGB")
    w, h = img.size
    tw, th = size
    want = tw / th
    if w / h > want:
        nw = int(round(h * want))
        x0 = (w - nw) // 2
        box = (x0, 0, x0 + nw, h)
    else:
        nh = int(round(w / want))
        y0 = int(round((h - nh) * bias))
        box = (0, y0, w, y0 + nh)
    return img.crop(box).resize(size, Image.LANCZOS)


def import_batch(batch, folder, order="mtime", dry=False, allow_partial=False):
    files = list_images(folder, order)
    ids = batch["ids"]
    if len(files) != len(ids) and not allow_partial:
        raise SystemExit(f"{batch['title']}: há {len(files)} imagens em {folder}, mas o lote tem {len(ids)}. "
                         "Usa --allow-partial para pôr só as primeiras.")
    spec = SPEC[batch["kind"]]
    outdir = ROOT / batch["outdir"]
    done = []
    for f, id_, label in zip(files, ids, batch["labels"]):
        with Image.open(f) as im:
            out = cover(im, spec["size"], spec["bias"])
        dest = outdir / f"{id_}.webp"
        if not dry:
            outdir.mkdir(parents=True, exist_ok=True)
            out.save(dest, "WEBP", quality=spec["quality"], method=6)
        done.append((id_, label, f.name, out))
    return done


def contact_sheet(rows, path, title):
    """Folha com as imagens recortadas, o id e a descrição curta (para confirmar a ordem)."""
    thumb_w = 300
    cells = []
    for id_, label, src, img in rows:
        t = img.copy()
        t.thumbnail((thumb_w, thumb_w))
        cells.append((id_, label, src, t))
    cols = 5
    rows_n = (len(cells) + cols - 1) // cols
    cell_h = max(c[3].height for c in cells) + 52 if cells else 100
    sheet = Image.new("RGB", (cols * (thumb_w + 12) + 12, rows_n * (cell_h + 12) + 50), (24, 20, 34))
    d = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype(str(ROOT / "assets" / "fonts" / "Inter-Medium.otf"), 15)
        big = ImageFont.truetype(str(ROOT / "assets" / "fonts" / "Inter-Medium.otf"), 22)
    except OSError:
        font = big = ImageFont.load_default()
    d.text((12, 12), title, fill=(250, 200, 90), font=big)
    for i, (id_, label, src, t) in enumerate(cells):
        x = 12 + (i % cols) * (thumb_w + 12)
        y = 50 + (i // cols) * (cell_h + 12)
        sheet.paste(t, (x, y))
        d.text((x, y + t.height + 4), f"{i + 1}. {id_}", fill=(250, 200, 90), font=font)
        d.text((x, y + t.height + 24), label[:38], fill=(225, 220, 240), font=font)
    sheet.save(path)


def status(batches):
    total = have = 0
    for b in batches:
        outdir = ROOT / b["outdir"]
        n = sum(1 for i in b["ids"] if (outdir / f"{i}.webp").exists())
        total += len(b["ids"])
        have += n
        mark = "✓" if n == len(b["ids"]) else ("·" if n == 0 else "~")
        print(f"{mark} {b['title']:<16} {n:>2}/{len(b['ids'])}")
    print(f"Total: {have}/{total} imagens no jogo.")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("folder", nargs="?")
    ap.add_argument("--batch")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--order", choices=["mtime", "name"], default="mtime")
    ap.add_argument("--sheet")
    ap.add_argument("--sheet-dir")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--allow-partial", action="store_true")
    ap.add_argument("--status", action="store_true")
    a = ap.parse_args()
    batches = load_batches()
    if a.status:
        status(batches)
        return
    if not a.folder:
        ap.error("falta a pasta")
    if a.all:
        base = Path(a.folder)
        for sub in sorted(p for p in base.iterdir() if p.is_dir()):
            try:
                b = find_batch(batches, sub.name)
            except SystemExit:
                print(f"(ignorada: {sub.name})")
                continue
            rows = import_batch(b, sub, a.order, a.dry_run, a.allow_partial)
            print(f"{b['title']}: {len(rows)} imagens → {b['outdir']}")
            if a.sheet_dir:
                Path(a.sheet_dir).mkdir(parents=True, exist_ok=True)
                contact_sheet(rows, Path(a.sheet_dir) / f"{b['title']}.png", b["title"])
        return
    if not a.batch:
        ap.error("indica o lote com --batch (ou usa --all)")
    b = find_batch(batches, a.batch)
    rows = import_batch(b, a.folder, a.order, a.dry_run, a.allow_partial)
    print(f"{b['title']}: {len(rows)} imagens → {b['outdir']}" + (" (ensaio)" if a.dry_run else ""))
    for i, (id_, label, src, _) in enumerate(rows, start=1):
        print(f"  {i:>2}. {src}  →  {id_}  ({label})")
    if a.sheet:
        contact_sheet(rows, a.sheet, b["title"])


if __name__ == "__main__":
    sys.exit(main())
