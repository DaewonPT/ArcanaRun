#!/usr/bin/env python3
"""Põe no jogo as imagens geradas no Gemini (folhas de tools/art_sheets.json, 0.13.0).

Cada parte (tools/make_art_prompts.py) dá até 10 imagens: folhas com várias ilustrações numa grelha
(células pintadas separadas por margens magenta #FF00FF) e fundos inteiros. O Gemini junta-as num zip
ZeroSum_arte_parte_XX.zip; cada ficheiro chama-se pelo código da folha (CAR-01.png, RET-03.png…).
O corte procura as margens magenta (colunas/linhas quase todas magenta); se não as encontrar, divide a
folha em partes iguais. Cada célula perde a franja magenta, é recortada para o formato do jogo e
grava-se em WebP em assets/art/<pasta>/<id>.webp:
    card        16:9, 512×288   (por trás do texto da carta e na carta em grande)
    portrait    quadrado, 320×320 (retrato redondo do inimigo / planeswalker)
    relic       quadrado, 160×160 (medalhão da relíquia)
    item        quadrado, 128×128 (poções e pergaminhos)
    background  16:9, 1280×720  (fundo da batalha: ato ou clima)
    mapnode     quadrado, 192×192 (medalhão de um nó do mapa)

Uso (na raiz do projeto):
    python3 tools/import_art.py <zip ou pasta> [mais zips/pastas…] [--contact DIR] [--dry-run]
    python3 tools/import_art.py --status
A folha de contacto (--contact) mostra cada ilustração cortada com o id e o nome, para confirmar a ordem.
"""
import argparse
import io
import json
import sys
import zipfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageOps

ROOT = Path(__file__).resolve().parent.parent
SHEETS = ROOT / "tools" / "art_sheets.json"
EXTS = {".png", ".jpg", ".jpeg", ".webp"}
SPEC = {
    "card": {"size": (512, 288), "quality": 80, "bias": 0.42, "dir": "assets/art/cards"},
    "portrait": {"size": (320, 320), "quality": 82, "bias": 0.38, "dir": "assets/art/portraits"},
    "relic": {"size": (160, 160), "quality": 84, "bias": 0.5, "dir": "assets/art/relics"},
    "item": {"size": (128, 128), "quality": 84, "bias": 0.5, "dir": "assets/art/items"},
    "background": {"size": (1280, 720), "quality": 76, "bias": 0.5, "dir": "assets/art/backgrounds"},
    "mapnode": {"size": (192, 192), "quality": 84, "bias": 0.5, "dir": "assets/art/mapnodes"},
}


def load_sheets():
    data = json.loads(SHEETS.read_text(encoding="utf-8"))
    return {s["code"].upper(): s for p in data["parts"] for s in p["sheets"]}


def gather(paths):
    """[(nome, Image)] de zips, pastas ou ficheiros soltos."""
    out = []
    for raw in paths:
        p = Path(raw)
        if p.is_dir():
            for f in sorted(p.rglob("*")):
                if f.is_file() and f.suffix.lower() in EXTS:
                    out.append((f.name, Image.open(f)))
                elif f.is_file() and f.suffix.lower() == ".zip":
                    out.extend(gather([f]))
        elif p.suffix.lower() == ".zip":
            with zipfile.ZipFile(p) as z:
                for name in sorted(z.namelist()):
                    if Path(name).suffix.lower() in EXTS and not name.startswith("__MACOSX"):
                        out.append((Path(name).name, Image.open(io.BytesIO(z.read(name)))))
        elif p.is_file() and p.suffix.lower() in EXTS:
            out.append((p.name, Image.open(p)))
    return out


def magenta(arr):
    r, g, b = arr[..., 0].astype(int), arr[..., 1].astype(int), arr[..., 2].astype(int)
    return (r > 170) & (b > 170) & (g < 120) & (np.abs(r - b) < 95)


def gutter_mask(arr):
    """Píxeis das margens. O Gemini às vezes pinta-as num magenta mais escuro ou desbotado (e o JPEG mexe na
    cor), por isso a referência é a cor do contorno exterior da folha; se não for magenta, fica o magenta puro."""
    edge = np.concatenate([arr[:4].reshape(-1, 3), arr[-4:].reshape(-1, 3), arr[:, :4].reshape(-1, 3), arr[:, -4:].reshape(-1, 3)])
    ref = np.median(edge, axis=0).astype(int)
    base = magenta(arr)
    if not (ref[0] > ref[1] + 60 and ref[2] > ref[1] + 40):
        return base
    a = arr.astype(int)
    d = np.abs(a - ref).sum(axis=2)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    return base | ((d < 75) & (r > g + 50) & (b > g + 30))


def runs(flags, min_len):
    """Troços seguidos de False (as células entre margens), com pelo menos min_len."""
    out, start = [], None
    for i, f in enumerate(list(flags) + [True]):
        if not f and start is None:
            start = i
        elif f and start is not None:
            if i - start >= min_len:
                out.append((start, i))
            start = None
    return out


FALLBACKS = []   # folhas em que não se encontraram as margens (cortadas em partes iguais) — para rever


def split_axis(mask, axis, n, size, label=""):
    frac = mask.mean(axis=axis)
    segs = runs(frac > 0.55, max(8, int(size * 0.25 / max(1, n))))
    if len(segs) == n:
        return segs
    # Sem margens claras: partes iguais dentro da zona sem magenta.
    FALLBACKS.append(label)
    inside = np.where(frac < 0.55)[0]
    lo, hi = (int(inside[0]), int(inside[-1]) + 1) if inside.size else (0, size)
    step = (hi - lo) / n
    return [(int(lo + i * step), int(lo + (i + 1) * step)) for i in range(n)]


def trim_magenta(arr):
    """Tira as franjas magenta que sobram à volta de uma célula."""
    m = gutter_mask(arr) if arr.shape[0] > 8 and arr.shape[1] > 8 else magenta(arr)
    top, bottom, left, right = 0, arr.shape[0], 0, arr.shape[1]
    while bottom - top > 8 and m[top, left:right].mean() > 0.3:
        top += 1
    while bottom - top > 8 and m[bottom - 1, left:right].mean() > 0.3:
        bottom -= 1
    while right - left > 8 and m[top:bottom, left].mean() > 0.3:
        left += 1
    while right - left > 8 and m[top:bottom, right - 1].mean() > 0.3:
        right -= 1
    h, w = bottom - top, right - left
    inset_y, inset_x = int(h * 0.012), int(w * 0.012)   # um pouco para dentro: sem franja nenhuma
    return arr[top + inset_y:bottom - inset_y, left + inset_x:right - inset_x]


def cells(img, cols, rows, label=""):
    arr = np.array(ImageOps.exif_transpose(img).convert("RGB"))
    if cols == 1 and rows == 1:
        return [Image.fromarray(arr)]
    m = gutter_mask(arr)
    xs = split_axis(m, 0, cols, arr.shape[1], label + " (colunas)")
    ys = split_axis(m, 1, rows, arr.shape[0], label + " (linhas)")
    out = []
    for (y0, y1) in ys:
        for (x0, x1) in xs:
            out.append(Image.fromarray(trim_magenta(arr[y0:y1, x0:x1])))
    return out


def cover(img, size, bias):
    """Recorta para o formato de `size` (centrado na horizontal, `bias` na vertical) e reduz."""
    img = img.convert("RGB")
    w, h = img.size
    tw, th = size
    want = tw / th
    if w / h > want:
        nw = int(round(h * want))
        x0 = (w - nw) // 2
        box = (x0, 0, x0 + nw, h)
    else:
        nh = int(round(w / want))
        y0 = int(round((h - nh) * bias))
        box = (0, y0, w, y0 + nh)
    return img.crop(box).resize(size, Image.LANCZOS)


def import_sheet(sheet, img, dry=False):
    spec = SPEC[sheet["kind"]]
    outdir = ROOT / spec["dir"]
    done = []
    pieces = cells(img, sheet["cols"], sheet["rows"], sheet["code"])
    for piece, id_, label in zip(pieces, sheet["ids"], sheet["labels"]):
        out = cover(piece, spec["size"], spec["bias"])
        if not dry:
            outdir.mkdir(parents=True, exist_ok=True)
            out.save(outdir / f"{id_}.webp", "WEBP", quality=spec["quality"], method=6)
        done.append((id_, label, sheet["code"], out))
    return done


def contact_sheet(rows, path, title):
    """Folha com as ilustrações cortadas, o id e o nome (para confirmar a ordem)."""
    thumb_w = 260
    cells_ = []
    for id_, label, code, img in rows:
        t = img.copy()
        t.thumbnail((thumb_w, thumb_w))
        cells_.append((id_, label, code, t))
    cols = 5
    rows_n = max(1, (len(cells_) + cols - 1) // cols)
    cell_h = (max(c[3].height for c in cells_) + 52) if cells_ else 100
    sheet = Image.new("RGB", (cols * (thumb_w + 12) + 12, rows_n * (cell_h + 12) + 50), (24, 20, 34))
    d = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype(str(ROOT / "assets" / "fonts" / "Inter-Medium.otf"), 15)
        big = ImageFont.truetype(str(ROOT / "assets" / "fonts" / "Inter-Medium.otf"), 22)
    except OSError:
        font = big = ImageFont.load_default()
    d.text((12, 12), title, fill=(250, 200, 90), font=big)
    for i, (id_, label, code, t) in enumerate(cells_):
        x = 12 + (i % cols) * (thumb_w + 12)
        y = 50 + (i // cols) * (cell_h + 12)
        sheet.paste(t, (x, y))
        d.text((x, y + t.height + 4), f"{code} · {id_}", fill=(250, 200, 90), font=font)
        d.text((x, y + t.height + 24), label[:34], fill=(225, 220, 240), font=font)
    sheet.save(path)


def status(sheets):
    total = have = 0
    for code, s in sheets.items():
        outdir = ROOT / SPEC[s["kind"]]["dir"]
        n = sum(1 for i in s["ids"] if (outdir / f"{i}.webp").exists())
        total += len(s["ids"])
        have += n
        mark = "✓" if n == len(s["ids"]) else ("·" if n == 0 else "~")
        print(f"{mark} {code:<7} {n:>2}/{len(s['ids'])}")
    print(f"Total: {have}/{total} ilustrações no jogo.")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("inputs", nargs="*", help="zips, pastas ou imagens das folhas")
    ap.add_argument("--contact", help="pasta para as folhas de contacto (uma por folha importada)")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--status", action="store_true")
    a = ap.parse_args()
    sheets = load_sheets()
    if a.status:
        status(sheets)
        return 0
    if not a.inputs:
        ap.error("falta o zip ou a pasta com as imagens")
    images = gather(a.inputs)
    unknown = []
    count = 0
    for name, img in images:
        code = Path(name).stem.upper().replace("_", "-")
        s = sheets.get(code)
        if s is None:
            unknown.append(name)
            continue
        rows = import_sheet(s, img, a.dry_run)
        count += len(rows)
        print(f"{code}: {len(rows)} ilustrações → {SPEC[s['kind']]['dir']}" + (" (ensaio)" if a.dry_run else ""))
        if a.contact:
            Path(a.contact).mkdir(parents=True, exist_ok=True)
            contact_sheet(rows, Path(a.contact) / f"{code}.png", f"{code} ({s['kind']})")
    if unknown:
        print("Sem folha com este nome (ignoradas): " + ", ".join(unknown))
    if FALLBACKS:
        print("Sem margens claras (cortadas em partes iguais — confirma na folha de contacto): " + ", ".join(FALLBACKS))
    print(f"{count} ilustrações.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
