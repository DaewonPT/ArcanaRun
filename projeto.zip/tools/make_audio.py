#!/usr/bin/env python3
"""Música e efeitos sonoros do Zero-Sum, compostos e sintetizados por código (numpy + scipy), sem samples
de ninguém. Tudo é determinístico (sementes fixas): correr outra vez dá os mesmos ficheiros.

Uso (na raiz do projeto):
    python3 tools/make_audio.py                 # tudo
    python3 tools/make_audio.py --music menu    # só algumas faixas (separadas por vírgulas)
    python3 tools/make_audio.py --sfx           # só os efeitos
    python3 tools/make_audio.py --preview DIR   # também escreve WAV e espetrogramas para verificar

Escreve:
    assets/audio/music_<faixa>.ogg   Vorbis estéreo 32 kHz, loop perfeito (a cauda do eco volta ao início)
    assets/audio/sfx/<nome>.wav      PCM 16 bits mono 32 kHz

Faixas: menu, act1, act2, act3, act4, endless, boss (uma por ato, o Infinito, os bosses e os menus).
0.13.0: guild_<cores> (tema de cada guilda no Livro II da História: wu, ub, br, rg, gw, wb, ur, bg, rw, gu) e drive_<andamento> (camada só de
percussão que entra durante o ataque, para a música crescer na cascata).
Precisa do ffmpeg (libvorbis) para os .ogg.
"""
import argparse
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
from scipy import signal
from scipy.io import wavfile

ROOT = Path(__file__).resolve().parent.parent
SR = 32000
OUT_MUSIC = ROOT / "assets" / "audio"
OUT_SFX = ROOT / "assets" / "audio" / "sfx"

# --------------------------------------------------------------------------------------------------
# Básicos
# --------------------------------------------------------------------------------------------------

NOTE = {"C": 0, "C#": 1, "Db": 1, "D": 2, "D#": 3, "Eb": 3, "E": 4, "F": 5, "F#": 6, "Gb": 6, "G": 7,
        "G#": 8, "Ab": 8, "A": 9, "A#": 10, "Bb": 10, "B": 11}

CHORDS = {
    "": [0, 4, 7], "m": [0, 3, 7], "5": [0, 7, 12], "7": [0, 4, 7, 10], "m7": [0, 3, 7, 10],
    "maj7": [0, 4, 7, 11], "m9": [0, 3, 7, 10, 14], "9": [0, 4, 7, 10, 14], "add9": [0, 4, 7, 14],
    "madd9": [0, 3, 7, 14], "6": [0, 4, 7, 9], "m6": [0, 3, 7, 9], "sus2": [0, 2, 7], "sus4": [0, 5, 7],
    "7sus4": [0, 5, 7, 10], "dim7": [0, 3, 6, 9], "maj7#11": [0, 4, 7, 11, 18], "maj7#5": [0, 4, 8, 11],
    "mmaj7": [0, 3, 7, 11], "7b9": [0, 4, 7, 10, 13], "maj9": [0, 4, 7, 11, 14], "m11": [0, 3, 7, 10, 17],
}

SCALES = {
    "major": [0, 2, 4, 5, 7, 9, 11], "minor": [0, 2, 3, 5, 7, 8, 10], "dorian": [0, 2, 3, 5, 7, 9, 10],
    "lydian": [0, 2, 4, 6, 7, 9, 11], "phrygian": [0, 1, 3, 5, 7, 8, 10], "harmonic": [0, 2, 3, 5, 7, 8, 11],
    "mixolydian": [0, 2, 4, 5, 7, 9, 10],
}


def hz(m):
    return 440.0 * 2.0 ** ((np.asarray(m, dtype=float) - 69.0) / 12.0)


def tvec(seconds):
    return np.arange(int(seconds * SR)) / SR


def adsr(n, a, d, s, r, hold):
    """Envelope de n amostras: ataque a, decaimento d até s, mantém até `hold` s e solta em r s."""
    t = np.arange(n) / SR
    env = np.empty(n)
    a = max(a, 1e-4)
    env[:] = s
    m_a = t < a
    env[m_a] = t[m_a] / a
    m_d = (t >= a) & (t < a + d)
    env[m_d] = 1.0 - (1.0 - s) * (t[m_d] - a) / max(d, 1e-4)
    m_r = t >= hold
    if np.any(m_r):
        level = np.interp(hold, t, env) if hold < t[-1] else env[-1]
        env[m_r] = level * np.exp(-(t[m_r] - hold) * (6.9 / max(r, 1e-3)))
    return env


def additive(freq, t, amps, phase0=None):
    """Soma de harmónicos k·freq (só os que ficam abaixo de 0,45·SR, sem aliasing)."""
    out = np.zeros_like(t)
    for k, a in enumerate(amps, start=1):
        if a == 0.0 or k * freq >= 0.45 * SR:
            continue
        ph = 0.0 if phase0 is None else phase0[(k - 1) % len(phase0)]
        out += a * np.sin(2 * np.pi * k * freq * t + ph)
    return out


def lowpass(x, cutoff, order=2):
    b, a = signal.butter(order, min(cutoff, 0.45 * SR) / (SR / 2), "low")
    return signal.lfilter(b, a, x, axis=0)


def highpass(x, cutoff, order=2):
    b, a = signal.butter(order, cutoff / (SR / 2), "high")
    return signal.lfilter(b, a, x, axis=0)


def bandpass(x, lo, hi, order=2):
    b, a = signal.butter(order, [lo / (SR / 2), min(hi, 0.45 * SR) / (SR / 2)], "band")
    return signal.lfilter(b, a, x, axis=0)


def pan(mono, p):
    """p: 0 = esquerda, 0,5 = centro, 1 = direita (lei de potência constante)."""
    ang = p * np.pi / 2
    return np.stack([mono * np.cos(ang), mono * np.sin(ang)], axis=1)


# --------------------------------------------------------------------------------------------------
# Instrumentos (cada um devolve um array mono ou estéreo de uma nota)
# --------------------------------------------------------------------------------------------------

def inst_pad(m, dur, vel, bright=0.45, rng=None):
    rel = 1.1
    t = tvec(dur + rel)
    f = float(hz(m))
    ks = np.arange(1, 13)
    amps = (1.0 / ks) * np.exp(-ks * (1.0 - bright) * 0.55)
    out = np.zeros((len(t), 2))
    for det, p in ((-0.09, 0.15), (0.09, 0.85), (0.0, 0.5)):
        ph = rng.uniform(0, 2 * np.pi, 12) if rng is not None else None
        w = additive(f * 2 ** (det / 12), t, amps, ph)
        out += pan(w, p)
    out += pan(0.35 * np.sin(2 * np.pi * f * 0.5 * t), 0.5)
    env = adsr(len(t), 0.45, 0.6, 0.8, rel, dur)
    trem = 1.0 + 0.06 * np.sin(2 * np.pi * 0.23 * t + (rng.uniform(0, 6) if rng is not None else 0))
    out *= (env * trem)[:, None]
    out = lowpass(out, 900 + 2600 * bright)
    return out * vel * 0.11


def inst_pluck(m, dur, vel, bright=0.7):
    length = min(dur + 0.35, 1.8)
    t = tvec(length)
    f = float(hz(m))
    out = np.zeros_like(t)
    for k in range(1, 16):
        if k * f >= 0.45 * SR:
            break
        a = abs(np.sin(k * np.pi / 4.7)) / k ** (1.25 - 0.3 * bright)
        out += a * np.exp(-t * (2.6 + 1.9 * k * (1.2 - bright))) * np.sin(2 * np.pi * k * f * t)
    pick = np.random.default_rng(int(m * 7)).standard_normal(len(t)) * np.exp(-t * 900) * 0.15
    out += lowpass(pick, 4000)
    off = adsr(len(t), 0.002, 0.0, 1.0, 0.09, dur)
    return out * off * vel * 0.32


def inst_bell(m, dur, vel, ratio=4.0, index=2.0, decay=2.4):
    length = min(dur + 1.6, 3.2)
    t = tvec(length)
    f = float(hz(m))
    idx = index * np.exp(-t * 3.2)
    mod = np.sin(2 * np.pi * f * ratio * t)
    car = np.sin(2 * np.pi * f * t + idx * mod)
    car += 0.25 * np.sin(2 * np.pi * f * 2.0 * t) * np.exp(-t * 4.0)
    env = np.minimum(t / 0.003, 1.0) * np.exp(-t * decay)
    off = adsr(len(t), 0.001, 0.0, 1.0, 0.5, dur + 0.4)
    return car * env * off * vel * 0.2


def inst_bass(m, dur, vel, kind="round"):
    rel = 0.08
    t = tvec(dur + rel)
    f = float(hz(m))
    if kind == "saw":
        w = additive(f, t, [1.0 / k for k in range(1, 14)])
        w = np.tanh(1.6 * (0.65 * lowpass(w, 700) + 0.35 * lowpass(w, 1800)))
        env = adsr(len(t), 0.004, 0.18, 0.7, rel, dur)
        return w * env * vel * 0.32
    w = np.sin(2 * np.pi * f * t) + 0.28 * np.sin(4 * np.pi * f * t) + 0.08 * np.sin(6 * np.pi * f * t)
    w = np.tanh(1.3 * w) / np.tanh(1.3)
    env = adsr(len(t), 0.006, 0.3, 0.72, rel, dur)
    return w * env * vel * 0.36


def inst_lead(m, dur, vel, bright=0.5):
    rel = 0.18
    t = tvec(dur + rel)
    f0 = float(hz(m))
    vib = 0.0045 * np.sin(2 * np.pi * 5.3 * t) * np.clip((t - 0.18) / 0.25, 0, 1)
    phase = 2 * np.pi * np.cumsum(f0 * (1 + vib)) / SR
    w = np.zeros_like(t)
    for k in range(1, 14, 2):
        if k * f0 >= 0.45 * SR:
            break
        w += np.sin(k * phase) / k
    w += 0.3 * np.sin(2 * phase)
    w = lowpass(w, 1300 + 2200 * bright)
    env = adsr(len(t), 0.03, 0.25, 0.75, rel, dur)
    return w * env * vel * 0.13


def inst_brass(m, dur, vel):
    rel = 0.2
    t = tvec(dur + rel)
    f = float(hz(m))
    w = additive(f, t, [1.0 / k ** 0.9 for k in range(1, 16)])
    swell = np.clip(t / 0.06, 0, 1)
    cut = 500 + 2600 * swell
    w = lowpass(w, 2600) * 0.6 + lowpass(w, 900) * 0.4
    env = adsr(len(t), 0.05, 0.2, 0.8, rel, dur)
    return np.tanh(1.2 * w) * env * vel * 0.16 * (0.8 + 0.2 * swell)


def drum_kick(vel, tight=1.0):
    t = tvec(0.45)
    f = 44 + 80 * np.exp(-t * 32 * tight)
    ph = 2 * np.pi * np.cumsum(f) / SR
    body = np.sin(ph) * np.exp(-t * 8.5 * tight)
    click = lowpass(np.random.default_rng(3).standard_normal(len(t)) * np.exp(-t * 400), 3500) * 0.25
    return np.tanh(1.5 * (body + click)) * vel * 0.55


def drum_snare(vel, tone=185.0):
    t = tvec(0.32)
    n = np.random.default_rng(5).standard_normal(len(t))
    noise = bandpass(n, 1200, 7000) * np.exp(-t * 15)
    body = (np.sin(2 * np.pi * tone * t) + 0.5 * np.sin(2 * np.pi * tone * 1.75 * t)) * np.exp(-t * 24)
    return (0.7 * noise + 0.45 * body) * vel * 0.36


def drum_hat(vel, open_=False, seed=7):
    t = tvec(0.5 if open_ else 0.09)
    n = np.random.default_rng(seed).standard_normal(len(t))
    w = highpass(n, 7200, 2) * np.exp(-t * (11 if open_ else 55))
    return w * vel * 0.12


def drum_shaker(vel, seed=9):
    t = tvec(0.12)
    n = np.random.default_rng(seed).standard_normal(len(t))
    env = np.clip(t / 0.018, 0, 1) * np.exp(-t * 30)
    return bandpass(n, 4000, 11000) * env * vel * 0.1


def drum_rim(vel):
    t = tvec(0.08)
    n = np.random.default_rng(11).standard_normal(len(t))
    w = bandpass(n, 1500, 3500) * np.exp(-t * 90) + 0.6 * np.sin(2 * np.pi * 820 * t) * np.exp(-t * 70)
    return w * vel * 0.2


def drum_tom(m, vel):
    t = tvec(0.6)
    f0 = float(hz(m))
    f = f0 * (1 + 0.6 * np.exp(-t * 18))
    ph = 2 * np.pi * np.cumsum(f) / SR
    w = np.sin(ph) * np.exp(-t * 6.5) + 0.15 * bandpass(np.random.default_rng(int(m)).standard_normal(len(t)), 300, 3000) * np.exp(-t * 30)
    return w * vel * 0.4


def drum_crash(vel):
    t = tvec(1.6)
    n = np.random.default_rng(13).standard_normal(len(t))
    w = highpass(n, 4500) * np.exp(-t * 3.4)
    for r in (1.0, 1.47, 2.09, 2.83):
        w += 0.05 * np.sin(2 * np.pi * 410 * r * t) * np.exp(-t * 4.0)
    return w * vel * 0.05


# --------------------------------------------------------------------------------------------------
# Efeitos de mistura
# --------------------------------------------------------------------------------------------------

def make_ir(seconds=2.4, seed=1, brightness=0.5):
    n = int(seconds * SR)
    t = np.arange(n) / SR
    rng = np.random.default_rng(seed)
    out = []
    for ch in range(2):
        x = rng.standard_normal(n)
        dark = lowpass(x, 1800 + 3000 * brightness, 1)
        w = np.exp(-t * 2.5)
        y = (x * w + dark * (1 - w)) * np.exp(-t * 6.9 / seconds)
        # reflexões iniciais
        for d, g in ((0.011, 0.6), (0.019, 0.45), (0.027, 0.35), (0.041, 0.25)):
            i = int((d + 0.003 * ch) * SR)
            y[i] += g * 4
        out.append(y)
    ir = np.stack(out, axis=1)
    pre = int(0.018 * SR)
    ir = np.concatenate([np.zeros((pre, 2)), ir])
    return ir / np.sqrt(np.sum(ir ** 2) / 2) * 0.9


def reverb(x, ir):
    return np.stack([signal.fftconvolve(x[:, c], ir[:, c])[: len(x)] for c in range(2)], axis=1)


def pingpong(x, delay_s, fb=0.42, taps=5, damp=2500):
    out = np.zeros_like(x)
    d = int(delay_s * SR)
    src = lowpass(x, damp)
    for i in range(1, taps + 1):
        g = fb ** i
        sh = d * i
        if sh >= len(x):
            break
        ch_from = 0 if i % 2 else 1
        mono = src[: len(x) - sh, ch_from] * 0.5 + src[: len(x) - sh, 1 - ch_from] * 0.5
        out[sh:, i % 2] += mono * g
    return out


# --------------------------------------------------------------------------------------------------
# Composição
# --------------------------------------------------------------------------------------------------

class Song:
    def __init__(self, name, bpm, key, scale, progression, bars_per_chord, seed):
        self.name = name
        self.bpm = bpm
        self.key = NOTE[key] if isinstance(key, str) else key
        self.scale = [(self.key + s) % 12 for s in SCALES[scale]]
        self.prog = progression          # [(raiz, qualidade)]
        self.bpc = bars_per_chord
        self.beat = 60.0 / bpm
        self.bars = len(progression) * bars_per_chord
        self.length = self.bars * 4 * self.beat
        self.rng = np.random.default_rng(seed)
        self.tail = 3.2
        n = int((self.length + self.tail) * SR) + 1
        self.bus = {k: np.zeros((n, 2)) for k in ("pad", "bass", "arp", "lead", "drums")}

    # --- tempo ---
    def at(self, bar, beat=0.0):
        return (bar * 4 + beat) * self.beat

    def chord_at(self, bar):
        root, q = self.prog[(bar // self.bpc) % len(self.prog)]
        r = NOTE[root] if isinstance(root, str) else root
        return r, CHORDS[q]

    def add(self, bus, start, audio, gain=1.0, p=0.5):
        if audio.ndim == 1:
            audio = pan(audio, p)
        i = int(start * SR)
        j = min(i + len(audio), len(self.bus[bus]))
        if i >= j:
            return
        self.bus[bus][i:j] += audio[: j - i] * gain

    # --- harmonia ---
    def voicing(self, bar, low=53, high=74, prev=None):
        r, iv = self.chord_at(bar)
        pcs = [(r + i) % 12 for i in iv]
        best, best_cost = None, 1e9
        for inv in range(len(pcs)):
            order = pcs[inv:] + pcs[:inv]
            v = []
            base = low
            for pc in order:
                n = base + ((pc - base) % 12)
                v.append(n)
                base = n + 1
            while v and v[-1] > high:
                v = [x - 12 for x in v]
            if v[0] < low - 7:
                continue
            cost = 0 if prev is None else sum(min(abs(a - b) for b in prev) for a in v)
            cost += abs(np.mean(v) - (low + high) / 2) * 0.3
            if cost < best_cost:
                best, best_cost = v, cost
        return best

    def chord_tones(self, bar, lo, hi):
        r, iv = self.chord_at(bar)
        pcs = {(r + i) % 12 for i in iv}
        return [m for m in range(lo, hi + 1) if m % 12 in pcs]

    def scale_tones(self, lo, hi):
        return [m for m in range(lo, hi + 1) if m % 12 in self.scale]

    # --- partes ---
    def part_pad(self, vel=0.8, bright=0.45, bus="pad", low=53, high=74, stab=None):
        prev = None
        for c in range(len(self.prog)):
            bar = c * self.bpc
            v = self.voicing(bar, low, high, prev)
            prev = v
            if stab:
                for b in range(self.bpc):
                    for beat, dur, sv in stab:
                        for m in v:
                            self.add(bus, self.at(bar + b, beat), inst_pad(m, dur * self.beat, vel * sv, bright, self.rng), p=0.5)
            else:
                for m in v:
                    self.add(bus, self.at(bar), inst_pad(m, self.bpc * 4 * self.beat * 0.98, vel, bright, self.rng), p=0.5)

    def part_bass(self, pattern, vel=0.9, kind="round", octave=36):
        """pattern: [(beat, dur_beats, grau)] por compasso; grau 0 = raiz, 7 = quinta, 12 = oitava,
        'a' = nota de aproximação (meio-tom abaixo da raiz seguinte)."""
        for bar in range(self.bars):
            r, _ = self.chord_at(bar)
            nr, _ = self.chord_at(bar + 1)
            root = octave + ((r - octave) % 12)
            if root > octave + 7:
                root -= 12
            for beat, dur, deg in pattern:
                if deg == "a":
                    nroot = octave + ((nr - octave) % 12)
                    if nroot > octave + 7:
                        nroot -= 12
                    m = nroot - 1 if nr != r else root + 7
                else:
                    m = root + deg
                v = vel * (1.0 if beat in (0, 0.0) else 0.85)
                self.add("bass", self.at(bar, beat), inst_bass(m, dur * self.beat * 0.95, v, kind), p=0.5)

    def part_arp(self, pattern, step=0.5, vel=0.55, low=60, high=84, bright=0.7, inst="pluck", bus="arp", gain=1.0):
        """pattern: índices nas notas do acorde (subindo a partir de `low`)."""
        steps_per_bar = int(round(4 / step))
        for bar in range(self.bars):
            tones = self.chord_tones(bar, low, high)
            if not tones:
                continue
            for s in range(steps_per_bar):
                idx = pattern[s % len(pattern)]
                if idx is None:
                    continue
                m = tones[min(idx, len(tones) - 1)]
                beat = s * step
                acc = 1.0 if beat % 1.0 == 0 else 0.78
                p = 0.3 + 0.4 * ((s % 4) / 3.0)
                if inst == "bell":
                    a = inst_bell(m, step * self.beat, vel * acc)
                else:
                    a = inst_pluck(m, step * self.beat * 0.9, vel * acc, bright)
                self.add(bus, self.at(bar, beat), a, gain, p)

    def make_motif(self, rhythm, contour_span=4):
        """Contorno (passos na escala) para um ritmo; reutilizado em cada frase."""
        steps = []
        pos = 0
        for i, (dur, rest) in enumerate(rhythm):
            if rest:
                steps.append(None)
                continue
            move = int(self.rng.choice([-2, -1, -1, 1, 1, 2, 0, 3, -3], p=[0.1, 0.18, 0.18, 0.18, 0.18, 0.1, 0.04, 0.02, 0.02]))
            if abs(pos + move) > contour_span:
                move = -move
            pos += move
            steps.append(pos)
        return steps

    def part_melody(self, rhythm, inst="bell", vel=0.7, low=67, high=88, bus="lead", phrase_bars=2,
                    start_bar=0, end_bar=None, motif=None, gain=1.0, answer_shift=2):
        """Melodia por frases de `phrase_bars` compassos com o mesmo contorno, ajustado ao acorde."""
        end_bar = self.bars if end_bar is None else end_bar
        motif = motif or self.make_motif(rhythm)
        scale = self.scale_tones(low - 5, high + 5)
        center = (low + high) // 2
        prev = None
        phrase = 0
        bar = start_bar
        while bar < end_bar:
            beat = 0.0
            tones = self.chord_tones(bar, low, high)
            anchor = min(tones, key=lambda m: abs(m - (prev if prev is not None else center))) if tones else center
            shift = answer_shift if phrase % 2 == 1 else 0
            notes = []
            for (dur, rest), st in zip(rhythm, motif):
                if rest or st is None:
                    beat += dur
                    continue
                b_bar = bar + int(beat // 4)
                b_beat = beat % 4
                if b_bar >= end_bar:
                    break
                i0 = scale.index(min(scale, key=lambda m: abs(m - anchor)))
                i = int(np.clip(i0 + st + shift, 0, len(scale) - 1))
                m = scale[i]
                strong = b_beat in (0.0, 2.0) or dur >= 1.5
                if strong:
                    ct = self.chord_tones(b_bar, low - 3, high + 3)
                    if ct:
                        m = min(ct, key=lambda x: abs(x - m))
                m = int(np.clip(m, low, high))
                notes.append((b_bar, b_beat, dur, m))
                beat += dur
            # fim de frase longa: última nota vai para a raiz/terça do acorde
            if notes and (phrase % 2 == 1):
                b_bar, b_beat, dur, m = notes[-1]
                r, iv = self.chord_at(b_bar)
                targets = [x for x in range(low, high + 1) if x % 12 in {(r + iv[0]) % 12, (r + iv[1]) % 12}]
                if targets:
                    notes[-1] = (b_bar, b_beat, dur, min(targets, key=lambda x: abs(x - m)))
            for b_bar, b_beat, dur, m in notes:
                d = dur * self.beat
                if inst == "bell":
                    a = inst_bell(m, d, vel)
                elif inst == "lead":
                    a = inst_lead(m, d * 0.92, vel)
                elif inst == "brass":
                    a = inst_brass(m, d * 0.9, vel)
                else:
                    a = inst_pluck(m, d, vel, 0.8)
                self.add(bus, self.at(b_bar, b_beat), a, gain, 0.5)
                prev = m
            phrase += 1
            bar += phrase_bars

    def part_drums(self, grid, fill=None, vel=1.0, crash_every=8, start_bar=0):
        """grid: {voz: "x.o." por 16 avos} (x = forte, o = fraco, . = nada)."""
        for bar in range(start_bar, self.bars):
            last = (bar % 8 == 7)
            g = fill if (last and fill) else grid
            for voice, patt in g.items():
                for s, ch in enumerate(patt):
                    if ch == ".":
                        continue
                    v = vel * (1.0 if ch == "x" else 0.55)
                    beat = s * 0.25
                    if voice == "kick":
                        a = drum_kick(v)
                    elif voice == "snare":
                        a = drum_snare(v)
                    elif voice == "hat":
                        a = drum_hat(v, seed=7 + s)
                    elif voice == "ohat":
                        a = drum_hat(v, True)
                    elif voice == "shaker":
                        a = drum_shaker(v, seed=9 + s)
                    elif voice == "rim":
                        a = drum_rim(v)
                    elif voice.startswith("tom"):
                        a = drum_tom({"tom1": 50, "tom2": 45, "tom3": 40}[voice], v)
                    else:
                        continue
                    p = {"hat": 0.62, "ohat": 0.62, "shaker": 0.38, "rim": 0.45, "tom1": 0.35, "tom2": 0.5, "tom3": 0.65}.get(voice, 0.5)
                    self.add("drums", self.at(bar, beat), a, 1.0, p)
            if crash_every and bar % crash_every == 0 and bar > 0 or (crash_every and bar == start_bar and start_bar > 0):
                self.add("drums", self.at(bar), drum_crash(vel * 0.8), 1.0, 0.55)

    def drum_bar(self, bar, grid, vel=1.0):
        """Um compasso de bateria (0.13.0: camadas de ataque, compasso a compasso)."""
        for voice, patt in grid.items():
            for st, ch in enumerate(patt):
                if ch == ".":
                    continue
                v = vel * (1.0 if ch == "x" else 0.55)
                beat = st * 0.25
                if voice == "kick":
                    a = drum_kick(v)
                elif voice == "snare":
                    a = drum_snare(v)
                elif voice == "hat":
                    a = drum_hat(v, seed=7 + st)
                elif voice == "ohat":
                    a = drum_hat(v, True)
                elif voice == "shaker":
                    a = drum_shaker(v, seed=9 + st)
                elif voice == "rim":
                    a = drum_rim(v)
                elif voice.startswith("tom"):
                    a = drum_tom({"tom1": 50, "tom2": 45, "tom3": 40}[voice], v)
                else:
                    continue
                p = {"hat": 0.62, "ohat": 0.62, "shaker": 0.38, "rim": 0.45, "tom1": 0.35, "tom2": 0.5, "tom3": 0.65}.get(voice, 0.5)
                self.add("drums", self.at(bar, beat), a, 1.0, p)

    # --- mistura ---
    # Equilíbrio automático: cada papel (pad, baixo, arpejo, melodia, bateria) fica a um nível percebido
    # (ponderação K, a dos LUFS, só onde toca) relativo à melodia. Assim nenhuma faixa fica com o baixo a tapar a
    # melodia ou a bateria a mandar, mesmo sem se ouvir cada mistura à mão.
    BALANCE = {"lead": 0.0, "arp": -5.0, "pad": -3.5, "bass": -4.5, "drums": -6.0}
    VERB_SEND = {"pad": 1.0, "arp": 0.6, "lead": 0.7, "bass": 0.1, "drums": 0.12}
    ECHO_SEND = {"arp": 0.9, "lead": 0.45}

    def render(self, verb_mix=0.32, echo_delay=0.75, ir_seconds=2.4, balance=None, master_gain=1.0):
        targets = dict(self.BALANCE)
        targets.update(balance or {})
        ref = None
        gains = {}
        levels = {k: loudness_db(b) for k, b in self.bus.items()}
        ref = levels["lead"] if levels["lead"] > -90 else max(levels.values())
        for k, lv in levels.items():
            gains[k] = 0.0 if lv <= -90 else 10 ** ((ref + targets.get(k, -6.0) - lv) / 20.0)
        self.levels = levels
        bus = {k: b * gains[k] for k, b in self.bus.items()}
        ir = make_ir(ir_seconds, seed=len(self.name))
        echo_in = sum(bus[k] * g for k, g in self.ECHO_SEND.items())
        echo_wet = pingpong(echo_in, echo_delay * self.beat, 0.38)
        dry = sum(bus.values())
        send = sum(bus[k] * g for k, g in self.VERB_SEND.items()) + echo_wet * 0.5
        wet = reverb(send, ir)
        mix = dry + echo_wet * 0.7 + wet * verb_mix
        # loop perfeito: a cauda (eco, reverb, notas soltas) volta ao início
        L = int(self.length * SR)
        out = mix[:L].copy()
        tail = mix[L:]
        out[: len(tail)] += tail
        # filtros num ciclo duplo, para o início do loop já ter o estado do fim
        two = np.concatenate([out, out])
        two = highpass(two, 32, 2)
        two = lowpass(two, 13000, 2)
        out = two[L:]
        return master(out, master_gain)


def k_weighting():
    """Ponderação K (ITU-R BS.1770, a dos LUFS): prateleira +4 dB nos agudos e passa-alto a 38 Hz."""
    def shelf(G, Q, fc):
        A = 10 ** (G / 40)
        w0 = 2 * np.pi * fc / SR
        al = np.sin(w0) / (2 * Q)
        c = np.cos(w0)
        b = [A * ((A + 1) + (A - 1) * c + 2 * np.sqrt(A) * al), -2 * A * ((A - 1) + (A + 1) * c),
             A * ((A + 1) + (A - 1) * c - 2 * np.sqrt(A) * al)]
        a = [(A + 1) - (A - 1) * c + 2 * np.sqrt(A) * al, 2 * ((A - 1) - (A + 1) * c),
             (A + 1) - (A - 1) * c - 2 * np.sqrt(A) * al]
        return np.array(b) / a[0], np.array(a) / a[0]

    def hp(Q, fc):
        w0 = 2 * np.pi * fc / SR
        al = np.sin(w0) / (2 * Q)
        c = np.cos(w0)
        b = [(1 + c) / 2, -(1 + c), (1 + c) / 2]
        a = [1 + al, -2 * c, 1 - al]
        return np.array(b) / a[0], np.array(a) / a[0]

    return [shelf(4.0, 1 / np.sqrt(2), 1500.0), hp(0.5, 38.0)]


_KW = None


def loudness_db(x):
    """Nível percebido (ponderação K) só nas janelas de 100 ms em que a parte toca (com porta a −45 dB)."""
    global _KW
    if _KW is None:
        _KW = k_weighting()
    mono = x.mean(axis=1) if x.ndim == 2 else x
    if not np.any(mono):
        return -120.0
    y = mono
    for b, a in _KW:
        y = signal.lfilter(b, a, y)
    w = int(0.1 * SR)
    n = len(y) // w
    if n == 0:
        return -120.0
    blocks = np.sqrt(np.mean(y[: n * w].reshape(n, w) ** 2, axis=1)) + 1e-12
    db = 20 * np.log10(blocks)
    gate = db > (db.max() - 45.0)
    return float(10 * np.log10(np.mean(blocks[gate] ** 2)))


def master(x, gain=1.0, target_rms=0.105):
    x = x - np.mean(x, axis=0)
    rms = np.sqrt(np.mean(x ** 2))
    if rms > 0:
        x = x * (target_rms / rms) * gain
    x = np.tanh(x * 1.1) / 1.1
    peak = np.max(np.abs(x))
    if peak > 0.89:
        x = x * (0.89 / peak)
    return x


# --------------------------------------------------------------------------------------------------
# As faixas
# --------------------------------------------------------------------------------------------------

R = lambda *d: [(x, False) if x > 0 else (-x, True) for x in d]   # ritmo: negativo = pausa


def song_menu():
    s = Song("menu", 86, "D", "dorian",
             [("D", "m9"), ("G", "9"), ("F", "maj7"), ("C", "add9"), ("Bb", "maj7"), ("C", "6"), ("A", "m7"), ("A", "7sus4")],
             2, seed=101)
    s.part_pad(vel=0.85, bright=0.35)
    s.part_bass([(0, 3.5, 0), (3.5, 0.5, 7)], vel=0.75)
    s.part_arp([0, 2, 1, 3, 2, 4, 1, 3], step=0.5, vel=0.32, low=62, high=86, bright=0.55, gain=0.9)
    s.part_melody(R(1.5, 0.5, 1, 1, 2, -2, 1, 0.5, 0.5, 2, -1, 3), inst="bell", vel=0.55, low=69, high=86,
                  start_bar=2, phrase_bars=4)
    s.part_drums({"shaker": "o.x.o.x.o.x.o.x.", "kick": "x...........x...", "rim": "........o......."},
                 fill={"shaker": "o.x.o.x.o.x.xxxx", "kick": "x.....x...x.x...", "rim": "........o...o.o."}, vel=0.55, crash_every=0)
    return s.render(verb_mix=0.42, echo_delay=0.75, ir_seconds=2.8, balance={"drums": -12.0, "pad": -2.5})


def song_act1():
    s = Song("act1", 100, "C", "lydian",
             [("C", "add9"), ("G", ""), ("A", "m7"), ("F", "maj7#11"), ("D", "m7"), ("G", "7sus4"), ("E", "m7"), ("A", "m7"),
              ("F", "maj7"), ("G", ""), ("E", "m7"), ("A", "m"), ("D", "m7"), ("F", ""), ("G", "sus4"), ("G", "")],
             1, seed=202)
    s.part_pad(vel=0.7, bright=0.5)
    s.part_bass([(0, 1.5, 0), (1.5, 0.5, 0), (2, 1, 7), (3, 0.5, 12), (3.5, 0.5, "a")], vel=0.8)
    s.part_arp([0, 2, 4, 2, 1, 3, 5, 3], step=0.25, vel=0.26, low=64, high=88, bright=0.75, gain=0.8)
    s.part_melody(R(1, 0.5, 0.5, 1, -1, 1.5, 0.5, 2), inst="bell", vel=0.6, low=67, high=88, phrase_bars=2)
    s.part_drums({"kick": "x.......x.o.....", "rim": "....x.......x...", "hat": "o.x.o.x.o.x.o.x.", "shaker": "................"},
                 fill={"kick": "x.......x.o.x.x.", "rim": "....x.......x.xx", "hat": "o.x.o.x.o.x.xxxx"}, vel=0.7)
    return s.render(verb_mix=0.3, echo_delay=0.75, balance={"drums": -8.0})


def song_act2():
    s = Song("act2", 108, "A", "minor",
             [("A", "m"), ("F", "maj7"), ("C", ""), ("G", ""), ("A", "m"), ("F", ""), ("D", "m7"), ("E", "7sus4"),
              ("F", "maj7"), ("G", ""), ("E", "m7"), ("A", "m"), ("D", "m"), ("F", ""), ("E", "sus4"), ("E", "")],
             1, seed=303)
    s.part_pad(vel=0.65, bright=0.4)
    s.part_bass([(0, 0.5, 0), (0.5, 0.5, 0), (1, 0.5, 12), (1.5, 0.5, 0), (2, 0.5, 0), (2.5, 0.5, 7), (3, 0.5, 12), (3.5, 0.5, "a")], vel=0.75)
    s.part_arp([0, 1, 2, 1], step=0.5, vel=0.3, low=57, high=81, bright=0.6, gain=0.85)
    s.part_melody(R(0.5, 0.5, 1, 0.5, 0.5, 1, 1, 2, -1), inst="pluck", vel=0.62, low=64, high=84, phrase_bars=2)
    s.part_melody(R(2, 2, 3, -1), inst="lead", vel=0.42, low=69, high=84, phrase_bars=2, start_bar=8, bus="arp")
    s.part_drums({"kick": "x.....x...x.....", "snare": "....x.......x...", "hat": "xoxoxoxoxoxoxoxo"},
                 fill={"kick": "x.....x...x.....", "snare": "....x.......xoxx", "hat": "xoxoxoxoxoxo...."}, vel=0.72)
    return s.render(verb_mix=0.28, echo_delay=0.75)


def song_act3():
    s = Song("act3", 116, "E", "phrygian",
             [("E", "m"), ("F", ""), ("E", "m"), ("D", ""), ("C", "maj7"), ("B", "7"), ("E", "m"), ("F", "maj7"),
              ("A", "m"), ("C", ""), ("B", "sus4"), ("B", "7"), ("E", "m"), ("D", ""), ("C", ""), ("B", "7b9")],
             1, seed=404)
    s.part_pad(vel=0.6, bright=0.38, stab=[(0, 1.5, 1.0), (2.5, 1.0, 0.7)])
    s.part_bass([(0, 0.25, 0), (0.25, 0.25, 0), (0.5, 0.5, 0), (1, 0.25, 0), (1.25, 0.25, 0), (1.5, 0.5, 12),
                 (2, 0.25, 0), (2.25, 0.25, 0), (2.5, 0.5, 7), (3, 0.5, 0), (3.5, 0.5, "a")], vel=0.72)
    s.part_arp([0, 2, 1, 2, 0, 2, 1, 3], step=0.25, vel=0.22, low=59, high=83, bright=0.5, gain=0.8)
    s.part_melody(R(1, 0.5, 0.5, 1.5, 0.5, 1, 1, 0.5, 0.5, 1), inst="lead", vel=0.5, low=64, high=83, phrase_bars=2)
    s.part_drums({"kick": "x..x..x...x..x..", "snare": "....x.......x...", "hat": "x.o.x.o.x.o.x.o.", "tom3": "..............o."},
                 fill={"kick": "x..x..x.........", "snare": "....x...........", "tom1": "........xo......", "tom2": "..........xo....", "tom3": "............xoxo"},
                 vel=0.78)
    return s.render(verb_mix=0.27, echo_delay=0.5, balance={"drums": -5.5})


def song_act4():
    s = Song("act4", 124, "F#", "harmonic",
             [("F#", "m"), ("D", "maj7"), ("E", ""), ("C#", "7"), ("F#", "m"), ("B", "m7"), ("D", ""), ("C#", "7"),
              ("B", "m"), ("D", ""), ("A", ""), ("E", ""), ("F#", "m"), ("D", ""), ("C#", "sus4"), ("C#", "7")],
             1, seed=505)
    s.part_pad(vel=0.75, bright=0.5, low=54, high=78)
    s.part_bass([(0, 0.5, 0), (0.5, 0.5, 12), (1, 0.5, 0), (1.5, 0.5, 12), (2, 0.5, 0), (2.5, 0.5, 12), (3, 0.5, 7), (3.5, 0.5, "a")], vel=0.8)
    s.part_arp([0, 1, 2, 3, 4, 3, 2, 1], step=0.25, vel=0.24, low=61, high=90, bright=0.72, gain=0.85)
    s.part_melody(R(2, 1, 1, 1.5, 0.5, 1, 1), inst="brass", vel=0.62, low=61, high=81, phrase_bars=2)
    s.part_melody(R(0.5, 0.5, 0.5, 0.5, 1, 1, 2, -2), inst="bell", vel=0.42, low=73, high=90, phrase_bars=2, start_bar=8, bus="arp")
    s.part_drums({"kick": "x...x...x...x...", "snare": "....x.......x...", "hat": "..x...x...x...x.", "ohat": "......o.......o."},
                 fill={"kick": "x...x...x.x.x.x.", "snare": "....x.......x.xx", "tom1": "........x.......", "tom2": "..........x.....", "tom3": "............x..."},
                 vel=0.8)
    return s.render(verb_mix=0.3, echo_delay=0.75, ir_seconds=2.6)


def song_endless():
    s = Song("endless", 84, "Bb", "lydian",
             [("Bb", "maj7#11"), ("C", "add9"), ("A", "m7"), ("D", "m9"), ("G", "m9"), ("C", "add9"), ("F", "maj9"), ("A", "7sus4")],
             2, seed=606)
    s.part_pad(vel=0.9, bright=0.3, low=50, high=74)
    s.part_bass([(0, 7.5, 0)], vel=0.55)
    s.part_arp([0, None, 2, None, 4, None, 3, None], step=0.5, vel=0.36, low=70, high=94, inst="bell", gain=0.75)
    s.part_melody(R(3, 1, 2, 2, -4, 2, 2), inst="bell", vel=0.42, low=72, high=91, phrase_bars=4, start_bar=4)
    s.part_drums({"kick": "x.........x.....", "shaker": "..o...o...o...o."}, vel=0.4, crash_every=0)
    return s.render(verb_mix=0.5, echo_delay=1.5, ir_seconds=3.4, balance={"drums": -13.0, "pad": -2.0, "arp": -4.0})


def song_boss():
    s = Song("boss", 138, "C", "harmonic",
             [("C", "m"), ("Ab", ""), ("F", "m"), ("G", "7"), ("C", "m"), ("Ab", "maj7"), ("Db", ""), ("G", "7"),
              ("F", "m"), ("G", ""), ("Eb", ""), ("Ab", ""), ("F", "m"), ("Db", ""), ("B", "dim7"), ("G", "7b9")],
             1, seed=707)
    s.part_pad(vel=0.55, bright=0.55, stab=[(0, 0.75, 1.0), (1.5, 0.5, 0.8), (3, 0.5, 0.7)], low=55, high=75)
    s.part_bass([(0, 0.5, 0), (0.5, 0.5, 0), (1, 0.5, 12), (1.5, 0.5, 0), (2, 0.5, 0), (2.5, 0.5, 12), (3, 0.5, 0), (3.5, 0.5, "a")],
                vel=0.82, kind="saw")
    s.part_arp([0, 1, 2, 1, 3, 2, 1, 0], step=0.25, vel=0.2, low=60, high=84, bright=0.6, gain=0.75)
    s.part_melody(R(1.5, 0.5, 1, 1, 1, 0.5, 0.5, 1, 1), inst="lead", vel=0.55, low=60, high=84, phrase_bars=2, answer_shift=-2)
    s.part_drums({"kick": "x.x...x...x.x...", "snare": "....x.......x...", "hat": "xoxoxoxoxoxoxoxo"},
                 fill={"kick": "x.x...x.x.x.x.x.", "snare": "....x...x.x.xxxx", "hat": "xoxoxoxo........"}, vel=0.85)
    return s.render(verb_mix=0.24, echo_delay=0.75, balance={"drums": -4.5, "bass": -4.0, "pad": -5.0})


# --- 0.13.0: temas das guildas (Livro II da História) ---
# Cada guilda tem o seu tema curto (8 compassos), num dos andamentos das faixas (para servir a camada de
# ataque do mesmo andamento). O Music.gd escolhe-o pelo "music" do capítulo em data/saga.json.

def song_guild_wu():
    s = Song("guild_wu", 100, "D", "lydian",
             [("D", "maj7"), ("E", "add9"), ("B", "m7"), ("G", "maj7"), ("D", ""), ("A", "sus4"), ("G", "maj9"), ("A", "")], 1, seed=811)
    s.part_pad(vel=0.75, bright=0.55)
    s.part_bass([(0, 2, 0), (2, 2, 7)], vel=0.65)
    s.part_arp([0, 1, 2, 3, 2, 1, 2, 3], step=0.5, vel=0.3, low=66, high=90, inst="bell", gain=0.8)
    s.part_melody(R(1, 1, 2, 1, 1, 2), inst="bell", vel=0.55, low=69, high=88, phrase_bars=2)
    s.part_drums({"rim": "....x.......x...", "shaker": "o.x.o.x.o.x.o.x.", "kick": "x.......x......."}, vel=0.55, crash_every=0)
    return s.render(verb_mix=0.4, echo_delay=0.75, ir_seconds=2.8, balance={"drums": -11.0})


def song_guild_ub():
    s = Song("guild_ub", 84, "B", "minor",
             [("B", "m9"), ("G", "maj7"), ("E", "m7"), ("F#", "7sus4"), ("B", "m"), ("D", "maj7"), ("E", "m9"), ("F#", "7")], 1, seed=822)
    s.part_pad(vel=0.7, bright=0.25, low=47, high=69)
    s.part_bass([(0, 3, 0), (3, 1, 7)], vel=0.6)
    s.part_arp([0, None, 2, None, 1, None, 3, None], step=0.5, vel=0.3, low=59, high=79, bright=0.4, gain=0.75)
    s.part_melody(R(2, 1, -1, 1.5, 0.5, 2), inst="pluck", vel=0.5, low=62, high=79, phrase_bars=2)
    s.part_drums({"kick": "x.........x.....", "rim": "........o.......", "shaker": "..o...o...o...o."}, vel=0.5, crash_every=0)
    return s.render(verb_mix=0.45, echo_delay=1.5, ir_seconds=3.2, balance={"drums": -10.0, "pad": -2.5})


def song_guild_br():
    s = Song("guild_br", 138, "E", "harmonic",
             [("E", "m"), ("C", ""), ("A", "m"), ("B", "7"), ("E", "m"), ("F", ""), ("C", ""), ("B", "7b9")], 1, seed=833)
    s.part_pad(vel=0.55, bright=0.5, stab=[(0, 0.5, 1.0), (1, 0.5, 0.7), (2, 0.5, 0.9), (3, 0.5, 0.7)], low=55, high=74)
    s.part_bass([(0, 0.5, 0), (1, 0.5, 7), (2, 0.5, 0), (3, 0.5, 7)], vel=0.8, kind="saw")
    s.part_melody(R(0.5, 0.5, 1, 0.5, 0.5, 1, 1, 1, 2), inst="brass", vel=0.6, low=62, high=84, phrase_bars=2, answer_shift=-2)
    s.part_drums({"kick": "x...x...x...x...", "snare": "..x...x...x...x.", "hat": "x.x.x.x.x.x.x.x."},
                 fill={"kick": "x...x...x.x.x.x.", "snare": "..x...x...xxxxxx", "hat": "x.x.x.x........."}, vel=0.82)
    return s.render(verb_mix=0.22, echo_delay=0.75, balance={"drums": -4.5, "bass": -4.0})


def song_guild_rg():
    s = Song("guild_rg", 116, "A", "dorian",
             [("A", "m"), ("G", ""), ("D", ""), ("A", "m"), ("C", ""), ("G", ""), ("D", "sus4"), ("E", "7sus4")], 1, seed=844)
    s.part_pad(vel=0.55, bright=0.35, stab=[(0, 1.5, 1.0), (2.5, 1.0, 0.8)], low=52, high=72)
    s.part_bass([(0, 0.5, 0), (0.5, 0.5, 0), (1.5, 0.5, 12), (2, 0.5, 0), (3, 0.5, 7), (3.5, 0.5, "a")], vel=0.85)
    s.part_melody(R(1, 0.5, 0.5, 1, 1, 1.5, 0.5, 2), inst="lead", vel=0.52, low=62, high=81, phrase_bars=2)
    s.part_drums({"kick": "x..x..x...x.....", "snare": "....x.......x...", "tom3": "......x.......x.", "hat": "x.o.x.o.x.o.x.o."},
                 fill={"kick": "x..x..x.........", "snare": "....x...........", "tom1": "........xo......", "tom2": "..........xo....", "tom3": "............xoxo"}, vel=0.85)
    return s.render(verb_mix=0.26, echo_delay=0.5, balance={"drums": -4.0})


def song_guild_gw():
    s = Song("guild_gw", 100, "G", "major",
             [("G", "add9"), ("D", ""), ("E", "m7"), ("C", "maj7"), ("G", ""), ("D", "sus4"), ("C", "add9"), ("D", "")], 1, seed=855)
    s.part_pad(vel=0.8, bright=0.45)
    s.part_bass([(0, 1.5, 0), (1.5, 0.5, 7), (2, 2, 0)], vel=0.65)
    s.part_arp([0, 2, 1, 3, 2, 4, 3, 1], step=0.5, vel=0.28, low=67, high=91, inst="bell", gain=0.8)
    s.part_melody(R(1.5, 0.5, 1, 1, 2, 1, 1), inst="bell", vel=0.55, low=67, high=86, phrase_bars=2)
    s.part_drums({"shaker": "o.x.o.x.o.x.o.x.", "kick": "x.......x.......", "rim": "....o.......o..."}, vel=0.5, crash_every=0)
    return s.render(verb_mix=0.42, echo_delay=0.75, ir_seconds=2.8, balance={"drums": -12.0, "pad": -2.5})


def song_guild_wb():
    s = Song("guild_wb", 84, "C", "harmonic",
             [("C", "m"), ("Ab", "maj7"), ("F", "m"), ("G", "7"), ("C", "m"), ("Ab", ""), ("Db", "maj7"), ("G", "7sus4")], 1, seed=866)
    s.part_pad(vel=0.9, bright=0.4, low=50, high=74)
    s.part_bass([(0, 4, 0)], vel=0.6)
    s.part_melody(R(2, 1, 1, 3, 1), inst="bell", vel=0.55, low=67, high=86, phrase_bars=2)
    s.part_arp([0, None, None, 2, None, None, 1, None], step=0.5, vel=0.25, low=60, high=79, inst="bell", gain=0.7)
    s.part_drums({"kick": "x.......x.......", "rim": "........x......."}, vel=0.5, crash_every=0)
    return s.render(verb_mix=0.5, echo_delay=1.5, ir_seconds=3.6, balance={"drums": -11.0, "pad": -1.5})


def song_guild_ur():
    s = Song("guild_ur", 124, "F#", "lydian",
             [("F#", "maj7"), ("G#", "add9"), ("D#", "m7"), ("B", "maj7#11"), ("F#", ""), ("C#", "sus4"), ("B", "maj9"), ("C#", "")], 1, seed=877)
    s.part_pad(vel=0.6, bright=0.6, low=54, high=76)
    s.part_bass([(0, 0.5, 0), (0.5, 0.5, 12), (1, 0.5, 0), (1.5, 0.5, 12), (2, 0.5, 7), (2.5, 0.5, 12), (3, 0.5, 0), (3.5, 0.5, "a")], vel=0.75)
    s.part_arp([0, 1, 2, 3, 4, 3, 2, 1], step=0.25, vel=0.24, low=63, high=92, bright=0.8, gain=0.85)
    s.part_melody(R(0.5, 0.5, 1, 0.5, 0.5, 1, 2, -2), inst="lead", vel=0.5, low=66, high=85, phrase_bars=2)
    s.part_drums({"kick": "x...x...x...x...", "snare": "....x.......x...", "hat": "xoxoxoxoxoxoxoxo"},
                 fill={"kick": "x...x...x.x.x.x.", "snare": "....x.......x.xx", "hat": "xoxoxoxoxoxo...."}, vel=0.75)
    return s.render(verb_mix=0.3, echo_delay=0.75, balance={"drums": -6.0})


def song_guild_bg():
    s = Song("guild_bg", 108, "C#", "phrygian",
             [("C#", "m"), ("D", ""), ("C#", "m"), ("B", ""), ("A", "maj7"), ("G#", "7"), ("C#", "m"), ("D", "maj7")], 1, seed=888)
    s.part_pad(vel=0.55, bright=0.3, low=49, high=70)
    s.part_bass([(0, 0.75, 0), (0.75, 0.75, 0), (1.5, 0.5, 7), (2, 1, 0), (3, 1, "a")], vel=0.75)
    s.part_melody(R(1, 0.5, 0.5, 1.5, 0.5, 1, 1, 2), inst="pluck", vel=0.55, low=61, high=80, phrase_bars=2)
    s.part_drums({"kick": "x.....x...x.....", "tom3": "....o.......o...", "shaker": "..x...x...x...x.", "rim": "..........o....."}, vel=0.7, crash_every=0)
    return s.render(verb_mix=0.34, echo_delay=0.75, ir_seconds=3.0, balance={"drums": -6.5})


def song_guild_rw():
    s = Song("guild_rw", 124, "Bb", "mixolydian",
             [("Bb", ""), ("Ab", ""), ("Eb", ""), ("F", ""), ("Bb", ""), ("G", "m"), ("Eb", ""), ("F", "sus4")], 1, seed=899)
    s.part_pad(vel=0.6, bright=0.5, stab=[(0, 1, 1.0), (2, 1, 0.8)], low=53, high=74)
    s.part_bass([(0, 1, 0), (1, 1, 7), (2, 1, 0), (3, 1, 7)], vel=0.8)
    s.part_melody(R(1, 0.5, 0.5, 1, 1, 2, 2), inst="brass", vel=0.62, low=62, high=82, phrase_bars=2)
    s.part_drums({"kick": "x.......x.......", "snare": "....x..x....x.xx", "hat": "x.x.x.x.x.x.x.x."},
                 fill={"kick": "x.......x.......", "snare": "x.x.x.x.xxxxxxxx", "hat": "x.x.x.x........."}, vel=0.8)
    return s.render(verb_mix=0.26, echo_delay=0.75, balance={"drums": -4.5})


def song_guild_gu():
    s = Song("guild_gu", 108, "Eb", "dorian",
             [("Eb", "m9"), ("Ab", "9"), ("Bb", "m7"), ("Db", "maj7"), ("Eb", "m7"), ("B", "maj7"), ("Ab", "9"), ("Bb", "7sus4")], 1, seed=900)
    s.part_pad(vel=0.7, bright=0.4, low=51, high=74)
    s.part_bass([(0, 1.5, 0), (1.5, 1, 7), (2.5, 1.5, 0)], vel=0.65)
    s.part_arp([0, 2, 4, 2, 1, 3, 5, 3], step=0.25, vel=0.22, low=63, high=89, inst="bell", gain=0.8)
    s.part_melody(R(1.5, 0.5, 2, 1, 1, 2), inst="bell", vel=0.5, low=66, high=86, phrase_bars=2)
    s.part_drums({"kick": "x.....x.........", "rim": "....x.......x...", "shaker": "o.o.x.o.o.o.x.o."}, vel=0.6, crash_every=0)
    return s.render(verb_mix=0.4, echo_delay=0.75, ir_seconds=3.0, balance={"drums": -9.0})


# --- 0.13.0: camada de ataque (a música cresce durante a cascata) ---
# Só percussão (serve qualquer tonalidade), 4 compassos, uma por andamento das faixas. O Music.gd toca-a por
# cima da faixa enquanto o ataque se conta, alinhada ao compasso, e funde-a para fora no fim.
DRIVE_BPMS = [84, 86, 100, 108, 116, 124, 138]


def drive_layer(bpm):
    s = Song("drive%d" % bpm, bpm, "C", "major", [("C", "")] * 4, 1, seed=950 + bpm)
    main = {"kick": "x...x...x...x...", "snare": "....x.......x...", "hat": "xoxoxoxoxoxoxoxo", "ohat": "..o...o...o...o.", "shaker": "x.x.x.x.x.x.x.x."}
    fill = {"kick": "x...x...x.x.x.x.", "snare": "....x...x.x.xxxx", "hat": "xoxoxoxoxoxo....", "tom1": "........x.......", "tom2": "..........x.....", "tom3": "............x.x."}
    for bar in range(4):
        s.drum_bar(bar, fill if bar == 3 else main, vel=0.9)
    return s.render(verb_mix=0.14, echo_delay=0.75, ir_seconds=1.6, master_gain=0.62)


SONGS = {"menu": song_menu, "act1": song_act1, "act2": song_act2, "act3": song_act3, "act4": song_act4,
         "endless": song_endless, "boss": song_boss,
         "guild_wu": song_guild_wu, "guild_ub": song_guild_ub, "guild_br": song_guild_br,
         "guild_rg": song_guild_rg, "guild_gw": song_guild_gw, "guild_wb": song_guild_wb,
         "guild_ur": song_guild_ur, "guild_bg": song_guild_bg, "guild_rw": song_guild_rw,
         "guild_gu": song_guild_gu}
for _bpm in DRIVE_BPMS:
    SONGS["drive_%d" % _bpm] = (lambda b: (lambda: drive_layer(b)))(_bpm)
# Faixas novas da 0.13.0 em qualidade um pouco mais baixa (mais pequenas no APK).
LOW_QUALITY = {n for n in SONGS if n.startswith("guild_") or n.startswith("drive_")}


# --------------------------------------------------------------------------------------------------
# Efeitos sonoros
# --------------------------------------------------------------------------------------------------

def _noise(seconds, seed):
    return np.random.default_rng(seed).standard_normal(int(seconds * SR))


def _sweep_bp(x, f0, f1, q=2.0, frames=24):
    """Passa-banda a varrer de f0 para f1 (em blocos)."""
    out = np.zeros_like(x)
    n = len(x)
    edges = np.linspace(0, n, frames + 1).astype(int)
    for i in range(frames):
        f = f0 * (f1 / f0) ** (i / max(frames - 1, 1))
        lo, hi = f / (1 + 1 / q), min(f * (1 + 1 / q), 0.45 * SR)
        seg = bandpass(x[max(0, edges[i] - 256): edges[i + 1]], lo, hi)
        out[edges[i]: edges[i + 1]] = seg[-(edges[i + 1] - edges[i]):]
    return out


def sfx_draw():
    x = _noise(0.16, 1)
    t = np.arange(len(x)) / SR
    y = _sweep_bp(x, 1500, 5500) * np.clip(t / 0.02, 0, 1) * np.exp(-t * 22)
    return y * 0.5


def sfx_play():
    t = tvec(0.16)
    f = 90 + 90 * np.exp(-t * 40)
    thud = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 26)
    click = highpass(_noise(0.16, 2), 2500) * np.exp(-t * 260) * 0.35
    return (thud * 0.8 + click)


def sfx_land():
    t = tvec(0.6)
    rumble = lowpass(_noise(0.6, 3), 220, 2) * np.exp(-t * 7) * 2.2
    low = np.sin(2 * np.pi * 68 * t) * np.exp(-t * 9) * 0.5
    chime = inst_pluck(67, 0.4, 0.5, 0.6)[: len(t)] + inst_pluck(74, 0.4, 0.4, 0.6)[: len(t)]
    chime = np.pad(chime, (0, max(0, len(t) - len(chime))))[: len(t)]
    return rumble + low + chime * 1.2


def _fades(x, fin=0.002, fout=0.006):
    x = np.array(x, dtype=float)
    i = min(len(x), int(fin * SR))
    o = min(len(x), int(fout * SR))
    if i > 0:
        x[:i] *= np.linspace(0, 1, i)
    if o > 0:
        x[-o:] *= np.linspace(1, 0, o)
    return x


def sfx_coin():
    t1 = tvec(0.075)
    t2 = tvec(0.34)
    a = _fades(additive(988, t1, [1, 0, 0.3, 0, 0.15]) * 0.5, 0.002, 0.008)
    b = additive(1319, t2, [1, 0, 0.3, 0, 0.15]) * np.exp(-t2 * 9) * 0.5
    b = _fades(b, 0.003, 0.02)
    out = np.zeros(len(a) + len(b) - int(0.006 * SR))
    out[: len(a)] += a
    out[len(a) - int(0.006 * SR):] += b
    return out


def sfx_heal():
    out = np.zeros(int(0.8 * SR))
    for i, m in enumerate([72, 76, 79, 84]):
        b = inst_bell(m, 0.25, 0.8, ratio=2.0, index=0.8)
        j = int(i * 0.055 * SR)
        k = min(len(out), j + len(b))
        out[j:k] += b[: k - j]
    t = np.arange(len(out)) / SR
    out += highpass(_noise(0.8, 4), 6000) * np.exp(-t * 6) * 0.05
    return out * 1.6


def sfx_shield():
    t = tvec(0.55)
    w = np.zeros_like(t)
    for r, d in ((1.0, 6), (2.76, 9), (5.4, 13), (8.93, 18)):
        w += np.sin(2 * np.pi * 420 * r * t) * np.exp(-t * d) / r ** 0.5
    w += highpass(_noise(0.55, 5), 3000) * np.exp(-t * 60) * 0.5
    return w * 0.35


def sfx_relic():
    return inst_bell(84, 0.2, 1.0, ratio=4.0, index=1.4, decay=7.0)[: int(0.45 * SR)] * 2.2


def sfx_victory():
    out = np.zeros(int(2.2 * SR))
    seq = [(60, 0.0, 0.14), (64, 0.13, 0.14), (67, 0.26, 0.14), (72, 0.39, 0.9)]
    for m, st, d in seq:
        a = inst_brass(m, d, 0.9)
        j = int(st * SR)
        k = min(len(out), j + len(a))
        out[j:k] += a[: k - j] * 2.6
    for m in (60, 64, 67, 72, 76):
        a = inst_pad(m, 1.1, 0.6, 0.55)[:, 0]
        j = int(0.39 * SR)
        k = min(len(out), j + len(a))
        out[j:k] += a[: k - j] * 1.8
    t = np.arange(len(out)) / SR
    roll = lowpass(_noise(2.2, 6), 400) * np.clip((t - 0.1) / 0.3, 0, 1) * np.exp(-np.clip(t - 0.4, 0, None) * 5) * 0.25
    return out + roll


def sfx_defeat():
    out = np.zeros(int(2.2 * SR))
    for m, st, d in [(67, 0.0, 0.35), (63, 0.35, 0.35), (60, 0.7, 0.35), (59, 1.05, 0.9)]:
        a = inst_lead(m, d, 0.9, 0.3)
        j = int(st * SR)
        k = min(len(out), j + len(a))
        out[j:k] += a[: k - j] * 2.4
    drone = inst_pad(36, 1.8, 0.6, 0.25)[:, 0]
    out[: len(drone)] += drone[: len(out)] * 1.6
    return out


def sfx_unlock():
    out = np.zeros(int(0.9 * SR))
    for i, m in enumerate([84, 88, 91, 96]):
        b = inst_bell(m, 0.18, 0.7, ratio=4.0, index=1.0, decay=5)
        j = int(i * 0.06 * SR)
        k = min(len(out), j + len(b))
        out[j:k] += b[: k - j]
    t = np.arange(len(out)) / SR
    out += highpass(_noise(0.9, 7), 7000) * np.clip(t / 0.05, 0, 1) * np.exp(-t * 5) * 0.06
    return out * 1.6


def sfx_boss():
    t = tvec(1.5)
    vib = 1 + 0.02 * np.sin(2 * np.pi * 6 * t)
    f = 52 * vib * (1 + 0.15 * np.exp(-t * 3))
    ph = 2 * np.pi * np.cumsum(f) / SR
    w = np.zeros_like(t)
    for k in range(1, 30):
        w += np.sin(k * ph) / k
    growl = 1 + 0.35 * np.sin(2 * np.pi * 31 * t)
    env = np.clip(t / 0.12, 0, 1) * np.exp(-np.clip(t - 0.5, 0, None) * 2.6)
    w = lowpass(w * growl, 900) * env
    breath = bandpass(_noise(1.5, 8), 300, 2500) * env * 0.25
    boom = np.sin(2 * np.pi * np.cumsum(40 + 50 * np.exp(-t * 12)) / SR) * np.exp(-t * 4) * 0.8
    return np.tanh(1.4 * (w * 0.8 + breath + boom)) * 0.8


def sfx_transform():
    t = tvec(0.6)
    f = 300 * (1 + 2.5 * t / 0.6)
    ph = 2 * np.pi * np.cumsum(f) / SR
    idx = 2.5 * np.exp(-t * 3)
    w = np.sin(ph + idx * np.sin(ph * 1.5)) * np.clip(t / 0.03, 0, 1) * np.exp(-t * 4)
    sh = highpass(_noise(0.6, 9), 5000) * np.exp(-t * 7) * 0.08
    return (w * 0.4 + sh)


def sfx_shuffle():
    out = np.zeros(int(0.5 * SR))
    n = 16
    times = np.cumsum(np.concatenate([[0], 0.02 + 0.012 * np.abs(np.linspace(-1, 1, n - 1))]))
    for i, st in enumerate(times):
        c = highpass(_noise(0.02, 10 + i), 2000) * np.exp(-np.arange(int(0.02 * SR)) / SR * 300) * 0.5
        j = int(st * SR)
        k = min(len(out), j + len(c))
        out[j:k] += c[: k - j]
    return out


def sfx_keyword():
    x = _noise(0.35, 11)
    t = np.arange(len(x)) / SR
    y = _sweep_bp(x, 500, 3200, q=3) * np.sin(np.pi * np.clip(t / 0.35, 0, 1)) * 0.7
    chime = inst_bell(88, 0.15, 0.4, ratio=4.0, index=0.6, decay=8)
    j = int(0.18 * SR)
    k = min(len(y), j + len(chime))
    y[j:k] += chime[: k - j]
    return y


def sfx_jail():
    out = np.zeros(int(0.6 * SR))
    for st, base in ((0.0, 310), (0.11, 270)):
        t = tvec(0.4)
        w = np.zeros_like(t)
        for r, d in ((1.0, 9), (2.4, 12), (4.1, 16), (6.7, 22)):
            w += np.sin(2 * np.pi * base * r * t) * np.exp(-t * d) / r ** 0.6
        w += highpass(_noise(0.4, 12), 2500) * np.exp(-t * 80) * 0.4
        j = int(st * SR)
        k = min(len(out), j + len(w))
        out[j:k] += w[: k - j] * 0.3
    t = np.arange(len(out)) / SR
    out += np.sin(2 * np.pi * 70 * t) * np.exp(-t * 14) * 0.4
    return out


def sfx_channel():
    x = _noise(0.25, 13)
    t = np.arange(len(x)) / SR
    y = _sweep_bp(x, 3000, 600, q=2.5) * np.sin(np.pi * np.clip(t / 0.25, 0, 1)) * 0.6
    tone = np.sin(2 * np.pi * np.cumsum(520 * np.exp(-t * 3)) / SR) * np.exp(-t * 12) * 0.15
    return y + tone


def sfx_death():
    t = tvec(0.3)
    crunch = lowpass(_noise(0.3, 14), 1800) * np.exp(-t * 18) * 0.7
    drop = np.sin(2 * np.pi * np.cumsum(300 * np.exp(-t * 6) + 60) / SR) * np.exp(-t * 9) * 0.5
    return crunch + drop


def sfx_deny():
    t = tvec(0.08)
    beep = _fades(additive(220, t, [1, 0, 0.33, 0, 0.2]) * np.exp(-t * 12), 0.004, 0.02)
    gap = np.zeros(int(0.04 * SR))
    return np.concatenate([beep, gap, beep * 0.85]) * 0.45


def sfx_level_up():
    out = np.zeros(int(0.9 * SR))
    for i, m in enumerate([72, 76, 79, 84, 88]):
        a = inst_pluck(m, 0.25, 0.8, 0.8)
        j = int(i * 0.07 * SR)
        k = min(len(out), j + len(a))
        out[j:k] += a[: k - j]
    return out * 1.5


def sfx_tick():
    t = tvec(0.09)
    w = np.sin(2 * np.pi * 1180 * t) * np.exp(-t * 70) + bandpass(_noise(0.09, 15), 1500, 4000) * np.exp(-t * 120) * 0.3
    return w * 0.4


def sfx_back():
    t = tvec(0.07)
    return np.sin(2 * np.pi * np.cumsum(330 - 600 * t) / SR) * np.exp(-t * 40) * 0.5


def sfx_reward():
    """0.16.1 (V62): cosmético novo — harpa a subir duas oitavas e um acorde de sinos, com brilho por cima."""
    out = np.zeros(int(1.4 * SR))
    notes = [72, 76, 79, 83, 84, 88, 91, 95]
    for i, m in enumerate(notes):
        a = inst_pluck(m, 0.35, 0.55 + 0.04 * i, 0.85)
        j = int(i * 0.045 * SR)
        k = min(len(out), j + len(a))
        out[j:k] += a[: k - j]
    j0 = int(0.42 * SR)
    for m in [84, 88, 91, 96]:
        b = inst_bell(m, 0.9, 0.55, ratio=3.5, index=0.8, decay=3.2)
        k = min(len(out), j0 + len(b))
        out[j0:k] += b[: k - j0] * 0.6
    t = np.arange(len(out)) / SR
    shimmer = highpass(_noise(1.4, 21), 6500) * np.clip((t - 0.38) / 0.08, 0, 1) * np.exp(-np.clip(t - 0.38, 0, None) * 3.2) * 0.08
    return (out + shimmer) * 1.3


SFX = {"draw": sfx_draw, "play": sfx_play, "land": sfx_land, "coin": sfx_coin, "heal": sfx_heal,
       "shield": sfx_shield, "relic": sfx_relic, "victory": sfx_victory, "defeat": sfx_defeat,
       "unlock": sfx_unlock, "boss": sfx_boss, "transform": sfx_transform, "shuffle": sfx_shuffle,
       "keyword": sfx_keyword, "jail": sfx_jail, "channel": sfx_channel, "death": sfx_death,
       "deny": sfx_deny, "level_up": sfx_level_up, "tick": sfx_tick, "back": sfx_back, "reward": sfx_reward}


# --------------------------------------------------------------------------------------------------
# Escrita
# --------------------------------------------------------------------------------------------------

def to_int16(x):
    return (np.clip(x, -1.0, 1.0) * 32767.0).astype(np.int16)


def write_ogg(path, x, quality=2):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        wav = Path(td) / "in.wav"
        wavfile.write(wav, SR, to_int16(x))
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(wav), "-c:a", "libvorbis", "-q:a", str(quality),
                        str(path)], check=True)


def write_sfx(path, x):
    path.parent.mkdir(parents=True, exist_ok=True)
    x = np.asarray(x, dtype=float)
    x = x - np.mean(x)
    peak = np.max(np.abs(x))
    if peak > 0:
        x = x / peak * 0.85
    x = _fades(x, 0.001, 0.006)
    wavfile.write(path, SR, to_int16(x))


def spectrogram_png(x, path, title):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return
    mono = x.mean(axis=1) if x.ndim == 2 else x
    f, t, S = signal.spectrogram(mono, SR, nperseg=1024, noverlap=768)
    fig, ax = plt.subplots(figsize=(12, 3.2), dpi=90)
    ax.pcolormesh(t, f, 10 * np.log10(S + 1e-12), shading="auto", vmin=-110, vmax=-20, cmap="magma")
    ax.set_ylim(0, 8000)
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--music", default=None, help="faixas separadas por vírgulas (omisso = todas)")
    ap.add_argument("--sfx", action="store_true", help="só os efeitos")
    ap.add_argument("--preview", default=None, help="pasta para WAV e espetrogramas de verificação")
    a = ap.parse_args()
    do_music = not a.sfx or a.music is not None
    do_sfx = a.sfx or a.music is None
    prev = Path(a.preview) if a.preview else None
    if prev:
        prev.mkdir(parents=True, exist_ok=True)
    if do_music:
        names = list(SONGS) if not a.music else [n.strip() for n in a.music.split(",") if n.strip()]
        for n in names:
            x = SONGS[n]()
            out = OUT_MUSIC / f"music_{n}.ogg"
            write_ogg(out, x, 1 if n in LOW_QUALITY else 2)
            peak = float(np.max(np.abs(x)))
            rms = float(np.sqrt(np.mean(x ** 2)))
            seam = float(np.max(np.abs(x[0] - x[-1])))
            print(f"música {n}: {len(x) / SR:.1f} s, pico {peak:.2f}, rms {rms:.3f}, salto no loop {seam:.3f}, {out.stat().st_size // 1024} KB")
            if prev:
                wavfile.write(prev / f"music_{n}.wav", SR, to_int16(x))
                spectrogram_png(x, prev / f"music_{n}.png", n)
    if do_sfx:
        for n, fn in SFX.items():
            x = fn()
            out = OUT_SFX / f"{n}.wav"
            write_sfx(out, x)
            if prev:
                spectrogram_png(np.asarray(x, dtype=float), prev / f"sfx_{n}.png", n)
        print(f"efeitos: {len(SFX)} em {OUT_SFX.relative_to(ROOT)}")


if __name__ == "__main__":
    sys.exit(main())
