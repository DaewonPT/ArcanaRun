#!/usr/bin/env python3
"""Escreve os prompts do Gemini (um ficheiro .txt por parte) a partir de tools/art_sheets.json.

Formato "folhas" (0.13.0, igual ao do SCAM Operator): cada imagem é UMA folha com várias ilustrações
numa grelha (células pintadas separadas por margens magenta #FF00FF), com código e nome de ficheiro;
no fim o Gemini junta as imagens da parte num zip. Os fundos são imagens inteiras (FULL IMAGE).
Cada parte tem no máximo 10 imagens (o Gemini só faz 10 de cada vez).

Uso (na raiz do projeto):
    python3 tools/make_art_prompts.py <pasta de saída>
Depois de gerar as imagens: python3 tools/import_art.py <zip ou pasta da parte> [--contact DIR].
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SHEETS = ROOT / "tools" / "art_sheets.json"

ROLE = """ROLE
You are the image generator for an original fantasy card game called Zero-Sum (a mobile deckbuilder where creatures, spells and relics fire one after another in a cascade of Power × Mult). This is part {part} of {total} of the game's illustrations. Write every text reply in short European Portuguese; the images follow this English brief.
If earlier parts were made in this same chat, match their look exactly (same painting style, brushwork, palette and lighting)."""

HOUSE = """HOUSE STYLE "ZERO-SUM" (applies to every image, in every part)
- Painterly digital fantasy illustration, like the art of a premium modern card game: rich saturated colours, dramatic lighting from the top-left, soft visible brushwork, one clear central subject with a strong readable silhouette, simple uncluttered background. Not pixel art, not anime, not photo-realistic, no 3D-render look.
- Colours follow the card's mana: white = ivory, gold, pale sky, sunlight; blue = azure, silver, water, mist; black = violet, sickly green, bone, shadow; red = fire, orange, crimson, embers; green = emerald forest, moss, amber light; colourless = steel, stone, grey, copper and brass. Multicoloured cards blend their colours.
- Everything is ORIGINAL: no characters, creatures, symbols or artwork from Magic: The Gathering or any other game, film or brand, and no real people. Generic fantasy archetypes (goblins, elves, angels, dragons, knights, wizards, golems) are fine.
- Tone: epic and a little playful. Family friendly: no gore, no blood, no nudity.
- Never draw text, letters, numbers, runes that look like writing, signatures, watermarks, frames, borders, card templates or UI inside an image.
- Make every image at the highest resolution you can."""

RULES = """SHEET RULES (every entry marked SHEET)
- One sheet = ONE image with exactly the stated number of columns × rows of cells. All cells have the same size. The numbered items go left to right, top to bottom, one item per cell.
- PAINTED CELLS: every cell is a complete little painting that fills its own cell edge to edge, with its own background. Between the cells and all around the outside of the sheet leave a straight, perfectly flat gutter of solid magenta #FF00FF (about 3% of the image width), so I can cut the cells apart. Nothing crosses a gutter.
- Never use magenta or near-magenta inside a painting (use a warm pink like #FF8FB0 or a purple like #7B2FBE instead).
- No grid lines, no frames, no numbers, no captions. A cell without an item stays solid magenta.
- All the items of a sheet share the same style, scale and lighting and must still read clearly when shrunk to 128 px.
- Use the stated aspect ratio for the whole image; the cells get the shape that results from it.
- Entries marked FULL IMAGE are one single painting edge to edge, without magenta."""

KIND_LINE = {
    "card": "SHEET {cols} columns × {rows} rows of {n} card illustrations, each cell a 16:9 painting. Subject centred with a little empty space around it (the game crops each picture to a wide band).",
    "portrait": "SHEET {cols} columns × {rows} rows of {n} character portraits, each cell a square painting: head-and-shoulders bust, centred, facing the viewer, expressive face, dramatic rim light, simple dark background in the character's colours (the game shows it inside a circle).",
    "relic": "SHEET {cols} columns × {rows} rows of {n} relic icons, each cell a square painting of ONE magical object, centred, on a plain dark softly lit background, like a game inventory icon (the game shows it inside a small circle).",
    "item": "SHEET {cols} columns × {rows} rows of {n} potion and scroll icons, each cell a square painting of ONE item, centred, on a plain dark softly lit background, like a game inventory icon (the game shows it inside a small circle).",
    "background": "FULL IMAGE (not a sheet): one wide atmospheric fantasy environment painting for behind the game board, edge to edge, no characters and no creatures in the foreground, darker and low-contrast in the lower half (the cards sit on top of it).",
    "mapnode": "SHEET {cols} columns × {rows} rows of {n} map location icons, each cell a square painting of ONE place or object, centred and filling about 70% of the cell, on a plain dark softly lit background, like a game map marker (the game shows it inside a round medallion, so keep the subject in the middle).",
    "event": "SHEET {cols} columns × {rows} rows of {n} event scenes, each cell a 16:9 storybook painting of ONE scene or place, readable at a glance, with the main subject in the middle band (the game shows it as a wide banner above the event text).",
}
GROUP_TITLE = {
    "card": "== ILUSTRAÇÕES DAS CARTAS ==",
    "portrait": "== RETRATOS (inimigos, bosses, Némesis e patronos) ==",
    "relic": "== RELÍQUIAS ==",
    "item": "== POÇÕES E PERGAMINHOS ==",
    "background": "== FUNDOS DAS BATALHAS (atos e climas) ==",
    "mapnode": "== ÍCONES DO MAPA (paragens e batalhas) ==",
    "event": "== EVENTOS E PARAGENS DO MAPA ==",
}


def render_part(part, total):
    sheets = part["sheets"]
    first, last = sheets[0]["n"], sheets[-1]["n"]
    out = [f"=== ZERO-SUM · ILUSTRAÇÕES · PARTE {part['part']} DE {total} (folhas #{first} a #{last}) ===", ""]
    out.append(ROLE.format(part=part["part"], total=total))
    out += ["", HOUSE, "", RULES, ""]
    if part.get("reference"):
        out += ["REFERENCE IMAGE", part["reference"], ""]
    else:
        out += ["TEMPLATES", "No templates in this part.", ""]
    n = len(sheets)
    out.append("WHAT TO DO NOW")
    out.append(f"- Start right away, without asking anything: make the {n} images below in order, one image per entry. Never put two entries in one image.")
    out.append(f'- Before each image write ONE line, for example: "Folha {first} · {sheets[0]["code"]} · guardar como {sheets[0]["file"]}". Then the image, and nothing else.')
    out.append("- Never ask me for confirmation. If you cannot draw something, draw the nearest harmless version and say so in one short line.")
    out.append(f"- When the {n} images are done, create ONE downloadable zip named ZeroSum_arte_parte_{part['part']:02d}.zip with these {n} images (original quality, with the file names above) and a text file lista.txt (code, file name). If you cannot, write exactly \"NÃO CONSIGO ZIP\".")
    out.append("- Every image must come from your image generator. Never draw or fake images with code, never use placeholders.")
    out += ["", f"THE ENTRIES OF THIS PART ({n}, in this order)"]
    kind = None
    for s in sheets:
        if s["kind"] != kind:
            kind = s["kind"]
            out += ["", GROUP_TITLE[kind]]
        out.append("")
        out.append(f"#{s['n']} · {s['code']} · file {s['file']} · aspect {s['aspect']}")
        out.append(KIND_LINE[kind].format(cols=s["cols"], rows=s["rows"], n=len(s["ids"])))
        if s.get("note"):
            out.append(s["note"])
        if kind == "background":
            out.append(s["desc"][0])
        else:
            for i, d in enumerate(s["desc"], 1):
                out.append(f"{i}) {d}")
    out += ["", f"=== END OF PART {part['part']} === Start now with entry #{first}."]
    return "\n".join(out) + "\n"


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    dest = Path(sys.argv[1])
    dest.mkdir(parents=True, exist_ok=True)
    data = json.loads(SHEETS.read_text(encoding="utf-8"))
    total = len(data["parts"])
    for part in data["parts"]:
        path = dest / f"ZeroSum_Gemini_parte_{part['part']:02d}.txt"
        path.write_text(render_part(part, total), encoding="utf-8")
        print(path, len(part["sheets"]), "imagens")


if __name__ == "__main__":
    main()
