# -*- coding: utf-8 -*-
"""Traduções para inglês da 0.16.1 (importado por tools/make_en_json.py, depois do en_0160).

CODE: textos da interface (chave = o texto em português, como no código).
EXTRA: textos dos dados novos da 0.16.1 (conquista das costas holográficas, Novidades).
"""

CODE = {
    # Coleção: separadores, etiquetas e painel (V49, V51, V13, 53)
    "GALERIA": "GALLERY",
    "COSMÉTICOS": "COSMETICS",
    "Comuns": "Common",
    "Incomuns": "Uncommon",
    "Raras": "Rare",
    "Lendárias": "Legendary",
    "De boss": "Boss",
    "Bênçãos": "Blessings",
    "Todos": "All",
    "Bosses": "Bosses",
    "Lugares": "Places",
    "Costas": "Backs",
    "Molduras": "Frames",
    "Tapetes": "Mats",
    "Efeitos": "Effects",
    "Toca numa relíquia para a ver aqui ao lado.": "Tap a relic to see it here on the side.",
    "Desbloqueia-se com a conquista «%s»: %s": "Unlocked by the achievement “%s”: %s",
    "Dá-ta o Santuário, uma paragem do mapa.": "The Sanctuary, a map stop, gives it to you.",
    "Vem no Baú de Espólio, depois de venceres um boss.": "Comes in the Spoils Chest after you beat a boss.",
    "Vende-a o Mercador Cego.": "The Blind Merchant sells it.",
    "Aparece nas lojas e noutros prémios da run.": "Shows up in shops and other run rewards.",
    "As que ainda não descobriste aparecem com «?». Toca numa e depois em «SÓ A ARTE» para a ver em grande.":
        "The ones you haven't found yet show a “?”. Tap one, then “ART ONLY” to see it large.",
    "Ainda por descobrir: aparece aqui quando a encontrares numa run.": "Not found yet: it shows up here once you meet it in a run.",
    "Eternidade": "Eternity",
    "Clima planar": "Planar climate",
    "Paragem do mapa": "Map stop",
    "Loja do Mercador": "Merchant's Shop",
    "Tenda do Mercador Cego": "Blind Merchant's Tent",
    "SÓ A ARTE": "ART ONLY",
    "Os cosméticos só mudam o aspeto. Toca num para ver como se ganha; USAR escolhe-o.": "Cosmetics only change the look. Tap one to see how to earn it; USE picks it.",
    "Costas do baralho": "Deck back",
    "Em uso": "In use",
    "EM USO": "IN USE",
    "Desbloqueado": "Unlocked",
    # Origem dos cosméticos
    "Tens desde o início.": "You have it from the start.",
    "Descobre todas as cartas brancas na Coleção.": "Discover every white card in the Collection.",
    "Descobre todas as cartas azuis na Coleção.": "Discover every blue card in the Collection.",
    "Descobre todas as cartas pretas na Coleção.": "Discover every black card in the Collection.",
    "Descobre todas as cartas vermelhas na Coleção.": "Discover every red card in the Collection.",
    "Descobre todas as cartas verdes na Coleção.": "Discover every green card in the Collection.",
    "Leva o baralho «%s» ao nível %d.": "Take the “%s” deck to level %d.",
    "Conquista «%s»: %s": "Achievement “%s”: %s",
    "História: vence o capítulo «%s».": "Story: beat the chapter “%s”.",
    "Chega ao ante %d no Infinito.": "Reach ante %d in Endless.",
    # Costas por baralho (V12) e aviso de cosmético novo (V62)
    "padrão": "default",
    "Costas: %s": "Back: %s",
    "Toca para escolher as costas deste baralho (o grimório, a troca de ecrã e a loja).": "Tap to choose this deck's card back (library, screen changes and shop).",
    "Novas costas de carta!": "New card back!",
    "Nova moldura!": "New frame!",
    "Novo tapete da Arena!": "New Arena mat!",
    "Novo efeito do golpe!": "New finishing effect!",
    "Escolhe-o na Coleção → Cosméticos.": "Pick it in Collection → Cosmetics.",
    # Talentos em árvore (V53)
    "%d pontos": "%d points",
    "NÍVEL %d": "TIER %d",
    "NÍVEL %d · %d pontos neste ramo": "TIER %d · %d points in this branch",
    "Níveis: %s": "Levels: %s",
    "(no máximo)": "(maxed)",
    # Estatísticas (V54–V56)
    "Resumo por baralho": "Summary by deck",
    "melhor ante": "best ante",
    "vitórias": "wins",
    "Histórico": "History",
    "VER TODAS": "SEE ALL",
    "Números": "Numbers",
    "Ainda não acabaste nenhuma run.": "You haven't finished a run yet.",
    "Derrota no ante %d": "Defeat at ante %d",
    "maior golpe %s": "biggest hit %s",
    "Todas %d": "All %d",
    "Ganhas %d": "Earned %d",
    "Por ganhar %d": "To earn %d",
    "Progresso: %s/%s": "Progress: %s/%s",
    "Toca numa medalha para ver como se ganha e o que dá. As de contagem mostram quanto falta.":
        "Tap a medal to see how to earn it and what it gives. Counting ones show how much is left.",
}

EXTRA = {
    # V10: a conquista das costas holográficas.
    "Pesadelo Selado": "Sealed Nightmare",
    "Vence uma run no Pesadelo com o Selo Planar 8.": "Win a run on Nightmare with Planar Seal 8.",
    # Novidades da 0.16.1 (data/news.json)
    "Novidades da 0.16.1": "What's new in 0.16.1",
    "Coleção nova: cartas com ilustrações, relíquias, Bestiário, Galeria e Cosméticos, com um painel ao lado.":
        "New Collection: illustrated cards, relics, Bestiary, Gallery and Cosmetics, with a side panel.",
    "Galeria das ilustrações que descobriste e o botão «SÓ A ARTE», também na carta em grande.":
        "A gallery of the illustrations you've found and an “ART ONLY” button, also on the large card.",
    "Costas de cada baralho (no nível 4) e costas holográficas para quem vencer o Pesadelo com o Selo 8.":
        "A card back for each deck (at level 4) and a holographic back for beating Nightmare on Seal 8.",
    "Escolhe umas costas para cada baralho, na Campanha e no Construtor.":
        "Pick a card back for each deck, in the Campaign and the Deck Builder.",
    "Talentos em árvore, conquistas em medalhas e Estatísticas com gráfico e histórico.":
        "Talents as a tree, achievements as medals and Statistics with a chart and history.",
    "Construtor com ilustrações e o baralho em tiras.":
        "Deck Builder with illustrations and your deck in strips.",
    "Abertura animada, céu do menu conforme a hora, míticas com a arte viva e mapa que se desenha.":
        "Animated opening, a menu sky that follows the time of day, living art on mythics and a map that draws itself.",
    "A troca de ecrã muda com o destino e há um aviso próprio para os cosméticos novos.":
        "Screen changes depend on where you're going, and new cosmetics get their own notice.",
}


def build_data(root):
    """Pares {português: inglês} dos textos dos dados novos."""
    return dict(EXTRA)
