# -*- coding: utf-8 -*-
"""Traduções para inglês da 0.14.1 (importado por tools/make_en_json.py, depois do en_0140).

CODE: textos da interface (chave = o texto em português, como no código).
EXTRA: textos soltos dos dados que não têm id próprio (Novidades).
"""

CODE = {}

EXTRA = {
    "Novidades da 0.14.1": "What's new in 0.14.1",
    "Cartas com o visual «Arte em destaque»: a ilustração ocupa a parte de cima da carta, com o nome por cima.": "Cards with the «Art in focus» look: the illustration fills the top of the card, with the name over it.",
    "Custo numa esfera com brilho e tipo numa pílula colorida, com o losango da raridade.": "Cost in a glowing orb and type in a coloured pill, with the rarity diamond.",
    "Poder numa pílula azul e Vida numa pílula vermelha; o texto da carta fica centrado.": "Power in a blue pill and Life in a red pill; the card text is centred.",
    "A carta em grande tem o mesmo visual.": "The enlarged card has the same look.",
    "Sem ilustrações (Coleção, Construtor), o sigilo da carta fica no lugar da arte.": "Without illustrations (Collection, Deck Builder), the card's sigil takes the place of the art.",
    "As cartas pesam menos: a batalha desenha cerca de um quarto menos em cada frame.": "Cards are lighter: the battle draws about a quarter less each frame.",
}


def build_data(root):
    """Pares {português: inglês} dos textos soltos (Novidades)."""
    return dict(EXTRA)
