# -*- coding: utf-8 -*-
"""Traduções para inglês da 0.20.0 «Sem armadilhas» (importado por tools/make_en_json.py, depois do en_0190).

CODE: textos da interface (chave = o texto em português, como no código).
EXTRA: textos soltos que não estão em nenhum tr("…") literal (constantes, _t("…"), howto.json).
TIPS: dicas novas de data/tips.json (id → inglês).
"""
import json
import os

CODE = {
    # Construtor: «por guardar» (A3) e o resumo (E16).
    "• por guardar": "• unsaved",
    "GUARDAR AS ALTERAÇÕES?": "SAVE CHANGES?",
    "NÃO GUARDAR": "DON'T SAVE",
    "SAIR SEM GUARDAR": "LEAVE WITHOUT SAVING",
    "MUDAR SEM GUARDAR": "SWITCH WITHOUT SAVING",
    "%d criaturas · %d feitiços · %d terrenos · %d outros · cores: %s": "%d creatures · %d spells · %d lands · %d others · colours: %s",
    # Tarefa 4 (A4): sair do Arena Draft
    "SAIR DO DRAFT?": "QUIT THE DRAFT?",
    "Perdes a carta escolhida.": "You lose the card you picked.",
    "Perdes as %d cartas escolhidas.": "You lose the %d cards you picked.",
    "FICAR": "STAY",
}

# B7: o último turno e o ATACAR que diz a verdade.
CODE.update({
    "ÚLTIMO TURNO": "LAST TURN",
    "NÃO CHEGA": "NOT ENOUGH",
    "MORRES": "YOU DIE",
    "toca outra vez para atacar": "tap again to attack",
    "segura outra vez para atacar": "hold again to attack",
    "Este ataque não chega: perdes a run.": "This attack isn't enough: you lose the run.",
    "Este contra-ataque mata-te: perdes a run.": "This counterattack kills you: you lose the run.",
    "Ainda tens por usar: %s.": "You still have: %s.",
    "%d canalização": "%d channel",
    "%d canalizações": "%d channels",
    "+%d fragmento para cosméticos.": "+%d fragment for cosmetics.",
    "Tens %d fragmento. Ganham-se nas runs: 1 por ante (+5 se venceres).": "You have %d fragment. Earned in runs: 1 per ante (+5 if you win).",
    "o patrono": "your patron",
})

# B9: a causa da derrota (2.ª linha do letreiro e início do detalhe do RunOver)
CODE.update({
    "Os turnos acabaram · faltaram %s": "Out of turns · %s short",
    "Ficaste sem vida": "You ran out of life",
})

# C11: avisos de progresso fora do caminho
CODE.update({
    "Também ganhaste:": "You also earned:",
    "… e mais %d nos AVISOS (o sino).": "… and %d more in NOTICES (the bell).",
    "%d avisos no sino (AVISOS).": "%d notices in the bell (NOTICES).",
})

# Revisão final: LIMPAR no Construtor com alterações por guardar.
CODE.update({
    "LIMPAR O BARALHO?": "CLEAR THE DECK?",
    "Perdes as alterações que não guardaste.": "You lose the changes you haven't saved.",
})

CODE.update({
    # D12: tutorial do Poder × Mult
    "Se a mão não te agradar, MULLIGAN dá-te uma mão nova (uma carta vai para o fundo). Só no turno 1, antes de jogares.": "If you don't like your hand, MULLIGAN gives you a new one (one card goes to the bottom). Only on turn 1, before you play.",
    "Tens %d turnos para o derrotar.": "You have %d turns to defeat it.",
    "O Poder soma-se e o Mult multiplica. O Mult vem das cartas, das relíquias e das FORMAÇÕES, que são combinações de cartas na Arena. A ordem na Arena conta: arrasta para trocar.": "Power adds up and Mult multiplies. Mult comes from cards, relics and FORMATIONS, which are card combinations in the Arena. The order in the Arena matters: drag to swap.",
    "CANALIZAR: liga o botão e toca numa carta da mão para a trocar por outra. Tens %d por batalha.": "CHANNEL: switch the button on and tap a card in hand to swap it for another. You have %d per battle.",
    "Feitiços com ↺ lançam-se do CEMITÉRIO uma segunda vez. Depois da batalha escolhes o caminho no mapa. Boa sorte.": "Spells with ↺ can be cast from the GRAVEYARD a second time. After the battle you choose your path on the map. Good luck.",
})

EXTRA = {
    # D13 e E19
    "Letras maiores nas cartas e nos menus.": "Bigger letters on cards and in menus.",
    "«O boss ruge», «Relíquia dispara»… do lado direito do ecrã, para quem joga sem som.": "«The boss roars», «Relic fires»… on the right of the screen, for those playing without sound.",
}

TIPS = {
    "formation": "Formations: card combinations in the Arena (2 creatures with the same cost, 3 or more attacking…) add extra Mult. The name shows in the attack calculation.",
}

# --- 0.20.0: lançamento (Novidades, data/news.json) ---
EXTRA.update({
    "Novidades da 0.20.0": "What's new in 0.20.0",
    "Último turno à vista: o ATACAR avisa quando o ataque não chega ou quando o contra-ataque te mata, e numa run pede um 2.º toque.":
        "Last turn in sight: ATTACK warns when the attack falls short or when the counterattack would kill you, and in a run it asks for a second tap.",
    "A derrota diz porquê: os turnos acabaram (e quanto faltou) ou ficaste sem vida.":
        "Defeat tells you why: you ran out of turns (and how much was missing) or out of life.",
    "Segurar num botão para ler a explicação já não carrega nele.": "Holding a button to read its explanation no longer presses it.",
    "Nada se perde sem querer: o Construtor e a Arena Draft perguntam antes de sair, e o Reforço tem VOLTAR.":
        "Nothing gets lost by accident: the Deck Builder and Arena Draft ask before leaving, and Boost has BACK.",
    "Conquistas e desbloqueios já não tapam a batalha: aparecem com as recompensas.":
        "Achievements and unlocks no longer cover the battle: they show up with the rewards.",
    "O tutorial da 1.ª batalha explica o MULLIGAN e o Poder × Mult, com as formações.":
        "The first battle's tutorial explains MULLIGAN and Power × Mult, with formations.",
    "O Texto maior também aumenta os menus, o mapa e a loja.": "Bigger text now also enlarges the menus, the map and the shop.",
})


def _load(root, name):
    path = os.path.join(root, "data", name)
    return json.load(open(path, encoding="utf-8")) if os.path.exists(path) else []


def build_data(root):
    """Pares {português: inglês} das dicas novas (pelo id) e os de EXTRA."""
    out = {}
    for tip in _load(root, "tips.json"):
        en = TIPS.get(str(tip.get("id", "")))
        if en and tip.get("text"):
            out[tip["text"]] = en
    out.update(EXTRA)
    return out
