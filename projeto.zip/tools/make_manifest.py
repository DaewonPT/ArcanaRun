#!/usr/bin/env python3
"""Gera o pacote de atualização de conteúdo (sem APK novo):

    python3 tools/make_manifest.py --key /caminho/zerosum-atualizacoes-privada.pem \
        --version 2 --min-app 7 --out /caminho/pub \
        --note-pt "Equilíbrio: Izzet mais forte" --note-en "Balance: Izzet buffed"

Escreve em --out:  versao.txt (manifesto assinado), f/<sha256> (ficheiros), .nojekyll
Os ficheiros abrangidos são os JSON de data/ e i18n/ (nunca código). O jogo (ContentUpdate.gd)
lê https://daewonpt.github.io/zerosum-updates/versao.txt, verifica a assinatura ECDSA P-256 /
SHA-256 com a chave pública embutida e descarrega só o que mudou.

Formato do manifesto (linhas):
    ZSUPD 1
    c <versão do conteúdo, inteiro crescente>
    min <versionCode mínimo da app>
    n pt <nota>            n en <nota>
    f <sha256> <tamanho> <caminho relativo, p.ex. data/cards.json>
    sig <assinatura base64 DER sobre todas as linhas anteriores unidas por \\n, com \\n final>
"""
import argparse
import base64
import hashlib
import os
import shutil

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILES = [
    "data/cards.json", "data/cards_en.json", "data/decks.json", "data/relics.json", "data/formations.json",
    "data/enemies.json", "data/campaign.json", "data/events.json", "data/achievements.json",
    "data/seals.json", "data/planeswalkers.json", "data/puzzles.json",
    "data/climates.json", "data/contracts.json", "data/acts.json",
    "data/tribes.json", "data/vouchers.json", "data/challenges.json", "data/nemesis.json",
    "data/saga.json", "data/cosmetics.json", "data/glossary.json", "data/news.json",
    "data/tips.json", "data/lessons.json", "data/talents.json",
    "i18n/en.json", "i18n/howto.json",
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--key", required=True, help="chave privada PEM (fica com o Paulo, nunca no projeto)")
    ap.add_argument("--version", type=int, required=True, help="versão do conteúdo (c)")
    ap.add_argument("--min-app", type=int, default=14, help="versionCode mínimo da app")
    ap.add_argument("--out", required=True, help="pasta de saída (vai para o repositório zerosum-updates)")
    ap.add_argument("--note-pt", default="")
    ap.add_argument("--note-en", default="")
    args = ap.parse_args()

    with open(args.key, "rb") as f:
        key = serialization.load_pem_private_key(f.read(), password=None)
    os.makedirs(os.path.join(args.out, "f"), exist_ok=True)
    lines = ["ZSUPD 1", "c %d" % args.version, "min %d" % args.min_app]
    if args.note_pt:
        lines.append("n pt " + args.note_pt.replace("\n", " "))
    if args.note_en:
        lines.append("n en " + args.note_en.replace("\n", " "))
    for rel in FILES:
        path = os.path.join(ROOT, rel)
        if not os.path.exists(path):
            continue
        data = open(path, "rb").read()
        digest = hashlib.sha256(data).hexdigest()
        shutil.copyfile(path, os.path.join(args.out, "f", digest))
        lines.append("f %s %d %s" % (digest, len(data), rel))
    body = "\n".join(lines) + "\n"
    sig = key.sign(body.encode("utf-8"), ec.ECDSA(hashes.SHA256()))
    manifest = body + "sig " + base64.b64encode(sig).decode("ascii") + "\n"
    with open(os.path.join(args.out, "versao.txt"), "w", encoding="utf-8") as f:
        f.write(manifest)
    open(os.path.join(args.out, ".nojekyll"), "w").close()
    print(manifest)
    print("pasta pronta:", args.out)


if __name__ == "__main__":
    main()
