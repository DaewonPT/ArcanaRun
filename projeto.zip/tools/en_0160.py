# -*- coding: utf-8 -*-
"""Traduções para inglês da 0.16.0 (importado por tools/make_en_json.py, depois do en_0150).

CODE: textos da interface (chave = o texto em português, como no código).
EXTRA: textos dos dados novos da 0.16.0 (frases dos mercadores, dica do letal, Novidades).
"""

CODE = {
    # Loja (V14–V27)
    "COMPRAR": "BUY",
    "VENDER": "SELL",
    "VENDIDO": "SOLD",
    "VALE": "VOUCHER",
    "NÃO SE VENDE": "CAN'T SELL",
    "FICAR COM ESTA": "TAKE THIS ONE",
    "BOOSTER — escolhe 1 de 3": "BOOSTER — pick 1 of 3",
    "Toca numa carta para a escolher (manter o dedo: ver em grande).": "Tap a card to pick it (hold to see it large).",
    "Booster · 1 de 3": "Booster · 1 of 3",
    "Booster aberto": "Booster opened",
    "Novas ofertas": "New offers",
    "Curar %d": "Heal %d",
    "Vida máxima +%d": "Max life +%d",
    "Melhorar uma carta": "Upgrade a card",
    "Carta melhorada": "Card upgraded",
    "Remover uma carta": "Remove a card",
    "Carta removida": "Card removed",
    "Selar uma carta": "Seal a card",
    "Carta selada": "Card sealed",
    "Ver baralho": "View deck",
    "Poções %d/%d": "Potions %d/%d",
    "Sobe 1 nível a uma formação à tua escolha.": "Raises a formation of your choice by 1 level.",
    "Usa-se no mapa.": "Used on the map.",
    "Usa-se na batalha.": "Used in battle.",
    "+%d juros": "+%d interest",
    "Ouro. Juros: 1 ouro por cada 5 guardados ao entrar na loja (máx. %d).": "Gold. Interest: 1 gold for every 5 you hold when you enter the shop (max. %d).",
    "Sair para o menu (a loja fica gravada tal como está)": "Exit to the menu (the shop is saved just as it is)",
    "Mercador": "Merchant",
    "«%s»": "“%s”",
    # Batalha
    "faltam %d": "%d to go",
    "Fechar": "Close",
    "Letal": "Lethal",
    "Ordenar a mão: %s": "Sort hand: %s",
    "Grimório": "Library",
    "Outras": "Other",
    # Ecrã de recompensas (V38)
    "Vitória": "Victory",
    "Excesso do golpe final": "Final blow overkill",
    "Turnos que sobraram": "Turns left over",
    "Relíquias recuperadas": "Relics recovered",
    "Afixos da Elite": "Elite affixes",
    "Jogada perfeita": "Perfect play",
    "Elite sem lugar para relíquia": "Elite with no room for a relic",
    "Relíquias, Vales e contratos": "Relics, Vouchers and contracts",
    # Pausa (V47)
    "Pausa": "Pause",
    "Ante %d de %d": "Ante %d of %d",
    # Telemóveis lentos (82)
    "O jogo está lento neste telemóvel": "The game is running slowly on this phone",
    "O modo de desempenho tira alguns efeitos e fixa o jogo a 30 FPS: fica mais fluido e gasta menos bateria. Podes mudar isto nas Configurações.":
        "Performance mode removes some effects and locks the game at 30 FPS: it runs smoother and uses less battery. You can change this in Settings.",
    "LIGAR": "TURN ON",
    "AGORA NÃO": "NOT NOW",
    "Modo de desempenho ligado": "Performance mode on",
}

EXTRA = {
    # O que os mercadores dizem (data/shop_lines.json)
    "Entra, entra! Hoje há coisas que não vais ver em mais lado nenhum.": "Come in, come in! Today I've got things you won't see anywhere else.",
    "Ah, um cliente com cara de quem vai ganhar. Vê à vontade.": "Ah, a customer with a winner's face. Take a look around.",
    "Cada carta aqui já mudou o destino de alguém. Escolhe bem.": "Every card here has changed someone's fate. Choose well.",
    "Fresquinho da caravana! Ainda cheira a pó de estrada.": "Fresh off the caravan! It still smells of road dust.",
    "Olho de entendido! Essa guardava-a para um rei.": "A connoisseur's eye! I was saving that one for a king.",
    "Ah… essa vai fazer estragos. Do bom tipo.": "Ah… that one will do some damage. The good kind.",
    "Boa escolha. Não digas a ninguém que ma levaste tão barata.": "Good choice. Don't tell anyone you got it this cheap.",
    "Mais? Deixa-me ir lá atrás buscar a caixa boa.": "More? Let me fetch the good box from the back.",
    "Exigente! Gosto disso. Vamos ver o que há no fundo do baú.": "Picky! I like that. Let's see what's at the bottom of the chest.",
    "Ofertas novas, acabadinhas de chegar.": "New offers, fresh off the cart.",
    "Já? Nem um amuleto para dar sorte?": "Already? Not even a lucky charm?",
    "Volta quando o ouro te pesar no bolso.": "Come back when the gold weighs down your pocket.",
    "A caravana espera. As ofertas, essas, não.": "The caravan will wait. The offers won't.",
    "Sinto o teu ouro antes de ouvir os teus passos.": "I sense your gold before I hear your steps.",
    "Não preciso de ver para saber o que procuras.": "I don't need to see to know what you're looking for.",
    "As relíquias daqui escolhem o dono. Deixa-as escolher-te.": "The relics here choose their owner. Let them choose you.",
    "Essa já te esperava há muito tempo.": "That one has been waiting for you for a long time.",
    "Sinto-a acordar na tua mão. Cuida dela.": "I can feel it waking in your hand. Look after it.",
    "Bom. O teu caminho acabou de mudar.": "Good. Your path has just changed.",
    "O que é para ti não muda por pedires outra vez.": "What is meant for you doesn't change because you ask again.",
    "O destino não se compra. Mas aluga-se.": "Fate can't be bought. But it can be rented.",
    "Vais voltar. Os que saem de mãos vazias voltam sempre.": "You'll be back. Those who leave empty-handed always come back.",
    "Vai. Eu fico a ouvir o teu ouro a afastar-se.": "Go. I'll stay and listen to your gold walking away.",
    # Dica (data/tips.json)
    "Contorno dourado a pulsar numa carta da mão: jogá-la chega para derrotar o inimigo neste turno.":
        "A pulsing gold outline on a card in your hand: playing it is enough to defeat the enemy this turn.",
    # Novidades da 0.16.0 (data/news.json)
    "Novidades da 0.16.0": "What's new in 0.16.0",
    "Loja nova: cartas a sério com preço, relíquias em medalhões, um booster que se abre e ofertas que se viram.":
        "New shop: real cards with price tags, relics in medallions, a booster you tear open and offers that flip over.",
    "O Mercador e o Mercador Cego têm cara e falam contigo; MENU na loja para sair sem perder nada.":
        "The Merchant and the Blind Merchant have faces and talk to you; MENU in the shop to leave without losing anything.",
    "Batalha mais viva: câmara na cascata, letreiros em faixa de luz, setas de sinergia, brilho de letal e ecrã de recompensas.":
        "A livelier battle: camera on the cascade, light-band banners, synergy arrows, a lethal glow and a rewards screen.",
    "Bosses com três caras (normal, ferido e zangado) e ilustrações nos eventos e paragens.":
        "Bosses with three faces (normal, hurt and angry) and illustrations for events and stops.",
    "Cemitério e grimório em pilha, feitiços em miniatura, lugares na Arena e a Cadeia em elos.":
        "Graveyard and library as piles, spells as miniatures, slots on the board and the Chain as links.",
    "Janelas novas para relíquias, patronos e climas; pausa com resumo e listas de cartas com separadores.":
        "New windows for relics, patrons and climates; a pause screen with a summary and card lists with tabs.",
    "Ícones próprios em todo o jogo e botões que respondem ao toque.": "Custom icons across the game and buttons that react to your touch.",
    "Mais leve no telemóvel; num telemóvel lento, o jogo sugere o modo de desempenho.":
        "Lighter on your phone; on a slow phone, the game suggests performance mode.",
}


def build_data(root):
    """Pares {português: inglês} dos textos dos dados novos."""
    return dict(EXTRA)
