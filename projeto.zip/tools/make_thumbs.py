#!/usr/bin/env python3
"""0.16.1 (76): miniaturas com mipmaps.

- Cartas: assets/art/cards/<id>.webp (512×288) → assets/art/cards_256/<id>.webp (256×144), para a mão, a
  Coleção e o Construtor (a de 512×288 fica para a carta em grande). Gastam um quarto da memória e,
  pequenas, ficam mais limpas (o Godot escolhe o nível do mipmap em vez de saltar píxeis).
- Lugares, para a Galeria da Coleção: os fundos (assets/art/backgrounds, 1280×720) e as imagens dos eventos
  (assets/art/events, 640×360) → assets/art/places_320/ a 320×180 (os eventos com o prefixo "ev_").

Cada miniatura leva um .import que liga os mipmaps (o Godot completa o resto ao importar). Só refaz as que
faltam ou estão mais velhas do que a original, e apaga as que já não têm original.
Corre-se depois de importar ilustrações novas.

Uso (na raiz do projeto):  python3 tools/make_thumbs.py [--all]
"""
import argparse
import sys
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
ART = ROOT / "assets" / "art"
# (pasta de origem, pasta das miniaturas, tamanho, prefixo do nome)
JOBS = [
    ("cards", "cards_256", (256, 144), ""),
    ("backgrounds", "places_320", (320, 180), ""),
    ("events", "places_320", (320, 180), "ev_"),
]
# Mantido para quem já usava estes nomes (testes e ferramentas antigas).
SRC = ART / "cards"
DST = ART / "cards_256"
QUALITY = 84
IMPORT = """[remap]

importer="texture"
type="CompressedTexture2D"

[deps]

source_file="res://assets/art/{folder}/{name}"

[params]

compress/mode=1
compress/high_quality=false
compress/lossy_quality=0.8
compress/hdr_compression=1
compress/normal_map=0
compress/channel_pack=0
mipmaps/generate=true
mipmaps/limit=-1
roughness/mode=0
roughness/src_normal=""
process/fix_alpha_border=true
process/premult_alpha=false
process/normal_map_invert_y=false
process/hdr_as_srgb=false
process/hdr_clamp_exposure=false
process/size_limit=0
detect_3d/compress_to=1
"""


def _job(src_dir, dst_dir, size, prefix, all_):
    src_root = ART / src_dir
    dst_root = ART / dst_dir
    dst_root.mkdir(parents=True, exist_ok=True)
    made = 0
    wanted = set()
    for src in sorted(src_root.glob("*.webp")):
        name = prefix + src.name
        wanted.add(name)
        out = dst_root / name
        imp = dst_root / (name + ".import")
        if all_ or not out.exists() or out.stat().st_mtime < src.stat().st_mtime:
            img = Image.open(src).convert("RGB").resize(size, Image.LANCZOS)
            img.save(out, "WEBP", quality=QUALITY, method=6)
            made += 1
        if not imp.exists():
            imp.write_text(IMPORT.format(folder=dst_dir, name=name), encoding="utf-8")
    return made, wanted


def make(all_=False):
    made = 0
    wanted_by_dir = {}
    for src_dir, dst_dir, size, prefix in JOBS:
        n, wanted = _job(src_dir, dst_dir, size, prefix, all_)
        made += n
        wanted_by_dir.setdefault(dst_dir, set()).update(wanted)
    # Miniaturas cuja ilustração já não existe.
    for dst_dir, wanted in wanted_by_dir.items():
        for old in (ART / dst_dir).glob("*.webp"):
            if old.name not in wanted:
                old.unlink()
                Path(str(old) + ".import").unlink(missing_ok=True)
    return made


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--all", action="store_true", help="refaz todas")
    a = ap.parse_args()
    n = make(a.all)
    for dst_dir in sorted({j[1] for j in JOBS}):
        print(f"{dst_dir}: {len(list((ART / dst_dir).glob('*.webp')))} miniaturas")
    print(f"{n} novas.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
