#!/usr/bin/env python3
"""Converte a base de dados de 300 cartas (Mana Cascade) para o formato do Zero-Sum.

Saídas: data/cards.json, data/decks.json e um relatório de cobertura no stdout.
Os efeitos são mapeados por regras (regex) para a DSL do EffectResolver; o que não
se percebe fica registado em "approx_notes" e a carta marcada "approx": true.
"""
import json, re, sys, collections, unicodedata

import os
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'mana_cascade_300.txt')   # documento original (282 cartas) + as 18 finais
OUT_DIR = os.path.join(HERE, '..', 'data')

txt = open(SRC, encoding='utf-8').read()

# ----------------------------------------------------------------------------
# Baralhos (matriz do documento)
# ----------------------------------------------------------------------------
DECKS = [
 (1,"Centelha Rubra","R",8,"Blitz de custo 1 e reciclagem rápida do grimório",1),
 (2,"Paradoxo Cronomante","U",9,"Cantrips (compra de cartas) e acumulação de feitiços",4),
 (3,"Pacto Abissal","B",10,"Sacrifica descartes por ×Mult brutal",2),
 (4,"Semente Primordial","G",11,"Crescimento permanente de Poder ao longo da run",1),
 (5,"Falange Solar","W",12,"Bando Tribal: enxame de criaturas",1),
 (6,"Senado Azorius","W/U",13,"Retenção na mão: bónus por cartas não jogadas",3),
 (7,"Cabala Dimir","U/B",14,"Auto-mill: topo do grimório para o cemitério",4),
 (8,"Carnaval Rakdos","B/R",15,"Hellbent (mão vazia) e destruição de cartas",3),
 (9,"Clã Gruul","R/G",16,"Fúria colossal: custos 4 e 5 e tríades",2),
 (10,"Conclave Selesnya","G/W",17,"Pactos duais (pares) e terrenos vivos",2),
 (11,"Sindicato Orzhov","W/B",18,"Economia de sangue: Mult pelo ouro acumulado",3),
 (12,"Liga Izzet","U/R",19,"Tempestade Arcana: feitiços em cadeia",4),
 (13,"Enxame Golgari","B/G",20,"Motor de cemitério: canalizar dá Poder e Mult",3),
 (14,"Legião Boros","R/W",21,"Posicionamento: 1.ª e 5.ª carta ativam várias vezes",2),
 (15,"Biomancia Simic","G/U",22,"Mutação de curva: custos para forçar Curva 1-5",4),
 (16,"Trono de Grixis","U/B/R",24,"Maldições tricolor: mais forte com o inimigo ferido",4),
 (17,"Forja de Urza","CL/LD",25,"Afinidade de artefactos e terrenos na mão",5),
 (18,"Convergência Planar","WUBRG",26,"Domínio das 5 cores: Convergência WUBRG",5),
]
deck_ranges = []
start = 1
for d in DECKS:
    deck_ranges.append((d[0], start, start + d[3] - 1))
    start += d[3]
assert start - 1 == 300, start

def deck_of(num):
    for did, a, b in deck_ranges:
        if a <= num <= b:
            return did
    raise ValueError(num)

# ----------------------------------------------------------------------------
# Parse das cartas
# ----------------------------------------------------------------------------
pat = re.compile(r'^\s*\d+\.\s*#(\d{3})\s*\|\s*(.+?)\s*\|\s*(.+?)\s*\|\s*(CR|SP|MG|LD)\s*\|\s*Custo\s*(\d)\s*\|\s*(\d+)\s*Pod\s*\|\s*(.*?)\s*$', re.M)
raw = {}
for m in pat.findall(txt):
    num = int(m[0])
    raw[num] = dict(num=num, name=re.sub(r'\s+', ' ', m[1]).strip(), colorcode=m[2].strip(), tcode=m[3],
                    cost=int(m[4]), power=int(m[5]), text=m[6].strip())
assert len(raw) == 300, len(raw)

COLOR = {'W': 'white', 'U': 'blue', 'B': 'black', 'R': 'red', 'G': 'green'}
def colors_of(code):
    code = code.strip()
    if code in ('MC', 'WUBRG'):
        return ['white', 'blue', 'black', 'red', 'green']
    if code in ('CL', 'LD'):
        return []
    out = []
    for part in code.split('/'):
        part = part.strip()
        if part in COLOR:
            out.append(COLOR[part])
    return out

TYPE = {'CR': 'creature', 'SP': 'spell', 'MG': 'spell', 'LD': 'land'}
SUBTYPE = {'CR': '', 'SP': 'sorcery', 'MG': 'instant', 'LD': ''}

# ----------------------------------------------------------------------------
# Mapeamento de texto → efeitos
# ----------------------------------------------------------------------------
COLOR_WORDS = {
    'vermelh': 'red', 'azu': 'blue', 'pret': 'black', 'verde': 'green', 'branc': 'white',
}
def color_from_word(s):
    s = s.lower()
    for k, v in COLOR_WORDS.items():
        if k in s:
            return v
    return None

def num(s):
    return float(s.replace(',', '.'))

def parse_filter(desc):
    """desc: fragmento tipo 'carta Vermelha', 'Criatura Verde', 'Feitiço', 'carta de Custo 1', 'Terreno (LD)'."""
    f = {}
    d = desc.lower()
    c = color_from_word(d)
    if c:
        f['color'] = c
    if 'criatura' in d:
        f['type'] = 'creature'
    elif 'feitiço' in d or 'mágica' in d or 'feitico' in d:
        f['type'] = 'spell'
    elif 'terreno' in d:
        f['type'] = 'land'
    elif 'incolor' in d:
        f['colorless'] = True
    elif 'artefacto' in d:
        f['colorless'] = True
    m = re.search(r'custo (\d)(?: ou (\d))?', d)
    if m:
        if m.group(2):
            f['cost_min'] = int(m.group(1)); f['cost_max'] = int(m.group(2))
        else:
            f['cost'] = int(m.group(1))
    m = re.search(r'mais de (\d+) de poder', d)
    if m:
        f['power_min'] = int(m.group(1)) + 1
    m = re.search(r'(\d+)\+ de poder', d)
    if m:
        f['power_min'] = int(m.group(1))
    return f

def zone_of(desc):
    d = desc.lower()
    if 'cemitério' in d or 'cemiterio' in d:
        return 'graveyard'
    if 'na mão' in d or 'na tua mão' in d:
        return 'hand'
    if 'grimório' in d:
        return 'library'
    if 'jogad' in d or 'nesta mão' in d or 'na mesma mão' in d or 'na jogada' in d:
        return 'played'
    if 'na arena' in d or 'atacante' in d:
        return 'attacker'
    return None

def make_per(clause):
    """Devolve (per_dict, clause_sem_por_cada) ou (None, clause)."""
    m = re.search(r'por cada (?:outra |outro )?(.+?)(?:\.|$|;| e dá| e \+| \(até)', clause, re.I)
    if not m:
        return None, clause
    desc = m.group(1).strip()
    per = {}
    d = desc.lower()
    other = 'outra' in clause.lower()[max(0, m.start()-1):m.end()] or ' outra ' in d or ' outro ' in d
    mdiv = re.match(r'(\d+)\s*(🪙|cartas no cemitério|de poder da maior criatura|feitiços/mágicas jogados)', d)
    if mdiv:
        per['per_div'] = int(mdiv.group(1))
    if '🪙' in d or 'ouro' in d:
        per['of'] = 'gold'
    elif 'cor diferente' in d or 'cores diferentes' in d or 'cor presente' in d:
        per['of'] = 'colors'
    elif 'tipo diferente' in d:
        per['of'] = 'graveyard_types'
    elif 'slot de artefacto' in d or 'artefacto no topo' in d or 'artefactos' in d and 'topo' in d:
        per['of'] = 'relics'
    elif 'carta comprada' in d:
        per['of'] = 'drawn_this_turn'
    elif 'de poder da maior' in d:
        per['of'] = 'max_power'
    elif 'carta que tens na mão' in d or 'carta na mão' in d or 'carta que ficou retida' in d or 'carta não jogada' in d:
        per['of'] = 'hand'
    elif 'cemitério' in d:
        per['of'] = 'graveyard'
        f = parse_filter(desc)
        f.pop('type', None) if 'carta no' in d else None
        if f: per['filter'] = f
    elif 'feitiço' in d or 'mágica' in d:
        per['of'] = 'spell'
        f = parse_filter(desc); f.pop('type', None)
        if 'mágica' in d and 'feitiço' not in d:
            f['subtype'] = 'instant'
        if f: per['filter'] = f
    elif 'criatura' in d:
        per['of'] = 'attacker'
        f = parse_filter(desc); f.pop('type', None)
        if f: per['filter'] = f
    elif 'terreno' in d:
        per['of'] = 'land_hand' if 'mão' in d else 'graveyard' if 'cemitério' in d else 'land_hand'
    elif 'carta' in d:
        per['of'] = 'played'
        f = parse_filter(desc)
        if f: per['filter'] = f
    else:
        return None, clause
    if other:
        per['exclude_self'] = True
    mcap = re.search(r'até \+(\d+) Mult', clause)
    if mcap:
        per['cap'] = int(mcap.group(1))
    rest = clause[:m.start()] + clause[m.end():]
    return per, rest

FORMATIONS = {
    'bando tribal': 'band', 'devoção pura': 'devotion', 'pacto dual': 'pair', 'par': 'pair', 'dois pares': 'pair',
    'tríade': 'trips', 'tríade de custo': 'trips', 'curva de mana': 'curve', 'tempestade arcana': 'storm',
    'convergência wubrg': 'wubrg', 'convergência': 'wubrg',
}

def parse_condition(clause):
    """Extrai uma condição ('se ...') do clause. Devolve (cond, clause_sem_cond)."""
    cond = {}
    low = clause.lower()
    # posição
    if re.search(r'1ª carta|posição 1\b|primeira carta', low):
        cond['position'] = 'first'
    elif re.search(r'posição 5|5ª carta|\(direita\)', low):
        cond['position'] = 'last'
    if 'posição 1 ou 5' in low:
        cond['position'] = 'edge'
    m = re.search(r'\bse\b (.+)$', clause, re.I)
    if not m:
        return cond, clause
    c = m.group(1).lower()
    rest = clause[:m.start()].rstrip(' ,;')
    if re.match(r'(estiver na posição|for a 1ª carta|estiver na 1ª)', c) and cond.get('position'):
        m3 = re.search(r'[,:]\s*(.+)$', c)
        return cond, (rest + ' ' + (m3.group(1) if m3 else '')).strip()
    # "se X, dá Y" / "se X: Y" — a ação vem depois da condição
    m2 = re.search(r'[,:]\s*((?:dá|ganha|recebe|ainda pontua|reativa|ativa|duplica|compra|envia|destrói|silencia|puxa|\+|×).+)$', c)
    if m2:
        rest = (rest + ' ' + m2.group(1)).strip()
        c = c[:m2.start()].strip()
    # formações
    forms = [v for k, v in FORMATIONS.items() if k in c and ('formação' in c or 'jogares' in c or 'atacares' in c or 'formar' in c or 'contiver' in c or 'formares' in c)]
    if forms:
        cond['formation'] = sorted(set(forms))
        return cond, rest
    if 'todas as cartas jogadas' in c and 'custo 1' in c:
        cond['all_cost'] = 1; return cond, rest
    mm = re.search(r'grimório tiver (\d+) ou menos', c)
    if mm: cond['library_max'] = int(mm.group(1)); return cond, rest
    mm = re.search(r'grimório tiver menos de (\d+)', c)
    if mm: cond['library_max'] = int(mm.group(1)) - 1; return cond, rest
    if 'grimório tiver 2 ou menos' in c: cond['library_max'] = 2; return cond, rest
    if '0 canalizações' in c: cond['discards_max'] = 0; return cond, rest
    if 'tiveres 1 ou 0 cartas na mão' in c: cond['hand_max'] = 1; return cond, rest
    if 'destruíste uma carta' in c: cond['discarded_min'] = 1; return cond, rest
    if 'tiveres ouro' in c: cond['gold_min'] = 1; return cond, rest
    mm = re.search(r'atacar com mais (\d+) criaturas', c)
    if mm: cond['count'] = {'of': 'attacker', 'min': int(mm.group(1)) + 1}; return cond, rest
    mm = re.search(r'jogado junto com pelo menos (\d+) cartas incolores', c)
    if mm: cond['count'] = {'of': 'played', 'filter': {'colorless': True}, 'min': int(mm.group(1))}; return cond, rest
    if 'central e torre na mão' in c: cond['hand_has'] = ['c271', 'c272']; return cond, rest
    if 'mina e torre na mão' in c: cond['hand_has'] = ['c270', 'c272']; return cond, rest
    if 'mina e central na mão' in c: cond['hand_has'] = ['c270', 'c271']; return cond, rest
    if 'nenhuma carta na mão' in c or 'mão estiver vazia' in c or 'mão vazia' in c:
        cond['hand_max'] = 0; return cond, rest
    if '1 ou 0 cartas na mão' in c: cond['hand_max'] = 1; return cond, rest
    if 'única carta na tua mão' in c: cond['hand_max'] = 1; return cond, rest
    mm = re.search(r'tiveres (\d+)\+? ?(?:ou mais )?🪙', c) or re.search(r'mais de (\d+) 🪙', c)
    if mm: cond['gold_min'] = int(mm.group(1)) + (1 if 'mais de' in c else 0); return cond, rest
    mm = re.search(r'tiveres (\d+) ou mais 🪙', c)
    if mm: cond['gold_min'] = int(mm.group(1)); return cond, rest
    if 'boss' in c and ('50%' in c or '< 50' in c):
        cond['enemy_hp_below_pct'] = 50; return cond, rest
    if 'já usaste canalizar' in c: cond['discarded_min'] = 1; return cond, rest
    if 'não descartaste' in c: cond['discarded_max'] = 0; return cond, rest
    if 'nenhuma carta colorida' in c:
        cond['count'] = {'of': 'attacker', 'filter': {'colored': True}, 'max': 0}; return cond, rest
    if 'exatamente 5 cartas' in c: cond['count'] = {'of': 'attacker', 'min': 5}; return cond, rest
    if 'exatamente 1 ou 2 cartas' in c or 'apenas 1 ou 2 cartas' in c:
        cond['count'] = {'of': 'played', 'max': 2}; return cond, rest
    if '4ª ou 5ª carta' in c: cond['count'] = {'of': 'spell', 'min': 4}; return cond, rest
    mm = re.search(r'terreno.*no cemitério', c)
    if mm: cond['count'] = {'of': 'graveyard', 'filter': {'type': 'land'}, 'min': 1}; return cond, rest
    mm = re.search(r'cemitério tiver (\d+)\+? ?(?:ou mais )?cartas', c) or re.search(r'cemitério tiver (\d+)\+', c)
    if mm: cond['count'] = {'of': 'graveyard', 'min': int(mm.group(1))}; return cond, rest
    mm = re.search(r'tiveres (\d+) ou mais cartas no cemitério', c)
    if mm: cond['count'] = {'of': 'graveyard', 'min': int(mm.group(1))}; return cond, rest
    if 'feitiços e criaturas no cemitério' in c: cond['count'] = {'of': 'graveyard', 'min': 2}; return cond, rest
    mm = re.search(r'pelo menos (\d+) terrenos na mão', c)
    if mm: cond['count'] = {'of': 'land_hand', 'min': int(mm.group(1))}; return cond, rest
    if 'terreno' in c and 'na mão' in c: cond['count'] = {'of': 'land_hand', 'min': 1}; return cond, rest
    mm = re.search(r'(\d+)\+? ?(?:ou mais )?cores', c) or re.search(r'(\d+) ou mais cores', c)
    if mm and 'cores' in c: cond['count'] = {'of': 'colors', 'min': int(mm.group(1))}; return cond, rest
    if 'ao lado' in c:
        col = color_from_word(c)
        if col: cond['neighbor_color'] = col; return cond, rest
        mm = re.search(r'pelo menos (\d+) criaturas', c)
        if mm: cond['count'] = {'of': 'attacker', 'min': int(mm.group(1))}; return cond, rest
        if 'custo 5' in c: cond['neighbor_cost'] = 5; return cond, rest
    if 'entre duas criaturas' in c: cond['neighbors_min'] = 2; return cond, rest
    mm = re.search(r'controlares uma criatura com (\d+)\+', c)
    if mm: cond['count'] = {'of': 'attacker', 'filter': {'power_min': int(mm.group(1))}, 'min': 1}; return cond, rest
    mm = re.search(r'(?:houver )?(?:outra|outro) (?:carta de |criatura )?(.+?) na arena', c)
    if mm:
        f = parse_filter(mm.group(1)); f.pop('type', None)
        cond['count'] = {'of': 'attacker', 'filter': f, 'min': 2}; return cond, rest
    mm = re.search(r'houver (?:uma |um )?(.+?) na arena', c)
    if mm:
        f = parse_filter(mm.group(1)); f.pop('type', None)
        cond['count'] = {'of': 'attacker', 'filter': f, 'min': 1}; return cond, rest
    mm = re.search(r'jogares (?:outro|outra) custo (\d)', c)
    if mm: cond['count'] = {'of': 'played', 'filter': {'cost': int(mm.group(1))}, 'min': 2}; return cond, rest
    mm = re.search(r'formar par com outra carta de custo (\d)', c)
    if mm: cond['count'] = {'of': 'played', 'filter': {'cost': int(mm.group(1))}, 'min': 2}; return cond, rest
    mm = re.search(r'(?:jogares|atacares com|houver|tiveres|a arena tiver|a mão conter|jogada ao lado de)\s*(?:pelo menos |com )?(\d+)\s*(?:\+|ou mais)?\s*(.*?)(?:\s+nesta mão|\s+na mesma mão|\s+na arena|\s+juntas|\s*$)', c)
    if mm:
        f = parse_filter(mm.group(2))
        of = 'spell' if f.get('type') == 'spell' else 'attacker' if f.get('type') == 'creature' else 'played'
        f.pop('type', None)
        cond['count'] = {'of': of, 'min': int(mm.group(1))}
        if f: cond['count']['filter'] = f
        return cond, rest
    mm = re.search(r'(?:a mão conter|jogares|na mesma mão.*?)\s*([a-zçã]+) e ([a-zçã]+)', c)
    if mm and color_from_word(mm.group(1)) and color_from_word(mm.group(2)):
        cond['colors_all'] = [color_from_word(mm.group(1)), color_from_word(mm.group(2))]; return cond, rest
    mm = re.search(r'(?:a mão conter|jogares|jogares cartas|jogares verde ou branco|cartas) ([a-zçã]+) ou ([a-zçã]+)', c)
    if mm and color_from_word(mm.group(1)):
        cond['colors_any'] = [color_from_word(mm.group(1)), color_from_word(mm.group(2))]; return cond, rest
    if 'pelo menos uma carta u, uma b e uma r' in c:
        cond['colors_all'] = ['blue', 'black', 'red']; return cond, rest
    if 'jogares 5 cores' in c: cond['formation'] = ['wubrg']; return cond, rest
    if 'jogado numa convergência' in c: cond['formation'] = ['wubrg']; return cond, rest
    if 'jogar uma carta de custo 4 ou 5' in c or 'jogares uma carta de custo 4 ou 5' in c:
        cond['count'] = {'of': 'played', 'filter': {'cost_min': 4}, 'min': 1}; return cond, rest
    if 'houver 4 ou mais criaturas' in c:
        cond['count'] = {'of': 'attacker', 'min': 4}; return cond, rest
    if 'tiveres 4+ cartas na mão' in c:
        cond['count'] = {'of': 'hand', 'min': 4}; return cond, rest
    if 'a carta à direita tiver custo 3' in c: cond['right_cost'] = 3; return cond, rest
    if 'houver uma carta de custo 2 na arena' in c: cond['count'] = {'of': 'attacker', 'filter': {'cost': 2}, 'min': 1}; return cond, rest
    if 'houver uma carta de custo 3 na arena' in c: cond['count'] = {'of': 'attacker', 'filter': {'cost': 3}, 'min': 1}; return cond, rest
    if 'houver outro feitiço à direita' in c: cond['has_right'] = True; return cond, rest
    if 'mão só tiver cartas incolores' in c: cond['hand_all_colorless'] = True; return cond, rest
    if 'for destruída' in c or 'for descartad' in c:
        cond['_trigger'] = 'on_discard'; return cond, rest
    return {'_unknown': c}, rest

IMMEDIATE_ACTIONS = {'draw', 'gold', 'mill', 'discard_random', 'silence_enemy', 'extra_turn', 'discard_plus',
                     'shuffle_graveyard', 'enemy_max_hp_pct', 'recover', 'tutor_land', 'tutor_strongest',
                     'tutor_creature', 'grow_self', 'grow_hand', 'grow_left', 'grow_board', 'destroy_left',
                     'destroy_right', 'consume_discard', 'mill_half', 'enemy_vulnerable', 'grow_mult_self'}

def parse_actions(clause, card):
    """Extrai ações numéricas e especiais de um clause. Devolve lista de dicts (sem per/cond) e notas."""
    acts = []
    notes = []
    c = clause
    low = c.lower()
    # Ações especiais primeiro
    for pattern, act in [
        (r'reativa (?:a |o )?(?:criatura|carta|mágica|feitiço)[^.;]*?à (?:sua )?esquerda', ('retrigger', 'left')),
        (r'reativa (?:a |o )?(?:criatura|carta|mágica|feitiço)[^.;]*?à (?:sua )?direita', ('retrigger', 'right')),
        (r'a carta à sua esquerda ativa 2 vezes', ('retrigger', 'left')),
        (r'reativa a si mesma', ('retrigger', 'self')),
        (r'ativa 2 vezes', ('retrigger', 'self')),
        (r'ativa(?:m)? o seu poder base 2 vezes', ('retrigger', 'all')),
        (r'reativa todos os teus artefactos', ('retrigger', 'relics')),
        (r'reativa a carta que estiver na posição 1', ('retrigger', 'first')),
        (r'reativa todas as cartas de custo 2 ou 3', ('retrigger', 'all')),
        (r'reativa toda a mão', ('retrigger', 'all')),
        (r'reativa todos os efeitos \[na mão\]', ('retrigger', 'hand')),
        (r'reativa (?:qualquer|o) feitiço', ('retrigger', 'last_spell')),
        (r'reativa esse feitiço', ('retrigger', 'last_spell')),
        (r'ativa também 1 feitiço aleatório que esteja no teu cemitério', ('cascade_library', 'graveyard_spell')),
        (r'ativa automaticamente o efeito da carta no topo do teu grimório', ('cascade_library', 'top')),
        (r'ativa em cascata 1 carta extra do topo do grimório', ('cascade_library', 'top')),
        (r'puxa a maior criatura do teu grimório e ativa-a', ('cascade_library', 'strongest')),
        (r'copia a habilidade da carta que estiver à sua direita', ('retrigger', 'right')),
        (r'copia o multiplicador da carta à sua esquerda', ('retrigger', 'left')),
        (r'copia a habilidade de qualquer carta na arena', ('retrigger', 'best')),
        (r'duplica os valores base da formação', ('retrigger', 'formations')),
        (r'todas as habilidades de criaturas orzhov ativam uma 2ª vez', ('retrigger', 'all')),
        (r'cada feitiço/mágica nesta mão ativa \+1 vez', ('retrigger', 'spells')),
        (r'duplica o poder base atual desta carta', ('power_double_self', None)),
        (r'duplica \(×2\) o multiplicador final', ('mult_mul', 2.0)),
        (r'duplica o dano final \(×2\)', ('mult_mul', 2.0)),
        (r'ignora a restrição do boss|silencia o boss|anula a habilidade do boss|remove a regra do boss|imune a (?:todas as )?regras de boss|impede que o boss anule', ('silence_enemy', 1)),
        (r'\+1 turno extra|dá \+1 turno', ('extra_turn', 1)),
        (r'\+1 canalização', ('discard_plus', 1)),
        (r'consome 1 canalização', ('consume_discard', 1)),
        (r'baralha o cemitério no grimório', ('shuffle_graveyard', 1)),
        (r'reduz o hp máximo do boss em (\d+)%', ('enemy_max_hp_pct', 'g1')),
        (r'rouba (\d+)% do hp do boss como poder', ('power_pct_enemy', 'g1')),
        (r'faz o boss receber ×([\d.,]+) de dano extra', ('enemy_vulnerable', 'g1')),
        (r'envia metade do teu grimório', ('mill_half', 1)),
        (r'envia (?:as )?(\d+) cartas? do (?:topo do )?grimório', ('mill', 'g1')),
        (r'envia (\d+) cartas ao cemitério', ('mill', 'g1')),
        (r'duplica o seu poder', ('power_double_self', None)),
        (r'ativa todos os terrenos na tua mão 2 vezes', ('retrigger', 'hand')),
        (r'envia \+?(\d+) cartas do grimório', ('mill', 'g1')),
        (r'envia (\d+) do grimório', ('mill', 'g1')),
        (r'envia 1 carta do grimório ao cemitério por turno', ('mill', 1)),
        (r'descarta (\d+) cartas? (?:aleatória |da mão |da tua mão )?', ('discard_random', 'g1')),
        (r'destrói 1 carta (?:aleatória|fraca)[^.;]*mão', ('discard_random', 1)),
        (r'destrói a (?:carta|criatura) à (?:sua )?esquerda', ('destroy_left', 1)),
        (r'destrói a carta à (?:sua )?direita', ('destroy_right', 1)),
        (r'devolve (?:até )?(\d+) cartas? do cemitério', ('recover', 'g1')),
        (r'devolve 1 mágica', ('recover', 1)),
        (r'puxa 1 terreno', ('tutor_land', 1)),
        (r'puxa a carta mais forte do teu grimório', ('tutor_strongest', 1)),
        (r'puxa 1 criatura de poder', ('tutor_creature', 1)),
        (r'compra (\d+) cartas?', ('draw', 'g1')),
        (r'ganha \+(\d+) 🪙|\+(\d+) 🪙', ('gold', 'g1')),
        (r'custa 1 🪙', ('gold', -1)),
    ]:
        m = re.search(pattern, low)
        if m:
            name, val = act
            if val == 'g1':
                g = [x for x in m.groups() if x]
                val = num(g[0]) if g else 1
            acts.append({'action': name, 'value': val})
            low = low[:m.start()] + ' ' + low[m.end():]
    # crescimento permanente
    for m in re.finditer(r'\+(\d+) pod permanente', low):
        v = int(m.group(1))
        seg = low[max(0, m.start()-60):m.end()+60]
        if 'à sua esquerda' in seg or 'à criatura à sua esquerda' in seg or 'à esquerda' in seg:
            acts.append({'action': 'grow_left', 'value': v})
        elif 'na tua mão' in seg or 'cartas na mão' in seg or 'criaturas na tua mão' in seg:
            acts.append({'action': 'grow_hand', 'value': v})
        elif 'todas as outras' in seg or 'a todas as outras cartas' in seg:
            acts.append({'action': 'grow_board', 'value': v, 'exclude_self': True})
        elif 'todas as' in seg and 'arena' in seg:
            acts.append({'action': 'grow_board', 'value': v})
        elif 'criaturas verdes jogadas ganham' in seg:
            acts.append({'action': 'grow_played', 'value': v, 'filter': {'color': 'green'}})
        else:
            acts.append({'action': 'grow_self', 'value': v})
    low = re.sub(r'\+\d+ pod permanente(?:mente)?', ' ', low)
    m = re.search(r'ganha \+(\d+) pod permanentemente', low)
    if m:
        acts.append({'action': 'grow_self', 'value': int(m.group(1))}); low = low[:m.start()] + low[m.end():]
    m = re.search(r'\+(\d+) mult permanente', low)
    if m:
        acts.append({'action': 'grow_mult_self', 'value': int(m.group(1))}); low = low[:m.start()] + low[m.end():]
    # numéricas
    for m in re.finditer(r'×\s*([\d.,]+)(?:\s*mult)?', low):
        acts.append({'action': 'mult_mul', 'value': num(m.group(1))})
    for m in re.finditer(r'\+\s*(\d+)\s*mult', low):
        acts.append({'action': 'mult_add', 'value': int(m.group(1))})
    for m in re.finditer(r'\+\s*(\d+)\s*pod', low):
        acts.append({'action': 'power_add', 'value': int(m.group(1))})
    for m in re.finditer(r'-(\d+)\s*mult', low):
        acts.append({'action': 'mult_add', 'value': -int(m.group(1))})
    return acts, notes

TARGET_PATTERNS = [
    (r'às cartas adjacentes', {'per': {'of': 'neighbors'}}),
    (r'a todas as (?:tuas )?criaturas (?:na arena|nesta jogada)|todas as criaturas (?:na arena |nesta jogada |jogadas nesta mão )?ganham', {'per': {'of': 'attacker'}}),
    (r'todas as criaturas brancas nesta jogada dão', {'per': {'of': 'attacker', 'filter': {'color': 'white'}}}),
    (r'todas as mágicas e feitiços nesta jogada dão', {'per': {'of': 'spell'}}),
    (r'a todas as cartas jogadas nesta mão|a todas as cartas na arena|a todas as (?:tuas )?jogadas', {'per': {'of': 'played'}}),
    (r'a todas as cartas pretas na arena', {'per': {'of': 'played', 'filter': {'color': 'black'}}}),
    (r'a todas as cartas de custo 4 ou 5 na arena', {'per': {'of': 'attacker', 'filter': {'cost_min': 4}}}),
    (r'para cartas pretas e vermelhas', {}),
    (r'para cartas u, b ou r', {}),
    (r'a cartas incolores', {}),
    (r'a formações de bando tribal', {'cond': {'formation': ['band']}}),
    (r'à criatura à direita', {'cond': {'has_right': True}}),
    (r'criaturas jogadas nesta mão ganham', {'per': {'of': 'attacker'}}),
    (r'todas as criaturas incolores ganham', {'per': {'of': 'attacker', 'filter': {'colorless': True}}}),
    (r'sempre que uma mágica ou feitiço ativa', {'per': {'of': 'spell'}}),
    (r'sempre que uma carta é destruída ou descartada', {'per': {'of': 'discards_used'}}),
    (r'por cada carta no cemitério e dá', {'per': {'of': 'graveyard'}}),
]

def map_text(card):
    text = card['text']
    effects = []
    notes = []
    approx = False
    flags = {}
    in_hand = text.startswith('[Na Mão')
    body = re.sub(r'^\[Na Mão(?: ou Arena)?\]\s*', '', text)
    low = body.lower()
    # flags "conta como"
    if 'conta como qualquer cor' in low or 'conta como todas as 5 cores' in low or 'conta como qualquer cor que falte' in low:
        flags['wild_color'] = True
    if 'conta como qualquer custo' in low or 'conta como custo 1 ou custo 5' in low or 'conta como custo 1 ou' in low or 'preenche 1 custo em falta' in low:
        flags['wild_cost'] = True
    if 'conta como 2 criaturas' in low:
        flags['counts_as_two'] = True
    if 'conta como criatura e como' in low or 'conta como criatura e como feitiço' in low or 'conta como criatura e como mágica' in low:
        flags['counts_as'] = ['creature', 'spell']
    if 'transforma qualquer mão de 5 cartas numa convergência' in low:
        flags['force_formation'] = 'wubrg'
    if 'volta para o grimório em vez do cemitério' in low:
        flags['return_to_library'] = True
    clauses = [s.strip() for s in re.split(r';|\.\s+(?=[A-ZÁÉÍÓÚ+×])', body) if s.strip()]
    for clause in clauses:
        cl = clause.rstrip('.!')
        per, rest = make_per(cl)
        cond, rest2 = parse_condition(rest)
        extra = {}
        for pat_, add in TARGET_PATTERNS:
            if re.search(pat_, rest2.lower()):
                extra.update(add)
        acts, _ = parse_actions(rest2, card)
        unknown = cond.pop('_unknown', None)
        trig_override = cond.pop('_trigger', None)
        if not acts:
            if any(k in cl.lower() for k in ('conta como', 'proteção', 'impede debuffs', 'imune', 'ignora reduções', 'transforma', 'ajusta o custo', 'converte o custo', 'muda a cor', 'volta para o grimório', 'preenche 1 custo', 'ativam para qualquer cor')):
                pass
            else:
                notes.append(cl)
                approx = True
            continue
        if unknown:
            notes.append('cond? ' + unknown); approx = True
        for a in acts:
            e = dict(a)
            if per and a['action'] in ('mult_add', 'power_add', 'mult_mul'):
                e['per'] = per['of']
                if 'filter' in per: e['filter'] = per['filter']
                if 'per_div' in per: e['per_div'] = per['per_div']
                if 'cap' in per: e['cap'] = per['cap']
                if per.get('exclude_self'): e['exclude_self'] = True
            elif 'per' in extra and a['action'] in ('mult_add', 'power_add'):
                e['per'] = extra['per']['of']
                if 'filter' in extra['per']: e['filter'] = extra['per']['filter']
            cnd = dict(cond)
            if 'cond' in extra: cnd.update(extra['cond'])
            if cnd: e['cond'] = cnd
            # trigger
            if trig_override:
                e['trigger'] = trig_override
            elif in_hand:
                e['trigger'] = 'in_hand'
            elif card['tcode'] == 'CR':
                e['trigger'] = 'on_play' if a['action'] in IMMEDIATE_ACTIONS else 'on_attack'
            elif card['tcode'] == 'LD':
                e['trigger'] = 'in_hand'
            else:
                e['trigger'] = 'on_cast'
            effects.append(e)
    return effects, approx, notes, flags

# ----------------------------------------------------------------------------
# Overrides à mão (baralhos 1–5 e casos especiais)
# ----------------------------------------------------------------------------
def E(trigger, action, value=None, **kw):
    e = {'trigger': trigger, 'action': action}
    if value is not None: e['value'] = value
    e.update(kw); return e

OVERRIDES = {
  1: [E('on_attack','mult_add',4), E('on_attack','power_add',20, cond={'position':'first'})],
  2: [E('on_cast','mult_add',6), E('on_cast','mult_add',4, per='played', filter={'cost':1}, exclude_self=True)],
  3: [E('on_attack','mult_mul',1.5, cond={'count':{'of':'played','filter':{'color':'red'},'min':3}})],
  4: [E('on_cast','mult_add',8)],
  5: [E('on_attack','mult_add',5, per='spell')],
  6: [E('on_cast','mult_mul',2, cond={'library_max':2})],
  7: [E('on_attack','mult_add',10, cond={'all_cost':1})],
  8: [E('in_hand','mult_mul',1.5, cond={'count':{'of':'played','filter':{'cost':1},'min':3}})],
  9: [E('on_cast','mult_add',3), E('on_cast','draw',1)],
  10:[E('on_attack','retrigger','last_spell')],
  11:[E('on_cast','power_add',50), E('on_cast','mult_add',4, per='hand')],
  12:[E('on_cast','silence_enemy',1), E('on_cast','mult_mul',1.5)],
  13:[E('on_attack','power_add',15, per='spell', filter={'subtype':'instant'})],
  14:[E('on_cast','shuffle_graveyard',1), E('on_cast','mult_mul',2)],
  15:[E('on_attack','mult_add',6, per='played', filter={'color':'blue'})],
  16:[E('on_cast','mult_mul',2.5, cond={'count':{'of':'spell','min':4}})],
  17:[E('in_hand','power_add',30, cond={'formation':['storm']}), E('in_hand','mult_mul',1.3, cond={'formation':['storm']})],
  18:[E('on_cast','mult_add',8)],
  19:[E('on_attack','mult_add',6), E('on_attack','mult_mul',2, cond={'discards_max':0})],
  20:[E('on_play','consume_discard',1), E('on_attack','mult_add',12, cond={'consumed':True})],
  21:[E('on_cast','power_add',30), E('on_cast','mult_add',5), E('on_cast','draw',1)],
  22:[E('on_play','discard_random',1), E('on_attack','mult_mul',1.8)],
  23:[E('on_cast','retrigger','last_creature')],
  24:[E('on_play','discard_random',1), E('on_attack','mult_mul',2)],
  25:[E('on_cast','mult_add',4, per='played', filter={'color':'black'})],
  26:[E('on_attack','mult_mul',3, cond={'hand_max':0})],
  27:[E('in_hand','mult_mul',1.6, cond={'count':{'of':'played','filter':{'color':'black'},'min':3}})],
  28:[E('on_play','grow_self',15)],
  29:[E('on_cast','grow_left',20), E('on_cast','mult_add',4)],
  30:[E('on_attack','mult_add',4), E('on_play','grow_mult_self',0.5)],
  31:[E('on_attack','power_double_self',1)],
  32:[E('on_attack','power_add',50, cond={'count':{'of':'attacker','filter':{'color':'green'},'min':2}})],
  33:[E('on_cast','mult_add',3, per='attacker', filter={'power_min':41})],
  34:[E('on_attack','mult_mul',1.5, per='attacker', filter={'color':'green'})],
  35:[E('on_cast','power_add',15), E('on_cast','mult_add',2, per='played', filter={'color':'green'})],
  36:[E('on_play','grow_hand',8)],
  37:[E('on_play','grow_self',25), E('on_attack','mult_mul',1.5)],
  38:[E('in_hand_on_play','grow_played',10, filter={'color':'green'})],
  39:[E('on_attack','power_add',20, per='attacker', exclude_self=True)],
  40:[E('on_attack','mult_add',3, per='attacker')],
  41:[E('on_attack','mult_add',6, cond={'count':{'of':'played','filter':{'cost':2},'min':2}})],
  42:[E('on_cast','mult_add',4, per='attacker', filter={'color':'white'})],
  43:[E('on_attack','mult_mul',1.5, cond={'formation':['band','devotion']})],
  44:[E('on_attack','retrigger','left', filter={'color':'white'})],
  45:[E('on_cast','mult_add',8, cond={'count':{'of':'attacker','min':3}})],
  46:[E('on_attack','mult_mul',2, cond={'count':{'of':'attacker','min':4}})],
  47:[E('on_attack','mult_add',4), E('on_attack','power_add',15, per='neighbors')],
  48:[E('on_attack','mult_add',5), E('on_play','silence_enemy',1)],
  49:[E('on_cast','mult_mul',1.8)],
  50:[E('in_hand','mult_mul',1.5, cond={'count':{'of':'attacker','min':3}})],
}
OVERRIDES[183] = [E('on_attack','retrigger','all', cond={'position':'edge'})]
# Afinação (simulação): o baralho 01 e os terrenos de Urza estavam demasiado fortes.
OVERRIDES[2] = [E('on_cast','mult_add',6), E('on_cast','mult_add',2, per='played', filter={'cost':1}, exclude_self=True)]
OVERRIDES[6] = [E('on_cast','mult_mul',1.5, cond={'library_max':2})]
OVERRIDES[270] = [E('in_hand','power_add',30), E('in_hand','mult_mul',1.5, cond={'hand_has':['c271','c272']})]
OVERRIDES[271] = [E('in_hand','mult_add',5), E('in_hand','mult_mul',1.5, cond={'hand_has':['c270','c272']})]
OVERRIDES[272] = [E('in_hand','mult_mul',1.5), E('in_hand','mult_mul',2.0, cond={'hand_has':['c270','c271']})]
# Aparar os baralhos dominantes na simulação (01, 03, 05, 17).
OVERRIDES[3] = [E('on_attack','mult_mul',1.3, cond={'count':{'of':'played','filter':{'color':'red'},'min':3}})]
OVERRIDES[7] = [E('on_attack','mult_add',6, cond={'all_cost':1})]
OVERRIDES[8] = [E('in_hand','mult_mul',1.3, cond={'count':{'of':'played','filter':{'cost':1},'min':3}})]
OVERRIDES[19] = [E('on_attack','mult_add',6), E('on_attack','mult_mul',1.5, cond={'discards_max':0})]
OVERRIDES[26] = [E('on_attack','mult_mul',2.5, cond={'hand_max':0})]
OVERRIDES[27] = [E('in_hand','mult_mul',1.4, cond={'count':{'of':'played','filter':{'color':'black'},'min':3}})]
OVERRIDES[43] = [E('on_attack','mult_mul',1.3, cond={'formation':['band','devotion']})]
OVERRIDES[46] = [E('on_attack','mult_mul',1.5, cond={'count':{'of':'attacker','min':4}})]
OVERRIDES[50] = [E('in_hand','mult_mul',1.3, cond={'count':{'of':'attacker','min':3}})]
OVERRIDES[251] = [E('on_cast','mult_mul',2.0, cond={'count':{'of':'attacker','filter':{'colored':True},'max':0}})]
OVERRIDES[255] = [E('on_attack','mult_mul',1.5), E('on_play','silence_enemy',1)]
OVERRIDES[262] = [E('on_attack','mult_mul',2.0, cond={'count':{'of':'land_hand','min':2}})]
OVERRIDES[269] = [E('on_cast','mult_mul',1.8)]
# Izzet precisava de ajuda: os feitiços disparam uma vez por turno.
OVERRIDES[144] = [E('on_attack','mult_add',8, per='spell')]
OVERRIDES[145] = [E('on_attack','power_add',40, per='spell')]
OVERRIDES[149] = [E('on_attack','power_add',40, cond={'count':{'of':'spell','min':2}}), E('on_attack','mult_add',6, cond={'count':{'of':'spell','min':2}})]
TEXT_OVERRIDES = {
  144: 'Sempre que uma Mágica ou Feitiço ativa na Arena, dá +8 Mult extra!',
  145: 'Todas as Mágicas e Feitiços nesta jogada dão +40 Pod extra.',
  149: 'Ganha +40 Pod e +6 Mult se jogares pelo menos 2 Feitiços nesta mão.',
  3: '×1.3 Mult se jogares pelo menos 3 cartas Vermelhas.',
  7: '+6 Mult se todas as cartas jogadas na mão tiverem Custo 1.',
  8: '[Na Mão] Dá ×1.3 Mult se atacares com 3+ cartas de Custo 1.',
  19: '+6 Mult; se tiveres 0 Canalizações restantes, dá ×1.5 Mult.',
  26: '×2.5 Mult se não tiveres nenhuma carta na mão após conjurar.',
  27: '[Na Mão] ×1.4 Mult se jogares 3 ou mais cartas Pretas.',
  43: '×1.3 Mult se a formação for Bando Tribal ou Devoção Pura.',
  46: '×1.5 Mult se houver 4 ou mais Criaturas na Arena.',
  50: '[Na Mão] ×1.3 Mult se jogares 3 ou mais Criaturas.',
  251: '×2 Mult se não houver nenhuma carta colorida na Arena!',
  255: '×1.5 Mult e imune a todas as regras de Boss.',
  262: '×2 Mult se tiveres pelo menos 2 Terrenos na mão!',
  269: '×1.8 Mult.',
  2: '+6 Mult; ganha +2 Mult extra por cada outra carta de Custo 1 jogada.',
  6: '×1.5 Mult se o teu Grimório tiver 2 ou menos cartas restantes.',
  270: '[Na Mão] +30 Pod; se tiveres Central e Torre na mão, dá ×1.5 Mult!',
  271: '[Na Mão] +5 Mult; se tiveres Mina e Torre na mão, dá ×1.5 Mult!',
  272: '[Na Mão] ×1.5 Mult; se tiveres Mina e Central na mão, dá ×2 Mult!',
}
OVERRIDE_FLAGS = {49: {'counts_as_two': True}}

# ----------------------------------------------------------------------------
# Construção das cartas
# ----------------------------------------------------------------------------
def rarity_for(cost, tcode):
    if tcode == 'LD': return 'uncommon'
    return 'rare' if cost == 5 else 'uncommon' if cost == 4 else 'common'

def price_for(cost, tcode):
    return 3 + cost + (2 if cost == 5 else 0) if tcode != 'LD' else 5

cards = []
report = collections.Counter()
notes_by_deck = collections.defaultdict(list)
for num_ in range(1, 301):
    r = raw[num_]
    effects, approx, notes, flags = map_text(r)
    if num_ in OVERRIDES:
        effects = OVERRIDES[num_]; approx = False; notes = []
        flags.update(OVERRIDE_FLAGS.get(num_, {}))
    deck = deck_of(num_)
    t = TYPE[r['tcode']]
    card = {
        'id': 'c%03d' % num_, 'num': num_, 'name': r['name'], 'deck': deck,
        'colors': colors_of(r['colorcode']), 'type': t, 'subtype': SUBTYPE[r['tcode']],
        'cost': r['cost'], 'power': r['power'] if t != 'land' else 0,
        'toughness': (r['cost'] + 1) if t == 'creature' else 0,
        'rarity': rarity_for(r['cost'], r['tcode']), 'price': price_for(r['cost'], r['tcode']),
        'text': TEXT_OVERRIDES.get(num_, r['text']), 'effects': effects,
    }
    card.update(flags)
    if approx:
        card['approx'] = True
        card['approx_notes'] = notes
        notes_by_deck[deck].extend(['#%03d %s: %s' % (num_, r['name'], n) for n in notes])
    report['approx' if approx else 'ok'] += 1
    cards.append(card)

decks = []
for did, name, code, size, mech, diff in DECKS:
    ids = [c['id'] for c in cards if c['deck'] == did]
    assert len(ids) == size, (did, len(ids), size)
    approx_n = sum(1 for c in cards if c['deck'] == did and c.get('approx'))
    decks.append({'id': 'deck%02d' % did, 'num': did, 'name': name, 'colors': colors_of(code) if code not in ('CL/LD',) else [],
                  'color_code': code, 'size': size, 'mechanic': mech, 'difficulty': diff,
                  'cards': ids, 'approx_cards': approx_n})

json.dump(cards, open(OUT_DIR + '/cards.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
json.dump(decks, open(OUT_DIR + '/decks.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

print('cartas:', len(cards), dict(report))
acts = collections.Counter(e['action'] for c in cards for e in c['effects'])
print('ações:', dict(acts))
pers = collections.Counter(e.get('per') for c in cards for e in c['effects'] if e.get('per'))
print('per:', dict(pers))
trig = collections.Counter(e['trigger'] for c in cards for e in c['effects'])
print('triggers:', dict(trig))
for d in decks:
    print('deck %02d %-22s %2d cartas, %d aproximadas' % (d['num'], d['name'], d['size'], d['approx_cards']))
if '-v' in sys.argv:
    for did in sorted(notes_by_deck):
        print('--- deck', did)
        for n in notes_by_deck[did]:
            print('  ', n)
