#!/usr/bin/env python3
"""Converte a base de dados de 300 cartas (Mana Cascade) para o formato do Zero-Sum.

Saídas: data/cards.json, data/decks.json e um relatório de cobertura no stdout.
Os efeitos são mapeados por regras (regex) para a DSL do EffectResolver; o que não
se percebe fica registado em "approx_notes" e a carta marcada "approx": true.
"""
import json, re, sys, collections, unicodedata

import os
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'mana_cascade_300.txt')   # documento original (282 cartas) + as 18 finais
OUT_DIR = os.path.join(HERE, '..', 'data')

txt = open(SRC, encoding='utf-8').read()

# ----------------------------------------------------------------------------
# Baralhos (matriz do documento)
# ----------------------------------------------------------------------------
DECKS = [
 (1,"Centelha Rubra","R",8,"Blitz de custo 1 e reciclagem rápida do grimório",1),
 (2,"Paradoxo Cronomante","U",9,"Compra de cartas e acumulação de feitiços",4),
 (3,"Pacto Abissal","B",10,"Sacrifica descartes por ×Mult brutal",2),
 (4,"Semente Primordial","G",11,"Crescimento permanente de Poder ao longo da run",1),
 (5,"Falange Solar","W",12,"Bando Tribal: enxame de criaturas",1),
 (6,"Corte de Cristal","W/U",13,"Retenção na mão: bónus por cartas não jogadas",3),
 (7,"Irmandade do Véu","U/B",14,"Cemitério cheio: topo do grimório para o cemitério",4),
 (8,"Circo Carmim","B/R",15,"Mão vazia e destruição de cartas",3),
 (9,"Tribos da Pedreira","R/G",16,"Fúria colossal: custos 4 e 5 e tríades",2),
 (10,"Coro do Jardim","G/W",17,"Pactos duais (pares) e terrenos vivos",2),
 (11,"Casa da Dívida","W/B",18,"Economia de sangue: Mult pelo ouro acumulado",3),
 (12,"Oficina da Tempestade","U/R",19,"Tempestade Arcana: feitiços em cadeia",4),
 (13,"Reino do Fungo","B/G",20,"Motor de cemitério: canalizar dá Poder e Mult",3),
 (14,"Ordem do Estandarte","R/W",21,"Posicionamento: 1.ª e 5.ª carta ativam várias vezes",2),
 (15,"Viveiro das Marés","G/U",22,"Mutação de curva: custos para forçar Curva 1-5",4),
 (16,"Trono da Ruína","U/B/R",24,"Maldições tricolor: mais forte com o inimigo ferido",4),
 (17,"Forja do Artífice","CL/LD",25,"Artefactos e terrenos na mão",5),
 (18,"Convergência Planar","WUBRG",26,"Domínio das 5 cores: Convergência Prismática",5),
]
deck_ranges = []
start = 1
for d in DECKS:
    deck_ranges.append((d[0], start, start + d[3] - 1))
    start += d[3]
assert start - 1 == 300, start

def deck_of(num):
    for did, a, b in deck_ranges:
        if a <= num <= b:
            return did
    raise ValueError(num)

# ----------------------------------------------------------------------------
# Parse das cartas
# ----------------------------------------------------------------------------
pat = re.compile(r'^\s*\d+\.\s*#(\d{3})\s*\|\s*(.+?)\s*\|\s*(.+?)\s*\|\s*(CR|SP|MG|LD)\s*\|\s*Custo\s*(\d)\s*\|\s*(\d+)\s*Pod\s*\|\s*(.*?)\s*$', re.M)
raw = {}
for m in pat.findall(txt):
    num = int(m[0])
    raw[num] = dict(num=num, name=re.sub(r'\s+', ' ', m[1]).strip(), colorcode=m[2].strip(), tcode=m[3],
                    cost=int(m[4]), power=int(m[5]), text=m[6].strip())
assert len(raw) == 300, len(raw)

COLOR = {'W': 'white', 'U': 'blue', 'B': 'black', 'R': 'red', 'G': 'green'}
def colors_of(code):
    code = code.strip()
    if code in ('MC', 'WUBRG'):
        return ['white', 'blue', 'black', 'red', 'green']
    if code in ('CL', 'LD'):
        return []
    out = []
    for part in code.split('/'):
        part = part.strip()
        if part in COLOR:
            out.append(COLOR[part])
    return out

TYPE = {'CR': 'creature', 'SP': 'spell', 'MG': 'spell', 'LD': 'land', 'EN': 'enchantment', 'EQ': 'equipment'}
SUBTYPE = {'CR': '', 'SP': 'sorcery', 'MG': 'instant', 'LD': '', 'EN': '', 'EQ': ''}

# ----------------------------------------------------------------------------
# Mapeamento de texto → efeitos
# ----------------------------------------------------------------------------
COLOR_WORDS = {
    'vermelh': 'red', 'azu': 'blue', 'pret': 'black', 'verde': 'green', 'branc': 'white',
}
def color_from_word(s):
    s = s.lower()
    for k, v in COLOR_WORDS.items():
        if k in s:
            return v
    return None

def num(s):
    return float(s.replace(',', '.'))

def parse_filter(desc):
    """desc: fragmento tipo 'carta Vermelha', 'Criatura Verde', 'Feitiço', 'carta de Custo 1', 'Terreno (LD)'."""
    f = {}
    d = desc.lower()
    c = color_from_word(d)
    if c:
        f['color'] = c
    if 'criatura' in d:
        f['type'] = 'creature'
    elif 'feitiço' in d or 'mágica' in d or 'feitico' in d:
        f['type'] = 'spell'
    elif 'terreno' in d:
        f['type'] = 'land'
    elif 'incolor' in d:
        f['colorless'] = True
    elif 'artefacto' in d:
        f['colorless'] = True
    m = re.search(r'custo (\d)(?: ou (\d))?', d)
    if m:
        if m.group(2):
            f['cost_min'] = int(m.group(1)); f['cost_max'] = int(m.group(2))
        else:
            f['cost'] = int(m.group(1))
    m = re.search(r'mais de (\d+) de poder', d)
    if m:
        f['power_min'] = int(m.group(1)) + 1
    m = re.search(r'(\d+)\+ de poder', d)
    if m:
        f['power_min'] = int(m.group(1))
    return f

def zone_of(desc):
    d = desc.lower()
    if 'cemitério' in d or 'cemiterio' in d:
        return 'graveyard'
    if 'na mão' in d or 'na tua mão' in d:
        return 'hand'
    if 'grimório' in d:
        return 'library'
    if 'jogad' in d or 'nesta mão' in d or 'na mesma mão' in d or 'na jogada' in d:
        return 'played'
    if 'na arena' in d or 'atacante' in d:
        return 'attacker'
    return None

def make_per(clause):
    """Devolve (per_dict, clause_sem_por_cada) ou (None, clause)."""
    m = re.search(r'por cada (?:outra |outro )?(.+?)(?:\.|$|;| e dá| e \+| \(até)', clause, re.I)
    if not m:
        return None, clause
    desc = m.group(1).strip()
    per = {}
    d = desc.lower()
    other = 'outra' in clause.lower()[max(0, m.start()-1):m.end()] or ' outra ' in d or ' outro ' in d
    mdiv = re.match(r'(\d+)\s*(🪙|cartas no cemitério|de poder da maior criatura|feitiços/mágicas jogados)', d)
    if mdiv:
        per['per_div'] = int(mdiv.group(1))
    if '🪙' in d or 'ouro' in d:
        per['of'] = 'gold'
    elif 'cor diferente' in d or 'cores diferentes' in d or 'cor presente' in d:
        per['of'] = 'colors'
    elif 'tipo diferente' in d:
        per['of'] = 'graveyard_types'
    elif 'slot de artefacto' in d or 'artefacto no topo' in d or 'artefactos' in d and 'topo' in d:
        per['of'] = 'relics'
    elif 'carta comprada' in d:
        per['of'] = 'drawn_this_turn'
    elif 'de poder da maior' in d:
        per['of'] = 'max_power'
    elif 'carta que tens na mão' in d or 'carta na mão' in d or 'carta que ficou retida' in d or 'carta não jogada' in d:
        per['of'] = 'hand'
    elif 'cemitério' in d:
        per['of'] = 'graveyard'
        f = parse_filter(desc)
        f.pop('type', None) if 'carta no' in d else None
        if f: per['filter'] = f
    elif 'feitiço' in d or 'mágica' in d:
        per['of'] = 'spell'
        f = parse_filter(desc); f.pop('type', None)
        if 'mágica' in d and 'feitiço' not in d:
            f['subtype'] = 'instant'
        if f: per['filter'] = f
    elif 'criatura' in d:
        per['of'] = 'attacker'
        f = parse_filter(desc); f.pop('type', None)
        if f: per['filter'] = f
    elif 'terreno' in d:
        per['of'] = 'land_hand' if 'mão' in d else 'graveyard' if 'cemitério' in d else 'land_hand'
    elif 'carta' in d:
        per['of'] = 'played'
        f = parse_filter(desc)
        if f: per['filter'] = f
    else:
        return None, clause
    if other:
        per['exclude_self'] = True
    mcap = re.search(r'até \+(\d+) Mult', clause)
    if mcap:
        per['cap'] = int(mcap.group(1))
    rest = clause[:m.start()] + clause[m.end():]
    return per, rest

FORMATIONS = {
    'bando tribal': 'band', 'devoção pura': 'devotion', 'pacto dual': 'pair', 'par': 'pair', 'dois pares': 'pair',
    'tríade': 'trips', 'tríade de custo': 'trips', 'curva de mana': 'curve', 'tempestade arcana': 'storm',
    'convergência prismática': 'wubrg', 'convergência': 'wubrg',
}

def parse_condition(clause):
    """Extrai uma condição ('se ...') do clause. Devolve (cond, clause_sem_cond)."""
    cond = {}
    low = clause.lower()
    # posição
    if re.search(r'1ª carta|posição 1\b|primeira carta', low):
        cond['position'] = 'first'
    elif re.search(r'posição 5|5ª carta|\(direita\)', low):
        cond['position'] = 'last'
    if 'posição 1 ou 5' in low:
        cond['position'] = 'edge'
    m = re.search(r'\bse\b (.+)$', clause, re.I)
    if not m:
        return cond, clause
    c = m.group(1).lower()
    rest = clause[:m.start()].rstrip(' ,;')
    if re.match(r'(estiver na posição|for a 1ª carta|estiver na 1ª)', c) and cond.get('position'):
        m3 = re.search(r'[,:]\s*(.+)$', c)
        return cond, (rest + ' ' + (m3.group(1) if m3 else '')).strip()
    # "se X, dá Y" / "se X: Y" — a ação vem depois da condição
    m2 = re.search(r'[,:]\s*((?:dá|ganha|recebe|ainda pontua|reativa|ativa|duplica|compra|envia|destrói|silencia|puxa|\+|×).+)$', c)
    if m2:
        rest = (rest + ' ' + m2.group(1)).strip()
        c = c[:m2.start()].strip()
    # formações
    forms = [v for k, v in FORMATIONS.items() if k in c and ('formação' in c or 'jogares' in c or 'atacares' in c or 'formar' in c or 'contiver' in c or 'formares' in c)]
    if forms:
        cond['formation'] = sorted(set(forms))
        return cond, rest
    if 'todas as cartas jogadas' in c and 'custo 1' in c:
        cond['all_cost'] = 1; return cond, rest
    mm = re.search(r'grimório tiver (\d+) ou menos', c)
    if mm: cond['library_max'] = int(mm.group(1)); return cond, rest
    mm = re.search(r'grimório tiver menos de (\d+)', c)
    if mm: cond['library_max'] = int(mm.group(1)) - 1; return cond, rest
    if 'grimório tiver 2 ou menos' in c: cond['library_max'] = 2; return cond, rest
    if '0 canalizações' in c: cond['discards_max'] = 0; return cond, rest
    if 'tiveres 1 ou 0 cartas na mão' in c: cond['hand_max'] = 1; return cond, rest
    if 'destruíste uma carta' in c: cond['discarded_min'] = 1; return cond, rest
    if 'tiveres ouro' in c: cond['gold_min'] = 1; return cond, rest
    mm = re.search(r'atacar com mais (\d+) criaturas', c)
    if mm: cond['count'] = {'of': 'attacker', 'min': int(mm.group(1)) + 1}; return cond, rest
    mm = re.search(r'jogado junto com pelo menos (\d+) cartas incolores', c)
    if mm: cond['count'] = {'of': 'played', 'filter': {'colorless': True}, 'min': int(mm.group(1))}; return cond, rest
    if 'central e torre na mão' in c: cond['hand_has'] = ['c271', 'c272']; return cond, rest
    if 'mina e torre na mão' in c: cond['hand_has'] = ['c270', 'c272']; return cond, rest
    if 'mina e central na mão' in c: cond['hand_has'] = ['c270', 'c271']; return cond, rest
    if 'nenhuma carta na mão' in c or 'mão estiver vazia' in c or 'mão vazia' in c:
        cond['hand_max'] = 0; return cond, rest
    if '1 ou 0 cartas na mão' in c: cond['hand_max'] = 1; return cond, rest
    if 'única carta na tua mão' in c: cond['hand_max'] = 1; return cond, rest
    mm = re.search(r'tiveres (\d+)\+? ?(?:ou mais )?🪙', c) or re.search(r'mais de (\d+) 🪙', c)
    if mm: cond['gold_min'] = int(mm.group(1)) + (1 if 'mais de' in c else 0); return cond, rest
    mm = re.search(r'tiveres (\d+) ou mais 🪙', c)
    if mm: cond['gold_min'] = int(mm.group(1)); return cond, rest
    if 'boss' in c and ('50%' in c or '< 50' in c):
        cond['enemy_hp_below_pct'] = 50; return cond, rest
    if 'já usaste canalizar' in c: cond['discarded_min'] = 1; return cond, rest
    if 'não descartaste' in c: cond['discarded_max'] = 0; return cond, rest
    if 'nenhuma carta colorida' in c:
        cond['count'] = {'of': 'attacker', 'filter': {'colored': True}, 'max': 0}; return cond, rest
    if 'exatamente 5 cartas' in c: cond['count'] = {'of': 'attacker', 'min': 5}; return cond, rest
    if 'exatamente 1 ou 2 cartas' in c or 'apenas 1 ou 2 cartas' in c:
        cond['count'] = {'of': 'played', 'max': 2}; return cond, rest
    if '4ª ou 5ª carta' in c: cond['count'] = {'of': 'spell', 'min': 4}; return cond, rest
    mm = re.search(r'terreno.*no cemitério', c)
    if mm: cond['count'] = {'of': 'graveyard', 'filter': {'type': 'land'}, 'min': 1}; return cond, rest
    mm = re.search(r'cemitério tiver (\d+)\+? ?(?:ou mais )?cartas', c) or re.search(r'cemitério tiver (\d+)\+', c)
    if mm: cond['count'] = {'of': 'graveyard', 'min': int(mm.group(1))}; return cond, rest
    mm = re.search(r'tiveres (\d+) ou mais cartas no cemitério', c)
    if mm: cond['count'] = {'of': 'graveyard', 'min': int(mm.group(1))}; return cond, rest
    if 'feitiços e criaturas no cemitério' in c: cond['count'] = {'of': 'graveyard', 'min': 2}; return cond, rest
    mm = re.search(r'pelo menos (\d+) terrenos na mão', c)
    if mm: cond['count'] = {'of': 'land_hand', 'min': int(mm.group(1))}; return cond, rest
    if 'terreno' in c and 'na mão' in c: cond['count'] = {'of': 'land_hand', 'min': 1}; return cond, rest
    mm = re.search(r'(\d+)\+? ?(?:ou mais )?cores', c) or re.search(r'(\d+) ou mais cores', c)
    if mm and 'cores' in c: cond['count'] = {'of': 'colors', 'min': int(mm.group(1))}; return cond, rest
    if 'ao lado' in c:
        col = color_from_word(c)
        if col: cond['neighbor_color'] = col; return cond, rest
        mm = re.search(r'pelo menos (\d+) criaturas', c)
        if mm: cond['count'] = {'of': 'attacker', 'min': int(mm.group(1))}; return cond, rest
        if 'custo 5' in c: cond['neighbor_cost'] = 5; return cond, rest
    if 'entre duas criaturas' in c: cond['neighbors_min'] = 2; return cond, rest
    mm = re.search(r'controlares uma criatura com (\d+)\+', c)
    if mm: cond['count'] = {'of': 'attacker', 'filter': {'power_min': int(mm.group(1))}, 'min': 1}; return cond, rest
    mm = re.search(r'(?:houver )?(?:outra|outro) (?:carta de |criatura )?(.+?) na arena', c)
    if mm:
        f = parse_filter(mm.group(1)); f.pop('type', None)
        cond['count'] = {'of': 'attacker', 'filter': f, 'min': 2}; return cond, rest
    mm = re.search(r'houver (?:uma |um )?(.+?) na arena', c)
    if mm:
        f = parse_filter(mm.group(1)); f.pop('type', None)
        cond['count'] = {'of': 'attacker', 'filter': f, 'min': 1}; return cond, rest
    mm = re.search(r'jogares (?:outro|outra) custo (\d)', c)
    if mm: cond['count'] = {'of': 'played', 'filter': {'cost': int(mm.group(1))}, 'min': 2}; return cond, rest
    mm = re.search(r'formar par com outra carta de custo (\d)', c)
    if mm: cond['count'] = {'of': 'played', 'filter': {'cost': int(mm.group(1))}, 'min': 2}; return cond, rest
    mm = re.search(r'(?:jogares|atacares com|houver|tiveres|a arena tiver|a mão conter|jogada ao lado de)\s*(?:pelo menos |com )?(\d+)\s*(?:\+|ou mais)?\s*(.*?)(?:\s+nesta mão|\s+na mesma mão|\s+na arena|\s+juntas|\s*$)', c)
    if mm:
        f = parse_filter(mm.group(2))
        of = 'spell' if f.get('type') == 'spell' else 'attacker' if f.get('type') == 'creature' else 'played'
        f.pop('type', None)
        cond['count'] = {'of': of, 'min': int(mm.group(1))}
        if f: cond['count']['filter'] = f
        return cond, rest
    mm = re.search(r'(?:a mão conter|jogares|na mesma mão.*?)\s*([a-zçã]+) e ([a-zçã]+)', c)
    if mm and color_from_word(mm.group(1)) and color_from_word(mm.group(2)):
        cond['colors_all'] = [color_from_word(mm.group(1)), color_from_word(mm.group(2))]; return cond, rest
    mm = re.search(r'(?:a mão conter|jogares|jogares cartas|jogares verde ou branco|cartas) ([a-zçã]+) ou ([a-zçã]+)', c)
    if mm and color_from_word(mm.group(1)):
        cond['colors_any'] = [color_from_word(mm.group(1)), color_from_word(mm.group(2))]; return cond, rest
    if 'pelo menos uma carta u, uma b e uma r' in c:
        cond['colors_all'] = ['blue', 'black', 'red']; return cond, rest
    if 'jogares 5 cores' in c: cond['formation'] = ['wubrg']; return cond, rest
    if 'jogado numa convergência' in c: cond['formation'] = ['wubrg']; return cond, rest
    if 'jogar uma carta de custo 4 ou 5' in c or 'jogares uma carta de custo 4 ou 5' in c:
        cond['count'] = {'of': 'played', 'filter': {'cost_min': 4}, 'min': 1}; return cond, rest
    if 'houver 4 ou mais criaturas' in c:
        cond['count'] = {'of': 'attacker', 'min': 4}; return cond, rest
    if 'tiveres 4+ cartas na mão' in c:
        cond['count'] = {'of': 'hand', 'min': 4}; return cond, rest
    if 'a carta à direita tiver custo 3' in c: cond['right_cost'] = 3; return cond, rest
    if 'houver uma carta de custo 2 na arena' in c: cond['count'] = {'of': 'attacker', 'filter': {'cost': 2}, 'min': 1}; return cond, rest
    if 'houver uma carta de custo 3 na arena' in c: cond['count'] = {'of': 'attacker', 'filter': {'cost': 3}, 'min': 1}; return cond, rest
    if 'houver outro feitiço à direita' in c: cond['has_right'] = True; return cond, rest
    if 'mão só tiver cartas incolores' in c: cond['hand_all_colorless'] = True; return cond, rest
    if 'for destruída' in c or 'for descartad' in c:
        cond['_trigger'] = 'on_discard'; return cond, rest
    return {'_unknown': c}, rest

IMMEDIATE_ACTIONS = {'draw', 'gold', 'mill', 'discard_random', 'silence_enemy', 'extra_turn', 'discard_plus',
                     'shuffle_graveyard', 'enemy_max_hp_pct', 'recover', 'tutor_land', 'tutor_strongest',
                     'tutor_creature', 'grow_self', 'grow_hand', 'grow_left', 'grow_board', 'destroy_left',
                     'destroy_right', 'consume_discard', 'mill_half', 'enemy_vulnerable', 'grow_mult_self'}

def parse_actions(clause, card):
    """Extrai ações numéricas e especiais de um clause. Devolve lista de dicts (sem per/cond) e notas."""
    acts = []
    notes = []
    c = clause
    low = c.lower()
    # Ações especiais primeiro
    for pattern, act in [
        (r'reativa (?:a |o )?(?:criatura|carta|mágica|feitiço)[^.;]*?à (?:sua )?esquerda', ('retrigger', 'left')),
        (r'reativa (?:a |o )?(?:criatura|carta|mágica|feitiço)[^.;]*?à (?:sua )?direita', ('retrigger', 'right')),
        (r'a carta à sua esquerda ativa 2 vezes', ('retrigger', 'left')),
        (r'reativa a si mesma', ('retrigger', 'self')),
        (r'ativa 2 vezes', ('retrigger', 'self')),
        (r'ativa(?:m)? o seu poder base 2 vezes', ('retrigger', 'all')),
        (r'reativa todos os teus artefactos', ('retrigger', 'relics')),
        (r'reativa a carta que estiver na posição 1', ('retrigger', 'first')),
        (r'reativa todas as cartas de custo 2 ou 3', ('retrigger', 'all')),
        (r'reativa toda a mão', ('retrigger', 'all')),
        (r'reativa todos os efeitos \[na mão\]', ('retrigger', 'hand')),
        (r'reativa (?:qualquer|o) feitiço', ('retrigger', 'last_spell')),
        (r'reativa esse feitiço', ('retrigger', 'last_spell')),
        (r'ativa também 1 feitiço aleatório que esteja no teu cemitério', ('cascade_library', 'graveyard_spell')),
        (r'ativa automaticamente o efeito da carta no topo do teu grimório', ('cascade_library', 'top')),
        (r'ativa em cascata 1 carta extra do topo do grimório', ('cascade_library', 'top')),
        (r'puxa a maior criatura do teu grimório e ativa-a', ('cascade_library', 'strongest')),
        (r'copia a habilidade da carta que estiver à sua direita', ('retrigger', 'right')),
        (r'copia o multiplicador da carta à sua esquerda', ('retrigger', 'left')),
        (r'copia a habilidade de qualquer carta na arena', ('retrigger', 'best')),
        (r'duplica os valores base da formação', ('retrigger', 'formations')),
        (r'todas as habilidades das criaturas ativam uma 2ª vez', ('retrigger', 'all')),
        (r'cada feitiço/mágica nesta mão ativa \+1 vez', ('retrigger', 'spells')),
        (r'duplica o poder base atual desta carta', ('power_double_self', None)),
        (r'duplica \(×2\) o multiplicador final', ('mult_mul', 2.0)),
        (r'duplica o dano final \(×2\)', ('mult_mul', 2.0)),
        (r'ignora a restrição do boss|silencia o boss|anula a habilidade do boss|remove a regra do boss|imune a (?:todas as )?regras de boss|impede que o boss anule', ('silence_enemy', 1)),
        (r'\+1 turno extra|dá \+1 turno', ('extra_turn', 1)),
        (r'\+1 canalização', ('discard_plus', 1)),
        (r'consome 1 canalização', ('consume_discard', 1)),
        (r'baralha o cemitério no grimório', ('shuffle_graveyard', 1)),
        (r'reduz o hp máximo do boss em (\d+)%', ('enemy_max_hp_pct', 'g1')),
        (r'rouba (\d+)% do hp do boss como poder', ('power_pct_enemy', 'g1')),
        (r'faz o boss receber ×([\d.,]+) de dano extra', ('enemy_vulnerable', 'g1')),
        (r'envia metade do teu grimório', ('mill_half', 1)),
        (r'envia (?:as )?(\d+) cartas? do (?:topo do )?grimório', ('mill', 'g1')),
        (r'envia (\d+) cartas ao cemitério', ('mill', 'g1')),
        (r'duplica o seu poder', ('power_double_self', None)),
        (r'ativa todos os terrenos na tua mão 2 vezes', ('retrigger', 'hand')),
        (r'envia \+?(\d+) cartas do grimório', ('mill', 'g1')),
        (r'envia (\d+) do grimório', ('mill', 'g1')),
        (r'envia 1 carta do grimório ao cemitério por turno', ('mill', 1)),
        (r'descarta (\d+) cartas? (?:aleatória |da mão |da tua mão )?', ('discard_random', 'g1')),
        (r'destrói 1 carta (?:aleatória|fraca)[^.;]*mão', ('discard_random', 1)),
        (r'destrói a (?:carta|criatura) à (?:sua )?esquerda', ('destroy_left', 1)),
        (r'destrói a carta à (?:sua )?direita', ('destroy_right', 1)),
        (r'devolve (?:até )?(\d+) cartas? do cemitério', ('recover', 'g1')),
        (r'devolve 1 mágica', ('recover', 1)),
        (r'puxa 1 terreno', ('tutor_land', 1)),
        (r'puxa a carta mais forte do teu grimório', ('tutor_strongest', 1)),
        (r'puxa 1 criatura de poder', ('tutor_creature', 1)),
        (r'compra (\d+) cartas?', ('draw', 'g1')),
        (r'ganha \+(\d+) 🪙|\+(\d+) 🪙', ('gold', 'g1')),
        (r'custa 1 🪙', ('gold', -1)),
    ]:
        m = re.search(pattern, low)
        if m:
            name, val = act
            if val == 'g1':
                g = [x for x in m.groups() if x]
                val = num(g[0]) if g else 1
            acts.append({'action': name, 'value': val})
            low = low[:m.start()] + ' ' + low[m.end():]
    # crescimento permanente
    for m in re.finditer(r'\+(\d+) pod permanente', low):
        v = int(m.group(1))
        seg = low[max(0, m.start()-60):m.end()+60]
        if 'à sua esquerda' in seg or 'à criatura à sua esquerda' in seg or 'à esquerda' in seg:
            acts.append({'action': 'grow_left', 'value': v})
        elif 'na tua mão' in seg or 'cartas na mão' in seg or 'criaturas na tua mão' in seg:
            acts.append({'action': 'grow_hand', 'value': v})
        elif 'todas as outras' in seg or 'a todas as outras cartas' in seg:
            acts.append({'action': 'grow_board', 'value': v, 'exclude_self': True})
        elif 'todas as' in seg and 'arena' in seg:
            acts.append({'action': 'grow_board', 'value': v})
        elif 'criaturas verdes jogadas ganham' in seg:
            acts.append({'action': 'grow_played', 'value': v, 'filter': {'color': 'green'}})
        else:
            acts.append({'action': 'grow_self', 'value': v})
    low = re.sub(r'\+\d+ pod permanente(?:mente)?', ' ', low)
    m = re.search(r'ganha \+(\d+) pod permanentemente', low)
    if m:
        acts.append({'action': 'grow_self', 'value': int(m.group(1))}); low = low[:m.start()] + low[m.end():]
    m = re.search(r'\+(\d+) mult permanente', low)
    if m:
        acts.append({'action': 'grow_mult_self', 'value': int(m.group(1))}); low = low[:m.start()] + low[m.end():]
    # numéricas
    for m in re.finditer(r'×\s*([\d.,]+)(?:\s*mult)?', low):
        acts.append({'action': 'mult_mul', 'value': num(m.group(1))})
    for m in re.finditer(r'\+\s*(\d+)\s*mult', low):
        acts.append({'action': 'mult_add', 'value': int(m.group(1))})
    for m in re.finditer(r'\+\s*(\d+)\s*pod', low):
        acts.append({'action': 'power_add', 'value': int(m.group(1))})
    for m in re.finditer(r'-(\d+)\s*mult', low):
        acts.append({'action': 'mult_add', 'value': -int(m.group(1))})
    return acts, notes

TARGET_PATTERNS = [
    (r'às cartas adjacentes', {'per': {'of': 'neighbors'}}),
    (r'a todas as (?:tuas )?criaturas (?:na arena|nesta jogada)|todas as criaturas (?:na arena |nesta jogada |jogadas nesta mão )?ganham', {'per': {'of': 'attacker'}}),
    (r'todas as criaturas brancas nesta jogada dão', {'per': {'of': 'attacker', 'filter': {'color': 'white'}}}),
    (r'todas as mágicas e feitiços nesta jogada dão', {'per': {'of': 'spell'}}),
    (r'a todas as cartas jogadas nesta mão|a todas as cartas na arena|a todas as (?:tuas )?jogadas', {'per': {'of': 'played'}}),
    (r'a todas as cartas pretas na arena', {'per': {'of': 'played', 'filter': {'color': 'black'}}}),
    (r'a todas as cartas de custo 4 ou 5 na arena', {'per': {'of': 'attacker', 'filter': {'cost_min': 4}}}),
    (r'para cartas pretas e vermelhas', {}),
    (r'para cartas u, b ou r', {}),
    (r'a cartas incolores', {}),
    (r'a formações de bando tribal', {'cond': {'formation': ['band']}}),
    (r'à criatura à direita', {'cond': {'has_right': True}}),
    (r'criaturas jogadas nesta mão ganham', {'per': {'of': 'attacker'}}),
    (r'todas as criaturas incolores ganham', {'per': {'of': 'attacker', 'filter': {'colorless': True}}}),
    (r'sempre que uma mágica ou feitiço ativa', {'per': {'of': 'spell'}}),
    (r'sempre que uma carta é destruída ou descartada', {'per': {'of': 'discards_used'}}),
    (r'por cada carta no cemitério e dá', {'per': {'of': 'graveyard'}}),
]

def map_text(card):
    text = card['text']
    effects = []
    notes = []
    approx = False
    flags = {}
    in_hand = text.startswith('[Na Mão')
    body = re.sub(r'^\[Na Mão(?: ou Arena)?\]\s*', '', text)
    low = body.lower()
    # flags "conta como"
    if 'conta como qualquer cor' in low or 'conta como todas as 5 cores' in low or 'conta como qualquer cor que falte' in low:
        flags['wild_color'] = True
    if 'conta como qualquer custo' in low or 'conta como custo 1 ou custo 5' in low or 'conta como custo 1 ou' in low or 'preenche 1 custo em falta' in low:
        flags['wild_cost'] = True
    if 'conta como 2 criaturas' in low:
        flags['counts_as_two'] = True
    if 'conta como criatura e como' in low or 'conta como criatura e como feitiço' in low or 'conta como criatura e como mágica' in low:
        flags['counts_as'] = ['creature', 'spell']
    if 'transforma qualquer mão de 5 cartas numa convergência' in low:
        flags['force_formation'] = 'wubrg'
    if 'volta para o grimório em vez do cemitério' in low:
        flags['return_to_library'] = True
    clauses = [s.strip() for s in re.split(r';|\.\s+(?=[A-ZÁÉÍÓÚ+×])', body) if s.strip()]
    for clause in clauses:
        cl = clause.rstrip('.!')
        per, rest = make_per(cl)
        cond, rest2 = parse_condition(rest)
        extra = {}
        for pat_, add in TARGET_PATTERNS:
            if re.search(pat_, rest2.lower()):
                extra.update(add)
        acts, _ = parse_actions(rest2, card)
        unknown = cond.pop('_unknown', None)
        trig_override = cond.pop('_trigger', None)
        if not acts:
            if any(k in cl.lower() for k in ('conta como', 'proteção', 'impede debuffs', 'imune', 'ignora reduções', 'transforma', 'ajusta o custo', 'converte o custo', 'muda a cor', 'volta para o grimório', 'preenche 1 custo', 'ativam para qualquer cor')):
                pass
            else:
                notes.append(cl)
                approx = True
            continue
        if unknown:
            notes.append('cond? ' + unknown); approx = True
        for a in acts:
            e = dict(a)
            if per and a['action'] in ('mult_add', 'power_add', 'mult_mul'):
                e['per'] = per['of']
                if 'filter' in per: e['filter'] = per['filter']
                if 'per_div' in per: e['per_div'] = per['per_div']
                if 'cap' in per: e['cap'] = per['cap']
                if per.get('exclude_self'): e['exclude_self'] = True
            elif 'per' in extra and a['action'] in ('mult_add', 'power_add'):
                e['per'] = extra['per']['of']
                if 'filter' in extra['per']: e['filter'] = extra['per']['filter']
            cnd = dict(cond)
            if 'cond' in extra: cnd.update(extra['cond'])
            if cnd: e['cond'] = cnd
            # trigger
            if trig_override:
                e['trigger'] = trig_override
            elif in_hand:
                e['trigger'] = 'in_hand'
            elif card['tcode'] == 'CR':
                e['trigger'] = 'on_play' if a['action'] in IMMEDIATE_ACTIONS else 'on_attack'
            elif card['tcode'] == 'LD':
                e['trigger'] = 'in_hand'
            else:
                e['trigger'] = 'on_cast'
            effects.append(e)
    return effects, approx, notes, flags

# ----------------------------------------------------------------------------
# Overrides à mão (baralhos 1–5 e casos especiais)
# ----------------------------------------------------------------------------
def E(trigger, action, value=None, **kw):
    e = {'trigger': trigger, 'action': action}
    if value is not None: e['value'] = value
    e.update(kw); return e

OVERRIDES = {
  1: [E('on_attack','mult_add',4), E('on_attack','power_add',20, cond={'position':'first'})],
  2: [E('on_cast','mult_add',6), E('on_cast','mult_add',4, per='played', filter={'cost':1}, exclude_self=True)],
  3: [E('on_attack','mult_mul',1.5, cond={'count':{'of':'played','filter':{'color':'red'},'min':3}})],
  4: [E('on_cast','mult_add',8)],
  5: [E('on_attack','mult_add',5, per='spell')],
  6: [E('on_cast','mult_mul',2, cond={'library_max':2})],
  7: [E('on_attack','mult_add',10, cond={'all_cost':1})],
  8: [E('in_hand','mult_mul',1.5, cond={'count':{'of':'played','filter':{'cost':1},'min':3}})],
  9: [E('on_cast','mult_add',3), E('on_cast','draw',1)],
  10:[E('on_attack','retrigger','last_spell')],
  11:[E('on_cast','power_add',50), E('on_cast','mult_add',4, per='hand')],
  12:[E('on_cast','silence_enemy',1), E('on_cast','mult_mul',1.5)],
  13:[E('on_attack','power_add',15, per='spell', filter={'subtype':'instant'})],
  14:[E('on_cast','shuffle_graveyard',1), E('on_cast','mult_mul',2)],
  15:[E('on_attack','mult_add',6, per='played', filter={'color':'blue'})],
  16:[E('on_cast','mult_mul',2.5, cond={'count':{'of':'spell','min':4}})],
  17:[E('in_hand','power_add',30, cond={'formation':['storm']}), E('in_hand','mult_mul',1.3, cond={'formation':['storm']})],
  18:[E('on_cast','mult_add',8)],
  19:[E('on_attack','mult_add',6), E('on_attack','mult_mul',2, cond={'discards_max':0})],
  20:[E('on_play','consume_discard',1), E('on_attack','mult_add',12, cond={'consumed':True})],
  21:[E('on_cast','power_add',30), E('on_cast','mult_add',5), E('on_cast','draw',1)],
  22:[E('on_play','discard_random',1), E('on_attack','mult_mul',1.8)],
  23:[E('on_cast','retrigger','last_creature')],
  24:[E('on_play','discard_random',1), E('on_attack','mult_mul',2)],
  25:[E('on_cast','mult_add',4, per='played', filter={'color':'black'})],
  26:[E('on_attack','mult_mul',3, cond={'hand_max':0})],
  27:[E('in_hand','mult_mul',1.6, cond={'count':{'of':'played','filter':{'color':'black'},'min':3}})],
  28:[E('on_play','grow_self',15)],
  29:[E('on_cast','grow_left',20), E('on_cast','mult_add',4)],
  30:[E('on_attack','mult_add',4), E('on_play','grow_mult_self',0.5)],
  31:[E('on_attack','power_double_self',1)],
  32:[E('on_attack','power_add',50, cond={'count':{'of':'attacker','filter':{'color':'green'},'min':2}})],
  33:[E('on_cast','mult_add',3, per='attacker', filter={'power_min':41})],
  34:[E('on_attack','mult_mul',1.5, per='attacker', filter={'color':'green'})],
  35:[E('on_cast','power_add',15), E('on_cast','mult_add',2, per='played', filter={'color':'green'})],
  36:[E('on_play','grow_hand',8)],
  37:[E('on_play','grow_self',25), E('on_attack','mult_mul',1.5)],
  38:[E('in_hand_on_play','grow_played',10, filter={'color':'green'})],
  39:[E('on_attack','power_add',20, per='attacker', exclude_self=True)],
  40:[E('on_attack','mult_add',3, per='attacker')],
  41:[E('on_attack','mult_add',6, cond={'count':{'of':'played','filter':{'cost':2},'min':2}})],
  42:[E('on_cast','mult_add',4, per='attacker', filter={'color':'white'})],
  43:[E('on_attack','mult_mul',1.5, cond={'formation':['band','devotion']})],
  44:[E('on_attack','retrigger','left', filter={'color':'white'})],
  45:[E('on_cast','mult_add',8, cond={'count':{'of':'attacker','min':3}})],
  46:[E('on_attack','mult_mul',2, cond={'count':{'of':'attacker','min':4}})],
  47:[E('on_attack','mult_add',4), E('on_attack','power_add',15, per='neighbors')],
  48:[E('on_attack','mult_add',5), E('on_play','silence_enemy',1)],
  49:[E('on_cast','mult_mul',1.8)],
  50:[E('in_hand','mult_mul',1.5, cond={'count':{'of':'attacker','min':3}})],
}
OVERRIDES[183] = [E('on_attack','retrigger','all', cond={'position':'edge'})]
# Afinação (simulação): o baralho 01 e os terrenos da Forja estavam demasiado fortes.
OVERRIDES[2] = [E('on_cast','mult_add',6), E('on_cast','mult_add',2, per='played', filter={'cost':1}, exclude_self=True)]
OVERRIDES[6] = [E('on_cast','mult_mul',1.5, cond={'library_max':2})]
OVERRIDES[270] = [E('in_hand','power_add',30), E('in_hand','mult_mul',1.5, cond={'hand_has':['c271','c272']})]
OVERRIDES[271] = [E('in_hand','mult_add',5), E('in_hand','mult_mul',1.5, cond={'hand_has':['c270','c272']})]
OVERRIDES[272] = [E('in_hand','mult_mul',1.5), E('in_hand','mult_mul',2.0, cond={'hand_has':['c270','c271']})]
# Aparar os baralhos dominantes na simulação (01, 03, 05, 17).
OVERRIDES[3] = [E('on_attack','mult_mul',1.3, cond={'count':{'of':'played','filter':{'color':'red'},'min':3}})]
OVERRIDES[7] = [E('on_attack','mult_add',6, cond={'all_cost':1})]
OVERRIDES[8] = [E('in_hand','mult_mul',1.3, cond={'count':{'of':'played','filter':{'cost':1},'min':3}})]
OVERRIDES[19] = [E('on_attack','mult_add',6), E('on_attack','mult_mul',1.5, cond={'discards_max':0})]
OVERRIDES[26] = [E('on_attack','mult_mul',2.5, cond={'hand_max':0})]
OVERRIDES[27] = [E('in_hand','mult_mul',1.4, cond={'count':{'of':'played','filter':{'color':'black'},'min':3}})]
OVERRIDES[43] = [E('on_attack','mult_mul',1.3, cond={'formation':['band','devotion']})]
OVERRIDES[46] = [E('on_attack','mult_mul',1.5, cond={'count':{'of':'attacker','min':4}})]
OVERRIDES[50] = [E('in_hand','mult_mul',1.3, cond={'count':{'of':'attacker','min':3}})]
OVERRIDES[251] = [E('on_cast','mult_mul',2.0, cond={'count':{'of':'attacker','filter':{'colored':True},'max':0}})]
OVERRIDES[255] = [E('on_attack','mult_mul',1.5), E('on_play','silence_enemy',1)]
OVERRIDES[262] = [E('on_attack','mult_mul',2.0, cond={'count':{'of':'land_hand','min':2}})]
OVERRIDES[269] = [E('on_cast','mult_mul',1.8)]
# A Oficina da Tempestade precisava de ajuda: os feitiços disparam uma vez por turno.
OVERRIDES[144] = [E('on_attack','mult_add',8, per='spell')]
OVERRIDES[145] = [E('on_attack','power_add',40, per='spell')]
OVERRIDES[149] = [E('on_attack','power_add',40, cond={'count':{'of':'spell','min':2}}), E('on_attack','mult_add',6, cond={'count':{'of':'spell','min':2}})]
TEXT_OVERRIDES = {
  # 0.11.0: "Relíquia" em vez de "Artefacto" (é o nome que o jogo usa em todo o lado).
  250: 'Reativa todas as tuas Relíquias uma 2.ª vez!',
  256: '+4 Mult por cada Relíquia que tens.',
  266: '+5 Mult por cada Relíquia que tens.',
  273: '[Na Mão] ×1.5 Mult.',
  144: 'Sempre que uma Mágica ou Feitiço ativa na Arena, dá +8 Mult extra!',
  145: 'Todas as Mágicas e Feitiços nesta jogada dão +40 Pod extra.',
  149: 'Ganha +40 Pod e +6 Mult se jogares pelo menos 2 Feitiços nesta mão.',
  3: '×1.3 Mult se jogares pelo menos 3 cartas Vermelhas.',
  7: '+6 Mult se todas as cartas jogadas na mão tiverem Custo 1.',
  8: '[Na Mão] Dá ×1.3 Mult se atacares com 3+ cartas de Custo 1.',
  19: '+6 Mult; se tiveres 0 Canalizações restantes, dá ×1.5 Mult.',
  26: '×2.5 Mult se não tiveres nenhuma carta na mão após conjurar.',
  27: '[Na Mão] ×1.4 Mult se jogares 3 ou mais cartas Pretas.',
  43: '×1.3 Mult se a formação for Bando Tribal ou Devoção Pura.',
  46: '×1.5 Mult se houver 4 ou mais Criaturas na Arena.',
  50: '[Na Mão] ×1.3 Mult se jogares 3 ou mais Criaturas.',
  251: '×2 Mult se não houver nenhuma carta colorida na Arena!',
  255: '×1.5 Mult e imune a todas as regras de Boss.',
  262: '×2 Mult se tiveres pelo menos 2 Terrenos na mão!',
  269: '×1.8 Mult.',
  2: '+6 Mult; ganha +2 Mult extra por cada outra carta de Custo 1 jogada.',
  6: '×1.5 Mult se o teu Grimório tiver 2 ou menos cartas restantes.',
  270: '[Na Mão] +30 Pod; se tiveres Central e Torre na mão, dá ×1.5 Mult!',
  271: '[Na Mão] +5 Mult; se tiveres Mina e Torre na mão, dá ×1.5 Mult!',
  272: '[Na Mão] ×1.5 Mult; se tiveres Mina e Central na mão, dá ×2 Mult!',
  # 0.17.0: sem o nome do Magic que vinha no documento ("junto com Meren").
  173: 'A última Criatura enviada ao Cemitério volta a ativar o seu efeito!',
}
OVERRIDE_FLAGS = {49: {'counts_as_two': True}}

# 0.12.0 — reforço dos baralhos mais fracos com o bot novo (tests/Balance.gd --bot=smart, que joga como a
# DICA do jogo) e os dados por carta (--cards=…): Convergência Planar ganhava 2 em 8, Trono da Ruína 4 e
# Casa da Dívida 5 (os outros 6 a 8). As cartas que quase não faziam dano ganharam efeito.
OVERRIDES[300] = [E('in_hand','mult_add',4, per='colors'), E('in_hand','mult_mul',2.0, cond={'formation':['wubrg']})]
OVERRIDES[279] = [E('on_attack','mult_add',4, per='colors')]   # mantém a Convergência Prismática automática (flag)
OVERRIDES[289] = [E('on_cast','cascade_library','top'), E('on_cast','mult_add',4)]
OVERRIDES[296] = [E('on_cast','mult_add',3)]
OVERRIDE_FLAGS[296] = {'wild_color': True}                     # conta como a cor que falta para as 5 cores
OVERRIDES[241] = [E('on_cast','draw',2.0, cond={'count':{'of':'graveyard','min':4}}), E('on_cast','mult_add',6)]
OVERRIDES[228] = [E('on_attack','cascade_library','graveyard_spell'), E('on_attack','mult_add',4)]
OVERRIDES[139] = [E('on_attack','power_add',50, cond={'gold_min':6})]
OVERRIDES[127] = [E('on_cast','gold',3.0), E('on_cast','mult_mul',1.5, cond={'gold_min':8})]
OVERRIDES[143] = [E('in_hand','mult_add',1, per='gold')]
TEXT_OVERRIDES.update({
  300: '[Na Mão] +4 Mult por cada cor diferente na Arena; ×2 Mult se atacares com Convergência Prismática!',
  279: 'Transforma qualquer mão de 5 cartas numa Convergência Prismática automática; +4 Mult por cada cor diferente na Arena.',
  289: 'Ativa em cascata 1 carta extra do topo do Grimório; +4 Mult.',
  296: 'Conta como a cor que faltar para a Convergência Prismática; +3 Mult.',
  241: 'Compra 2 cartas se o Cemitério tiver 4+ cartas; +6 Mult.',
  228: 'Ao atacar, ativa também 1 Feitiço aleatório do teu Cemitério; +4 Mult.',
  139: '+50 Poder se tiveres 6 ou mais 🪙.',
  127: '+3 🪙; dá ×1.5 Mult se tiveres 8 ou mais 🪙.',
  143: '[Na Mão] Dá +1 Mult por cada 🪙 que possuas.',
})


# ----------------------------------------------------------------------------
# 0.8.0 — Recapitular (flashback) e cartas de dupla face (fora dos 18 baralhos: deck 0, chegam
# pela loja, boosters e eventos). O texto da frente diz o que a missão pede e o que a carta vira.
# ----------------------------------------------------------------------------
FLASHBACK = {2, 11, 18, 21, 29, 42, 57, 65, 79, 86, 105, 120, 141, 156, 171, 195, 211, 233, 245, 258, 284}

def X(num_, name, colors, tcode, cost, power, price, text, effects, mission, back):
    t = TYPE[tcode]
    return {
        'id': 'c%03d' % num_, 'num': num_, 'name': name, 'deck': 0, 'colors': colors, 'type': t,
        'subtype': SUBTYPE[tcode], 'cost': cost, 'power': power, 'toughness': (cost + 1) if t == 'creature' else 0,
        'rarity': 'rare', 'price': price, 'text': text, 'effects': effects, 'mission': mission, 'transformed': back,
    }

EXTRA_CARDS = [
    X(301, 'Candidato Infiltrado', ['black'], 'CR', 2, 20, 7,
      'Missão: canaliza 3 cartas com esta na mão ou na Arena. Vira em Agente Duplo: 50 Pod, ×3 Mult; as criaturas à direita ganham +15 Pod.',
      [], {'trigger': 'channel', 'count': 3},
      {'name': 'Agente Duplo', 'power': 50, 'toughness': 4, 'text': '×3 Mult. Ao virar, as criaturas à sua direita ganham +15 Pod.',
       'effects': [E('on_attack', 'mult_mul', 3.0), E('on_transform', 'buff_right', 15)]}),
    X(302, 'Aprendiz de Piromante', ['red'], 'CR', 1, 10, 6,
      'Missão: lança 3 feitiços com esta na mão ou na Arena. Vira em Mestre das Chamas: 35 Pod, +3 Mult por feitiço lançado neste turno.',
      [], {'trigger': 'spells', 'count': 3},
      {'name': 'Mestre das Chamas', 'power': 35, 'toughness': 3, 'text': '+3 Mult por feitiço lançado neste turno.',
       'effects': [E('on_attack', 'mult_add', 3, per='spell')]}),
    X(303, 'Lobo Solitário', ['green'], 'CR', 2, 20, 7,
      'Missão: joga 3 outras criaturas com esta na mão ou na Arena. Vira em Alfa da Matilha: 45 Pod, +10 Pod por criatura atacante e ×1.5 Mult.',
      [], {'trigger': 'creatures', 'count': 3},
      {'name': 'Alfa da Matilha', 'power': 45, 'toughness': 5, 'text': '+10 Pod por criatura atacante; ×1.5 Mult.',
       'effects': [E('on_attack', 'power_add', 10, per='attacker'), E('on_attack', 'mult_mul', 1.5)]}),
    X(304, 'Noviço da Capela', ['white'], 'CR', 1, 12, 6,
      'Missão: sobrevive a 2 ataques na Arena. Vira em Inquisidor Veterano: 40 Pod, +5 Mult e reativa a criatura à esquerda.',
      [], {'trigger': 'attacks', 'count': 2},
      {'name': 'Inquisidor Veterano', 'power': 40, 'toughness': 6, 'text': '+5 Mult; reativa a criatura à sua esquerda.',
       'effects': [E('on_attack', 'mult_add', 5), E('on_attack', 'retrigger', 'left')]}),
    X(305, 'Escriba das Marés', ['blue'], 'CR', 2, 15, 7,
      'Missão: fica 2 turnos na mão. Vira em Oráculo das Marés: 30 Pod, ×2 Mult com 4+ cartas na mão; compra 1 ao virar.',
      [], {'trigger': 'turns_in_hand', 'count': 2},
      {'name': 'Oráculo das Marés', 'power': 30, 'toughness': 3, 'text': '×2 Mult se tiveres 4+ cartas na mão. Ao virar, compra 1 carta.',
       'effects': [E('on_attack', 'mult_mul', 2.0, cond={'hand_min': 4}), E('on_transform', 'draw', 1)]}),
    X(306, 'Relicário Selado', [], 'SP', 1, 10, 6,
      'Missão: tem 10 ou mais ouro com esta na mão. Vira em Relicário Aberto: 40 Pod, +6 Mult e +2 ouro.',
      [], {'trigger': 'gold', 'count': 10},
      {'name': 'Relicário Aberto', 'power': 40, 'toughness': 0, 'text': '+6 Mult; +2 ouro.',
       'effects': [E('on_cast', 'mult_add', 6), E('on_cast', 'gold', 2)]}),
    X(307, 'Ovo Dracónico', ['red'], 'CR', 3, 10, 8,
      'Missão: sobrevive a 3 ataques na Arena. Vira em Dragão Nascente: 80 Pod e ×2 Mult.',
      [], {'trigger': 'attacks', 'count': 3},
      {'name': 'Dragão Nascente', 'power': 80, 'toughness': 8, 'text': '×2 Mult.',
       'effects': [E('on_attack', 'mult_mul', 2.0)]}),
    X(308, 'Cultista do Vazio', ['black'], 'MG', 2, 10, 7,
      'Missão: canaliza 2 cartas com esta na mão. Vira em Rito do Vazio: 20 Pod, ×2.5 Mult e compra 1 carta.',
      [], {'trigger': 'channel', 'count': 2},
      {'name': 'Rito do Vazio', 'power': 20, 'toughness': 0, 'text': '×2.5 Mult; compra 1 carta.',
       'effects': [E('on_cast', 'mult_mul', 2.5), E('on_cast', 'draw', 1)]}),
    # --- 0.9.0 (ideias do Top 50) ---
    X(309, 'Recruta Instável', ['red'], 'CR', 1, 15, 6,
      'Missão: lança 2 feitiços no mesmo turno com esta na mão ou na Arena. Vira em Vanguardista de Chamas: 70 Pod; reativa o último feitiço lançado.',
      [], {'trigger': 'spells_turn', 'count': 2},
      {'name': 'Vanguardista de Chamas', 'power': 70, 'toughness': 3, 'text': 'Reativa o último feitiço lançado neste turno.',
       'effects': [E('on_attack', 'retrigger', 'last_spell')]}),
    X(310, 'Sombra na Cripta', ['black'], 'CR', 1, 15, 6,
      'Missão: canaliza 3 cartas com esta na mão ou na Arena. Vira em Lorde dos Despojos: 55 Pod; +10 Pod por carta no cemitério.',
      [], {'trigger': 'channel', 'count': 3},
      {'name': 'Lorde dos Despojos', 'power': 55, 'toughness': 3, 'text': '+10 Pod por carta no teu cemitério.',
       'effects': [E('on_attack', 'power_add', 10, per='graveyard')]}),
    X(311, 'Semente Dorminhoca', ['green'], 'CR', 2, 10, 7,
      'Missão: sobrevive a 2 ataques na Arena. Vira em Ancião da Raiz Sagrada: 90 Pod; ao virar, curas 5 de vida.',
      [], {'trigger': 'attacks', 'count': 2},
      {'name': 'Ancião da Raiz Sagrada', 'power': 90, 'toughness': 6, 'text': 'Ao virar, curas 5 de vida.',
       'effects': [E('on_transform', 'heal_player', 5)]}),
    X(312, 'Juramento do Escudeiro', ['white'], 'CR', 2, 15, 7,
      'Missão: tem 5 criaturas na Arena ao mesmo tempo. Vira em General da Aliança: 60 Pod; +4 Mult por criatura atacante.',
      [], {'trigger': 'board_full', 'count': 5},
      {'name': 'General da Aliança', 'power': 60, 'toughness': 5, 'text': '+4 Mult por criatura atacante.',
       'effects': [E('on_attack', 'mult_add', 4, per='attacker')]}),
    X(313, 'Sangue do Pacto', ['black', 'red'], 'CR', 3, 25, 8,
      'Missão: perde 5 de vida nesta batalha. Vira em Demónio Corrompido: 100 Pod; ×2 Mult, mas perdes 2 de vida em cada ataque.',
      [], {'trigger': 'life_lost', 'count': 5},
      {'name': 'Demónio Corrompido', 'power': 100, 'toughness': 6, 'text': '×2 Mult; perdes 2 de vida em cada ataque.',
       'effects': [E('on_attack', 'mult_mul', 2.0), E('on_attack', 'self_damage', 2)]}),
]

# Maldições: não se jogam (tipo "curse"); só saem canalizando-as ou removendo-as na loja.
CURSES = [
    {'id': 'c314', 'num': 314, 'name': 'Maldição do Saltimbanco', 'deck': 0, 'colors': [], 'type': 'curse', 'subtype': '',
     'cost': 0, 'power': 0, 'toughness': 0, 'rarity': 'common', 'price': 0,
     'text': 'Maldição: não pode ser jogada. Ocupa espaço na mão até a canalizares; na loja podes removê-la.', 'effects': []},
]

# ----------------------------------------------------------------------------
# 0.10.0 — Fichas, tribos, encantamentos, Reforço (kicker), Reação e cartas Míticas.
# Fora dos 18 baralhos (deck 0): chegam pela loja, boosters, eventos e capítulos da História.
# As Míticas ("locked") só entram nos sorteios depois da conquista que as desbloqueia.
# ----------------------------------------------------------------------------
TOKEN_SOLDIER = {'id': 'tok_soldier', 'num': 0, 'name': 'Soldado', 'deck': 0, 'colors': ['white'], 'type': 'creature',
                 'subtype': '', 'cost': 0, 'power': 10, 'toughness': 1, 'rarity': 'token', 'price': 0,
                 'text': 'Ficha. Desaparece quando morre e no fim da batalha.', 'effects': [], 'token': True, 'tribe': 'soldier'}

# Tribos das cartas existentes (pelo número), escolhidas pelo nome/arte de cada carta.
TRIBES = {
    'goblin': [1, 3, 145, 309],
    'elf': [28, 30, 36, 93, 113, 122, 123, 172],
    'zombie': [167, 170, 178, 234, 240, 310],
    'angel': [46, 119, 135, 183, 194, 288],
    'dragon': [96, 101, 144, 146, 242, 275, 290, 291, 292, 293, 307],
    'soldier': [39, 40, 43, 44, 47, 110, 139, 169, 185, 186, 187, 189, 192, 193, 196, 199, 285, 304, 312],
    # 0.13.0: Construtos — as máquinas incolores antigas também contam (Golem Modular, Autómato de Latão…)
    'construct': [344, 386, 387, 389, 392],
}
TRIBE_OF = {n: t for t, nums in TRIBES.items() for n in nums}

def N(num_, name, colors, tcode, cost, power, rarity, text, effects, tribe=None, kicker=None, rules=None, locked=False, price=None, deck=0, keywords=None, flags=None):
    t = TYPE[tcode]
    c = {
        'id': 'c%03d' % num_, 'num': num_, 'name': name, 'deck': deck, 'colors': colors, 'type': t,
        'subtype': SUBTYPE[tcode], 'cost': cost, 'power': power if t in ('creature', 'spell', 'equipment') else 0,
        'toughness': (cost + 1) if t == 'creature' else 0, 'rarity': rarity,
        'price': price if price is not None else (3 + cost + {'common': 0, 'uncommon': 1, 'rare': 2, 'mythic': 6}[rarity]),
        'text': text, 'effects': effects,
    }
    if tribe: c['tribe'] = tribe
    if kicker: c['kicker'] = kicker
    if rules: c['rules'] = rules
    if locked: c['locked'] = True
    if keywords: c['keywords'] = keywords
    if flags: c.update(flags)
    return c

def K(cost, text, effects):
    return {'cost': cost, 'text': text, 'effects': effects}

NEW_CARDS = [
    # --- Fichas ---
    N(315, 'Chamada da Milícia', ['white'], 'SP', 2, 10, 'common',
      'Cria 2 Fichas de Soldado (10 Pod) na Arena.', [E('on_cast', 'create_token', 2)]),
    N(316, 'Capitã da Guarda', ['white'], 'CR', 3, 30, 'uncommon',
      'Ao entrar, cria 1 Ficha de Soldado. Ataque: +2 Mult por Ficha atacante.',
      [E('on_play', 'create_token', 1), E('on_attack', 'mult_add', 2, per='tokens')], tribe='soldier'),
    N(317, 'Recrutamento em Massa', ['white'], 'SP', 4, 10, 'rare',
      'Enche a Arena de Fichas de Soldado.', [E('on_cast', 'create_token', 5)]),
    N(318, 'Estandarte da Legião', ['red', 'white'], 'CR', 2, 20, 'uncommon',
      'Ataque: +15 Pod por cada outro Soldado atacante.',
      [E('on_attack', 'power_add', 15, per='attacker', filter={'tribe': 'soldier'}, exclude_self=True)], tribe='soldier'),
    N(319, 'Sacerdotisa do Sacrifício', ['black'], 'CR', 2, 20, 'uncommon',
      'Ao entrar, sacrifica uma Ficha tua e ganha +40 Pod nesta batalha.', [E('on_play', 'devour_token', 40)]),
    N(320, 'Ninhada Verdejante', ['green'], 'SP', 3, 10, 'common',
      'Cria 2 Fichas de Soldado; as tuas Fichas ganham +10 Pod nesta batalha.',
      [E('on_cast', 'create_token', 2), E('on_cast', 'buff_power', 10, filter={'token': True})]),
    # --- Tribos ---
    N(321, 'Rufia Goblin', ['red'], 'CR', 1, 15, 'common',
      'Ataque: +10 Pod por cada outro Goblin atacante.',
      [E('on_attack', 'power_add', 10, per='attacker', filter={'tribe': 'goblin'}, exclude_self=True)], tribe='goblin'),
    N(322, 'Cabecilha Goblin', ['red'], 'CR', 3, 35, 'rare',
      'Os teus Goblins custam 1 a menos. Ataque: +3 Mult por Goblin atacante.',
      [E('passive', 'cost_reduction', 1, filter={'tribe': 'goblin'}), E('on_attack', 'mult_add', 3, per='attacker', filter={'tribe': 'goblin'})], tribe='goblin'),
    N(323, 'Batedora Élfica', ['green'], 'CR', 1, 12, 'common',
      'Ao entrar, ganhas +1 mana neste turno.', [E('on_play', 'mana_now', 1)], tribe='elf'),
    N(324, 'Druida-Mor Élfica', ['green'], 'CR', 3, 30, 'rare',
      'Ataque: +4 Mult por Elfo atacante.', [E('on_attack', 'mult_add', 4, per='attacker', filter={'tribe': 'elf'})], tribe='elf'),
    N(325, 'Zombie Cambaleante', ['black'], 'CR', 1, 15, 'common',
      'Ataque: +1 Mult por cada 3 cartas no teu cemitério.', [E('on_attack', 'mult_add', 1, per='graveyard', per_div=3)], tribe='zombie'),
    N(326, 'Necromante da Horda', ['black'], 'CR', 3, 30, 'rare',
      'Ao entrar, devolve 1 carta do cemitério à mão. Ataque: +2 Mult por Zombie atacante.',
      [E('on_play', 'recover', 1), E('on_attack', 'mult_add', 2, per='attacker', filter={'tribe': 'zombie'})], tribe='zombie'),
    N(327, 'Anjo da Vigília', ['white'], 'CR', 3, 35, 'uncommon',
      'Ataque: curas 1 e +3 Mult por Anjo atacante.',
      [E('on_attack', 'heal', 1), E('on_attack', 'mult_add', 3, per='attacker', filter={'tribe': 'angel'})], tribe='angel'),
    N(328, 'Arcanjo da Redenção', ['white'], 'CR', 5, 70, 'rare',
      '×1.5 Mult; com 2 ou mais Anjos a atacar, ×2 Mult em vez disso.',
      [E('on_attack', 'mult_mul', 1.5, cond={'count': {'of': 'attacker', 'filter': {'tribe': 'angel'}, 'max': 1}}),
       E('on_attack', 'mult_mul', 2.0, cond={'count': {'of': 'attacker', 'filter': {'tribe': 'angel'}, 'min': 2}})], tribe='angel'),
    N(329, 'Cria de Dragão', ['red'], 'CR', 2, 25, 'common',
      'Ataque: +2 Mult por Dragão atacante.', [E('on_attack', 'mult_add', 2, per='attacker', filter={'tribe': 'dragon'})], tribe='dragon'),
    N(330, 'Dragão Ancestral', ['red', 'green'], 'CR', 5, 90, 'rare',
      '×1.5 Mult.', [E('on_attack', 'mult_mul', 1.5)], tribe='dragon'),
    # --- Encantamentos (ficam em jogo; máx. 2) ---
    N(331, 'Bênção da Falange', ['white'], 'EN', 2, 0, 'uncommon',
      'Encantamento. Ataque: +2 Mult por criatura atacante.', [E('on_attack', 'mult_add', 2, per='attacker')]),
    N(332, 'Maré do Saber', ['blue'], 'EN', 2, 0, 'uncommon',
      'Encantamento. Ataque: +1 Mult por carta na tua mão.', [E('on_attack', 'mult_add', 1, per='hand')]),
    N(333, 'Pacto Eterno', ['black'], 'EN', 3, 0, 'rare',
      'Encantamento. Ataque: ×1.4 Mult, mas perdes 1 de vida.', [E('on_attack', 'mult_mul', 1.4), E('on_attack', 'self_damage', 1)]),
    N(334, 'Fornalha Eterna', ['red'], 'EN', 2, 0, 'uncommon',
      'Encantamento. Ataque: +4 Mult por feitiço lançado neste turno.', [E('on_attack', 'mult_add', 4, per='spell')]),
    N(335, 'Bosque Ancestral', ['green'], 'EN', 3, 0, 'uncommon',
      'Encantamento. No início de cada turno, a criatura mais fraca na Arena ganha +8 Pod permanente.', [E('turn_start', 'grow_weakest', 8)]),
    N(336, 'Engrenagem Perpétua', [], 'EN', 3, 0, 'uncommon',
      'Encantamento. Ataque: +50 Pod.', [E('on_attack', 'power_add', 50)]),
    N(337, 'Pacto das Cores', ['red', 'white'], 'EN', 3, 0, 'rare',
      'Encantamento. Ataque: ×1.5 Mult se jogares cartas de 2 ou mais cores.', [E('on_attack', 'mult_mul', 1.5, cond={'count': {'of': 'colors', 'min': 2}})]),
    N(338, 'Estandarte Tribal', [], 'EN', 2, 0, 'rare',
      'Encantamento. Cada tribo conta com mais 1 criatura para os bónus de tribo.', [], rules=['tribe_plus']),
    # --- Reforço (kicker): paga mana extra por uma versão maior ---
    N(339, 'Rajada de Fogo', ['red'], 'SP', 2, 20, 'common',
      '+4 Mult. Reforço +2: mais +4 Mult.', [E('on_cast', 'mult_add', 4)],
      kicker=K(2, '+4 Mult extra', [E('on_cast', 'mult_add', 4)])),
    N(340, 'Visão Arcana', ['blue'], 'MG', 1, 10, 'common',
      'Compra 1 carta. Reforço +2: compra mais 1 e +3 Mult.', [E('on_cast', 'draw', 1)],
      kicker=K(2, 'compra mais 1 e +3 Mult', [E('on_cast', 'draw', 1), E('on_cast', 'mult_add', 3)])),
    N(341, 'Behemoth Desperto', ['green'], 'CR', 3, 40, 'uncommon',
      'Reforço +3: ao entrar, ganha +30 Pod permanente.', [],
      kicker=K(3, '+30 Pod permanente', [E('on_play', 'grow_self', 30)])),
    N(342, 'Arauto da Aurora', ['white'], 'CR', 2, 25, 'common',
      'Reforço +2: ao entrar, cria 2 Fichas de Soldado.', [],
      kicker=K(2, 'cria 2 Fichas de Soldado', [E('on_play', 'create_token', 2)]), tribe='soldier'),
    N(343, 'Ceifa Sombria', ['black'], 'SP', 2, 15, 'uncommon',
      '+1 Mult por carta no cemitério (máx. +12). Reforço +3: ×1.5 Mult.', [E('on_cast', 'mult_add', 1, per='graveyard', cap=12)],
      kicker=K(3, '×1.5 Mult', [E('on_cast', 'mult_mul', 1.5)])),
    N(344, 'Golem Modular', [], 'CR', 2, 30, 'uncommon',
      'Reforço +2: ataque: +2 Mult por criatura atacante.', [],
      kicker=K(2, '+2 Mult por criatura atacante', [E('on_attack', 'mult_add', 2, per='attacker')])),
    # --- Reação: lançadas quando o inimigo vai contra-atacar (uma por turno) ---
    N(345, 'Escudo da Fé', ['white'], 'MG', 1, 10, 'common',
      '+2 Mult. Reação: anula o contra-ataque deste turno.', [E('on_cast', 'mult_add', 2), E('reaction', 'prevent_counter', 1)]),
    N(346, 'Recusa Arcana', ['blue'], 'MG', 2, 10, 'uncommon',
      '+3 Mult. Reação: anula o contra-ataque e silencia o inimigo neste turno.',
      [E('on_cast', 'mult_add', 3), E('reaction', 'prevent_counter', 1), E('reaction', 'silence_enemy', 1)]),
    N(347, 'Ricochete', ['red'], 'MG', 2, 15, 'uncommon',
      'Reação: anula o contra-ataque e devolve 5% da vida máxima do inimigo como dano.',
      [E('reaction', 'prevent_counter', 1), E('reaction', 'reflect_pct', 5)]),
    N(348, 'Pacto de Sombras', ['black'], 'MG', 1, 10, 'common',
      '+2 Mult. Reação: o contra-ataque perde 3 de dano e ganhas 3 ouro.',
      [E('on_cast', 'mult_add', 2), E('reaction', 'reduce_counter', 3), E('reaction', 'gold', 3)]),
    N(349, 'Raízes Protetoras', ['green'], 'MG', 1, 20, 'common',
      'Reação: neste turno o inimigo não fere nem destrói as tuas criaturas; curas 2.',
      [E('reaction', 'protect_creatures', 1), E('reaction', 'heal_player', 2)]),
    # --- Míticas: mudam regras; desbloqueiam-se com conquistas ---
    N(350, 'Avatar da Convergência', [], 'CR', 5, 80, 'mythic',
      'Mítica. As formações ativam duas vezes.', [], rules=['double_formations'], locked=True),
    N(351, 'Arauto do Eco Eterno', ['blue'], 'CR', 4, 50, 'mythic',
      'Mítica. As relíquias ativam duas vezes.', [], rules=['relics_twice'], locked=True),
    N(352, 'Rainha das Labaredas', ['red'], 'CR', 4, 60, 'mythic',
      'Mítica. Os feitiços deste turno ativam duas vezes.', [], rules=['spells_twice'], locked=True),
    N(353, 'Ancião do Mundo', ['green'], 'CR', 5, 70, 'mythic',
      'Mítica. Todo o crescimento de Poder é a dobrar.', [], rules=['double_growth'], locked=True),
    N(354, 'Comandante da Alvorada', ['white'], 'CR', 4, 50, 'mythic',
      'Mítica. Sempre que jogas uma criatura, cria uma Ficha de Soldado. As Fichas têm +20 Pod.', [], rules=['token_engine'], tribe='soldier', locked=True),
    N(355, 'Motor do Infinito', [], 'CR', 5, 90, 'mythic',
      'Mítica. No fim da cascata, ×1.5 Mult.', [], rules=['final_mult'], locked=True),
    N(356, 'Lich da Eternidade', ['black'], 'CR', 5, 60, 'mythic',
      'Mítica. Sempre que uma criatura tua morre, curas 2 de vida.', [], rules=['counter_heals'], tribe='zombie', locked=True),
]

# 0.12.0 — expansão: Voar, Atropelar, Primeiro Golpe, cartas que dão palavras-chave, Chegada de Terreno
# (gatilho "landfall": dispara nas criaturas da Arena e nos encantamentos quando jogas um Terreno),
# Terrenos especiais (aparecem na loja; "Ao jogar" = gatilho on_play) e incolores.
def L(num_, name, colors, text, effects, rarity='uncommon', price=6):
    c = N(num_, name, colors, 'LD', 1, 0, rarity, text, effects, price=price)
    c['special_land'] = True
    return c

NEW_CARDS_0120 = [
    # --- Voar ---
    N(357, 'Grifo da Atalaia', ['white'], 'CR', 2, 20, 'common', 'Ataque: +3 Mult.', [E('on_attack', 'mult_add', 3)]),
    N(358, 'Esfinge dos Enigmas', ['blue'], 'CR', 4, 40, 'rare', 'Ataque: +2 Mult por carta na tua mão (máx. +12).',
      [E('on_attack', 'mult_add', 2, per='hand', cap=12)]),
    N(359, 'Corvo Mensageiro', ['black'], 'CR', 1, 10, 'common', 'Ao entrar, compra 1 carta.', [E('on_play', 'draw', 1)]),
    N(360, 'Dragonete Faiscante', ['red'], 'CR', 3, 30, 'uncommon', 'Ataque: +4 Mult por cada criatura com Voar.',
      [E('on_attack', 'mult_add', 4, per='attacker', filter={'keyword': 'flying'})], tribe='dragon'),
    N(361, 'Asas Emprestadas', ['blue'], 'SP', 1, 10, 'common', '+3 Mult. As tuas Criaturas ganham Voar nesta batalha.',
      [E('on_cast', 'mult_add', 3), E('on_cast', 'grant_keyword', keyword='flying', target='board')]),
    N(362, 'Pégaso da Alvorada', ['white'], 'CR', 3, 30, 'uncommon', '+3 Mult. Ao entrar, a Criatura à sua esquerda ganha Voar.',
      [E('on_attack', 'mult_add', 3), E('on_play', 'grant_keyword', keyword='flying', target='left')]),
    # --- Atropelar ---
    N(363, 'Rinoceronte Couraçado', ['green'], 'CR', 3, 45, 'common', 'Ataque: +2 Mult.', [E('on_attack', 'mult_add', 2)]),
    N(364, 'Mamute das Estepes', ['green'], 'CR', 5, 80, 'rare', '×1.5 Mult se já jogaste 3 ou mais Terrenos nesta batalha.',
      [E('on_attack', 'mult_mul', 1.5, cond={'count': {'of': 'land', 'min': 3}})]),
    N(365, 'Fúria da Manada', ['green'], 'SP', 2, 20, 'uncommon', '+4 Mult. As tuas Criaturas ganham Atropelar nesta batalha.',
      [E('on_cast', 'mult_add', 4), E('on_cast', 'grant_keyword', keyword='trample', target='board')]),
    N(366, 'Javali Sanguinário', ['red'], 'CR', 2, 30, 'common', 'Ataque: +10 Poder por cada criatura com Atropelar.',
      [E('on_attack', 'power_add', 10, per='attacker', filter={'keyword': 'trample'})]),
    N(367, 'Gigante das Pedreiras', ['red', 'green'], 'CR', 4, 60, 'uncommon', 'Ataque: +5 Mult.', [E('on_attack', 'mult_add', 5)]),
    # --- Primeiro Golpe ---
    N(368, 'Duelista do Sol', ['white'], 'CR', 1, 15, 'common', 'Ataque: +3 Mult.', [E('on_attack', 'mult_add', 3)], tribe='soldier'),
    N(369, 'Mestra de Esgrima', ['white', 'red'], 'CR', 3, 35, 'rare', 'Ataque: +3 Mult por cada criatura com Primeiro Golpe.',
      [E('on_attack', 'mult_add', 3, per='attacker', filter={'keyword': 'first_strike'})], tribe='soldier'),
    N(370, 'Lâmina Ensaiada', ['red'], 'MG', 1, 15, 'common', '+4 Mult. A 1.ª Criatura da Arena ganha Primeiro Golpe.',
      [E('on_cast', 'mult_add', 4), E('on_cast', 'grant_keyword', keyword='first_strike', target='first')]),
    N(371, 'Cavaleira do Juramento Negro', ['black'], 'CR', 2, 25, 'uncommon', '+6 Mult se for a 1.ª carta da Arena.',
      [E('on_attack', 'mult_add', 6, cond={'position': 'first'})]),
    N(372, 'Toque de Aço', ['white'], 'SP', 2, 10, 'uncommon', 'As tuas Criaturas ganham Primeiro Golpe e +10 Poder nesta batalha.',
      [E('on_cast', 'grant_keyword', keyword='first_strike', target='board'), E('on_cast', 'buff_power', 10)]),
    # --- Chegada de Terreno ---
    N(373, 'Elemental da Clareira', ['green'], 'CR', 2, 20, 'common', 'Chegada de Terreno: ganha +15 Poder nesta batalha.',
      [E('landfall', 'buff_self', 15)]),
    N(374, 'Druida das Encostas', ['green'], 'CR', 1, 10, 'common', 'Chegada de Terreno: ganhas +1 mana neste turno.',
      [E('landfall', 'mana_now', 1)], tribe='elf'),
    N(375, 'Fera do Solo Fendido', ['red', 'green'], 'CR', 3, 35, 'uncommon', 'Chegada de Terreno: ganha +20 Poder nesta batalha e ganhas 2 ouro.',
      [E('landfall', 'buff_self', 20), E('landfall', 'gold', 2)]),
    N(376, 'Oráculo das Marés', ['blue'], 'CR', 2, 20, 'uncommon', 'Chegada de Terreno: compra 1 carta.', [E('landfall', 'draw', 1)]),
    N(377, 'Colhedor da Planície', ['black'], 'CR', 3, 30, 'uncommon', 'Chegada de Terreno: devolve 1 carta do cemitério à mão.',
      [E('landfall', 'recover', 1)]),
    N(378, 'Campo Sagrado', ['white'], 'EN', 2, 0, 'uncommon', 'Chegada de Terreno: as tuas Criaturas ganham +10 Poder nesta batalha.',
      [E('landfall', 'buff_power', 10)]),
    N(379, 'Avalanche', ['red'], 'EN', 3, 0, 'rare', 'Chegada de Terreno: a vida máxima do inimigo desce 3%.',
      [E('landfall', 'enemy_max_hp_pct', 3)]),
    N(380, 'Titã da Terra Viva', ['green'], 'CR', 5, 70, 'rare', 'Ataque: +2 Mult por cada Terreno jogado nesta batalha.',
      [E('on_attack', 'mult_add', 2, per='land')]),
    # --- Terrenos especiais (aparecem na loja) ---
    L(381, 'Templo das Brumas', ['blue'], '[Na Mão] +2 Mult. Ao jogar: compra 1 carta.',
      [E('in_hand', 'mult_add', 2), E('on_play', 'draw', 1)]),
    L(382, 'Forja Subterrânea', ['red'], '[Na Mão] +20 Poder. Ao jogar: a última Criatura da Arena ganha Atropelar.',
      [E('in_hand', 'power_add', 20), E('on_play', 'grant_keyword', keyword='trample', target='left')]),
    L(383, 'Clareira dos Ventos', ['white'], '[Na Mão] +2 Mult. Ao jogar: as tuas Criaturas com Voar ganham +15 Poder nesta batalha.',
      [E('in_hand', 'mult_add', 2), E('on_play', 'buff_power', 15, filter={'keyword': 'flying'})]),
    L(384, 'Pântano dos Sussurros', ['black'], '[Na Mão] +1 Mult por cada 4 cartas no cemitério. Ao jogar: ganhas 2 ouro.',
      [E('in_hand', 'mult_add', 1, per='graveyard', per_div=4), E('on_play', 'gold', 2)]),
    L(385, 'Bosque Primordial', ['green'], '[Na Mão] +15 Poder. Ao jogar: as tuas Criaturas ganham +10 Poder nesta batalha.',
      [E('in_hand', 'power_add', 15), E('on_play', 'buff_power', 10)], rarity='rare', price=7),
    # --- Incolores ---
    N(386, 'Autómato de Latão', [], 'CR', 2, 25, 'common', 'Ataque: +2 Mult por cada cor diferente jogada nesta mão.',
      [E('on_attack', 'mult_add', 2, per='colors')]),
    N(387, 'Sentinela de Engrenagens', [], 'CR', 3, 35, 'uncommon', 'Ataque: +3 Mult.', [E('on_attack', 'mult_add', 3)]),
    N(388, 'Bússola dos Planos', [], 'EN', 1, 0, 'uncommon', 'Ataque: +1 Mult por cada Terreno jogado nesta batalha (máx. +8).',
      [E('on_attack', 'mult_add', 1, per='land', cap=8)]),
    N(389, 'Colosso de Ferro Velho', [], 'CR', 5, 85, 'rare', 'Ataque: ×1.4 Mult.', [E('on_attack', 'mult_mul', 1.4)]),
    N(390, 'Lâmpada do Viajante', [], 'EN', 2, 0, 'uncommon', 'No início de cada turno, ganhas 1 ouro.', [E('turn_start', 'gold', 1)]),
    N(391, 'Ídolo das Asas', [], 'CR', 2, 20, 'uncommon', '+2 Mult. Ao entrar, a Criatura à sua esquerda ganha Voar.',
      [E('on_attack', 'mult_add', 2), E('on_play', 'grant_keyword', keyword='flying', target='left')]),
    N(392, 'Mecanismo do Eco', [], 'CR', 4, 40, 'rare', 'Ataque: +2 Mult por cada palavra-chave nas tuas criaturas atacantes.',
      [E('on_attack', 'mult_add', 2, per='keywords')]),
]

# 0.13.0 — dois baralhos novos (19 Engrenagens, incolor, Construtos; 20 Legião Infinda, Fichas verdes e
# brancas), Fichas novas (Engrenagem, Espírito, Fera, Rebento) e 30 raras/míticas para as cores e
# arquétipos com menos opções. As Míticas ("locked") desbloqueiam-se com conquistas.
def T(tid, name, colors, power, toughness, tribe, text, effects=None, keywords=None):
    t = {'id': tid, 'num': 0, 'name': name, 'deck': 0, 'colors': colors, 'type': 'creature', 'subtype': '',
         'cost': 0, 'power': power, 'toughness': toughness, 'rarity': 'token', 'price': 0, 'text': text,
         'effects': effects or [], 'token': True, 'tribe': tribe}
    if keywords:
        t['keywords'] = keywords
    return t

TOKENS_0130 = [
    T('tok_gear', 'Engrenagem', [], 10, 1, 'construct', 'Construto. Desaparece quando morre e no fim da batalha.'),
    T('tok_spirit', 'Espírito', ['white'], 15, 1, 'spirit', 'Voar. Desaparece quando morre e no fim da batalha.', keywords=['flying']),
    T('tok_beast', 'Fera', ['green'], 20, 2, 'beast', 'Atropelar. Desaparece quando morre e no fim da batalha.', keywords=['trample']),
    T('tok_sapling', 'Rebento', ['green'], 10, 1, 'plant', 'Ataque: +2 Mult. Desaparece quando morre e no fim da batalha.',
      effects=[E('on_attack', 'mult_add', 2)]),
]

DECKS_0130 = [
    (19, 'Engrenagens', 'CL', 'Construtos em linha: cada máquina dá força à seguinte', 3),
    (20, 'Legião Infinda', 'G/W', 'Fichas: enche a Arena e multiplica-as', 2),
]
CON = {'tribe': 'construct'}

NEW_CARDS_0130 = [
    # --- Baralho 19: Engrenagens (incolor) ---
    N(393, 'Engrenagem Solta', [], 'CR', 1, 15, 'common', 'Ao entrar, cria 1 Engrenagem (Ficha de 10 Poder).',
      [E('on_play', 'create_token', 1, token='tok_gear')], tribe='construct', deck=19),
    N(394, 'Autómato Aprendiz', [], 'CR', 1, 20, 'common', 'Ataque: +2 Mult por cada Construto atacante.',
      [E('on_attack', 'mult_add', 2, per='attacker', filter=CON)], tribe='construct', deck=19),
    N(395, 'Biela de Bronze', [], 'CR', 2, 25, 'uncommon', 'Ataque: reativa o Construto à sua direita.',
      [E('on_attack', 'retrigger', 'right', filter=CON)], tribe='construct', deck=19),
    N(396, 'Linha de Montagem', [], 'SP', 2, 15, 'common', 'Cria 2 Engrenagens.',
      [E('on_cast', 'create_token', 2, token='tok_gear')], deck=19),
    N(397, 'Ferreiro Mecânico', [], 'CR', 2, 20, 'uncommon', 'Ao entrar, os teus Construtos crescem +10 Poder permanente.',
      [E('on_play', 'grow_board', 10, filter=CON)], tribe='construct', deck=19),
    N(398, 'Regulador de Pressão', [], 'EN', 2, 0, 'uncommon', 'Ataque: +3 Mult por cada carta incolor no ataque.',
      [E('on_attack', 'mult_add', 3, per='played', filter={'colorless': True})], deck=19),
    N(399, 'Torre de Engrenagens', [], 'CR', 3, 35, 'uncommon', 'Ataque: +15 Poder por cada Ficha atacante.',
      [E('on_attack', 'power_add', 15, per='tokens')], tribe='construct', deck=19, keywords=['vigilance']),
    N(400, 'Motor de Vapor', [], 'CR', 3, 30, 'uncommon', 'Ataque: ×1 Mult, mais ×0.1 por cada Construto atacante.',
      [E('on_attack', 'mult_mul', 0.1, per='attacker', filter=CON, linear=True)], tribe='construct', deck=19),
    N(401, 'Relojoeiro Louco', [], 'CR', 3, 30, 'rare', 'Ataque: se for a última Criatura da Arena, reativa a 1.ª.',
      [E('on_attack', 'retrigger', 'first', cond={'position': 'rightmost'})], tribe='construct', deck=19),
    N(402, 'Prensa Hidráulica', [], 'SP', 3, 30, 'uncommon', '+15 Poder por cada Construto atacante; ×1.3 Mult com 4 ou mais.',
      [E('on_cast', 'power_add', 15, per='attacker', filter=CON),
       E('on_cast', 'mult_mul', 1.3, cond={'count': {'of': 'attacker', 'filter': CON, 'min': 4}})], deck=19),
    N(403, 'Golem de Sucata', [], 'CR', 4, 50, 'uncommon', 'Ao entrar, desmonta uma Ficha tua e ganha +40 Poder nesta batalha.',
      [E('on_play', 'devour_token', 40)], tribe='construct', deck=19, keywords=['trample']),
    N(404, 'Fábrica Autónoma', [], 'EN', 3, 0, 'rare', 'No início de cada turno, cria 1 Engrenagem.',
      [E('turn_start', 'create_token', 1, token='tok_gear')], deck=19),
    N(405, 'Colosso de Rodas Dentadas', [], 'CR', 5, 85, 'rare', '×1.5 Mult; com 3 ou mais Construtos a atacar, ×2 Mult em vez disso.',
      [E('on_attack', 'mult_mul', 1.5, cond={'count': {'of': 'attacker', 'filter': CON, 'max': 2}}),
       E('on_attack', 'mult_mul', 2.0, cond={'count': {'of': 'attacker', 'filter': CON, 'min': 3}})], tribe='construct', deck=19,
      keywords=['protection']),
    N(406, 'Engenheira-Chefe', [], 'CR', 4, 45, 'rare', 'Os teus Construtos custam 1 a menos. Ataque: +4 Mult.',
      [E('passive', 'cost_reduction', 1, filter=CON), E('on_attack', 'mult_add', 4)], tribe='construct', deck=19),
    N(407, 'Ferro-Velho', [], 'LD', 1, 0, 'uncommon', '[Na Mão] +10 Poder por cada Construto atacante.',
      [E('in_hand', 'power_add', 10, per='attacker', filter=CON)], deck=19, price=5),
    N(408, 'Calibrar', [], 'MG', 1, 10, 'common', '+4 Mult. A 1.ª Criatura da Arena ganha Primeiro Golpe.',
      [E('on_cast', 'mult_add', 4), E('on_cast', 'grant_keyword', keyword='first_strike', target='first')], deck=19),
    # --- Baralho 20: Legião Infinda (verde e branco, Fichas) ---
    N(409, 'Recruta Entusiasta', ['white'], 'CR', 1, 15, 'common', 'Ao entrar, cria 1 Soldado.',
      [E('on_play', 'create_token', 1)], tribe='soldier', deck=20),
    N(410, 'Semeadora de Rebentos', ['green'], 'CR', 1, 10, 'common', 'Ao entrar, cria 1 Rebento (Ficha de 10 Poder: +2 Mult ao atacar).',
      [E('on_play', 'create_token', 1, token='tok_sapling')], tribe='elf', deck=20),
    N(411, 'Chamamento dos Espíritos', ['white'], 'SP', 2, 10, 'common', 'Cria 2 Espíritos (Fichas de 15 Poder com Voar).',
      [E('on_cast', 'create_token', 2, token='tok_spirit')], deck=20),
    N(412, 'Pastora de Feras', ['green'], 'CR', 2, 20, 'uncommon', 'Ao entrar, cria 1 Fera (Ficha de 20 Poder com Atropelar).',
      [E('on_play', 'create_token', 1, token='tok_beast')], deck=20),
    N(413, 'Estandarte do Povo', ['green', 'white'], 'EN', 2, 0, 'uncommon', 'Ataque: +2 Mult por cada Ficha atacante.',
      [E('on_attack', 'mult_add', 2, per='tokens')], deck=20),
    N(414, 'Capitão das Multidões', ['white'], 'CR', 3, 30, 'rare', 'Ataque: ×1 Mult, mais ×0.1 por cada Ficha atacante.',
      [E('on_attack', 'mult_mul', 0.1, per='tokens', linear=True)], tribe='soldier', deck=20),
    N(415, 'Duplicação', ['green'], 'SP', 3, 15, 'uncommon', 'Cria uma cópia de cada Ficha na Arena (até a encher).',
      [E('on_cast', 'double_tokens', 1)], deck=20),
    N(416, 'Bosque Fervilhante', ['green'], 'LD', 1, 0, 'uncommon', '[Na Mão] +2 Mult por cada Ficha atacante.',
      [E('in_hand', 'mult_add', 2, per='tokens')], deck=20, price=5),
    N(417, 'Comandante dos Rebentos', ['green'], 'CR', 4, 45, 'rare', 'Ao entrar, as tuas Fichas ganham +15 Poder nesta batalha. Ataque: +3 Mult.',
      [E('on_play', 'buff_power', 15, filter={'token': True}), E('on_attack', 'mult_add', 3)], tribe='elf', deck=20),
    N(418, 'Muralha de Escudos', ['white'], 'MG', 1, 10, 'common', '+3 Mult. Reação: cria 2 Soldados e o contra-ataque perde 2 de dano.',
      [E('on_cast', 'mult_add', 3), E('reaction', 'create_token', 2), E('reaction', 'reduce_counter', 2)], deck=20),
    N(419, 'Banquete da Legião', ['green', 'white'], 'SP', 2, 15, 'uncommon', '+1 Mult por cada Ficha criada nesta batalha (máx. +15).',
      [E('on_cast', 'mult_add', 1, per='tokens_made', cap=15)], deck=20),
    N(420, 'Guardiã do Bosque', ['green'], 'CR', 3, 35, 'uncommon', 'Ao entrar, cria 1 Fera.',
      [E('on_play', 'create_token', 1, token='tok_beast')], deck=20, keywords=['vigilance']),
    N(421, 'Arauto dos Espíritos', ['white'], 'CR', 4, 50, 'rare', 'Ao entrar, cria 1 Espírito. Ataque: +3 Mult por cada Espírito atacante.',
      [E('on_play', 'create_token', 1, token='tok_spirit'), E('on_attack', 'mult_add', 3, per='attacker', filter={'tribe': 'spirit'})],
      tribe='angel', deck=20, keywords=['flying']),
    N(422, 'Rainha da Colmeia', ['green'], 'CR', 5, 70, 'rare', 'Ao entrar, enche a Arena de Soldados. Ataque: ×1.3 Mult.',
      [E('on_play', 'create_token', 5), E('on_attack', 'mult_mul', 1.3)], deck=20),
    N(423, 'Marcha Triunfal', ['green', 'white'], 'SP', 4, 30, 'rare', 'As tuas Fichas ganham Atropelar; ×1.5 Mult com 4 ou mais Fichas a atacar.',
      [E('on_cast', 'grant_keyword', keyword='trample', target='board', filter={'token': True}),
       E('on_cast', 'mult_mul', 1.5, cond={'count': {'of': 'tokens', 'min': 4}})], deck=20),
    N(424, 'Rebento Teimoso', ['green'], 'CR', 2, 20, 'common', 'Chegada de Terreno: cria 1 Rebento.',
      [E('landfall', 'create_token', 1, token='tok_sapling')], deck=20),
    # --- 30 raras e míticas (fora dos baralhos: loja, boosters, eventos) ---
    N(425, 'Arcanjo da Linha da Frente', ['white'], 'CR', 4, 50, 'rare', 'Ataque: +3 Mult por cada Criatura com Vigilância.',
      [E('on_attack', 'mult_add', 3, per='attacker', filter={'keyword': 'vigilance'})], tribe='angel', keywords=['flying', 'vigilance']),
    N(426, 'Mártir da Alvorada', ['white'], 'CR', 2, 20, 'rare', 'Quando morre, as tuas outras Criaturas crescem +20 Poder permanente.',
      [E('on_death', 'grow_board', 20, exclude_self=True)], tribe='soldier'),
    N(427, 'Juramento Solar', ['white'], 'SP', 3, 25, 'rare', '+2 Mult por cada Criatura branca atacante; ×1.5 Mult com 4 ou mais.',
      [E('on_cast', 'mult_add', 2, per='attacker', filter={'color': 'white'}),
       E('on_cast', 'mult_mul', 1.5, cond={'count': {'of': 'attacker', 'filter': {'color': 'white'}, 'min': 4}})]),
    N(428, 'Tecelã do Tempo', ['blue'], 'CR', 3, 30, 'rare', 'Ataque: +2 Mult por cada carta comprada neste turno (máx. +16).',
      [E('on_attack', 'mult_add', 2, per='drawn_this_turn', cap=16)]),
    N(429, 'Djinn das Profundezas', ['blue'], 'CR', 5, 75, 'rare', 'Ao entrar, compra 2 cartas. Ataque: ×1.4 Mult.',
      [E('on_play', 'draw', 2), E('on_attack', 'mult_mul', 1.4)], keywords=['flying']),
    N(430, 'Biblioteca Viva', ['blue'], 'EN', 2, 0, 'rare', 'No início de cada turno, compra 1 carta.',
      [E('turn_start', 'draw', 1)]),
    N(431, 'Paradoxo Estável', ['blue'], 'MG', 2, 15, 'rare', 'Reativa todos os outros feitiços deste turno.',
      [E('on_cast', 'retrigger', 'spells')]),
    N(432, 'Ceifeira de Almas', ['black'], 'CR', 3, 35, 'rare', 'Ataque: +2 Mult por cada Criatura no teu cemitério.',
      [E('on_attack', 'mult_add', 2, per='graveyard', filter={'type': 'creature'})]),
    N(433, 'Pacto de Sangue Antigo', ['black'], 'SP', 3, 20, 'rare', '×2 Mult; perdes 2 de vida.',
      [E('on_cast', 'mult_mul', 2.0), E('on_cast', 'self_damage', 2)]),
    N(434, 'Vampira Anciã', ['black'], 'CR', 4, 45, 'rare', 'Ataque: +6 Mult se a tua vida estiver abaixo de metade.',
      [E('on_attack', 'mult_add', 6, cond={'life_below_pct': 50})], keywords=['lifelink']),
    N(435, 'Coveiro Sombrio', ['black'], 'CR', 2, 25, 'rare', 'Ataque: +3 Mult por cada Criatura tua que morreu nesta batalha.',
      [E('on_attack', 'mult_add', 3, per='deaths')], tribe='zombie'),
    N(436, 'Dragão da Tempestade de Fogo', ['red'], 'CR', 5, 85, 'rare', 'Ataque: +5 Mult por cada feitiço lançado neste turno.',
      [E('on_attack', 'mult_add', 5, per='spell')], tribe='dragon', keywords=['flying']),
    N(437, 'Berserker Imparável', ['red'], 'CR', 3, 35, 'rare', 'Ataque: cresce +10 Poder permanente.',
      [E('on_attack', 'grow', 10)], keywords=['trample']),
    N(438, 'Chuva de Brasas', ['red'], 'SP', 2, 15, 'rare', '+3 Mult por cada carta de Custo 1 no ataque.',
      [E('on_cast', 'mult_add', 3, per='played', filter={'cost': 1})]),
    N(439, 'Colosso da Floresta Antiga', ['green'], 'CR', 5, 95, 'rare', 'Ataque: +2 Mult por cada Terreno jogado nesta batalha; ×1.3 Mult.',
      [E('on_attack', 'mult_add', 2, per='land'), E('on_attack', 'mult_mul', 1.3)], keywords=['trample', 'protection']),
    N(440, 'Druida do Crescimento', ['green'], 'CR', 2, 20, 'rare', 'No início de cada turno, a Criatura mais fraca da Arena cresce +10 Poder permanente.',
      [E('turn_start', 'grow_weakest', 10)], tribe='elf'),
    N(441, 'Hidra Sem Fim', ['green'], 'CR', 4, 40, 'rare', 'Ataque: cresce +15 Poder permanente; ×1.2 Mult.',
      [E('on_attack', 'grow', 15), E('on_attack', 'mult_mul', 1.2)], keywords=['protection']),
    N(442, 'Apelo da Selva', ['green'], 'SP', 3, 20, 'rare', '+4 Mult. As tuas Criaturas ganham +20 Poder nesta batalha.',
      [E('on_cast', 'mult_add', 4), E('on_cast', 'buff_power', 20)]),
    N(443, 'Barão das Dívidas', ['white', 'black'], 'CR', 4, 45, 'rare', 'Ataque: +1 Mult por cada 2 ouro (máx. +15).',
      [E('on_attack', 'mult_add', 1, per='gold', per_div=2, cap=15)]),
    N(444, 'Tesoureira da Dívida', ['white', 'black'], 'CR', 2, 20, 'rare', 'Ao entrar, ganhas 4 ouro. Ataque: ×1.3 Mult se tiveres 10 ou mais ouro.',
      [E('on_play', 'gold', 4), E('on_attack', 'mult_mul', 1.3, cond={'gold_min': 10})]),
    N(445, 'Prisma da Convergência', ['white', 'blue', 'black', 'red', 'green'], 'SP', 3, 25, 'rare',
      '+3 Mult por cada cor no ataque; ×1.5 Mult com a Convergência Prismática.',
      [E('on_cast', 'mult_add', 3, per='colors'), E('on_cast', 'mult_mul', 1.5, cond={'formation': ['wubrg']})]),
    N(446, 'Avatar dos Cinco', ['white', 'blue', 'black', 'red', 'green'], 'CR', 5, 80, 'rare',
      'Conta como todas as cores. Ataque: ×1 Mult, mais ×0.1 por cada cor no ataque.',
      [E('on_attack', 'mult_mul', 0.1, per='colors', linear=True)], flags={'wild_color': True}),
    N(447, 'Arcanista da Tempestade', ['blue', 'red'], 'CR', 3, 30, 'rare', 'Ataque: reativa o último feitiço lançado neste turno.',
      [E('on_attack', 'retrigger', 'last_spell')]),
    N(448, 'Senhora da Ruína', ['blue', 'black', 'red'], 'CR', 4, 50, 'rare', 'Ataque: ×1.5 Mult; mais ×1.3 com o inimigo abaixo de metade da vida.',
      [E('on_attack', 'mult_mul', 1.5), E('on_attack', 'mult_mul', 1.3, cond={'enemy_hp_below_pct': 50})]),
    # Míticas: mudam as regras enquanto estão em jogo (desbloqueiam-se com conquistas)
    N(449, 'Arquimaga do Fluxo', ['blue'], 'CR', 4, 50, 'mythic', 'Mítica. O 1.º feitiço de cada turno não custa mana.', [],
      rules=['first_spell_free'], locked=True),
    N(450, 'Guardião dos Enigmas', ['white', 'blue'], 'CR', 4, 45, 'mythic', 'Mítica. Os efeitos [Na Mão] disparam duas vezes.', [],
      rules=['hand_twice'], locked=True),
    N(451, 'Coração da Colmeia', ['green'], 'CR', 5, 60, 'mythic', 'Mítica. Sempre que crias Fichas, crias o dobro.', [],
      rules=['token_double'], locked=True),
    N(452, 'Senhor da Carnificina', ['black', 'red'], 'CR', 5, 70, 'mythic',
      'Mítica. Sempre que uma Criatura tua morre, as outras crescem +20 Poder permanente.', [], rules=['death_growth'], locked=True),
    N(453, 'Fonte Primordial', [], 'CR', 4, 40, 'mythic', 'Mítica. Tens +1 mana em cada turno.', [],
      rules=['mana_plus'], tribe='construct', locked=True),
    N(454, 'Eco do Primeiro Golpe', ['red', 'white'], 'CR', 4, 55, 'mythic', 'Mítica. A 1.ª Criatura a disparar dispara duas vezes.', [],
      rules=['echo_first'], locked=True, keywords=['first_strike']),
]

# ----------------------------------------------------------------------------
# 0.15.0 — cartas das mecânicas novas (Destreza, Persistir, Delírio, Domínio, Energia, Coroa, Mana
# de Sangue) e cartas de apoio aos baralhos mais fracos; 6 Míticas desbloqueadas por conquistas.
# Os campos novos: 'phyrexian' (Mana de Sangue 🩸 no custo) e 'return_spells' (volta à mão se for o N.º feitiço do turno).
# ----------------------------------------------------------------------------
NEW_CARDS_0150 = [
    N(455, 'Goblin Rastilho', ['red'], 'CR', 1, 15, 'common',
      'Ataque: +3 Mult por cada outra carta de Custo 1 jogada neste turno.',
      [E('on_attack', 'mult_add', 3, per='played', filter={'cost': 1}, exclude_self=True)], tribe='goblin'),
    N(456, 'Sombra Faminta', ['black'], 'CR', 2, 20, 'common',
      'Ataque: +10 Poder e +2 Mult por cada canalização feita nesta batalha.',
      [E('on_attack', 'power_add', 10, per='discards_used'), E('on_attack', 'mult_add', 2, per='discards_used')]),
    N(457, 'Ancião do Bosque Fundo', ['green'], 'CR', 5, 70, 'rare',
      'Ao entrar, as Criaturas da Arena ganham +10 Poder nesta batalha. Ataque: +2 Mult por cada Elfo atacante.',
      [E('on_play', 'buff_power', 10), E('on_attack', 'mult_add', 2, per='attacker', filter={'tribe': 'elf'})], tribe='elf'),
    N(458, 'Instrutora da Muralha', ['white'], 'CR', 2, 25, 'uncommon',
      'Ao entrar, a Criatura mais fraca da Arena cresce +10 Poder permanente.',
      [E('on_play', 'grow_weakest', 10)], tribe='soldier', keywords=['vigilance']),
    N(459, 'Chanceler da Coroa', ['white', 'blue'], 'CR', 4, 40, 'rare',
      'Ao entrar, ganhas a Coroa. Ataque: +3 Mult por cada carta na mão.',
      [E('on_play', 'crown', 1), E('on_attack', 'mult_add', 3, per='hand')]),
    N(460, 'Vigia das Duas Sombras', ['blue', 'black'], 'CR', 2, 20, 'common',
      'Ao entrar, 2 cartas do grimório vão para o cemitério. Ataque: +1 Mult por cada carta no cemitério (máx. +12).',
      [E('on_play', 'mill', 2), E('on_attack', 'mult_add', 1, per='graveyard', cap=12)]),
    N(461, 'Palhaço Incendiário', ['black', 'red'], 'CR', 3, 35, 'uncommon',
      'Ataque: +10 Poder por cada 3 de vida perdida nesta batalha; ×1.3 Mult se canalizaste neste turno.',
      [E('on_attack', 'power_add', 10, per='life_lost', per_div=3), E('on_attack', 'mult_mul', 1.3, cond={'discarded_min': 1})]),
    N(462, 'Saurópode Atropelador', ['red', 'green'], 'CR', 5, 90, 'rare',
      'Ataque: ×1.5 Mult se for a Criatura com mais Poder da Arena.',
      [E('on_attack', 'mult_mul', 1.5, cond={'strongest': True})], keywords=['trample']),
    N(463, 'Cobradora Espectral', ['white', 'black'], 'CR', 3, 30, 'uncommon',
      'Ataque: +1 Mult por cada 3 ouro. Quando morre: +2 ouro e cria um Espírito (15 Poder, Voar).',
      [E('on_attack', 'mult_add', 1, per='gold', per_div=3), E('on_death', 'gold', 2), E('on_death', 'create_token', 1, token='tok_spirit')],
      keywords=['flying']),
    N(464, 'Condensador de Faíscas', ['blue', 'red'], 'CR', 2, 20, 'uncommon',
      'Ataque: com 3 ou mais feitiços lançados neste turno, reativa o último.',
      [E('on_attack', 'retrigger', 'last_spell', cond={'count': {'of': 'spell', 'min': 3}})], keywords=['prowess']),
    N(465, 'Faísca Recorrente', ['red'], 'SP', 1, 10, 'common',
      '+4 Mult. Se for o 3.º feitiço do turno (ou mais), volta à mão em vez de ir para o cemitério.',
      [E('on_cast', 'mult_add', 4)], flags={'return_spells': 3}),
    N(466, 'Raiz Putrefacta', ['black', 'green'], 'CR', 2, 25, 'common',
      'Ataque: +3 Mult por cada Criatura no cemitério (máx. +15).',
      [E('on_attack', 'mult_add', 3, per='graveyard', filter={'type': 'creature'}, cap=15)], tribe='zombie', keywords=['persist']),
    N(467, 'Lanceira da Vanguarda', ['red', 'white'], 'CR', 3, 35, 'uncommon',
      'Ataque: na 1.ª posição da Arena, reativa a Criatura à sua direita.',
      [E('on_attack', 'retrigger', 'right', cond={'position': 'first'})], tribe='soldier', keywords=['first_strike']),
    N(468, 'Arquivista das Cinzas', ['blue', 'black', 'red'], 'CR', 3, 30, 'uncommon',
      'Ao entrar, 2 cartas do grimório vão para o cemitério. Delírio: ×1.5 Mult.',
      [E('on_play', 'mill', 2), E('on_attack', 'mult_mul', 1.5, cond={'delirium': True})]),
    N(469, 'Tríplice Ruína', ['blue', 'black', 'red'], 'SP', 4, 35, 'rare',
      '+5 Mult por cada cor entre as cartas do cemitério.',
      [E('on_cast', 'mult_add', 5, per='graveyard_colors')]),
    N(470, 'Peregrina dos Cinco Céus', ['green'], 'CR', 2, 25, 'common',
      'Ao entrar, põe na mão um Terreno do grimório.',
      [E('on_play', 'tutor_land', 1)]),
    N(471, 'Vitral Prismático', ['white', 'blue', 'black', 'red', 'green'], 'EN', 3, 20, 'rare',
      'Domínio: +3 Mult por cada cor de Terreno jogada nesta batalha.',
      [E('on_attack', 'mult_add', 3, per='domain')]),
    N(472, 'Dínamo de Éter', [], 'CR', 2, 20, 'uncommon',
      'Ao entrar: +2 Energia. Ataque: gasta 1 Energia para reativar o Construto à sua esquerda.',
      [E('on_play', 'energy', 2), E('on_attack', 'retrigger', 'left', filter=CON, energy=1)], tribe='construct'),
    N(473, 'Viveiro dos Rebentos', ['green'], 'EN', 3, 15, 'uncommon',
      'No início de cada turno, cria 1 Rebento. Com a Arena cheia, +10 Poder por cada Ficha atacante.',
      [E('turn_start', 'create_token', 1, token='tok_sapling'),
       E('on_attack', 'power_add', 10, per='tokens', cond={'count': {'of': 'attacker', 'min': 5}})]),
    N(474, 'Acumulador de Éter', [], 'CR', 3, 30, 'common',
      'Ao entrar: +3 Energia. Ataque: +2 Mult por cada Energia que tens (máx. +10).',
      [E('on_play', 'energy', 3), E('on_attack', 'mult_add', 2, per='energy', cap=10)], tribe='construct'),
    N(475, 'Descarga de Éter', [], 'SP', 2, 20, 'uncommon',
      'Gasta toda a tua Energia: +4 Mult por cada uma.',
      [E('on_cast', 'mult_add', 4, per='energy_spend_all')]),
    N(476, 'Ceifeira de Sangue', ['black'], 'CR', 3, 40, 'uncommon',
      '🩸1. Ataque: +2 Mult por cada 3 de vida perdida nesta batalha.',
      [E('on_attack', 'mult_add', 2, per='life_lost', per_div=3)], flags={'phyrexian': 1}),
    N(477, 'Lâmina Sedenta', ['red'], 'SP', 3, 30, 'uncommon',
      '🩸2. +8 Mult.',
      [E('on_cast', 'mult_add', 8)], flags={'phyrexian': 2}),
    N(478, 'Oráculo do Sangue', ['blue'], 'CR', 2, 20, 'common',
      '🩸1. Ao entrar, compra 1 carta.',
      [E('on_play', 'draw', 1)], flags={'phyrexian': 1}),
    N(479, 'Arauto da Coroa', ['white'], 'CR', 2, 20, 'uncommon',
      'Ao entrar, ganhas a Coroa. Ataque: +5 Mult se tiveres a Coroa.',
      [E('on_play', 'crown', 1), E('on_attack', 'mult_add', 5, cond={'crown': True})]),
    N(480, 'Exploradora dos Confins', ['green'], 'CR', 2, 20, 'common',
      'Domínio: +10 Poder por cada cor de Terreno jogada nesta batalha.',
      [E('on_attack', 'power_add', 10, per='domain')]),
    N(481, 'Sibila do Delírio', ['black'], 'CR', 1, 10, 'common',
      'Ao entrar, 1 carta do grimório vai para o cemitério. Delírio: +20 Poder e +4 Mult.',
      [E('on_play', 'mill', 1), E('on_attack', 'power_add', 20, cond={'delirium': True}),
       E('on_attack', 'mult_add', 4, cond={'delirium': True})]),
    # Míticas das mecânicas novas (desbloqueiam-se com conquistas)
    N(482, 'Rainha das Coroas', ['white', 'blue'], 'CR', 5, 60, 'mythic',
      'Mítica. Ao entrar, ganhas a Coroa; voltas a ganhá-la no início de cada turno.',
      [E('on_play', 'crown', 1)], rules=['crown_always'], locked=True),
    N(483, 'Coração de Éter', [], 'CR', 4, 40, 'mythic',
      'Mítica. Sempre que ganhas Energia, ganhas o dobro.', [], rules=['energy_double'], tribe='construct', locked=True),
    N(484, 'Rainha do Ossário', ['black'], 'CR', 4, 45, 'mythic',
      'Mítica. Tens sempre Delírio.', [], rules=['always_delirium'], locked=True),
    N(485, 'Ceifeiro Imortal', ['black', 'green'], 'CR', 5, 55, 'mythic',
      'Mítica. As tuas Criaturas têm Persistir.', [], rules=['all_persist'], locked=True),
    N(486, 'Tempestade Viva', ['blue', 'red'], 'CR', 4, 45, 'mythic',
      'Mítica. As tuas Criaturas têm Destreza.', [], rules=['all_prowess'], locked=True),
    N(487, 'Avatar dos Domínios', ['white', 'blue', 'black', 'red', 'green'], 'CR', 5, 70, 'mythic',
      'Mítica. O Domínio conta sempre as 5 cores.', [], rules=['full_domain'], locked=True),
]

# ----------------------------------------------------------------------------
# 0.18.0 (19) — Equipamentos ('EQ'): ficam em jogo presos a uma criatura. O Poder da carta soma-se ao
# ataque dela, os efeitos 'on_attack' disparam logo a seguir aos dela e as 'keywords' passam para ela.
# Se a criatura morrer, o equipamento fica à espera e muda-se por 1 de mana. Fora dos baralhos (loja,
# boosters, eventos, Draft), como as outras cartas extra.
# ----------------------------------------------------------------------------
NEW_CARDS_0180 = [
    N(488, 'Lâmina de Aprendiz', [], 'EQ', 1, 10, 'common',
      'A criatura equipada tem +10 Poder.', []),
    N(489, 'Asas de Latão', [], 'EQ', 2, 10, 'common',
      'A criatura equipada tem +10 Poder e Voar.', [], keywords=['flying']),
    N(490, 'Manoplas de Ferro Velho', [], 'EQ', 3, 30, 'uncommon',
      'A criatura equipada tem +30 Poder e Atropelar.', [], keywords=['trample']),
    N(491, 'Coroa de Engrenagens', [], 'EQ', 3, 10, 'rare',
      'A criatura equipada tem +10 Poder. Ataque: +2 Mult por cada equipamento em jogo.',
      [E('on_attack', 'mult_add', 2, per='equipment')]),
    N(492, 'Escudo da Alvorada', ['white'], 'EQ', 2, 15, 'uncommon',
      'A criatura equipada tem +15 Poder e Vigilância. Ataque: +1 Mult.',
      [E('on_attack', 'mult_add', 1)], keywords=['vigilance']),
    N(493, 'Monóculo do Arcanista', ['blue'], 'EQ', 2, 10, 'uncommon',
      'A criatura equipada tem +10 Poder. Ataque: +2 Mult por cada feitiço lançado neste turno.',
      [E('on_attack', 'mult_add', 2, per='spell')]),
    N(494, 'Punhal de Ébano', ['black'], 'EQ', 2, 20, 'uncommon',
      'A criatura equipada tem +20 Poder e Vínculo Vital.', [], keywords=['lifelink']),
    N(495, 'Machado Rubro', ['red'], 'EQ', 3, 25, 'rare',
      'A criatura equipada tem +25 Poder. Ataque: ×1.3 Mult.',
      [E('on_attack', 'mult_mul', 1.3)]),
    N(496, 'Clava de Raiz Viva', ['green'], 'EQ', 3, 20, 'rare',
      'A criatura equipada tem +20 Poder. Ataque: a clava cresce +5 Poder permanente.',
      [E('on_attack', 'grow', 5)]),
    N(497, 'Amuleto da Fénix', ['black', 'green'], 'EQ', 2, 10, 'uncommon',
      'A criatura equipada tem +10 Poder e Persistir.', [], keywords=['persist']),
    N(498, 'Luvas do Duelista', ['blue', 'red'], 'EQ', 2, 15, 'uncommon',
      'A criatura equipada tem +15 Poder e Destreza.', [], keywords=['prowess']),
    N(499, 'Lança do Arauto', ['red', 'white'], 'EQ', 2, 20, 'uncommon',
      'A criatura equipada tem +20 Poder e Primeiro Golpe.', [], keywords=['first_strike']),
]

# ----------------------------------------------------------------------------
# Construção das cartas
# ----------------------------------------------------------------------------
def rarity_for(cost, tcode):
    if tcode == 'LD': return 'uncommon'
    return 'rare' if cost == 5 else 'uncommon' if cost == 4 else 'common'

def price_for(cost, tcode):
    return 3 + cost + (2 if cost == 5 else 0) if tcode != 'LD' else 5

cards = []
report = collections.Counter()
notes_by_deck = collections.defaultdict(list)
for num_ in range(1, 301):
    r = raw[num_]
    effects, approx, notes, flags = map_text(r)
    if num_ in OVERRIDES:
        effects = OVERRIDES[num_]; approx = False; notes = []
        flags.update(OVERRIDE_FLAGS.get(num_, {}))
    deck = deck_of(num_)
    t = TYPE[r['tcode']]
    card = {
        'id': 'c%03d' % num_, 'num': num_, 'name': r['name'], 'deck': deck,
        'colors': colors_of(r['colorcode']), 'type': t, 'subtype': SUBTYPE[r['tcode']],
        'cost': r['cost'], 'power': r['power'] if t != 'land' else 0,
        'toughness': (r['cost'] + 1) if t == 'creature' else 0,
        'rarity': rarity_for(r['cost'], r['tcode']), 'price': price_for(r['cost'], r['tcode']),
        'text': TEXT_OVERRIDES.get(num_, r['text']), 'effects': effects,
    }
    card.update(flags)
    if num_ in FLASHBACK:
        card['flashback'] = True
    if approx:
        card['approx'] = True
        card['approx_notes'] = notes
        notes_by_deck[deck].extend(['#%03d %s: %s' % (num_, r['name'], n) for n in notes])
    report['approx' if approx else 'ok'] += 1
    cards.append(card)

# Nomes que o documento original juntou numa só palavra (quebras de linha perdidas).
NAME_FIXES = {
    'c034': 'Colosso Musgoso', 'c046': 'Anjo da Lança Solar', 'c068': 'Onda do Lago Negro', 'c166': 'Diabrete das Ervas Daninhas', 'c203': 'Quartel do Estandarte', 'c264': 'Zumbidor de Cobre',
}
for c in cards:
    if c['id'] in NAME_FIXES:
        c['name'] = NAME_FIXES[c['id']]

cards.extend(EXTRA_CARDS)
cards.extend(CURSES)
cards.extend(NEW_CARDS)
cards.extend(NEW_CARDS_0120)
cards.extend(NEW_CARDS_0130)
cards.extend(NEW_CARDS_0150)
cards.extend(NEW_CARDS_0180)
for c in cards:
    if c['num'] in TRIBE_OF and c['type'] == 'creature' and not c.get('tribe'):
        c['tribe'] = TRIBE_OF[c['num']]
cards.append(TOKEN_SOLDIER)
cards.extend(TOKENS_0130)

# 0.11.0 — palavras-chave de criatura (ícone na carta, explicação no glossário):
#   vigilance  Vigilância: bloqueia o contra-ataque sem sofrer dano.
#   lifelink   Vínculo Vital: cada vez que ataca, curas 1.
#   protection Proteção: as habilidades do inimigo não lhe tocam.
KEYWORDS = {
    # Vigilância: cavaleiros, guardiões e colossos
    43: ['vigilance'], 44: ['vigilance'], 116: ['vigilance'], 192: ['vigilance'], 139: ['vigilance'],
    110: ['vigilance'], 285: ['vigilance'], 58: ['vigilance'], 255: ['vigilance'], 268: ['vigilance'],
    169: ['vigilance'],
    # Vínculo Vital: anjos, vampiros e curandeiros
    20: ['lifelink'], 130: ['lifelink'], 119: ['lifelink'], 288: ['lifelink'], 135: ['lifelink'],
    183: ['lifelink'], 194: ['lifelink'], 46: ['lifelink', 'vigilance'], 121: ['lifelink'], 136: ['lifelink'],
    # Proteção: hidras, titãs e colossos
    31: ['protection'], 104: ['protection'], 219: ['protection'], 205: ['protection'], 278: ['protection'],
    262: ['protection'], 204: ['protection'], 34: ['protection'], 24: ['protection'], 75: ['protection'],
}
# 0.12.0 — Voar (os lacaios não a travam), Atropelar (corta a meio o escudo do inimigo) e Primeiro Golpe
# (dispara antes das outras criaturas na cascata): cartas antigas e as da expansão.
KEYWORDS_0120 = {
    # Voar: dragões, anjos, aves e espíritos do ar
    15: ['flying'], 41: ['flying'], 96: ['flying'], 135: ['flying'], 242: ['flying'], 290: ['flying'], 291: ['flying'],
    292: ['flying'], 293: ['flying'], 327: ['flying'], 328: ['flying'], 329: ['flying'], 330: ['flying'],
    357: ['flying'], 358: ['flying'], 359: ['flying'], 360: ['flying'], 362: ['flying'], 391: ['flying'],
    # Atropelar: feras grandes, gigantes e colossos
    32: ['trample'], 37: ['trample'], 85: ['trample'], 97: ['trample'], 103: ['trample'], 106: ['trample'],
    149: ['trample'], 179: ['trample'], 341: ['trample'],
    363: ['trample'], 364: ['trample'], 366: ['trample'], 367: ['trample'], 380: ['trample'], 389: ['trample'],
    # Primeiro Golpe: duelistas e cavaleiros rápidos
    39: ['first_strike'], 139: ['first_strike'], 186: ['first_strike'], 192: ['first_strike'], 193: ['first_strike'],
    316: ['first_strike'], 368: ['first_strike'], 369: ['first_strike'], 371: ['first_strike'], 387: ['first_strike'],
}
for num_, kws in KEYWORDS_0120.items():
    KEYWORDS[num_] = KEYWORDS.get(num_, []) + [k for k in kws if k not in KEYWORDS.get(num_, [])]
for c in cards:
    if c['num'] in KEYWORDS and c['type'] == 'creature':
        c['keywords'] = KEYWORDS[c['num']]
# 0.13.0: palavras-chave já dadas na definição (N(..., keywords=…)) ficam como estão.

# 0.11.0 — textos sem siglas: "Poder" por extenso e sem "(SP)", "(MG)", "(LD)", "(CR)", "(Retrigger)".
def normalize_text(t):
    t = re.sub(r'\s*\((?:SP|MG|LD|CR|Retrigger)\)', '', t)
    return re.sub(r'\bPod\b', 'Poder', t)

for c in cards:
    c['text'] = normalize_text(c['text'])
    # A faixa do tipo já diz "Encantamento" e "Ficha": o texto começa logo pelo efeito.
    for prefix in ('Encantamento. ', 'Ficha. '):
        if c['text'].startswith(prefix):
            c['text'] = c['text'][len(prefix):]
            c['text'] = c['text'][0].upper() + c['text'][1:]
    if c.get('transformed'):
        c['transformed']['text'] = normalize_text(c['transformed']['text'])
    if c.get('kicker'):
        c['kicker']['text'] = normalize_text(c['kicker']['text'])

assert len({c['id'] for c in cards}) == len(cards), 'ids repetidos'
for c in NEW_CARDS + NEW_CARDS_0120 + NEW_CARDS_0130 + NEW_CARDS_0150 + NEW_CARDS_0180:
    assert c['type'] not in ('creature', 'spell', 'equipment') or 10 <= c['power'] <= 100, c['id']

decks = []
for did, name, code, size, mech, diff in DECKS:
    ids = [c['id'] for c in cards if c['deck'] == did]
    assert len(ids) == size, (did, len(ids), size)
    approx_n = sum(1 for c in cards if c['deck'] == did and c.get('approx'))
    decks.append({'id': 'deck%02d' % did, 'num': did, 'name': name, 'colors': colors_of(code) if code not in ('CL/LD',) else [],
                  'color_code': code, 'size': size, 'mechanic': mech, 'difficulty': diff,
                  'cards': ids, 'approx_cards': approx_n})

# 0.13.0: baralhos 19 e 20 (as cartas trazem o "deck" na definição).
for did, name, code, mech, diff in DECKS_0130:
    ids = [c['id'] for c in cards if c['deck'] == did]
    decks.append({'id': 'deck%02d' % did, 'num': did, 'name': name, 'colors': colors_of(code), 'color_code': code,
                  'size': len(ids), 'mechanic': mech, 'difficulty': diff, 'cards': ids, 'approx_cards': 0})

json.dump(cards, open(OUT_DIR + '/cards.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
json.dump(decks, open(OUT_DIR + '/decks.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

print('cartas:', len(cards), dict(report))
acts = collections.Counter(e['action'] for c in cards for e in c['effects'])
print('ações:', dict(acts))
pers = collections.Counter(e.get('per') for c in cards for e in c['effects'] if e.get('per'))
print('per:', dict(pers))
trig = collections.Counter(e['trigger'] for c in cards for e in c['effects'])
print('triggers:', dict(trig))
for d in decks:
    print('deck %02d %-22s %2d cartas, %d aproximadas' % (d['num'], d['name'], d['size'], d['approx_cards']))
if '-v' in sys.argv:
    for did in sorted(notes_by_deck):
        print('--- deck', did)
        for n in notes_by_deck[did]:
            print('  ', n)
