# -*- coding: utf-8 -*-
"""Traduções para inglês da 0.14.0 (importado por tools/make_en_json.py, depois do en_0130).

CODE: textos da interface (chave = o texto em português, como no código).
EXTRA: textos soltos dos dados que não têm id próprio (Novidades).
"""

CODE = {
    "Fontes: Inter, Lora e New Rocker (SIL Open Font License).": "Fonts: Inter, Lora and New Rocker (SIL Open Font License).",
}

EXTRA = {
    "Novidades da 0.14.0": "What's new in 0.14.0",
    "Cartas com visual novo, «Vidro arcano»: vidro escuro com contorno e brilho na cor da carta.": "New card look, «Arcane Glass»: dark glass with an outline and glow in the card's colours.",
    "As ilustrações das cartas aparecem com a cor toda, numa janela com contorno.": "Card illustrations now show in full colour, in a framed window.",
    "No texto das cartas, o Poder aparece a azul e o Mult a vermelho.": "In card text, Power shows in blue and Mult in red.",
    "Custo num hexágono, raridade num losango, Poder à esquerda e Vida à direita.": "Cost in a hexagon, rarity in a diamond, Power on the left and Life on the right.",
    "Os nomes compridos encolhem para caber, e a carta em grande tem o mesmo visual.": "Long names shrink to fit, and the enlarged card has the same look.",
    "Menu mais leve: o círculo de runas gasta muito menos e fica sempre centrado no título.": "Lighter menu: the rune circle uses much less power and always sits centred on the title.",
    "Depois de uma Run Rápida, o botão volta à Run Rápida.": "After a Quick Run, the button takes you back to Quick Run.",
}


def build_data(root):
    """Pares {português: inglês} dos textos soltos (Novidades)."""
    return dict(EXTRA)
