#!/usr/bin/env python3
"""Gera i18n/en.json (texto PT → EN) para a interface. As chaves são o texto português tal como
aparece nas cenas/scripts/dados. Correr a partir da raiz:  python3 tools/make_en_json.py
Verifica também que todas as chaves tr("…") dos scripts têm tradução.
"""
import glob
import json
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

EN = {
    # --- Menu ---
    "NOVO JOGO": "NEW GAME",
    "CONTINUAR": "CONTINUE",
    "MODO LIVRE": "FREE MODE",
    "DIFICULDADE: %s": "DIFFICULTY: %s",
    "DIFICULDADE: NORMAL": "DIFFICULTY: NORMAL",
    "COMO JOGAR": "HOW TO PLAY",
    "CONFIGURAÇÕES": "SETTINGS",
    "SAIR": "QUIT",
    "Cada vitória é a derrota de alguém.\nUm deckbuilder de cascatas, 300 cartas, 18 baralhos.":
        "Every win is someone's loss.\nA cascade deckbuilder: 300 cards, 18 decks.",
    "protótipo 0.5.0": "prototype 0.5.0",
    "Fácil": "Easy",
    "Normal": "Normal",
    "Difícil": "Hard",
    # --- Campanha ---
    "◀ MENU": "◀ MENU",
    "◀ VOLTAR": "◀ BACK",
    "CAMPANHA": "CAMPAIGN",
    "CAMPANHA  ·  %s": "CAMPAIGN  ·  %s",
    "MODO LIVRE  ·  todos os baralhos": "FREE MODE  ·  every deck",
    "Ato bloqueado — chega ao ante 6 com um baralho do ato anterior.": "Act locked — reach ante 6 with a deck from the previous act.",
    "VENCIDO": "WON",
    "melhor: ante %d": "best: ante %d",
    "bloqueado": "locked",
    "%s  ·  %d cartas  ·  dificuldade %s": "%s  ·  %d cards  ·  difficulty %s",
    "Mecânica: %s": "Mechanic: %s",
    "Melhor ante: %d": "Best ante: %d",
    "Ainda não jogado": "Not played yet",
    "Vitórias: %d": "Wins: %d",
    "%d carta(s) com efeito aproximado (≈)": "%d card(s) with an approximated effect (≈)",
    "Incolor": "Colourless",
    "5 cores": "5 colours",
    "COMEÇAR  ▶": "START  ▶",
    "Intro do ato": "Act intro",
    "Capítulo": "Chapter",
    "História": "Story",
    "Branco": "White",
    "Azul": "Blue",
    "Preto": "Black",
    "Vermelho": "Red",
    "Verde": "Green",
    "Ato I": "Act I",
    "Ato II": "Act II",
    "Ato III": "Act III",
    # --- Batalha ---
    "PAUSA": "PAUSE",
    "Turno %d/%d  ·  Ante %d": "Turn %d/%d  ·  Ante %d",
    "Turno 1/5  ·  Ante 1": "Turn 1/5  ·  Ante 1",
    "Turno %d/%d": "Turn %d/%d",
    "Ouro %d": "Gold %d",
    "Ouro 4": "Gold 4",
    "Inimigo": "Enemy",
    "Habilidade do inimigo": "Enemy ability",
    "ATACAR": "ATTACK",
    "CANALIZAR (%d)": "CHANNEL (%d)",
    "CANALIZAR (3)": "CHANNEL (3)",
    "GRIMÓRIO %d": "LIBRARY %d",
    "CEMITÉRIO %d": "GRAVEYARD %d",
    "GRIMÓRIO 12": "LIBRARY 12",
    "CEMITÉRIO 0": "GRAVEYARD 0",
    "GRIMÓRIO": "LIBRARY",
    "CEMITÉRIO": "GRAVEYARD",
    "Vida %d/%d": "Life %d/%d",
    "Vida 20/20": "Life 20/20",
    "Mana %d/%d": "Mana %d/%d",
    "Mana 2/2": "Mana 2/2",
    "Feitiços deste turno": "Spells this turn",
    "Sem atacantes": "No attackers",
    "Ataque": "Attack",
    "ANTE %d": "ANTE %d",
    "ANTE 1": "ANTE 1",
    "TURNO %d": "TURN %d",
    "ANTE %d VENCIDO": "ANTE %d CLEARED",
    "VITÓRIA": "VICTORY",
    "DERROTA": "DEFEAT",
    "Toca numa carta para a jogar.": "Tap a card to play it.",
    "Run retomada no turno %d.": "Run resumed on turn %d.",
    "Toca na carta a canalizar.": "Tap the card to channel.",
    "%s morreu.": "%s died.",
    "%s bloqueou %d de dano.": "%s blocked %d damage.",
    "Canalizaste %s.": "You channelled %s.",
    "Cresce +%d": "Grows +%d",
    "Causaste %s de dano.": "You dealt %s damage.",
    "Levaste %d de dano.": "You took %d damage.",
    "Seed %d": "Seed %d",
    "+%d Poder": "+%d Power",
    "+%s Mult": "+%s Mult",
    "×%s Mult": "×%s Mult",
    "+%d ouro": "+%d gold",
    "roubou-te ouro": "stole your gold",
    "curou-se": "healed itself",
    "destruiu a tua criatura mais forte": "destroyed your strongest creature",
    "feriu todas as tuas criaturas": "wounded all your creatures",
    "fez-te descartar uma carta": "made you discard a card",
    # --- Pausa ---
    "ABANDONAR RUN": "ABANDON RUN",
    "TENS A CERTEZA? TOCA OUTRA VEZ": "ARE YOU SURE? TAP AGAIN",
    # --- Configurações ---
    "Efeitos sonoros": "Sound effects",
    "Música": "Music",
    "Idioma": "Language",
    "Automático": "Automatic",
    "Velocidade das animações": "Animation speed",
    "Rápida": "Fast",
    "Instantânea": "Instant",
    "Vibração": "Vibration",
    "Ligada": "On",
    "Desligada": "Off",
    "As cartas e a história estão em português; a interface traduz-se.": "Cards and story are in Portuguese; the interface is translated.",
    "APAGAR PROGRESSO": "ERASE PROGRESS",
    "PROGRESSO APAGADO": "PROGRESS ERASED",
    "FECHAR": "CLOSE",
    # --- Cartas / zoom / listas ---
    "Criatura": "Creature",
    "Mágica": "Instant",
    "Feitiço": "Sorcery",
    "Terreno": "Land",
    "Terreno · na mão": "Land · in hand",
    "Relíquia": "Relic",
    "Sem efeito.": "No effect.",
    "Comum": "Common",
    "Incomum": "Uncommon",
    "Rara": "Rare",
    "Mítica": "Mythic",
    "Lendária": "Legendary",
    "Bónus permanente: %s": "Permanent bonus: %s",
    "Nesta batalha: +%d Poder": "This battle: +%d Power",
    "Dano sofrido: %d": "Damage taken: %d",
    "≈ efeito aproximado da carta original": "≈ approximated effect of the original card",
    "Toca para fechar": "Tap to close",
    "Nada aqui.": "Nothing here.",
    "Toca numa carta para a ver em grande.": "Tap a card to see it up close.",
    "O TEU BARALHO": "YOUR DECK",
    # --- Loja ---
    "MERCADOR": "MERCHANT",
    "MERCADOR  ·  ante %d vencido  ·  %s": "MERCHANT  ·  ante %d cleared  ·  %s",
    "VER BARALHO": "VIEW DECK",
    "Ouro: %d": "Gold: %d",
    "Ouro: 0": "Gold: 0",
    "Cartas": "Cards",
    "Relíquias": "Relics",
    "%s  (custo %d%s  ·  %d ouro)": "%s  (cost %d%s  ·  %d gold)",
    "★ %s  (%d ouro)": "★ %s  (%d gold)",
    "Carta removida  ✓": "Card removed  ✓",
    "REMOVER UMA CARTA (%d ouro)": "REMOVE A CARD (%d gold)",
    "REMOVER UMA CARTA": "REMOVE A CARD",
    "PRÓXIMO ANTE  ▶": "NEXT ANTE  ▶",
    "Toca na carta a remover": "Tap the card to remove",
    "CANCELAR": "CANCEL",
    # --- Fim de run ---
    "FIM": "END",
    "MENU": "MENU",
    "%s venceu os 8 antes.\nRelíquias: %d  ·  Ouro: %d  ·  Seed: %d": "%s beat all 8 antes.\nRelics: %d  ·  Gold: %d  ·  Seed: %d",
    "%s caiu no ante %d.\nRelíquias: %d  ·  Baralho: %d cartas  ·  Seed: %d": "%s fell at ante %d.\nRelics: %d  ·  Deck: %d cards  ·  Seed: %d",
    "Modo Livre — não conta para a campanha.": "Free Mode — does not count towards the campaign.",
    "Melhor ante com este baralho: %d.  Chega ao ante 4 para desbloquear o capítulo seguinte.": "Best ante with this deck: %d.  Reach ante 4 to unlock the next chapter.",
    "Melhor ante com este baralho: %d.": "Best ante with this deck: %d.",
    "Desbloqueaste: ": "Unlocked: ",
    # --- Como jogar ---
    "Regras": "Rules",
    # --- Formações ---
    "Pacto Dual": "Dual Pact",
    "Tríade de Custo": "Cost Triad",
    "Bando Tribal": "Tribal Band",
    "Tempestade Arcana": "Arcane Storm",
    "Curva de Mana": "Mana Curve",
    "Devoção Pura": "Pure Devotion",
    "Horda": "Horde",
    "Convergência WUBRG": "WUBRG Convergence",
    # --- Relíquias ---
    "Tambor de Guerra": "War Drum",
    "Ataque: +30 Poder por criatura atacante.": "Attack: +30 Power per attacking creature.",
    "Mox de Rubi": "Ruby Mox",
    "Ataque: +3 Mult por criatura vermelha atacante.": "Attack: +3 Mult per attacking red creature.",
    "Mox de Safira": "Sapphire Mox",
    "Ataque: +3 Mult por criatura azul atacante.": "Attack: +3 Mult per attacking blue creature.",
    "Mox de Azeviche": "Jet Mox",
    "Ataque: +3 Mult por criatura preta atacante.": "Attack: +3 Mult per attacking black creature.",
    "Mox de Esmeralda": "Emerald Mox",
    "Ataque: +3 Mult por criatura verde atacante.": "Attack: +3 Mult per attacking green creature.",
    "Mox de Pérola": "Pearl Mox",
    "Ataque: +3 Mult por criatura branca atacante.": "Attack: +3 Mult per attacking white creature.",
    "Engrenagem": "Cogwheel",
    "Ataque: +3 Mult por criatura incolor atacante.": "Attack: +3 Mult per attacking colourless creature.",
    "Grimório Negro": "Black Grimoire",
    "Ataque: +2 Mult por carta no cemitério.": "Attack: +2 Mult per card in the graveyard.",
    "Lente Arcana": "Arcane Lens",
    "Ataque: +5 Mult por feitiço lançado este turno.": "Attack: +5 Mult per spell cast this turn.",
    "Ampulheta": "Hourglass",
    "Ataque: +4 Mult por carta na mão.": "Attack: +4 Mult per card in hand.",
    "Bolsa Encantada": "Enchanted Purse",
    "Início de cada turno: +1 ouro.": "Start of each turn: +1 gold.",
    "Placa Tectónica": "Tectonic Plate",
    "Ataque: +40 Poder por terreno na mão.": "Attack: +40 Power per land in hand.",
    "Estandarte Real": "Royal Banner",
    "Ataque: ×2 Mult.": "Attack: ×2 Mult.",
    "Pétala de Lótus": "Lotus Petal",
    "Ataque com 4+ criaturas: ×3 Mult.": "Attack with 4+ creatures: ×3 Mult.",
    "Espelho Rachado": "Cracked Mirror",
    "Ataque: a primeira criatura ativa duas vezes.": "Attack: the first creature triggers twice.",
    "Coroa das Formações": "Crown of Formations",
    "Ataque: ×1.4 Mult por cada formação ativa.": "Attack: ×1.4 Mult per active formation.",
    "Eco Arcano": "Arcane Echo",
    "Ataque: o último feitiço deste turno ativa outra vez.": "Attack: the last spell of this turn triggers again.",
    "Bigorna": "Anvil",
    "Ataque: +10 Poder por carta no cemitério.": "Attack: +10 Power per card in the graveyard.",
    # --- Inimigos ---
    "Lodo": "Sludge",
    "Sem habilidades. Só quer ser deixado em paz.": "No abilities. It just wants to be left alone.",
    "Bandido": "Bandit",
    "Fim de cada turno: rouba 1 ouro.": "End of each turn: steals 1 gold.",
    "Necromante": "Necromancer",
    "Fim de cada turno: cura-se 3.": "End of each turn: heals 3.",
    "Golem de Pedra": "Stone Golem",
    "A cada 3 turnos: destrói a tua criatura mais forte.": "Every 3 turns: destroys your strongest creature.",
    "Hidra": "Hydra",
    "A cada 2 turnos: 1 de dano a todas as tuas criaturas.": "Every 2 turns: 1 damage to all your creatures.",
    "Dragão Jovem": "Young Dragon",
    "A cada 3 turnos: 2 de dano a todas as tuas criaturas.": "Every 3 turns: 2 damage to all your creatures.",
    "Lich": "Lich",
    "Fim de cada turno: descarta uma carta ao acaso e cura-se 2.": "End of each turn: discards a random card and heals 2.",
    # --- Baralhos ---
    "Centelha Rubra": "Crimson Spark",
    "Blitz de custo 1 e reciclagem rápida do grimório": "Cost-1 blitz and fast library recycling",
    "Paradoxo Cronomante": "Chronomancer Paradox",
    "Cantrips (compra de cartas) e acumulação de feitiços": "Cantrips (card draw) and spell stacking",
    "Pacto Abissal": "Abyssal Pact",
    "Sacrifica descartes por ×Mult brutal": "Sacrifice discards for brutal ×Mult",
    "Semente Primordial": "Primordial Seed",
    "Crescimento permanente de Poder ao longo da run": "Permanent Power growth across the run",
    "Falange Solar": "Solar Phalanx",
    "Bando Tribal: enxame de criaturas": "Tribal Band: a swarm of creatures",
    "Senado Azorius": "Azorius Senate",
    "Retenção na mão: bónus por cartas não jogadas": "Hand retention: bonuses for unplayed cards",
    "Cabala Dimir": "Dimir Cabal",
    "Auto-mill: topo do grimório para o cemitério": "Self-mill: top of the library into the graveyard",
    "Carnaval Rakdos": "Rakdos Carnival",
    "Hellbent (mão vazia) e destruição de cartas": "Hellbent (empty hand) and card destruction",
    "Clã Gruul": "Gruul Clan",
    "Fúria colossal: custos 4 e 5 e tríades": "Colossal fury: costs 4 and 5 and triads",
    "Conclave Selesnya": "Selesnya Conclave",
    "Pactos duais (pares) e terrenos vivos": "Dual pacts (pairs) and living lands",
    "Sindicato Orzhov": "Orzhov Syndicate",
    "Economia de sangue: Mult pelo ouro acumulado": "Blood economy: Mult from hoarded gold",
    "Liga Izzet": "Izzet League",
    "Tempestade Arcana: feitiços em cadeia": "Arcane Storm: chained spells",
    "Enxame Golgari": "Golgari Swarm",
    "Motor de cemitério: canalizar dá Poder e Mult": "Graveyard engine: channelling gives Power and Mult",
    "Legião Boros": "Boros Legion",
    "Posicionamento: 1.ª e 5.ª carta ativam várias vezes": "Positioning: 1st and 5th card trigger several times",
    "Biomancia Simic": "Simic Biomancy",
    "Mutação de curva: custos para forçar Curva 1-5": "Curve mutation: costs that force the 1-5 Curve",
    "Trono de Grixis": "Throne of Grixis",
    "Maldições tricolor: mais forte com o inimigo ferido": "Tricolour curses: stronger against a wounded enemy",
    "Forja de Urza": "Urza's Forge",
    "Afinidade de artefactos e terrenos na mão": "Artifact affinity and lands in hand",
    "Convergência Planar": "Planar Convergence",
    "Domínio das 5 cores: Convergência WUBRG": "Mastery of the 5 colours: WUBRG Convergence",
    # --- Campanha: atos e capítulos ---
    "Ato I — Os Cinco Reinos": "Act I — The Five Realms",
    "O Plano está a esvaziar-se. Cada vitória de um Convocador é a derrota de outro — a soma é sempre zero. Começas com os cinco baralhos puros dos reinos antigos, um por cor.":
        "The Plane is emptying. Every Summoner's victory is another's defeat — the sum is always zero. You start with the five pure decks of the old realms, one per colour.",
    "A Centelha": "The Spark",
    "As Montanhas de Mogg ardem há três luas. Os goblins não querem vencer — querem que tudo arda ao mesmo tempo. Oito cartas, todas de custo 1: a mão que vês no primeiro turno é a que vais jogar até ao fim.":
        "The Mogg Mountains have burned for three moons. The goblins do not want to win — they want everything to burn at once. Eight cards, all cost 1: the hand you see on turn one is the one you will play to the end.",
    "O Paradoxo": "The Paradox",
    "Em Halimar, o tempo dobra-se como papel. Os cronomantes compram cartas que ainda não existem e lançam mágicas por cima umas das outras. Pequeno baralho, grandes cantrips: cada feitiço prepara o seguinte.":
        "In Halimar, time folds like paper. The chronomancers draw cards that do not exist yet and cast instants on top of one another. Small deck, big cantrips: every spell sets up the next.",
    "O Pacto": "The Pact",
    "No fundo do Abismo há um contrato com o teu nome. Cada carta que canalizas é um pagamento; a mão vazia é a assinatura. Aprende a descartar sem medo — é aí que o Mult explode.":
        "At the bottom of the Abyss there is a contract with your name on it. Every card you channel is a payment; the empty hand is the signature. Learn to discard without fear — that is where the Mult explodes.",
    "A Semente": "The Seed",
    "Pendelhaven cresce um palmo por dia. Os elfos não são fortes — ainda. Cada vez que jogas uma criatura verde ela fica mais forte para sempre, e a run inteira é uma floresta a engrossar.":
        "Pendelhaven grows a hand's width a day. The elves are not strong — yet. Every time you play a green creature it grows stronger forever, and the whole run is a forest thickening.",
    "A Falange": "The Phalanx",
    "Benalia marcha em linha. Sozinho, um soldado é um soldado; quatro em simultâneo são um Bando Tribal, e o Marechal multiplica tudo. Enche o tabuleiro e deixa o enxame falar.":
        "Benalia marches in line. Alone, a soldier is a soldier; four at once are a Tribal Band, and the Marshal multiplies everything. Fill the board and let the swarm speak.",
    "Ato II — As Guildas": "Act II — The Guilds",
    "Os reinos puros caíram uns sobre os outros e das ruínas nasceram as Guildas: duas cores, uma ideia fixa. Cada guilda joga um jogo diferente — descobre qual é o teu.":
        "The pure realms fell upon each other and from the ruins the Guilds were born: two colours, one fixed idea. Every guild plays a different game — find out which one is yours.",
    "O Senado": "The Senate",
    "Azorius legisla até o inimigo desistir. Joga pouco, retém muito: as cartas que ficam na mão valem mais do que as que jogas.":
        "Azorius legislates until the enemy gives up. Play little, keep much: the cards that stay in hand are worth more than the ones you play.",
    "A Cabala": "The Cabal",
    "Dimir não luta de frente. Envia o teu próprio grimório para o cemitério e deixa que os mortos façam as contas por ti.":
        "Dimir never fights head-on. Send your own library to the graveyard and let the dead do the maths for you.",
    "O Carnaval": "The Carnival",
    "Rakdos destrói as próprias cartas para rir. Com a mão vazia — hellbent — tudo o que resta bate o dobro.":
        "Rakdos destroys its own cards for a laugh. With an empty hand — hellbent — everything that remains hits twice as hard.",
    "O Clã": "The Clan",
    "Gruul não conhece custos baixos. Espera pelos turnos tardios, pousa o Dragão da Cratera e o Titã do Inferno, e faz a tríade de custo 5 tremer o Plano.":
        "Gruul knows no low costs. Wait for the late turns, drop the Crater Dragon and the Inferno Titan, and make the cost-5 triad shake the Plane.",
    "O Conclave": "The Conclave",
    "Selesnya canta em pares. Duas criaturas com o mesmo custo são um Pacto Dual; a Voz do Ressurgimento transforma o par numa explosão.":
        "Selesnya sings in pairs. Two creatures with the same cost are a Dual Pact; the Voice of Resurgence turns the pair into an explosion.",
    "O Sindicato": "The Syndicate",
    "Orzhov cobra dízimo a quem perde. Acumula ouro em pleno combate e converte-o em Mult — a Dívida aos Imortais paga-se com juros.":
        "Orzhov tithes the losers. Hoard gold mid-combat and convert it into Mult — the Debt to the Immortals is paid with interest.",
    "A Liga": "The League",
    "Izzet é o baralho mais difícil das guildas: só ganha quem encadeia três feitiços no mesmo turno. Tempestade Arcana, Niv-Mizzet a contar cada um — ou nada.":
        "Izzet is the hardest deck of the guilds: only those who chain three spells in one turn win. Arcane Storm, Niv-Mizzet counting each one — or nothing.",
    "O Enxame": "The Swarm",
    "Golgari recicla tudo. Canalizar não é perder cartas, é plantar: Jarad e Hogaak crescem com o cemitério.":
        "Golgari recycles everything. Channelling is not losing cards, it is planting: Jarad and Hogaak grow with the graveyard.",
    "A Legião": "The Legion",
    "Boros é posição. A primeira criatura é o comandante, a quinta o flanco, e Aurélia reativa a linha inteira. A ordem em que jogas é a estratégia.":
        "Boros is position. The first creature is the commander, the fifth the flank, and Aurelia retriggers the whole line. The order you play in is the strategy.",
    "A Biomancia": "The Biomancy",
    "Simic muta a própria curva. Krasis e Mutação Genética contam como o custo que falta — a Curva de Mana 1-2-3-4-5 deixa de ser sorte.":
        "Simic mutates its own curve. Krasis and Genetic Mutation count as whichever cost is missing — the 1-2-3-4-5 Mana Curve stops being luck.",
    "Ato III — Os Tronos": "Act III — The Thrones",
    "Acima das Guildas sentam-se os que já nem cor têm: Bolas, Urza e a própria Convergência. São os baralhos mais difíceis do jogo e os únicos que chegam ao fim do Plano.":
        "Above the Guilds sit those who no longer even have a colour: Bolas, Urza and Convergence itself. They are the hardest decks in the game and the only ones that reach the end of the Plane.",
    "O Trono de Grixis": "The Throne of Grixis",
    "Três cores e uma maldição. Nicol Bolas triplica tudo quando a mão tem azul, preto e vermelho, e as maldições pesam mais num inimigo ferido.":
        "Three colours and a curse. Nicol Bolas triples everything when your hand holds blue, black and red, and curses weigh more on a wounded enemy.",
    "A Forja de Urza": "Urza's Forge",
    "Nem cor nem alma: máquinas e os três terrenos de Urza. Guarda a Mina, a Central e a Torre na mão e nunca as jogues — juntas, são o multiplicador mais alto do jogo.":
        "Neither colour nor soul: machines and Urza's three lands. Keep the Mine, the Power Plant and the Tower in hand and never play them — together, they are the highest multiplier in the game.",
    "A Convergência": "The Convergence",
    "Vinte e seis cartas, cinco cores, uma formação impossível: Convergência WUBRG. Jodah faz qualquer mão de cinco cartas convergir; Progenitus triplica. Se chegares ao fim com este, o Plano é teu.":
        "Twenty-six cards, five colours, one impossible formation: WUBRG Convergence. Jodah makes any five-card hand converge; Progenitus triples. If you reach the end with this one, the Plane is yours.",
}


def collect_keys():
    keys = set()
    for pattern in ("scenes/**/*.gd", "scripts/**/*.gd"):
        for f in glob.glob(os.path.join(ROOT, pattern), recursive=True):
            s = open(f, encoding="utf-8").read()
            for m in re.finditer(r'(?:\btr|TranslationServer\.translate)\("((?:[^"\\]|\\.)*)"\)', s):
                keys.add(m.group(1).encode().decode("unicode_escape").encode("latin-1").decode("utf-8"))
    return keys


def main():
    path = os.path.join(ROOT, "i18n", "en.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(EN, f, ensure_ascii=False, indent=1)
    missing = sorted(k for k in collect_keys() if k not in EN)
    print("en.json:", len(EN), "entradas")
    if missing:
        print("SEM TRADUÇÃO:")
        for k in missing:
            print("  ", repr(k))


if __name__ == "__main__":
    main()
