#!/usr/bin/env python3
"""0.19.0 (239): o Inter (o tipo de letra do texto) só com as letras que o jogo usa.

O Inter completo tem ~2500 glifos (cirílico, grego, vietnamita…): eram 608 KB no APK. O jogo só fala português
e inglês: ficam o latim básico, o Latin-1, o Latin Extended-A, a pontuação, os símbolos e TODOS os carateres que
aparecem nos textos do jogo (dados, traduções, cenas e código), com as funções OpenType (kern, tnum, …).

O original fica em tools/brand/fonts_src/ (pasta que o Godot ignora); o resultado vai para assets/fonts/.
Só o Inter: o Lora, o New Rocker e o OpenDyslexic têm «Reserved Font Name» na licença OFL, e uma versão
modificada (um subconjunto é uma modificação) não podia manter o nome — ficam inteiros.

Uso (na raiz do projeto):  python3 tools/subset_fonts.py        (depois de mudar textos com letras novas)
"""
from pathlib import Path

from fontTools import subset

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "tools" / "brand" / "fonts_src" / "Inter-Medium.otf"
DST = ROOT / "assets" / "fonts" / "Inter-Medium.otf"
TEXT_GLOBS = ["data/*.json", "i18n/*.json", "scenes/**/*.gd", "scripts/**/*.gd", "scenes/**/*.tscn", "tests/*.gd", "tools/en_*.py", "notas_versao.txt"]
RANGES = [(0x20, 0x7E), (0xA0, 0x17F), (0x2000, 0x206F), (0x20A0, 0x20BF), (0x2100, 0x214F), (0x2190, 0x21FF),
          (0x2200, 0x22FF), (0x2460, 0x24FF), (0x25A0, 0x25FF), (0x2600, 0x26FF), (0x2700, 0x27BF)]


def used_chars() -> set:
    chars = set()
    for g in TEXT_GLOBS:
        for f in ROOT.glob(g):
            try:
                chars.update(f.read_text(encoding="utf-8"))
            except UnicodeDecodeError:
                pass
    for a, b in RANGES:
        chars.update(chr(c) for c in range(a, b + 1))
    return {c for c in chars if ord(c) >= 0x20}


def main() -> None:
    chars = used_chars()
    opts = subset.Options()
    opts.layout_features = ["*"]
    opts.name_IDs = ["*"]
    opts.name_legacy = True
    opts.name_languages = ["*"]
    opts.notdef_outline = True
    opts.glyph_names = False
    opts.hinting = True
    font = subset.load_font(str(SRC), opts)
    sub = subset.Subsetter(opts)
    sub.populate(unicodes=[ord(c) for c in chars])
    sub.subset(font)
    subset.save_font(font, str(DST), opts)
    print(f"{DST.relative_to(ROOT)}: {SRC.stat().st_size // 1024} KB → {DST.stat().st_size // 1024} KB ({len(chars)} carateres)")


if __name__ == "__main__":
    main()
