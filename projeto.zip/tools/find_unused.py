#!/usr/bin/env python3
"""0.19.0 (241): ficheiros que nada usa — para saírem do APK.

Procura em assets/ (e em data/ e i18n/) os ficheiros que não aparecem em lado nenhum: nem pelo caminho
(res://…), nem pelo nome do ficheiro, nem — nas ilustrações, que o ArtLib encontra pelo id — pelo id (o nome
sem a extensão) nos dados, nas cenas ou no código. Mostra a lista e o tamanho; com --json grava-a em
tools/unused.json. Não apaga nada.

Uso (na raiz do projeto):  python3 tools/find_unused.py [--json]
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCAN = ["assets", "data", "i18n"]
SKIP_EXT = {".import", ".md5", ".txt", ".gdignore", ".uid"}
# Pastas onde o ficheiro se encontra pelo id (o ArtLib, o Sfx e a Music juntam o caminho no código).
BY_ID = ["assets/art/", "assets/audio/"]
# Sempre usados (o motor ou o export pedem-nos pelo nome do projeto, ou servem as ferramentas).
KEEP = {"icon.png", "icon.svg", "splash.png", "theme.tres", "LEIA-ME.txt"}
TEXT_EXT = {".gd", ".tscn", ".tres", ".json", ".cfg", ".godot", ".py", ".gdshader"}


def corpus() -> str:
    parts = []
    for f in ROOT.rglob("*"):
        if f.is_file() and f.suffix in TEXT_EXT and ".godot" not in f.parts and "__pycache__" not in f.parts:
            try:
                parts.append(f.read_text(encoding="utf-8"))
            except UnicodeDecodeError:
                pass
    return "\n".join(parts)


def ids_in(text: str) -> set:
    return set(re.findall(r"[A-Za-z0-9_]+", text))


def main() -> int:
    text = corpus()
    words = ids_in(text)
    unused = []
    for top in SCAN:
        for f in (ROOT / top).rglob("*"):
            if not f.is_file() or f.suffix in SKIP_EXT or f.name in KEEP:
                continue
            rel = f.relative_to(ROOT).as_posix()
            if ("res://" + rel) in text or f.name in text:
                continue
            if any(rel.startswith(p) for p in BY_ID):
                stem = f.stem
                bare = re.sub(r"^(music_|ev_|clim_)", "", stem)
                if stem in words or bare in words or any(stem.startswith(w + "_") for w in ("music_guild", "music_drive")):
                    continue
                # «c001_hurt» / «boss_x_angry»: as expressões dos bosses e as variantes contam pelo id de base.
                base = re.sub(r"_(hurt|angry|back|alt\d*)$", "", stem)
                if base in words:
                    continue
            if top in ("data", "i18n") and f.suffix == ".json":
                continue   # os dados leem-se por caminhos construídos (CardDB, Settings); o make_manifest lista-os
            unused.append((rel, f.stat().st_size))
    unused.sort()
    total = sum(s for _, s in unused)
    for rel, size in unused:
        print(f"{size // 1024:6d} KB  {rel}")
    print(f"{len(unused)} ficheiros sem uso, {total / 1048576:.2f} MB")
    if "--json" in sys.argv:
        (ROOT / "tools" / "unused.json").write_text(json.dumps([r for r, _ in unused], indent=1, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
