# -*- coding: utf-8 -*-
"""Traduções para inglês da 0.15.0 (importado por tools/make_en_json.py, depois do en_0142).

CODE: textos da interface (chave = o texto em português, como no código).
EXTRA: textos dos dados novos da 0.15.0 (relíquias, selos, rituais, conquistas, glossário, dicas, Novidades)
e alguns que a troca de nomes deixou sem par.
"""

CODE = {
    # Batalha: mecânicas novas
    "%s persiste: volta à Arena com %s Poder.": "%s persists: back on the board with %s Power.",
    "%s é veterana: estrela %d de %d (+%d Poder até ao fim da run).": "%s is a veteran: star %d of %d (+%d Power for the rest of the run).",
    "%s: toca outra vez para a jogar — pagas %d de vida pelo Mana de Sangue.": "%s: tap again to play it — you pay %d life for the Blood Mana.",
    "A cópia de %s desaparece.": "The copy of %s vanishes.",
    "Coroa": "Crown",
    "Coroa perdida": "Crown lost",
    "Cópia": "Copy",
    "Cópia do Selo do Espelho: desaparece no fim do turno.": "Copy made by the Mirror Seal: it vanishes at the end of the turn.",
    "Energia": "Energy",
    "Energia: %d": "Energy: %d",
    "Excesso: +%d ouro.": "Overkill: +%d gold.",
    "Excesso: o golpe final passou da vida do inimigo (+%d ouro).": "Overkill: the final blow went past the enemy's life (+%d gold).",
    "Falta mana: %s custa %d e tens %d (mais %d de Mana de Sangue, com vida).": "Not enough mana: %s costs %d and you have %d (plus %d of Blood Mana, paid with life).",
    "Fraco": "Weak",
    "Ganhaste a Coroa: +1 carta no início de cada turno, até levares dano.": "You took the Crown: +1 card at the start of each turn, until you take damage.",
    "Gravado sozinho em «%s» a cada jogada.": "Saved automatically to “%s” after every play.",
    "Interrompeste o ritual de %s!": "You broke %s's ritual!",
    "Mana de Sangue": "Blood Mana",
    "Mana de Sangue: paga-se com 1 de mana ou com 2 de vida.": "Blood Mana: paid with 1 mana or with 2 life.",
    "Mana de Sangue: pagaste %d de vida para jogar %s.": "Blood Mana: you paid %d life to play %s.",
    "Perdeste a Coroa.": "You lost the Crown.",
    "Persiste!": "Persists!",
    "Persistiu: já voltou uma vez nesta batalha.": "Persisted: it already came back once this battle.",
    "Ponto fraco": "Weak point",
    "Ponto fraco: %s. Cada carta dessa cor no ataque dá +%s Mult, num passo próprio da cascata.":
        "Weak point: %s. Each card of that colour in the attack gives +%s Mult, in its own cascade step.",
    "RITUAL": "RITUAL",
    "RITUAL INTERROMPIDO": "RITUAL BROKEN",
    "Recurso desta batalha": "Resource for this battle",
    "Ritual": "Ritual",
    "Ritual de %s: %s.": "%s's ritual: %s.",
    "Ritual: %s daqui a %d turno(s). Um golpe de %s ou mais (15 %% da vida máxima) interrompe-o.":
        "Ritual: %s in %d turn(s). A single blow of %s or more (15 %% of max life) breaks it.",
    "Veterano: %d/%d ataques até à próxima estrela.": "Veteran: %d/%d attacks to the next star.",
    "Veterano: +%d Poder até ao fim da run.": "Veteran: +%d Power for the rest of the run.",
    "Vida do inimigo: %s / %s": "Enemy life: %s / %s",
    "persistiu": "persisted",
    "🩸 Mana de Sangue: %d do custo pode pagar-se com vida (%d de vida cada) quando falta mana.":
        "🩸 Blood Mana: %d of the cost can be paid with life (%d life each) when you lack mana.",
    # Loja: Constelação e DESFAZER
    "⁂ Constelação  (%d ouro)": "⁂ Constellation  (%d gold)",
    "Sobe 1 nível a uma formação à tua escolha: mais Mult sempre que a fizeres, até ao fim da run.":
        "Raises a formation of your choice by 1 level: more Mult every time you make it, for the rest of the run.",
    "%s sobe ao nível %d: +%s Mult sempre que a fizeres.": "%s rises to level %d: +%s Mult every time you make it.",
    "⁂ CONSTELAÇÃO — ESCOLHE A FORMAÇÃO": "⁂ CONSTELLATION — PICK THE FORMATION",
    "A formação que escolheres sobe 1 nível até ao fim da run: dá mais Mult sempre que a fizeres.":
        "The formation you pick rises 1 level for the rest of the run: it gives more Mult every time you make it.",
    "⁂ %s · nível %d → %d": "⁂ %s · level %d → %d",
    "+%s Mult → +%s Mult": "+%s Mult → +%s Mult",
    "↩ DESFAZER": "↩ UNDO",
    "Desfaz %s.": "Undoes %s.",
    "Desfaz a última compra, serviço ou venda desta visita.": "Undoes the last purchase, service or sale of this visit.",
    "Desfeito: %s.": "Undone: %s.",
    "a compra de %s": "buying %s",
    "a venda de %s": "selling %s",
    "a cura": "the heal",
    "a vida máxima": "the max life upgrade",
    "a melhoria de %s": "upgrading %s",
    "o selo de %s": "sealing %s",
    "a remoção de %s": "removing %s",
    "o booster (%s)": "the booster (%s)",
    "a Constelação (%s)": "the Constellation (%s)",
    "Vale: %s": "Voucher: %s",
    # Fim da run: PORQUE PERDI?
    "PORQUE PERDI?": "WHY DID I LOSE?",
    "PERCEBI": "GOT IT",
    "Ficaste sem vida ao fim de %d turno(s), com %s ainda a %d %% da vida. Bloqueia os golpes grandes com criaturas que aguentam e cura-te no Mercador antes dos bosses.":
        "You ran out of life after %d turn(s), with %s still at %d %% of its life. Block the big hits with creatures that can take them and heal at the Merchant before bosses.",
    "Os turnos acabaram com %s ainda a %d %% da vida: faltou dano por ataque. Junta mais criaturas antes de atacar e procura formações e relíquias que dão Mult.":
        "You ran out of turns with %s still at %d %% of its life: each attack needed more damage. Gather more creatures before attacking and look for formations and relics that give Mult.",
    "%s tinha escudo e travou %s de dano. Cada criatura com Atropelar no ataque corta o escudo a meio.":
        "%s had a shield that blocked %s damage. Each creature with Trample in the attack cuts the shield in half.",
    "O ritual de %s chegou ao fim %d vez(es). Um só golpe de 15 %% da vida máxima do boss interrompe-o.":
        "%s's ritual went off %d time(s). A single blow of 15 %% of the boss's max life breaks it.",
    "Em %d turno(s) acabaste com mana por gastar (%d no total) e cartas na mão que podias jogar. Joga tudo o que puderes antes de ATACAR.":
        "In %d turn(s) you finished with unspent mana (%d in total) and cards in hand you could play. Play everything you can before you ATTACK.",
    "Ficaram %d canalizações por usar. Canalizar troca uma carta fraca da mão por outra do grimório.":
        "You left %d channels unused. Channelling swaps a weak card in your hand for another one from the library.",
    "Perdeste %d criaturas. Bloquear só com as que aguentam o golpe guarda Poder para o ataque.":
        "You lost %d creatures. Blocking only with the ones that survive the hit keeps Power for the attack.",
    "No Mercador, MELHORAR as cartas que mais atacam e comprar relíquias da tua cor ajudam nas batalhas seguintes.":
        "At the Merchant, UPGRADING the cards that attack the most and buying relics of your colour help in the next battles.",
}

EXTRA = {
    # A troca de nomes deixou este título sem par (o Livro IV continua a ter «A Legião»).
    "A Legião": "The Legion",
    # Conquistas
    "Cabeça Coroada": "Crowned Head",
    "Compra 15 cartas a mais com a Coroa (somando todas as runs).": "Draw 15 extra cards with the Crown (across all runs).",
    "Sobrecarga": "Overload",
    "Gasta 25 de Energia (somando todas as runs).": "Spend 25 Energy (across all runs).",
    "Mente Delirante": "Delirious Mind",
    "Ataca 10 vezes com Delírio.": "Attack 10 times with Delirium.",
    "Teimosia": "Stubbornness",
    "Faz 10 Criaturas Persistirem.": "Make 10 Creatures Persist.",
    "Tempestade Interior": "Inner Storm",
    "Ativa a Destreza 20 vezes.": "Trigger Dexterity 20 times.",
    "Cinco Terras": "Five Lands",
    "Joga Terrenos das 5 cores na mesma batalha.": "Play Lands of all 5 colours in the same battle.",
    "Quebra-Rituais": "Ritual Breaker",
    "Interrompe 5 rituais de bosses.": "Break 5 boss rituals.",
    "Lenda Viva": "Living Legend",
    "Leva uma Criatura às 3 estrelas de Veterano.": "Take a Creature to 3 Veteran stars.",
    # Rituais dos bosses
    "Prende a tua Criatura mais forte": "Locks up your strongest Creature",
    "Rouba-te 6 ouro": "Steals 6 gold from you",
    "Cura 12 % da vida": "Heals 12% of its life",
    "Fere todas as tuas Criaturas (2)": "Wounds all your Creatures (2)",
    "Reforça o escudo (+6 %)": "Strengthens its shield (+6%)",
    "Destrói a tua Criatura mais forte": "Destroys your strongest Creature",
    "Descarta 2 cartas da tua mão": "Discards 2 cards from your hand",
    "Tira-te 2 de mana no turno seguinte": "Takes 2 mana from you next turn",
    # Glossário
    "Palavra-chave: +1 Mult por cada feitiço lançado neste turno.": "Keyword: +1 Mult for each spell cast this turn.",
    "Palavra-chave: na 1.ª vez que a Criatura morre em cada batalha, volta à Arena com −10 Poder.":
        "Keyword: the first time the Creature dies in each battle, it comes back to the board with −10 Power.",
    "Com uma Criatura, um Feitiço (ou Mágica), um Terreno e um Encantamento no cemitério, o efeito com Delírio dispara.":
        "With a Creature, a Sorcery (or Instant), a Land and an Enchantment in the graveyard, the Delirium effect triggers.",
    "Conta as cores diferentes entre os Terrenos que jogaste nesta batalha (até 5).": "Counts the different colours among the Lands you played this battle (up to 5).",
    "Recurso (⚡) que dura até ao fim da batalha: umas cartas dão Energia, outras gastam-na em efeitos.":
        "A resource (⚡) that lasts until the end of the battle: some cards give Energy, others spend it on effects.",
    "Com a Coroa compras +1 carta no início de cada turno; perdes a Coroa quando um contra-ataque te fere.":
        "With the Crown you draw +1 card at the start of each turn; you lose the Crown when a counterattack hurts you.",
    "Mana de Sangue (🩸): cada 🩸 no custo paga-se com 1 de mana ou, se a mana não chegar, com 2 de vida (nunca a última).":
        "Blood Mana (🩸): each 🩸 in the cost is paid with 1 mana or, if you lack mana, with 2 life (never your last).",
    "Cada Criatura ganha uma estrela a cada 5 ataques: +10 Poder permanente por estrela, até 3.":
        "Each Creature earns a star every 5 attacks: +10 permanent Power per star, up to 3.",
    "Cada inimigo tem uma cor fraca: cada carta dessa cor no ataque dá +0,5 Mult.": "Each enemy has a weak colour: each card of that colour in the attack gives +0.5 Mult.",
    "O boss anuncia um ritual com contagem de turnos; um golpe de 15 % da vida máxima dele interrompe-o.":
        "The boss announces a ritual with a turn countdown; a single blow of 15% of its max life breaks it.",
    # Relíquias
    "Coroa de Espinhos": "Crown of Thorns",
    "Ataque: com a Coroa, +3 Mult por cada carta na mão.": "Attack: with the Crown, +3 Mult for each card in hand.",
    "Bateria de Éter": "Ether Battery",
    "Início de cada batalha: +2 Energia.": "Start of each battle: +2 Energy.",
    "Bobina de Éter": "Ether Coil",
    "Ataque: +1 Mult por cada Energia que tens (máx. +8).": "Attack: +1 Mult for each Energy you have (max. +8).",
    "Grimório Rasgado": "Torn Grimoire",
    "Início de cada batalha: 2 cartas do grimório vão para o cemitério.": "Start of each battle: 2 cards from the library go to the graveyard.",
    "Mapa dos Cinco Reinos": "Map of the Five Realms",
    "Ataque: +4 Mult por cada cor de Terreno jogada nesta batalha (Domínio).": "Attack: +4 Mult for each Land colour played this battle (Domain).",
    "Fénix de Bronze": "Bronze Phoenix",
    "As Criaturas que Persistem voltam com +10 Poder em vez de −10.": "Creatures that Persist come back with +10 Power instead of −10.",
    "Talismã do Duelista": "Duellist's Talisman",
    "Ataque: +2 Mult por cada feitiço lançado neste turno.": "Attack: +2 Mult for each spell cast this turn.",
    "Medalha de Veterano": "Veteran's Medal",
    "As Criaturas ganham estrelas de Veterano a cada 3 ataques em vez de 5.": "Creatures earn Veteran stars every 3 attacks instead of 5.",
    "Lupa do Caçador": "Hunter's Loupe",
    "O Ponto fraco do inimigo dá +1 Mult por carta em vez de +0,5.": "The enemy's Weak point gives +1 Mult per card instead of +0.5.",
    "Ampulheta Quebrada": "Broken Hourglass",
    "Os rituais dos bosses demoram mais 1 turno.": "Boss rituals take 1 more turn.",
    "Frasco de Sangue": "Blood Flask",
    "Pagar o Mana de Sangue com vida custa 1 em vez de 2.": "Paying Blood Mana with life costs 1 instead of 2.",
    "Bolsa do Carniceiro": "Butcher's Purse",
    "O Excesso do golpe final dá o dobro do ouro.": "Overkill on the final blow gives twice the gold.",
    # Selos
    "Selo do Guardião": "Guardian Seal",
    "A Criatura tem Vigilância; quando bloqueia, ganhas +1 canalização.": "The Creature has Vigilance; when it blocks, you get +1 channel.",
    "Conjunto do Guardião": "Guardian Set",
    "3 cartas com o Selo do Guardião no ataque: +4 Mult.": "3 cards with the Guardian Seal in the attack: +4 Mult.",
    "Selo do Espelho": "Mirror Seal",
    "Criatura: ao entrar, cria uma cópia dela com metade do Poder, que desaparece no fim do turno.":
        "Creature: when it enters, it makes a copy of itself with half the Power, which vanishes at the end of the turn.",
    "Conjunto do Espelho": "Mirror Set",
    "3 cartas com o Selo do Espelho no ataque: ×1.3 Mult.": "3 cards with the Mirror Seal in the attack: ×1.3 Mult.",
    "Selo da Fortuna": "Fortune Seal",
    "Quando é canalizada, ganhas +2 ouro.": "When it is channelled, you gain +2 gold.",
    "Conjunto da Fortuna": "Fortune Set",
    "3 cartas com o Selo da Fortuna no ataque: +6 ouro.": "3 cards with the Fortune Seal in the attack: +6 gold.",
    # Dicas
    "Destreza: esta Criatura ganha +1 Mult por cada feitiço que lançares neste turno.": "Dexterity: this Creature gains +1 Mult for each spell you cast this turn.",
    "Persistir: na 1.ª vez que morre, a Criatura volta logo à Arena com −10 Poder.": "Persist: the first time it dies, the Creature comes straight back to the board with −10 Power.",
    "Delírio: junta no cemitério uma Criatura, um Feitiço, um Terreno e um Encantamento para o efeito disparar.":
        "Delirium: put a Creature, a Sorcery, a Land and an Enchantment in the graveyard to trigger the effect.",
    "Domínio: joga Terrenos de cores diferentes nesta batalha; cada cor conta.": "Domain: play Lands of different colours this battle; each colour counts.",
    "Energia (⚡): ganha-se com algumas cartas, fica até ao fim da batalha e gasta-se nos efeitos que a pedem.":
        "Energy (⚡): some cards give it, it stays until the end of the battle and is spent on the effects that ask for it.",
    "Coroa: enquanto a tiveres, compras +1 carta no início de cada turno. Perde-la quando um contra-ataque te fere.":
        "Crown: while you hold it, you draw +1 card at the start of each turn. You lose it when a counterattack hurts you.",
    "Mana de Sangue (🩸): se a mana não chegar, cada 🩸 do custo paga-se com 2 de vida (nunca a última).":
        "Blood Mana (🩸): if you lack mana, each 🩸 in the cost is paid with 2 life (never your last).",
    "Ponto fraco: cada carta da cor fraca do inimigo no ataque dá +0,5 Mult.": "Weak point: each card of the enemy's weak colour in the attack gives +0.5 Mult.",
    "Ritual: o boss vai fazer algo daqui a uns turnos. Um golpe de 15 % da vida máxima dele interrompe-o.":
        "Ritual: the boss will do something in a few turns. A single blow of 15% of its max life breaks it.",
    "Veteranos: a cada 5 ataques uma Criatura ganha uma estrela (+10 Poder para o resto da run, até 3).":
        "Veterans: every 5 attacks a Creature earns a star (+10 Power for the rest of the run, up to 3).",
    # Novidades da 0.15.0
    "Novidades da 0.15.0": "What's new in 0.15.0",
    "12 mecânicas novas: Destreza, Delírio, Domínio, Persistir, Veteranos, Energia, Coroa, Mana de Sangue, Excesso, Ponto fraco, Rituais e Constelações.":
        "12 new mechanics: Dexterity, Delirium, Domain, Persist, Veterans, Energy, Crown, Blood Mana, Overkill, Weak point, Rituals and Constellations.",
    "33 cartas novas, 12 relíquias e 3 selos.": "33 new cards, 12 relics and 3 seals.",
    "7 costas de carta novas, ganhas com conquistas.": "7 new card backs, earned with achievements.",
    "PORQUE PERDI? no fim de uma run perdida.": "WHY DID I LOSE? at the end of a lost run.",
    "Na loja, ↩ DESFAZER a última compra, serviço ou venda.": "In the shop, ↩ UNDO the last purchase, service or sale.",
    "Nomes novos e originais para cartas, baralhos, personagens e lugares.": "New, original names for cards, decks, characters and places.",
    "A batalha grava-se sozinha a cada jogada; na pausa há SAIR PARA O MENU.": "The battle saves itself after every play; the pause menu has EXIT TO MENU.",
    # Costas de carta novas (V1–V7) e as conquistas que as dão
    "Vitral": "Stained Glass",
    "Mapa Estelar": "Star Map",
    "Runas": "Runes",
    "Escamas de Dragão": "Dragon Scales",
    "Noite das Abóboras": "Pumpkin Night",
    "Floco de Neve": "Snowflake",
    "Vitral Vivo": "Living Stained Glass",
    "Vence uma run com um baralho de 3 cores ou mais.": "Win a run with a deck of 3 colours or more.",
    "Mestre Relojoeiro": "Master Clockmaker",
    "Vence uma run com Engrenagens ou com a Forja do Artífice.": "Win a run with Gears or with the Artificer's Forge.",
    "Sangue-Frio": "Cold Blood",
    "Derrota 10 bosses no Difícil (ou no Pesadelo).": "Defeat 10 bosses on Hard (or Nightmare).",
    "Joga uma batalha entre 25 de outubro e 2 de novembro.": "Play a battle between 25 October and 2 November.",
    "Inverno Arcano": "Arcane Winter",
    "Joga uma batalha em dezembro.": "Play a battle in December.",
}


def build_data(root):
    """Pares {português: inglês} dos textos dos dados novos."""
    return dict(EXTRA)
