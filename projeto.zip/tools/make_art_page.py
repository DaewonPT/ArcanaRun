#!/usr/bin/env python3
"""Gera a página "Arte do Zero-Sum" (prompts do Gemini em lotes de 10) a partir de tools/art_batches.json.

Uso: python3 tools/make_art_page.py <saida.html> [<lotes.txt>]
O 2.º argumento (opcional) escreve também uma versão em texto simples dos prompts.
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

PAGE = r'''<title>Arte do Zero-Sum</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Lora:wght@600;700&family=Inter:wght@400;500;600&display=swap">
<style>
/* Layout: uma coluna de lotes (cartões de trabalho), separadores por tipo e progresso no topo. */
:root{
  --bg:#f6f3fb; --panel:#ffffff; --ink:#221c33; --muted:#6b6283; --line:#ddd5ee;
  --gold:#a87412; --gold-ink:#ffffff; --done:#2f7d4f; --chip:#efe9f8;
  --display:"Lora", Georgia, "Times New Roman", serif;
  --body:"Inter", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  --mono:ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace;
}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){
  --bg:#17131f; --panel:#221c2e; --ink:#efe9fa; --muted:#a79cc0; --line:#3a3150;
  --gold:#f2b84b; --gold-ink:#1b1408; --done:#7fd69f; --chip:#2c2440; color-scheme:dark}}
:root[data-theme="dark"]{
  --bg:#17131f; --panel:#221c2e; --ink:#efe9fa; --muted:#a79cc0; --line:#3a3150;
  --gold:#f2b84b; --gold-ink:#1b1408; --done:#7fd69f; --chip:#2c2440; color-scheme:dark}
*{box-sizing:border-box}
body{background:var(--bg);color:var(--ink);font-family:var(--body);font-size:15px;line-height:1.5;
  padding-left:max(16px, env(safe-area-inset-left, 0px));padding-right:max(16px, env(safe-area-inset-right, 0px));padding-block:20px 48px}
.wrap{max-width:860px;margin:0 auto;display:flex;flex-direction:column;gap:18px}
h1{font-family:var(--display);font-weight:700;font-size:clamp(26px,5vw,36px);margin:0;letter-spacing:.2px;text-wrap:balance}
.lead{color:var(--muted);margin:0;max-width:65ch}
.how{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:14px 16px}
.how ol{margin:6px 0 0;padding-left:20px;display:grid;gap:4px}
.how code{font-family:var(--mono);font-size:13px;background:var(--chip);padding:1px 6px;border-radius:5px;word-break:break-all}
.bar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between}
.tabs{display:flex;flex-wrap:wrap;gap:6px}
.tab{font:inherit;font-weight:600;font-size:14px;border:1px solid var(--line);background:var(--panel);color:var(--ink);
  border-radius:999px;padding:7px 14px;min-height:40px;cursor:pointer;font-variant-numeric:tabular-nums}
.tab[aria-pressed="true"]{background:var(--gold);color:var(--gold-ink);border-color:var(--gold)}
.tab:focus-visible,.btn:focus-visible,summary:focus-visible{outline:3px solid var(--gold);outline-offset:2px}
.progress{font-variant-numeric:tabular-nums;color:var(--muted);font-weight:600}
.meter{height:6px;border-radius:99px;background:var(--chip);overflow:hidden}
.meter i{display:block;height:100%;width:0;background:var(--done);transition:width .3s}
.list{display:grid;gap:12px}
.batch{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:14px 16px;display:grid;gap:10px}
.batch.is-done{border-color:var(--done)}
.head{display:flex;flex-wrap:wrap;gap:4px 14px;align-items:baseline;justify-content:space-between}
.head h2{font-family:var(--display);font-size:20px;margin:0}
.folder{font-family:var(--mono);font-size:12.5px;color:var(--muted);word-break:break-all}
.items{margin:0;padding:0;list-style:none;display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:2px 14px;counter-reset:n}
.items li{counter-increment:n;font-size:14px;min-width:0}
.items li::before{content:counter(n) ". ";color:var(--muted);font-variant-numeric:tabular-nums}
.row{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.btn{font:inherit;font-weight:600;border-radius:9px;min-height:44px;padding:8px 16px;cursor:pointer;border:1px solid var(--line);background:var(--chip);color:var(--ink)}
.btn.primary{background:var(--gold);border-color:var(--gold);color:var(--gold-ink)}
.done-label{display:inline-flex;gap:8px;align-items:center;font-weight:600;min-height:44px;padding:0 6px;cursor:pointer}
.done-label input{width:20px;height:20px;accent-color:var(--done)}
.batch.is-done .done-label{color:var(--done)}
details summary{cursor:pointer;color:var(--muted);font-size:14px}
pre{white-space:pre-wrap;word-break:break-word;font-family:var(--mono);font-size:12.5px;background:var(--bg);border:1px solid var(--line);border-radius:8px;padding:10px;margin:8px 0 0;max-height:320px;overflow:auto}
.toast{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(18px + env(safe-area-inset-bottom, 0px));background:var(--ink);color:var(--bg);
  padding:10px 16px;border-radius:10px;font-weight:600;opacity:0;transition:opacity .2s;pointer-events:none}
.toast.on{opacity:1}
@media (prefers-reduced-motion: reduce){.meter i,.toast{transition:none}}
</style>
<div class="wrap">
  <header style="display:grid;gap:6px">
    <h1>Arte do Zero-Sum</h1>
    <p class="lead">__LEAD__</p>
  </header>
  <section class="how" aria-label="Como usar">
    <strong>Como usar</strong>
    <ol>
      <li>Carrega em <b>Copiar prompt</b> e cola no Gemini, num chat novo.</li>
      <li>Descarrega as imagens pela ordem (1 → 10) para a pasta indicada no lote, por exemplo <code>Downloads\Zero-Sum\Arte\Cartas 01</code>. Não precisas de lhes mudar o nome.</li>
      <li>Marca o lote como <b>Feito</b>. Se uma imagem sair mal (com texto, ou diferente da descrição), pede-a outra vez nesse mesmo chat.</li>
      <li>Quando tiveres lotes prontos, diz-me e eu ponho-os no jogo.</li>
    </ol>
  </section>
  <div class="bar">
    <div class="tabs" role="toolbar" aria-label="Tipo de imagens" id="tabs"></div>
    <div class="progress" id="progress"></div>
  </div>
  <div class="meter" aria-hidden="true"><i id="meter"></i></div>
  <div class="list" id="list"></div>
</div>
<div class="toast" id="toast" role="status" aria-live="polite"></div>
<script>
const BATCHES = __DATA__;
const GROUPS = [["cards","Cartas"],["portraits","Retratos"],["relics","Relíquias"],["backgrounds","Fundos"]];
const KEY = "zs-arte-feitos-v1";
let done = {};
try { done = JSON.parse(localStorage.getItem(KEY) || "{}") || {}; } catch (e) { done = {}; }
let group = "cards";
try { group = localStorage.getItem(KEY + "-tab") || "cards"; } catch (e) {}
const byId = (id) => document.getElementById(id);
function save(){ try { localStorage.setItem(KEY, JSON.stringify(done)); } catch (e) {} }
function toast(msg){ const t = byId("toast"); t.textContent = msg; t.classList.add("on"); clearTimeout(toast.h); toast.h = setTimeout(() => t.classList.remove("on"), 1800); }
function renderTabs(){
  const box = byId("tabs"); box.innerHTML = "";
  for (const [g, name] of GROUPS){
    const all = BATCHES.filter(b => b.g === g);
    if (!all.length) continue;
    const d = all.filter(b => done[b.t]).length;
    const b = document.createElement("button"); b.className = "tab"; b.type = "button"; b.id = "tab-" + g;
    b.textContent = name + " " + d + "/" + all.length; b.setAttribute("aria-pressed", String(g === group));
    b.onclick = () => { group = g; try { localStorage.setItem(KEY + "-tab", g); } catch (e) {} render(); };
    box.appendChild(b);
  }
  const total = BATCHES.length, dn = BATCHES.filter(b => done[b.t]).length;
  byId("progress").textContent = dn + " de " + total + " lotes feitos";
  byId("meter").style.width = (100 * dn / total) + "%";
}
async function copyText(text, el){
  try { await navigator.clipboard.writeText(text); toast("Prompt copiado"); }
  catch (e) {
    const det = el.querySelector("details"); if (det) det.open = true;
    const r = document.createRange(); r.selectNodeContents(el.querySelector("pre"));
    const s = getSelection(); s.removeAllRanges(); s.addRange(r);
    toast("Copia o texto selecionado");
  }
}
function render(){
  renderTabs();
  const list = byId("list"); list.innerHTML = "";
  for (const b of BATCHES.filter(x => x.g === group)){
    const el = document.createElement("article"); el.className = "batch" + (done[b.t] ? " is-done" : "");
    const id = b.t.normalize("NFD").replace(/[^\w]+/g, "-");
    el.innerHTML = '<div class="head"><h2></h2><span class="folder"></span></div><ol class="items"></ol>' +
      '<div class="row"><button class="btn primary" type="button">Copiar prompt</button>' +
      '<label class="done-label"><input type="checkbox" id="feito-' + id + '"> Feito</label></div>' +
      '<details><summary>Ver o prompt</summary><pre></pre></details>';
    el.querySelector("h2").textContent = b.t;
    el.querySelector(".folder").textContent = "Downloads\\Zero-Sum\\" + b.f;
    const ol = el.querySelector(".items");
    for (const l of b.l){ const li = document.createElement("li"); li.textContent = l; ol.appendChild(li); }
    el.querySelector("pre").textContent = b.p;
    el.querySelector(".btn").onclick = () => copyText(b.p, el);
    const cb = el.querySelector("input"); cb.checked = !!done[b.t];
    cb.onchange = () => { if (cb.checked) done[b.t] = true; else delete done[b.t]; save(); el.classList.toggle("is-done", cb.checked); renderTabs(); };
    list.appendChild(el);
  }
}
if (!GROUPS.some(g => g[0] === group && BATCHES.some(b => b.g === g[0]))) group = BATCHES.length ? BATCHES[0].g : "cards";
render();
</script>
'''


def main() -> None:
    out = Path(sys.argv[1])
    data = json.loads((ROOT / "tools" / "art_batches.json").read_text(encoding="utf-8"))
    batches = data["batches"]
    payload = [{"g": b["group"], "t": b["title"], "f": b["folder"].replace("/", "\\"), "l": b["labels"], "p": b["prompt"]} for b in batches]
    counts = {}
    for b in batches:
        counts[b["group"]] = counts.get(b["group"], 0) + 1
    lead = ("%d prompts para o Gemini, cada um com até 10 imagens: as cartas, os retratos dos inimigos e planeswalkers, "
            "as relíquias e os fundos dos atos e climas.") % len(batches)
    js = json.dumps(payload, ensure_ascii=False).replace("</", "<\\/")
    page = PAGE.replace("__DATA__", js).replace("__LEAD__", lead)
    out.write_text(page, encoding="utf-8")
    print("página:", out, len(page), "bytes;", counts)
    if len(sys.argv) > 2:
        lines = ["ARTE DO ZERO-SUM — prompts para o Gemini (lotes de 10 imagens)", "",
                 "Descarrega as imagens de cada lote pela ordem (1 a 10) para a pasta indicada.", ""]
        for b in batches:
            lines += ["=" * 70, "%s  →  Downloads\\Zero-Sum\\%s" % (b["title"], b["folder"].replace("/", "\\")),
                      "Imagens: " + ", ".join("%d %s" % (i + 1, l) for i, l in enumerate(b["labels"])), "-" * 70, b["prompt"], ""]
        Path(sys.argv[2]).write_text("\n".join(lines), encoding="utf-8")
        print("texto:", sys.argv[2])


if __name__ == "__main__":
    main()
