#!/usr/bin/env python3
"""Gera o ícone da app (icon.png, launcher 192, adaptive 432 fg/bg) e o splash (1280x720).

Arte: uma carta creme inclinada com um "0" grande e os "pips" + (azul) e − (vermelho):
tudo o que ganhas, alguém perde. Correr a partir da raiz do projeto:  python3 tools/make_icons.py
"""
import math
import os

from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT = "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf"
if not os.path.exists(FONT):
    FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

NAVY = (28, 26, 46, 255)
NAVY2 = (42, 35, 69, 255)
CREAM = (243, 231, 192, 255)
GOLD = (242, 187, 69, 255)
GOLD_LIGHT = (255, 235, 153, 255)
BLUE = (59, 159, 224, 255)
RED = (240, 76, 102, 255)


def font(size):
    return ImageFont.truetype(FONT, size)


def card(size, with_shadow=True):
    """Carta inclinada numa tela transparente size×size."""
    s = size
    canvas = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    cw, ch = int(s * 0.50), int(s * 0.68)
    # carta de trás (profundidade)
    back = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    bd = ImageDraw.Draw(back)
    bd.rounded_rectangle((0, 0, cw - 1, ch - 1), radius=int(s * 0.06), fill=(120, 95, 150, 255))
    back = back.rotate(9, expand=True, resample=Image.BICUBIC)
    # carta da frente
    front = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    fd = ImageDraw.Draw(front)
    border = max(3, int(s * 0.022))
    fd.rounded_rectangle((0, 0, cw - 1, ch - 1), radius=int(s * 0.06), fill=CREAM, outline=GOLD, width=border)
    # "0" central
    f0 = font(int(ch * 0.62))
    bbox = fd.textbbox((0, 0), "0", font=f0)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    fd.text(((cw - tw) / 2 - bbox[0], (ch - th) / 2 - bbox[1]), "0", font=f0, fill=NAVY)
    # pips
    fp = font(int(ch * 0.2))
    fd.text((int(cw * 0.09), int(ch * 0.03)), "+", font=fp, fill=BLUE)
    bb = fd.textbbox((0, 0), "−", font=fp)
    fd.text((cw - (bb[2] - bb[0]) - int(cw * 0.09) - bb[0], ch - (bb[3] - bb[1]) - int(ch * 0.06) - bb[1]), "−", font=fp, fill=RED)
    front = front.rotate(-7, expand=True, resample=Image.BICUBIC)
    if with_shadow:
        sh = Image.new("RGBA", front.size, (0, 0, 0, 0))
        sd = ImageDraw.Draw(sh)
        sd.rounded_rectangle((int(s * 0.04), int(s * 0.05), front.width - int(s * 0.02), front.height - int(s * 0.01)), radius=int(s * 0.06), fill=(0, 0, 0, 120))
        sh = sh.filter(ImageFilter.GaussianBlur(int(s * 0.03)))
        canvas.alpha_composite(sh, ((s - front.width) // 2, (s - front.height) // 2))
    canvas.alpha_composite(back, ((s - back.width) // 2 + int(s * 0.04), (s - back.height) // 2 - int(s * 0.02)))
    canvas.alpha_composite(front, ((s - front.width) // 2, (s - front.height) // 2))
    return canvas


def background(size, rounded=True):
    img = Image.new("RGBA", (size, size), NAVY)
    d = ImageDraw.Draw(img)
    # brilho radial suave
    glow = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse((int(size * 0.1), int(size * 0.0), int(size * 0.9), int(size * 0.8)), fill=(90, 70, 140, 110))
    glow = glow.filter(ImageFilter.GaussianBlur(int(size * 0.18)))
    img.alpha_composite(glow)
    if rounded:
        mask = Image.new("L", (size, size), 0)
        ImageDraw.Draw(mask).rounded_rectangle((0, 0, size - 1, size - 1), radius=int(size * 0.22), fill=255)
        out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        out.paste(img, (0, 0), mask)
        return out
    return img


def icon(size):
    img = background(size, rounded=True)
    img.alpha_composite(card(size))
    return img


def splash(w=1280, h=720):
    img = Image.new("RGBA", (w, h), (23, 20, 31, 255))
    glow = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse((int(w * 0.25), int(h * 0.1), int(w * 0.75), int(h * 0.9)), fill=(80, 60, 130, 90))
    img.alpha_composite(glow.filter(ImageFilter.GaussianBlur(120)))
    c = card(300, with_shadow=True)
    d = ImageDraw.Draw(img)
    ft = font(150)
    title = "ZERO-SUM"
    bb = d.textbbox((0, 0), title, font=ft)
    tw, th = bb[2] - bb[0], bb[3] - bb[1]
    total_w = c.width - 40 + tw + 24
    x0 = (w - total_w) // 2
    img.alpha_composite(c, (x0, (h - c.height) // 2 - 30))
    tx = x0 + c.width - 40 + 24
    ty = (h - th) // 2 - 50 - bb[1]
    d.text((tx + 4, ty + 6), title, font=ft, fill=(0, 0, 0, 140))
    d.text((tx, ty), title, font=ft, fill=GOLD_LIGHT)
    fs = font(30)
    sub = "Cada vitória é a derrota de alguém."
    d.text((tx + 8, ty + bb[3] + 22), sub, font=fs, fill=(178, 178, 204, 255))
    return img


def main():
    out = os.path.join(ROOT, "assets", "icons")
    os.makedirs(out, exist_ok=True)
    icon(512).save(os.path.join(ROOT, "icon.png"))
    icon(192).save(os.path.join(out, "icon_192.png"))
    # Adaptive: o Android recorta a máscara; a arte tem de caber no círculo central (66 %).
    fg = Image.new("RGBA", (432, 432), (0, 0, 0, 0))
    art = card(300)
    fg.alpha_composite(art, ((432 - art.width) // 2, (432 - art.height) // 2))
    fg.save(os.path.join(out, "adaptive_fg_432.png"))
    background(432, rounded=False).save(os.path.join(out, "adaptive_bg_432.png"))
    splash().save(os.path.join(ROOT, "splash.png"))
    print("ok:", out)


if __name__ == "__main__":
    main()
