#!/usr/bin/env python3
"""Gera o ícone da app (icon.png 512, launcher 192, adaptativo 432 frente/fundo) e o splash (1280x720).

0.13.1: arte "leque de cartas" — três cartas em leque (azul com +, creme com o 0, vermelha com −) com
moldura dourada, num fundo roxo com brilho. As fontes estão em tools/brand/ (SVG e HTML; a pasta tem
.gdignore para o Godot não as importar):
  icone.svg          ícone completo (cantos redondos)       -> icon.png, assets/icons/icon_192.png
  icone_frente.svg   só as cartas, na zona segura (264 px)  -> assets/icons/adaptive_fg_432.png
  icone_fundo.svg    fundo do ícone adaptativo             -> assets/icons/adaptive_bg_432.png
  splash.html        ícone + título em New Rocker dourado  -> splash.png

Desenha com o Chromium do Playwright (pip install playwright && playwright install chromium, se faltar).
Correr a partir da raiz do projeto:  python3 tools/make_icons.py
"""
import os
import pathlib

from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
BRAND = ROOT / "tools" / "brand"

JOBS = [
    ("icone.svg", 512, ROOT / "icon.png", True),
    ("icone.svg", 192, ROOT / "assets" / "icons" / "icon_192.png", True),
    ("icone_frente.svg", 432, ROOT / "assets" / "icons" / "adaptive_fg_432.png", True),
    ("icone_fundo.svg", 432, ROOT / "assets" / "icons" / "adaptive_bg_432.png", False),
]


def main() -> None:
    page_file = BRAND / "_render.html"
    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--allow-file-access-from-files"])
        for svg, px, out, transparent in JOBS:
            page = browser.new_page(viewport={"width": px, "height": px})
            page_file.write_text(f'<html><body style="margin:0;background:transparent"><img src="{svg}" width="{px}" height="{px}" style="display:block"></body></html>')
            page.goto(page_file.as_uri())
            page.wait_for_timeout(300)
            page.screenshot(path=str(out), omit_background=transparent)
            page.close()
            print("escrito", out.relative_to(ROOT))
        page = browser.new_page(viewport={"width": 1280, "height": 720})
        page.goto((BRAND / "splash.html").as_uri())
        page.wait_for_timeout(1000)   # tempo para as fontes carregarem
        page.screenshot(path=str(ROOT / "splash.png"))
        page.close()
        print("escrito splash.png")
        browser.close()
    if page_file.exists():
        os.remove(page_file)


if __name__ == "__main__":
    main()
