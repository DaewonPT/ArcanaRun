# -*- coding: utf-8 -*-
"""Traduções para inglês da 0.18.0 (importado por tools/make_en_json.py, depois do en_0170).

CODE: textos da interface (chave = o texto em português, como no código).
Dados (emparelhados pelos ids, para os textos portugueses poderem mudar sem se perder a tradução):
  ABOUT    — o ecrã Sobre (data/about.json): créditos e política de privacidade;
  CARDS    — (os equipamentos traduzem-se no tools/make_cards_en.py);
  ACHIEVEMENTS, COSMETICS — conquistas e cosméticos novos;
EXTRA: textos soltos que não estão em nenhum tr("…") literal (nomes dos nós do mapa, tipos…).
"""
import json
import os

CODE = {
    # Ecrã Sobre (menu principal).
    "SOBRE": "ABOUT",
    "SOBRE O ZERO-SUM": "ABOUT ZERO-SUM",
    "Versão %s": "Version %s",
    "CRÉDITOS": "CREDITS",
    "CONTACTOS": "CONTACT",
    "PRIVACIDADE": "PRIVACY",
    "LICENÇAS": "LICENSES",
    " e ": " and ",
    "Contacto": "Contact",
    "ESCREVER": "WRITE",
    "COPIAR": "COPY",
    "Email copiado.": "Email copied.",
    "Sugestões, dúvidas e elogios são bem-vindos. Respondemos em português ou em inglês.":
        "Suggestions, questions and praise are welcome. We reply in Portuguese or English.",
    "Reportar um erro": "Report a bug",
    "Encontraste um erro? Toca em REPORTAR UM ERRO: abre-se a tua app de email com o relatório técnico (versão, telemóvel e as últimas mensagens de erro do jogo). Escreve por cima o que aconteceu e envia. O relatório fica também copiado, se preferires colá-lo noutro sítio.":
        "Found a bug? Tap REPORT A BUG: your email app opens with the technical report (version, phone and the game's latest error messages). Write what happened above it and send. The report is also copied, in case you'd rather paste it somewhere else.",
    "REPORTAR UM ERRO": "REPORT A BUG",
    "SÓ COPIAR O RELATÓRIO": "JUST COPY THE REPORT",
    "Relatório copiado: cola-o numa mensagem para %s.": "Report copied: paste it into a message to %s.",
    "VER A POLÍTICA DE PRIVACIDADE": "SEE THE PRIVACY POLICY",
    "Zero-Sum %s": "Zero-Sum %s",
    "Zero-Sum %s — erro": "Zero-Sum %s — bug",
    "Não encontrámos uma app de email: o endereço ficou copiado.": "No email app found: the address was copied.",
    "O que aconteceu (e o que estavas a fazer):": "What happened (and what you were doing):",
    "Relatório pronto no email (e copiado). Obrigado!": "Report ready in your email (and copied). Thank you!",
    "Não encontrámos uma app de email. O relatório ficou copiado: envia-o para %s.":
        "No email app found. The report was copied: send it to %s.",
    "Política de privacidade e proteção de dados": "Privacy and data protection policy",
    "Última atualização: %s": "Last updated: %s",
    "O Zero-Sum é feito com o Godot Engine, distribuído com esta licença:":
        "Zero-Sum is made with Godot Engine, distributed under this license:",
    "Tipos de letra": "Fonts",
    "Componentes do Godot Engine": "Godot Engine components",
    "Textos das licenças": "License texts",
    "Toca numa licença para ler o texto completo.": "Tap a license to read its full text.",
    "ABRIR O SITE": "OPEN THE WEBSITE",
    # (19) Equipamentos
    "Equipamento": "Equipment",
    "Mult": "Mult",
    "%s fica em %s.": "%s goes on %s.",
    "%s passa para %s.": "%s moves to %s.",
    "%s fica à espera de uma criatura (equipa-a depois por %d de mana).": "%s waits for a creature (equip one later for %d mana).",
    "%s fica sem dono: toca nele para o passar a outra criatura (%d de mana).": "%s has no bearer: tap it to move it to another creature (%d mana).",
    "%s: em %s.": "%s: on %s.",
    "%s: à espera de uma criatura (toca para a equipar por %d de mana).": "%s: waiting for a creature (tap to equip one for %d mana).",
    "Equipar quem?": "Equip whom?",
    "O número é o ataque deste turno com o equipamento nessa criatura.": "The number is this turn's attack with the equipment on that creature.",
    "Está em %s.": "It's on %s.",
    "Está à espera de uma criatura.": "It's waiting for a creature.",
    "Mudar para outra criatura (%d de mana):": "Move it to another creature (%d mana):",
    "Equipar uma criatura (%d de mana):": "Equip a creature (%d mana):",
    "Precisas de %d de mana (tens %d).": "You need %d mana (you have %d).",
    "VER A CARTA": "SEE THE CARD",
    "Criaturas %d · Feitiços %d · Encantamentos %d · Equipamentos %d · Terrenos %d · custo médio %s":
        "Creatures %d · Spells %d · Enchantments %d · Equipment %d · Lands %d · average cost %s",
    # (24) Batalhas com outro objetivo
    "Emboscada: o inimigo ataca antes do teu 1.º turno. Vencer dá +%d %% de ouro.":
        "Ambush: the enemy attacks before your 1st turn. Winning gives +%d %% gold.",
    "Cerco: no fim de cada turno o inimigo cura %d %% da vida máxima, mas tens +%d turno (e +%d ouro).":
        "Siege: at the end of each turn the enemy heals %d %% of its max life, but you get +%d turn (and +%d gold).",
    "Fuga: basta sobreviveres %d turnos. Se o venceres mesmo assim, +%d %% de ouro.":
        "Escape: you just need to survive %d turns. If you beat it anyway, +%d %% gold.",
    "EMBOSCADA!": "AMBUSH!",
    "Emboscada! %s atacou antes de ti: −%d de vida.": "Ambush! %s struck before you: −%d life.",
    "Cerco: %s recupera %s de vida.": "Siege: %s recovers %s life.",
    "FUGISTE!": "YOU ESCAPED!",
    # (25) Dupla
    "Dupla: os dois contra-atacam. Toca no retrato pequeno para mudar de alvo; o excesso do golpe passa para o outro.":
        "Pair: both strike back. Tap the small portrait to switch targets; the excess of a blow carries over to the other.",
    "Toca para atacar %s": "Tap to attack %s",
    "%s caiu": "%s fell",
    "%s caiu! %s passa a ser o alvo.": "%s fell! %s is now the target.",
    "Alvo: %s.": "Target: %s.",
    "Não deu para abrir o navegador: o endereço ficou copiado.": "Couldn't open the browser: the address was copied.",
}

ABOUT_CREDITS = {
    "studio": ("Estúdio", "Studio"),
    "design": ("Criação e design", "Design and creation"),
    "testers": ("Testes de jogo", "Game testing"),
    "engine": ("Motor", "Engine"),
    "fonts": ("Tipos de letra", "Fonts"),
    "art": ("Ilustrações, música e efeitos sonoros", "Illustrations, music and sound effects"),
}
ABOUT_NAMES = {
    "Godot Engine 4.3 (licença MIT)": "Godot Engine 4.3 (MIT license)",
    "Inter, Lora e New Rocker (SIL Open Font License)": "Inter, Lora and New Rocker (SIL Open Font License)",
    "Originais, feitos para o Zero-Sum": "Original, made for Zero-Sum",
}
ABOUT_THANKS = "Thank you for playing!"
PRIVACY = {
    "p_who": ("Who is responsible",
              "Zero-Sum is a game by Pixel Lusitano, the independent studio of AlizeOnMe, in Portugal. For any question about privacy or your data, write to contact@pixellusitano.com."),
    "p_device": ("What stays on your phone",
                 "Your progress, saved runs, settings, statistics and achievements stay on your phone only. There are no accounts, ads, usage analytics or in-game purchases. The game does not ask for your location, contacts, camera, microphone or files."),
    "p_internet": ("Internet connections",
                   "When it opens, the game asks GitHub whether there is a new version (api.github.com) and new content (daewonpt.github.io). None of your data or progress is sent in those requests; as with any Internet connection, GitHub receives the IP address and the type of device, which it handles under its own privacy policy. Without Internet, the game works just the same."),
    "p_update": ("Updates",
                 "If you tap UPDATE, the browser opens the new version's file on GitHub and Android asks whether you want to install it. Your progress stays on the phone."),
    "p_report": ("Reporting a bug",
                 "REPORT A BUG opens your email app with a technical report: the game version, the phone's model and system, the screen size, the language, the difficulty, a summary of the saved run, your statistics numbers and the latest error messages. It is only sent if you press send. Your email and the report are used only to fix the bug and reply to you, and are deleted when no longer needed (at most 12 months later)."),
    "p_clipboard": ("Copying and sharing",
                    "Progress and deck codes, run sharing and the bug report only go to the clipboard when you tap the button; then you decide where to paste them."),
    "p_permissions": ("Android permissions",
                      "Internet, for the two checks above, and vibration, for haptic effects (turn them off in Settings → Sound)."),
    "p_children": ("Children",
                   "The game collects no data from anyone, children included. If a child writes to us, the email is deleted at the request of their parents or guardians."),
    "p_rights": ("Your rights",
                 "Under the General Data Protection Regulation (GDPR), you can ask to access, correct or delete the data you sent us by email, or object to its processing, by writing to contact@pixellusitano.com. You can also complain to the Portuguese data protection authority, CNPD (www.cnpd.pt). To delete everything the game keeps on your phone, use Settings → Game → Erase progress, or uninstall the game."),
    "p_changes": ("Changes",
                  "If this policy changes, the new version appears here, with the updated date."),
}

EXTRA = {
    # Nomes dos nós e das batalhas especiais (Map.NODE_INFO, Battle.VARIANT_NAMES, BattleRewards.LINE_NAMES)
    "Emboscada": "Ambush",
    "Cerco": "Siege",
    "Fuga": "Escape",
    "Dupla": "Pair",
    "Ataca primeiro · +50 % de ouro": "Strikes first · +50 % gold",
    "Cura-se · +1 turno · +3 ouro": "Heals itself · +1 turn · +3 gold",
    "Sobrevive 4 turnos": "Survive 4 turns",
    "Dois inimigos · +5 ouro": "Two enemies · +5 gold",
    "Emboscada (+50 %)": "Ambush (+50 %)",
    "Venceste em vez de fugir (+50 %)": "You won instead of escaping (+50 %)",
    "Dupla: os dois contra-atacam. Toca num para ser o alvo; o excesso do golpe passa para o outro.":
        "Pair: both strike back. Tap one to make it the target; the excess of a blow carries over to the other.",
    # Equipamentos (BattleManager.play_block_reason, separadores e filtros)
    "Já tens o máximo de equipamentos em jogo.": "You already have the maximum equipment in play.",
    "Equipamentos": "Equipment",
    # Novidades da 0.18.0 (data/news.json)
    "Novidades da 0.18.0": "What's new in 0.18.0",
    "Equipamentos: cartas que ficam presas a uma criatura e lhe dão Poder, Mult ou uma palavra-chave.":
        "Equipment: cards that stay attached to a creature and give it Power, Mult or a keyword.",
    "Emboscada, Cerco e Fuga: batalhas com outro objetivo no mapa.": "Ambush, Siege and Escape: battles with a different goal on the map.",
    "Dupla: dois inimigos de uma vez — escolhes o alvo e o excesso do golpe passa para o outro.":
        "Pair: two enemies at once — you pick the target and the excess of a blow carries over to the other.",
    "Botão SOBRE no menu: créditos, contactos, reportar um erro e política de privacidade.":
        "ABOUT button in the menu: credits, contact, bug reports and privacy policy.",
    "A batalha já não fica cortada depois do ataque com a escala a 100 %.": "The battle is no longer cut off after the attack at 100 % scale.",
    # Palavras-chave da 0.15.0 que tinham ficado sem inglês (CardData.KEYWORD_NAMES / KEYWORD_TEXT)
    "Destreza": "Dexterity",
    "Persistir": "Persist",
    "Destreza: +1 Mult por cada feitiço lançado neste turno.": "Dexterity: +1 Mult for each spell cast this turn.",
    "Persistir: na 1.ª vez que morre em cada batalha, volta à Arena com −10 Poder.":
        "Persist: the first time it dies in each battle, it comes back to the board with −10 Power.",
}

ACHIEVEMENTS = {
    "equip_10": ["Armourer", "Equip creatures 10 times."],
    "ambush_3": ["Unafraid of Ambushes", "Win 3 Ambushes."],
    "siege_3": ["Siege Breaker", "Win 3 Sieges."],
    "escape_3": ["Light Feet", "Survive 3 Escapes."],
    "escape_kill_1": ["Didn't Run After All", "In an Escape, beat the enemy instead of escaping."],
    "pair_5": ["Two at Once", "Win 5 Pair battles."],
}
TIPS = {
    "equipment": "Equipment: stays in play attached to a creature and gives it Power, Mult or a keyword. Drop it onto the creature you want. If that creature dies, tap the equipment to move it for 1 mana.",
    "ambush": "Ambush: the enemy attacks before your 1st turn (it never kills you). Winning gives +50 % gold.",
    "siege": "Siege: the enemy heals 5 % of its max life at the end of each turn, but you get +1 turn. Hit hard and early.",
    "escape": "Escape: the enemy is stronger, but you just need to survive 4 turns. If you beat it anyway, you get +50 % gold.",
    "pair": "Pair: two enemies with separate life and both strike back. Tap the small portrait to switch targets; the excess of a blow carries over to the other.",
}
GLOSSARY = {
    "Equipamento": "A card that stays in play attached to a creature: it adds its Power and its attack effects to that creature and passes on its keywords. Each creature holds at most one. If it dies, the equipment waits and can be moved for 1 mana.",
}


def _load(root, name):
    path = os.path.join(root, "data", name)
    return json.load(open(path, encoding="utf-8")) if os.path.exists(path) else []


def _put(out, pt, en):
    if isinstance(pt, str) and pt and isinstance(en, str) and en:
        out[pt] = en


def build_data(root):
    """Pares {português: inglês} dos textos dos dados novos (pelos ids) e os de EXTRA."""
    out = {}
    about = _load(root, "about.json")
    if about and isinstance(about[0], dict):
        a = about[0]
        for cr in a.get("credits", []):
            t = ABOUT_CREDITS.get(str(cr.get("id", "")))
            if t:
                _put(out, cr.get("role"), t[1])
            for n in cr.get("names", []):
                _put(out, n, ABOUT_NAMES.get(n))
        _put(out, a.get("thanks"), ABOUT_THANKS)
        for sec in a.get("privacy", []):
            t = PRIVACY.get(str(sec.get("id", "")))
            if t:
                _put(out, sec.get("title"), t[0])
                _put(out, sec.get("text"), t[1])
    for a in _load(root, "achievements.json"):
        t = ACHIEVEMENTS.get(str(a.get("id", "")))
        if t:
            _put(out, a.get("name"), t[0])
            _put(out, a.get("text"), t[1])
    for tip in _load(root, "tips.json"):
        _put(out, tip.get("text"), TIPS.get(str(tip.get("id", ""))))
    for g in _load(root, "glossary.json"):
        _put(out, g.get("text"), GLOSSARY.get(str(g.get("term", ""))))
    out.update(EXTRA)
    return out
